# IBM Storage Fusion Management Operator

## Introduction

IBM Storage Fusion provides container-native data and storage services for your OpenShift workloads.
Bring applications to production faster, with data services that are simple, consistent, and strategic.

### Summary

Protect your applications with efficient incremental snapshots of stateful data.  Use local snapshots for fast recovery, and offload copies to object storage to protect against cluster outages.

IBM Storage Fusion puts you in control of how data consistency is achieved, with support for both application-consistency and crash-consistency
  - Crash consistency - Creates a backup without pausing application I/O, avoiding affecting application performance, but not capturing application data still in memory.  Many modern container workloads are able to take advantage of this type of consistency.
  - Application consistency - creates a backup by queiscing application IO, preserving 100% of application writes.

### Features

* Modenlization and Cloud Native Workload on OCP 4.10 and higher
* Validated workload performance with IBM Cloud Paks
* Simplified Management Console User experience
* Application-centric Backup and Restore to S3 and Azure block
* Application-consistent Backup and Restore
* Crash Consistent Backup and Restore
* High performance distributed storage capabilities, like Consistency Groups, Storage tiers, compression for PV, filesystem encryption
* Bundle OpenShift Data Fundation Essentials

## Details

### Supported platforms

Red Hat OpenShift Container Platform 4.10 or higher installed on one of the following platforms:
  - Linux x86_64
  - Z s390x

## Prerequisites

IBM Storage Fusion requires Red Hat OpenShift Container Platform that is installed on any of the following supported platforms: On-premises VMware 7.0, On-premises Bare Metal, On-premises zLinux, IBM Cloud, Amazon Web Services, or Azure.

Ensure that you have a minimum of 344 GB of (Read Write Once) RWO storage and a configured storage class so that IBM Storage Fusion can create persistent volumes dynamically for hosting its internal data catalog. To know about all prerequisites, [Learn More](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=fusion-prerequisites)

## Resources Required

To learn about the IBM Storage Fusion system requirements, visit our [requirements doc](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=prerequisites-system-requirements)


## Installing IBM Storage Fusion

### Planning your installation
IBM Storage Fusion provides two choices for storage provisioning:
  - Remote storage access - Attaches to a remote IBM Spectrum Scale file system. Use it to access existing data sets as well as for provisioning storage for workloads in the local OpenShift cluster.
  - Red Hat OpenShift Data Foundation - Provides storage by using devices in the local Red Hat OpenShift cluster.

### How to Install
  - Firstly, [create a pull secret](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=prerequisites-creating-image-pull-secret) to access the IBM Storage Fusion services from IBM Registry.
  - Click the Install to begin the IBM Storage Fusion operator installation and follow the on-screen instructions to complete the installation procedure.
  - After creating the custom resource, click `IBM Storage Fusion` from the Applications menu to open the IBM Storage Fusion user interface.
  
## Configuration

To confirm whether the configuration is correct and the installation is successful, refer [Prerequisites](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=fusion-validating-storage-installation)

## Storage

Storage provisioning is automated through the Container Storage Interface. IBM Storage Fusion provides two choices for storage provisioning:
  - Red Hat OpenShift® Data Foundation - IBM Storage Fusion provides entitlement for Red Hat OpenShift Data Foundation.
  - Remote IBM Spectrum Scale file system mount - Connects to an external IBM Spectrum Scale cluster to access an existing file system. Container workloads running in Red Hat OpenShift can access existing data sets stored in the IBM Spectrum Scale file system and provision new persistent volumes backed by storage from the remote IBM Spectrum Scale file system.

## Data protection
Protect your applications with efficient incremental snapshots of stateful data. Use local snapshots for fast recovery and offload copies to object storage to protect against cluster outages.

IBM Storage Fusion puts you in control of how data consistency is achieved with support for both application-consistency and crash-consistency:
  - Crash consistency - Creates a backup without pausing application I/O and impacting application performance. It does not capture application data that is still in memory. Many modern container workloads are able to take advantage of this type of consistency.
  - Application consistency - Creates a backup by quiescing application I/O and preserving 100% of application writes.

## Limitations

  - Prerequisites and procedure to install IBM Storage Fusion software on Red Hat OpenShift® Container Platform that runs on On-premises VMware® 7.0, On-premises Bare Metal, On-premises zLinux, IBM Cloud, Amazon Web Services, or Azure.
  - Ensure that you have the infrastructure and Red Hat® OpenShift® Container Platform 4.10 or higher. Red Hat OpenShift Data Foundation service is available only on OpenShift Container Platform 4.10. [Learn More]( https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=troubleshooting)

   
## Documentation

  - [Global Data Platform](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=services-global-data-platform)
  - [Fusion Data Foundation](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=storage-fusion-data-foundation)
  - [Data Cataloging](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=data-cataloging)
  - [Data Protection](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=data-protection)
  - [Data Recovery](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=disaster-recovery)
  - [Workload](https://ibm.com/docs/en/storage-fusion-software/2.8.x?topic=workloads)



## Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
allowHostPorts: false
priority: null
requiredDropCapabilities:
  - ALL
allowPrivilegedContainer: false
runAsUser:
  type: MustRunAsRange
users: []
allowHostDirVolumePlugin: false
allowHostIPC: false
seLinuxContext:
  type: MustRunAs
readOnlyRootFilesystem: false
metadata:
  annotations:
    include.release.openshift.io/ibm-cloud-managed: 'true'
    include.release.openshift.io/self-managed-high-availability: 'true'
    include.release.openshift.io/single-node-developer: 'true'
    kubernetes.io/description: >-
      restricted denies access to all host features and requires pods to be run
      with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated
      users.
    release.openshift.io/create-only: 'true'
  creationTimestamp: '2021-07-16T09:49:07Z'
  generation: 1
  managedFields:
    - apiVersion: security.openshift.io/v1
      fieldsType: FieldsV1
      fieldsV1:
        'f:seLinuxContext':
          .: {}
          'f:type': {}
        'f:readOnlyRootFilesystem': {}
        'f:metadata':
          'f:annotations':
            .: {}
            'f:include.release.openshift.io/ibm-cloud-managed': {}
            'f:include.release.openshift.io/self-managed-high-availability': {}
            'f:include.release.openshift.io/single-node-developer': {}
            'f:kubernetes.io/description': {}
            'f:release.openshift.io/create-only': {}
        'f:volumes': {}
        'f:groups': {}
        'f:defaultAddCapabilities': {}
        'f:allowedCapabilities': {}
        'f:supplementalGroups':
          .: {}
          'f:type': {}
        'f:allowHostPID': {}
        'f:allowHostNetwork': {}
        'f:allowPrivilegeEscalation': {}
        'f:users': {}
        'f:runAsUser':
          .: {}
          'f:type': {}
        'f:allowHostPorts': {}
        'f:priority': {}
        'f:requiredDropCapabilities': {}
        'f:allowPrivilegedContainer': {}
        'f:allowHostDirVolumePlugin': {}
        'f:fsGroup':
          .: {}
          'f:type': {}
        'f:allowHostIPC': {}
      manager: cluster-version-operator
      operation: Update
      time: '2021-07-16T09:49:07Z'
  name: ibm-spectrum-fusion-operator
fsGroup:
  type: MustRunAs
groups: []
kind: SecurityContextConstraints
defaultAddCapabilities: null
supplementalGroups:
  type: RunAsAny
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
allowHostPID: false
allowHostNetwork: false
allowPrivilegeEscalation: false
apiVersion: security.openshift.io/v1
allowedCapabilities: null
```

## PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition: No requirement