# Cognos Analytics

https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-svc.html

# Introduction
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-svc.html

# Details
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-svc.html
## Prerequisites
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-adm-cmd.html

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
...
```

### Resources Required
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-instance.html

# Installing
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-svc-install.html

## Configuration

https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-instance.html

## Storage
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-instance.html


## Limitations
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-instance.html

## Documentation

https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/analytics/ca-svc.html
