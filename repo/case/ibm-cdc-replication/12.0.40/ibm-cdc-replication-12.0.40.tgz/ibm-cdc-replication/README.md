# ibm-cdc-replication

IBM Data Replication CDC Engine CASE bundle.

Deploys the IBM CDC Engine (UDB and Java Engine variants) on Red Hat OpenShift via the `cdc-replication` Helm chart.
