# cdcReplicationSetup

Inventory item for setting up the IBM CDC Replication Engine.

Installs the `cdc-replication` Helm chart and registers the CDC Engine container images for air-gap mirroring.
