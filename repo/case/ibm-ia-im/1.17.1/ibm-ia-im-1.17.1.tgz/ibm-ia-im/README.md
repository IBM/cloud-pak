# Name

IBM&reg; (IBM Infrastructure Management Install Operator)

# Introduction

## Summary

IBM Infrastructure Management Install Operator follows the Kubernetes Operator pattern to provide a way to deploy and manage the install of IBM Infrastructure Management on an OCP4 cluster. 

## Features

* deploy the install of IBM Infrastructure Management inside an OCP4 cluster
* manage the install of IBM Infrastructure Management inside an OCP4 cluster

# Details

## Prerequisites

Supported container platforms:
  - OpenShift v4.3+

### Resources Required

* At least 1GB of persistent storage, minimum 50m CPU and 64MB memory available for resource requests.

# Installing

The `CASE` has the following inventory items:

* `ibmInfraManagementInstallOperatorSetup`: Contains the CRD for the IBM Infrastructure Management Install operator
* `ibmInfraManagementInstallOperator`: Contains the CSV and CR for the IBM Infrastructure Management Install operator

## Configuration

See each inventory item for specific configuration information.

## Storage

## Limitations

* This product is limited to install on amd64

## Documentation

* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.

### PodSecurityPolicy Requirements

The predefined PodSecurityPolicy name `ibm-anyuid-psp` has been verified for this operator. If your target namespace is bound to this PodSecurityPolicy, you can proceed to install the operator.

### SecurityContextConstraints Requirements

This operator is supported on Red Hat OpenShift.

The predefined SecurityContextConstraints name: [`ibm-anyuid-scc`](https://ibm.biz/cpkspec-scc) has been verified for this operator.

This operator requires a SecurityContextConstraints to be bound to the target namespace prior to installation.

This operator also defines a custom SecurityContextConstraints object which is used to finely control the permissions/capabilities needed to deploy this operator, the definition of this SCC is shown below:

```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: anyuid
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: RunAsAny
groups:
- system:cluster-admins
priority: 10
readOnlyRootFilesystem: false
requiredDropCapabilities:
- MKNOD
runAsUser:
  type: RunAsAny
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users:
- system:serviceaccount:openshift-operators:default
- system:serviceaccount:cp4m:default
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```