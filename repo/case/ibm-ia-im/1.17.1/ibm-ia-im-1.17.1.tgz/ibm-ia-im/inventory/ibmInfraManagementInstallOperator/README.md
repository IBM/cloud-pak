# IBM Infrastructure Management Install Operator

Contains IBM Infrastructure Management Install Operator custom resource and launch scripts to install/delete the custom resources
