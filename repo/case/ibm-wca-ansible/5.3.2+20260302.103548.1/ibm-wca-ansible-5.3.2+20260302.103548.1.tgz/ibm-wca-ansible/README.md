watsonx Code Assistant for Red Hat Ansible Lightspeed
