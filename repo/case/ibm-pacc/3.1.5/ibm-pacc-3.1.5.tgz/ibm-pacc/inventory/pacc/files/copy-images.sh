#!/usr/bin/env bash
set -euo pipefail

# Configuration
PRIVATE_TARGET_REGISTRY="${1:-}"
RESOURCE_FILE="../resources.yaml"

MAX_RETRIES=2
RETRY_DELAY=5

# Define terminal colors
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
BOLD=$(tput bold)
RESET=$(tput sgr0)

# Fail if the target registry name is not provided
if [[ -z "$PRIVATE_TARGET_REGISTRY" ]]; then
  echo "${RED}Error: PRIVATE_TARGET_REGISTRY is not set.${RESET}"
  echo "Usage: $0 <private-target-registry>"
  exit 1
fi

# Check required tools installed
for cmd in skopeo yq jq; do
  command -v "$cmd" >/dev/null || {
    echo "${RED}Error: Missing required command: $cmd${RESET}"
    exit 1
  }
done

# Copy with retry (clean logging)
copy_with_retry() {
  local source="$1" dest="$2" attempt=1
  local errfile
  errfile=$(mktemp)

  while [[ $attempt -le $MAX_RETRIES ]]; do
    echo "Attempt ${attempt}/${MAX_RETRIES}: ${source} -> ${dest}"

    if skopeo copy --all --preserve-digests \
        "docker://$source" \
        "docker://$dest" \
        >/dev/null 2>"$errfile"; then
      return 0
    fi

    ((attempt++))
    if [[ $attempt -le $MAX_RETRIES ]]; then
      echo "Failed. Retrying."
      sleep "$RETRY_DELAY"
    fi
  done

  echo
  echo "${YELLOW}Make sure you are logged into both source and target registries:${RESET}"
  echo "  skopeo login $SOURCE_REGISTRY -u <myuser>"
  echo "  skopeo login $PRIVATE_TARGET_REGISTRY -u <myuser>"
  echo
  echo "${RED}Image copy failed. Error details:${RESET}"
  cat "$errfile"
  rm -f "$errfile"
  return 1
}

yq -o=json '.resources.resourceDefs.containerImages[]' "$RESOURCE_FILE" \
  | jq -c '.' \
  | while read -r entry; do

    IMAGE=$(jq -r '.image' <<< "$entry")
    TAG=$(jq -r '.tag' <<< "$entry")
    SOURCE_REGISTRY=$(jq -r '.registries[0].host' <<< "$entry")

    if [[ -z "$SOURCE_REGISTRY" || "$SOURCE_REGISTRY" == "null" ]]; then
      echo "${RED}Error: Source registry missing for image $IMAGE.${RESET}"
      exit 1
    fi

    SOURCE_IMAGE="${SOURCE_REGISTRY}/${IMAGE}:${TAG}"
    IMG_NAME=$(basename "$IMAGE")
    DEST_IMAGE="${PRIVATE_TARGET_REGISTRY}/${IMG_NAME}:${TAG}"

    copy_with_retry "$SOURCE_IMAGE" "$DEST_IMAGE"
  done

echo
echo "${GREEN}Complete.${RESET}"
