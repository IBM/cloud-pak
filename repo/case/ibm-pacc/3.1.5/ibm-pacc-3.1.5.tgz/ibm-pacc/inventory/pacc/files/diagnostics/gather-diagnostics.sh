#  IBM
#  (C) Copyright IBM Corp. 2021, 2024

#  The source code for this program is not published or
#  otherwise divested of its trade secrets, irrespective
#  of what has been deposited with the U.S. Copyright Office.
 

# Gather diagnostics of Planning Analytics Certified Container deployments

###
### Settings
###

# Namespaces to collect diagnostics from - update this section
operator_ns="pa-operators"  # The namespace where the PA operators are deployed
paw_ns="paw"                # The namespace running PA Workspace
pass_ns="pass"              # The namespace running PA Spreadsheet Services
pae_ns="tm1"                # The namespace running PA Engine

# Folder to store results. Default name is timestamped
outdir="$(date +%F_%H-%M-%S)-diagnostics"

###
### Setup
###

# Cluster namespaces to gather diagnostics from. Make unique as deployment may share namespaces.
namespaces=($operator_ns $paw_ns $pass_ns $pae_ns) 
namespaces=($(printf '%s\n' "${namespaces[@]}" | sort -u ))

# Create the output folder
mkdir -p $outdir

###
### Collect general Kubernetes info
###
for ns in ${namespaces[@]}; do
    echo $ns

    # Get high level statuses
    kubectl get pods -n $ns -o wide        > $outdir/$ns--pods.txt
    kubectl get deployments -n $ns -o wide > $outdir/$ns--deployments.txt
    kubectl get statefulset -n $ns -o wide > $outdir/$ns--statefulsets.txt
    kubectl get daemonset -n $ns -o wide   > $outdir/$ns--daemonsets.txt
    kubectl get jobs -n $ns                > $outdir/$ns--jobs.txt
    kubectl get pvc -n $ns                 > $outdir/$ns--pvcs.txt

    # Get more detailed statuses
    kubectl get pods -n $ns -o yaml        > $outdir/$ns--pods.yaml
    kubectl get deployments -n $ns -o yaml > $outdir/$ns--deployments.yaml
    kubectl get statefulset -n $ns -o yaml > $outdir/$ns--statefulsets.yaml
    kubectl get daemonset -n $ns -o yaml   > $outdir/$ns--daemonsets.yaml
    kubectl get jobs -n $ns -o yaml        > $outdir/$ns--jobs.yaml
    kubectl get pvc -n $ns -o yaml         > $outdir/$ns--pvcs.yaml

    # Get resource information
    kubectl get pods -n $ns -o=jsonpath="{range .items[*]}{.metadata.name}{'\t'}{.spec.nodeName}{'\t'}{.spec.containers[*].resources.requests.cpu}{'\t'}{.spec.containers[*].resources.limits.cpu}{'\t'}{.spec.containers[*].resources.requests.memory}{'\t'}{.spec.containers[*].resources.limits.memory}{'\n'}{end}" > $outdir/$ns--podresources.csv
    kubectl top pods -n $ns > $outdir/$ns--top.csv

    # Get pod information
    pods=$(kubectl get pods -n $ns -o jsonpath='{.items[*].metadata.name}')
    for pod in ${pods[@]}; do
        echo $pod
        containers=$(kubectl get po $pod -n $ns -o jsonpath="{.spec.containers[*].name}")
        for container in ${containers[@]}; do
            echo -e "\t $container"
            kubectl logs $pod -n $ns -c $container            > $outdir/$ns--$pod--$container.log
            kubectl logs $pod -n $ns -c $container --previous > $outdir/$ns--$pod--$container--previous.log 2>/dev/null
        done
    done
done

###
### Collect Planning Analytics-specific info
###
kubectl get PlanningAnalytics -n $operator_ns -o yaml > $outdir/crs--pa.yaml
kubectl get PAWorkspace -n $paw_ns -o yaml            > $outdir/crs--paw.yaml
kubectl get PASSService -n $pass_ns -o yaml           > $outdir/crs--pass.yaml
kubectl get TM1 -n $pae_ns -o yaml                    > $outdir/crs--pae.yaml
kubectl get pods -n $pae_ns -o jsonpath='{range.items[*] }{"\n"}{.metadata.labels.version}' | sort | uniq -c > $outdir/pae--versions.txt

# Disk usage
kubectl exec -it deploy/mongo-data1 -n $paw_ns -- du -hs /data > $outdir/$paw_ns--pv--mongo-data1.txt
kubectl exec -it deploy/mongo-data2 -n $paw_ns -- du -hs /data > $outdir/$paw_ns--pv--mongo-data2.txt
kubectl exec -it deploy/mongo-data3 -n $paw_ns -- du -hs /data > $outdir/$paw_ns--pv--mongo-data3.txt
kubectl exec -it deploy/redis-data1 -n $paw_ns -- du -hs /data > $outdir/$paw_ns--pv--redis-data1.txt
kubectl exec -it deploy/redis-data2 -n $paw_ns -- du -hs /data > $outdir/$paw_ns--pv--redis-data2.txt
kubectl exec -it deploy/redis-data3 -n $paw_ns -- du -hs /data > $outdir/$paw_ns--pv--redis-data3.txt
kubectl exec -it deploy/mysql-data1 -n $paw_ns -- du -hs /var/lib/mysql > $outdir/$paw_ns--pv--mysql-data1.txt
kubectl exec -it deploy/mysql-data2 -n $paw_ns -- du -hs /var/lib/mysql > $outdir/$paw_ns--pv--mysql-data2.txt

### 
### Zip
###
tar -zcvf $outdir.tgz $outdir
