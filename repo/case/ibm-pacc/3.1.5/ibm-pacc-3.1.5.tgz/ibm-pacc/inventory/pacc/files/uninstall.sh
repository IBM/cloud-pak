#!/bin/bash

# Fail if namespace is not provided
if [ -z "$1" ]; then
  echo "❌ Error: Namespace argument is required."
  echo "Usage: $0 <namespace> "
  exit 1
fi

NAMESPACE="$1"
echo "🔄 Removing operator Deployments.."
kubectl delete deployment -n $NAMESPACE -l app.kubernetes.io/part-of=pacc-operators
echo "🔄 Removing operator Services if any.."
kubectl delete service -n $NAMESPACE -l app.kubernetes.io/part-of=pacc-operators
echo "🔄 Removing all operator ClusterRoleBindings if any.."
kubectl delete ClusterRoleBinding -l app.kubernetes.io/part-of=pacc-operators
echo "🔄 Removing operator ClusterRoles if any.."
kubectl delete ClusterRole -l app.kubernetes.io/part-of=pacc-operators
echo "🔄 Removing operator ServiceAccounts if any.."
kubectl delete ServiceAccount -n $NAMESPACE -l app.kubernetes.io/part-of=pacc-operators
echo "✅ Done."