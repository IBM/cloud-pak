#!/bin/bash

# Fail if namespace is not provided
if [ -z "$1" ]; then
  echo "❌ Error: Namespace argument is required."
  echo "Usage: $0 <namespace> [directory]"
  exit 1
fi
SCRIPT_PATH="$(readlink -f "$0")"
BASE_DIR="$(dirname "$SCRIPT_PATH")"
NAMESPACE="$1"
SECRET_EXISTS=false

echo "Verifying permissions for user: $(kubectl config current-context)"

# Namespaced resources to check — include secrets here
namespaced_resources=(serviceaccounts deployments secrets)
# Cluster-scoped resources to check — do NOT pass --namespace
cluster_resources=(clusterroles clusterrolebindings customresourcedefinitions)

for resource in "${namespaced_resources[@]}"; do
  if kubectl auth can-i create "$resource" --namespace="$NAMESPACE" &>/dev/null; then
    echo " Can create $resource in namespace '$NAMESPACE'"
  else
    echo "❌ Cannot create $resource in namespace '$NAMESPACE'"
    exit 1
  fi
done
# Check cluster-wide permissions
for resource in "${cluster_resources[@]}"; do
  if kubectl auth can-i create "$resource"  &>/dev/null; then
    echo " Can create $resource "
  else
    echo "❌ Cannot create $resource"
    exit 1
  fi
done
echo " Permission checks passed."

# === Check if OPERATOR_PULL_SECRET is set ===
if [ -n "${OPERATOR_PULL_SECRET:-}" ]; then
  SECRET_NAME="$OPERATOR_PULL_SECRET"
  # === Check if the secret exists ===
  if kubectl get secret "$SECRET_NAME" -n "$NAMESPACE" >/dev/null 2>&1; then
    SECRET_EXISTS=true
    echo "✅ Found secret '$SECRET_NAME' in namespace '$NAMESPACE'"
  else
    echo "⚠️ Secret '$SECRET_NAME' not found in namespace '$NAMESPACE', but environment OPERATOR_PULL_SECRET was defined.. Continuing without it."
  fi
else
  echo "ℹ️ Environment variable OPERATOR_PULL_SECRET is not set. Skipping pull secret check."
fi

if ! kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
  echo "🔄 Namespace '$NAMESPACE' does not exist. Creating it..."
  if ! kubectl create namespace "$NAMESPACE" 2>&1; then
    echo "❌ Failed to create namespace '$NAMESPACE'"
    exit 1
  fi
fi

# Find and apply all YAML files, excluding "kustomize.yaml"
while read -r file; do
  echo "🔄 Processing $file"

  if $SECRET_EXISTS; then
    if ! sed "s/namespace-placeholder/$NAMESPACE/g" "$file" \
      | awk -v secret="$SECRET_NAME" '
        BEGIN { inserted=0 }
        /^[[:space:]]*spec:[[:space:]]*$/ {
          print
          next
        }
        /^[[:space:]]*containers:/ && !inserted {
          print "      imagePullSecrets:"
          print "        - name: " secret
          inserted=1
        }
        { print }
      ' | kubectl apply -f - -n "$NAMESPACE"; then
      echo "❌ Failed to apply $file to namespace '$NAMESPACE'" >&2
      exit 1
    fi
  else
    if ! sed "s/namespace-placeholder/$NAMESPACE/g" "$file" \
      | kubectl apply -f - -n "$NAMESPACE"; then
      echo "❌ Failed to apply $file to namespace '$NAMESPACE'" >&2
      exit 1
    fi
  fi

done < <(find "$BASE_DIR" -type f \( -name "*.yaml" -o -name "*.yml" \) ! -name "kustomization.yaml")

echo "✅ Done."