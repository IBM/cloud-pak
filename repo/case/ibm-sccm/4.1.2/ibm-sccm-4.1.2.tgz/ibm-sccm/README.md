# Name

## IBM Sterling Control Center Monitor V6.4.1.0

# Introduction

IBM▒ Control Center Monitor is a centralized monitoring and management system. It gives operations personnel the capability to continuously monitor the status of Configuration Managers, engines, and adapters across the enterprise for the following server types from one central location: IBM Sterling Connect:Direct▒, IBM Sterling Connect:Enterprise▒, IBM Sterling B2B Integrator, IBM Sterling File Gateway, IBM Global High Availability Mailbox, IBM Sterling Connect:Express, IBM QuickFile, IBM MQ Managed File Transfer and Many FTP servers. To find out more, see the Knowledge Center for [IBM Sterling Control Center Monitor](  https://www.ibm.com/docs/en/control-center/6.4.1?topic=sterling-control-center-monitor-641 ).

# Details

This chart deploys IBM Sterling Control Center Monitor on a container management platform with the following resources deployments

- a statefulset pod `<release-name>-ibm-sccm` with 1 replica by default.
- a configMap `<release-name>-ibm-sccm`. This is used to provide default configuration in scc_config_file.
- a service `<release-name>-ibm-sccm`. This is used to expose the Control Center Monitor services for accessing using clients.
- a service-account `<release-name>-ibm-sccm-serviceaccount`. This service will not be created if `serviceAccount.create` is `false`.
- a persistence volume claim `<release-name>-ibm-sccm-pvc-ccm`.
- a persistence volume claim `<release-name>-ibm-sccm-pvc-ui`.

# Prerequisites

1. Red Hat OpenShift Container Platform 
   * Version 4.15.0 or later fixes
   * Version 4.16.0 or later fixes
   * Version 4.17.0 or later fixes
   * Version 4.18.0 or later fixes
2. Kubernetes version >= 1.30 and <=1.33 with beta APIs enabled.
3. Helm version >= 3.18.x
4. Ensure that one of the supported database server (Oracle/DB2/MSSQL) is installed and the database is accessible from inside the cluster.
5. Ensure that the docker images for IBM Sterling Control Center Monitor from IBM Entitled Registry are downloaded and pushed to an image registry accessible to the cluster.
6. Database driver files can be passed using any one of the following ways:
a. Create a persistent volume with access mode as 'ReadWriteOnce' and place the database driver jar files in the mapped volume location.
b. Create a wrapper image over existing control center image and add database driver files to that new image and give that path in configuration of control center. Sample Dockerfile content can be found at location ibm_cloud_pak/pak_extensions/pre-install/wrapper/.
c. Create an image that includes database drivers, specify that image as extra init container and use command to copy drivers to one of shared mapped location so that main container can access those drivers.

7. Keystore and trust store files can be passed using one of the following ways:
a. Create a persistent volume with access mode as 'ReadWriteOnce' and place the Key store and trust store files in the mapped volume location.
b. Key store and trust store files can be specified using kubernetes secrets using following command
```
kubectl create secret generic ibm-sccm-certs --from-file=keystore=<path to keystore file> --from-file=truststore=<path to truststore file>
```

8. Create a persistent volume for mapping configuration and logs of Control Center. Sample file can be found at location ibm_cloud_pak/pak_extensions/pre-install/volumes/
9. Create a secret with all secure credentials such as database password, keystore, truststore passwords, admin password and user key. Example can be found at ibm_cloud_pak/pak_extensions/pre-install/secret/.

10. Create a secret to pull the image from a private registry or repository using following command
```
kubectl create secret docker-registry <name of secret> --docker-server=<your-registry-server> --docker-username=<your-username> --docker-password=<your-password> --docker-email=<your-email>
```

## CASE Bundle (Prereq #1)

Please refer to [Offline deployment - For OpenShift](https://www.ibm.com/docs/en/control-center/6.4.1?topic=planning-downloading-certified-container-software-offline-cluster) section in the online Knowledge Center documentation. 
 
## Storage (Prereq #2) 

Please refer to [Creating storage for Data Persistence](https://www.ibm.com/docs/en/control-center/6.4.1?topic=p-configuring-application-storage) section in the online Knowledge Center documentation.

## Secret (Prereq #3)

Please refer to [Creating secret](https://www.ibm.com/docs/en/control-center/6.4.1?topic=p-secrets) section in the online Knowledge Center documentation.

## Tools (Prereq #4)

To install chart from the command prompt, tools needed are:

- Kubernetes version `>=1.30 && <=1.33`
- OpenShift version `>=4.15 && <=4.18`
- helm version `>=3.18.x`
- The `kubectl` and `helm` commands available
- The environment should be configured to connect to the target cluster
- Cloud Pak Cli `>=3.6.1` from [here](https://github.com/IBM/cloud-pak-cli/releases)


## PodSecurityPolicy Requirements

With Kubernetes v1.25, Pod Security Policy (PSP) API has been removed and replaced with Pod Security Admission (PSA) contoller. Kubernetes PSA conroller enforces predefined Pod Security levels at the namespace level. The Kubernetes Pod Security Standards defines three different levels: privileged, baseline, and restricted. Refer to Kubernetes [`Pod Security Standards`] (https://kubernetes.io/docs/concepts/security/pod-security-standards/) documentation for more details. This chart is compatible with the restricted security level. 

For users upgrading from older Kubernetes version to v1.29 or higher, refer to Kubernetes [`Migrate from PSP`](https://kubernetes.io/docs/tasks/configure-pod-container/migrate-from-psp/) documentation to help with migrating from PodSecurityPolicies to the built-in Pod Security Admission controller.

For users continuing on older Kubernetes versions (<1.25) and using PodSecurityPolicies, choose either a predefined PodSecurityPolicy or have your cluster administrator create a custom PodSecurityPolicy for you. This chart is compatible with most restrictive policies.
Below is an optional custom PSP definition based on the IBM restricted PSP.

* Predefined PodSecurityPolicy name: [`ibm-restricted-psp`](https://ibm.biz/cpkspec-psp)
 
- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom PodSecurityPolicy based on IBM restricted PSP.
	- Custom PodSecurityPolicy definition:

	```
	apiVersion: policy/v1beta1
	kind: PodSecurityPolicy
	metadata:
	  name: ibm-sccm-psp
	  labels:
	    app: "ibm-sccm-psp"
	spec:
	  privileged: false
	  allowPrivilegeEscalation: false
	  hostPID: false
	  hostIPC: false
	  hostNetwork: false
	  allowedCapabilities:
	  requiredDropCapabilities:
	  - ALL
	  allowedHostPaths:
	  runAsUser:
	    rule: MustRunAsNonRoot
	  runAsGroup:
	    rule: MustRunAs
	    ranges:
	    - min: 1
              max: 4294967294
	  seLinux:
	    rule: RunAsAny
	  supplementalGroups:
	    rule: MustRunAs
	    ranges:
	    - min: 1
	      max: 4294967294
	  fsGroup:
	    rule: MustRunAs
	    ranges:
	    - min: 1
	      max: 4294967294
	  volumes:
	  - configMap
	  - emptyDir
	  - projected
	  - secret
	  - downwardAPI
	  - persistentVolumeClaim
	  - nfs
	  forbiddenSysctls:
	  - "*"
	```

	- Custom ClusterRole for the custom PodSecurityPolicy:

	```
	apiVersion: rbac.authorization.k8s.io/v1
	kind: ClusterRole
	metadata:
	  name: "ibm-sccm-psp"
	  labels:
	    app: "ibm-sccm-psp"
	rules:
	- apiGroups:
	  - policy
	  resourceNames:
	  - ibm-sccm-psp
	  resources:
	  - podsecuritypolicies
	  verbs:
	  - use
	```
	
	- Custom Role binding for the custom PodSecurityPolicy:
	
	```
	apiVersion: rbac.authorization.k8s.io/v1beta1
	kind: RoleBinding
	metadata:
	  name: "ibm-sccm-psp"
	  labels:
	    app: "ibm-sccm-psp"
	roleRef:
	  apiGroup: rbac.authorization.k8s.io
	  kind: ClusterRole
	  name: "ibm-sccm-psp"
	subjects:
	- apiGroup: rbac.authorization.k8s.io
	  kind: Group
	  name: system:serviceaccounts
	  namespace: {{ NAMESPACE }}
	```


- From the command line, you can run the setup scripts included under pak_extensions (untar the downloaded archive to extract the pak_extensions directory)

  As a cluster admin the pre-install script is located at:
  - pre-install/clusterAdministration/createSecurityClusterPrereqs.sh

  As team admin the namespace scoped pre-install script is located at:
  - pre-install/namespaceAdministration/createSecurityNamespacePrereqs.sh


## SecurityContextConstraints Requirements

Red Hat OpenShift provides a pre-defined or default set of SecurityContextConstraints (SCC). These SCCs are used to control permissions for pods. These permissions include actions that a pod can perform and what resources it can access. You can use SCCs to define a set of conditions that a pod must run with to be accepted into the system. Refer to OpenShift [`Managing Security Context Constraints`](https://docs.openshift.com/container-platform/4.14/authentication/managing-security-context-constraints.html#default-sccs_configuring-internal-oauth) documentation for more details on the default SCCs. This chart is compatible with **nonroot-v2** (added in OpenShift v4.11) default SCCs and does not require a custom SCC to be defined explicity.

For OpenShift, choose either a predefined SCC or have your cluster administrator create a custom SCC for you as per the security profile and policies adopted for all OpenShift deployments. This chart is compatible with most restrictive security context constraints.
Below is an optional custom SCC definition based on the IBM restricted SCC.

* Predefined SecurityContextConstraints name: [`ibm-restricted-scc`](https://ibm.biz/cpkspec-scc)

- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom SCC based on IBM restricted SCC.

	- Custom SecurityContextConstraints definition:

	```
	apiVersion: security.openshift.io/v1
	kind: SecurityContextConstraints
	metadata:
	  name: ibm-sccm-scc 
	  labels:
	    app: "ibm-sccm-scc"
		app.kubernetes.io/instance: "ibm-sccm"
		app.kubernetes.io/managed-by: "ibm-sccm"
		app.kubernetes.io/name: "ibm-sccm"
	allowHostDirVolumePlugin: false
	allowHostIPC: false
	allowHostNetwork: false
	allowHostPID: false
	allowHostPorts: false
	allowPrivilegeEscalation: false
	allowPrivilegedContainer: false
	allowedCapabilities:
	defaultAddCapabilities: null
	fsGroup:
	  type: MustRunAs
	  ranges:
	  - min: 1
	    max: 4294967294
	priority: 0
	readOnlyRootFilesystem: false
	requiredDropCapabilities:
	- ALL
	runAsUser:
	  type: MustRunAsRange
	  uidRangeMin: 1
	  uidRangeMax: 4294967294
	seLinuxContext:
	  type: MustRunAs
	seccompProfiles:
	- runtime/default
	supplementalGroups:
          type: MustRunAs
          ranges:
          - min: 1
            max: 4294967294
	users: []
	volumes:
	- configMap
	- downwardAPI
	- emptyDir
	- persistentVolumeClaim
	- projected
	- secret
	- nfs
	```

	- Custom ClusterRole for the custom SecurityContextConstraints:

	```
	apiVersion: rbac.authorization.k8s.io/v1
	kind: ClusterRole
	metadata:
	  name: "ibm-sccm-scc"
	  labels:
		app: "ibm-sccm-scc"
	rules:
	- apiGroups:
	  - security.openshift.io
	  resourceNames:
	  - ibm-sccm-scc
	  resources:
	  - securitycontextconstraints
	  verbs:
	  - use
	```

	- Custom Role binding for the custom SecurityContextConstraints:

	```	
	apiVersion: rbac.authorization.k8s.io/v1
	kind: ClusterRoleBinding
	metadata:
	  name: "ibm-sccm-scc"
	  labels:
		app: "ibm-sccm-scc"
	roleRef:
	  apiGroup: rbac.authorization.k8s.io
	  kind: ClusterRole
	  name: "ibm-sccm-scc"
	subjects:
	- apiGroup: rbac.authorization.k8s.io
	  kind: Group
	  name: system:serviceaccounts
	  namespace: {{ NAMESPACE }}
	```

- From the command line, you can run the setup scripts included under pak_extensions (untar the downloaded archive to extract the pak_extensions directory)

  As a cluster admin the pre-install script is located at:
  - pre-install/clusterAdministration/createSecurityClusterPrereqs.sh

  As team admin the namespace scoped pre-install script is located at:
  - pre-install/namespaceAdministration/createSecurityNamespacePrereqs.sh
 
  As team admin the namespace scoped pre-install script for adding **nonroot-v2** is located at:
  - pre-install/namespaceAdministration/addNonrootSCCNamespacePrereqs.sh
  
# Configuration

- [Chart Readme](./inventory/ibmSccm/README.md)
  
# Installing

## Install Prequisites

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Setup](./inventory/ibmSccm/README.md)

## Install CASE inventory items

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmSccm/README.md)

## Uninstalling the CASE

See the following readme files for details of removing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmSccm/README.md)

# Resources Required

This chart uses the following resources by default:

* 8Gi of persistent volume
* 20 GB Disk space
* 3000m CPU
* 8Gi Memory
* 1 master node and at least 1 worker node

# Storage

IBM Sterling Control Center Helm chart supports both dynamic and pre-created persistent storage. 

* Either use storage class for dynamic provisioning or pre-create Persistent Volume
* To retain the data stored on Persistent Volume, the storage class should have reclaim policy as `Retain`
* The default access mode is set to `ReadWriteOnce`

# Limitations

- High availability and scalability are supported in traditional way of Control Center deployment using Kubernetes load balancer service.
- IBM Control Center Monitor chart supports only amd64,ppc64le architecture.
- In a containerized environment, the following certificate management features are not supported:
* Keystore certificate management
* Truststore certificate management
* Certificate management using Venafi
- SSP reports will not run in container enironment

# Documentation

[IBM Sterling Control Center](https://www.ibm.com/docs/en/control-center/6.4.1?topic=sterling-control-center-monitor-641)
