# Name

## IBM Sterling Control Center Monitor V6.4.3.0

# Introduction

IBM▒ Control Center Monitor is a centralized monitoring and management system. It gives operations personnel the capability to continuously monitor the status of Configuration Managers, engines, and adapters across the enterprise for the following server types from one central location: IBM Sterling Connect:Direct▒, IBM Sterling Connect:Enterprise▒, IBM Sterling B2B Integrator, IBM Sterling File Gateway, IBM Global High Availability Mailbox, IBM Sterling Connect:Express, IBM QuickFile, IBM MQ Managed File Transfer and Many FTP servers. To find out more, see the Knowledge Center for [IBM Sterling Control Center Monitor](  https://www.ibm.com/docs/en/control-center/6.4.3?topic=sterling-control-center-monitor-643 ).

# Details

This chart deploys IBM Sterling Control Center Monitor on a container management platform with the following resources deployments

- a statefulset pod `<release-name>-ibm-sccm` with 1 replica by default.
- a configMap `<release-name>-ibm-sccm`. This is used to provide default configuration in scc_config_file.
- a service `<release-name>-ibm-sccm`. This is used to expose the Control Center Monitor services for accessing using clients.
- a service-account `<release-name>-ibm-sccm-serviceaccount`. This service will not be created if `serviceAccount.create` is `false`.
- a persistence volume claim `<release-name>-ibm-sccm-pvc-ccm`.
- a persistence volume claim `<release-name>-ibm-sccm-pvc-ui`.

# Prerequisites

1. Red Hat OpenShift Container Platform 
   * Version 4.19.0 or later fixes
   * Version 4.20.0 or later fixes
   * Version 4.21.0 or later fixes
   * Version 4.22.0 or later fixes
2. Kubernetes version >= 1.32 and <=1.36 with beta APIs enabled.
3. Helm version >= 3.18.x and <= 4.3.0
4. Ensure that one of the supported database server (Oracle/DB2/MSSQL) is installed and the database is accessible from inside the cluster.
5. Ensure that the docker images for IBM Sterling Control Center Monitor from IBM Entitled Registry are downloaded and pushed to an image registry accessible to the cluster.
6. Database driver files can be passed using any one of the following ways:
a. Create a persistent volume with access mode as 'ReadWriteOnce' and place the database driver jar files in the mapped volume location.
b. Create a wrapper image over existing control center image and add database driver files to that new image and give that path in configuration of control center. Sample Dockerfile content can be found at location ibm_cloud_pak/pak_extensions/pre-install/wrapper/.
c. Create an image that includes database drivers, specify that image as extra init container and use command to copy drivers to one of shared mapped location so that main container can access those drivers.

7. Keystore and trust store files can be passed using one of the following ways:
a. Create a persistent volume with access mode as 'ReadWriteOnce' and place the Key store and trust store files in the mapped volume location.
b. Key store and trust store files can be specified using kubernetes secrets using following command
```
kubectl create secret generic ibm-sccm-certs --from-file=keystore=<path to keystore file> --from-file=truststore=<path to truststore file>
```

8. Create a persistent volume for mapping configuration and logs of Control Center. Sample file can be found at location ibm_cloud_pak/pak_extensions/pre-install/volumes/
9. Create a secret with all secure credentials such as database password, keystore, truststore passwords, admin password and user key. Example can be found at ibm_cloud_pak/pak_extensions/pre-install/secret/.

10. Create a secret to pull the image from a private registry or repository using following command
```
kubectl create secret docker-registry <name of secret> --docker-server=<your-registry-server> --docker-username=<your-username> --docker-password=<your-password> --docker-email=<your-email>
```

Configure this pull secret in the service account used for deployment using this command

```
kubectl patch serviceaccount <service-account-name> -p '{"imagePullSecrets": [{"name": "<pull-secret-name>"}]}'
```

> **Note:** It is recommended to configure the pull secret in the service account as it automatically binds as a pull secret for all application pods. If the pull secret is added to the service account then the <b>image.imageSecrets</b> configurations in the helm configuration file are not required.

## CASE Bundle (Prereq #1)

Please refer to [Offline deployment - For OpenShift](https://www.ibm.com/docs/en/control-center/6.4.3?topic=planning-downloading-certified-container-software-offline-cluster) section in the online Knowledge Center documentation. 
 
## Storage (Prereq #2) 

Please refer to [Creating storage for Data Persistence](https://www.ibm.com/docs/en/control-center/6.4.3?topic=p-configuring-application-storage) section in the online Knowledge Center documentation.

## Secret (Prereq #3)

Please refer to [Creating secret](https://www.ibm.com/docs/en/control-center/6.4.3?topic=p-secrets) section in the online Knowledge Center documentation.

## Tools (Prereq #4)

To install chart from the command prompt, tools needed are:

- Kubernetes version `>=1.32 && <=1.36`
- OpenShift version `>=4.19 && <=4.22`
- helm version `>=3.18.x` && <= 4.3.0
- The `kubectl` and `helm` commands available
- The environment should be configured to connect to the target cluster
- Cloud Pak Cli `>=3.6.1` from [here](https://github.com/IBM/cloud-pak-cli/releases)


## Pod Security Admission (PSA) Requirements

Pod Security Admission (PSA) is a built-in Kubernetes admission controller that enforces security standards on Pods during creation and updates. It helps prevent insecure pod configurations from running in a Kubernetes cluster.

PSA replaces the deprecated PodSecurityPolicy (PSP) mechanism and enforces predefined Pod Security Standards (PSS) across namespaces.

IBM Sterling Control Center supports all three Pod Security Standards.

PSA is configured at the namespace level using labels. Whenever a Pod is created or updated, Kubernetes validates its specification against the security policy defined for the target namespace.

PSA supports three enforcement modes:

- <b>enforce</b>: Blocks Pods that violate the configured security policy.
- <b>audit</b>: Allows the Pod but records policy violations in the audit logs.
- <b>warn</b>: Allows the Pod but displays warning messages to the user about policy violations.

### Pod Security Standards

Kubernetes defines the following security levels:

1. <b>Privileged</b>
	<p>The least restrictive security profile.</p>

	- Allows nearly all Pod capabilities.
	- Suitable for infrastructure and system-level workloads.
	- Commonly used for CNI plugins, storage drivers, monitoring agents, and other privileged components.

2. <b>Baseline</b>
	<p>Provides protection against common privilege escalation risks while maintaining compatibility with most applications.</p>

	- Disallows privileged containers.
	- Prevents use of host networking.
	- Prevents access to the host PID namespace.
	- Restricts Linux capabilities.

3. <b>Restricted</b>
	<p>Provides the highest level of security and is recommended for most application workloads.</p>

	- Requires containers to run as non-root users.
	- Disallows privileged containers.
	- Minimizes Linux capabilities.
	- Restricts allowed volume types.
	- Requires a Seccomp profile.

Applying PSA to a Namespace
PSA policies can be applied to a namespace using either the command line or a Kubernetes manifest.

<b>Using the Command Line</b>
``` 
kubectl label --overwrite ns <my-project-namespace> \
  pod-security.kubernetes.io/enforce=<Pod-Security-Standard> 
```

Example
``` 
kubectl label --overwrite ns my-project-namespace \
  pod-security.kubernetes.io/enforce=baseline 
```

<b>Using a Kubernetes Manifest</b>

Create a file named apply-psa.yaml with the following content:

```
apiVersion: v1
kind: Namespace
metadata:
  name: my-project-namespace
  labels:
    # Enforce the baseline policy
    pod-security.kubernetes.io/enforce: baseline
    pod-security.kubernetes.io/enforce-version: latest

    # Generate warnings for workloads that do not meet the restricted policy
    pod-security.kubernetes.io/warn: restricted
    pod-security.kubernetes.io/warn-version: latest

    # Record audit events for workloads that do not meet the restricted policy
    pod-security.kubernetes.io/audit: restricted
    pod-security.kubernetes.io/audit-version: latest

```

Apply the manifest using:
```
kubectl apply -f apply-psa.yaml
```

<p>For a complete description of Pod Security Standards and supported controls, refer to the official Kubernetes documentation:

- [Pod Security Standards](https://kubernetes.io/docs/concepts/security/pod-security-standards/)
- [Pod Security Admission](https://kubernetes.io/docs/concepts/security/pod-security-admission/)

These documents provide detailed guidance on policy requirements, enforcement behavior, and best practices for securing Kubernetes workloads.</p>



## SecurityContextConstraints Requirements

Red Hat OpenShift provides a pre-defined or default set of SecurityContextConstraints (SCC). These SCCs are used to control permissions for pods. These permissions include actions that a pod can perform and what resources it can access. You can use SCCs to define a set of conditions that a pod must run with to be accepted into the system. Refer to OpenShift [`Managing Security Context Constraints`](https://docs.openshift.com/container-platform/4.14/authentication/managing-security-context-constraints.html#default-sccs_configuring-internal-oauth) documentation for more details on the default SCCs. This chart is compatible with **nonroot-v2** (added in OpenShift v4.11) default SCCs and does not require a custom SCC to be defined explicity.

For OpenShift, choose either a predefined SCC or have your cluster administrator create a custom SCC for you as per the security profile and policies adopted for all OpenShift deployments. This chart is compatible with most restrictive security context constraints.
Below is an optional custom SCC definition based on the IBM restricted SCC.

* Predefined SecurityContextConstraints name: [`ibm-restricted-scc`](https://ibm.biz/cpkspec-scc)

- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom SCC based on IBM restricted SCC.

	- Custom SecurityContextConstraints definition:

	```
	apiVersion: security.openshift.io/v1
	kind: SecurityContextConstraints
	metadata:
	  name: ibm-sccm-scc 
	  labels:
	    app: "ibm-sccm-scc"
		app.kubernetes.io/instance: "ibm-sccm"
		app.kubernetes.io/managed-by: "ibm-sccm"
		app.kubernetes.io/name: "ibm-sccm"
	allowHostDirVolumePlugin: false
	allowHostIPC: false
	allowHostNetwork: false
	allowHostPID: false
	allowHostPorts: false
	allowPrivilegeEscalation: false
	allowPrivilegedContainer: false
	allowedCapabilities:
	defaultAddCapabilities: null
	fsGroup:
	  type: MustRunAs
	  ranges:
	  - min: 1
	    max: 4294967294
	priority: 0
	readOnlyRootFilesystem: false
	requiredDropCapabilities:
	- ALL
	runAsUser:
	  type: MustRunAsRange
	  uidRangeMin: 1
	  uidRangeMax: 4294967294
	seLinuxContext:
	  type: MustRunAs
	seccompProfiles:
	- runtime/default
	supplementalGroups:
          type: MustRunAs
          ranges:
          - min: 1
            max: 4294967294
	users: []
	volumes:
	- configMap
	- downwardAPI
	- emptyDir
	- persistentVolumeClaim
	- projected
	- secret
	- nfs
	```

	- Custom ClusterRole for the custom SecurityContextConstraints:

	```
	apiVersion: rbac.authorization.k8s.io/v1
	kind: ClusterRole
	metadata:
	  name: "ibm-sccm-scc"
	  labels:
		app: "ibm-sccm-scc"
	rules:
	- apiGroups:
	  - security.openshift.io
	  resourceNames:
	  - ibm-sccm-scc
	  resources:
	  - securitycontextconstraints
	  verbs:
	  - use
	```

	- Custom Role binding for the custom SecurityContextConstraints:

	```	
	apiVersion: rbac.authorization.k8s.io/v1
	kind: ClusterRoleBinding
	metadata:
	  name: "ibm-sccm-scc"
	  labels:
		app: "ibm-sccm-scc"
	roleRef:
	  apiGroup: rbac.authorization.k8s.io
	  kind: ClusterRole
	  name: "ibm-sccm-scc"
	subjects:
	- apiGroup: rbac.authorization.k8s.io
	  kind: Group
	  name: system:serviceaccounts
	  namespace: {{ NAMESPACE }}
	```

- From the command line, you can run the setup scripts included under pak_extensions (untar the downloaded archive to extract the pak_extensions directory)

  As a cluster admin the pre-install script is located at:
  - pre-install/clusterAdministration/createSecurityClusterPrereqs.sh

  As team admin the namespace scoped pre-install script is located at:
  - pre-install/namespaceAdministration/createSecurityNamespacePrereqs.sh
 
  As team admin the namespace scoped pre-install script for adding **nonroot-v2** is located at:
  - pre-install/namespaceAdministration/addNonrootSCCNamespacePrereqs.sh
  
# Configuration

- [Chart Readme](./inventory/ibmSccm/README.md)
  
# Installing

## Install Prequisites

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Setup](./inventory/ibmSccm/README.md)

## Install CASE inventory items

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmSccm/README.md)

## Uninstalling the CASE

See the following readme files for details of removing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmSccm/README.md)

# Resources Required

This chart uses the following resources by default:

* 8Gi of persistent volume
* 20 GB Disk space
* 3000m CPU
* 8Gi Memory
* 1 master node and at least 1 worker node

# Storage

IBM Sterling Control Center Helm chart supports both dynamic and pre-created persistent storage. 

* Either use storage class for dynamic provisioning or pre-create Persistent Volume
* To retain the data stored on Persistent Volume, the storage class should have reclaim policy as `Retain`
* The default access mode is set to `ReadWriteOnce`

# Limitations

- High availability and scalability are supported in traditional way of Control Center deployment using Kubernetes load balancer service.
- IBM Control Center Monitor chart supports only amd64,ppc64le,s390x architecture.
- SSP reports will not run in container enironment

# Documentation

[IBM Sterling Control Center](https://www.ibm.com/docs/en/control-center/6.4.3?topic=sterling-control-center-monitor-643)
