# Readme

README document for Helm Chart for IBM&reg; Sterling Transformation Extender for Launcher Container 11.0.3
<br>&copy; Copyright IBM Corporation 2025, 2026 All rights reserved.
<br>Program Number : 5724-Q23 

## Introduction

IBM&reg; Sterling Transformation Extender (ITX) provides a unified solution for data transformation and integration. It enables complex validation, transformation and integration across a wide range of data sources and data formats. The transformation functionality is packaged into modular objects called maps. The maps are included in systems, which are deployed and then triggered by time, file or source input events.

IBM&reg; Sterling Transformation Extender Launcher Container, also referred to as ITX Launcher Server (ITX LS), is a containerized distribution of ITX. It enables maps and systems to be executed within a cluster of worker nodes on the cloud. Maps are designed using ITX Design Studio and systems are defined with ITX Integration Flow Designer. Both ITX Design Studio and Integration Flow Designer are components that are separate from ITX LS. They must be installed and run locally on a Windows host. When you obtain access to the ITX LS component, you will be provided with instructions on how to obtain the ITX Design Studio and Integration Flow Designer components as well.

For additional high-level overview of the ITX Launcher Container product, refer to this [support page](https://www.ibm.com/support/pages/node/7274355).

## Prerequisites

ITX LS supports Red Hat OpenShift cluster version 4.20. It runs on Linux 64 clusters only. When compiling maps in ITX Design Studio, you must choose the option to compile them for Linux 64 platform. Alternatively, you can use multi-platform composite maps, at the cost of increased map size. 

### PodDisruptionBudgets

The ITX LS deployment does not specify a pod disruption budget. Each consumer of this transformation logic should consider how disruption might impact any specific process.

### SecurityContextConstraints Requirement

The Helm chart of this deployment requires a specific type of `SecurityContextConstraints` to be defined and bound to the user or service account of the installation. The predefined `SecurityContextConstraints`, [`nonroot-v2`](https://docs.openshift.com/container-platform/4.20/authentication/managing-security-context-constraints.html), has been verified for this chart.  If your user or service account is bound to this `SecurityContextConstraints` resource, you can proceed to install the chart.

Below is a `SecurityContextConstraints` (SCC) which can be used for finer control of the permissions and capabilities needed to install this chart. It is modeled after the predefined `nonroot-v2` SCC but with the added restriction of only permitting user and group ID, 1001, which is required by ITX Launcher Container.

Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy allows a single, non-root user"
  name: ibm-itx-ls-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: false
allowedCapabilities: 
- NET_BIND_SERVICE
allowedFlexVolumes: null
allowedUnsafeSysctls: null
defaultAddCapabilities: null
defaultAllowPrivilegeEscalation: false
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
seccompProfiles:
- runtime/default
runAsUser:
  type: MustRunAsRange
  uidRangeMin: 1001
  uidRangeMax: 1001
fsGroup:
  type: MustRunAs
  ranges:
  - max: 1001
    min: 1001
supplementalGroups:
  type: RunAsAny
seLinuxContext:
  type: MustRunAs
volumes:
- configMap
- csi
- downwardAPI
- emptyDir
- ephemeral
- nfs
- persistentVolumeClaim
- projected
- secret
priority: 0
```
From the command line, save the YAML object to a file and run the following command.

``` { .shell }
oc apply -f <file_name>

---
