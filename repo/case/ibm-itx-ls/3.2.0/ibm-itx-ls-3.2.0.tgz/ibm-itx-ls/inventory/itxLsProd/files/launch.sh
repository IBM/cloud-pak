#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2025  All Rights Reserved.
#
# This script is a utility to install a product bundled in CASE in online and air gap environment
# This script can be invoked using cloudctl tool (github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli)
# This script serves as an interface which defines install actions, functions and their inputs

# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(dirname "$0")"

# Script invocation defaults for parms populated via cloudctl
action="install"
caseJsonFile=""
casePath=$(realpath "${scriptDir}/../../..")
chartsPath=$(realpath "${casePath}/../../charts/")
instance=""

# - optional parameter / argument defaults
dryRun=""
deleteCRDs=0
namespace=""
src_registry=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
helmOpts=""
licenseAccept=""
tag_catalog=0
mirror_image_chunks=""
recursive_action=0
tolerance_val=0

# docker registry variables
registry_clean=
registry_dir=
registry_engine=
registry_image=
registry_subject=
registry_port=

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="
  --tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}

OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}

 ARGS per Action:
    configure-creds-airgap
      --registry               : source/target container image registry (required)
      --user                   : login user name for the container image registry (required)
      --pass                   : login password for the container image registry (required)

    configure-cluster-airgap
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory
      --registry               : target container image registry (required)

    mirror-images
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)
      --fromRegistry           : override the source image registry in the CASE
      --registry               : target container image registry (required)
      --chunks                 : mirror the images in batches with a given size. Default is 100

    install
      --registry               : source/target container image registry
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --secret                 : name of existing image pull secret for the container image registry

    install-catalog:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)

    install-operator:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --channelName            : name of channel for subscription (packagemanifest default used if not specified)
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)

    install-operator-native:
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if pass specified)
      --pass                   : login password for the container image registry (required if user specified)
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)

    uninstall                  : uninstall the product

    TODOlww apply-custom-resources     : creates the sample custom resource

    TODOlww delete-custom-resources    : deletes the same custom resource

    init-registry              : configure a local docker registry with self-sign certificate
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --subject                : self-sign TLS certificate subject
      --registry               : IP or FQDN for the docker registry ( default: $(hostname -f))
      --clean                  : clean up all existing repositories data


    start-registry             : start a local docker registry container
      --port                   : registry service port (default: 5000 )
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --engine                 : container engine to run the container (docker or podman)
      --image                  : docker registry image (default: docker.io/library/registry:2.6)

    stop-registry              : stop a local docker registry container
      --engine                 : container engine to run the container (docker or podman)
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ----- Actions -----
# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    configureCredsAirgap)
        configure_creds_airgap
        ;;
    configureClusterAirgap)
        configure_cluster_airgap
        ;;
    install)
        install
        ;;
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    installOperatorNative)
        install_operator_native
        ;;
    mirrorImages)
        mirror_images
        ;;
    uninstall)
        uninstall
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    uninstallOperatorNative)
        uninstall_operator_native
        ;;
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    initRegistry)
        init_registry
        ;;
    startRegistry)
        start_registry
        ;;
    stopRegistry)
        stop_registry
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"

    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --deleteCRDs)
            deleteCRDs=1
            ;;
        --channelName)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            channelName="${v}"
            ;;
        --fromRegistry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            src_registry="${v}"
            ;;
        --registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry="${v}"
            ;;
        --chunks)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            mirror_image_chunks="${v}"
            ;;
        --inputDir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            inputcasedir="${v}"
            ;;
        --user)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            user="${v}"
            ;;
        --pass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pass="${v}"
            ;;
        --secret)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            secret="${v}"
            ;;
        --recursive)
            recursive_action=1
            ;;
        # flags related to starting/stopping local docker registry
        --subject)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_subject="${v}"
            ;;
        --dir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_dir="${v}"
            ;;
        --engine)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_engine="${v}"
            ;;
        --port)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_port="${v}"
            ;;
        --clean)
            registry_clean=1
            ;;
        --help)
            print_usage 0
            ;;
        *)
            # pass arr[i], arr[i+1] to the override function
            parse_custom_dynamic_args "${arr[${idx}]}" "${arr[$((idx + 1))]}"
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    # skip this check for certain actions
    skip_actions="mirrorImages configureCredsAirgap initRegistry startRegistry stopRegistry"
    if [[ "$skip_actions" != *$action* ]]; then
        check_kube_connection
        check_kube_namespace
    fi
}

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exit "No oc or kubectl found in path"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

check_kube_namespace() {
    [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
    if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
        err_exit "Unable to retrieve namespace specified ${namespace}"
    fi
}

check_secret_params() {

    local foundError=0

    [[ -z ${secret} ]] && {
        foundError=1
        err "'--secret' is required for creating a registry secret"
    }
    [[ -z ${registry} ]] && {
        foundError=1
        err "'--registry' is required for creating a registry secret"
    }
    [[ -z ${user} ]] && {
        foundError=1
        err "'--user' is required for creating a registry secret"
    }
    [[ -z ${pass} ]] && {
        foundError=1
        err "'--pass' is required for creating a registry secret"
    }

    # Print usage if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

# Validates that the required args were specified for install action
validate_install_args() {
    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    # Verify arguments required per install method were provided
    echo "Checking install arguments for ${mode:-install}"

    if [[ ${recursive_action} -eq 1 && -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
        print_usage 1
    fi

    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" && -n "${user}" && -n "${pass}" ]]; then
        check_secret_params
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    fi
}

validate_install_catalog() {

    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    echo "Checking arguments for ${mode:-install} catalog action"

    if [[ ${recursive_action} -eq 1 && -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
        print_usage 1
    fi
}

# Validates that the required args were specified for secret creation
validate_configure_creds_airgap_args() {
    # Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }
    [[ -z "${user}" ]] && {
        foundError=1
        err "'--user' must be specified with the '--args' parameter"
    }
    [[ -z "${pass}" ]] && {
        foundError=1
        err "'--pass' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_configure_cluster_airgap_args() {
    # Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    [[ -z "${inputcasedir}" ]] && {
        foundError=1
        err "'--inputDir' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** UTILS *****

# Print version
print_version() {
    echo "[INFO] Version ${version}"
    exit 0
}

get_case_name(){

    validate_file_exists $casePath/case.yaml

    caseName="$(grep '^name: ' $casePath/case.yaml)" #get name from case.yaml
    caseName=$(echo $caseName | awk -F':' '{print $2}') #get everything after ':', ex. `name: ibm-sample-panamax` becomes `ibm-sample-panamax`
    caseName="$(echo -e "${caseName}" | tr -d '[:space:]')"#trim ALL whitespaces
}

# Error reporting functions
err() {
    echo >&2 "[ERROR] $1"
}
err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

# ----- REGISTRY ACTIONS -----

init_registry() {
    "${scriptDir}"/airgap.sh registry service init \
        ${user:+'--username' "$user"} \
        ${pass:+'--password' "$pass"} \
        ${registry_dir:+'--dir' "$registry_dir"} \
        ${registry_subject:+'--subject' "$registry_subject"} \
        ${registry:+'--registry' "$registry"} \
        ${registry_clean:+'--clean'}
}

start_registry() {
    "${scriptDir}"/airgap.sh registry service start \
        ${registry_dir:+'--dir' "$registry_dir"} \
        ${registry_engine:+'--engine' "$registry_engine"} \
        ${registry_port:+'--port' "$registry_port"} \
        ${registry_image:+'--image' "$registry_image"}
}

stop_registry() {
    "${scriptDir}"/airgap.sh registry service stop \
        ${registry_engine:+'--engine' "$registry_engine"}
}

# ----- CONFIGURE ACTIONS -----

# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)
configure_creds_airgap() {
    echo "-------------Configuring authentication secret-------------"

    validate_configure_creds_airgap_args

    # Create registry secret for user information provided

    "${scriptDir}"/airgap.sh registry secret -c -u "${user}" -p "${pass}" "${registry}"
}

# Append secret to Global Cluster Pull Secret (pull-secret in openshif-config)
configure_cluster_pull_secret() {

    echo "-------------Configuring cluster pullsecret-------------"

    # configure global pull secret if an authentication secret exists on disk
    if "${scriptDir}"/airgap.sh registry secret -l | grep "${registry}"; then
        "${scriptDir}"/airgap.sh cluster update-pull-secret --registry "${registry}" "${dryRun}"
    else
        echo "Skipping configuring cluster pullsecret: No authentication exists for ${registry}"
    fi
}

configure_content_image_source_policy() {

    echo "-------------Configuring imagecontentsourcepolicy-------------"

    get_case_name

    echo "name is ${caseName}"
    echo "dir is ${inputcasedir}"

    "${scriptDir}"/airgap.sh cluster apply-image-policy \
        --name "${caseName}" \
        --dir "${inputcasedir}" \
        --registry "${registry}" "${dryRun}"
}

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap() {

    echo "-------------Configuring cluster for airgap-------------"

    validate_configure_cluster_airgap_args

    configure_cluster_pull_secret

    configure_content_image_source_policy
}

# Mirror required images
mirror_images() {
    echo "-------------Mirroring images-------------"

    validate_configure_cluster_airgap_args

    # mirror all images in this case
    # skip copying other images, when --tagCatalog is passed
    if [[ $tag_catalog -eq 0 ]]; then
        "${scriptDir}"/airgap.sh image mirror \
            --dir "${inputcasedir}" \
            ${src_registry:+'--from-registry' "$src_registry"} \
            --to-registry "${registry}" \
            ${mirror_image_chunks:+'--split-size' "$mirror_image_chunks"} \
            "${dryRun}"
    fi
}

# ----- ABSTRACT FUNCTIONS -----
# the below functions can be overridden in launch implementation script

# 17-Oct-2022 lww  using "set" as an argument for Helm
parse_custom_dynamic_args() {
    case $1 in
        *set)
            helmOpts+=" --set  $2"
            idx=$((idx + 1))
            ;;
        *string)
            helmOpts+=" --set-string  $2"
            idx=$((idx + 1))
            ;;
        *f|*values)
            helmOpts+=" --values  $2"
            idx=$((idx + 1))
            ;;
        *accept)
            licenseAccept=$2
            helmOpts+=" --set license.accept=$2"
            idx=$((idx + 1))
            ;;
        *)
            err_exit "$0 found an invalid option in --args: ${1} ${2}"
    esac
}

# ----- INSTALL ACTIONS -----

# products can choose to implement the install/uninstall mechanism they support in launch_impl.sh

install() {
    #echo "helm install

    if [ -z "${licenseAccept}" ]; then
        cat "${casePath}/licenses/LICENSE"
        echo -e "\nYou must review and acccept the license terms for this product before installing.\n\nIf you agree with the terms, reissue this command including an argument like:\n\t\t-accept true\n"
        err_exit "Please accept the terms."
    fi

    helm status  ibm-itx-ls  2>/dev/null
    if [ $? = 0 ]; then
        echo -e "\nThe product, \"ibm-itx-ls,\" is currently installed in \"${namespace}.\"  Please uninstall it before trying to install this version.\n"
    else
        echo helm install ibm-itx-ls "${chartsPath}/ibm-itx-ls-prod" ${helmOpts}
        helm install ibm-itx-ls "${chartsPath}/ibm-itx-ls-prod" ${helmOpts}
    fi
}

install_dependent_catalogs() {
    echo "No dependencies."
}

install_operator_group() {

    echo "Check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "Found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "No existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "Done"
}

# Installs the catalog source
install_catalog() {

    validate_install_catalog

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verify expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # If local registry is not specified, apply the original catalog source definition, 
    # otherwise replace the original registry with local registry and apply the modified 
    # catalog source
    if [[ "${registry}" == "" ]]; then
      $kubernetesCLI apply ${dryRun} -f "${catsrc_file}"
    else
      local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
      local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
      sed "${catsrc_file}" -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "Done"
}

install_operator() {
    # Verify arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "Expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed "${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

install_operator_native() {
    # Verify arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing native-------------"

    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local crd_file="${op_cli_files}/itx.ibm.com_itxlauncherservers_crd.yaml"
    local sa_file="${op_cli_files}/service_account.yaml"
    local role_file="${op_cli_files}/role.yaml"
    local role_binding_file="${op_cli_files}/role_binding.yaml"
    local operator_file="${op_cli_files}/operator.yaml"

    validate_file_exists "${sa_file}"
    validate_file_exists "${role_file}"
    validate_file_exists "${role_binding_file}"
    validate_file_exists "${operator_file}"

    # Create ServiceAccount
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${sa_file}"
    # Create CustomResourceDefinition
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${crd_file}"
    # Create Role
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${role_file}"
    # Create RoleBinding
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${role_binding_file}"
    # Create Deployment (for operator controller)
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${operator_file}"
}

apply_custom_resources() {
    echo "Action not supported"
}

# ----- UNINSTALL ACTIONS -----

uninstall() {
    helm status  ibm-itx-ls  >/dev/null 2>&1
    if [ $? ]; then
        echo -e "\nThe product, \"ibm-itx-ls,\" is currently installed in \"${namespace}.\""
        helm uninstall ibm-itx-ls 
    fi
}


uninstall_dependent_catalogs() {
    echo "Action not supported"
}

# Deletes the catalog source
uninstall_catalog() {

    validate_install_catalog "uninstall"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # delete CRD
    [[ -f "${casePath}/inventory/${inventory}/files/op-cli/itx.ibm.com_itxlauncherservers_crd.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/itx.ibm.com_itxlauncherservers_crd.yaml" --ignore-not-found=true ${dryRun}; }        
}

uninstall_operator_native() {
    echo "-------------Uninstalling operator-------------"

    # Verify expected yaml files for uninstall and delete resources for each
    [[ -f "${casePath}/inventory/${inventory}/files/op-cli/service_account.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/service_account.yaml" --ignore-not-found=true ${dryRun}; }
    [[ -f "${casePath}/inventory/${inventory}/files/op-cli/role.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/role.yaml" --ignore-not-found=true ${dryRun}; }
    [[ -f "${casePath}/inventory/${inventory}/files/op-cli/role_binding.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/role_binding.yaml" --ignore-not-found=true ${dryRun}; }
    [[ -f "${casePath}/inventory/${inventory}/files/op-cli/operator.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/operator.yaml" --ignore-not-found=true ${dryRun}; }

    # - CRD
    if [[ $deleteCRDs -eq 1 ]]; then
        echo "-------------Deleting custom resource definitions-------------"
        [[ -f "${casePath}/inventory/${inventory}/files/op-cli/itx.ibm.com_itxlauncherservers_crd.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/itx.ibm.com_itxlauncherservers_crd.yaml" --ignore-not-found=true ${dryRun}; }
    fi
}

delete_custom_resources() {
    echo "Action not supported"
}

# ----- END ACTIONS -----

##
# Main
##

# Parse CLI parameters
while [ "${1-}" != "" ]; do
    case $1 in
    # Supported parameters for cloudctl & direct script invocation
    --casePath | -c)
        shift
        casePath="${1}"
        ;;
    --caseJsonFile)
        shift
        caseJsonFile="${1}"
        ;;
    --inventory | -e)
        shift
        inventory="${1}"
        ;;
    --action | -a)
        shift
        action="${1}"
        ;;
    --namespace | -n)
        shift
        namespace="${1}"
        ;;
    --tolerance | -t)
        shift
        tolerance_val="${1}"
        ;;
    --instance | -i)
        shift
        instance="${1}"
        ;;
    --args | -r | --)
        shift
        parse_dynamic_args "${1}"
        ;;
    # Additional supported parameters for direct script invocation ONLY
    --help)
        print_usage 0
        ;;
    --debug)
        set -x
        ;;
    --version)
        print_version
        ;;
    *)
        echo "Invalid Option ${1}" >&2
        exit 1
        ;;
    esac
    shift
done

# Execution order
check_cli_args
run_action
