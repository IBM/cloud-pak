# IBM CLOUD Application Modernization Accelerator


# Introduction

[IBM Application Modernization Accelerator](https://www.ibm.com/docs/en/ama) helps you plan, prioritize, and package your on-premise workloads for modernization on OpenShift Container Platform. Documentation for the product can be found [here](https://www.ibm.com/docs/en/ama).

# Details

The Application Modernization Accelerator is delivered as an interconnected set of pods and kubernetes services. It consists of four pods: server, ui, database and graph database, managed by an operator.

This CASE bundle contains three inventory items: 
- v2InstallProduct - Provides the CASE actions to install/uninstall the Application Modernization Accelerator product.  It will first install the operator - optionally installing catalogs as required - and then install the instance. See [README](inventory/v2InstallProduct/README.md).
- v2AppModOperator - Provides the CASE actions to install/uninstall the Application Modernization Accelerator operator.See [README](inventory/v2AppModOperator/README.md).
- v2AppMod - Provides the CASE actions to install/uninstall the Application Modernization Accelerator instance.See [README](inventory/v2AppMod/README.md).

## Prerequisites

### IBM Operator Catalog

Application Modernization Accelerator is available in the IBM Operator Catalog. See [IBM Operator Catalog documentation](https://github.com/IBM/cloud-pak/blob/<DEFAULT_BRANCH>/reference/operator-catalog-enablement.md) for more details.

When installing Application Modernization Accelerator using the CASE actions, there is an option `--installIbmCatalog` which will automatically install the IBM operator catalog if it is not already installed on your cluster.

### Namespace/Project

Create a project for Application Modernization Accelerator installation.

This can be done from the OpenShift UI as follows:
- Click the hamburger icon in the top left of the Red Hat OpenShift Container Platform dashboard. 
- Expand "Home" menu and select "Projects". 
- Click "Create Project" button.
- Name the project and click "Create".

Alternatively, you can use the `oc new-project <project name>` command from the command line.

For convenience, set an environment variable that can be used during the install.

```
export AMA_PROJECT=ta
```

### Access Application Modernization Accelerator images from the entitled registry

Application Modernization Accelerator can be installed with a time limited evaluation license (fully featured), or as an entitled product. Please read the [license](https://www.ibm.com/docs/en/ama?topic=accelerator-licensing) for more details:

- If installing as an evaluation, you can ignore the following instructions that describe how to get access to the entitled registry. In this case, the required images will be pulled from a public registry and no access details are required.

- If installing as an entitled product, you will need to have an entitled registry key.

Follow the [Cloud Pak instructions](https://www.ibm.com/docs/en/cloud-paks/1.0.0?topic=entitlements-obtaining-your-red-hat-entitlement-key) to get your entitled registry key.

You can set the entitled registry details as environment details for use during the install.

```
export ENTITLED_REGISTRY=cp.icr.io
export ENTITLED_REGISTRY_USER=cp
export ENTITLED_REGISTRY_KEY=<entitled registry key>
```

During the install, these values will be used to create an image pull secret so that you can access the images from the entitled registry.

### Persistence

Application Modernization Accelerator requires persistence to be configured in order to persist the database data. There are a number of different configuration options depending on the type of persistence that is available on your cluster.

Please refer to the [documentation](https://www.ibm.com/docs/en/ama) for full details on how to configure persistence.

**NOTE:** Application Modernization Accelerator officially supports `ReadWriteOnce` accessMode.

Although it is NOT recommended for a production install, you can also turn the persistence off. If you turn persistence off - Application Modernization Accelerator will function as normal, however, you will lose all of your Application Modernization Accelerator data when the database container restarts. Persistence can be turned on or off using the `--persistence <true|false>` argument when installing. See "Installing the CASE" section for more details.

The persistence enabled and other persistence options can be set at install time by passing arguments to the CASE installer. (see "Installing the CASE" section below).

## Resources Required

### Minimum Default Configuration

| Subsystem  | CPU Minimum | Memory Minimum (GB) | Disk Space Minimum (GB) |
| ---------- | ----------- | ------------------- | ----------------------- |
| CouchDB    | 0.5         | 1                   | 20                       |
| GraphDB    | 0.5         | 1                   | 5                       |
| Server     | 0.5         | 1                   | N/A                     |
| UI         | 0.5         | 1                   | N/A                     |
| Operator   | 0.4         | 0.5                 | N/A                     |

These values can be changed in the custom resource yaml prior to install (see "Configure and Install Application Modernization Accelerator Instance" section below).


## Installing the CASE

The CASE installer provides the commands needed to install/uninstall Application Modernization Accelerator.
Please see the [installProduct README](inventory/v2InstallProduct/README.md) for details on running the CASE installer. 

## Configuration

Using the CASE installer, you can supply arguments at install time to configure the install. All available options are described in the [installProduct README](inventory/v2InstallProduct/README.md).


## Open Application Modernization Accelerator UI

After a successful install using the CASE install action, a URL will be printed to the console that will take you directly to the Application Modernization Accelerator UI. You will need to have a valid cluster login in order to access the UI.

Alternatively, you can navigate to the RedHat OpenShift web console. Click on the Routes item in the left navigation and select the project that you installed into. From there you should see the UI route which wil take you to the Application Modernization Accelerator UI.


# PodSecurityPolicy Requirements
No PodSecurityPolicy Requirements. A custom SecurityContextConstraint is used. See below.

Custom PodSecurityPolicy definition:
```
N/A
```

# SecurityContextConstraints Requirements
Application Modernization Accelerator Operator runs as restricted SCC.

### Custom SecurityContextConstraints definition:
N/A

## Backup and restore data

Please follow instruction in [documentation](https://www.ibm.com/docs/en/ama) to backup/restore your data.

## FAQ

For more help, or if you are experiencing issues please refer to the FAQ [here](https://www.ibm.com/docs/en/ama).

## Copyright

© Copyright IBM Corp. 2020. All Rights Reserved.
