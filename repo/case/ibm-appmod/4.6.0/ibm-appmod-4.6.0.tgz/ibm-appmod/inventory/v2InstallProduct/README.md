# IBM CLOUD Application Modernization Accelerator PRODUCT INSTALL

## Introduction
This inventory item contains scripts to do a full install of IBM Application Modernization Accelerator, the operator and the instance. The actions here wrap the actions defined in the v2AppMod and v2AppModOperator inventories.
The operator will first be installed (optionally installing the IBM operator catalog), and then the operands will be installed.

You are required to pass the `--acceptLicense true` argument in order for the install to succeed.


## Prerequisites

See the [CASE bundle README](../../README.md) for prerequisites.

## Installing with ibm-pak plugin

#### Step 1: Get ibm-pak plugin

- Follow the instructions here to get the ibm-pak `plugin`: https://github.com/IBM/ibm-pak-plugin#overview

- Log in to the OpenShift cluster with the oc tool.

```
oc login https://<your_api_cluster_url>  ...
```

#### Step 2. Set project and entitled registry environment variables

- As per prerequisites, you need to create a project to install into. Also, if you are installed from the entitled registry you need the entitled registry details. If you haven't already done so, set an environment variables for the project and entitled registry details. 

```
export AMA_PROJECT=ta
export AMA_VERSION=X.Y.Z

export ENTITLED_REGISTRY=cp.icr.io
export ENTITLED_USER=ekey
export ENTITLED_PASS=123ABC
```

**NOTE:** If you are not installing from the entitled registry, you do no need to set the `ENTITLED_*` environment variables. Instead you will pass an argument called `--tryAndBuy`  when installing.

See: https://www.ibm.com/docs/en/ama

```
oc ibm-pak get $CASE_NAME --version $CASE_VERSION
```
...where `<VERSION>` is the desired version of Application Modernization Accelerator, e.g. `2.4.1`

#### Step 3. Extract the CASE archive

```
cd appmod-case
tar -xzvf ibm-appmod-<VERSION>.tgz
```

#### Step 4. Run the CASE install action

To view the license run the following command:

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace $AMA_PROJECT \
    --action install \
    --args "--viewLicense"
```


To accept the license and install from entitled registry (See Prerequisite section) run the following command:

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace $AMA_PROJECT \
    --action install \
    --args "--acceptLicense true --registry $ENTITLED_REGISTRY --user $ENTITLED_USER --pass $ENTITLED_PASS --secret appmod-pull-secret --installIbmCatalog --storageClass rook-ceph-cephfs-internal"
```

**NOTE:** The above command sets the persistence to create and use a PVC of storage class `rook-ceph-cephfs-internal`. Change the `--storageClass` value to match a storage class that exists on your system.

**NOTE:** The above command uses the `--installIbmCatalog` argument to automatically install the [IBM operator catalog](https://github.com/IBM/cloud-pak/blob/<DEFAULT_BRANCH>/reference/operator-catalog-enablement.md) if it is not already installed on the cluster.

Alternatively, to accept the license and install Application Modernization Accelerator as a try and buy evaluation (See Prerequisite section) run the following command:

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace $AMA_PROJECT \
    --action install \
    --args "--acceptLicense true --tryAndBuy --accessMode ReadWriteOnce --supplementalGroups [65534] --installAmaCatalog"
```
**NOTE:** The above command also shows an alternative configuration for persistence. You will need to update persistence according to the options available on your cluster. Please refer to the [documentation](https://www.ibm.com/docs/en/ama) for full details on how to configure persistence.

See the "ACTION: install" section below for more details on the install action.

#### Accessing the UI

At the end of a successful install, you will be presented with a link in the console that will take you to the Application Modernization Accelerator UI. You will need to have a valid login to the cluster to access Application Modernization Accelerator UI.

## Uninstalling with ibm-pak CASE launcher

Run the following command to uninstall:

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace $AMA_PROJECT \
    --action uninstall
```
See the "ACTION: uninstall" section below for more details on the uninstall action.


## Air Gap Install

See: https://www.ibm.com/docs/en/ama

## CASE launch actions
The following case launch actions are supported in this inventory:
- `install`
- `uninstall`

### ACTION: install

#### Description

Full install of Application Modernization Accelerator.
 
#### Usage

```
oc ibm-pak launch ibm-appmod \
    --version <version> \
    --inventory v2InstallProduct \
    --namespace <namespace> \
    --action install \
    --args "[EXTRA ARGS]"

EXTRA ARGS:
    --acceptLicense <true|false>        : REQUIRED: Must be used and set to true to proceed with install.
    --installIbmCatalog <true|false>    : OPTIONAL: If set to true, the IBM operator catalog will be installed if it is not already. Default is false.
    --secret <secret>                   : OPTIONAL: Specify a secret to use to pull the Application Modernization Accelerator images from entitle registry.
    --registry <registry>               : OPTIONAL: Specify entitled registry, e.g. cp.icr.io.
    --user <user>                       : OPTIONAL: Specify user to access the entitled registry.
    --pass <password>                   : OPTIONAL: Specify password for user to access entitled registry.
    --tryAndBuy                         : OPTIONAL: If you do not have an entitlement key for the entitled registry, use this option to install Application Modernization Accelerator in try and buy mode
    --persistence <true|false>          : OPTIONAL: If persistence is required for Application Modernization Accelerator (Default is true)
    --accessMode <accessMode>           : OPTIONAL: storage accessMode. Default is ReadWriteOnce
    --persistenceClaimCouchDB <claim>   : OPTIONAL: Use an existing persistence claim for CouchDB
    --persistenceClaimNeo4j <claim>     : OPTIONAL: Use an existing persistence claim for Neo4j
    --storageClass <storage class>      : OPTIONAL: Recommended way use persistence with Application Modernization Accelerator. Specify a valid storage class to use.
    --supplementalGroups [gid,...]      : OPTIONAL: May be used if using file system based storage to ensure database container has read/write permission for the storage.
    --hostName <hostname>               : OPTIONAL: hostname to access cluster. Application Modernization Accelerator will discover and set this value. It should not need to be changed for most environments.
    --apiEndpoint <apiEndpoint>         : OPTIONAL: API url for the cluster. Application Modernization Accelerator will discover and set this value. It should not need to be changed for most environments.
    --authIssuerEndpoint <aiEndpoint>   : OPTIONAL: Auth issuer endpoint for the cluster. Application Modernization Accelerator will discover and set this value. It should not need to be changed for most environments.
    --customCACert <file path>          : OPTIONAL: Specify file to use as custom CA cert.
    --publicUrlServer                   : OPTIONAL: See docs for more information. Application Modernization Accelerator will discover and set this value. It should not need to be changed for most environments.
    --publicUrlUI                       : OPTIONAL: See docs for more information. Application Modernization Accelerator will discover and set this value. It should not need to be changed for most environments.
    --authConfigFile <file path>        : OPTIONAL: Specify file to use to configure third party authentication.
    --namespaceScoped <true|false>      : OPTIONAL: If ommitted, defaults to false. This will make the operator to be insalled into openshift-operators namespace and manage all the namespaces, operand will go into namespace specified by --namespace attribute. If set to true, operator and operand are installed into namespace specified by --namespace attribute.
    --amaHelp                            : OPTIONAL: Display options available

```

#### Examples

##### Example 1
```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace ta \
    --action install \
    --args "--acceptLicense true --registry cp.icr.io --user ekey --pass w9KpPj7MIN2coc_jMHYDK5iS --secret appmod-pull-secret --installIbmCatalog --storageClass rook-ceph-cephfs-internal "
```

The command above will do the following:

- Accept the license
- Set a storage class to be used for persistence
- Install the IBM operator catalog if its not already installed
- Install Application Modernization Accelerator operator into the `ta` namespace.
- Install Application Modernization Accelerator instance into a namespace called `ta`
- Create and use a PVC with a `rook-ceph-cephfs-internal` storage class.
- Create a secret (from the supplied user and pass) to access the entitled registry and pull the product images from entitled registry. 


##### Example 2

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace ta \
    --action install \
    --args "--acceptLicense true --tryAndBuy --installIbmCatalog --storageClass rook-ceph-cephfs-internal"
    
```
The command above will do the following:

- Accept the license
- Install the try and buy evaluation - pulling images from public registry.
- Install the IBM operator catalog if its not already installed
- Install Application Modernization Accelerator operator into the `ta` namespace.
- Install Application Modernization Accelerator instance into a namespace called `ta`
- Create and use a PVC with a `rook-ceph-cephfs-internal` storage class.


### ACTION: uninstall

#### Description

Full uninstall of Application Modernization Accelerator.
 
#### Usage

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace <namespace> \
    --action uninstall

EXTRA ARGS:
    --uninstallIbmCatalog <true|false>    : OPTIONAL: If set to true, the IBM operator catalog will be uninstalled. Default is false.
    --amaHelp                              : OPTIONAL: Display options available

```

#### Examples

##### Example 1
This command will uninstall Application Modernization Accelerator, including the operator and instance.

```
oc ibm-pak launch ibm-appmod \
    --version $AMA_VERISON \
    --inventory v2InstallProduct \
    --namespace ta \
    --action uninstall
```
