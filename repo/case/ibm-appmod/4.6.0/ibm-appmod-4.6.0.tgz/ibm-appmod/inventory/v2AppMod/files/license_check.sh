# (C) Copyright IBM Corp. 2022
view_license() {
    local _license_list_file=${casePath}/inventory/${inventory}/files/LICENSE_LIST

    echo ""
    echo "IBM Application Modernization Accelerator is offered under the following licences:"
    echo ""
    cat ${_license_list_file}
    echo ""
    echo "For details on each license, please see https://www.ibm.com/docs/en/ama"
    echo ""
    echo "Use the --licenseType option when installing to specify the ID of the license you are accepting."
    echo ""
}

get_full_license_from_id() {
    local _license_list_file=${casePath}/inventory/${inventory}/files/LICENSE_LIST
    local _full_license_descr="INVALID"

    while IFS= read -r line || [ -n "$line" ]; do
        local _id=$(echo ${line} | sed "s/.* - //")

        if [[ "${line}" == "${license_type}" ]] || [[ "${_id}" == "${license_type}" ]]; then
            _full_license_descr=${line}
            break
        fi

    done < "${_license_list_file}"

    echo ${_full_license_descr}
}

check_license_type() {
    local _license_list_file=${casePath}/inventory/${inventory}/files/LICENSE_LIST

    _full_license_descr=$(get_full_license_from_id ${license_type})
    if [[ ${_full_license_descr} == "INVALID" ]]; then
        err_exit "License type \"${license_type}\" is not valid. You must provide a valid license type using the --licenseType option. Use --viewLicense to see the valid options."
    fi
}

check_license_accept() {

    if [[ "${license_accept}" != "true" ]]; then
        err_exit "You must accept the license before installing Application Modernization Acceleratorion Acceleratorion Accelerator. Use '--viewLicense' to view the license and '--acceptLicense true' to accept the license."
    fi
}

check_license() {
    if [[ "${view_license}" == "true" ]]; then
        view_license
        exit 0;
    fi

    check_license_type

    check_license_accept
}
