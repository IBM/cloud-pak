# Name

IBM&reg; (IBM Sterling B2B Integrator Enterprise Edition v6.2.0.5_2)

# Introduction

IBM Sterling B2B Integrator helps companies integrate complex B2B EDI processes with their partner communities. Organizations get a single, flexible B2B platform that supports most communication protocols, helps secure your B2B network and data, and achieves high-availability operations. The offering enables companies to reduce costs by consolidating EDI and non-EDI any-to-any transmissions on a single B2B platform and helps automate B2B processes across enterprises, while providing governance and visibility over those processes.
This CASE provides a helm chart to install IBM Sterling B2B Integrator Enterprise Edition v6.2.0.5_2.

To find out more, see [IBM Sterling B2B Integrator](https://www.ibm.com/us-en/marketplace/b2b-gateway-software) on IBM Marketplace.

# Details

This CASE contains two inventory items:

ibmB2biProd - a helm chart for installing IBM Sterling B2B Integrator Enterprise Edition v6.2.0.5_2.
ibmB2biProdSetup - required setup for installing the ibmB2biProd item.

## Prerequisites

### PodSecurityPolicy Requirements

With Kubernetes v1.25, Pod Security Policy (PSP) API has been removed and replaced with Pod Security Admission (PSA) contoller. Kubernetes PSA conroller enforces predefined Pod Security levels at the namespace level. The Kubernetes Pod Security Standards defines three different levels: privileged, baseline, and restricted. Refer to Kubernetes [`Pod Security Standards`] (https://kubernetes.io/docs/concepts/security/pod-security-standards/) documentation for more details. This chart is compatible with the restricted security level. 

For users upgrading from older Kubernetes version to v1.25 or higher, refer to Kubernetes [`Migrate from PSP`](https://kubernetes.io/docs/tasks/configure-pod-container/migrate-from-psp/) documentation to help with migrating from PodSecurityPolicies to the built-in Pod Security Admission controller.

For users continuing on older Kubernetes versions (<1.25) and using PodSecurityPolicies, choose either a predefined PodSecurityPolicy or have your cluster administrator create a custom PodSecurityPolicy for you. This chart is compatible with most restrictive policies.
Below is an optional custom PSP definition based on the IBM restricted PSP.

* Predefined PodSecurityPolicy name: [`ibm-restricted-psp`](https://ibm.biz/cpkspec-psp)
 
- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom PodSecurityPolicy based on IBM restricted PSP.
  - Custom PodSecurityPolicy definition:

    ```
    
    apiVersion: policy/v1beta1
    kind: PodSecurityPolicy
    metadata:
      name: "ibm-b2bi-psp"
      labels:
        app: "ibm-b2bi-psp"
      
    spec:
      privileged: false
      allowPrivilegeEscalation: false
      hostPID: false
      hostIPC: false
      hostNetwork: false
      allowedCapabilities:
      requiredDropCapabilities:
      - ALL
      allowedHostPaths:
      runAsUser:
        rule: MustRunAsNonRoot
      runAsGroup:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      seLinux:
        rule: RunAsAny
      supplementalGroups:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      fsGroup:
        rule: MustRunAs  
        ranges:
        - min: 1
          max: 4294967294
      volumes:
      - configMap
      - emptyDir
      - projected
      - secret
      - downwardAPI
      - persistentVolumeClaim
      - nfs
      forbiddenSysctls:
      - '*' 
    ```

  - Custom Role for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: Role
    metadata:
      name: "ibm-b2bi-psp"
      labels:
        app: "ibm-b2bi-psp"
    rules:
    - apiGroups:
      - policy
      resourceNames:
      - "ibm-b2bi-psp"
      resources:
      - podsecuritypolicies
      verbs:
      - use
    ```

  - Custom Role binding for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: RoleBinding
    metadata:
      name: "ibm-b2bi-psp"
      labels:
        app: "ibm-b2bi-psp"
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: "ibm-b2bi-psp"
    subjects:
    - apiGroup: rbac.authorization.k8s.io
      kind: Group
      name: system:serviceaccounts
      namespace: {{ NAMESPACE }}
    ```

### SecurityContextConstraints Requirements

Red Hat OpenShift provides a pre-defined or default set of SecurityContextConstraints (SCC). These SCCs are used to control permissions for pods. These permissions include actions that a pod can perform and what resources it can access. You can use SCCs to define a set of conditions that a pod must run with to be accepted into the system. Refer to OpenShift [`Managing Security Context Constraints`](https://docs.openshift.com/container-platform/4.11/authentication/managing-security-context-constraints.html#default-sccs_configuring-internal-oauth) documentation for more details on the default SCCs. This chart is compatible with both restricted and resticted-v2 (added in OpenShift v4.11) default SCCs and does not require a custom SCC to be defined explicity.

For OpenShift, choose either a predefined SCC or have your cluster administrator create a custom SCC for you as per the security profile and policies adopted for all OpenShift deployments. This chart is compatible with most restrictive security context constraints.
Below is an optional custom SCC definition based on the IBM restricted SCC.

* Predefined SecurityContextConstraints name: [`ibm-restricted-scc`](https://ibm.biz/cpkspec-scc)

- From the user interface or command line, you can copy and paste the following snippets to create and enable the below custom SCC based on IBM restricted SCC.

  - Custom SecurityContextConstraints definition:

    ```
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata: 
      name: ibm-b2bi-scc
      labels:
       app: "ibm-b2bi-scc"
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    privileged: false
    allowPrivilegeEscalation: false
    allowPrivilegedContainer: false
    allowedCapabilities: 
    allowedFlexVolumes: []
    allowedUnsafeSysctls: []
    defaultAddCapabilities: []
    defaultAllowPrivilegeEscalation: false
    forbiddenSysctls:
      - "*"
    fsGroup:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - ALL
    runAsUser:
      type: MustRunAsRange
    # This can be customized for your host machine
    seLinuxContext:
      type: MustRunAs
    # seLinuxOptions:
    #   level:
    #   user:
    #   role:
    #   type:
    supplementalGroups:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    # This can be customized for your host machine
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
    - nfs
    priority: 0
    ```

    - Custom Role for the custom SecurityContextConstraints:
    
    ```
    apiVersion: rbac.authorization.k8s.io/v1
	  kind: Role
	  metadata:
     name: "ibm-b2bi-scc"
     labels:
      app: "ibm-b2bi-scc" 
	  rules:
	  - apiGroups:
  	  - security.openshift.io
  	  resourceNames:
      - "ibm-b2bi-scc"
      resources:
      - securitycontextconstraints
      verbs:
      - use
    
    ```

    - Custom Role binding for the custom SecurityContextConstraints:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: RoleBinding
    metadata:
      name: "ibm-b2bi-scc"
      labels:
        app: "ibm-b2bi-scc"
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: "ibm-b2bi-scc"
    subjects:
    - apiGroup: rbac.authorization.k8s.io
      kind: Group
      name: system:serviceaccounts
      namespace: {{ NAMESPACE }}
    ```

### Resources Required

The following table describes the default usage and limits per pod

Pod                                       | Memory Requested  | Memory Limit | CPU Requested | CPU Limit
------------------------------------------| ------------------|--------------| --------------|----------
Application Server Independent (ASI) pod  |       4 Gi        |     8 Gi     |      2        |    4
Adapter Container (AC) pod                |       4 Gi        |     8 Gi     |      2        |    4
Liberty API server (API) pod              |       2 Gi        |     4 Gi     |      2        |    4
External Purge (API) pod                  |       0.5 Gi      |     1 Gi     |      0.1      |    0.5

# Installing the case

### Install Prequisites

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Setup Readme](./inventory/ibmB2biProdSetup/README.md)

### Install CASE inventory items

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmB2biProd/README.md)

### Uninstalling the CASE

See the following readme files for details of removing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmB2biProd/README.md)

## Configuration

- [Chart Readme](./inventory/ibmB2biProd/README.md)

## Storage

To work with IBM Sterling B2B Integrator Helm Charts 3 out of the box Persistent Volume Claims can be configured or enabled for resources, logs and documents. 

* While the resources volume is not dynamic and needs to be pre-setup on shared file storage viz. NFS with the     
required database driver and other resources files, It is recommended to use a dynamic provisioner to  
create the logs and documents persistent volume.
* resources, logs and documents volume should have the access mode set to ReadOnlyMany, ReadWriteMany and  ReadWriteMany respectively.  
* The Storage Class should have a Reclaim Policy of Retain.
* The persistent volume cannot be hostpath or empty dir.

### Setting the `fsGroup`

Unless overridden by the environment (e.g. OpenShift may set these according to the restricted SCC)), the `B2BICluster` uses a default `securityContext` of:

```
securityContext:
  runAsUser: 1010
  fsGroup: 1010
  supplementalGroups: [5555]
```

For resources volume the group id of the shared file system needs to be assigned as part of the supplementalGroups to configure the correct file permissions for persistent volumes.

## Limitations

* If user wishes to use fluentd log collector, it needs to run with root user to access the /var/log/ directories.
* In case the data setup job takes more than 3600 seconds due to database server connectivity, please edit the kube-apiserver.yaml to increase request timeout to 3600 or more. Example : `- --min-request-timeout=3600`

## Documentation

[IBM Sterling B2B Integrator V6.2.0.5_2](https://www.ibm.com/docs/en/b2b-integrator/6.2.0)
