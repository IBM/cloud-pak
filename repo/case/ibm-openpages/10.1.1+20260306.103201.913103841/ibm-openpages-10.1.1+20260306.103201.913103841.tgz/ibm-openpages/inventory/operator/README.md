# OpenPages Operator

Contains the OpenPages Operator custom resources and launch scripts to install/delete the custom resources
