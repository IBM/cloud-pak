# Name

IBM OpenPages® for IBM Cloud Pak® for Data

# Introduction

IBM OpenPages is an integrated governance, risk, and compliance platform that companies can use as a tool to assist in managing risk and regulatory challenges across the enterprise.

# Details

This operator deploys IBM OpenPages® Extension for IBM Cloud Pak® for Data which is an AI-driven governance, risk and compliance (GRC) solution built to help organizations manage risk and regulatory compliance challenges. For more information about IBM OpenPages see the [product documentation](https://www.ibm.com/docs/en/software-hub/5.3.x/svc-welcome/openpages.html).

This service is not available by default. An administrator must install this service on the IBM® Cloud Pak for Data platform.

## Prerequisites

- Red Hat OpenShift Container Platform 4.12 or 4.14 or 4.15 installed on `x86_64`
- IBM Cloud Pak for Data will need to be deployed prior to the deployment of the IBM OpenPages service add-on.
- A user with cluster administrator role
- No storage is required to install the operator, but you need storage and resources to install Cloud Pak for Data services. For more information, see [Storage considerations](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/plan/storage_considerations.html).
- See [Setup client workstation](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/install/setup-client.html), [Collecting required information](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/install/collect-info.html) and [Preparing cluster](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/install/prep-cluster.html).
- Before you install Cloud Pak for Data services, review the [System requirements for services](https://www.ibm.com/docs/en/software-hub/5.3.x/sys-reqs/overview-sys-reqs.html).
- For air-gapped installations, see [Mirroring images to your private container registry](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/install/prep-cluster-mirror.html).

### Resources Required

See [System requirements](https://www.ibm.com/docs/en/software-hub/5.3.x/sys-reqs/overview-sys-reqs.html).

## Installing

- [Installing Cloud Pak for Data platform & services](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/install/install-platform.html)
- [Installing OpenPages](https://www.ibm.com/docs/en/software-hub/5.3.x/svc-openpages/openpages-svc-install.html)

## Configuration

See [Administering OpenPages](https://www.ibm.com/docs/en/software-hub/5.3.x/svc-openpages/openpages-admin.html).

## Storage

See [Recommended storage classes for services](https://www.ibm.com/docs/en/software-hub/5.3.x/sys-reqs/storage-requirements.html#compute-requirements__stg-classes-svcs__title__1).

## PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition is not applicable

## SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

The `restricted` security context constraint (SCC) is used for OpenPages.

- See [Custom security context constraints for services](https://www.ibm.com/docs/en/software-hub/5.3.x/cpd/install/prep-cluster-sccs.html#preinstall-install-sccs__custom-title).

## Limitations
- Only `x86-64` platforms are supported by OpenPages.
- See [Limitations and known issues for OpenPages](https://www.ibm.com/docs/en/software-hub/5.3.x/svc-openpages/openpages-known_issues.html).

## Documentation

See the [product documentation](https://www.ibm.com/docs/en/software-hub/5.3.x/svc-welcome/openpages.html).
