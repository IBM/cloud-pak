# Metadata Inventory (metainv)

This inventory contains the metadata and container image references for the IBM Optim CASE bundle.

## Container Images

The following container images are included in this CASE bundle:

1. **optim-metadb** (1.2.0-amd64) - PostgreSQL database for Optim metadata
2. **optim-ui** (1.2.0-amd64) - Web-based user interface
3. **optim-core-api** (1.2.0-amd64) - Core REST API service
4. **optim-runtime** (1.2.0-amd64) - Job execution and workflow engine
5. **optim-spark** (1.2.0-amd64) - Apache Spark for data processing
6. **optim-keycloak** (1.2.0-amd64) - Identity and access management
7. **optim-flight-service** (12.3.310-amd64) - Apache Arrow Flight service

## Registry

All images are hosted on IBM Container Registry: `cp.icr.io/cp/ibm-optim/`

## Architecture Support

- **amd64** (x86_64) - Fully supported