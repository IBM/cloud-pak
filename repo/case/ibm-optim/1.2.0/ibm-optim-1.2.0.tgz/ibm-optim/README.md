# IBM Optim CASE Bundle

## Overview

This is a CASE (Cloud Pak Application Software Exchange) bundle for IBM Optim. It contains the core container images needed for standalone deployment.

## Version Information

- **CASE Version**: 1.2.0
- **Application Version**: 1.2.0
- **Image Tag**: 1.2.0-amd64

## Components

This CASE bundle includes the following Optim components:

### Core Services
- **optim-metadb**: PostgreSQL database for storing Optim metadata
- **optim-core-api**: REST API service providing core Optim functionality
- **optim-runtime**: Job execution and workflow engine
- **optim-ui**: Web-based user interface

### Supporting Services
- **optim-spark**: Apache Spark engine for data processing operations
- **optim-keycloak**: Identity and access management service
- **optim-flight-service**: Apache Arrow Flight service for high-performance data transfer (version 12.3.310-amd64)

## Architecture Support

- **amd64** (x86_64)

## Container Registry

All images are hosted on IBM Container Registry:
```
cp.icr.io/cp/ibm-optim/
```

## Usage

### Prerequisites

- Docker or Podman container runtime
- Access to the IBM Container Registry (cp.icr.io)
- Sufficient storage for container images and data volumes

### Deployment

This CASE bundle is designed to work with the `archon-compose` deployment scripts. Refer to the `archon-compose/optim-compose.yaml` file for the complete deployment configuration.

### Image List

To view all images in this CASE bundle:
```bash
casectl repo list -r /path/to/case-repo
```

### Air-Gap Installation

For air-gapped environments, use the CASE bundle to mirror images:
```bash
# Save images
casectl image save -c ibm-optim -o /path/to/output

# Load images in air-gapped environment
casectl image load -i /path/to/images
```

## License

This software is licensed under the IBM Cloud Pak for Data License. See the LICENSE file for details.

## Support

For support and documentation, visit:
- [IBM Optim Product Page](https://www.ibm.com/products/optim)
- [IBM Cloud Pak for Data Documentation](https://docs-icpdata.mybluemix.net/home)

## Related Resources

- Source compose file: `archon-compose/optim-compose.yaml`
- Helm charts: `cpd-case-repo/optim/helm/`