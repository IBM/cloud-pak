# Name

IBM&reg; (Secure Tunnel)

# Introduction
This is the case for IBM Secure Tunnel.

## Summary

You can use this operator to simplify and facilitate the troubleshooting process. Secure Tunnel service is a network tool, which you can use to access services or servers in a private network from an endpoint in the Cluster, or a public cluster. You can also use Secure Tunnel to access the Cluster services from an endpoint in a public network.

## Features

* Using tunnel to access resources in the private network.

## Details

## Prerequisites
Before you install this operator, you need to ensure that the WAIOps has been installed in the cluster. Then you can go to the [Installing](#installing)

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software        | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------------- | ----------- | ----------- | --------- | ----- |
| Tunnel API      |256Mi        |100m        |           |   1    |
| Tunnel Controler|256Mi        |100m        |           |    1   |
| Tunnel UI       |256Mi        |100m        |           |    1   |
| Tunnel worker       |256Mi        |100m        |           |  1     |
| Total       |1024Mi        |400m        |           |   1    |

# PodSecurityPolicy Requirements
N/A

# SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          privileged: false
          readOnlyRootFilesystem: false
          runAsNonRoot: true
```
Custom PodSecurityPolicy definition:
```
N/A
```


## Installing
1. Install the Secure Tunnel operator.
   Secure Tunnel operator is included in the CloudPak for AIOPS catalog source as sub component. The operator will be registered to the operator hub together with AIOPS.
    - From your OpenShift Container Platform console, click **Operators** > **OperatorHub**. The OperatorHub page is displayed.
    - In the All Items field, enter Secure Tunnel. The IBM Secure Tunnel operator is displayed.
    - Click IBM Secure Tunnel operator, in the IBM IBM Secure Tunnel operator window, click Install
    - Input cp4waiops as the namespace
    - Click Install, the IBM IBM Secure Tunnel operator is installed after a few minutes
2. Create a Secure Tunnel CR to create a Secure Tunnel instance.
   **Note:** the CR should be created in the same namespace which the operator locates.
   Tunnel CR sample yaml file:
    ```
    apiVersion: sretooling.management.ibm.com/v1
    kind: Tunnel
    metadata:
      labels:
        app.kubernetes.io/instance: ibm-secure-tunnel-operator
        app.kubernetes.io/managed-by: ibm-secure-tunnel-operator
        app.kubernetes.io/name: ibm-secure-tunnel-operator
      name: sre-tunnel
    spec:
      license:
        accept: true
      pullSecret: integration-pull-secret
      showInContainerLog: true
      size: medium
      version: 1.0.0
    ```
4. Steps to validate installation: 
   Check whether all secure-tunnel pods are in running state.
   ```
   ibm-secure-tunnel-operator-59cc454d9c-r2hr5                       1/1     Running            0          4d15h
   sre-tunnel-controller-57684dd99-zdqk7                             1/1     Running            0          4d15h
   sre-tunnel-tunnel-network-api-8655dbcdc4-mrnn9                    1/1     Running            0          4d15h
   sre-tunnel-tunnel-ui-mcmtunnelui-7d7bc9b6d7-2tstf                 1/1     Running            0          4d18h
   ```
3. From the AIOPS management UI, click the **top left menu** > **Administration** > **Tunnel** to open the Secure Tunnel management UI.

### Configuration
- Provide configuration instructions if any.

## Storage
- IBM Management Secure Tunnel need no storage.

## Limitations
- No Limitations.

## Documentation
  - https://www.ibm.com/docs/en/cloud-paks/cloud-pak-watson-aiops

