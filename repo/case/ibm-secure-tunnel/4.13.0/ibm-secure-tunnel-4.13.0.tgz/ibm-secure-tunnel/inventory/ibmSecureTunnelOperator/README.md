# ibmSecureTunnelOperator

The following files are required for the operator instance creation and management. 
1. config/samples/cache_v1_tunnel.yaml
The secure tunnel custom resource deployment yaml file 
