# ibmSecureTunnelOperatorSetup

The following files are required for the operator setup. 

1. deploy/crds/sretooling.management.ibm.com_tunnels_crd.yaml
The CustomResourceDefinition yaml file for custom resource secure tunnel

1. deploy/olm-catalog/ibm-secure-tunnel/manifests/sretooling.management.ibm.com_tunnels_crd.yaml
The CustomResourceDefinition yaml file for custom resource secure tunnel

3. deploy/operator.yaml
The operator deployment yaml file for the secure tunnel operator deployment

4. deploy/role.yaml
The role definition required to deploy the secure tunnel operator

5. deploy/role_binding.yaml
The role binding definition to bind the required role to the service account required by secure tunnel operator deployment

6. deploy/service_account.yaml
The service account definition required by secure tunnel operator deployment
