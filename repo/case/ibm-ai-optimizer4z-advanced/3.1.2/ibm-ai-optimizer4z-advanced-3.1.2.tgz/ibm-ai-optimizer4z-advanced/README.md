# Name

IBM AI Optimizer for IBM Z and IBM LinuxONE 3.1.2 edition

# Introduction

AI Optimizer for Z and LinuxONE, previously known as IBM AI Optimizer for Z, is an enterprise-grade appliance that serves as a central AI inference gateway for large language model (LLM) workloads on IBM Z and LinuxONE systems. Built for the IBM Secure Service Container (SSC) platform, the appliance provides a unified control plane for deploying LLMs, routing inference requests, and executing routed requests across locally deployed and remotely hosted LLMs.

The AI Optimizer for Z and LinuxONE appliance is designed to fully leverage IBM Spyre Accelerator, an advanced hardware acceleration technology purpose‑built for AI inference workloads. Enabled by the accelerator, the appliance intelligently optimizes inference request routing across your mission‑critical AI workloads while preserving data integrity, compliance, and security already provided by the mainframe platforms.

# Documentation

Please refer to the IBM AI Optimizer for IBM Z and IBM LinuxONE documentation for instructions on accessing images:
https://www.ibm.com/docs/en/ai-optimizer-for-z
Ensure that version 3.1.2 is selected when viewing the documentation.