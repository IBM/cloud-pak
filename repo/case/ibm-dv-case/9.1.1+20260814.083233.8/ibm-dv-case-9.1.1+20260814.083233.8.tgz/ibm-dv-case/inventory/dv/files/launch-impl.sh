# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the IBM DataVirtualization (DV) operator

# IBM DV operator specific variables
caseName="ibm-dv-bundle"
inventory="dv"
caseCatalogName="ibm-dv-operator-catalog"
channelName="v9.2"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation

case_depedencies="ibm-ccs ibm-dmc ibm-db2uoperator"
skip_case_dependencies=0
travis_env=0

# ***** GLOBALS *****

# ----- DEFAULTS -----

# - additional variables
operatorName="ibm-dv-operator-controller-manager"
svcAccountName="ibm-dv-operator-controller-manager"
custom_resource_name="db2u.databases_v1_dvservice.yaml"
crd_names="db2u.databases.ibm.com_dvservices.yaml"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --travisTest)
        skip_case_dependencies=1
        travis_env=1
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    ibm-dmc)
        echo "dmcOperatorSetup"
        return 0
        ;;
    ibm-db2uoperator)
        echo "db2uOperatorSetup"
        return 0
        ;;
    *)
        echo "[ERROR] unknown dependant case: $case_name" >&2
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}
# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    local registry_arg=""
    [[ -n "${registry}" ]] && registry_arg="--registry ${registry}"

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    local registry_arg=""
    [[ -n "${registry}" ]] && registry_arg="--registry ${registry}"

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog install

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    [[ -z "${namespace}" || "${travis_env}" -eq "1" ]] && namespace="openshift-marketplace"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        sed -e "s|openshift-marketplace|${namespace}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | sed -e "s|openshift-marketplace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args install

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    install_custom_resources

    if [[ "${travis_env}" -eq "1" ]]; then
        catalogNamespace="openshift-marketplace"
    else
        catalogNamespace="${namespace}"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|${channelName}|g" | sed "s|openshift-marketplace|${catalogNamespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {

    validate_install_args install

    # TODO Validate Pre-requisite (zen, db2u op)

    # Proceed with install
    echo "-------------Installing native-------------"

    install_adm

    install_custom_resources

    if [[ "$secret" != "" ]] && [[ "${dryRun}" == "" ]]; then
       $kubernetesCLI secrets link serviceaccount/${svcAccountName} ${secret} --for=pull -n ${namespace}
    fi

    if [ -n "$registry" ]; then
        sed -i "s#icr.io/cpopen#${registry}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    fi

    $kubernetesCLI apply ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/deploy/crds/${custom_resource_name}

    validate_file_exists "$cr"

    if [[ ${skip_case_dependencies} -eq 0 ]]; then
        sed -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
        sed -e "s/accept: false/accept: true/g" "${cr}" | sed "s/spec:/spec:\n  skipdependencyinstall: 1/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {
    validate_install_catalog uninstall

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    [[ -z "${namespace}" || "${travis_env}" -eq "1" ]] && namespace="openshift-marketplace"

    echo "-------------Uninstalling catalog source-------------"
    sed -e "s|openshift-marketplace|${namespace}|g" "${catsrc_file}" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    uninstall_custom_resources
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args uninstall

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}

    uninstall_custom_resources

    uninstall_adm
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/deploy/crds/${custom_resource_name}
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun} --ignore-not-found=true
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}

# ----- END ACTIONS -----

install_adm(){
    echo "-------------Setting up administrative objects-------------"
    $kubernetesCLI apply ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
    $kubernetesCLI apply ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml

    sed -i "s/NAMESPACE/${namespace}/g" "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml
    $kubernetesCLI apply ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml
}

install_custom_resources() {
    # Both Big SQL & DV CRDs must be installed otherwise the operator will not start
    echo "-------------Installing custom resource definitions-------------"
    for crd in $crd_names;
    do
        $kubernetesCLI apply ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/${crd}
    done
}

uninstall_adm(){
    echo "-------------Deleting administrative objects-------------"
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
}

uninstall_custom_resources() {
    echo "-------------Uninstalling custom resource definitions-------------"
    for crd in $crd_names;
    do
        $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/${crd}
    done
}
