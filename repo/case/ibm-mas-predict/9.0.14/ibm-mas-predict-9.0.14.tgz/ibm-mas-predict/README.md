# Name

IBM&reg; Maximo&reg; Predict

# Introduction
## Summary
Maximo® Predict uses historical and real-time asset performance data, maintenance records, inspection reports, and environmental data to correlate performance factors that predict asset degradation or failure. Detects asset anomalies and resolve them with service requests and work orders in Maximo Manage. Predict uses artificial intelligence to optimize predict model accuracy.

## Features
With Maximo Predict, you can:
- Build asset failure models
- Predict failures
- Determine factors that contribute to failure
- Score models with current sensor data

Maximo Predict offers the following capabilities:
- Templates provided to build common predictive models
- Score predictive models using Watson™ Machine Learning
- View pre-built visualizations for common models
- Use model scores to asses asset health with Maximo Health

# Details
## Prerequisites
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4.x
- IBM&reg; Cloud Pack for Data 4.x (CP4D)
- IBM&reg; DB2 on CP4D or DB2U stand alone
- IBM&reg; Watson Machine Learning on CP4D
- IBM&reg; Watson Stusio on CP4D
- IBM&reg; Watson Openscale on CP4D
- IBM&reg; Maximo&reg; Application Suite 8.x
- IBM&reg; Maximo&reg; Health
- IBM&reg; Maximo&reg; Monitor

### Resources Required
Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |    1.5      |      2      |    250    |    1  |

## Installing
Refer to offical Predict documentation in [IBM docs](https://www.ibm.com/docs/en/mas86/8.6.0?topic=predict-deploying-maximo)

### Verifying Install
Verify no pods are crashing:
```sh
oc get pods -n mas-<instance>-predict
NAME                                                     READY   STATUS              RESTARTS   AGE
devtest-aiexpts-64744b67b-cbqjv                          1/1     Running             0          11h
devtest-aiexpts-64744b67b-cdm87                          1/1     Running             0          19h
devtest-aiexpts-64744b67b-r9s2f                          1/1     Running             0          11h
devtest-mat-service-66565d6b79-5gz7v                     1/1     Running             0          19h
devtest-mat-service-66565d6b79-f4qsv                     1/1     Running             0          11h
devtest-mat-service-66565d6b79-s2pk8                     1/1     Running             0          11h
devtest-predict-api-757d7d9c78-p7sg7                     1/1     Running             0          19h
devtest-predict-api-757d7d9c78-vh7rs                     1/1     Running             0          13h
devtest-predict-api-757d7d9c78-w2ctn                     0/1     Running             0          72s
devtest-predict-entitymgr-ws-6bb9686c55-fvhdw            1/1     Running             0          77m
ibm-mas-predict-operator-785cf97578-prc8h                1/1     Running             0          13h
ibm-truststore-mgr-controller-manager-7d9b7b9775-l5krs   1/1     Running             0          19h
```
Check status of the PredictApp custom resource:
```sh
oc get PredictApp {{instanceId}}
NAME      VERSION         STATUS   AGE
devtest   8.7.0           Ready    49d
```
Check status of the PredictWorkspace custom resource:
```sh
oc get PredictWorkspace {{instanceId}}-{{workspaceId}}
NAME             VERSION         STATUS           AGE
devtest-masdev   8.7.0           Ready            49d
```
For a more detailed view of the status of PredictWorkspace run the following:
```sh
oc get PredictWorkspace {{instanceId}} -o yaml
```

The status will show two key conditions (IntegrationSuccess, Ready) and an overall Workspace status:
```yaml
status:
  conditions:
  - lastTransitionTime: "2022-09-26T02:01:10Z"
    message: Health and Monitor Integration status is COMPLETE
    reason: IntegrationSuccess
    status: "True"
    type: Integration
  - lastTransitionTime: "2022-11-07T05:49:49Z"
    message: Workspace activation complete
    reason: Ready
    status: "True"
    type: Ready
  - lastTransitionTime: "2022-10-27T08:21:37Z"
    message: 'Failed with error: Specified project ID does not exist. Change your
      configuration or manually upload notebooks to a Watson Studio Project.'
    reason: NotebookFailure
    status: "False"
    type: Preload Notebooks
  - lastTransitionTime: "2022-11-07T05:46:26Z"
    message: ""
    reason: ""
    status: "False"
    type: Failure
  - ansibleResult:
      changed: 10
      completion: 2022-11-07T16:25:37.948612
      failures: 0
      ok: 147
      skipped: 33
    lastTransitionTime: "2022-11-07T05:46:26Z"
    message: Awaiting next reconciliation
    reason: Successful
    status: "True"
    type: Running
  - lastTransitionTime: "2022-11-07T16:25:39Z"
    message: Last reconciliation succeeded
    reason: Successful
    status: "True"
    type: Successful
  milestones:
    activated:
      anonymousId: fd3bad74-9bf5-4827-a429-e337b076ef84
      timestamp: "2022-09-26T02:01:03.024753+00:00"
      transactionId: e5a99e1e-a9cb-4a35-bed0-4078f82883e5
  predictExternalURL: https://{{workspaceId}}.predict.{{instanceId}}.{{domain}}/ibm/pmi/service
  predictInternalURL: https://{{instanceId}}-predict-api.mas-{{instanceId}}-predict.svc/ibm/pmi/service
  version:
    reconciled: "8.7.0"
```

### Known Errors
#### NotebookFailure
NotebookFailure is acceptable and does not affect the overall Status of the application and its functionality. To fix this error and make use of the new auto predict notebook upload feature into watson studio. Please edit the Watson Studio Project Settings on Predict Workspace Configuration UI on MAS and insert a valid Watson Studio Project ID. Apply the changes and save the configurations. 

### Application Status Reason Codes
The Predict operator uses the `Ready` condition reason code of the CR to indicate progress in generating the required secret. The following reason codes are used:
- `Ready` ... the predict app is up to date and ready to use
- `InvalidConfiguration` ... one or more configuration are not available or incorrect
- `CertificateNotReady` ... one or more certificates are not ready to use
- `TruststoreNotReady` ... one or more truststores are not ready to use
- `IntegrationSuccess` ... Health and Monitor Integration status is success
- `IntegrationFailed` ... Health and Monitor Integration status is failed
- `WorkspaceReady` ... Predict workspace is up to date and ready to use
- `Successful` ... Task was successful

Additionally, the notebook preloading has its own status codes. Even if the notebook preloading fails, the operator will not stop and will attempt to finish updating the workspace.
- `NotebookSuccess` ... notebooks were successfully uploaded to project
- `NotebookSkipped` ... skipped uploading notebooks due to no project ID preset
- `NotebookFailed` ... notebook upload failed for some reason, which is shown in the Predict workspace UI. Ensure a valid Watson Studio Project ID is added to Predict workspace configurations UI

## Configuration
See the details provided in [IBM docs](https://www.ibm.com/docs/en/mas86/8.6.0?topic=predict-deploying-maximo) for more information about how to configure Maximo Predict.

The following Configurations are Required for predict to work end to end:
### Database connection

Connect to the configured database by specifying the Java database connectivity values or by providing the connection URL. Please ensure A working Db2 connection info with valid Jdbc url, username and password is applied to `MAS Suite Administration -> configuration -> JDBC.` Predict consumes MAS JDBC configuration defined at System Scope
```
JDBC connection information 
Connection string: jdbc:db2://c-db2w-shared-db2u-engn-svc.db2u.svc:50001/BLUDB:sslConnection=true;
Username: db2inst1
Password: ****
Certifcate: Valid db2 ca certifcate
```
### IBM Watson Studio
Predict consumes IBM Watson Studio configuration defined at System Scope on `MAS Suite Administration -> configuration -> IBM Watson Studio.` 
```
URL: Vaild CP4D URL
Username: User name with Access to Predict notebook project on watson studio
Password: ***
```

### Dependent Applications
Predict depends on Health and Monitor. Please ensure Monitor and Health applications are working end to end before activating predict. The following compatibility matrix needs to be strictly followed to ensure compalibilty between apps. 

Example: Predict 8.7.0 works only with Manage/Health 8.5.0 and Monitor 8.9.0

| Operator         | ibm-mas-predict 8.7.x | ibm-mas-predict 8.6.x | ibm-mas-predict 8.5.x | 
| -----------------| :--:    |:--:     |:--:    |
| ibm-mas          |  8.9.x  | 8.8.x   | 8.7.x  |
| ibm-mas-manage   |  8.5.x  |  8.4.x  | 8.3.x  |
| ibm-mas-monitor  |  8.9.x  |  8.8.x  | 8.7.x  |

### Advanced Settings
Predict requires a few of these settings to ensure stability 
#### IBM Watson Studio Project Settings
Ensure a Project ID Text box has a valid Watson Studio project ID. To obtain the project ID, Navigate to Cp4d/Watson Studio and create/Reuse a project. Open the project and look into the Browser URL, obtain the project ID from the URL and update Project ID settings. 
```
Project ID: 67d5945b-bf48-4144-8c52-ec599f788c6d
```
#### IBM Watson Machine Learning
WML Configuraiton is critical to the functioning of Explanability feature of predict. Please ensure the below settings are accurate. 

Default URL out of the box points to a Internal WML URL running within CP4D on the same cluster as MAS Predict. If your setup is different or if you wish to use a different WML, Update the URL field and Apply the changes. Predict 8.7 support WML client `4.5`, Please ensure version is always set to `4.5`. Default WML Instance ID is always `Openshift`
```
URL: https://internal-nginx-svc.ibm-cpd.svc:12443
Version: 4.5
Instance ID: Opensift
```

#### Deployment size
Deployment Size lets you manage the Predict Workload size on Openshift. This settings controlls the Replica count of each of the predict containers deployed on openshift. Developer options sets Replica to 1, Small lets you set Replicas to 2 and Medium to 3. 

By Default Deployment Size is set to small with a replica count of 2.


```
Developer
Small 
Medium
```
## Usage
See the details provided in [IBM docs](https://www.ibm.com/docs/en/mhmpmh-and-p-u/8.5.0?topic=started-getting-data-scientists) for more information about how to use Maximo Predict.
## Storage
IBM&reg; Maximo&reg; Predict requires no direct persistent storage in the OpenShift cluster. All data is stored in the IBM DB2 prerequiste. 

### Encryption
We recommend the use of storage with passive encryption enabled to protect the data in IBM DB2.

## Air Gap Installs
Air gap installs are not supported in Maximo Predict 8.0 ~ 8.6. Predict 8.7 onwards supports install via Digests. 

## Limitations
- The operator only supports single namespace deployment
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of the Suite can **not** be deployed in the same namespace
- Each Suite resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-predict`

## Upgrades
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.6/html/operators/administrator-tasks#olm-upgrading-operators).

## Documentation
The Maximo Application Suite documentation is available [here](https://www.ibm.com/support/knowledgecenter/SSRHPA_8.6.0)

## License
Maximo Application Suite 8.6 License is available [here](https://ibm.biz/MAS86-License) 

## Backup
### Backup process
Backups should be made of both the OpenShift Cluster and DB2. OpenShift Cluster backup requires backing up the etcd cluster. Details can be found in the OpenShift Container Platform [documentation](https://docs.openshift.com/container-platform/4.6/backup_and_restore/backing-up-etcd.html)

Backups should be made of the following DB2 databases:
- `BLUDB`

Database Backup documenation for DB2 is avaliable [here](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/svc-db2/backup_db_db2_backup-online.html)

### Restore process
Restoring should be executing as described in the OpenShift Container Platform documentation and DB2 documentation.

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
The operator runs with the `restricted` SCC

