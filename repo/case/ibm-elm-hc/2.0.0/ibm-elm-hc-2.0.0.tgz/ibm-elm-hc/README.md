# Name

IBM&reg; Engineering Lifecycle Management on Hybrid Cloud

# Introduction

## Summary

IBM Engineering Lifecycle Management (ELM) is the leading platform for today’s complex product and software development. ELM extends the functionality of standard ALM tools, providing an integrated, end-to-end solution that offers full transparency and traceability across all engineering data. From requirements through testing and deployment, ELM optimizes collaboration and communication across all stakeholders, improving decision-making, productivity, and overall product quality.

Engineering Lifecycle Management on Hybrid Cloud gives you the option to run ELM applications on container platforms. It is designed to
* Simplify installation, update, and upgrades, which can shorten the deployment cycles
* Reduce the efforts required for deploying and scaling ELM applications
* Improve serviceability by providing consistent configurations and diagnostic data collection


## Features

* An ELM operator installs and configures ELM applications running in containers, installs updated containers with latest interim fixes, and upgrades to new ELM releases. Project area configuration and user configuration continue to be the responsibility of JazzAdmins.
* Deploy on Red Hat® OpenShift® or other Kubernetes container platforms. Use an environment provided by a cloud provider or deploy on premises.
* For general ELM information see [Engineering Lifecycle Management overview](https://www.ibm.com/docs/en/engineering-lifecycle-management-suite/lifecycle-management/7.1?topic=overview) and the [ELM prouduct page](https://www.ibm.com/products/engineering-lifecycle-management).

# Details

## Prerequisites

### Resources Required

* ELM on Hybrid Cloud supports five predefined deployment sizes for ELM instance creation, which can be further customized after installation. Each deployment size denotes the memory, CPU, and disk that is required in the cluster to run ELM applications. For more information, see [ELM instance deployment sizes](https://ibm.biz/ELMHC-Size).

# Installing

* For pre-installation tasks, see [Preinstallation tasks](https://ibm.biz/ELMHC-Planning).

* For installation tasks, see [Installation tasks](https://ibm.biz/ELMHC-Install). 

* For postinstallation tasks, see [Postinstallation tasks](https://ibm.biz/ELMHC-PostInstall). 

## Configuration

* You can configure and customize the ELM instance when you create it. For more information about supported configurations, see [Checklist for creating ELM instance](https://ibm.biz/ELMHC-Config). 

## Storage

ELM on Hybrid Cloud uses following storage types,

* Dynamically provisioned persistent volume
* Pre-created persistent volume

For more information, see [Storage requirements](https://ibm.biz/ELMHC-Storage). 

If the storage or storage provider you want to use in the cluster require specific permissions (user or group), you can configure that during ELM instance creation. For more information, see [Configuring storage requirements for ELM instance](https://ibm.biz/elmhc-storageconfig).

## Limitations

* [Limitations of Engineering Lifecycle Management on Hybrid Cloud](https://ibm.biz/ELMHC-Limitation)


## Documentation

* [ELM on Hybrid Cloud product documentation](https://ibm.biz/ELM-On-Hybrid-Cloud)
* [ELM product documentation](https://www.ibm.com/docs/en/elm) 

# SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

* ELM on Hybrid cloud supports only the restricted SCC (security context constraints) on the Red Hat OpenShift platform. For more information, see this [documentation topic](https://ibm.biz/ELMHC-RBAC-SCC). 