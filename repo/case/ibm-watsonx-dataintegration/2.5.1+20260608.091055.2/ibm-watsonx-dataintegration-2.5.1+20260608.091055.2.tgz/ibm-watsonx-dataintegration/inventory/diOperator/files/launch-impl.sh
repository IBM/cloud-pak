# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ds operator

# ds operator specific variables
#caseName="ibm-sample-panamax"
caseName="ibm-watsonx-dataintegration"
#inventory="panamaxOperatorSetup"
inventory="diOperatorSetup"
#caseCatalogName="ibm-sample-panamax-catalog"
caseCatalogName="ibm-watsonx-dataintegration-operator-catalog"
catalogNamespace="openshift-marketplace"

channelName="v2.5"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-di-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:tbd}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-wcp-datastage-team-docker-local.artifactory.swg-devops.com}"
CATALOG_IMAGE="${CATALOG_IMAGE:-di-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:tbd}"
BUILD_NUMBER="3"
entitledRegistry="wcp-datastage-team-docker-local.artifactory.swg-devops.com"
storageclass=""
backupstorageclass=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}


# install operand custom resources
apply_custom_resources() {
    echo "start apply_custom_resources()"
    local cr="${casePath}"/inventory/"${inventory}"/files/wxdi_cr.yaml

    echo "storageclass: ${storageclass}"
    if [[ -z ${storageclass} ]]; then
        echo "storageclass is empty"
        storageclass="nfs-client"
    fi

    sed -i "s/namespace: ds/namespace: ${namespace}/g" $cr
    sed -i "s/storageClass: nfs-client/storageClass: ${storageclass}/g" $cr

    oc apply -f $cr -n ${namespace}

    echo "complete apply_custom_resources()" 
}

delete_custom_resources() {
    echo "start delete_custom_resources()"
    local cr="${casePath}"/inventory/"${inventory}"/files/wxdi_cr.yaml
    sed -i "s/namespace: ds/namespace: ${namespace}/g" $cr
    sed -i "s/storageClass: nfs-client/storageClass: ${storageclass}/g" $cr
    oc delete -n "${namespace}" -f "${cr}"
    echo "complete delete_custom_resources()"
}