# Name

IBM&reg; Managed Services

# Introduction

## Summary

By using the Managed services, you can automate provisioning of infrastructure and virtual machine applications across multiple cloud environments with optional workflow orchestration.

The Managed services was previously called as Terraform & Service Automation or IBM Cloud Automation Manager. For documentation for previous versions of IBM Cloud Automation Manager, see the [IBM Cloud Automation Manager Knowledge Center](https://www.ibm.com/support/knowledgecenter/en/SS2L37/product_welcome_cloud_automation_manager.html).

Managed services is a multi-cloud, self-service management platform running on IBM Cloud Pak for AIOps.

Service Composer from the Managed services allows you to expose cloud services to any cloud through the Service library. It accelerates developer velocity and improve governance.

Managed services uses open source Terraform to manage and deliver cloud infrastructure as code. Cloud infrastructure delivered as code is reusable, able to be placed under version control, shared across distributed teams, and it can be used to easily replicate environments. Managed services brings a common approach to automate all workloads in all clouds to reduce configuration errors and improve operational efficiency. You can manage infrastructure as code using Hashicorp Terraform software.

The Managed services content library comes pre-populated with sample templates to help you get started quickly. It allows you to leverage IBM, community, and home-grown assets as building blocks and modernize legacy applications and build new cloud native applications. Use the sample templates as is or customize them as needed. A Chef runtime environment can also be deployed using Managed services for more advanced application configuration and deployment.

The locally installed Template Designer accelerates development of reusable Terraform automation.

With Managed services, you can provision cloud infrastructure and accelerate application delivery into multiple cloud environments with a single user experience.

You can spend more time building applications and less time building environments when cloud infrastructure is delivered with automation. You are able to get started fast with pre-built infrastructure from the Managed services library.

## Features

- **Accelerate innovation and agility**
  
  Provision your multi-cloud environments through a self-service catalog. Easily integrate with your existing processes and tools through automated workflow capabilities.

- **Enrich cloud automation**
  
  It helps to  troubleshoot, pinpoint and predict outcomes while seeking prescriptive guidance for intelligent workload placement.

- **Multi-cloud operations**
  
  Consistently manage and govern across all of your cloud environments.

- **Open source technology**
  
  Simplify your multi-cloud provisioning by utilizing open source and industry standards such as Terraform. Reuse your existing skills and Chef scripts and avoid vendor lock-in.  

# Details

## Prerequisites

### Resources Required


Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Nodes |
| --------- | ----------- | ----------- | ----- |
| High availability configuration | 16 per node | 4 per node | 3 |
| Single node deployment | >30 | 12 | 1 |
| Large Number of deployed instances | 16 per node | 5 per node | 3 |

# Installing

Documentation for the IBM Cloud Pak for AIOps installation can be found [here](https://www.ibm.com/support/knowledgecenter/SSFC4F/product_welcome_cloud_pak.html). Select the correct version and navigate to the installation page. 

## Configuration

Additional configuration steps can be found [here](https://www.ibm.com/support/knowledgecenter/en/SS2L37_4.2.0.0/cam_configure.html). Be sure to select the proper product version. 

## Storage

RWO storage is required. Documentation can be found [here](https://www.ibm.com/support/knowledgecenter/en/SS2L37_4.2.0.0/cam_create_pv.html). Be sure to select the proper product version.

Persistent storage requirement: 

| Persistent Volume | Size (GB) |
| --------- | ----------- |
| cam-mongo-pv | 20 |

## Documentation

The main documentation page for Managed services can be found [here](https://www.ibm.com/support/knowledgecenter/en/SSFC4F_1.3.0/cam/cam_intro.html). Be sure to select the proper product version. 
