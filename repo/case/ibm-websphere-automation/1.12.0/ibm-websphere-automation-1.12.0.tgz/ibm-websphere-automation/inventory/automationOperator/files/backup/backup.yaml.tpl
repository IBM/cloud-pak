apiVersion: batch/v1
kind: Job
metadata:
  name: wsa-<action>-<job_id>
  labels:
    app.kubernetes.io/name: wsa-<action>-<job_id>
    app.kubernetes.io/component: wsa-<action>
spec:
  backoffLimit: 0
  template:
    metadata:
      labels:
        app.kubernetes.io/component: wsa-<action>
        app.kubernetes.io/instance: wsa-<action>
        app.kubernetes.io/managed-by: websphere-automation-operator
        app.kubernetes.io/name: wsa-<action>-<job_id>
        app.kubernetes.io/part-of: wsa
        automation.websphere.ibm.com/allow-db-access: 'true'
        automation.websphere.ibm.com/allow-apiserver-access: 'true'
    spec: 
      affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
            - matchExpressions:
              - key: kubernetes.io/arch
                operator: In
                values:
                - amd64
                - s390x
      containers:
      - name: backup
        image: <image>
        command:
        - /scripts/backup.sh
        args:
        - <action>
        resources:
          limits:
            cpu: 500m
            memory: 256Mi
          requests:
            cpu: 250m
            memory: 128Mi
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          privileged: false
          readOnlyRootFilesystem: false
          runAsNonRoot: true
        volumeMounts:
        - name: ca
          mountPath: /etc/wasintops/ca/
          readOnly: true
        - name: mongo-config
          mountPath: /etc/wasintops/backbone/mongo
          readOnly: true
        - mountPath: /scripts/
          name: scripts
          readOnly: true
        - mountPath: /backup
          name: backup-dir
        env:
        - name: WSA_MONGODB_USER
          valueFrom:
            secretKeyRef:
              name: <prefix>-mongo-admin-creds
              key: "user"
        - name: WSA_MONGODB_PASS
          valueFrom:
            secretKeyRef:
              name: <prefix>-mongo-admin-creds
              key: "password"
        - name: BACKUP_BASE_DIR
          value: /backup
        - name: TIMESTAMP
          value: "<timestamp>"
        - name: AUTOMATION_CR
          value: <prefix>
        - name: SECURE_CR
          value: "<secure_cr>"
        - name: HEALTH_CR
          value: "<health_cr>"
      restartPolicy: Never
      serviceAccount: wsa-backup-sa
      volumes:
      - name: mongo-config
        configMap:
          defaultMode: 420
          name: <prefix>-mongo-client
      - name: ca
        secret:
          secretName: <prefix>-truststore
          defaultMode: 0420
      - name: scripts
        configMap:
          defaultMode: 0774
          name: wsa-backup-scripts
      - name: backup-dir
        persistentVolumeClaim:
          claimName: <claim>
