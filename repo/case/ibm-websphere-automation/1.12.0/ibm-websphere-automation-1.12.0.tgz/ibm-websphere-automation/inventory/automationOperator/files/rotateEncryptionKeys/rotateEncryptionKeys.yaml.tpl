apiVersion: batch/v1
kind: Job
metadata:
  name: wsa-<action>-<job_id>
  labels:
    app.kubernetes.io/name: wsa-<action>-<job_id>
    app.kubernetes.io/component: wsa-<action>
spec:
  parallelism: 1
  completions: 1
  activeDeadlineSeconds: 300
  backoffLimit: 0
  template:
    metadata:
      labels:
        app.kubernetes.io/component: wsa-<action>
        app.kubernetes.io/instance: wsa-<action>
        app.kubernetes.io/managed-by: websphere-automation-operator
        app.kubernetes.io/name: wsa-<action>-<job_id>
        app.kubernetes.io/part-of: wsa
        automation.websphere.ibm.com/allow-db-access: 'true'
        automation.websphere.ibm.com/allow-apiserver-access: 'true'
    spec: 
      affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
            - matchExpressions:
              - key: kubernetes.io/arch
                operator: In
                values:
                - amd64
                - s390x
      containers:
      - name: rotate-encryption-keys
        image: <image>
        resources:
          limits:
            cpu: 500m
            memory: 256Mi
          requests:
            cpu: 250m
            memory: 128Mi
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          privileged: false
          readOnlyRootFilesystem: false
          runAsNonRoot: true
        volumeMounts:
        - name: ca
          mountPath: /etc/wasintops/ca/
          readOnly: true
        - name: mongo-config
          mountPath: /etc/wasintops/backbone/mongo
          readOnly: true
        - name: mongo-creds
          readOnly: true
          mountPath: /etc/wasintops/backbone/mongo/credentials
        - name: mongo-encryption
          readOnly: true
          mountPath: /etc/wasintops/backbone/mongo/encryption
        - name: mongo-encryption-previous
          readOnly: true
          mountPath: /etc/wasintops/backbone/mongo/encryption-previous
        env:
        - name: MONGODB_DBNAME
          value: <dbname>
        - name: TRUSTSTORE_PASSWORD
          valueFrom:
            secretKeyRef:
              name: <prefix>-truststore
              key: trust.password
        - name: TRUSTSTORE_PATH
          value: /etc/wasintops/ca/trust.p12
        - name: CLI_ARGS
          value: server
      restartPolicy: Never
      serviceAccount: wsa-rotate-encryption-keys-sa
      volumes:
      - name: ca
        secret:
          secretName: <prefix>-truststore
          defaultMode: 400
      - name: mongo-config
        configMap:
          defaultMode: 420
          name: <prefix>-mongo-client
      - name: mongo-creds
        secret:
          secretName: <prefix>-secure-mongo-creds
          defaultMode: 400
      - name: mongo-encryption
        secret:
          secretName: <prefix>-secure-encrypt
          defaultMode: 400
      - name: mongo-encryption-previous
        secret:
          secretName: <prefix>-secure-encrypt-previous
          defaultMode: 400
