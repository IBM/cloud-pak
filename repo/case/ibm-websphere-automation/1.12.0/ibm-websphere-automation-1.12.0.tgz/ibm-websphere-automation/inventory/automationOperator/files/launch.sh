#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#

# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action=""
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName=""
instance=""

# - optional parameter / argument defaults
dryRun=""
namespace=""
timestamp=""
action_image=""
backup_claim=""
tolerance_val=0

# Pod replica global vars
core_activityRecordManager_replicas=""
core_apis_replicas=""
core_runbookManager_replicas=""
secure_apis_replicas=""
secure_fixManager_replicas=""
secure_installationManager_replicas=""
secure_serverRegistrationProcessor_replicas=""
secure_usageMeteringAPIs_replicas=""
secure_ui_replicas=""
secure_vulnerabilityManager_replicas=""
secure_vulnerabilityNotifier_replicas=""
health_analysisManager_replicas=""
health_apis_replicas=""
health_investigationManager_replicas=""
health_webhooksAPIs_replicas=""

# script version
version=0.0.1

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="--tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}

OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}

 ARGS per Action:
    apply-custom-resources     : creates the sample custom resource

    delete-custom-resources    : deletes the same custom resource

    backup
      --claim                  : use existing persistent volume claim
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --image                  : use alternative container image with backup utilities

    restore
      --claim                  : use existing persistent volume claim    
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --image                  : use alternative container image with backup utilities
      --timestamp              : backup timestamp to restore

    rotateEncryptionKeys
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --image                  : use alternative container image with encryption key rotation utilities
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

show_license() {
    cat "${casePath}/licenses/LA_en"
    exit 0
}

# ----- Actions -----
# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    backup)
        backup
        ;;
    restore)
        restore
        ;;
    rotateEncryptionKeys)
        rotateEncryptionKeys
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"

    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --timestamp)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            timestamp="${v}"
            ;;
        --image)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            action_image="${v}"
            ;;
        --claim)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            backup_claim="${v}"
            ;;
        --help)
            print_usage 0
            ;;
        --acceptLicense)
            accepted_license=true
            ;;
        --viewLicense)
            show_license
            ;;
        --smallProfile)
            small_profile=true
            ;;
        *)
            # pass arr[i], arr[i+1] to the override function
            parse_custom_dynamic_args "${arr[${idx}]}" "${arr[$((idx + 1))]}"
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    check_kube_connection
    check_kube_namespace    
}

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exit "No oc or kubectl found in path"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

check_kube_namespace() {
    [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
    if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
        err_exit "Unable to retrieve namespace specified ${namespace}"
    fi
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** UTILS *****

# Print version
print_version() {
    echo "[INFO] Version ${version}"
    exit 0
}

# Error reporting functions
err() {
    echo >&2 "[ERROR] $1"
}
err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

# ----- ABSTRACT FUNCTIONS -----
# the below functions can be overridden in launch implementation script

parse_custom_dynamic_args() {
    err_exit "Invalid Option ${v}"
}

# ----- INSTALL ACTIONS -----

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    $kubernetesCLI delete -n "${namespace}" ${dryRun} --ignore-not-found webspherehealth --all
    $kubernetesCLI delete -n "${namespace}" ${dryRun} --ignore-not-found webspheresecure --all
    $kubernetesCLI delete -n "${namespace}" ${dryRun} --ignore-not-found websphereautomation --all
}

apply_custom_resources() {
    if [ -z "$accepted_license" ]; then
        err_exit "To apply the custom resources, the license must be accepted by adding '--args \"--acceptLicense\"'. To view the license use '--args \"--viewLicense\"'"
    fi
    
    echo "-------------Applying custom resources-------------"
    # Create WebSphereHealth CR (this will in turn create an instance of both WebSphereAutomation & WebSphereSecure)
    if [ -z "$small_profile" ]; then
        local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/automation_v1_webspherehealth.yaml
    else
        local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/small_profile.yaml
    fi

    validate_file_exists "$cr"

    sed -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

#
# BACKUP related
#

init_backup() {
    automation_cr_name=$($kubernetesCLI get websphereautomation -n "${namespace}" -o name | cut -d/ -f2)
    echo "Found WebSphereAutomation CR: $automation_cr_name"
    if [ -z "$automation_cr_name" ]; then
        err_exit "WebSphereAutomation custom resource not found in the ${namespace} namespace."
    fi

    secure_cr_name=$($kubernetesCLI get webspheresecure -n "${namespace}" -o name | cut -d/ -f2)
    if [ -z "$secure_cr_name" ]; then
        echo "WebSphereSecure CR not found in the ${namespace} namespace."
    else
        echo "Found WebSphereSecure CR: $secure_cr_name"
    fi

    health_cr_name=$($kubernetesCLI get webspherehealth -n "${namespace}" -o name | cut -d/ -f2)
    if [ -z "$health_cr_name" ]; then
        echo "WebSphereHealth CR not found in the ${namespace} namespace."
    else
        echo "Found WebSphereHealth CR: $health_cr_name"
    fi

    if [ -z "$action_image" ]; then
        action_image=$($kubernetesCLI get statefulset -n "${namespace}" "${automation_cr_name}-mongo" -o jsonpath='{.spec.template.spec.containers[0].image}')
        if [ -z "$action_image" ]; then
            err_exit "Unable to determine backup image"
        fi
    fi

    if [ -z "$backup_claim" ]; then
        backup_claim="wsa-backup"
        echo "Using $backup_claim persistence volume claim"
        $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/backup/pvc.yaml"
    else
        echo "Checking for $backup_claim persistence volume claim"
        if ! $kubernetesCLI get pvc "$backup_claim" -n "${namespace}" >/dev/null; then
            err_exit "Persistence volume claim $backup_claim does not exist"
        fi
    fi

    $kubernetesCLI delete configmap wsa-backup-scripts ${dryRun} -n "${namespace}" --ignore-not-found
    oc create configmap wsa-backup-scripts ${dryRun} -n "${namespace}" --from-file=backup.sh="${casePath}/inventory/${inventory}/files/backup/backup.sh"

    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/backup/rbac.yaml"
}

show_logs() {
    echo "See the $backup_action logs by running:"
    echo "$kubernetesCLI logs -l job-name=wsa-${backup_action}-${job_id} --tail=-1"
}

backup() {
    timestamp=$(date +%Y%m%d-%H%M%S)
    job_id=$timestamp
    echo "--- Backing up ($timestamp) ---"
    init_backup
    backup_action=backup
    sed -e "s|<prefix>|$automation_cr_name|" \
        -e "s|<secure_cr>|$secure_cr_name|" \
        -e "s|<health_cr>|$health_cr_name|" \
        -e "s|<timestamp>|$timestamp|" \
        -e "s|<job_id>|$job_id|" \
        -e "s|<action>|$backup_action|" \
        -e "s|<image>|$action_image|" \
        -e "s|<claim>|$backup_claim|" \
       "${casePath}/inventory/${inventory}/files/backup/backup.yaml.tpl" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    show_logs
}

restore() {
    if [ -z "$timestamp" ]; then
        echo "--- Listing backups ---"
        backup_action=list
        # generate dummy timestamp
        timestamp=$(date +%Y%m%d-%H%M%S)
    else
        echo "--- Restoring data ($timestamp) ---"
        backup_action=restore
    fi
    job_id="${timestamp}-$$"
    init_backup
    sed -e "s|<prefix>|$automation_cr_name|" \
        -e "s|<secure_cr>|$secure_cr_name|" \
        -e "s|<health_cr>|$health_cr_name|" \
        -e "s|<timestamp>|$timestamp|" \
        -e "s|<job_id>|$job_id|" \
        -e "s|<action>|$backup_action|" \
        -e "s|<image>|$action_image|" \
        -e "s|<claim>|$backup_claim|" \
       "${casePath}/inventory/${inventory}/files/backup/backup.yaml.tpl" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    show_logs
}

#
# Encryption key rotation related
#

show_encryption_key_rotation_logs() {
    echo "See the encryption key rotation logs by running:"
    echo "$kubernetesCLI logs -l job-name=wsa-rotate-encryption-keys-${job_id} --tail=-1"
}

################################################################################
# The init_encryption_key_rotation function initializes the environment in
# preparation for the encryption key rotation.
#  
# The main tasks are:
# 
#   1) Scale all of the WebSphere Automation pods to 0 
#   2) Take a copy of the exising encryption key
#   3) Delete the existing encyption key
#   4) Wait for the WebSphere Automation Operator to create a new encryption key
#   5) Create the ServiceAccount, Role and RoleBinding that are required
################################################################################
init_encryption_key_rotation() {
    ################################################################################
    # WebSphere Automation Core
    ################################################################################
    automation_cr_name=$($kubernetesCLI get websphereautomation -n "${namespace}" -o name | cut -d/ -f2)
    if [ -z "$automation_cr_name" ]; then
        err_exit "WebSphereAutomation custom resource not found in the ${namespace} namespace."
    else
        echo "Found WebSphereAutomation CR: $automation_cr_name"
        # Scale all of the core pods down to zero
        setScaleToZero $automation_cr_name
    fi

    ################################################################################
    # WebSphere Automation Secure
    ################################################################################
    secure_cr_name=$($kubernetesCLI get webspheresecure -n "${namespace}" -o name | cut -d/ -f2)
    if [ -z "$secure_cr_name" ]; then
        echo "WebSphereSecure CR not found in the ${namespace} namespace."
    else
        echo "Found WebSphereSecure CR: $secure_cr_name"
    fi

    ################################################################################
    # WebSphere Automation Health
    ################################################################################
    health_cr_name=$($kubernetesCLI get webspherehealth -n "${namespace}" -o name | cut -d/ -f2)
    if [ -z "$health_cr_name" ]; then
        echo "WebSphereHealth CR not found in the ${namespace} namespace."
    else
        echo "Found WebSphereHealth CR: $health_cr_name"
    fi

    echo "Waiting 180 seconds for pods to terminate"
    sleep 180

    ################################################################################
    # Copy the existing encryption key
    ################################################################################
    echo "Copying existing encryption key to $automation_cr_name-secure-encrypt-previous"
    if !( copySecret $automation_cr_name-secure-encrypt $automation_cr_name-secure-encrypt-previous ); then
        err "An error occurred when copying the existing encryption key"
        cleanup_encryption_key_rotation
        exit 1
    fi

    ################################################################################
    # Delete the existing encryption key
    ################################################################################
    echo "Deleting existing encryption key: $automation_cr_name-secure-encrypt"
    if !($kubernetesCLI delete secret $automation_cr_name-secure-encrypt); then
        err "An error occurred when deleting the existing encryption key"
        cleanup_encryption_key_rotation
        exit 1
    fi 

    ################################################################################
    # Wait for new encryption key to be generated
    ################################################################################
    echo "Waiting for operator to generate new encryption key"
    done="false"
    i=0
    max_attempts=12    # 2 minutes max
    while [ $done == "false" ] && [ $i -lt $max_attempts ]; do
        sleep 10
        if ($kubernetesCLI get secret $automation_cr_name-secure-encrypt -n "${namespace}" > /dev/null 2>&1 ); then 
            done="true"
        fi
        ((i=i+1))
    done
    if [ $done == "false" ]; then
        err "New encryption key not created after 60 seconds"
        copySecret $automation_cr_name-secure-encrypt-previous $automation_cr_name-secure-encrypt
        cleanup_encryption_key_rotation
        exit 1
    fi

    if [ -z "$action_image" ]; then
        action_image="cp.icr.io/cp/websphere-automation-encrypted-field-migrator@sha256:ac2c093a6c6d9eec9d34f05f3cfc87277d11444c7c4c7333b1da8e284865b9bd"
    fi

    ################################################################################
    # Create ServiceAccount, Role and RoleBinding
    ################################################################################
    echo "Creating encryption key rotation RoleBinding, Role and ServiceAccount"
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/rotateEncryptionKeys/rbac.yaml"
}

################################################################################
# The rotateEncryptionKeys performs the main tasks that are required rotate the
# encryption keys. They are:
#  
#   1) Initialize the environment in preparation to rotate the encryption keys
#   2) Create the encrypted-field-migrator job to migrate any encypted fields
#      over to the new encryption key
#   3) Cleanup the environment once the encryption keys have been rotated
################################################################################
rotateEncryptionKeys() {
    timestamp=$(date +%Y%m%d-%H%M%S)
    job_id=$timestamp
    echo "--- Rotating encryption keys ($timestamp) ---"

    # Initialize the environment
    init_encryption_key_rotation

    # Run the encrypted-field-migrator job
    sed -e "s|<prefix>|$automation_cr_name|" \
        -e "s|<job_id>|$job_id|" \
        -e "s|<action>|rotate-encryption-keys|" \
        -e "s|<dbname>|webspheresecuredb|" \
        -e "s|<image>|$action_image|" \
       "${casePath}/inventory/${inventory}/files/rotateEncryptionKeys/rotateEncryptionKeys.yaml.tpl" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    # Wait for the job to complete
    echo "Waiting for $automation_cr_name-rotate-encryption-keys-${job_id} job to complete"
    done="false"
    i=0
    max_attempts=9    # 3 minutes max
    while [ $done == "false" ] && [ $i -lt $max_attempts ]; do
        sleep 20
        pod_name=$($kubernetesCLI get pod -n "${namespace}" -l job-name=$automation_cr_name-rotate-encryption-keys-${job_id} --field-selector=status.phase==Succeeded -o name)
        if [[ -z "$pod_name" ]]; then
            echo "Job $automation_cr_name-rotate-encryption-keys-${job_id} is still running"
        else
            done="true"
        fi
        ((i=i+1))
    done

    # Check to see if the job completed successfully
    if [ $done == "false" ]; then
        err "$automation_cr_name-rotate-encryption-keys-${job_id} not complete after 180 seconds"
        $kubernetesCLI delete secret $automation_cr_name-secure-encrypt
        copySecret $automation_cr_name-secure-encrypt-previous $automation_cr_name-secure-encrypt
        cleanup_encryption_key_rotation
        exit 1
    fi

    # Cleanup the environment
    cleanup_encryption_key_rotation
    show_encryption_key_rotation_logs
}

################################################################################
# The setScaleToZero function scales operator-specified pods in WSA, WSH, and
# WSS down to zero.
#  
# Arguments:
#   $1 - The name of the WSA CR instance, e.g., wsa
################################################################################
setScaleToZero() {
    echo "  Scaling all operator-specified pods to 0"  >&2
    $kubernetesCLI patch ${dryRun} websphereautomation -n "${namespace}" $1 --type=merge -p "{\"spec\":{\"scaleToZero\":true}}" >/dev/null 2>&1
}

################################################################################
# The unsetScaleToZero function re-scales all operator-specified pods in WSA,
# WSH, and WSS back to their default settings.
#  
# Arguments:
#   $1 - The name of the WSA CR instance, e.g., wsa
################################################################################
unsetScaleToZero() {
    echo "  Restoring all operator-specified pods back up"
    $kubernetesCLI patch ${dryRun} websphereautomation -n "${namespace}" $1 --type=json -p "[{ \"op\": \"remove\", \"path\": \"/spec/scaleToZero\" }]" >/dev/null 2>&1
}

################################################################################
# The copySecret copies the specified secret to a new secret with the specified
# name.
#  
# Arguments:
#   $1 - The name of the secret to copy.
#   $2 - The name of the secret to copy the original secret to.
################################################################################
copySecret() {
    $kubernetesCLI get secret $1 -n "${namespace}" -o yaml | \
        sed "s/name: $1/name: $2/" | \
        $kubernetesCLI apply -f -
    return $?
}

################################################################################
# The cleanup_encryption_key_rotation function cleanups up the environment once
# encryption key rotation process is complete.
#  
# The main tasks are:
#   1) Delete the ServiceAccount, Role and RoleBinding that are required
#   2) Delete the copy of the old encryption key
#   3) Scale all of the WebSphere Automation pods back the original number of replicas
################################################################################
cleanup_encryption_key_rotation() {

    echo "Deleting encryption key rotation RoleBinding, Role and ServiceAccount"
    $kubernetesCLI delete ${dryRun} -n "${namespace}" rolebinding wsa-rotate-encryption-keys-rolebinding
    $kubernetesCLI delete ${dryRun} -n "${namespace}" role wsa-rotate-encryption-keys-role
    $kubernetesCLI delete ${dryRun} -n "${namespace}" serviceaccount wsa-rotate-encryption-keys-sa

    echo "Deleting previous encryption key: $automation_cr_name-secure-encrypt-previous"
    $kubernetesCLI delete secret $automation_cr_name-secure-encrypt-previous

    ################################################################################
    # WebSphere Automation Core
    ################################################################################
    if [ -z "$automation_cr_name" ]; then
        err_exit "WebSphereAutomation custom resource not found in the ${namespace} namespace."
    else
        echo "Found WebSphereAutomation CR: $automation_cr_name"
        # Scale all of the core pods back up
        unsetScaleToZero $automation_cr_name
    fi

    ################################################################################
    # WebSphere Automation Secure
    ################################################################################
    if [ -z "$secure_cr_name" ]; then
        echo "WebSphereSecure CR not found in the ${namespace} namespace."
    else
        echo "Found WebSphereSecure CR: $secure_cr_name"
    fi

    ################################################################################
    # WebSphere Automation Health
    ################################################################################
    if [ -z "$health_cr_name" ]; then
        echo "WebSphereHealth CR not found in the ${namespace} namespace."
    else
        echo "Found WebSphereHealth CR: $health_cr_name"
    fi

    echo "Waiting 300 seconds for pods to start"
    sleep 300
}

# ----- END ACTIONS -----

##
# Main
##

# Parse CLI parameters
while [ "${1-}" != "" ]; do
    case $1 in
    # Supported parameters for cloudctl & direct script invocation
    --casePath | -c)
        shift
        casePath="${1}"
        ;;
    --caseJsonFile)
        shift
        caseJsonFile="${1}"
        ;;
    --inventory | -e)
        shift
        inventory="${1}"
        ;;
    --action | -a)
        shift
        action="${1}"
        ;;
    --namespace | -n)
        shift
        namespace="${1}"
        ;;
    --tolerance | -t)
        shift
        tolerance_val="${1}"
        ;;
    --instance | -i)
        shift
        instance="${1}"
        ;;
    --args | -r | --)
        shift
        parse_dynamic_args "${1}"
        ;;
    # Additional supported parameters for direct script invocation ONLY
    --help)
        print_usage 0
        ;;
    --debug)
        set -x
        ;;
    --version)
        print_version
        ;;
    *)
        echo "Invalid Option ${1}" >&2
        exit 1
        ;;
    esac
    shift
done

# Execution order
check_cli_args
run_action
