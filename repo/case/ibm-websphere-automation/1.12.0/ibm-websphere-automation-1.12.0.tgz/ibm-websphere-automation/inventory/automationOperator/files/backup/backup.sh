#!/bin/bash -e

BACKUP_DIR="$BACKUP_BASE_DIR/$TIMESTAMP"


function mongo_url() {
    MONGO_HOSTS=$(cat /etc/wasintops/backbone/mongo/mongo.yaml | grep host | cut -d: -f2)
    if [ -z "$MONGO_HOSTS" ]; then
        echo "Unable to get MongoDB hosts"
        exit 1
    fi
    MONGO_CONNECTION=""
    for HOST in $MONGO_HOSTS; do
        if [ -z "$MONGO_CONNECTION" ]; then
            MONGO_CONNECTION="rs0/$HOST:27017"
        else
            MONGO_CONNECTION="$MONGO_CONNECTION,$HOST:27017"
        fi
    done
}


function mongo_backup() {
    mongo_url
    echo "Backing up MongoDB: $MONGO_CONNECTION"
    mongodump  --ssl --sslCAFile=/etc/wasintops/ca/data.crt -v -h "${MONGO_CONNECTION}" -u "${WSA_MONGODB_USER}" -p "${WSA_MONGODB_PASS}" --archive="$BACKUP_DIR/mongodump"
}


function mongo_restore() {
    mongo_url
    echo "Restoring MongoDB: $MONGO_CONNECTION"
    mongorestore  --ssl --sslCAFile=/etc/wasintops/ca/data.crt -v -h "${MONGO_CONNECTION}" -u "${WSA_MONGODB_USER}" -p "${WSA_MONGODB_PASS}" --archive="$BACKUP_DIR/mongodump"
}

function custom_resource_backup() {
    local cr_type=$1
    local cr_name=$2

    echo "Backing up ${cr_name} ${cr_type} custom resource"
    oc get "${cr_type}" "${cr_name}" -o json | jq -c .spec > "$BACKUP_DIR/${cr_type}-${cr_name}.json"
}

function custom_resource_restore() {
    local cr_type=$1
    local cr_name=$2

    echo "Restoring ${cr_name} ${cr_type} custom resource"
    oc patch "${cr_type}" "${cr_name}" --type json -p "[{ \"op\": \"replace\", \"path\": \"/spec\", \"value\": $(cat $BACKUP_DIR/${cr_type}-${cr_name}.json) }]"
}

function secret_backup() {
    local secret_prefix=$1
    local secret_suffix=$2
    local secret_name="${secret_prefix}-${secret_suffix}"
    
    echo "Backing up ${secret_name} secret"
    oc get secret "${secret_name}" -o json | jq -c '{data: .data}' > "$BACKUP_DIR/secret-${secret_suffix}.json"
}

function secret_restore() {
    local secret_prefix=$1
    local secret_suffix=$2
    local secret_name="${secret_prefix}-${secret_suffix}"
    
    echo "Restoring ${secret_name} secret"
    oc patch secret "$secret_name" -p "$(cat $BACKUP_DIR/secret-${secret_suffix}.json)"
}

function metering_token_backup() {
    local cr_name=$1
    local suffix=metering-apis-sa
    local sa_name="${cr_name}-${suffix}"
    local secret_name="${sa_name}-generated-token"
    echo "Backing up token from ${secret_name}"
    oc get secret "$secret_name" -o json | jq -c '{data: {token: .data.token}}' > "$BACKUP_DIR/token-${suffix}.json"
}

function metering_token_restore() {
    local cr_name=$1
    local suffix=metering-apis-sa
    local sa_name="${cr_name}-${suffix}"
    local secret_name="${sa_name}-generated-token"
    echo "Restoring ${secret_name} token"
    oc patch secret "$secret_name" -p "$(cat $BACKUP_DIR/token-${suffix}.json)"
}


function backup() {
    if [ -d "$BACKUP_DIR" ]; then
        echo "Backup directory $BACKUP_DIR already exists"
        exit 1
    fi
    
    mkdir -p "$BACKUP_DIR"
    
    mongo_backup

    # cutom resources
    custom_resource_backup "websphereautomation" "$AUTOMATION_CR"
    custom_resource_backup "webspheresecure" "$SECURE_CR"

    # required things
    secret_backup "$SECURE_CR" encrypt
    secret_backup "$SECURE_CR" crypto
    metering_token_backup "$SECURE_CR"

    # optional things (they get recreated by operator)
    secret_backup "$AUTOMATION_CR" mongo-admin-creds
    secret_backup "$SECURE_CR" mongo-creds
    secret_backup "$SECURE_CR" metering-apis-encrypted-tokens

    if [ -z "$HEALTH_CR" ]; then
        echo "Skipping back up of Health resources"
    else
        custom_resource_backup "webspherehealth" "$HEALTH_CR"

        secret_backup "$HEALTH_CR" mongo-creds
        secret_backup "$HEALTH_CR" webhooks-apis-sa-generated-token
    fi

    echo "Done"
}


function restore() {
    if [ ! -d "$BACKUP_DIR" ]; then
        echo "Backup directory $BACKUP_DIR does not exist"
        exit 1
    fi

    mongo_restore

    secret_restore "$SECURE_CR" encrypt
    secret_restore "$SECURE_CR" crypto
    metering_token_restore "$SECURE_CR"

    # no need to restore mongo-admin-creds or mongo-creds secrets
    # since mongo_restore does not restore old users & roles collections
    # that is, we are not passing --restoreDbUsersAndRoles to mongorestore command.

    # cutom resources
    custom_resource_restore "websphereautomation" "$AUTOMATION_CR"
    custom_resource_restore "webspheresecure" "$SECURE_CR"
    if [ -z "$HEALTH_CR" ]; then
        echo "Skipping restore of Health resources"
    else
        secret_restore "$HEALTH_CR" webhooks-apis-sa-generated-token
        custom_resource_restore "webspherehealth" "$HEALTH_CR"
    fi

    echo "Done"
}


function list() {
    echo "Available backups:"
    ls -1 $BACKUP_BASE_DIR
}


if [ "$1" = "backup" ]; then
    backup
elif [ "$1" = "restore" ]; then
    restore
elif [ "$1" = "list" ]; then
    list
else
    echo "Usage: $0 <backup|restore>"
    exit 1
fi
