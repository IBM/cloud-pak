# Name

IBM&reg; WebSphere&reg; Automation

# Introduction

IBM WebSphere Automation helps ensure the security and compliance of WebSphere environments by allowing administrators to easily see all of the unresolved security vulnerabilities that affect either the WebSphere Application Servers or the Java virtual machines in their purview. This automated, dynamically updated information helps server administrators understand the vulnerabilities affecting their environments and track when vulnerabilities are patched.

## Details 

The IBM WebSphere Automation operator installs and manages IBM WebSphere Automation. A cluster administrator can deploy and manage the IBM WebSphere Automation instance.

## Prerequisites

Review the [system requirements](https://ibm.biz/WebSphereAutoSysReqs) for details. 

## Supported platforms

Red Hat OpenShift Container Platform 4.6 or newer installed on one of the following platforms:
- Linux x86_64

## Documentation

See [IBM WebSphere Automation documentation](https://www.ibm.com/docs/en/ws-automation).

## SecurityContextConstraints Requirements

The IBM WebSphere Automation operator runs in the `restricted` security context constraints.

Custom SecurityContextConstraints definition:

```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
    name: websphere-automation
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
    type: MustRunAs
users: []
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
    type: MustRunAsRange
seLinuxContext:
    type: MustRunAs
supplementalGroups:
    type: RunAsAny
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Resources Required

Review the [resource requirements](https://ibm.biz/WebSphereAutoReqs) before you plan to install IBM WebSphere Automation.

## Installing

Install the IBM WebSphere Automation operator to the desired namespace and create an instance of the [WebSphereAutomation custom resource](https://ibm.biz/WebSphereAutoCRs).

## Configuration

Generally, extra configuration is not required, however, the [WebSphereSecure custom resource](https://ibm.biz/WebSphereAutoCRs) can be used to customize the configuration of the IBM WebSphere Automation instance.

## Storage

Storage is required for IBM WebSphere Automation. Please see the [storage requirements](https://ibm.biz/WebSphereAutoReqs) for details.

## Limitations

IBM WebSphere Automation is not available on Power or Z architectures. Please see the [limitations](https://ibm.biz/WebSphereAutoLimits) for additional information.
