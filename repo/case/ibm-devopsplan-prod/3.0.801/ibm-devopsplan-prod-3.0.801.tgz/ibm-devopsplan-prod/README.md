# **DevOps Plan Helm Chart**

## **Introduction**

[HCL DevOps Plan](https://www.hcl-software.com/devops-plan) is a change management software platform designed for enterprise-scale environments. It supports process customization and control to accelerate project delivery and enhance developer productivity.

## **Product Documentation**

- [HCL DevOps Plan Documentation](https://help.hcl-software.com/devops/plan/index.html)

## **Prerequisites**

1. **Kubernetes and CLI Tools**
   - Kubernetes v1.20.0 or later
   - `kubectl` CLI
   - Helm v3.16 or later

   Installation guides:
   - [Install kubectl](https://kubernetes.io/docs/tasks/tools/)
   - [Install Helm](https://helm.sh/docs/intro/install/)

2. **Image and Helm Chart Access**
   - The container images and Helm chart are available on [HCL Harbor (hclcr.io)](https://hclcr.io).

   To access the chart:
   - Use the OCI command to pull the Helm chart:  
     ```bash
     helm pull oci://hclcr.io/devops-plan/hcl-devopsplan-prod --untar
     ```

   - To retrieve your CLI secret:
     1. Go to [hclcr.io](https://hclcr.io)
     2. Log in using your HCL Software ID via "LOGIN VIA OIDC PROVIDER"
     3. Open your user profile (top right dropdown) and copy the CLI secret
     4. Use this secret when creating a Docker registry secret for authentication

3. **PostgreSQL Database**
   - DevOps Plan requires a PostgreSQL database to manage TeamSpaces and Applications.
   - You may use the built-in PostgreSQL provided by the Helm chart or disable it and configure your own external PostgreSQL instance.
   - Database connection parameters are required during installation if using an external database.

4. **Persistent Volumes**
   - Persistent storage is required for DevOps Plan data (`data`, `config`, `share`, `logs`).
   - If your Kubernetes cluster supports a default `StorageClass` and dynamic provisioning, no manual PV creation is needed.
   - Otherwise, create a `StorageClass`, `PersistentVolume` and set the storage class name during the helm install.

   Set storage classes:

   ```bash
   --set global.persistence.rwoStorageClass=<Your StorageClass>
   ```

   For RWX (ReadWriteMany) support:

   ```bash
   --set global.persistence.rwxStorageClass=<Your RWX StorageClass>
   ```

5. **Keycloak Single Sign-On**
   - The Helm chart installs Keycloak by default. You can disable this and use an external Keycloak instance instead.

---

## **Installing the Chart**

### **1. Authenticate with the Registry**

```bash
helm registry login hclcr.io -u <username> -p <CLI secret>
```

### **2. Pull the Helm Chart**

```bash
helm pull oci://hclcr.io/devops-plan/hcl-devopsplan-prod --untar
```

### **3. Create the Namespace**

```bash
kubectl create namespace devopsplan
```

### **4. Create an ImagePullSecret**

Create a Docker registry secret for pulling images from HCL Harbor:

```bash
kubectl create secret docker-registry hcl-entitlement-key \
  --docker-server=hclcr.io \
  --docker-username=<Your Username> \
  --docker-password=<Your CLI Secret> \
  --namespace=devopsplan
```

### **5. Install with Default Settings**

Install the Helm chart into the `devopsplan` namespace with the release name `hcl-devopsplan`:

```bash
helm install hcl-devopsplan ./hcl-devopsplan-prod \
  -f hcl-devopsplan-prod/values-nginx.yaml \
  --namespace devopsplan \
  --set global.imagePullSecrets={hcl-entitlement-key} \
  --set global.persistence.rwoStorageClass=<Your StorageClass> \
  --set keycloak.service.ipAddress=<Your External IP Address>
```

> Note:
> - Ensure global.imagePullSecrets are formatted with braces: `{hcl-entitlement-key}`
> - To enable user invitation emails, set the `serverQualifiedUrlPath` to your DevOps Plan URL:

```bash
--set serverQualifiedUrlPath=<DevOps Plan URL>
```

### **Optional Installations**

- **External PostgreSQL**: See *Installing DevOps Plan with External Database and Optional Email Server Settings*
- **External Keycloak**: See *Installing DevOps Plan with External Keycloak Single Sign-On*
- **Emissary Ingress**: See *Installing with Emissary Ingress Load Balancer*
- **DevOps Control**: See *Installing with DevOps Control*
- **AI Assistant (Llama)**: See *AI Assistant Integration with Llama*
- **Self-Signed and Private CA**: See *Self-Signed and Private CA*

---

## **Post-Installation Steps**

1. **Check Helm Release Status**  
   Retrieve service credentials using:

   ```bash
   helm status hcl-devopsplan -n devopsplan
   ```

2. **Access Keycloak Dashboard**

   Open the Keycloak interface in your browser:  
   ```
   https://<VirtualMachine_IP>:30104
   ```

   > Accept and trust the Keycloak self-signed certificate if prompted.

3. **Access DevOps Plan Web Interface**

   Navigate to the DevOps Plan UI:  
   ```
   https://<VirtualMachine_IP>:30102
   ```

### **Install on Kubernetes Cluster in the Cloud (GKE and AKS)**

1. **Install using Helm**

```bash
helm install hcl-devopsplan ./hcl-devopsplan-prod \
  --namespace devopsplan \
  --set global.imagePullSecrets={hcl-entitlement-key} \
  --set ingress.type=nginx \
  --set global.persistence.rwoStorageClass=<Your storage class name>
```

2. **Get External IPs for Services**

Run the following command and note the EXTERNAL-IP values for the `nginx`, `analytics`, `keycloak`, and `devopsplan` services:

```bash
kubectl get services
```

Set them as environment variables:

```bash
NGINX_EXTERNAL_IP=
ANALYTICS_EXTERNAL_IP=
KEYCLOAK_EXTERNAL_IP=
DEVOPSPLAN_EXTERNAL_IP=
```

3. **Upgrade the Chart with External URLs**

```bash
helm upgrade hcl-devopsplan ./hcl-devopsplan-prod \
  --namespace devopsplan \
  --set global.imagePullSecrets={hcl-entitlement-key} \
  --set ingress.type=nginx \
  --set global.persistence.rwoStorageClass=<Your storage class name> \
  --set nginx.urlMapping=https://${NGINX_EXTERNAL_IP}:5602 \
  --set keycloak.urlMapping=https://${KEYCLOAK_EXTERNAL_IP}:8443 \
  --set analytics.urlMapping=https://${ANALYTICS_EXTERNAL_IP}:8290 \
  --set service.urlMapping=https://${DEVOPSPLAN_EXTERNAL_IP}:8190
```

4. **Access Keycloak**

```bash
echo "https://${KEYCLOAK_EXTERNAL_IP}:8443"
```

5. **Access DevOps Plan**

```bash
echo "https://${DEVOPSPLAN_EXTERNAL_IP}:8190"
```

---

### **Install with Custom Parameter Settings**

1. **Inspect and Export Values**

```bash
helm inspect values ./hcl-devopsplan-prod > my_values.yaml
```

2. **Edit `my_values.yaml`**  
Update the file with custom values for your deployment.

3. **Install Using Custom Values**

```bash
helm install hcl-devopsplan ./hcl-devopsplan-prod \
  --namespace devopsplan \
  --values my_values.yaml
```

---

## **Uninstalling the Chart**

To delete the deployment:

```bash
helm delete hcl-devopsplan --namespace devopsplan
```

---

## **Installing DevOps Plan with External Database and Optional Email Server Settings**

DevOps Plan requires a PostgreSQL database to manage TeamSpaces and Applications. You may use the default bundled PostgreSQL or configure an external database.

1. **Create a `devopsplan.yaml` file with the following content:**

```yaml
## Spring datastore settings (Only PostgreSQL)
spring:
  datastore:
    url: "jdbc:postgresql://<DATABASE_HOST>:<DATABASE_PORT>/<DATABASE_NAME>"
    username: <DATABASE_USERNAME>
    password: <DATABASE_PASSWORD>

## Tenant datastore settings (Only PostgreSQL)
tenant:
  datastore:
    server: <DATABASE_SERVER_NAME>
    dbname: <DATABASE_NAME>
    username: <DATABASE_USERNAME>
    password: <DATABASE_PASSWORD>

postgresql:
  enabled: false 

## SMTP settings (Optional)
global:
  platform:
    smtp:
      sender: <SENDER_EMAIL_ADDRESS>
      host: <SMTP_SERVER>
      port: <SMTP_PORT>
      username: <SMTP_USERNAME>
      password: <SMTP_PASSWORD>
```

---

## **Enable External Access to the Internal PostgreSQL Database**

If you plan to install **DevOps Plan** using the **internal PostgreSQL** database and need to access it from **DevOps Plan Designer** or other supported PostgreSQL tools (such as **pgAdmin 4**), you must enable external PostgreSQL access and configure the exposed port during installation or upgrade.

Use the following options with the `helm install` or `helm upgrade` command:

```bash
--set postgresql.enableExternalAccess=true
--set postgresql.service.exposePort=30106
--set control.postgresql.port=30106
```

**Note1:** On Azure Kubernetes Service (AKS) and Amazon Elastic Kubernetes Service (EKS), the external IP address is **not the same as the Kubernetes node IP**, you must explicitly provide the node’s internal IP address when running `helm install` or `helm upgrade`.

Step 1: Retrieve the node internal IP address 

```bash
NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
```

Step 2: Pass the node IP to Helm

Include the following option in your `helm install` or `helm upgrade` command:

```bash
--set postgresql.service.ipAddress=${NODE_IP}
```

**Note2:** On Google Kubernetes Engine (GKE), PostgreSQL must be exposed using a LoadBalancer Service in order to obtain a public IP address. The external IP is assigned asynchronously after the Service is created.

Step 1: Include the following option in your `helm install` or `helm upgrade` command: 

```bash
--set postgresql.service.cloudType=GKE
```

Step 2: Wait for the PostgreSQL Service to get an EXTERNAL-IP

```bash
kubectl get svc devopsplan-postgresql -n devopsplan
```

Wait until you see an IP under EXTERNAL-IP, Then capture it:

```bash
PG_IP=$(kubectl get svc devopsplan-postgresql -n devopsplan \
  -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
```

Step 3: Upgrade Helm release and inject the external IP

```bash
helm upgrade hcl-devopsplan . \
  --namespace devopsplan \
  ...
  ...
  --set postgresql.service.ipAddress=${PG_IP}
```

After enabling external access, run the following command to view the PostgreSQL connection details required to connect to the database:

```bash
helm status <release-name>
```

This output includes the host, port, and other configuration values needed to connect to the internal PostgreSQL instance.

### Connection Details

- **Host:**
  - Use **global.domain** if using an Emissary-ingress Load Balancer.
  - Use the **VM IP address** if installing on a local Kubernetes cluster.
  - Use the **Kubernetes node internal IP address** if the global.domain **IP address** or the **VM IP address** is **not the same** as the node’s internal IP address.
- **Port:** Use the value of **postgresql.service.exposePort**.
  Defualt value is **30106**.
- **Database:** *postgres*
- **Username:** *postgres*
- **Password:**
  To retrieve the password, run the following command (ensure the namespace is set to devopsplan):

  ```bash
  kubectl get secret --namespace devopsplan devopsplan-postgresql -o jsonpath="{.data.tenant-datastore-password}" | base64 -d; echo 
  ```

### Retrieve Connection Details from DevOps Plan UI

You can also retrieve the PostgreSQL connection details from the DevOps Plan TeamSpace page by following these steps:

1. Open the Tenant Management page.
2. Select the desired Tenant.
3. In the TeamSpace panel on the right, select the Details tab.
4. Click Show connection properties.
5. View the PostgreSQL connection details for the selected Tenant TeamSpace.

---

## **Installing DevOps Plan with External Keycloak (Single Sign-On)**

The Helm chart supports disabling the internal Keycloak service and integrating with an external Keycloak instance.

1. **Create a `keycloak.json` ConfigMap**

```bash
mkdir /path/to/your/keycloak
# Place keycloak.json into this folder

kubectl create configmap keycloak-json \
  --from-file=/path/to/your/keycloak/keycloak.json \
  --namespace <namespace_name>

kubectl get configmap keycloak-json -o yaml --namespace <namespace_name>
```

2. **Create a `keycloak.yaml` file:**

```yaml
keycloak:
  enabled: true
  service:
    enabled: false
  urlMapping: <Keycloak_URL>
  username: <Keycloak_Admin_Username>
  password: <Keycloak_Admin_Password>
  realmName: <Keycloak_Realm_Name>
  dashboardsClientID: <Keycloak_Dashboards_Client_ID>
  dashboardsClientSecret: <Keycloak_Dashboards_Client_Secret>
  jsonFile:
    enabled: true
    configMapName: keycloak-json

keycloaksrv:
  enabled: false
```

3. **Install or Upgrade with External Keycloak Configuration**

Add `-f keycloak.yaml` to your `helm install` or `helm upgrade` command.

## **DevOps Plan Installation with Emissary-ingress Load Balancer**

### **Before You Begin**

1. **Check OpenSSL Version**

Ensure OpenSSL version is 1.1.1 or later:

```bash
openssl version
# Example output: OpenSSL 1.1.1s  1 Nov 2022
```

2. **Check Port 443 Availability**

```bash
netstat -anp | grep 443 | grep LISTEN
```

---

### **Step 1: Install Emissary-ingress**

Install Emissary-ingress via Helm. Refer to the [official quick start guide](https://www.getambassador.io/docs/emissary/latest/tutorials/getting-started) for full instructions.

```bash
# Add Helm repo and update
helm repo add datawire https://app.getambassador.io
helm repo update

# Create namespace and install Emissary
kubectl create namespace emissary
kubectl apply -f https://app.getambassador.io/yaml/emissary/3.9.1/emissary-crds.yaml
kubectl wait --timeout=90s --for=condition=available deployment emissary-apiext -n emissary-system

helm install emissary-ingress --namespace emissary datawire/emissary-ingress
kubectl -n emissary wait --for=condition=available --timeout=90s deploy -lapp.kubernetes.io/instance=emissary-ingress
```

Verify resources:

```bash
kubectl get all -n emissary
kubectl get all -n emissary-system
```

If the EXTERNAL-IP remains in a pending state, manually assign an external IP address to the Emissary Ingress service by patching it.

```bash
IPADDRESS=<Your_External_IP_Address>
kubectl patch service emissary-ingress -n emissary -p "{\"spec\": {\"externalIPs\": [\"$IPADDRESS\"]}}"
```

---

### **Step 2: Generate Ingress Secrets**

```bash
DOMAIN=<Your_External_IP_Address>.nip.io
NAMESPACE=devopsplan
kubectl create namespace $NAMESPACE
```

```bash
helm pull oci://hclcr.io/devops-plan/hcl-devopsplan-prod --untar \
  && chmod +x hcl-devopsplan-prod/files/*.sh \
  && bash hcl-devopsplan-prod/files/certificate.sh -n $NAMESPACE -s ingress $DOMAIN
```

Verify the secrets:

```bash
kubectl get secret -n $NAMESPACE | grep ingress
```

---

### **Step 3: Install DevOps Plan**

```bash
helm upgrade --install hcl-devopsplan ./hcl-devopsplan-prod \
  -f hcl-devopsplan-prod/values-emissary.yaml \
  --namespace $NAMESPACE \
  --set global.imagePullSecrets={hcl-entitlement-key} \
  --set global.certSecretName=ingress \
  --set global.domain=$DOMAIN \
  --set global.persistence.rwoStorageClass=<Your storage class name> \
  --set replicaCount=<Number_of_replica>
```

> Note:
> - Ensure imagePullSecrets are formatted with braces: `{hcl-entitlement-key}`
> - If using external Keycloak, replace `-f values-emissary.yaml` with `--set ingress.type=mapping`

---

### **Step 4: Verify the Installation**

```bash
kubectl get mapping -n $NAMESPACE
helm status hcl-devopsplan -n $NAMESPACE
```

Access URLs:

```bash
echo "https://hcl-devopsplan-keycloak.${DOMAIN}"
echo "https://hcl-devopsplan.${DOMAIN}"
```

---

## **Install DevOps Plan with DevOps Control**

DevOps Control offers Git hosting and collaboration features based on Gitea.

### **Steps**

1. Install DevOps Plan with Emissary (see above).
2. Enable DevOps Control via Helm:

```bash
--set control.enabled=true
```

3. Verify:

```bash
helm status hcl-devopsplan -n $NAMESPACE
echo "https://devopsplan-control.$DOMAIN/control"
```

### **Using External Database for Control**

```bash
--set control.postgresql.host=<CONTROL_DATABASE_SERVER_NAME> \
--set control.postgresql.dbName=<CONTROL_DATABASE_NAME> \
--set control.postgresql.username=<CONTROL_DATABASE_USERNAME> \
--set control.postgresql.password=<CONTROL_DATABASE_PASSWORD>
```

> 📧 SMTP support is optional. Refer to **External DB and Email** section.

---

## **AI Assistant Integration with Llama (Open-Source LLMs)**

Use [Ollama](https://ollama.com/) to run LLaMA models in DevOps Plan.

Supported models: `LLaMA 2`, `LLaMA 3`, `Mistral`, `Gemma`, `Code LLaMA`, and more.

### **Example Helm Values**

```yaml
llama:
  models:
    - name: <Model_Name>
  run:
    - name: <Model_Name>
```

### **API Call Example**

```bash
Llama_URL=http://{{ .Release.Name }}-llama:11434
curl -k -s ${Llama_URL}/api/generate -d '{
  "model": "<Model_Name>",
  "prompt": "<Your_Message>",
  "stream": false
}'
```

### **Enable via Helm**

```bash
--set llama.enabled=true
```

### **Verify Installation**

```bash
helm status hcl-devopsplan -n $NAMESPACE
kubectl exec -it <devopsplan_pod_name> -- curl -ks ${Llama_URL}
# Expected: Ollama is running
```

---

## **Certificates: Self-Signed and Private CAs**
Self-signed certificates and private Certificate Authorities (CAs) are essential for enabling TLS/SSL encryption and establishing mutual trust between services—especially within internal environments.

### **Create a Certificate**
You can create a valid certificate using either a self-signed certificate or a private CA. The example below shows how to generate a private key (key.pem) and a certificate (cert.pem) for your domain using OpenSSL:

```bash
DOMAIN=<Your_External_IP_Address>.nip.io

openssl genrsa -out key.pem 2048
openssl req -new -x509 -key key.pem -out cert.pem -days 365 \
  -subj "/CN=$DOMAIN" \
  -addext "subjectAltName = DNS:${DOMAIN},DNS:*.${DOMAIN}" \
  -addext "certificatePolicies = 1.2.3.4"
```

### **Use Self-Signed Cert**

1. Create a TLS secret.

```bash
kubectl create secret generic my-tls-secret \
  --from-file=tls.crt=./cert.pem \
  --from-file=tls.key=./key.pem \
  --from-file=ca.crt=./cert.pem \
  --namespace devopsplan
```

2. Set TLS secret name in Helm.

```bash
--set global.certSecretName=my-tls-secret
```

### **Use Private CA Bundle**

1. Create a private CA bundle secret.

```bash
kubectl create secret generic my-internal-ca-bundle \
  --from-file=ca.crt=./cert.pem \
  --namespace devopsplan
```

2. Set the private CA secret Name in Helm.

```bash
--set global.privateCaBundleSecretName=my-internal-ca-bundle
```

---

## **Install SSL Certificate in DevOpsPlan Container**

1. Create the keystore directory and add your `keystore.p12`:

```bash
mkdir /path/to/your/keystore
```

2. Create ConfigMap:

```bash
kubectl create cm keystore-file \
  --from-file=/path/to/your/keystore/keystore.p12 \
  --namespace <namespace_name>
```

3. Verify:

```bash
kubectl get cm keystore-file -o yaml --namespace <namespace_name>
```

4. Create `ssl.yaml`:

```yaml
ssl:
  enabled: true
  password: ""
  keyAlias: 1
  configMapName: keystore-file
```

5. Add to Helm command:

```bash
-f ssl.yaml
```

---

## Backup and Restore Kubernetes Cluster and PVC Using Velero, MinIO and AWS S3 Bucket

This guide explains how to configure and use **Velero** with **MinIO** and **AWS S3** to back up and restore a Kubernetes cluster, including **Persistent Volume Claims (PVCs)**.

You can set up backup and restore using one of the following methods:

1. **Velero with MinIO**  
   Velero is deployed on Kubernetes with **MinIO** providing S3-compatible object storage.  
   Please follow the **next section** for installation and configuration details.

2. **Velero with AWS S3**  
   Velero is deployed on Kubernetes using **AWS S3** as the backup storage backend.  
   Please follow the instructions in the **`backup-restore.md`** file to complete the **prerequisites and installation**.

## **Velero** on Kubernetes using **MinIO** provides S3-compatible storage.

### Install Backup and Restore Helm Chart
**Steps 1.** Download hcl-devopsplan-prod chart from devops-plan repository and unpack it in local directory

  ```bash
  helm pull oci://hclcr.io/devops-plan/hcl-devopsplan-prod --untar
  ```

**Step 2.** Create a namespace called backup.

  ```bash
  Kubectl create namespace backup
  ```

**Step 3.** Create a Docker registry secret for pulling images from HCL Harbor into the namespace backup.

```bash
kubectl create secret docker-registry hcl-entitlement-key \
  --docker-server=hclcr.io \
  --docker-username=<Your Username> \
  --docker-password=<Your CLI Secret> \
  --namespace=backup
```

**Step 4.** Install the Backup and Restore into namespace *backup* with the release name *backup*.

  ```bash
  helm install backup ./hcl-devopsplan-prod \
    -f hcl-devopsplan-prod/values-backup.yaml \
    --namespace backup \
    --set global.imagePullSecrets={hcl-entitlement-key}
  ```

 Note: When you are setting the global.imagePullSecrets, make sure to properly format it within curly braces.

 If your Kubernetes cluster does not have a default storage class set, you must explicitly specify the storage class when deploying:

    --set global.persistence.rwoStorageClass=<Your storage class name>

 Replace <your-storage-class-name> with the name of your desired storage class.

**Step 5.** Install the Velero client

    chmod +x  hcl-devopsplan-prod/files/backup.sh && hcl-devopsplan-prod/files/backup.sh backup

**Step 6.** Verify the Installation:

The BackupStorageLocation is ready to use when it has the phase Available. You can check the status with the following command:

    velero backup-location get -n backup

 Run **helm status backup -n backup**  to retrieve the URL, username and password for the MinIO Object Store to check list of the bucket of your backup.

### Backup and Restore Instructions for DevOps Plan

This section outlines the steps to backup and restore the DevOps Plan resources and persistent volumes deployed in the **devopsplan** namespace with the release name **hcl-devopsplan**.

**Step 1.** Annotate Pods for Backups

  - Run the following script. When prompted, enter the namespace as **devopsplan**.  This script annotate all pods in **devopsplan** namespace with their volume names for Velero backup:

    ```yaml
    read -p "Enter namespace: " ns; \
    kubectl get pods -n "$ns" -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | \
    while read pod; do \
      vols=$(kubectl get pod "$pod" -n "$ns" -o jsonpath='{.spec.volumes[*].name}' | tr ' ' ','); \
      echo "Annotating $pod with volumes: $vols"; \
      kubectl annotate pod "$pod" -n "$ns" backup.velero.io/backup-volumes="$vols" --overwrite; \
    done
    ```

    Note: Failing to annotate pods will result in persistent volume claim (PVC) data not being backed up or restored when using storage classes that do not support CSI snapshots.

**Step 2.** Create a backup

  ```yaml
    velero backup create <Backup_Name> --include-namespaces devopsplan -n backup
  ```

Replace <Backup_Name> with a name of your choice for the backup.

**Step 3.** Verify the Backup

  ```yaml
    velero backup get -n backup
  ```

**Restore**

To restore the DevOps Plan resources and persistent volumes from the previously created backup:

  ```yaml
    velero restore create --from-backup <Backup_Name> -n backup
  ```

Replace <Backup_Name> with a name of your choice for the backup.

### Additional reference guide for managing backups and restores

This section provides quick reference guide for managing backups and restores in Kubernetes using Velero

```yaml
1. Create Backup of a Namespace

velero backup create <Backup_Name> --include-namespaces <Namespace> -n backup
velero backup get -n backup

    What it does: Creates a backup of all resources inside the specified namespace.
    When to use: To save the current state of all resources (pods, services, etc.) in a namespace.
    velero backup get lists all backups.

2. Restore Backup to the Same Namespace

velero restore create --from-backup <Backup_Name> -n backup
velero restore get -n backup

    What it does: Restores the backup to the original namespace.
    When to use: Recover or duplicate resources in the same namespace.
    velero restore get lists all restore jobs and their status.
    
Note : We are not supporting namespace mapping for Plan Application.

3. Backup All Cluster-Level Resources

velero backup create <Backup_Name> --include-cluster-resources=true -n backup
velero backup get -n backup

    What it does: Backs up cluster-wide resources like CRDs, roles, storage classes.
    When to use: To create a full backup of your Kubernetes cluster state.

4. Backup Only Specific Cluster Resources

velero backup create full-backup --include-resources='customresourcedefinitions,clusterroles,clusterrolebindings,namespaces,persistentvolumes,persistentvolumeclaims,storageclasses,mutatingwebhookconfigurations,validatingwebhookconfigurations' --include-cluster-resources=true -n backup
velero backup get -n backup

    What it does: Backs up only selected critical cluster-wide resources.
    When to use: When you want to back up just important cluster components.

5. Backup PersistentVolumeClaims (PVCs) Across Namespace

velero backup create <Backup_Name> --include-resources persistentvolumeclaims,persistentvolumes --include-namespaces <Namespace> -n backup
velero backup get -n backup

    What it does: Backs up PVCs in namespace.
    When to use: To protect storage claims separately from pods or other resources.

6. Backup PersistentVolumes (PVs) and PVCs Cluster-wide

velero backup create <Backup_Name> --include-resources=persistentvolumeclaims,persistentvolumes --include-namespaces '*' --include-cluster-resources=true -n backup
velero backup get -n backup

    What it does: Backs up both PVs and PVCs for the entire cluster.
    When to use: To have a full backup of storage resources.

7. Backup Namespace Without Pods

velero backup create <Backup_Name> --include-namespaces <Namespace> --exclude-resources pods -n backup

    What it does: Backs up everything except pods in the namespace.
    When to use: Pods are often recreated automatically; this saves space and time.

8. Create Backup with Expiration Time (TTL)

velero backup create <Backup_Name> --include-namespaces <Namespace> --ttl 90d -n backup
velero backup get -n backup

    What it does: Creates a backup that expires automatically after 90 days.
    When to use: To manage storage by keeping backups only for a limited time.

9. View Details of a Backup

velero backup describe <Backup_Name> --details -n backup

    What it does: Shows detailed info about what resources were backed up.
    When to use: To verify the contents of your backup.

10. View Logs for a Backup

velero backup logs <Backup_Name> -n backup

    What it does: Displays logs generated during backup creation.
    When to use: Troubleshoot backup failures or issues.

11. Schedule Backups Every Minute

velero schedule create <Schedule_Name> --schedule="*/1 * * * *" --include-namespaces <Namespace> -n backup
velero schedule get -n backup

    What it does: Creates an automatic backup schedule running every minute.
    velero schedule get lists all scheduled backups.
    When to use: For very frequent backups during testing or for critical workloads.

12. Delete Scheduled Backups

velero schedule delete <Schedule_Name> -n backup

13. Delete Backups

velero delete <Backup_Name> -n backup

 Note:
 If your application has been upgraded and you want to restore it to an older version from a Velero backup, use the --existing-resource-policy update flag. This ensures existing resources are updated to match the backup, even if they already exist.

    velero restore create --from-backup <backup_name> --existing-resource-policy update

```
### Uninstall Backup and Restore Helm Chart

To uninstall/delete the backup and restore Helm chart.

  ```bash
  helm delete backup -n backup
  kubectl delete ns backup
  ```

### Limitation:

Velero does not back up or restore hostPath volumes directly. If your Kubernetes setup uses hostPath volumes, you won't be able to use Velero's backup and restore functionality for those volumes.

### Additional Configuration:

If the cluster is running slowly, you may need to adjust the Velero resource limits as well as the default liveness and readiness probe parameters to ensure that backup and restore operations work properly.

| **Parameter**                                         | **Description**                                                                 | **Default** |
| ----------------------------------------------------- | ------------------------------------------------------------------------------- | ----------- |
| `velero.nodeAgent.resources.requests.memory`          | Memory requests                                                                 | `128Mi`     |
| `velero.nodeAgent.resources.limits.memory`            | Memory limits                                                                   | `512Mi`     |
| `velero.nodeAgent.resources.requests.cpu`             | CPU requests                                                                    | `500m`      |
| `velero.nodeAgent.resources.limits.cpu`               | CPU limits                                                                      | `1000m`     |
| `velero.nodeAgent.livenessProbe.initialDelaySeconds`  | LivenessProbe initialDelaySeconds                                               | `10`        |
| `velero.nodeAgent.livenessProbe.periodSeconds`        | LivenessProbe periodSeconds                                                     | `30`        |
| `velero.nodeAgent.livenessProbe.timeoutSeconds=10`    | LivenessProbe timeoutSeconds                                                    | `5`         |
| `velero.nodeAgent.livenessProbe.failureThreshold`     | LivenessProbe failureThreshold                                                  | `5`         |
| `velero.nodeAgent.readinessProbe.initialDelaySeconds` | ReadinessProbe initialDelaySeconds                                              | `10`        |
| `velero.nodeAgent.readinessProbe.periodSeconds`       | ReadinessProbe periodSeconds                                                    | `30`        |
| `velero.nodeAgent.readinessProbe.timeoutSeconds`      | ReadinessProbe timeoutSeconds                                                   | `5`         |
| `velero.nodeAgent.readinessProbe.failureThreshold`    | ReadinessProbe failureThreshold                                                 | `5`         |

## Devops Plan Scaling
You can manually scale the number of DevOps Plan Server, Analytics, and Search instances by updating the replicaCount values in your configuration:

  ```bash
  ## DevOps Plan Server
  ccm:
    replicaCount:

  ## Analytics
  analytics:
    replicaCount: 
    
  ## Search
  search:
    replicaCount:
  ```

## Horizontal Pod Autoscaler (HPA)
DevOps Plan supports Horizontal Pod Autoscaler (HPA) for the Server, Analytics, and Search pods.

By default, HPA is disabled for all components. You can enable it by setting the autoscaling.enabled flag:

```bash
  ## DevOps Plan Server
  ccm:
    autoscaling:
      enabled: true

  ## Analytics
  analytics:
    autoscaling:
      enabled: true 

  ## Search
  search:
    autoscaling:
      enabled: true
  ```

### HPA Coonfiguration
The following parameters can be customized for each component.

**Common Parameters**

| **Parameter**                                     | **Description**                                                                 | **Default** |
| ------------------------------------------------- | ------------------------------------------------------------------------------- | ----------- |
| `*.autoscaling.enabled`                           | Enables or disables HPA for the component                                       | `false`     |
| `*.autoscaling.minReplicas`                       | Minimum number of pod replicas maintained at all times                          | `1`         |
| `*.autoscaling.maxReplicas`                       | Maximum number of pod replicas allowed                                          | `3`         |
| `*.autoscaling.targetCPUUtilizationPercentage`    | Desired average CPU utilization across pods (percentage of requested CPU)       | `80`        |
| `*.autoscaling.targetMemoryUtilizationPercentage` | Desired average memory utilization across pods (percentage of requested memory) | `80`        |

**Component-Specific Examples**

| **Component**      | **Config Path**           | **Notes**                                     |
| ------------------ | ------------------------- | --------------------------------------------- |
| DevOps Plan Server | `ccm.autoscaling.*`       | Controls autoscaling of core DevOps Plan pods |
| Analytics          | `analytics.autoscaling.*` | Controls autoscaling of Analytics pods        |
| Search             | `search.autoscaling.*`    | Controls autoscaling of Search pods           |


---

## Update OpenSearch and OpenSearch Dashboards Password

By default, OpenSearch and OpenSearch Dashboards use the username admin. To change the default username and password, you can update the values.yaml file or use the --set flags during Helm installation.

- Option 1: Modify values.yaml

  ```bash
  opensearch:
    username: <USERNAME>
    password: <PASSWORD>
  ```

- Option 2: Use --set flags with Helm

  ```bash
  --set opensearch.username=<USERNAME>
  --set opensearch.password=<PASSWORD>
  ```

---

## Settings Feedback Email Address
To set email address for the feedback, the admin requires to set feedback.to.emailaddress and feedback.from.emailaddress during the Helm install/upgrade.
  ```bash
  feedback:
    toEmailaddress: <TO_EMAIL_ADDRESS>
    fromEmailaddress: <FROM_EMAIL_ADDRESS>
  ```

---

## Rolling upgrade release

You can upgrade DevOps Plan to the newest release using the helm upgrade command.

- Use Helm to install the DevOps Plan chart as described in section **Installing the Chart**.

- If you're using an external Keycloak (i.e., one that’s already deployed outside of the Helm chart), you need to disable the internal Keycloak service. You do that by setting the following in your values.yaml or via the --set flag during installation:

- Option 1: Modify values.yaml
  ```bash
  keycloaksrv:
    enabled: false
  ```

- Option 2: Use --set flags with Helm
  ```bash
  --set keycloaksrv.enabled=false
  ```

- If you already installed with the internal PostgreSQL database, and you plan to upgrade with the latest release version without deleting the PostgreSQL PVC, then you need to get the existing password before uninstall/upgrade and set it during *helm upgrade --install*. Get the password for the internal PostgreSQL database by checking the console output of the *helm status <release_name> -n <namespace_name>* command and execute the *kubectl get secret ...* command under the PostgreSQL.

  This is an example of the **kubectl get secret ...** command when namespace is set to *devopsplan* and PostgreSQL secret name is hcl-devopsplan-postgresql:

    ```bash
    export POSTGRES_PASSWORD=$(kubectl get secret --namespace devopsplan hcl-devopsplan-postgresql -o jsonpath="{.data.tenant-datastore-password}" | base64 -d)
    ```

  Set the password during the helm upgrade --install:
    ```bash
    --set postgresql.existingPassword=$POSTGRES_PASSWORD
    ```

- If you already installed with the internal Keycloak, and you plan to upgrade with the latest release version without deleting the Keycloak PVC, then you need to get the existing password before uninstall/upgrade and set it during *helm upgrade --install*. Get the password for internal Keycloak by checking the console output of the *helm status <release_name> -n <namespace_name>* command and execute the **kubectl get secret ...** command under the Keycloak section.

  This is an example of the **kubectl get secret ...** command when namespace is set to *devopsplan* and Keycloak secret name is hcl-devopsplan-keycloak:
    ```bash
    export KEYCLOAK_PASSWORD=$(kubectl get secret --namespace devopsplan hcl-devopsplan-keycloak -o jsonpath="{.data.keycloak-password}" | base64 -d)
    ```
   Set the password during the helm upgrade --install:
    ```bash
    --set keycloak.existingPassword=$KEYCLOAK_PASSWORD
    ```

---

## Rolling rollback release
You can rollback to the previous release using *helm rollback* command.

**Before you begin**

1. Use Helm to install the chart as described in section **Installing the Chart**.
2. Use Helm to upgrade the chart to the new release as described in section **Rolling upgrade release**.

**Important: Rollback Limitation (Starting from v3.0.7)**

Beginning with DevOps **Plan v3.0.7**, the bundled OpenSearch and OpenSearch Dashboards versions were upgraded.

During this upgrade, OpenSearch creates or migrates internal indices using a newer index format that is not backward compatible with earlier OpenSearch versions.

As a result:

  - **Rollback from DevOps Plan v3.0.7 to any previous release (e.g., v3.0.6) is not supported.**
  - Attempting to roll back may cause OpenSearch to fail to start due to incompatible index formats.

**Recommended Actions**

Before upgrading to **DevOps Plan v3.0.7** or later, ensure a backup is created.

DevOps Plan supports **Backup and Restore using Velero**. If a downgrade to a previous release (such as **v3.0.6**) is required, you must restore the cluster state from a backup that was taken **before the upgrade**.

**Recommended workflow:**

1. Create a backup of the DevOps Plan environment using Velero before performing the upgrade.

2. Proceed with the upgrade to **v3.0.7 or later**.

3. If you need to revert to a previous release:

    - Roll back the application version.
    - Restore the cluster resources and persistent volumes from the **Velero backup taken prior to the upgrade**.

⚠️ Downgrading without restoring from a pre-upgrade backup may cause OpenSearch to fail to start due to incompatible index formats.

**Procedure:**
1. Run *helm history* command to see revision numbers of your helm chart release. You should have min two revision numbers. revision 1 for install and revision 2 for the upgrade that you execute in **Before you begin** section. Example below shows you have a helm chart release name *hcl-devopsplan1* with revision 1 installed the helm chart *hcl-devopsplan1-3.0.7* for release 3.0.7 and revision 2 upgraded the helm chart *hcl-devopsplan2-3.0.8* to release 3.0.8.

  ```bash
  $ helm history hcl-devopsplan1 --namespace dev
  REVISION        UPDATED                         STATUS          CHART           APP VERSION     DESCRIPTION
  1               Thu Nov 20 21:58:13 2024        superseded      hcl-devopsplan1-3.0.7          Install complete
  2               Thu Nov 20 22:13:56 2024        deployed        hcl-devopsplan2-3.0.8          Upgrade complete
  ```

2. Rollback helm chart using *helm rollback* command. Example below will rollback helm chart release *hcl-devopsplan1* from revision 2 to revision 1.

  ```bash
  $ helm rollback hcl-devopsplan --namespace dev
  Rollback was a success! Happy Helming!
  ```

3. Run *helm history RELEASE* command again to see the new revision 3 has been created after rollback, and it rollback to revision 1 the helm chart release *hcl-devopsplan1*. 

  ```bash
  $ helm history hcl-devopsplan1 --namespace dev
  REVISION        UPDATED                         STATUS          CHART           APP VERSION     DESCRIPTION
  1               Thu Nov 20 21:58:13 2024        superseded      hcl-devopsplan1-3.0.7          Install complete
  2               Thu Nov 20 22:13:56 2024        deployed        hcl-devopsplan2-3.0.8          Upgrade complete
  3               Thu Nov 20 22:30:32 2024        deployed        hcl-devopsplan1-3.0.7          Rollback to 1
  ```

---

## **Configuration**

### Parameters
The Helm chart has the following values that can be overridden using the --set parameter or specified via -f my_values.yaml.

### Common Parameters

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **global.imagePullSecrets** | Array of docker-registry secret to pull images from the imageRegistry. | "" |
| **global.imageRegistry** | Docker image registry. | hclcr.io |
| **global.passwordSeed** | The seed used to generate all passwords. | "" |
| **global.certSecretName** | Optionally used to terminate TLS and when ingress.cert.selfSigned, is used to verify trust of loopback connections.. | "" |
| **global.privateCaBundleSecretName** | Name of secret containing ca.crt, which lists certificates to trust (in PEM format). | "" |
| **global.persistence.rwoStorageClass** | StorageClassName with ReadWriteOnece access mode | "" |
| **global.persistence.rwxStorageClass** | StorageClassName with ReadWriteMany access mode | "" |
| **replicaCount** | Number of replicas to deploy instances of DevOps Plan service. | 1 |
| **image.repository** | DevOps Plan docker Image repository path. | devopsplan |
| **image.tag** | DevOps Plan Image tag. | 3.0.8.1 |
| **image.pullPolicy** | DevOps Plan image pull policy.Accepted values are:<br>- *IfNotPresent*<br>- *Always* | Always |
| **hostname** | DevOps Plan Docker Container hostname. | devopsplan |
| **timeZone** | DevOps Plan server Time Zone. It can be set based on a list of supported time zones and abbreviations.| EST5EDT |
| **serverQualifiedUrlPath** | If defined, it overrides the mapping URL in DevOps Plan server application.properties file.<br>Example: "https://[MAPPING_NAME>.com" | "" |
| **service.type** | Service type. It can be set to ClusterIP, LoadBalancer or NodePort | ClusterIP |
| **service.exposePort** | Service expose port  | 30102 |
| **ingress.enabled** | Ingress service. Accepted values are:<br> - *true* to enable the ingress service.<br> - *false* to disable the ingress service.| true |
| **ingress.type** | Ingress service type.. Accepted values are: nginx, route, mapping| nginx |
| **hosts** | List of hosts for the ingress. | devopsplan.hcl.com |
| **swagger.enabled** | This parameter enables or disables Swagger UI visibility. Accepted values are:<br>- *true* to enable Swagger UI visibility.<br>- *false* to disable Swagger UI visibility. | false |
| **auth.jwt.refreshTokenValiditySeconds** | Duration for which a JWT refresh token remains valid, in seconds. | `86400` (1 day) |

### Parameters for creating TeamSpace and Applications
The PostgreSQL database requires creating TeamSpace and Applications. The helm chart is installed with the internal PostgreSQL database by default. If you plan to install/upgrade the helm charts with an external database, then you need to set the *postgresql.enabled* to *false* and set the *spring.datastore* and *tenant.datastore* configuration settings based on your external database parameters. PostgreSQL database is supported for release 3.0.8.

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **spring.datastore.url** | postgresql JDBC URL with format *jdbc:postgresql://<host_address>:<port_number>/<database_name>.* | jdbc:postgresql://devopsplan-postgresql:5432/postgres |
| **spring.datastore.username** | postgresql database username | postgres |
| **spring.datastore.password** | postgresql database password | See values.yaml |
| **tenant.datastore.vendor** | Tenant database vendor. The current supported database is PostgreSQL. * | PostgreSQL |
| **tenant.datastore.server** | Tenant database server | devopsplan-postgresql |
| **tenant.datastore.dbname** | Tenant database name | postgres |
| **tenant.datastore.username** | Tenant database username | postgres |
| **tenant.datastore.password** | Tenant database password | See values.yaml |
| **tenant.registration.code** | Tenant generate registration codes. Accepted values are:<br>- *NONE* no verification needed. Any verification code is ignored.<br>- *PROVIDED* the code supplied by the registration API call .<br>- *GENERATED* the server generates a random code (default 6 alphanumeric characters). | NONE |

### SMTP Server Parameters

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **global.platform.smtp.host** | SMTP server host  | "" |
| **global.platform.smtp.port** | SMTP server port number | "" |
| **global.platform.smtp.username** | SMTP server username | "" |
| **global.platform.smtp.password** | SMTP server password | "" |
| **global.platform.smtp.sender** | The SMTP sender email address has to delivered from on-boarding process | "" |
| **global.platform.smtp.startTLS** | This parameter sets the mail server to secure protocol using TLS or SSL. Accepted values are:<br>- *true* to set secure protocol using TLS or SSL.<br>- *false* to set unsecure protocol | false |
| **global.platform.smtp.smtps** | This parameter sets the mail server protocol. Accepted values are:<br>- *true* to set smtps protocol.<br>- *false* to set smtp protocol. | false |

### Analytics Parameters
The helm chart installs the Analytics feature on a separate pod by default. you can disabled/enabled the Analytics feature service by setting *analytics.service* to *false/true*. 

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **analytics.service** | This parameter enables or disables Analytics service. Accepted values are:<br>- *true* to enable Analytics service.<br>- *false* to disable Analytics service.<br>This parameter is needed if you plan to use Analytics features for the DevOps Plan. | true |
| **analytics.type** | Analytics service type  | LoadBalancer |
| **analytics.exposePort** | Analytics service port  | "" |
| **analytics.urlMapping** | URL mapping. <br>- The mapping URL format should be *https:<mapping-name>.com*.  | "" |
| **analytics.replicaCount** | Number of replica Analytics Pods. This parameter is needed if analytics.service *=true.* | 1 |
| **analytics.image.repository** | Analytics docker Image repository path. This parameter is needed if analytics.service *=true.* | devopsplan-analytics |
| **analytics.image.tag** | Analytics Image tag. This parameter is needed if *analytics.service=true.* | 3.0.8.1 |
| **analytics.image.pullPolicy** | Analytics image pull policy. This parameter is needed if *analytics.service=true*. Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent | 
| **analytics.hostname** | Analytics hostname | analytics |

### PostgreSQL Database Parameters
The helm chart is installed with the internal postgresql database by default.

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **postgresql.enabled** | This parameter enables or disables devopsplan-postgresql database service. Accepted values are:<br>- *true* to enable postgresql database service.<br>- *false* to disable postgresql database service. | true |
| **postgresql.repository** | Postgresql database docker Image repository path. This parameter is needed if *postgresql.enabled=true.* | devopsplan-postgresql |
| **postgresql.tag** | Postgresql database Image tag. This parameter is needed if *postgresql.enabled=true.* | 3.0.8 |
| **postgresql.pullPolicy** | Postgresql database image pull policy. This parameter is needed if *postgresql.enabled=true*Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent |
 **postgresql.service.type** | postgresql service type  | LoadBalancer |
| **postgresql.service.exposePort** | postgresql service port  | "" |
| **postgresql.existingPassword** | postgresql existing password. It is needed if you uninstall and install the devopsplan without deleting the PostgreSQL PVC, then you need to set *postgresql.existingPassword* to the existing password before uninstalling. | "" |

### Dashboard Parameters
The dashboards analytics configuration setting options set by default for dashboard properties using Nginx, Opensearch and Opensearch-dashboards in Helm chart. It is strongly recommended to not modify the default values as shown in the below table. 

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **analyticsUserName** | Analytics UserName| SYSTEM_ANALYTICS1 |
| **analyticsBootstrapData** | Set number of the days of analytics data | 90 |
| **nginx.service** | This parameter enables or disables Nginx service. Accepted values are:<br>- *true* to enable Nginx service.<br>- *false* to disable Nginx service.<br>This parameter is needed if you plan to use Dashboard features for the Business Analytics. | true |
| **nginx.type** | Nginx service type  | LoadBalancer |
| **nginx.exposePort** | Nginx service port  | "" |
| **nginx.urlMapping** | URL mapping. <br>- The mapping URL format should be *https:<mapping-name>.com*.  | "" |
| **nginx.replicaCount** | Number of replica nginx Pods. This parameter is needed if nginx.service *=true.* | 1 |
| **nginx.image.repository** | Nginx docker Image repository path. This parameter is needed if nginx.service *=true.* | devopsplan-nginx |
| **nginx.image.tag** | Nginx Image tag. This parameter is needed if *nginx.service=true.* | 3.0.8 |
| **nginx.image.pullPolicy** | Nginx image pull policy. This parameter is needed if *nginx.service=true*. Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent | 
| **nginx.hostname** | Nginx hostname | nginx |
| **dashboards.service** | This parameter enables or disables dashboards service. Accepted values are:<br>- *true* to enable Nginx service.<br>- *false* to disable dashboards service.<br>This parameter is needed if you plan to use Dashboard features for Business Analytics. | true |
| **dashboards.replicaCount** | Number of replica dashboards Pods. This parameter is needed if dashboards.service *=true.* | 1 |
| **dashboards.image.repository** | Opensearch-dashboards docker Image repository path. This parameter is needed if dashboards.service *=true.* | devopsplan-dashboards |
| **dashboards.image.tag** | Opensearch-dashboards Image tag. This parameter is needed if *dashboards.service=true.* | 3.0.8 |
| **dashboards.image.pullPolicy** | Opensearch-dashboards image pull policy. This parameter is needed if *dashboards.service=true*. Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent | 
| **dashboards.hostname** | Dashboards hostname | dashboards |
| **dashboards.username** | Opensearch Dashboards username | "admin" |
| **dashboards.password** | Opensearch Dashboards password | "admin" |
| **logstash.service** | This parameter enables or disables devopsplan-logstash service. Accepted values are:<br>- *true* to enable Nginx service.<br>- *false* to disable devopsplan-logstash service.<br>This parameter is needed if you plan to use Dashboard features for Business Analytics. | true |
| **logstash.replicaCount** | Number of replica devopsplan-logstash pods. This parameter is needed if logstash.service *=true.* | 1 |
| **logstash.image.repository** | logstash docker Image repository path. This parameter is needed if logstash.service *=true.* | devopsplan-logstash |
| **logstash.image.tag** | devopsplan-logstash Image tag. This parameter is needed if *logstas.service=true.* | 3.0.8 |
| **logstash.image.pullPolicy** | Opensearch-logstash image pull policy. This parameter is needed if *logstas.service=true*. Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent | 
| **logstash.port** | logstash port | 5011 |
| **logstash.username** | logstash username | "logstash" |
| **logstash.password** | logstash password | "logstash" |
| **opensearch.service** | This parameter enables or disables opensearch service. Accepted values are:<br>- *true* to enable Nginx service.<br>- *false* to disable opensearch service.<br>This parameter is needed if you plan to use Dashboard features for Business Analytics. | true |
| **opensearch.replicaCount** | Number of replica opensearch pods. This parameter is needed if opensearch.service *=true.* | 1 |
| **opensearch.image.repository** | Opensearch docker Image repository path. This parameter is needed if opensearch.service *=true.* | devopsplan-opensearch |
| **opensearch.image.tag** | Opensearch Image tag. This parameter is needed if *opensearch.service=true.* | 3.0.8 |
| **opensearch.image.pullPolicy** | Opensearch image pull policy. This parameter is needed if *opensearch.service=true*. Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent | 
| **opensearch.hostname** | Opensearch hostname | opensearch |
| **opensearch.hash** | Opensearch password hash | "" |
| **opensearch.discoveryType** | Eleasticsearch discoveryType  | single-node |

### Single-Sign-On (Keycloak) functionality Parameters
Single-Sign-On functionality by default is set to disable. If the admin plans to enable the Single-Sign-On functionality, then it needs to modify the default values as shown in the below table. Refer to [Enabling the DevOps Plan Keycloak Single Sign On feature]() for more information.

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **keycloak.enabled** | This parameter enables or disables Single-Sign-On (Keycloak)  service. Accepted values are:<br>- *true* to enable Single-Sign-On service.<br>- *false* to disable Single-Sign-On service.<br>This parameter is needed if you plan to use Single-Sign-On feature. | false |
| **keycloak.service.enabled** | This parameter enables or disables Keycloak service in Helm Chart for Single-Sign-On service. Accepted values are:<br>- *true* to enable Keycloak service.<br>- *false* to disable Keycloak service.<br>This parameter is needed if you plan to use Single-Sign-On feature and deploy Keycloak with Helm chart. | false |
| **keycloak.service.ipAddress** | Cluster IP address or Hostname. | "" |
| **keycloak.service.clientName  | The ccn-client Id. | "ccm-client" |
| **keycloak.username** | Keycloak Administration Console username. | admin |
| **keycloak.password** | Keycloak Administration Console password. | admin |
| **keycloak.realmName** | The Realm name. | "CCM" |
| **keycloak.dashboardsClientID** | The dashboards-client Id. | "dashboards-client" |
| **keycloak.dashboardsClientSecret** | The secret for the dashboards-client. | "58846041-eb1e-46d8-bac4-b2ba541ff491" |
| **keycloak.urlMapping** | Keycloak URL | "" |
| **keycloak.jsonFile.enabled** | Enable installing keycloak.json file to the DevOps Plan servers /config folder.  Accepted values are:<br>- *true* to enable installing keycloak.json file <br>- *false* to disable installing keycloak.json file. | false |
| **keycloak.jsonFile.configMapName** | This is the configMap file name that contains the keycloak.json file. This parameter is needed if keycloak.jsonFile.enabled *=true.* | keycloak-json |
| **keycloaksrv.enabled** | This parameter enables or disables Keycloak service in Helm Chart for Single-Sign-On service. Accepted values are:<br>- *true* to enable Keycloak service.<br>- *false* to disable Keycloak service.<br>This parameter is needed if you plan to use Single-Sign-On feature and deploy Keycloak with Helm chart. | false |
| **keycloaksrv.image.repository** | keycloak docker Image repository path. | devopsplan-keycloak |
| **keycloaksrv.image.tag** | Keycloak Image tag. | 3.0.8 |
| **keycloaksrv.image.pullPolicy** | Keycloak image pull policy. Accepted values are:<br>- *IfNotPresent*<br>- *Always* | IfNotPresent |
| **keycloaksrv.service.type** | Specify the nodePort values for the LoadBalancer and NodePort service types. | LoadBalancer |
| **keycloaksrv.service.nodePorts.http** | Keycloak service HTTP port. | 30107 |
| **keycloaksrv.service.nodePorts.https** | Keycloak service HTTPS port. | 30104 |
| **keycloaksrv.auth.adminUser** | Keycloak administrator user | admin |
| **keycloaksrv.auth.adminPassword** | Keycloak administrator password for the new user | "" |
| **keycloaksrv.postgresql.auth.postgresPassword** | Password for the "postgres" admin user. | "" |
| **keycloaksrv.postgresql.auth.password** | Password for the non-root username for Keycloak | "" |
| **keycloaksrv.keycloakConfigCli.backoffLimit** | Specifies the number of retries before considering the Job as failed | 1 |


### SSL Parameters
You need to set the ssl parameters  in order to install SSL certificates.

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **ssl.enabled** | Enable installing SSL certificate.Accepted values are:<br>- *true* to enable installing SSL certificate <br>- *false* to disable installing SSL certificate. | false |
| **ssl.password** | Keystore password. This parameter is needed if ssl.enabled *=true.* | "" |
| **ssl.keyAlias** | keystore alias. | 1 |
| **ssl.configMapName** | This is the configMap file name that contains the SSL certificate keystore.p12 file.This parameter is needed if ssl.enabled *=true.* | keystore-file |

### Startup, Liveness and Readiness Parameters

See the values.yaml file for the Startup, Liveness and Readiness parameters

 

### Persistence Volumes Parameters
The helm chart set to enable by default the persistent volumes (PVs) and persistent volumes claims (PVCs) for following mounted pods:

  - hcl-devopsplan pod: data, config, share and logs folders
  - hcl-devopsplan-analytics pod: data, config, share and logs folders
  - hcl-devopsplan-postgresql pod: data folder
  - hcl-devopsplan-opensearch pod: data folder
  - hcl-devopsplan-keycloak pod: data folder

See the values.yaml file for the Persistence Volumes parameters.

### Storage Class Parameters

| **Parameter** | **Description** | **Default value** |
| --- | --- | --- |
| **persistence.storageClass** | If defined, It sets the global storageClassName. This parameter is needed if persistence.enabled =true and Storage Class will be used. | "" |
| **persistence.ccm.storageClass** | It sets the storageClassName for the hcl-devopsplan pods. This parameter is needed if the default storage class does not support the ReadWriteMany (RWX) accessMode. |  |
| **persistence.analytics.storageClass** | It sets the storageClassName for the devopsplan-analytics PVC. | "" |
| **persistence.postgresql.storageClass** | It sets the storageClassName for the devopsplan-postgresql PVC. | "" |
| **persistence.opensearch.storageClass** | It sets the storageClassName for the devopsplan-opensearch PVC. | "" |
| **persistence.keycloak.storageClass** | It sets the storageClassName for the devopsplan-keycloak PVC. | "" |


---

## Troubleshooting

### keycloak-config-cli Job Failure (Error Status)

The keycloak-config-cli Pod shows a status of Error, and the Job fails without applying the Keycloak configuration.

**Possible Cause**

The keycloak-config-cli Job may be starting before the Keycloak server is fully ready, resulting in a connection failure. Kubernetes will only retry the Job up to the number of times defined by backoffLimit. If the retry limit is too low, the Job may fail permanently before Keycloak becomes available. 

**Recommended Action: Increase backoffLimit**

By default, the backoffLimit set to 1. You can increase to 5:

- Option 1: Modify values.yaml

  ```bash
  keycloaksrv:
    keycloakConfigCli:
      backoffLimit: 5  # Try 5 retries instead of the default (usually 1)
  ```

- Option 2: Use --set flags with Helm

  ```bash
  --set keycloaksrv.keycloakConfigCli.backoffLimit=5
  ```

---

## **Additional Information**

<details><summary>Downloads and Useful Links</summary>
<p>

- [DevOps Plan](https://www.hcl-software.com/devops-plan)
- [HCL DevOps Plan Documentation](https://help.hcl-software.com/devops/plan/index.html)
- [Getting started with DevOps Plan Helm Chart](https://help.hcltechsw.com/devops/plan/3.0.0/oxy_ex-1/com.ibm.rational.clearquest.install_upgrade.doc/topics/t_deploy_helm_hcl.html)

</p>
</details>

<details><summary>Supported Environments</summary>
<p>

The helm chart was tested in Kubernetes environments:

  - K8s and K3s
  - [minikube](https://minikube.sigs.k8s.io/docs/start/)
  - [kubeadm](https://kubernetes.io/docs/reference/setup-tools/kubeadm/)
  - [Google Kubernetes Engine](https://cloud.google.com/kubernetes-engine)
  - [Azure Kubernetes Service](https://azure.microsoft.com/en-us/)
  - [Amazon Elastic Kubernetes Service](https://aws.amazon.com/eks/)

Supported Kubernetes Versions:

  - Kubernetes 1.16 and later

</p>
</details>
