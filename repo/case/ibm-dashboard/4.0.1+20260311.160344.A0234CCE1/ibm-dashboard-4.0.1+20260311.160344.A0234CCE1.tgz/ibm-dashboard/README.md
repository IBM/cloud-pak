# Name

IBM&reg; Cognos Dashboards

# Introduction

## Summary

IBM Cognos Dashboards allows you to build interactive visualizations to explore, analyze, and present your data.

## Features

IBM Cognos Dashboards provides a graphical canvas for a business user to investigate data for patterns and insights. The service includes a wide range of customizable visualization options to help you create interactive dashboards.
You don't need to understand coding or SQL to gain insights. To build a dashboard, drag data sources, visualizations, and widgets to the main canvas. You can also customize the appearance of the visualizations to make the data more visually appealing.

# Details

## Prerequisites
## Configuration
### Resources Required

Minimum scheduling capacity for workload sizes:

| Size          | CPU (cores) | Memory (GB) | Ephemeral Storage (GiB) | Nodes |
| ------------- | ----------- | ----------- | ----------------------- | ----- |
| Small(default)| 11          | 36          | 136                     | 1     |
| Medium        | 18          | 52          | 136                     | 1     |
| Large         | 47          | 97          | 136                     | 1     |

# Installing

* This chart is installed as part of the CP4D install

## Storage

* Supported storage classes: NFC, OCS, Portworx
* Dynamic PV created

## Limitations

* Cannot deploy more than once in the same namespace
* Cannot be installed as a standalone add-on

## SecurityContextConstraints Requirements
This chart requires a SecurityContextConstraint to be bound to the target namespace prior to installation. To meet this requirement there may be cluster scoped as well as namespace scoped pre and post actions that need to occur.

The predefined SecurityContextConstraints `restricted` has been verified for this chart, if your target namespace is bound to this SecurityContextConstraints resource you can proceed to install the chart.
    
The default platform restricted definition changes, below is the definition that was verified for this chart.

From the user interface, you can copy and paste the following snippets to enable the custom SecurityContextConstraints, The following security context constraint is the OCP 4.12 Restricted SCC.

Custom SecurityContextConstraints definition:
 ```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    include.release.openshift.io/ibm-cloud-managed: "true"
    include.release.openshift.io/self-managed-high-availability: "true"
    include.release.openshift.io/single-node-developer: "true"
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.
    release.openshift.io/create-only: "true"
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- ephemeral
- persistentVolumeClaim
- projected
- secret
 ```

## Documentation

More information about how to use IBM Cognos Dashboards can be found [here](https://www.ibm.com/docs/en/search/Cognos%20dashboard)
