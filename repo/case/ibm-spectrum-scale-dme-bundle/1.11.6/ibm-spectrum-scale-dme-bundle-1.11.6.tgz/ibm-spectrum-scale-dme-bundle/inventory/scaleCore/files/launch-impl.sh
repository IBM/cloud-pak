# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName=ibm-spectrum-scale-dme-case
inventory=scaleCore
setupInventory=scaleCoreSetup
caseCatalogName=
channelName=

# variables specific to catalog installation
catalogNamespace="openshift-marketplace"

# implement functions to install or uninstall products
# example

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --foo)
        echo "$val"
        ;;
    --bar)
        echo "do something"
        ;;
    esac
}

# cloudctl case launch --tls-skip-verify --case case/ibm-spectrum-scale-dme-bundle --namespace default --inventory scaleCoreSetup --action install --tolerance 1

install() {
    install_operator_native
}

uninstall() {
    uninstall_operator_native
}

install_operator_native() {
    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${setupInventory}/files/op-cli"
    local manifest_file="${op_cli_files}/ibm-spectrum-scale-operator.yaml"

    validate_file_exists "${manifest_file}"

    oc create -f ${manifest_file}
}

uninstall_operator_native() {
    local op_cli_files="${casePath}/inventory/${setupInventory}/files/op-cli"
    local manifest_file="${op_cli_files}/ibm-spectrum-scale-operator.yaml"

    validate_file_exists "${manifest_file}"

    oc delete -f "${manifest_file}"
}

apply_custom_resources() {
    local cr_file="${casePath}/inventory/${inventory}/files/scale_v1beta1_cluster_cr.yaml"

    validate_file_exists "${cr_file}"

    oc apply -f "${cr_file}"
}

delete_custom_resources() {
    local cr_file="${casePath}/inventory/${inventory}/files/scale_v1beta1_cluster_cr.yaml"

    validate_file_exists "${cr_file}"

    oc delete -f "${cr_file}"
}