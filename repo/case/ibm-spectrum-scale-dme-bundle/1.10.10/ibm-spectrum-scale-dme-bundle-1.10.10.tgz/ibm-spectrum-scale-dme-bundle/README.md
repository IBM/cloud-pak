# IBM Storage Scale Container Native Storage Access (CNSA)

IBM Storage® Scale is a clustered file system that provides concurrent access to a single file system or set of file systems from multiple nodes. The nodes can be SAN attached, network attached, a mixture of SAN attached, and network attached, or in a shared-nothing cluster configuration. This enables high performance access to this common set of data to support a scale-out solution or to provide a high availability platform. For more information on IBM Storage® Scale features, see the [Product Overview](https://www.ibm.com/docs/en/spectrum-scale).

IBM Storage® Scale in containers allows the deployment of the cluster file system in a Red Hat® OpenShift® cluster. Using a remote mount attached file system, the IBM Storage® Scale solution provides a persistent data store to be accessed by the applications via the [IBM Storage Scale Container Storage Interface (CSI) Driver](https://www.ibm.com/docs/en/scalecsi) driver using Persistent Volumes (PVs).

## Introduction

### Summary

The IBM Storage Scale CNSA operator deploys a number of pods of different types that together form an IBM Storage Scale cluster.

### Features

See [Features](https://www.ibm.com/docs/en/scalecontainernative/5.2.3?topic=overview-supported-features)

## Details

## Prerequisites

## Resources Required

Refer to the [IBM Storage Scale Container Native documentation](https://www.ibm.com/docs/en/scalecontainernative).

## Installing

Refer to the [Installing the IBM Storage Scale container native operator and cluster](https://www.ibm.com/docs/en/scalecontainernative/5.2.3?topic=installing-storage-scale-container-native-operator-cluster).

## Configuration

Refer to the [Kubernetes resources](https://www.ibm.com/docs/en/scalecontainernative/5.2.3?topic=cluster-kubernetes-resources).

## Storage

IBM Storage Scale CNSA utilizes IBM Storage Scale CSI in conjunction with the remote mount of a remote storage cluster.

Refer to the [Configuring IBM Storage Scale Container Storage Interface (CSI) driver](https://www.ibm.com/docs/en/scalecontainernative/5.2.3?topic=configuring-storage-scale-container-storage-interface-csi-driver).

## Limitations

Refer to the [Limitations](https://www.ibm.com/docs/en/scalecontainernative/5.2.3?topic=overview-limitations)

## Documentation

[IBM Storage Scale CNSA Knowledge Center](https://www.ibm.com/docs/en/scalecontainernative)

## PodSecurityPolicy Requirements

This operator does not require any pod security requirements.

Custom PodSecurityPolicy definition:
none

## SecurityContextConstraints Requirements

The operator creates one custom SecurityContextConstraint (SCC) to control the access of various parts of the CNSA deployment. The SCC is created automatically by the operator if it does not exist, however it is not removed when the CNSA deployment is deleted. The user must manually remove the SCC if the CNSA deployment is deleted.

Custom SecurityContextConstraints definition:
```yaml

---
allowHostDirVolumePlugin: true
allowHostIPC: true
allowHostNetwork: true
allowHostPID: true
allowHostPorts: true
allowPrivilegeEscalation: true
allowPrivilegedContainer: true
allowedCapabilities:
- '*'
allowedUnsafeSysctls:
- '*'
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: RunAsAny
kind: SecurityContextConstraints
metadata:
  labels:
    app.kubernetes.io/instance: ibm-spectrum-scale
    app.kubernetes.io/name: operator
  name: ibm-spectrum-scale-privileged
  namespace: ibm-spectrum-scale-operator
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities: null
runAsUser:
  type: RunAsAny
seLinuxContext:
  type: RunAsAny
seccompProfiles:
- '*'
supplementalGroups:
  type: RunAsAny
volumes:
- '*'
```

The operator pod uses the default OCP `restricted` SCC to limit it's abilities to interact with the OCP cluster. Storage Scale core, GUI, and perfmon pods use the `ibm-spectrum-scale-privileged` SCC due to their requirement of needing privileged access to the host machine they reside on.
