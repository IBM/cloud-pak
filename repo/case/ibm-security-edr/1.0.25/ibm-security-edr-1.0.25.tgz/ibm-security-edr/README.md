# Name

IBM Security&reg; QRadar - EDR

# Introduction

## Summary

IBM® Security QRadar EDR is a sophisticated, yet easy-to-use endpoint detection and response (EDR) solution that helps companies protect their endpoints against zero-day threats. It uses intelligent automation, AI and machine learning to detect behavioral anomalies and remediate threats in near real time. 
   

## Features
 IBM Security&reg; QRadar EDR provides security analysts with deep visibility across their entire endpoint ecosystem, including a visual storyline as each attack unfolds. Advanced behavioral analytics and customizable detection strategies address everything from unknown threats to company-specific requirements. IBM Security&reg; QRadar EDR also includes the Cyber Assistant, which learns from analyst decisions and can autonomously handle alerts, reducing false positives and minimizing analysts’ workloads.


   

# Details

## Prerequisites
Please refer to the Preparing to install IBM Security&reg; QRadar EDR section in the [IBM Documentation](https://ibm.biz/BdSdp3).

##  Resources Required
Please refer to the Planning section in the [IBM Documentation](https://ibm.biz/BdSdp3).

## Storage
Please refer to the Persistent Storage section in the [IBM Documentation](https://ibm.biz/BdSdp3).

## Installing IBM Security&reg; QRadar EDR
Please refer to the Installation section in the [IBM Documentation](https://ibm.biz/BdSdp3).

##  Verifying the Installation
Please refer to the Verifying QRadar EDR installation section for each type of install in the [IBM Documentation](https://ibm.biz/BdSdp3).

## Upgrading IBM Security&reg; QRadar EDR
Please refer to the Upgrading IBM Security&reg; QRadar EDR section in the [IBM Documentation](https://ibm.biz/BdSdp3).

##  Uninstalling IBM Security&reg; QRadar EDR
Please refer to the Uninstalling IBM Security&reg; QRadar EDR section in the [IBM Documentation](https://ibm.biz/BdSdp3).

## Configuration
Please refer to the Configuration parameters table for each type of install in the [IBM Documentation](https://ibm.biz/BdSdp3).

## Limitations
The IBM Security&reg; QRadar EDR application can only run on amd64 architecture type.

## Red Hat OpenShift SecurityContextConstraints Requirements

The ibm-security-edr-operator supports running with the OpenShift Container Platform default restricted Security Context Constraints (SCCs).

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.12/authentication/managing-security-context-constraints.html).

Custom SecurityContextConstraints definition:

```yaml
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
  creationTimestamp: "2020-02-14T15:44:45Z"
  generation: 1
  name: restricted-scc
  resourceVersion: "6128"
  selfLink: /apis/security.openshift.io/v1/securitycontextconstraints/restricted
  uid: ecb8cca7-4f40-11ea-bd4f-16ad4167adef
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Documentation

Further guidance can be found in the [IBM Documentation](https://ibm.biz/BdSdp3).

