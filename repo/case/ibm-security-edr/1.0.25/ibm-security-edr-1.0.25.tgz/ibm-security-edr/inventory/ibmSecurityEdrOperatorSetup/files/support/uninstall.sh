#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************
# set -x
kubernetesCLI=oc
edr_namespace=""
operator_namespace="openshift-operators"
delete_ns="false"
del_crd="false"
del_cr="false"
uninstall_edr="false"
read_cr=""
force="false"
action=""
read_cr=""
read_crd=""
airgap=""

usage() {
    echo "
Please pass one of the following arguments:
    #### Uninstall EDR
    --edrNamespace <EDR-NS>         [mandatory option, if no flags are passed along with '--edrNamespace <EDR-NS>' this initiates a complete cleanup of EDR and terminates the namespace]
    --deleteCr                        [if this flag is set, it will ONLY uninstall a EDR CR (e.g '--deleteCr <CR-NAME>'). If no option is provded it deletes 'all' the EDR CRs]
    --deleteCrd                       [if this flag is set, this option will delete all the EDR CRDs]
    --operators                       [if this flag is set, this option will uninstall IBM Security EDR operators]
    --operatorNamespace <OPERATOR-NS> [optional, specifies the namespace where operators are installed, defaults to 'openshift-operators']
    --force                           [if this flag is set, this option will force delete all the remaining objects from a previous uninstall and terminate namespace]
    "
} 
####################################################################
#check if ns was provided in arguments list
function ns_provided()
{ 
  function check_ns_exist()
  {
    r=$($kubernetesCLI get project $@ 2>/dev/null)
    if [[ -z $r ]]; then
      usage
      exit 77
    else 
      $kubernetesCLI project $@
    fi
  }
  ##edr_namespace
  message='[ERROR] Namespace not provided'
  if [[ $@ == 'edr' ]];then
    if [[ -z $edr_namespace ]];then
      echo $message
      usage
      exit 77
    else
      check_ns_exist $edr_namespace 
    fi
  fi
}

####################################################################
## function to remove imagecontent source policy required for Airgap
function delete_sourcepolicy()
{
  if [[ $airgap == 'true' ]]; then
    echo "-------------Deleting image contentsourcepolicy-------------"
    $kubernetesCLI delete imagecontentsourcepolicy ibm-security-edr --ignore-not-found=true
  fi
}


####################################################################
#cleanup catalog sourcecatalogsource
function cleanup_catalogsource()
{
  echo "-------------Uninstalling $@ catalogSources-------------"
  catalog_source_name=$@
  $kubernetesCLI delete catalogsource $catalog_source_name -n openshift-marketplace --ignore-not-found=true 2>/dev/null
  if [[ $force == 'true' ]];then
    $kubernetesCLI patch catalogsource $catalog_source_name -n openshift-marketplace --ignore-not-found=true --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
  fi
}
####################################################################
#terminate_ns
function terminate_ns()
{
  ns=$@
  get_ns()
  {
    $kubernetesCLI get namespace $ns -o name
  }
  if [[ "X$(get_ns $ns)" != "X" ]];then 
    echo  "-------------Deleting namespace $ns-------------"
    $kubernetesCLI delete ns $ns --wait=false --ignore-not-found 
  
    retry=30
    until [ "X$(get_ns $ns)" == "X" ]
    do
      retry=$((retry-1))
      echo "[INFO] Waiting for namespace $ns to terminate... (Remaining checks - $retry/30)"
      sleep 10
      if [ $retry == 0 ];then
        echo "[ERROR] Namespace: $ns did not terminate successfully"
        exit 1
      fi
    done
    echo "[SUCCESS] Namespace: $ns terminated successfully"
  fi
}

#####################################################################
#remove finalisers
function remove_finaliser()
{
  ns=$1
  obj_type=$2
  get_obj=($($kubernetesCLI get $obj_type -o name -n $ns --ignore-not-found))
  
  if [[ $obj_type == 'pods' ]]; then 
    $kubernetesCLI get pod --no-headers | awk '{print $1}' | xargs $kubernetesCLI delete pod --force --grace-period=0 >/dev/null
  fi
  
  
  if [ -z $get_obj ] ; then
    echo "* No $obj_type to patch "
  else
    for c in ${get_obj[@]}
    do
      $kubernetesCLI delete $c -n $ns --wait=false 2>/dev/null
      $kubernetesCLI patch $c -n $ns --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    done
  fi
}

####################################################################
#delete pvc, sa, csv, sub etc
function deleteObject()
{ 
    ns=$1
    object_type=$2
    echo "-------------Deleting $object_type from $ns namespace-------------"
    pending_objs=($($kubernetesCLI get $object_type -n $ns -o name 2>/dev/null))
    if [[ ! -z $pending_objs ]];then
      $kubernetesCLI delete $object_type -n $ns --all --wait=false --ignore-not-found
    else 
      echo "[INFO] No $object_type found "
    fi  
}

####################################################################
#cert manager
function remove_certmanager()
{
    echo "-------------Deleting Certmanagers from $edr_namespace namespace-------------"
    #remove certmanagers
    cm_default=($($kubernetesCLI get certmanagers default))
    if [[ -z $cm_default ]]; then
      echo "[INFO] Default certmanager not found"
      else
      $kubernetesCLI delete certmanagers default --wait=false --ignore-not-found  -n $edr_namespace
      $kubernetesCLI patch certmanagers default --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]'  -n $edr_namespace 2>/dev/null
    fi
    $kubernetesCLI delete validatingwebhookconfiguration cert-manager-webhook 2>/dev/null
}

####################################################################
#delete operand request - Add patch before 
function del_operandreqregistry()
{
    echo "-------------Deleting operand requests from $edr_namespace namespace-------------"
    #del operand requests
    $kubernetesCLI delete operandrequest $@ --wait=false --ignore-not-found -n $edr_namespace
    $kubernetesCLI patch operandrequest $@ -n $edr_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null

    echo "-------------Deleting operand registry from $edr_namespace namespace-------------"
    $kubernetesCLI delete operandregistry $@ --wait=false --ignore-not-found -n $edr_namespace
    $kubernetesCLI patch operandregistry $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' -n $edr_namespace 2>/dev/null
    
}

####################################################################
#delete CRs
function cleanup_status_check()
{
    retry=40
    until [[ $retry == 0 ]]
    do 
      retry=$((retry-1))
      echo "[INFO] Waiting for cleanup to complete... (Remaining checks - $retry/40)"
      sleep 15
      $kubernetesCLI get pods -n $edr_namespace --no-headers | grep 'Terminating' >/dev/null
      if [[ $? == 1 ]];then
        echo "[SUCCESS] Cleanup finished successfully"
        break
      fi
      if [[ $retry == 0 ]];then
        echo "[Error] Timed out: waiting for cleanup to finish"
        break
      fi
    done
    
}
delete_edr_crs()
{
  set_crd_name1=$1
  cr_name1=$2

  $kubernetesCLI delete $set_crd_name1 $cr_name1 -n $edr_namespace --wait=false --ignore-not-found
  if [[ $force == 'true' ]];then
    $kubernetesCLI patch $set_crd_name1 $cr_name1 -n $edr_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
  fi
  
}
function run_delete_edr_crs()
{  
    ns_provided EDR
    set_crd_name=''
    if [[ $@ == 'all' ]];then
       echo "-------------Uninstalling $@ CRs from $edr_namespace namespace-------------"
        crd=$($kubernetesCLI get crd --no-headers | awk '{print $1}'| grep isc.ibm.com)
        
        for crds in ${crd[*]}
        do 
            cr_name=($($kubernetesCLI get $crds -n $edr_namespace --no-headers --ignore-not-found | awk '{print $1}'))
            if [[ ! -z $cr_name ]];then
                for i in ${cr_name[*]}
                do
                  delete_edr_crs $crds $i
                done
            else 
                echo "[INFO] No CR found belonging to $crds"
            fi
        done
    else
        if [[ $@ == 'edr' ]];then
          set_crd_name='ibmsecurityedrs.isc.ibm.com'
        elif [[ $@ == 'cpserviceability' ]]; then
          set_crd_name="cpserviceabilities.isc.ibm.com"
        else
          set_crd_name=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep isc.ibm.com | awk '{print $1}' | grep $@)
          if [[ -z $set_crd_name ]];then echo "[ERROR] Check CR name"; exit 1; fi
        fi

        echo "-------------Uninstalling $@ CR from $edr_namespace namespace-------------"
        delete_edr_crs $set_crd_name $@
        sleep 90
        cleanup_status_check
        
    fi

    
}

####################################################################
#delete CRDs
function delete_crds()
{
  $kubernetesCLI delete crd $@ --ignore-not-found --wait=false
  if [[ $force == 'true' ]];then
    $kubernetesCLI patch crd $@ -n $edr_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
  fi
}
function run_delete_crds()
{
    ##########################  Deleting CRDS ##########################
    if [[ $del_crd == 'true' ]];then  
       echo "------------Remove CRD set to $del_crd------------"
       echo "[INFO] Removing EDR CRD : $@"

      if [[ $@ == 'all' ]];then 
          edr_crds=($($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E '.isc.ibm.com|getambassador.io' | awk '{print $1}'))
          for crds1 in ${edr_crds[@]}; 
          do 
            delete_crds $crds1
          done
          if [[ -z $edr_crds ]];then 
             echo "No CRDs found"
          fi
            
      else
          $kubernetesCLI get crd --no-headers | grep $@ >/dev/null
          if [[ $? -ne 0 ]];then echo "[ERROR] CRD $@ not found"; exit 1; fi
          delete_crds $@
      fi
    fi
      #delete EDR catalogsource from -n openshift-marketplace
      if [[ $airgap == 'true' ]]; then 
        echo "[INFO] Flag --airgap set to $airgap"
        #delete source policy
        delete_sourcepolicy
        #delete catalogsource
        cleanup_catalogsource EDR
      fi

}


# Uninstall IBM Licensing
function uninstall_ibm_licensing() {
    echo "-------------Uninstalling Licensing Resources-------------"

    # Remove resources
    echo "Removing any IBMLicensing related CRs..."
    oc delete ibmlicensing --all  --ignore-not-found

    # Delete any IBM-Licensing Related CRDs
    echo "Removing any IBM-Licensing related CRDs..."
    local ibm_licensing_crds
    ibm_licensing_crds="ibmlicensings.operator.ibm.com ibmlicensingdefinitions.operator.ibm.com ibmlicensingmetadatas.operator.ibm.com ibmlicensingquerysources.operator.ibm.com"

    for crd in $ibm_licensing_crds; do
        echo "Deleting CRD: $crd"
        $kubernetesCLI delete crd "$crd" --ignore-not-found
    done
    
    terminate_ns ibm-licensing 
    echo "-------------Uninstallation of IBM-Licensing Completed-------------"
}

# Uninstall Cert-Manager
function uninstall_cert_manager() {
    echo "-------------Uninstalling Cert-Manager Resources-------------"

    # Remove Subs, CSVs, and Install Plans
    uninstall_resources_in_namespace "cert-manager-operator"
    uninstall_resources_in_namespace "cert-manager"

    # Terminate the Cert-Manager and Cert-Manager-Operator Namespaces
    echo "Terminating cert-manager and cert-manager-operator namespaces..."
    terminate_ns cert-manager-operator
    terminate_ns cert-manager
    
    # Delete any Cert-Manager-Related CRDs after namespace termination
    echo "Removing Cert-Manager related CRDs..."
    local cert_manager_crds
    cert_manager_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'cert-manager' | awk '{print $1}')
    for crd in $cert_manager_crds; do
        echo "Deleting CRD: $crd"
        $kubernetesCLI delete crd "$crd" --ignore-not-found
    done

    echo "-------------Uninstallation of Cert-Manager Completed-------------"
}

####################################################################
#uninstall EDR
uninstall_edr()
{   
    #delete CRs
    run_delete_edr_crs edr
    run_delete_edr_crs all
    #delete objects
    deleteObject $edr_namespace serviceaccount
    deleteObject $edr_namespace deployment
    deleteObject $edr_namespace replicaset
    deleteObject $edr_namespace service
    deleteObject $edr_namespace pods
    deleteObject $edr_namespace pvc

    #remove certmanager
    remove_certmanager
    
    #del operand registry and requests
    del_operandreqregistry reaqta
    del_operandreqregistry cp4s-foundations
    
    #force cleanup
    if [[ $force == 'true' ]];then 
        remove_finaliser $edr_namespace sa
        remove_finaliser $edr_namespace csv
        remove_finaliser $edr_namespace sub
        remove_finaliser $edr_namespace installplan
        remove_finaliser $edr_namespace deployment
        remove_finaliser $edr_namespace replicaset
        remove_finaliser $edr_namespace service
        remove_finaliser $edr_namespace pods
        remove_finaliser $edr_namespace pvc
        deleteObject $edr_namespace job
    fi
    
    list_of_rolebindings=(rolebinding.authorization.openshift.io/admin rolebindings.rbac.authorization.k8s.io/admin-dedicated-admins rolebindings.rbac.authorization.k8s.io/admin-system:serviceaccounts:dedicated-admin)
    for role in ${list_of_rolebindings[@]};
    do
        $kubernetesCLI patch $role -n $edr_namespace --type="json" -p '[{"op": "remove", "path":"/metadata/finalizers"}]' 2>/dev/null
        $kubernetesCLI delete $role -n $edr_namespace --ignore-not-found=true
    done
    
    #remove pending objects
    list_of_objects=(pgprocedures.isc clients.oidc.security operandrequests.operator rolebindings namespacescopes.operator clients.oidc.security)
    for o in ${list_of_objects[@]}; 
    do  
        for p in $($kubernetesCLI get $o.ibm.com -o name --ignore-not-found)
        do
            #$kubernetesCLI get $p -n $edr_namespace --ignore-not-found 2>/dev/null
            $kubernetesCLI delete $p -n $edr_namespace --wait=false --ignore-not-found 2>/dev/null
            if [[ $force == 'true' ]];then 
                $kubernetesCLI patch $p -n $edr_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
            fi
        done
    done

    #terminate namespace
    terminate_ns $edr_namespace

    # Uninstall IBM Licensing
    uninstall_ibm_licensing

    # Uninstall Cert Manager
    uninstall_cert_manager
}

# Function to uninstall resources in each namespace
function uninstall_resources_in_namespace() {
    local namespace="$1"

    echo "------------- Uninstalling Resources in Namespace: $namespace -------------"

    # Remove Subscriptions, CSVs, and Install Plans
    echo "Removing Subs, CSVs, and InstallPlans for $namespace..."
    $kubernetesCLI delete subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    # Store OLM objects (subs, csvs, installplans) into a list so they can be deleted by saving the output of the oc command
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some Subscriptions, CSVs, or Install Plans still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" subscriptions.operators.coreos.com
        remove_finaliser "$namespace" clusterserviceversions.operators.coreos.com
    fi

    # Remove Deployments, DaemonSets, StatefulSets
    echo "Removing Deployments, DaemonSets, and StatefulSets in $namespace..."
    $kubernetesCLI delete deployment,daemonset,statefulset --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    # Store deployments, daemonsets, and statefulsets into a list so they can be deleted by saving the output of the oc command
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get deployment,daemonset,statefulset -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some Deployments, DaemonSets, or StatefulSets still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" deployment
        remove_finaliser "$namespace" daemonset
        remove_finaliser "$namespace" statefulset
    fi

    # Remove ConfigMaps and Secrets
    echo "Removing ConfigMaps and Secrets in $namespace..."
    $kubernetesCLI delete configmap,secret --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    # Store configmaps and secrets into a list so they can be deleted by saving the output of the oc command
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get configmap,secret -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some ConfigMaps or Secrets still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" configmap
        remove_finaliser "$namespace" secret
    fi

    # Remove remaining resources (Pods, CRs, etc.)
    echo "Removing Pods, and other resources in $namespace..."
    $kubernetesCLI delete all --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    # Do one last loop over all the objects (oc get all) and remove any remaining finalizers
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get all -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some resources still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" all
    fi

    # Remove remaining resources CRs
    echo "Removing Custom Resources in $namespace..."
    crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | awk '{print $1}' | grep isc.ibm.com)
    for crd in $crds; do
        pending_objs=()
        # Clean up CRDs by looping over each of them and removing any finalizers
        while IFS= read -r obj; do
            pending_objs+=("$obj")
        done < <($kubernetesCLI get $crd -n "$namespace" -o name --ignore-not-found)

        if [[ -n "${pending_objs[*]}" ]]; then
            echo "[INFO] Some CRs still present for CRD: $crd, proceeding to remove finalizers..."
            remove_finaliser "$namespace" "$crd"
        fi
    done

    echo "------------- Finished Uninstalling Resources in Namespace: $namespace -------------"
}

function uninstallServiceAccountsAndTokens(){
  resources=$(oc get serviceaccounts,secrets,role,rolebinding,clusterrole,clusterrolebinding,cm -oname --ignore-not-found | grep -E "cp-|cp4s-|ibm-cp-security|ibm-security-edr")
  if [[ -n $resources ]]; then
    oc delete $resources
  fi
}

function uninstall_operators(){
    ns="${operator_namespace}"
    echo "[INFO] Uninstalling operators from namespace: ${ns}"
    uninstallServiceAccountsAndTokens
    $kubernetesCLI get csv -n $ns -oname | grep -E "cp4s|ibm-security-edr-operator|cp-serviceability-operator|ibm-opensearch-operator" | xargs oc delete -n $ns
    $kubernetesCLI get subscription.operators.coreos.com -n $ns -oname | grep -E "cp4s|ibm-security-edr-operator|cp-serviceability-operator|ibm-opensearch-operator" | xargs oc delete -n $ns
}

####################################################################
#execute actions as per flags
function execute_actions()
{  
    
    if [[ $force == 'true' ]];then
     echo "[INFO] Force cleanup is enabled"
    fi
    if [[ $del_cr == 'true' ]];then
        run_delete_edr_crs $read_cr
    elif [[ $del_crd == 'true' ]];then
        run_delete_crds $read_crd
    elif [[ $uninstall_edr == 'true' ]];then
        uninstall_edr
    elif [[ $uninstall_operators == 'true' ]]; then
        uninstall_operators
    fi
}

####################################################################
#function to store flags
function read_flags()
{   

    if [[ $@ == '' ]];then 
      echo "[ERROR] Incorrect way of passing arguments!"
      usage
      exit 77
    elif [[ $@ == 'delete_crd' ]];then
        del_crd='true'
    elif [[ $@ == 'delete_cr' ]];then 
        del_cr='true'
    elif [[ $@ == 'uninstall_edr' ]];then 
        uninstall_edr='true'
    elif [[ $@ == 'operators' ]]; then
        uninstall_operators='true'
    fi  
}

####################################################################
#read input from user
while true
do
  flag="$1"
  shift
  if [ -z "$flag" ]; then
    break
  fi
    case $flag in
        --edrNamespace) 
            edr_namespace=$1
            read_flags uninstall_edr
            shift
            ;;
        --deleteCr)
            read_cr=$1
            if [[ -z $read_cr ]] || [[ $read_cr == '--force' ]]; then read_cr='all'; fi
            read_flags delete_cr
            shift
            ;;
        --operators)
            read_flags operators
            shift
            ;;
        --operatorNamespace)
            operator_namespace=$1
            shift
            ;;
        --deleteCrd)
            read_crd=$1
            if [[ -z $read_crd ]] || [[ $read_crd == '--force' ]] || [[ $read_crd == '--airgap' ]]; then 
              if [[ $read_crd == '--airgap' ]];then 
                airgap=true
              fi
              if [[ $read_crd == '--force' ]];then 
                force=true
              fi
              read_crd='all'
            fi
            read_flags delete_crd
            shift
            ;;
        --force)
            force='true'
            shift
            ;;
        *)
        echo "Invalid flag $flag"
        usage
        exit 77
        ;;
    esac
done
#call execute actions 
execute_actions
