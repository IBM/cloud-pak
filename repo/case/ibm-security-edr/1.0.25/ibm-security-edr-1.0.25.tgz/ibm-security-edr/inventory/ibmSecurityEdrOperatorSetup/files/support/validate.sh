#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
caseLocation=$(echo ${scriptDir} | rev | cut -d'/' -f5- | rev)


successfulText="[INFO] IBM Security EDR deployment is complete."
## This function returns the route of cp4s
function get_route() {
    ROUTE="$($kubernetesCLI get route isc-route-default --no-headers -n $namespace | awk '{print $2}')"
    echo "$ROUTE"
}
### This function checks the status of the edr cr and returns its status in
function check_edr_status() {
    ### Need to check the status of the top level CR after which we can optionally check the status of the operator crs

    ### Get the cr for top level ibm-security-edr

    CR=$($kubernetesCLI get ibmsecurityedrs.isc.ibm.com -n $namespace edr -o name)

    [[ -z $CR ]] && {
        printf "IBM Security EDR CR is not deployed,exiting \n"
        exit 1
    }

    EDR_STATUS=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{ range .items[*]}{.status.conditions[*].type}{"\n"}')

    # EDR_STATUS_REASON=$($kubernetesCLI get $CR -o jsonpath='{ range .items[*]}{.status.conditions[*].reason}{"\n"}')

    if [[ $EDR_STATUS != "Success" ]]; then
        maxRetry=100

        printf "%s\n" "[INFO] IBM Security EDR deployment is $EDR_STATUS"
        for ((retry = 0; retry <= maxRetry; retry++)); do
            TIME=$(date "+%Y/%m/%d-%H:%M:%S")
            EDR_STATUS_MESSAGE=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{ range .items[*]}{.status.conditions[*].message}{"\n"}')
            EDR_STATUS=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{ range .items[*]}{.status.conditions[*].type}{"\n"}')
            if [[ $EDR_STATUS == "Success" ]]; then
                ### get the route here and display in the print statement
                edr_route=$(get_route)
                printf "\n---------------------------------------------------------------------\n"
                printf "%s\n" "$TIME: $successfulText"
                break
            elif [[ "${EDR_STATUS}" == "Degraded" ]]; then
                edr_route=$(get_route)
                printf "\n---------------------------------------------------------------------\n"
#                @todo
                printf "%s:[INFO] Your IBM Security EDR console is available at ${edr_route}.\n" "${TIME}"
                break
            else
                printf "\n------------------------------------------------------------\n"
                printf "%s\n" "$TIME:[INFO] $EDR_STATUS_MESSAGE"
                printf "%s\n" "$TIME:[INFO] $EDR_STATUS"
                sleep 30
            fi

            if [ "${retry}" -eq "${maxRetry}" ]; then
                printf "%s :[ERROR] Timed out waiting for IBM Security EDR deployment to complete" "${TIME}"
                exit 1
            fi
        done
    else
        ### get the route here and display in the print statement
        edr_route=$(get_route)
        printf "%s\n" "$successfulText"
    fi
}

check_edr_status
