# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# ----- LOGS -----
log_file="/tmp/edr.log-$(date +'%Y-%m-%d_%H-%M-%S')"
exec &> >(tee -a "$log_file")

# ibm-security-edr specific variables
caseName="ibm-security-edr"
inventory="ibmSecurityEdrOperatorSetup"
caseCatalogName=""
channelName=""
configFile="${scriptDir}/values.conf"
export namespace
export kubernetesCLI="oc"
export inputcasedir
dev=0                   # Flag for dev mode
airgap=0                # Flag for airgap install
proxy=0                 # Flag for proxy install
skipCRDeployment=0      # Flag for skipping CR deployment
skipCredsValidation=0   # Flag for skipping the registry creds validation
skipTLSCreation=0       # Flag for skipping the TLS creation
singleNamespaceMode=0 # Flag to define the install via all namespaces mode
cr_passed='all'
crd_passed='all'
set_flag=()

# edr only supporting thin
storageClass="thin-csi"

# variables specific to catalog installation
catalogNamespace="openshift-marketplace"

# ----- HELPER FUNCTIONS -----

function run() {
    command=$1
    message=$2
    if ! bash ${command}; then
        err_exit "${message} has failed"
    fi
}

function validate_parameters() {
    # Validation for the actions and the parameters
    if [[ "${action}" == "install" ]] || [[ "$action" == "installOperator" ]]; then
        # Check if license has been accepted
        if [[ -z "${acceptLicense}" ]] || [[ "${acceptLicense}" != "true" ]]; then
            err_exit "License was not accepted, please read license in ibm-security-edr/licenses directory and accept by adding '--acceptLicense true' as part of the install arguments"
        fi

        # Check if values.conf file exists
        validate_file_exists "${configFile}"
        source "${configFile}"

        # Set variables based on values.conf
        airgapInstall="${airgapInstall}"
        clusterProxy="${clusterProxy}"
        domain="${domain}"
        domainCertificatePath="${domainCertificatePath}"
        domainCertificateKeyPath="${domainCertificateKeyPath}"
        customCaFilePath="${customCaFilePath}"
        storageClass="${storageClass}"
        backupStorageClass="${backupStorageClass}"
        backupStorageSize="${backupStorageSize}"
        imagePullPolicy="${imagePullPolicy}"
        repository="${repository}"
        repositoryUsername="${repositoryUsername}"
        repositoryPassword="${repositoryPassword}"

        # Check if airgapInstall is set to true
        if [[ "${airgapInstall}" == "true" ]]; then
            airgap=1
        else
            airgap=0
        fi

        # Check if clusterProxy is set to true
        if [[ "${clusterProxy}" == "true" ]]; then
            if [[ ${airgap} == 1 ]]; then
                err_exit "Proxy cannot be enabled if airgapInstall is set to true."
            fi
            proxy=1
        else
            proxy=0
        fi

        # Check the validity of the domain and if the certificates are available
        if [[ -n "${domain}" ]]; then
            if [[ ! "${domain}" =~ ^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])(.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]))*$ ]]; then
                err_exit "The domain set in the values.conf is invalid."
            fi

            # Check if isc-ingress-default-secret already exists
            local checkIngressSecret=$($kubernetesCLI get secret isc-ingress-default-secret -n "${namespace}" --ignore-not-found=true)
            if [[ -z "${checkIngressSecret}" ]]; then
                # If domain is valid then check if the certificate files are provided
                if [[ -z "${domainCertificatePath}" ]]; then
                    err_exit "domainCertificatePath parameter is empty. Please specify the domainCertificatePath in the values.conf."
                elif [[ -z "${domainCertificateKeyPath}" ]]; then
                    err_exit "domainCertificateKeyPath parameter is empty. Please specify the domainCertificateKeyPath in the values.conf."
                fi

                # Check if the provided certificate files exist
                validate_file_exists "${domainCertificatePath}"
                validate_file_exists "${domainCertificateKeyPath}"
                if [[ -n "${customCaFilePath}" ]]; then
                    validate_file_exists "${customCaFilePath}"
                fi
            else
                # Skip the TLS creation assuming that it is an upgrade
                skipTLSCreation=1
            fi
        fi

        # Validate the storage class
        validate_storage_class "${storageClass}"

        # Check if repositoryUsername is empty
        [[ -z "${repositoryUsername}" ]] && { err_exit "repositoryUsername parameter is empty. Please set repositoryUsername in the values.conf."; }

        # Check if repositoryPassword is empty
        [[ -z "${repositoryPassword}" ]] && { err_exit "repositoryPassword parameter is empty. Please set repositoryPassword in the values.conf."; }

        # Verify registry credentials
        if [[ "${skipCredsValidation}" -eq 0 ]]; then
            verify_registry "${repository}" "${repositoryUsername}" "${repositoryPassword}"
        fi

    elif [[ "${action}" == "installCatalog" ]] || [[ "${action}" == "setUpCatalogPrereqs" ]]; then
        # Check for registry credentials needed for the entitlement key
        if [[ "${airgap}" -eq 0 ]]; then
            # Check if registry is empty
            [[ -z "${registry}" ]] && { registry="cp.icr.io"; }

            # Check if user is empty
            [[ -z "${user}" ]] && { user="cp"; }

            # Check if pass is empty
            [[ -z "${pass}" ]] && { err_exit "Password for the production registry are needed when running ${action} action. Please use --pass flag within the '--args' parameter."; }

            # Check if dev mode is enabled
            if [[ "${dev}" -eq 1 ]]; then
                if [[ -z "${devRepo}" ]] || [[ -z "${devUser}" ]] || [[ -z "${devPass}" ]]; then
                    err_exit "Development or staging registry credentials are needed when running ${action} action with --dev flag. Please use --devRepo, --devUser, and --devPass flags."
                fi
                verify_registry "${devRepo}" "${devUser}" "${devPass}"
            fi
        else
            if [[ -z "${registry}" ]] || [[ -z "${user}" ]] || [[ -z "${pass}" ]]; then
                err_exit "Credentials for the local docker registry are needed when running ${action} action. Please use --registry, --user, and --pass flags within the '--args' parameter."
            fi
        fi
        # Verify registry credentials
        verify_registry "${registry}" "${user}" "${pass}"
    elif [[ "${action}" == "mirrorICRImages" ]]; then
        if [[ -z "$icrImages" ]]; then
            err_exit "--icrImages must be specified within '--args' parameter e.g. image:tag,image:tag"
        fi
    elif [[ "${action}" == "createTLSSecret" ]]; then
        # Check if the certs have been passed in, customCaArgs is optional
        [[ -z "${tlsCertArgs}" ]] && { err_exit "--tlsCert must be specified within '--args' parameter."; }
        [[ -z "${tlsKeyArgs}" ]] && { err_exit "--tlsKey must be specified within '--args' parameter."; }

        # Validate if files exists
        validate_file_exists "${tlsCertArgs}"
        validate_file_exists "${tlsKeyArgs}"
        if [[ -n "${customCaArgs}" ]]; then
            validate_file_exists "${customCaArgs}"
        fi
    fi
}

function validate_storage_class() {
    # Check if there a default storage class, if none found exit out
    local storageClass="$1"

    # Check the storage class passed in the values.conf
    if [[ -n "${storageClass}" ]]; then
        local checkStorage=$($kubernetesCLI get sc "${storageClass}" --no-headers --ignore-not-found=true | awk '{print $1;exit;}')
        if [[ -z "${checkStorage}" ]]; then
            availableStorage=$($kubernetesCLI get sc --no-headers | awk '{print $1}')
            err "Storage class ${storageClass} not found"
            err "Select from available storage classes:"
            echo "${availableStorage}"
            exit 1
        else
            echo "[INFO] Storage class ${storageClass} will be used."
            return
        fi
    else
        echo "[INFO] storageClass parameter in values.conf is empty, EDR will be using the default storage class in the cluster."
    fi

    local defaultSc=()
    local count=0

    # Loop through the storage classes and retrieve all default storage classes
    echo "[INFO] Looking for a default storage class..."
    for sc in $($kubernetesCLI get storageclass -o name); do
        local isDefault=$($kubernetesCLI get "${sc}" -o jsonpath="{.metadata.annotations['storageclass\.kubernetes\.io/is-default-class']}")
        # Check default storage classes labelled with beta annotations so script does not skip them
        local isDefaultBeta=$($kubernetesCLI get "${sc}" -o jsonpath="{.metadata.annotations['storageclass\.beta\.kubernetes\.io/is-default-class']}")
        if [[ "${isDefault}" != "true" ]] && [[ "${isDefaultBeta}" != "true" ]]; then
            continue
        else
            count=$((count + 1))
            defaultSc+=("$sc")
        fi
    done

    # Check the number of default storage classes in the cluster
    if [[ "${count}" -eq 0 ]]; then
        err_exit "There is no storage class set as default in the cluster."
    elif [[ "${count}" -gt 1 ]]; then
        local formatScs=$(echo ${defaultSc[@]} | sed 's/ /, /g')
        err "There is more than one default storage class in the cluster."
        err "Please choose only one default storage class from the following:"
        err_exit "${formatScs}"
    fi

    # Output the default storage class to be used
    echo "[INFO] Found default storage class: ${defaultSc}"
    # Patch default sc with the non-beta annotation
    local checkBeta=$($kubernetesCLI get "${defaultSc}" -o jsonpath="{.metadata.annotations['storageclass\.beta\.kubernetes\.io/is-default-class']}")
    if [[ "${checkBeta}" == true ]]; then
        echo "[INFO] Default storage class is using beta annotation, patching the storage class with the non-beta annotation..."
        $kubernetesCLI annotate "${defaultSc}" storageclass.beta.kubernetes.io/is-default-class-
        $kubernetesCLI patch "${defaultSc}" -p '{"metadata": {"annotations":{"storageclass.kubernetes.io/is-default-class":"true"}}}'
    fi
}

function verify_registry() {
    local reg="$1"
    local user="$2"
    local pass="$3"
    local cli="docker"

    echo "[INFO] Verifying registry credentials for ${reg}..."
    if ! docker version >/dev/null 2>&1; then
        cli="podman"
    fi

    if [[ ${user} != "demo" && ${pass} != "demo" ]]; then
        if ! $cli login -u "${user}" -p "${pass}" "${reg}" >/dev/null 2>&1; then
            err_exit "Registry validation failed. Please check registry credentials or if docker/podman is running."
        else
            echo "[INFO] Registry validation successful."
        fi
    fi
}

function setup_namespace() {
    local ns="$1"
    local checkNamespace=$($kubernetesCLI get namespace "${ns}" --no-headers --ignore-not-found=true | awk '{print $1}')

    if [[ -n "${checkNamespace}" ]]; then
        echo "[INFO] Found namespace ${ns}"
    else
        if [[ "${action}" == *"uninstall"* ]] && [[ $set_flag != *'--deleteCrd'* ]]; then
            err_exit "Unable to retrieve namespace specified ${namespace}."
        elif [[ "${action}" == *"uninstall"* ]] && [[ $set_flag == *'--deleteCrd'* ]]; then
            $kubernetesCLI project default
            #The above check is added to handle --deleteCrd flag. This flag will set to delete EDR CRDs and will be use mostly after uninstalling EDR and terminating its namespace.
            #err_exit "Unable to retrieve namespace specified ${namespace}."
        else
            if ! $kubernetesCLI create namespace "${ns}" 2>/dev/null; then
                err_exit "Failed to create ${ns} namespace."
            fi
        fi
    fi

    # Switch the EDR namespace
    $kubernetesCLI project "${ns}"
}


function create_pull_secret() {
    local secretName="$1"
    local secretNamespace="$2"
    local registry="$3"
    local username="$4"
    local password="$5"

    # Check if secret already exists, if so delete and recreate the secret
    secret=$($kubernetesCLI get secret "${secretName}" -n "${secretNamespace}" --no-headers --ignore-not-found=true | awk '{print $1}')
    if [[ -n "${secret}" ]]; then
        echo "[WARNING] ${secret} already exists in ${secretNamespace} namespace. It will be deleted and recreated."
        $kubernetesCLI delete secret "${secret}" -n "${secretNamespace}" --ignore-not-found=true
    fi

    if ! $kubernetesCLI create secret docker-registry "${secretName}" -n "${secretNamespace}" \
        --docker-server="${registry}" \
        --docker-username="${username}" \
        --docker-password="${password}"; then
        err_exit "Failed to create ${secretName} secret in ${secretNamespace} namespace."
    fi
}

function create_dev_resources() {
    local secretNamespace="$1"

    # Check if airgap install, if not then proceed with creating dev resources
    if [[ "${airgap}" -eq 0 ]]; then

        # Check if production registry credentials are passed in during dev mode
        if [[ -z "${registry}" ]] && [[ -z "${user}" ]]; then
            # Set default values if both flags are empty
            registry="cp.icr.io"
            user="cp"
        elif [[ -z "${pass}" ]]; then
            err_exit "Password for the production registry is needed when --dev flag is enabled."
        fi

        # Identify which variable to be used to create the secret data based on the install type
        if [[ "${action}" == "install" ]]; then
            local registryMod="${repository}"
            local registryUserMod="${repositoryUsername}"
            local registryPassMod="${repositoryPassword}"
        else
            local registryMod="${devRepo}"
            local registryUserMod="${devUser}"
            local registryPassMod="${devPass}"
        fi

        # Create ibm-isc-pull-secret in the openshift-marketplace namespace
        # and use the merged secrets in the EDR namespace
        if [[ "${secretNamespace}" == "openshift-marketplace" ]]; then
            create_pull_secret "ibm-entitlement-key" "${secretNamespace}" "${registryMod}" "${registryUserMod}" "${registryPassMod}"
            $kubernetesCLI -n "${secretNamespace}" secrets link default "ibm-entitlement-key" --for=pull
        else
            # Create the secret data and encode with base64
            # Encode with -w 0 flag when client is using Linux machine to disable line wrapping
            if [ "$(uname)" != "Darwin" ]; then
                base64Flag="-w 0"
            fi

            local secretData="{\"auths\":{\"${registry}\":{\"username\":\"${user}\",\"password\":\"${pass}\",\"auth\":\"$(echo -n ${user}:${pass} | base64 ${base64Flag})\"},
            \"${registryMod}\":{\"username\":\"${registryUserMod}\",\"password\":\"${registryPassMod}\",\"auth\":\"$(echo -n ${registryUserMod}:${registryPassMod} | base64 ${base64Flag})\"}}}"
            local secretDataEncoded=$(echo -n ${secretData} | base64 ${base64Flag})

            # Delete existing ibm-entitlement-key secret if there's any
            $kubernetesCLI delete secret ibm-entitlement-key -n "${secretNamespace}" --ignore-not-found=true

            # Create the secret using the encoded base64 data
            cat <<EOF | $kubernetesCLI apply -f -
            apiVersion: v1
            kind: Secret
            metadata:
                name: ibm-entitlement-key
                namespace: ${secretNamespace}
            type: kubernetes.io/dockerconfigjson
            data:
                .dockerconfigjson: |
                    ${secretDataEncoded}
EOF
        fi
    fi
}
function configure_cp4s_catalog_source(){
    if [[ "${dev}" -eq 0 ]]; then
        return
    fi
    local catSrcFile="${casePath}/inventory/${inventory}/files/op-olm/cp4s_catalog_source.yaml"
    # Verify if expected yaml files exists
    validate_file_exists "${catSrcFile}"

    # Retain a record for the original catalog source image
    local catSrcImgOriginal=$(grep "image:" "${catSrcFile}" | awk '{print $2}')
    local ogImg=$(cut -d "@" -f 1 <<< "$catSrcImgOriginal")

    # Determine the current QRadar Suite catalog source
    local repositoryMod=icr.io/cpopen/

    # Check if image is a UAT image
    if [[ -z "$1" || $1 == *icr.io* ]]; then
        repositoryMod="cp.icr.io/cpopen"
    else
        repositoryMod=$(get_repo_mod "$1")
    fi

    # Build the new catalog source image
    ogImgNameAndTags="${ogImg##*/}"
    ogImgName="${ogImgNameAndTags%:*}"

    if [[ -n "${cp4sCatalogSourceTag}" ]]; then
        if [[ $cp4sCatalogSourceTag == *"sha256"* ]]; then
         catSrcImageMod="${repositoryMod}/${ogImgName}@${cp4sCatalogSourceTag}"
        else
         catSrcImageMod="${repositoryMod}/${ogImgName}:${cp4sCatalogSourceTag}"
        fi
    else
     currentSha=$(cut -d "@" -f 2 <<< "$catSrcImgOriginal")
     catSrcImageMod="${repositoryMod}/${ogImgName}@${currentSha}"
    fi

    # Apply new catalog source image
    sed -ie "s|image:.*|image: ${catSrcImageMod}|g" "${catSrcFile}"

    # Apply new catalog source file
    $kubernetesCLI apply ${dryRun} -f "${catSrcFile}"
}

function configure_ibm_operator_catalog_source() {
    echo "[INFO] Installing IBM Operator catalog source"
    local catSrcFile="${casePath}/inventory/${inventory}/files/op-olm/ibmOperatorCatalogSource.yaml"
    validate_file_exists "${catSrcFile}"
    ## check if --IBMOperatorCatalogSource flag is passed in the args parameter and replace the image in the catalog source file
    if [[ -n "${ibmOperatorCatalogSrcTag}" ]]; then
        ## create the dev resources for the openshift-marketplace namespace to pull the images from the dev registry
        create_dev_resources "openshift-marketplace"
        ## delete the existing catalog source and recreate it with the new image
        $kubernetesCLI delete CatalogSource ibm-operator-catalog -n openshift-marketplace --ignore-not-found=true
        sed -e "s|image:.*|image: ${ibmOperatorCatalogSrcTag}|g" "${catSrcFile}" | $kubernetesCLI apply  -f -
    else
    # Apply the IBM operator catalog source
    $kubernetesCLI apply -f "${catSrcFile}"
    fi
}

function check_csv() {
    local maxRetry=20
    local operatorName="$1"
    local operatorNamespace="$2"

    # Check if the CSV for a specific operator has been successfully created
    for ((retry = 0; retry <= ${maxRetry}; retry++)); do
        csv=$($kubernetesCLI get csv --no-headers -n "${operatorNamespace}" | grep "${operatorName}" | awk '{print $1}')
        status=$($kubernetesCLI get csv "${csv}" -n "${operatorNamespace}" -o jsonpath='{.status.phase}' 2>/dev/null)
        if [[ "${status}" != "Succeeded" ]]; then
            if [[ ${retry} -eq ${maxRetry} ]]; then
                err_exit "${operatorName} CSV was not created."
            else
                echo "[INFO] Waiting for ${operatorName} CSV to be created..."
                sleep 60
                continue
            fi
        else
            echo "[INFO] ${operatorName} CSV has been successfully created."
            break
        fi
    done
}

function set_domain() {
    # Check if a domain has been passed in, if so return to main function
    if [[ -n "${domain}" ]]; then
        return
    fi

    # Create the EDR domain name based on the route of the cluster
    local edrDomain="edr.$($kubernetesCLI get -n openshift-console route console -o jsonpath="{.spec.host}" | sed -e 's/^[^\.]*\.//')"
    echo "[INFO] IBM Security EDR domain will be set to ${edrDomain}"
}

function setup_certs() {
    # Set the local variables based on the action
    if [[ "${action}" != "createTLSSecret" ]]; then
        local cert="$1"
        local key="$2"
        local ca="$3"
    else
        validate_parameters
        local cert="${tlsCertArgs}"
        local key="${tlsKeyArgs}"
        local ca="${customCaArgs}"
    fi

    local secretName="isc-ingress-default-secret"
    local exists=$($kubernetesCLI get secret "${secretName}" -o name -n "${namespace}" --ignore-not-found=true)

    # Skip the setup of the certs if a domain was not passed in and let the operators handle it
    if [[ -z "${domain}" ]] && [[ "${action}" != "createTLSSecret" ]] || [[ "${skipTLSCreation}" -eq 1 ]]; then
        return
    fi

    echo "[INFO] Setting up certificates"

    # Check if TLS secret already exists
    if [[ -n "$exists" ]]; then
        $kubernetesCLI delete cert "${secretName}" -n "${namespace}" --ignore-not-found=true
        $kubernetesCLI delete secret "${secretName}" -n "${namespace}" --ignore-not-found=true
    fi

    # Create the TLS secret using the files provided in the values.conf
    if [[ -z "${ca}" ]]; then
        if ! $kubernetesCLI create secret tls -n "${namespace}" "${secretName}" --cert "${cert}" --key "${key}"; then
            err_exit "Failed to create TLS secret."
        fi
    else
        # Create the TLS secret with the custom CA file
        if ! $kubernetesCLI create secret generic "${secretName}" --type=kubernetes.io/tls -n "${namespace}" \
            --from-file=ca.crt="${ca}" \
            --from-file=tls.crt="${cert}" \
            --from-file=tls.key="${key}"; then
            err_exit "Failed to create TLS secret."
        fi
    fi
}

function deploy_edr_cr() {
    # Apply the Threat Management CR with the values passed in the by the customer in values.conf
    validate_file_exists "${casePath}/inventory/${inventory}/files/op-olm/ibmSecurityEdr.yaml"
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" \
        -e "s|REPLACE_ACCEPT_LICENSE|${acceptLicense}|g" \
        -e "s|REPLACE_DOMAIN|${domain}|g" \
        -e "s|REPLACE_STORAGE_CLASS|${storageClass}|g" \
        -e "s|REPLACE_AIRGAP_INSTALL|${airgapInstall}|g" \
        -e "s|REPLACE_PROXY_INSTALL|${clusterProxy}|g" \
        -e "s|REPLACE_BACKUP_STORAGE_CLASS|${backupStorageClass}|g" \
        -e "s|REPLACE_BACKUP_STORAGE_SIZE|${backupStorageSize}|g" \
        -e "s|REPLACE_IMAGEPULL_POLICY|${imagePullPolicy}|g" \
        -e "s|REPLACE_REPOSITORY|${repository}|g" \
        -e "s|REPLACE_DEPLOYMENT_SIZE|${deploymentSize}|g" \
        -e "s|REPLACE_LICENSE_TYPE|${licenseType}|g" \
        "${casePath}/inventory/${inventory}/files/op-olm/ibmSecurityEdr.yaml" | $kubernetesCLI apply -n "${namespace}" -f -
}


## this function was included to handle the images mirrored to public registry namespace in the docker regitry for airgap installations.
function deploy_install_values_configmap() {
    if [[ ${airgap} -eq 1 ]]; then
        local installValuesPath="${casePath}"/inventory/"${inventory}"/files/support/installValues.yaml
        local airgapRegistry=""

        parsedRegistry=$(echo "${repository}" | sed "s/\/cp\/cp4s//")

        ## If we are in dev mode, we assume here the public images were mirrored from artifactory else it means the images were pulled from icr.io
        if [[ "${dev}" -eq 1 ]]; then
            airgapRegistry="$parsedRegistry"
        else
            airgapRegistry="$parsedRegistry/cpopen/cp4s"
        fi
        sed -e "s|REPLACE_REPOSITORY|$airgapRegistry|g" "$installValuesPath" | $kubernetesCLI apply -n "${namespace}" -f -
    fi
}

function install_external_catalog_source() {
    local caseFound=""
    local operatorName="$1"
    local caseName="$2"
    local inventory="$3"
    local registryMod="$4"
    local additionalArgs="$5"
    local caseVersion=""
    shift;shift;shift;shift

    caseFound=$(ls "${inputcasedir}"/"${caseName}"-*.tgz | head -1)
    if [[ ${caseFound} == *"no matches found"* ]]; then
        err_exit "CASE named ${caseName} not found."
    else
        echo "[INFO] Found CASE folder for ${caseName}: ${caseFound}"
        caseVersion=$(echo ${caseFound} | grep -o '\-[[:digit:]].*[[:digit:]].tgz' | sed -e "s/^\-//" -e "s/.tgz//")
        echo "[INFO] CASE version: ${caseVersion}"
    fi

    # Install the catalog source
    if [[ ${caseName} == "ibm-opensearch-operator" ]]; then
        # there is no launch file present in case bundle so we need to manually install the catalog source
        tar -xvzf "${caseFound}" -C "${inputcasedir}"
        local catalogSourceFile="${inputcasedir}/${caseName}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
        validate_file_exists "${catalogSourceFile}"
        
        if ! oc apply -f "${catalogSourceFile}"; then
            err_exit "${operatorName} operator catalog install has failed."
        fi
    else
        echo "[INFO] Installing catalog source for ${operatorName} operator"
        if ! oc ibm-pak launch --case "${caseFound}" --version "${caseVersion}" --inventory "${inventory}" --namespace "${catalogNamespace}" --action install-catalog --args "--registry ${registryMod} ${additionalArgs}" --tolerance 1; then
            err_exit "${operatorName} operator catalog install has failed."
        fi
    fi
}

# ----- INSTALL ACTIONS -----

# Install orchestrator for IBM Security EDR
install() {
    validate_install_catalog

    # Validate the parameters passed in values.conf file
    validate_parameters

    # Install the catalog source and the operator group
    install_catalog

    ## create install values if for airgap deployment. condition check is handled inside the function
    deploy_install_values_configmap

    # Install the IBM Security EDR operator
    install_operator
}

# Installs the catalog source and the operator group
install_catalog() {

    validate_install_catalog

    # Validate the parameters required
    if [[ "${action}" != "install" ]]; then
        validate_parameters
    fi

    # Create required resources for dev mode
    if [[ "${dev}" -eq 1 ]]; then
        echo "[INFO] Dev mode is enabled"
        echo "[INFO] Creating dev resources for openshift-marketplace namespace"
        create_dev_resources "openshift-marketplace"
        echo "[INFO] Creating dev resources for ${namespace} namespace"
        create_dev_resources "${namespace}"
    fi

    # Only deploy EDR Catalog source when airgap is enabled or during development mode
    if [[ "${airgap}" -eq 1 ]]; then
        configure_edr_suite_catalog "${repository}"
    else
        configure_edr_suite_catalog
    fi

    # Configure IBM Operator catalog source for online installs
    if [[ "${airgap}" -eq 0 ]]; then
        if ! configure_ibm_operator_catalog_source; then
            err_exit "Failed applying the IBM Operator catalog source."
        fi

        if ! configure_cp4s_catalog_source; then
            err_exit "Failed applying the CP4S catalog source."
        fi
    fi

    # Create the entitlement key secret in the EDR namespace
    if [[ "${dev}" -eq 0 ]] || [[ "${airgap}" -eq 1 ]]; then
        if [[ "${action}" == "install" ]]; then
            local repoRoot=$(echo "${repository}" | sed "s/\/cp\/cp4s//")
            create_pull_secret "ibm-entitlement-key" "${namespace}" "${repoRoot}" "${repositoryUsername}" "${repositoryPassword}"
        else
            create_pull_secret "ibm-entitlement-key" "${namespace}" "${registry}" "${user}" "${pass}"
        fi
    fi

    # Check for an existing operator group in the EDR namespace and create it if does not exists
    local operatorGroupFile="${casePath}/inventory/${inventory}/files/op-olm/operatorGroup.yaml"
    validate_file_exists "${operatorGroupFile}"
    echo "[INFO] Checking for existing operator group in ${namespace} namespace"
    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "[INFO] Operator group found"
        $kubernetesCLI get og -n "${namespace}" -o yaml
    else
        echo "[INFO] No existing operator group found"
        if [[ "${namespace}" != "openshift-operators" ]]; then
            echo "[INFO] Creating the operator group"
            sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${operatorGroupFile}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
        fi
    fi

    # Apply the external catalog sources for airgap install
    if [[ "${airgap}" -eq 1 ]]; then
        if [[ -n $cp4sCatalogSourceTag ]]; then
            cp4sCatalogSourceFlag="--catalogSrcTag $cp4sCatalogSourceTag"
        fi
        local repositoryMod
        repositoryMod=$(get_repo_mod)

        install_external_catalog_source "IBM Security Qradar Suite" "ibm-cp-security" "ibmSecurityOperatorSetup" "${repositoryMod}" "--downstream true $cp4sCatalogSourceFlag"
        install_external_catalog_source "Redis" "ibm-redis-cp" "ibmRedisCPOperator" "${repositoryMod}"
        install_external_catalog_source "ibm-cloud-native-postgresql" "ibm-cloud-native-postgresql" "ibmCloudNativePostgresqlOperator" "${repositoryMod}"
        install_external_catalog_source "ibm-licensing" "ibm-licensing" "ibmLicensingOperatorSetup" "${repositoryMod}"
        install_external_catalog_source "ibm-opensearch-operator" "ibm-opensearch-operator" "ibmOpensearchOperatorSetup" "${repositoryMod}"

    fi
}

get_repo_mod() {
    local repositoryMod=${1:-"icr.io"}
    if [[ "${action}" == "install" ]]; then
        repositoryMod="${repository}"
    elif [[ "${action}" != "install" ]]; then
        if [[ -n "${devRepo}" ]]; then
            repositoryMod="${devRepo}"
        else
            repositoryMod="${registry}"
        fi
    fi
    # Remove /cp/cp4s from the repository
    echo "${repositoryMod}" | sed "s/\/cp\/cp4s//"
}


configure_edr_suite_catalog(){
    local registry_input=$1
    echo "[INFO] Installing the EDR catalog source"
    local catSrcFile="${casePath}/inventory/${inventory}/files/op-olm/catalogSource.yaml"
    # Verify if expected yaml files exists
    validate_file_exists "${catSrcFile}"

    if [[ "${dev}" -eq 1 ]]; then
        echo "[INFO] Dev mode is enabled"
        echo "[INFO] Creating dev resources for openshift-marketplace namespace"
        create_dev_resources "openshift-marketplace"
        echo "[INFO] Creating dev resources for ${namespace} namespace"
        create_dev_resources "${namespace}"
    fi

    # Retain a record for the original catalog source image
    local catSrcImgOriginal=$(grep "image:" "${catSrcFile}" | awk '{print $2}')
    local ogImg=$(cut -d "@" -f 1 <<<"$catSrcImgOriginal")

    # Determine the current QRadar Suite catalog source
    local repositoryMod=icr.io

    # Configure repo if passed in
    if [[ -n "$registry_input" ]]; then
        echo "[INFO] Configuring repo for EDR catalog source"
        repositoryMod=$(get_repo_mod "$1")
    fi

    # Build the new catalog source image
    ogImgNameAndTags="${ogImg##*/}"
    ogImgName="${ogImgNameAndTags%:*}"

    if [[ -n "${catalogSrcTag}" ]]; then
        if [[ $catalogSrcTag == *"sha256"* ]]; then
            catSrcImageMod="${repositoryMod}/cpopen/${ogImgName}@${catalogSrcTag}"
        else
            catSrcImageMod="${repositoryMod}/cpopen/${ogImgName}:${catalogSrcTag}"
        fi
    else
        if [[ $catSrcImgOriginal == *"sha256"* ]]; then
            currentSha=$(cut -d "@" -f 2 <<<"$catSrcImgOriginal")
            catSrcImageMod="${repositoryMod}/cpopen/${ogImgName}@${currentSha}"
        else
            catSrcImageMod="${repositoryMod}/cpopen/${ogImgNameAndTags}"
        fi
    fi

    # Apply catalog source
    sed -e "s|image:.*|image: ${catSrcImageMod}|g" "${catSrcFile}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
}

# Check if a channel update is required (e.g. when foundations channel has been changed) and return boolean
is_upgrade_required() {
    if [[ ${singleNamespaceMode} -eq 1 ]]; then
        operatorNamespace="${namespace}"
    else
        operatorNamespace="openshift-operators"
    fi
    if [[ ! $($kubernetesCLI get subs ibm-security-edr-operator -n ${operatorNamespace}) ]]; then
        echo "[INFO] No existing installation found"
        return 1
    fi

    current_channel=$($kubernetesCLI get subs cp4s-foundations-operator -n ${operatorNamespace} -o jsonpath='{.spec.channel}')

    if [[ "${current_channel}" == "v1.10" ]]; then
        echo "[INFO] Current cp4s-foundations-operator subscrption channel is ${current_channel} so upgrade is required"  
        return 0
    fi

    return 1
}

# Prepare upgrade by scaling down operators and removing subscriptions and csvs. This is not needed for the EDR operator itself
# but it's needed for the foundations operator in order to switch the channel.
prepare_operator_upgrade() {
    if [[ ${singleNamespaceMode} -eq 1 ]]; then
        operatorNamespace="${namespace}"
    else
        operatorNamespace="openshift-operators"
    fi

    $kubernetesCLI scale deployment ibm-security-edr-operator --replicas=0  -n ${operatorNamespace}
    # wait for scale down to succeed
    for step in $(seq 0 10); do
        echo "[INFO] Waiting for ibm-security-edr-operator deployment to scale down"
        running=$($kubernetesCLI get deploy ibm-security-edr-operator -o jsonpath="{.status.readyReplicas}" -n ${operatorNamespace})
        if [ "X$running" == "X0" ]; then
            break
        fi
        sleep 10
    done

    # If upgrade scenario, delete subscriptions and csv's
    if [[ "${airgap}" -eq 1 ]]; then
        $kubernetesCLI delete subs -n ${operatorNamespace} $($kubernetesCLI get subs -n ${operatorNamespace} | grep 'cp4s-\|cp-serv' | grep 1.10 | awk '{ print $1 }')
        $kubernetesCLI delete csv -n ${operatorNamespace} $($kubernetesCLI get csv -n ${operatorNamespace} | grep 'cp4s-\|cp-serv' | grep 1.10 | awk '{ print $1 }')
    fi
}

# Install IBM Security EDR subscription and operator
install_operator() {
    # Wait time
    wait=30

    # Validate the parameters passed in values.conf file
    if [[ "${action}" != "install" ]]; then
        validate_parameters
    fi

    # Prepare operator upgrade if needed
    if is_upgrade_required; then 
        prepare_operator_upgrade
    fi

    echo "[INFO] Installing IBM Security EDR via OLM"

    # Verify if expected yaml files exists
    local subscriptionFile="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscriptionFile}"

    # Channel for the subscription
    local originalChannel="$(grep "channel:" "${subscriptionFile}" | awk '{print $2}')"
    local channelMod="$originalChannel"

    if [[ ${singleNamespaceMode} -eq 1 ]]; then
        operatorNamespace="${namespace}"
    else
        operatorNamespace="openshift-operators"
    fi

    # Set the channelName if provided in the arguments
    if [[ -n "${channelName}" ]]; then
        channelMod="$channelName"
        echo "[INFO] Channel name will be: ${channelMod}"
    fi

    # Apply the subscription file for ibm-security-edr-operator
    echo "[INFO] Create IBM Security EDR operator subscription"
    if [[ "${airgap}" -eq 1 ]] || [[ "${dev}" -eq 1 ]] && [[ -z $ibmOperatorCatalogSrcTag ]]; then
        subscriptionSource="edr"
    else
        subscriptionSource="ibm-operator-catalog"
    fi
    sed -e "s|${originalChannel}|${channelMod}|g;s|REPLACE_NAMESPACE|${operatorNamespace}|g;s|REPLACE_SOURCE|${subscriptionSource}|g" "${subscriptionFile}" | $kubernetesCLI apply -f -
    # Check if IBM Security EDR operator subscription was created
    while true; do
        $kubernetesCLI -n ${operatorNamespace} get subscription.operators.coreos.com ibm-security-edr-operator &>/dev/null && break
        sleep $wait
    done

    # Check if ibm-security-edr-operator CSV is successful
    check_csv "ibm-security-edr-operator" "${operatorNamespace}"
    # Check if --skipCRDeployment flag is enabled during install
    if [[ "${skipCRDeployment}" -eq 0 ]]; then
        # Set the domain value
        set_domain

        # Setup the certs for the domain
        setup_certs "${domainCertificatePath}" "${domainCertificateKeyPath}" "${customCaFilePath}"

        # Deploy Threat Management CR
        deploy_edr_cr
    fi
}


# Validates the EDR install
validate() {
    local scriptFile="${scriptDir}/support/validate.sh"
    validate_file_exists "${scriptFile}"
    run "${scriptFile}" "IBM IBM Security EDR validation"
}


# ----- OVERRIDEN FUNCTIONS -----
# Override the check_kube_namespace function from the generic launch.sh script
check_kube_namespace() {
    #check for --deleteCrd flag. This flag will set to delete EDR CRDs and will be use mostly after uninstalling EDR and terminating its namespace.
    if [[ $set_flag != *'--deleteCrd'* ]]; then
        [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
        setup_namespace "${namespace}"
    fi
}

# ----- UNINSTALL EDR FUNCTION -----
uninstall_edr() {
    local scriptFile="${scriptDir}/support/uninstall.sh"
    validate_file_exists "${scriptFile}"

    #check for --deleteCrd flag. This flag will set to delete EDR CRDs and will be use mostly after uninstalling EDR and terminating its namespace.
    if [[ $set_flag == *'--deleteCrd'* ]]; then
        run "${scriptFile} ${set_flag}" "Uninstall IBM Security EDR CRDs and Knative resources"
    elif [[ $set_flag == *'--operators'* ]]; then
        # Determine operator namespace based on singleNamespaceMode
        if [[ ${singleNamespaceMode} -eq 1 ]]; then
            operatorNamespace="${namespace}"
        else
            operatorNamespace="openshift-operators"
        fi
        run "${scriptFile} ${set_flag} --operatorNamespace ${operatorNamespace}" "Uninstall IBM Security EDR operators from ${operatorNamespace}"
    else
        run "${scriptFile} --edrNamespace ${namespace} ${set_flag}" "Uninstall IBM Security EDR in ${namespace} namespace"
    fi
}

# ----- OTHER EDR ACTIONS -----

function generate_auth_json() {
    path=$(find $HOME -type d -name ".airgap" 2>/dev/null)
    if [[ -z $path ]]; then
        err_exit "Failed to find path to registry credentials"
    fi
    # path="/root/.airgap"
    echo "[INFO] Generating auth.json"
    printf "{\n  \"auths\": {" >"$path/auth.json"

    if [ -d "$path/secrets" ]; then
        all_registry_auths=
        for secret in $(find "$path/secrets" -name "*.json"); do
            registry_auth=$(cat ${secret} | sed -e "s/^{\"auths\":{//" | sed -e "s/}}$//")
            if [[ "$?" -eq 0 ]]; then
                if [ ! -z "${all_registry_auths}" ]; then
                    printf ",\n    ${registry_auth}" >>"$path/auth.json"
                else
                    printf "\n    ${registry_auth}" >>"$path/auth.json"
                fi
                all_registry_auths="${all_registry_auths},${registry_auth}"
            fi
        done
    else
        err_exit "Failed to get credentials for image mirroring"
    fi

    printf "\n  }\n}\n" >>"$path/auth.json"
}

function mirror_icr_images() {
    validate_parameters
    IFS=',' read -r -a images_array <<<"$icrImages"
    if [ ${#images_array[@]} == 0 ]; then
        err_exit "No images specified. Please use --icrImages within '--args' parameter e.g. <image>:<tag>,<image>:<tag>"
    else
        generate_auth_json
        for image in ${images_array[*]}; do
            if ! $kubernetesCLI image mirror icr.io/cpopen/cp4s/"${image}" "${registry}"/cpopen/cp4s/"${image}" -a "${path}"/auth.json --insecure=true; then
                err_exit "Failed to mirror ${image}"
            fi
        done
    fi
}

# Override the run_action function from the generic launch.sh script
# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    configureCluster)
        configure_cluster
        ;;
    configureClusterAirgap)
        configure_cluster_airgap
        ;;
    configureCredsAirgap)
        configure_creds_airgap
        ;;
    install)
        install
        ;;
    validate)
        validate
        ;;
    setUpCatalogPrereqs)
        install_catalog
        ;;
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    mirrorImages)
        mirror_images
        ;;
    uninstall)
        uninstall_edr
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    initRegistry)
        init_registry
        ;;
    startRegistry)
        start_registry
        ;;
    stopRegistry)
        stop_registry
        ;;
    mirrorImages)
        mirror_images
        ;;
    mirrorICRImages)
        mirror_icr_images
        ;;
    createTLSSecret)
        setup_certs
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}
# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --storageClass)
      storageClass="$val"
    ;;
    --acceptLicense)
        acceptLicense=$val
        ;;
    --dev)
        dev=1
        ;;
    --catalogSrcTag)
        catalogSrcTag="$val"
        ;;
    --debugMode)
        DEBUG="true"
        export DEBUG
        ;;
    --deleteCr)
        cr_passed=$val
        set_flag+="--deleteCr $cr_passed"
        shift
        ;;
    --operators)
        cr_passed=$val
        set_flag+="--operators true"
        shift
        ;;
    --deleteCrd)
        crd_passed=$val
        set_flag+="--deleteCrd $crd_passed"
        shift
        ;;
    --airgap)
        airgap=1
        if [[ "${action}" == *"uninstall"* ]]; then
            set_flag+=" --airgap"
            shift
        fi
        ;;
    --singleNamespaceMode)
        singleNamespaceMode=1
        ;;
    --cp4sCatalogSourceTag)
        cp4sCatalogSourceTag="$val"
        ;;
    --force)
        set_flag+=" --force"
        ;;
    --icrImages)
        icrImages="$val"
        ;;
    --tlsCert)
        tlsCertArgs="$val"
        ;;
    --tlsKey)
        tlsKeyArgs="$val"
        ;;
    --customCa)
        customCaArgs="$val"
        ;;
    --skipCRDeployment)
        skipCRDeployment=1
        ;;
    --skipCredsValidation)
        skipCredsValidation=1
        ;;
    --devRepo)
        devRepo="$val"
        ;;
    --devUser)
        devUser="$val"
        ;;
    --devPass)
        devPass="$val"
        ;;
    --ibmOperatorCatalogSrcTag)
        ibmOperatorCatalogSrcTag="$val"
    esac
}
unset set_flag
