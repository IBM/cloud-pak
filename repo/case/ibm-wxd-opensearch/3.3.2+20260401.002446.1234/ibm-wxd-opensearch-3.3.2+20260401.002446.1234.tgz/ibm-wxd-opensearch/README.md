# Name

IBM OpenSearch

# Introduction

## Summary

OpenSearch is a search and indexing engine for building fast, scalable search experiences. It supports multiple search methods, enabling hybrid retrieval. This allows developers to create richer, more intelligent search across documents, products, and other content.

## Features

* CPD-facing Helm chart that installs the OpenSearch Operator and Traefik with the IBM OpenSearch auth plugin
* Pre-wired Traefik CRDs and routing to front OpenSearch APIs and Dashboards
* End-to-end authentication support: Traefik → IBM auth plugin → AMS → OpenSearch (native security)
* JWT-based authentication with externalized secrets managed by CPD
* QA harness with sample OpenSearch cluster, mock AMS, and reference routes for validation
* Clear separation of concerns: CPD owns secrets and routes; the chart/operator consumes them

# Details

## Prerequisites

### Resources Required

* See the [OpenSearch documentation](https://docs.opensearch.org/latest/getting-started/intro/)

# Installing

* This component is installed as a dependency of Watsonx.data Premium

## Storage

* See the [OpenSearch documentation](https://docs.opensearch.org/latest/getting-started/intro/)

## Limitations

* See the [OpenSearch documentation](https://docs.opensearch.org/latest/getting-started/intro/)

## Documentation

* See the [OpenSearch documentation](https://docs.opensearch.org/latest/getting-started/intro/)
