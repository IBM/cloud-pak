# ibmRabbitmqOperator

### PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:

```
Policy
```

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
kind: SecurityContextConstraints
apiVersion: security.openshift.io/v1
metadata:
  name: ibm-rabbitmq-scc
seLinuxContext:
  type: MustRunAs

```