# Name

IBM&reg; RabbitMQ Operator

# Introduction

## Summary

[RabbitMQ](https://www.rabbitmq.com/) is an open-source (Mozilla Public License) message-broker software that originally implemented the Advanced Message Queuing Protocol (AMQP) and has since been extended with a plug-in architecture to support Streaming Text Oriented Messaging Protocol, MQ Telemetry Transport, and other protocols

## Features

The IBM&reg; RabbitMQ Operator allows to create a statefulset to deploy a IBM RabbitMQ cluster. 

* Deployment of a Highly Available RabbitMQ server
* Service to expose the RabbitMQ deployment within cluster
* Secret containing credentials to connect to the RabbitMQ
* PersistentVolumeClaim if persistence is enabled 

# Details

## Prerequisites

- Kubernetes 1.19 or later
- Openshift 1.19 or later
- Helm 3.0.0 or later
- Libraries, kubectl, clouctl, oc, docker, podman, skopeo
- PV support on the underlying infrastructure
- Persistent Volume is required if persistance is enabled. Currently, only volumes created via dynamic provisioning are supported.

### Resources Required

**IBM&reg; RabbitMQ Operator**

| Software           | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| ------------------ | ----------- | ----------- | --------- | ----- |
| RabbitMQ Operator  |     512Mi   |        1    |           |  1    |
| **Total**          |             |             |           |       |

**IBM&reg; RabbitMQ Operands**

| Software           | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| ------------------ | ----------- | ----------- | --------- | ----- |
| RabbitMQ instances |    256Mi    |   200m      |           |       |
| Cred Gen/Cleanup   |    128Mi    |   50m       |           |       |
| **Total**          |             |             |           |       |

# Installing the Operator

The operator can be installed via native `oc` and `kubectl` apply commands (make use of the `installOperatorNative` action to deploy) or via OLM through a subscription and channel (make use of the `installOperator` action to deploy). 

* Include installation instructions or links to documentation
* Include the basic things necessary to install the product
* Include environment setup or any other items required

## Install via CLI

1. (Optional) Create image pull secret if installing operator from authenticated registry

    ```bash
    kubectl create secret docker-registry 'cp.icr.io' --docker-server='cp.icr.io' --docker-username='cp' --docker-password='<token>' --docker-email='<user>' --namespace='<target namespace>'
    ```
2. Install the operator via command line specifying image pull secret as argument if installing from authenticated registry


    ```bash
    cloudctl case launch \
        --case case/ibm-rabbitmq-operator \
        --namespace <target namespace> \
        --inventory ibmRabbitmqOperatorSetup \
        --action install-operator-native \
        --args "--secret cp.icr.io" 
    ```

    Alternatively, the install script can create a image pull secret, when authenticated registry user and token are also provided as arguments

    ```bash
    cloudctl case launch                   \
        --case case/ibm-rabbitmq-operator     \
        --namespace <target namespace>     \
        --inventory ibmRabbitmqOperatorSetup  \
        --action install-operator-native           \
        --args "--registry cp.icr.io --secret cp.icr.io --user cp --pass <token>"
    ```

    Create a RabbitMQ Instance

    ```bash
    cloudctl case launch                   \
        --case case/ibm-rabbitmq-operator     \
        --namespace <target namespace>     \
        --inventory ibmRabbitmqOperator  \
        --action apply-custom-resources \
        --args "--systemStatus hello" 
    ```

3. Verify install

    ```bash
    helm test <release name>
    ```
This will run a test against your RabbitMQ statefulset pods

## Install via OLM | using Openshift Operator Catalog

1. Create image pull secret if installing operator from authenticated registry

    ```bash
    kubectl create secret docker-registry 'cp.icr.io' --docker-server='cp.icr.io' --docker-username='cp' --docker-password='<token>' --docker-email='<user>' --namespace='<target namespace>'
    ```
2. Install via OLM

    Create a catalog

    ```bash
    cloudctl case launch \
        --case case/ibm-rabbitmq-operator \
        --namespace <target namespace> \
        --inventory ibmRabbitmqOperatorSetup \
        --action install-catalog \
        --args "--secret cp.icr.io" 
    ```

    Install Operator

    ```bash
    cloudctl case launch \
        --case case/ibm-rabbitmq-operator \
        --namespace <target namespace> \
        --inventory ibmRabbitmqOperatorSetup \ 
        --action install 
    ```
    Create an Instance

    ```bash
    cloudctl case launch \
        --case case/ibm-rabbitmq-operator     \
        --namespace <target namespace>     \
        --inventory ibmRabbitmqOperatorSetup  \
        --action apply-custom-resources \
        --args "--systemStatus hello" 
    ```

## Configuration

### Install Modes

```
  installModes:
  - supported: true
    type: OwnNamespace
  - supported: true
    type: SingleNamespace
  - supported: true
    type: MultiNamespace
  - supported: true
    type: AllNamespaces
```

### Architectures Supported and Tested

AMD64

## Storage

The image stores the RabbitMQ data and configurations at the /var/lib/rabbitmq path of the container.

The operator mounts a Persistent Volume volume at this location. By default, you must create the persistent volume ahead of time. 
If you have dynamic provisioning set up, you can install the CR with persistence.useDynamicProvisioning=true. An existing PersistentVolumeClaim can also be defined. 

CR configs that can be leveraged:

```
persistentVolume:
    accessModes: ReadWriteOnce
    enabled: true
    size: 5Gi
    useDynamicProvisioning: true
```

```
storageClassName: ""
```

Kubernetes PersistentVolumes have 3 access modes.

    ReadWriteOnce – the volume can be mounted as read-write by a single node
    ReadOnlyMany – the volume can be mounted read-only by many nodes
    ReadWriteMany – the volume can be mounted as read-write by many nodes

ReadWriteOnce is the best recommended and works as the default access mode.

Storage Providers supported: 

    Openshift Container Storage
    Portworx

## Limitations

* Does not support Hostpath type storage
* The chart is not tested/supported in ppc64le and s390x architectures.

## Documentation

### PodSecurityPolicy Requirements

### Custom PodSecurityPolicy definition

### Red Hat OpenShift SecurityContextConstraints Requirements

The predefined SCC name `restricted` has been verified for this helm based operator. If your target namespace is bound to this SCC, you can proceed to install the helm based operator.

### Custom SecurityContextConstraints definition:
```
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.
  name: ibm-rabbitmq-scc
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
### Custom Secret 

Note: The RabbitMQ pods will look for secrets `<release name>-ibm-rabbitmq-auth-secret` and `<release name>-ibm-rabbitmq-tls-secret`

The secret name is generated based on the instance name and release name.
This happens only when an existing secret is not passed.

A custom secret can be created and their name can be passed in the parameters auth.authSecretName and tls.tlsSecretName as respectively.

a) Auth secret(auth.authSecretName) should have the following keys: `rabbitmq-erlang-cookie`, `rabbitmq-management-password`, `rabbitmq-password`, `definitions.json`

b) TLS secret(tls.tlsSecretName) should have the following keys:
`ca.crt`, `tls.crt`, `tls.key`

For TLS, it is a standard to use TLS version 1.2 or higher for encrypting data over the wire (in transit).

Your workload must encrypt data in transit for all communications, even within the cluster communication.


### Kubernetes Distributions Supported

Red Hat OpenShift Container Platform 4
Red Hat OpenShift Container Platform 3

### Platform Delivery Models Supported

ibm-roks: IBM Cloud ROKS
redhat: The RedHat cloud

### Scaling

The CR creates a statefulset to deploy rabbitmq cluster. RabbitMQ can scale horizontally via manual scaling. The no. of replicas in this statefulset can be scaled down or scaled up via:

```bash
oc scale sts/<statefulsetName> --replicas=<no of replicas>
```

### Roles and Personas 

Role

```
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  creationTimestamp: null
  name: ibm-rabbitmq-operator
  labels:
    app.kubernetes.io/instance: ibm-rabbitmq-operator
    app.kubernetes.io/managed-by: ibm-rabbitmq-operator
    app.kubernetes.io/name: ibm-rabbitmq-operator
rules:
- apiGroups:
  - ""
  resources:
  - namespaces
  verbs:
  - get
- apiGroups:
  - ""
  resources:
  - configmaps
  - secrets
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - events
  verbs:
  - create
- apiGroups:
  - apps
  resources:
  - statefulsets
  verbs:
  - '*'
- apiGroups:
  - ""
  resources:
  - configmaps
  - serviceaccounts
  - services
  verbs:
  - '*'
- apiGroups:
  - rbac.authorization.k8s.io
  resources:
  - rolebindings
  - roles
  verbs:
  - '*'
- apiGroups:
  - batch
  resources:
  - jobs
  verbs:
  - '*'
- apiGroups:
  - monitoring.coreos.com
  resources:
  - servicemonitors
  verbs:
  - get
  - create
- apiGroups:
  - apps
  resourceNames:
  - ibm-rabbitmq-operator
  resources:
  - deployments/finalizers
  verbs:
  - update
- apiGroups:
  - ""
  resources:
  - pods
  verbs:
  - get
- apiGroups:
  - apps
  resources:
  - replicasets
  - deployments
  verbs:
  - get
- apiGroups:
  - helm.operator-sdk
  resources:
  - '*'
  verbs:
  - create
  - delete
  - get
  - list
  - patch
  - update
  - watch
- apiGroups:
  - ""
  resources:
  - 'endpoints'
  verbs:
  - create
  - delete
  - get
- apiGroups:
  -  security.openshift.io
  resources:
  - securitycontextconstraints
  verbs:
  - use
  resourceNames:
  - restricted
- apiGroups:
  - rabbitmq.opencontent.ibm.com
  resources:
  - '*'
  verbs:
  - create
  - delete
  - get
  - list
  - patch
  - update
  - watch

```

Service Account

```

apiVersion: v1
kind: ServiceAccount
metadata:
  name: ibm-rabbitmq-operator
  labels:
    app.kubernetes.io/instance: ibm-rabbitmq-operator
    app.kubernetes.io/managed-by: ibm-rabbitmq-operator
    app.kubernetes.io/name: ibm-rabbitmq-operator
imagePullSecrets:
- name: cp.stg.icr.io
```

Role Binding

```
kind: RoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-rabbitmq-operator
  labels:
    app.kubernetes.io/instance: ibm-rabbitmq-operator
    app.kubernetes.io/managed-by: ibm-rabbitmq-operator
    app.kubernetes.io/name: ibm-rabbitmq-operator
subjects:
- kind: ServiceAccount
  name: ibm-rabbitmq-operator
roleRef:
  kind: Role
  name: ibm-rabbitmq-operator
  apiGroup: rbac.authorization.k8s.io

```

### Network Policy 

The Kubernetes NetworkPolicy resource provides firewall capabilities to pods, similar to AWS Security groups, and it programs the software defined networking infrastructure (OpenShift Default, Flannel, etc...).  You can implement sophisticated network access policies to control ingress access to your workload pods. 

Adopting products can define network policies based on their requirements.


### In Air-Gapped OpenShift Cluster With a Bastion

#### 1. Prepare Bastion Host

* Logon to the bastion machine

* Verify that the bastion machine has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with Openshift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the bastion machine

#### 2. Download CASE

Create a directory to save the CASE to a local directory

```bash
$ mkdir /tmp/cases
```

Run

```bash
$ cloudctl case save \
--case "case/ibm-rabbitmq-operator" \
--repo https://github.com/IBM/cloud-pak/raw/master/repo/case/ \
--version "<version here>" \
--outputdir $HOME/offline/  


Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```

Verify the CASE and images csv has been downloaded

```bash
$ ls /tmp/cases/
total 32K
drwxr-xr-x 2 jey  64 Apr 22 23:37 charts/
-rw-r--r-- 1 jey 22K Apr 22 23:37 ibm-rabbitmq-operator-1.0.0.tgz
-rw-r--r-- 1 jey  32 Apr 22 23:37 ibm-rabbitmq-operator-1.0.0-charts.csv
-rw-r--r-- 1 jey 795 Apr 22 23:37 ibm-rabbitmq-operator-1.0.0-images.csv
```

#### 3. Configure Registry Auth

1. Create auth secret for the the source image registry

Create registry secret for source image registry (if the registry is public which doesn't require credentials, this step can be skipped)

```bash
$ cloudctl case launch  \
    --case case/ibm-rabbitmq-operator     \
    --namespace <target namespace>     \
    --inventory ibmRabbitmqOperatorSetup  \
    --action configureCredsAirgap      \
    --args "--registry cp.icr.io --user iamapikey --pass <apikey>"
```

2. Create auth secret for target image registry

```bash
$ cloudctl case launch  \
    --case case/ibm-rabbitmq-operator     \
    --namespace <target namespace>     \
    --inventory ibmRabbitmqOperatorSetup  \
    --action configureCredsAirgap      \
    --args "--registry $TARGET_REGISTRY --user iamapikey --pass <apikey>"
```

The credentials are now saved to `~/.airgap/secrets/<registry-name>.json`

#### 4. Mirror Images

In this step image from saved CASE (images.csv) are copied to target registry in the airgap environment

```bash
$ cloudctl case launch  \
    --case stable/ibm-sample-rabbitmq-case-bundle/case/ibm-sample-rabbitmq  \
    --namespace <target namespace>  \
    --inventory ibmRabbitmqOperatorSetup  \
    --action mirror-images  \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

#### 5. Configure Cluster for Airgap

This steps does the following

* creates a global image pull secret for the target registry (skipped if target registry is unauthenticated)
* creates a imagesourcecontentpolicy

WARNING:

* Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in $HOME/.airgap/secrets and /tmp/airgap* to support this action

* Applying imagesourcecontentpolicy causes cluster nodes to recycle.

```bash
$ cloudctl case launch                  \
    --case case/ibm-rabbitmq-operator      \
    --namespace <target namespace>      \
    --inventory ibmRabbitmqOperatorSetup   \
    --action configureClusterAirgap     \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

#### 6. Install Catalog Source

This step installs the operator catalogsource in the openshift-marketplace namespace. And also installs catalogs from dependent subcases (couchdb in this case)

```bash
cloudctl case launch                    \
  --case case/ibm-rabbitmq-operator        \
  --namespace $NS                       \
  --inventory ibmRabbitmqOperatorSetup     \
  --action installCatalog               \
  --args "--registry $TARGET_REGISTRY --inputDir $OFFLINEDIR --recursive"
```

#### 7. Install Operator

See instructions from [Installing rabbitmq](#installing-rabbitmq-example) section

### In Air-Gapped OpenShift Cluster Without a Bastion

#### 1. Prepare a portable device

Prepare a portable device (such as laptop) that be used to download the case and images can be carried into the air-gapped environment

* Verify that the portable device has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with Openshift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the portable device

#### 2. Download CASE

See instructions from previous [Downloading CASE](#2-download-case) section

#### 3. Configure Registry Auth

See instructions from previous [Configure Registry Auth](#3-configure-registry-auth) section

#### 4. Mirror Images

See instructions from previous [Mirror Images](#4-mirror-images) section

#### 5. Configure Cluster for Airgap

See instructions from previous [Configure Cluster for Airgap](#5-configure-cluster-for-airgap) section

#### 6. Install Catalog Source

See instructions from previous [Install Catalog Source](#6-install-catalog-source) section

#### 7. Install the Operator

See instructions from previous [Installing rabbitmq](#installing-rabbitmq-example) section

# Uninstalling RabbitMQ

## Online uninstall using command line
1. Delete RabbitMQ instance
```
$  cloudctl case launch                       \
     --case <case-path>/ibm-rabbitmq-operator    \
     --namespace <target-namespace>           \
     --inventory ibmRabbitmqOperator             \
     --action deleteCustomResources           \
```

2. Delete resources
```
$  cloudctl case launch                            \
     --case <case-path>/ibm-rabbitmq-operator         \
     --namespace <target-namespace>                \
     --inventory ibmRabbitmqOperatorSetup             \
     --action uninstallOperatorNative              \
```

3. Delete secrets
$`kubectl delete secret cp.icr.io`

## Online uninstall using Openshift Operator Catalog

1. Delete RabbitMQ instance
```
$  cloudctl case launch                       \
     --case <case-path>/ibm-rabbitmq-operator    \
     --namespace <target-namespace>           \
     --inventory ibmRabbitmqOperator             \
     --action deleteCustomResources           \
```

2. Delete the operator and catalog

```
cloudctl case launch                           \
    --case <case-path>/ibm-rabbitmq-operator      \
    --namespace <target namespace>             \
    --inventory ibmRabbitmqOperatorSetup          \
    --action uninstall
```

```
cloudctl case launch                           \
    --case <case-path>/ibm-rabbitmq-operator      \
    --namespace <target namespace>             \
    --inventory ibmRabbitmqOperatorSetup          \
    --action uninstallCatalog
```

3. Delete secrets
$`kubectl delete secret cp.icr.io`

# Backup and Recovery

As mentioned above, the image stores the RabbitMQ data and configurations at the /var/lib/rabbitmq path of the container.

To make sure configuration and data get stored within a persistent volume claim, we need to make sure/var/lib/rabbitmq is mounted to a volume within the pod specification.

In order to backup data within /var/lib/rabbitmq, there are some [approaches that RabbitMQ recommends](https://www.rabbitmq.com/backup.html)
