# RPA Operator Setup

This inventory item contains resources required to install the RPA Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI) application of kubernetes manifests in both an online and offline airgap environment.