# IBM Robotic Process Automation

IBM&reg; Robotic Process Automation

# Introduction

IBM Robotic Process Automation (RPA) is a technology that encompasses the use of smart robots in any process requiring efficiency, consistency and speed, with no risk of mistakes. In a nutshell, RPA simulates a human user working.

RPA makes it possible to automate processes through the use of digital robots, or bots, which execute pre-programed, repetitive tasks in a safe and mistake free manner. There are literally thousands of opportunities for Robotic Process Automation to make an impact on your organization today, including: automatic invoice emission, system integration, information reconciliation, report generation, intelligent email management to lead generation, and many others.

# Details

The operator supports instances of type `RoboticProcessAutomation` .

`RoboticProcessAutomation` is the custom resource used to install and upgrade IBM RPA on OpenShift.

## Features

- [OCR automation](https://www.ibm.com/docs/en/rpa/23.0?topic=automation-ocr)
- [SAP Automation](https://www.ibm.com/docs/en/rpa/23.0?topic=automation-sap)
- [Web Automation](https://www.ibm.com/docs/en/rpa/23.0?topic=automation-web)
- [Machine learning](https://www.ibm.com/docs/en/rpa/23.0?topic=automation-machine-learning)
- [Credentials Vault](https://www.ibm.com/docs/en/rpa/23.0?topic=automation-vault)
- [IBM RPA Studio recorder](https://www.ibm.com/docs/en/rpa/23.0?topic=automation-recorder)

## Prerequisites

You will need the following to be able to install the operator:
* Kubernetes version is 1.23.x or greater
* Cluster has at least one amd64 node
* Red Hat OpenShift Container Platform versions 4.12 or 4.14
* Client has oc version 4.4.0 or greater
* Client has cloudctl version v3.4.x

The user must have access to pull the images for the operator and operands. To enable this a secret called `ibm-entitlement-key` which contains the docker credentials required to pull the images must be present in all namespaces where components will be deployed.

### Supported Platforms
- Linux x86_64

### Windows Users Note

Windows users will need to enable the [Windows Subsystem for Linux](https://docs.microsoft.com/en-us/windows/wsl/about) to be able to use the cloudctl command.

Follow the [Manual Installation Steps](https://docs.microsoft.com/en-us/windows/wsl/install-win10#manual-installation-steps) to install WSL.

### Resources Required

The following table shows typical cluster configurations suitable for a single deployment of RPA and its dependencies.

| Configuration   | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| -------------   | ----------- | ----------- | --------- | ----- |
| Single instance | 24 GB per worker node | 12 cores per worker node | 250 GB per worker node | 3 worker nodes |
| High availability | 32 GB per worker node | 16 cores per worker node | 250 GB per worker node | 3 worker nodes |

Note: The exact configuration that is required depends on your hardware specifications, and your workload.
# Installing IBM Robotic Process Automation

This operator can be installed in an online environment using the Operator Lifecyle Manager, or in an offline (airgapped) environment by using `cloudctl` commands.

For further details on these installation methods, see [Installing the RPA Operator](https://www.ibm.com/docs/en/rpa/23.0?topic=server-installing-rpa-operator).

## Configuration

For details regarding configuring RPA, check out the [RPA custom resource configuration](https://www.ibm.com/docs/en/rpa/23.0?topic=platform-configuring-rpa-custom-resources) docs.

## Storage

Robotic Process Automation (RPA) on OpenShift has two mandatory persistent volumes: Archive and Hot. IBM Automation Foundation Core and IBM MQ are installed as prerequisites by the RPA operator. They also create their own persistent volumes.

The RPA operator creates persistent volume claims for the volumes by default. For information on customizing them see the [rpa-storage-configuration documentation](https://www.ibm.com/docs/en/rpa/23.0?topic=platform-storage-configuration-permissions).

### Encryption
You can use passive disk encryption, where supported by your chosen storage provider. If you want data at rest to be encrypted, you must provide a storage class that implements encryption.

### Backup
Data inside PVC storage must be backed up.

## SecurityContextConstraints Requirements

The Robotic Process Automation Operator currently will run under the `restricted` security context constraints.

```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
    name: restricted
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
    type: MustRunAs
users: []
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
    type: MustRunAsRange
seLinuxContext:
    type: MustRunAs
supplementalGroups:
    type: RunAsAny
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Limitations

- RPA must be deployed on Red Hat OpenShift Container Platform versions 4.12 or 4.14.
- Only supported on Linux x86_64 platform
- Not available on Power or Z architectures
- You can only deploy one instance of RPA per namespace. 
- Only a single replica of RPA operand pods is supported. 

## Documentation

For additional details regarding RPA, check out the RPA [documentation](https://www.ibm.com/docs/en/rpa/23.0).
