# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this rpa operator

# rpa operator specific variables
inventory="rpaOperatorSetup"
caseCatalogName="ibm-robotic-process-automation-catalog"
channelName="v3.3"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
operatorGroupDependencies="common-service ibmmq-operator-catalogsource-group"

await-installplan() {
    local subscription="$1"
    local ns="$2"
    local timeout="$3"
    end=$((SECONDS+$timeout))
    while [ $SECONDS -lt $end ]; do
        sleep 5
        installplan=$($kubernetesCLI get subscription.operators.coreos.com/${subscription} -n ${ns} -o yaml 2>/dev/null | yq '.status.installPlanRef.name' || true)
        if [ "$installplan" = "null" ]; then
            printf .
            continue
        fi
        $kubernetesCLI wait installplan/${installplan} -n ${ns} --for=jsonpath='{.status.phase}'=Complete --timeout=${timeout}s
        return 0
    done
    if [ $SECONDS -gt $end ]; then
        echo "Timed out waiting for InstallPlan:"
        $kubernetesCLI get subscription.operators.coreos.com/${subscription} -n ${ns} -o yaml | yq '.status.conditions'
        return 1
    fi
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    oc ibm-pak config repo 'IBM Cloud-Pak Github Repo' --url https://raw.github.com/IBM/cloud-pak/repo/case

    cases_yaml=stable/ibm-robotic-process-automation-case-bundle/case/ibm-robotic-process-automation/inventory/rpaOperatorSetup/resources.yaml
    while IFS=\= read case; do
        case_name=$(echo "$case" | yq e '.case')
        case_version=$(echo "$case" | yq e '.version')
        echo "-------------Installing dependent catalog source: ${case_name} ${case_version}-------------"
        oc ibm-pak get "$case_name" --version "$case_version" --skip-verify --skip-dependencies
    done < <(yq e -o=j -I=0 '.resources.resourceDefs.cases[]' $cases_yaml)

    # Remove extra operator groups as namespaces can only have one. Some dependencies end up installing multiple groups.
    for operatorGroup in $operatorGroupDependencies; do
        oc -n "${namespace}" delete operatorgroup $operatorGroup --ignore-not-found=true
    done
}

# Installs the operator group if none exist
install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    set_recursive_action=false
    set_registry=false

    if [[ ${recursive_action} -eq 0 ]]; then
        recursive_action=1
        set_recursive_action=true
        echo "install_catalog recursive_action set to ${recursive_action}"
    fi

    if [[ -z ${registry} ]]; then
        registry="icr.io"
        set_registry=true
        echo "install_catalog registry set to ${registry}"
    fi

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    if [[ set_recursive_action ]]; then
       recursive_action=0
    fi

    if [[ set_registry ]]; then
       registry=""
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install catalog sources and operator
install() {
    # install prerequisites from CP3 on
    $kubernetesCLI apply -f "${casePath}/inventory/${inventory}/files/op-olm/cert-manager-subscription.yaml"
    await-installplan ibm-cert-manager-operator ibm-cert-manager 600
    sed s#@ns_placeholder@#${namespace}# "${casePath}/inventory/${inventory}/files/op-olm/license-service-subscription.yaml" | $kubernetesCLI apply -f -
    await-installplan ibm-licensing-operator-app ibm-licensing 600

    sed s#@ns_placeholder@#${namespace}# "${casePath}/inventory/${inventory}/files/op-olm/common-services-subscription.yaml" | $kubernetesCLI apply -f -
    await-installplan ibm-common-service-operator ${namespace} 600

    # Remove the RPA CRD if it already exists as this will prevent the older operator from being installed
    oc delete crd roboticprocessautomations.rpa.automation.ibm.com --ignore-not-found

    install_catalog
    install_operator
}

# ----- UNINSTALL ACTIONS -----

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
}
