# CASE Bundle for IBM DevOps Build

## Introduction

## Prerequisites
1. OpenShift, OpenShift CLI (oc), and Helm 2.

    * [RedHat OpenShift Container Platform](https://docs.openshift.com/container-platform/4.15/release_notes/ocp-4-15-release-notes.html) v4.15 or later (x86_64)

    * [Install and setup OpenShift CLI](https://docs.openshift.com/container-platform/4.14/cli_reference/openshift_cli/getting-started-cli.html)

    * [Install and setup the Helm 2 CLI](https://helm.sh/docs/intro/install/).

2. Image and Helm Chart - The DevOps Plan images, and helm chart can be accessed via the Entitled Registry and public Helm repository.

    * The public Helm chart repository can be accessed at <https://github.com/IBM/charts/tree/master/repo/ibm-helm> and directions for accessing the DevOps Plan chart will be discussed later in this README.
    * Get a key to the entitled registry
      * Log in to [MyIBM Container Software Library](https://myibm.ibm.com/products-services/containerlibrary) with the IBMid and password that are associated with the entitled software.
      * In the Entitlement keys section, select Copy key to copy the entitlement key to the clipboard.
      * An imagePullSecret must be created to be able to authenticate and pull images from the Entitled Registry.  Note: Secrets are namespace scoped, so they must be created in every namespace you plan to install DevOps Plan into.  Following is an example command to create an imagePullSecret named 'ibm-entitlement-key'.

      ```bash
      oc create secret docker-registry ibm-entitlement-key \
        --namespace [namespace_name] \
        --docker-username=cp \
        --docker-password=<EntitlementKey> \
        --docker-server=cp.icr.io
      ```

## Resources Required
The minimal system resources required:
  * CPU: 8 vCPU (virtual CPUs)
  * Memory: 12 GB
  * Storage: 20 GB

## Install
1. **Deploy Using Helm**  
   Navigate to the directory containing the `devops-build-mysql` folder (Helm chart files) and run:  
   ```bash
   helm install <release-name> .\devops-build-mysql
   ```  
   Wait for the deployments, services, and PVC to roll out. Verify their status with:  
   ```bash
   kubectl get pod, deployment, svc, pvc
   ```
2. **Access the Application**  
   Run the following command to expose the application:  
   ```bash
   minikube service devops-build-preconfig
   ```  
   This command will output URLs for accessing the service. For example:  

   ```
   |-----------|------------------------|-------------|--------------|
   | NAMESPACE |          NAME          | TARGET PORT |     URL      |
   |-----------|------------------------|-------------|--------------|
   | default   | devops-build-preconfig |             | No node port |
   |-----------|------------------------|-------------|--------------|
   ```

   > If the service type is `ClusterIP`, Minikube provides a tunnel to access it. For example:  
   ```
   Starting tunnel for service devops-build-preconfig.
   |-----------|------------------------|-------------|------------------------|
   | NAMESPACE |          NAME          | TARGET PORT |          URL           |
   |-----------|------------------------|-------------|------------------------|
   | default   | devops-build-preconfig |             | http://127.0.0.1:56651 |
   |-----------|------------------------|-------------|------------------------|
   ```

   Copy the provided URL (e.g., `http://127.0.0.1:56651`) and replace `http` with `https` in your browser.

### Verifying the Chart
   The DevOps-Build homepage should now appear. This application is running in Docker containers orchestrated by Kubernetes and installed via a Helm chart.

### Uninstall

## Configuration
1. **Point Shell to Minikube’s Docker Daemon**  
   Once Minikube is set up and started, run the following command to build the required image inside Minikube’s Docker environment:  
   ```bash
   minikube -p minikube docker-env --shell powershell | Invoke-Expression
   ```  
   > _Note:_ This can also be achieved via the `minikube image load` command. However, if this results in errors, use the method above.

2. **Load Base Images**  
   Before building custom images, navigate to the directories containing the original `build-agent` and `build-server` image tar files. Use the following commands to load these images into Minikube’s Docker daemon:  
   ```bash
   docker load -i .\ibm-devops-build-server-container-linux-x86_64-7.0.0.4-1171807.tar.gz
   docker load -i .\ibm-devops-build-agent-container-linux-x86_64-7.0.0-1170263.tar.gz
   ```

3. **Build Custom Images**  
   Navigate to the directory containing the Dockerfile for the `devops-build-preconfig` image and the `devops-build-server` directory, which contains the property files for MySQL server connection. Build the custom image:  
   ```bash
   docker build -t devops-build-preconfig:1.0 .
   ```  
   Then, navigate to the custom MySQL server Dockerfile directory and build the MySQL image:  
   ```bash
   docker build -t mysql-devops-build:1.0 .
   ```

4. **Verify Images**  
   Use the following command to verify that the custom images exist in Minikube’s Docker daemon:  
   ```bash
   docker images
   ```

## **Known Issues**

- **Agent Failure After Minikube Restart**  
  Restarting Minikube can cause the agent to fail with an error:  
  ```
  ERROR SaContainer-1 com.urbancode.ubuild.services.agent.AgentInformationCallback - Error updating agent to online: QpTsdWd6iZqeratql1K9
  com.urbancode.ubuild.domain.persistent.PersistenceException: An agent already exists with name 'devops-build-agent-748b4d687-hx7qb:/opt/devops-build-agent'.
  ```  
  To resolve this, restart the deployment rollout for the agent to make it appear online again on the server's agents page.

> **Tip**: You can use the default values.yaml

## Storage
There are no permanent storage solutions required.

## Limitations
  * Only supported on `amd64` architecture.

## Backup and Recovery

## Other Documentation

**Knowledge Center**: https://www.ibm.com/docs/en/devops-build
**Videos, Blogs, and more**: https://community.ibm.com/community/user/search?s=tags%3A%22UrbanCode%20Build%22&executesearch=true