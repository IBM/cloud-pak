# Name

IBM&reg; watsonx.data Service

# Introduction

This case contains ibm-lakehouse addon service which is the module to interagte watsonx_data into Cloud pak for data.

## Features

See [Details](https://www.ibm.com/docs/en/watsonxdata/1.0.x?topic=administering-post-installation-setup-day-1)

## Prerequisites

See [Details](https://www.ibm.com/docs/en/watsonxdata/1.0.x?topic=administering-post-installation-setup-day-1)

### Resources Required

See [Details](https://www.ibm.com/docs/en/watsonxdata/1.0.x?topic=administering-post-installation-setup-day-1)

# Installing & Configuration

See [Details](https://www.ibm.com/docs/en/watsonxdata/1.0.x?topic=administering-post-installation-setup-day-1)

## Storage

See [Details](https://www.ibm.com/docs/en/watsonxdata/1.0.x?topic=administering-post-installation-setup-day-1)

## Limitations

See [Details](https://www.ibm.com/docs/en/watsonxdata/1.0.x?topic=administering-post-installation-setup-day-1)
