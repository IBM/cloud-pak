# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this open lakehouse operator

# open lakehouse operator specific variables
caseName="ibm-watsonx-data"
inventory="ibmWatsonxDataOperatorSetup"
caseCatalogName="ibm-lakehouse-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="alpha"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-lakehouse-operator}"
#OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:0704c99678322b9b15f9bc806b5405670b03146d16602679a1867407f1bd5c2d}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen/ibm-lakehouse-operator@sha256:2453c344b4c7303e0f6c228e36356d486bf29326f36ae034a7839e5e76d17ba8
entitledRegistry="quay.io/opencloudio"
storageclass=""
service=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
     ibm-cloud-databases-redis)
         echo "redisOperator"
         return 0
         ;;
#    ibm-couchdb)
#        echo "couchdbOperatorSetup"
#        return 0
#        ;;
#    ibm-cp-common-services)
#        echo "ibmCommonServiceOperatorSetup"
#        return 0
#        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    # Temporarily comments install operator source by tgz till redis special image be published
    local dep_case=""

    for dep in $case_depedencies; do
       local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

      echo "-------------Installing dependent catalog source: ${dep_case}-------------"

      validate_file_exists "${dep_case}"        
      local inventory=""
      inventory=$(dependent_inventory_item "${dep}")       

      cloudctl case launch \
           --case "${dep_case}" \
           --namespace "${namespace}" \
           --inventory "${inventory}" \
           --action install-catalog \
           --args "--recursive --inputDir ${inputcasedir} --registry ${registry} ${dryRun:+--dryRun }" \
           --tolerance "${tolerance_val}"
        
       if [[ $? -ne 0 ]]; then
           err_exit "installing dependent catalog for '${dep_case}' failed"
       fi
   done
    
    #     echo "-------------Installing dependent catalogs source -------------"
    # for dependency in ${casePath}/inventory/${inventory}/files/op-olm/dependencies/*.yaml; do
    #     # Verfy expected yaml files for install exit
    #     validate_file_exists "${dependency}"
    #     tee >($kubernetesCLI apply ${dryRun} -f -) <"${dependency}" | cat
    # done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # Temporarily comments install operator source by tgz till redis special image be published
    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        if [[ ${registry} =~ "/" ]];then
          local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s#\([^/]*/\)*##")"
        else
          local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s#[^/]*\/##")"
        fi

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}-catalog" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    existing_lakehouse_subscritpion_name=$(oc get sub -n "${namespace}"|grep "${caseCatalogName}" |awk '{print $1}' | head -1)
    
    # create subscription
    # fix namespace and channel before creating subscription
    if [[ -z $existing_lakehouse_subscritpion_name ]] ;then
       sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else 
       sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | sed 's|ibm-lakehouse-operator-subscription|'$existing_lakehouse_subscritpion_name'|g' | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat  
    fi
}

# Install utilizing default CLI method
install_operator_native() {
    echo "Inside  launch-impl.sh install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

#    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="ibm-lakehouse"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/ibmWatsonxDataOperatorSetup/files/config"
    echo "setup_definition_files: ${setup_definition_files}"

    lakehouse_addon_crd="${setup_definition_files}/crd/bases/watsonxdata.ibm.com_wxdaddons.yaml"
    lakehouse_crd="${setup_definition_files}/crd/bases/watsonxdata.ibm.com_wxds_crd.yaml"
    # lakehouse4ocp_crd="${setup_definition_files}/crd/bases/dmc.databases.ibm.com_dmc4ocps.yaml"

    validate_file_exists ${lakehouse_addon_crd}
    validate_file_exists ${lakehouse_crd}
    # validate_file_exists ${dmc4ocp_crd}

    operator_files="${setup_definition_files}/manager/manager.yaml"
    validate_file_exists ${operator_files}

    validate_file_exists "${setup_definition_files}/rbac/role.yaml"
    validate_file_exists "${setup_definition_files}/rbac/service_account.yaml"
    validate_file_exists "${setup_definition_files}/rbac/role_binding.yaml"
#    validate_file_exists "${setup_definition_files}/rbac/ibm_dmc_cluster_role.yaml"
#    validate_file_exists "${setup_definition_files}/rbac/ibm_dmc_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required
    # create CDR
    $kubernetesCLI apply ${dryRun} -f ${lakehouse_addon_crd}
    $kubernetesCLI apply ${dryRun} -f ${lakehouse_crd}
    # $kubernetesCLI apply ${dryRun} -f ${dmc4ocp_crd}

    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/role.yaml
#    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/ibm_dmc_cluster_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/service_account.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/role_binding.yaml

    # Append OPERATOR_PREFIX to all resources under rbac
#    sed <"${setup_definition_files}/rbac/ibm_dmc_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|controller-manager|${OPERATOR_PREFIX}-controller-manager|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    existing_lakehouse_subscription_name=$(oc get subscription -n "${namespace}"|grep "${caseCatalogName}" |awk '{print $1}' | head -1)

    if [[ ! -z $existing_lakehouse_subscription_name ]]; then
      # Find installed CSV
      csvName=$($kubernetesCLI get subscription $existing_lakehouse_subscription_name -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
      # Find install plan
      ipName=$($kubernetesCLI get subscription $existing_lakehouse_subscription_name -o jsonpath='{.status.installplan.name}' -n "${namespace}" --ignore-not-found=true)
      # Remove the subscription
      $kubernetesCLI delete subscription $existing_lakehouse_subscription_name -n "${namespace}" --ignore-not-found=true ${dryRun}
      # Remove the IP which was generated by the subscription but does not get garbage collected
      [[ -n "${ipName}" ]] && $kubernetesCLI delete installplan "${ipName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
      # Remove the CSV which was generated by the subscription but does not get garbage collected
      #[[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
      if [ ! -z ${csvName} ]; then
          $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; 
      fi
    fi
    
    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    setup_definition_files="${casePath}/inventory/ibmWatsonxDataOperatorSetup/files/config"
    # echo "Ready to delete crds from setup_definition_directory: ${setup_definition_files}"
    lakehouse_addon_crd="${setup_definition_files}/crd/bases/watsonxdata.ibm.com_wxdaddons.yaml"
    lakehouse_crd="${setup_definition_files}/crd/bases/watsonxdata.ibm.com_wxds_crd.yaml"
    # dmc4ocps_crd="${setup_definition_files}/crd/bases/dmc.databases.ibm.com_dmc4ocps.yaml"
    validate_file_exists ${lakehouse_addon_crd}
    validate_file_exists ${lakehouse_crd}
    #validate_file_exists ${dmc4ocps_crd}
    $kubernetesCLI delete -f "${lakehouse_addon_crd}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete -f "${lakehouse_crd}" --ignore-not-found=true ${dryRun}
    #$kubernetesCLI delete -f "${dmc4ocps_crd}" --ignore-not-found=true ${dryRun}
    echo "Uninstallation done!"
    #done

    # - dependent resources
    #$kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    # Delete catalog source
    #$kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/ibmWatsonxDataOperatorSetup/files/config"
    echo "setup_definition_files: ${setup_definition_files}"

    lakehouse_addon_crd="${setup_definition_files}/crd/bases/watsonxdata.ibm.com_wxdaddons.yaml"
    lakehouse_crd="${setup_definition_files}/crd/bases/watsonxdata.ibm.com_wxds_crd.yaml"
    #dmc4ocp_crd="${setup_definition_files}/crd/bases/dmc.databases.ibm.com_dmc4ocps.yaml"

    validate_file_exists ${lakehouse_addon_crd}
    validate_file_exists ${lakehouse_crd}
    #validate_file_exists ${dmc4ocp_crd}

    operator_files="${setup_definition_files}/manager/manager.yaml"
    validate_file_exists ${operator_files}

    validate_file_exists "${setup_definition_files}/rbac/role.yaml"
    validate_file_exists "${setup_definition_files}/rbac/service_account.yaml"
    validate_file_exists "${setup_definition_files}/rbac/role_binding.yaml"
#    validate_file_exists "${setup_definition_files}/rbac/ibm_dmc_cluster_role.yaml"
#    validate_file_exists "${setup_definition_files}/rbac/ibm_dmc_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"

    $kubernetesCLI delete ${dryRun} -n "${namespace}" deploy ibm-lakehouse-controller-manager
#    sed <"${setup_definition_files}/rbac/ibm_dmc_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/role.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/service_account.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/role_binding.yaml
#    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/rbac/ibm_dmc_cluster_role.yaml
    # delete CRD
    $kubernetesCLI delete ${dryRun} -f ${lakehouse_addon_crd}
    $kubernetesCLI delete ${dryRun} -f ${lakehouse_crd}
    #$kubernetesCLI delete ${dryRun} -f ${dmc4ocp_crd}
}


install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
