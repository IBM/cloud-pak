# Name

IBM&reg; MQ Agent

# Introduction

## Summary

The IBM® MQ Agent is a separate [IBM MQ](https://www.ibm.com/products/mq) component that provides an AI agent to help you find and solve problems with messages building up in your IBM MQ system.

## Features

* AI-powered agent for IBM MQ problem diagnosis
* Helps identify and solve message buildup issues in IBM MQ systems
* Integrates with watsonx.ai for AI capabilities
* MCP (Model Context Protocol) server integration for MQ operations

# Details

## Prerequisites

### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Agent Runtime | 4 | 2 | N/A | 1 |
| MCP Server | 1 | 1 | N/A | 1 |
| Embedding Service | 1 | 1 | N/A | 1 |
| **Total** | **6** | **4** | **N/A** | **1** |

### Licensing and CPU Allocation

This deployment consumes **4 Virtual Processor Cores (VPC)** under IBM MQ Advanced licensing.

CPU allocation is fixed as follows:

- Agent Runtime container: 2 CPU
- MCP Server container: 1 CPU
- Embedding Service container: 1 CPU

CPU values are not user configurable to ensure licensing compliance.

# Installing

## Prerequisites

* Red Hat OpenShift Container Platform 4.12 or later
* At least one amd64 Linux worker node
* Helm v3 or Helm v4
* watsonx.ai credentials (project ID and API key)
* The IBM Licensing Operator needs to be [installed separately](https://www.ibm.com/docs/en/cloud-paks/cp-integration/latest?topic=administration-deploying-license-service)
* IBM MQ connection configuration:
  * CCDT (Client Channel Definition Table) ConfigMap
  * MCP server configuration Secret (.ini file) for authentication settings and other advanced configuration
  * PKCS#12 keystore Secret for TLS connection to queue managers (if required)

## Installation Steps

See the IBM Documentation page for installation steps: <https://ibm.biz/mq-agent-deploy>

## Storage

* No persistent storage required

## Limitations

* **Platform Support**: Red Hat OpenShift Container Platform 4.12 or later only
* **Architecture**: amd64 (x86_64) only
* **watsonx.ai Dependency**: Requires active watsonx.ai instance (for example in US South region) with valid credentials

## Documentation

* [IBM MQ Product Page](https://www.ibm.com/products/mq)
* [License Information](https://www14.software.ibm.com/cgi-bin/weblap/lap.pl?popup=Y&li_formnum=L-JVBD-R9HX59)
