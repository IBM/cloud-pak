# DataPower Operator Case

IBM DataPower Gateway Operator

# Introduction

## Summary

The DataPower Operator packages, deploys, and manages IBM DataPower Gateway as a Kubernetes application. DataPower clusters are created and managed through DataPowerService CustomResources. Each DataPowerService CustomResource will result in a StatefulSet of DataPower pods with a mandatory Deployment of the DataPower Monitor. The DataPowerService allows for full DataPower Application Domain configuration utilizing ConfigMaps and Secrets already present within the cluster. Instead of defining configuration in ConfigMaps and Secrets, it is also possible to use a custom [DataPower Application Image](https://www.ibm.com/docs/en/datapower-gateway/10.5.x?topic=docker-creating-datapower-application) built in-house.

## Features

- [DataPower Application Domain configuration](https://www.ibm.com/docs/en/datapower-operator/1.6?topic=features-configuration-management) with ConfigMaps and Secrets
- Automatic upgrades in DataPower Firmware version channels
- DataPower runtime customization through environment variables
- Customizable persistent storage
- Horizontal auto-scaling
- Define custom Liveness and Readiness probes to fit your application
- Specify custom ServiceAccount to use on StatefulSet
- Custom Labels and Annotations for integration with other services
- High availability of the Operator

# Details

## Prerequisites

To install the CASE, you must have:
- Downloaded the [ibm-datapower-operator CASE bundle](https://github.com/IBM/cloud-pak/tree/master/repo/case/ibm-datapower-operator).
- Installed the latest `cloudctl` [tool](https://github.com/IBM/cloud-pak-cli/releases).
- An OCP [4.12, 4.14, 4.16] cluster.

### SecurityContextConstraints Requirements

#### DataPower Operator

The DataPower Operator currently runs with the default Red Hat `restricted-v2` SCC.

#### DataPower Operand

The DataPower operand currently runs with the default Red Hat `restricted-v2` SCC.

### Resources Required

Minimum scheduling capacity:

| Software           | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| ------------------ | ----------- | ----------- | --------- | ----- |
| DataPower Firmware | 4           | 1           | n/a       | 1     |
| DataPower Operator | 1           | 1           | n/a       | 1     |
| **Total**          | 5           | 2           | n/a       | 1     |

# Installing

There are two primary methods to install the DataPower Operator: using the Helm chart or via the Operator Lifecycle Manager (OLM) installed in your cluster. Either of these install methods will install the DataPower Operator in a targeted namespace. Once the DataPower Operator is installed, you can then create instances of the `DataPowerService` CR in the watched namespace(s).

### Helm

To install the DataPower Operator using Helm, you must use Helm v3. The DataPower Operator Helm chart is available [here](https://github.com/ibm/datapower-operator-chart). The chart readme includes steps to install, and documentation for the available toggles in the `values.yaml`.

### OLM

The [Operator Lifecycle Manager](https://olm.operatorframework.io/) is the best practice method for installing operators. OLM is installed by default in OpenShift clusters, and can also be installed manually in standard Kubernetes clusters.

## Storage

Storage is not required on any components deployed by the DataPower Operator. However, some users may desire persistent storage for their application. To that end, the DataPowerService CustomResource exposes a Service API to configure persistent or ephemeral volumes for the deployed DataPower Application.

## Limitations

- Only one Operator install per namespace is supported.
- Platforms supported:
  - Kubernetes 1.33, 1.34, 1.35, 1.36
  - OpenShift 4.12, 4.14, 4.16, 4.18, 4.19, 4.20, 4.21, 4.22
- Minimum highly available deployment: 3 replicas with 1 cpu and 4Gi Memory

## Configuration


## Documentation

Check out [IBM Documentation](https://www.ibm.com/docs/en/datapower-operator/1.6) for all documentation related to DataPower Operator.
Check out [IBM Documentation](https://www.ibm.com/docs/en/datapower-gateways/10.5.x) for all documentation related to DataPower Firmware.
