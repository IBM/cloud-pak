# Importing a Kibana dashboard from a JSON file

Log in to the IBM Cloud Private console, and navigate to Administer > Logging in the main menu. This will open the Kibana interface in a new tab.

Click Management in Kibana's left-side navigation menu. Click the Import button. Select the JSON file included in this inventory, and click OK.

Dashboards contained in the imported JSON file will now be displayed in the list of Saved Objects, and will be available in the dashboards view.
