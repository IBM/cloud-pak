#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# launch-impl.sh
#
# Defines overrides for standard CASE actions.

# ----- GLOBAL VARS -----
caseCatalogName="ibm-datapower-operator-catalog"
catalogNamespace="openshift-marketplace"
catalogSourceYaml="${scriptDir:?}/op-olm/catalog_source.yaml"
subscriptionYaml="${scriptDir}/op-olm/subscription.yaml"
operatorGroupYaml="${scriptDir}/op-olm/operator_group.yaml"
inventory="datapowerOperator"

crds="${scriptDir}/deploy/crds"

# ----- INSTALL ACTIONS -----

# Installs the catalog source
install_catalog() {

    validate_install_catalog

    echo "-------------Installing catalog source-------------"

    # Verify expected yaml files for install exit
    validate_file_exists "${catalogSourceYaml}"

    # Replace registry if one is provided, otherwise use default icr.io
    if [[ "${registry:=""}" != "" ]]; then
        # Apply yaml files manipulate variable input as required

        local catsrc_image_orig
        catsrc_image_orig=$(grep "image:" "${catalogSourceYaml}" | awk '{ print $2 }')

        # replace original registry with local registry
        local catsrc_image_mod
        catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s|icr.io/||g")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catalogSourceYaml}" | tee >( $kubernetesCLI apply ${dryRun} -f -) | cat
    else
        $kubernetesCLI apply ${dryRun} -f "${catalogSourceYaml}"
    fi

}

# Install utilizing default OLM method
install_operator() {

    # Verify arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing via OLM-------------"

    validate_file_exists "${operatorGroupYaml}"
    validate_file_exists "${subscriptionYaml}"

    # check if catalog source is installed ?
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then

        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"

    fi

    echo "-------------Installing operator group-------------"

    # apply operator group if one is not present in namespace
    if $kubernetesCLI -n $namespace get operatorgroup 2>&1 | grep "No resources found in $namespace namespace"; then
        sed "s|REPLACE_NAMESPACE|${namespace}|g" "$operatorGroupYaml" | $kubernetesCLI apply -n "${namespace}" -f -
    fi

    # - subscription
    if [[ "$channelName" = "" ]]; then
        channelName=$($kubernetesCLI get packagemanifests "datapower-operator" -o jsonpath='{.status.defaultChannel}')
    fi

    sed -e "s|REPLACE_CHANNEL_NAME|$channelName|g" "$subscriptionYaml" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    # Verify arguments are valid
    validate_install_args

    which yq >/dev/null 2>&1 || err_exit "yq required for native install, exiting deployment."

    local namespacedName="${namespace}-datapower-operator"

    # Proceed with install
    echo "-------------Installing native -------------"

    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local manifest_file="${op_cli_files}/native-install-manifest.yaml"
    validate_file_exists "${manifest_file}"

    # Identify document index for each yaml doc in super-manifest
    svc_idx=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " ServiceAccount$" -A 1 | awk '$1 == "doc:" { print $2; exit; }')
    [[ "${svc_idx}" == "" ]] && { err_exit "Missing required service account yaml, exiting deployment."; }
    role_idx=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " Role$" -A 1 | awk '$1 == "doc:" { print $2; exit; }')
    [[ "${role_idx}" == "" ]] && { err_exit "Missing required role yaml, exiting deployment."; }
    rolebind_idx=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " RoleBinding" -A 1 | awk '$1 == "doc:" { print $2; exit; }')
    [[ "${rolebind_idx}" == "" ]] && { err_exit "Missing required role binding yaml, exiting deployment."; }
    op_idx=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " Deployment" -A 1 | awk '$1 == "doc:" { print $2; exit; }')
    [[ "${op_idx}" == "" ]] && { err_exit "Missing required operator yaml, exiting deployment."; }
    clusterrole_idx=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " ClusterRole$" -A 1 | awk '$1 == "doc:" { print $2; exit; }')
    [[ "${clusterrole_idx}" == "" ]] && { err_exit "Missing required cluster role yaml, exiting deployment."; }
    clusterrb_idx=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " ClusterRoleBinding" -A 1 | awk '$1 == "doc:" { print $2; exit; }')
    [[ "${clusterrb_idx}" == "" ]] && { err_exit "Missing required cluster role binding yaml, exiting deployment."; }
    crd_idxs=$(yq eval '.kind | ({"match": ., "doc": documentIndex})' "${manifest_file}" | grep " CustomResourceDefinition" -A 1 | awk '$1 == "doc:" { print $2 }')
    [[ "${crd_idxs}" == "" ]] && { err_exit "Missing required CRD yaml, exiting deployment."; }

    # Apply yaml files - manipulate variable input as required
    
    # - service account
    yq eval "select(documentIndex == \"$svc_idx\") | .metadata.namespace = \"$namespace\"" "${manifest_file}" | sed "s|REPLACE_SECRET|$secret|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    # - crds
    for crd_idx in ${crd_idxs}; do
#        $kubernetesCLI apply -n "${namespace}" -f "${crdYaml}"
      yq eval "select(documentIndex == \"$crd_idx\")" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
      sleep 2
    done

    # - role
    yq eval "select(documentIndex == \"$role_idx\") | .metadata.name = \"$namespacedName\" | .metadata.namespace = \"$namespace\"" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    # - cluster role
    yq eval "select(documentIndex == \"$clusterrole_idx\") | .metadata.name = \"$namespacedName\" | .metadata.namespace = \"$namespace\"" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -f -

    # - role binding
    yq eval "select(documentIndex == \"$rolebind_idx\") | (.subjects[] | select(.name == \"datapower-operator\")).namespace |= \"$namespace\"" "${manifest_file}" |\
      yq eval ".roleRef.name = \"$namespacedName\"" - | yq eval ".metadata.name = \"$namespacedName\" | .metadata.namespace = \"$namespace\"" - | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

   # - clusterrole binding
   yq eval "select(documentIndex == \"$clusterrb_idx\") | (.subjects[] | select(.name == \"datapower-operator\")).namespace |= \"$namespace\"" "${manifest_file}" |\
     yq eval ".roleRef.name = \"$namespacedName\"" - | yq eval ".metadata.name = \"$namespacedName\" | .metadata.namespace = \"$namespace\"" - | $kubernetesCLI apply ${dryRun} -f -

   # - operator
   yq eval "select(documentIndex == \"$op_idx\") | select(.name == \"datapower-operator\").env += {\"name\": \"NAMESPACED_NAME\", \"value\": \"$namespacedName\"} | .metadata.namespace = \"$namespace\"" "${manifest_file}" |\
     $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
}

# ----- CONFIGURE ACTIONS -----

# Validates that the required args were specified for image mirroring
validate_mirror_images_args() {
    # Verify arguments required to mirror correct image-group subset were provided
    local foundError=0
    [[ -z "${image_groups}" ]] && {
            foundError=1
            err "'--groups <image-group>' was not supplied to the '--args' parameter for --action mirror-images"
    }
    # Exit if missing --groups flag and supplied argument
    [[ $foundError -eq 1 ]] && exit 1;
}

# Mirror required images
mirror_images() {
    echo "-------------Mirroring images-------------"

    get_case_name
    get_case_version

    case_archive="${caseName}-${caseVersion}.tgz"

    validate_configure_cluster_airgap_args

    # handle conversion from --filter to --groups
    [[ -n "${image_filters}" ]] && { translate_filters ; }
    validate_mirror_images_args

    "${scriptDir}"/airgap.sh image mirror \
        --dir "${inputcasedir}" \
        ${src_registry:+'--from-registry' "$src_registry"} \
        --to-registry "${registry}" \
        ${mirror_image_chunks:+'--split-size' "$mirror_image_chunks"} \
        ${image_groups:+'--groups' "$image_groups"} \
        ${skip_delta:+'--skip-delta' "$skip_delta"} \
        ${case_archive:+'--archive' "$case_archive"} \
        ${ns_prefix:+'--ns-prefix' "$ns_prefix"} \
        "${dryRun}"
}


# ----- UNINSTALL ACTIONS -----

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f $catalogSourceYaml --ignore-not-found=true ${dryRun}

}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"

    local subscription="ibm-datapower-operator-catalog-subscription"
    local operatorGroup="ibm-datapower-operator-catalog-group"

    # Find installed CSV
    csvName=$($kubernetesCLI get subscription $subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)

    # Remove the subscription
    $kubernetesCLI delete subscription $subscription -n "${namespace}" --ignore-not-found=true ${dryRun}

    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    echo "-------------Uninstalling operator group-------------"
    $kubernetesCLI delete operatorgroup $operatorGroup --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    echo "-------------Uninstalling operator-------------"

    local namespacedName="${namespace}-datapower-operator"

    $kubernetesCLI delete -n "${namespace}" deployment datapower-operator ${dryRun}
    $kubernetesCLI delete -n "${namespace}" serviceaccount datapower-operator ${dryRun}
    $kubernetesCLI delete -n "${namespace}" role "${namespacedName}" ${dryRun}
    $kubernetesCLI delete -n "${namespace}" rolebinding "${namespacedName}" ${dryRun}
    $kubernetesCLI delete clusterrole "${namespacedName}" ${dryRun}
    $kubernetesCLI delete clusterrolebinding "${namespacedName}" ${dryRun}

    # - crds
    if [[ $deleteCRDs -eq 1 ]]; then
        echo "deleting crds"
        for crdYaml in $crds/*; do
            $kubernetesCLI delete -n "${namespace}" -f "${crdYaml}" --ignore-not-found=true ${dryRun}
        done
    fi
}

# ***** END ACTIONS *****

