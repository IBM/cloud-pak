i a
# Maximo Application Suite - Visual Inspection
# Introduction
## Summary
IBM Maximo Visual Inspection puts the power of AI computer vision into the hands of subject matter experts. Building highly accurate customized AI models is remarkably easy and incredibly fast. Enable AI at the edge using existing cameras or commercial, off-the-shelf iOS devices to get immediate, actionable notifications of any emerging issue. This intuitive solution can be deployed on any asset or process, is simple to operate, scales globally, and is engineered to continuously improve model accuracy. Learn more [here](https://www.ibm.com/products/ibm-maximo-visual-inspection)
## Features
* Streamline processes to label, train, monitor and deploy
* Train models to classify images and detect issues
* Introducing auto labeling with deep learning models
* Video analytics made easy for training and inference
* Extend AI solutions with custom models
* Deploy models on-premises, in the cloud, and on edge devices
# Details
## Prerequisites
See prerequisites details [here](https://www.ibm.com/docs/en/maximo-vi)
### Resources Required
| Service | CPU Request | CPU Max  | Memory Request | Memory Max |
| ------- | ----------- | -------- | -------------- | ---------- |
| operator | 0.1 | 0.5 | 128M | 1Gi |
| service api | 0.2 | 5 | 2Gi | 10Gi |
| service-dataset | 0.2 | 4 | 2Gi | 8Gi |
| taskanalysis | 0.1 | 0.5 | 512M | 1Gi |
| ui | 0.2 | 1 | 256M | 1Gi |
| videoms | 0.1 | 2 | 2Gi | 12Gi |
| modelconversion | 0.2 | 2 | 256Mi | 6Gi |
| modelvalidation | 0.2 | 2 | 256Mi | 512Mi |
| datasetfeature | 0.1 | 2 | 1Gi | 10Gi |
| datasetsummarization | 0.1 | 1 | 128Mi | 1Gi |
| edge-manager | 0.2 | 1 | 512Mi | 1Gi |
| dlm-policy | 0.1 | 0.2 | 512Mi | 1Gi |
| auth | 0.1 | 4 | 128Mi | 6Gi |
| **Total** | **1.9** | **25.7** | **9.7 Gi**  | **59Gi**  |

### Resource Requirements - Dynamic pods
Model training, models deployed for inference, and data processing are actions handled by dynamically created pods.  During a typical activity exercising the lifecycle of these pods, resource utilization was monitored to get a typical peak value.  This is used as the recommendation for the minimal CPU and Memory resources that should be available in the environment for the train, inference/test or preprocessing activity.

#### Training
For model training, all models are trained in a single service pod that supports all model types. CPU and memory requirements vary, depending on the model type:

|Model Type|Modality|CPU Min Typical|Memory Min Typical|
|----------|--------|---------------|------------------|
|GoogLeNet|image classification|1.5|2.5Gi|
|Faster R-CNN|object detection|1.5|3Gi|
|SSD|object detection|3|3.5Gi|
|YOLOv3|object detection|4|6Gi|
|Tiny YOLOv3|object detection|4|4.5Gi|
|Anomaly optimized|object detection|8|35Gi|
|Detectron2|instance segmentation|2.5|3Gi|
|High resolution|instance segmentation|1.5|6.5Gi|
|SSN|action detection|2|9Gi|

#### Inference and Preprocessing
For model inference, models are either deployed in the Deep Learning Engine (DLE) service or dedicated services. Dedicated service pods can
only deploy a single model of a particular type in a pod. The DLE service can deploy multiple models of different types in a pod. The DLE
"stuffs" models until the pod no longer has sufficient GPU memory to deploy additional models. When a DLE pod has reached full capacity, a new DLE 
pod is spun up to accomodate additional models. 

The measurements below were calculated by deploying a single model and repeatedly calling the REST endpoint with a 1920x1080 resolution
image. For the DLE, CPU Min and Memory Min are the maximum of all model types that it supports. These values may need to be increased if multiple models
are deployed into the a single DLE pod.

|Service|Models/Function|CPU Min Typical| Memory Min Typical|
|-------|------|-------------|----------------|
|dle|Faster R-CNN, GoogLeNet, SSD, YOLOv3, Tiny YOLOv3, Detectron2, High-Resolution, Anomaly Optimized| 1.5 | 2.5Gi |
|action|Action Detection| 2 | 8Gi |
|preprocessing|Data augmentation| 2 | 1Gi |

# Installing
* https://www.ibm.com/docs/en/maximo-vi
# SecurityContextConstraints Requirements
Maximo Visual Inspection run with a custom SCC `ibm-mas-visualinspection-scc`
* customscc.yaml

Custom SecurityContextConstraints definition:
```
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: false
allowPrivilegedContainer: false
allowedCapabilities:
- CHOWN
- DAC_OVERRIDE
- FOWNER
- FSETID
- KILL
- SETGID
- SETUID
- SETPCAP
- NET_BIND_SERVICE
- NET_RAW
- SYS_CHROOT
allowedUnsafeSysctls: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
  ranges:
  - max: 65535
    min: 1
groups: []
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy is the most restrictive for IBM Maximo Visual Inspection." 
  name: ibm-mas-visualinspection-scc
readOnlyRootFilesystem: false
requiredDropCapabilities: 
- ALL
runAsUser:
  type: MustRunAsRange
  uidRangeMax: 65535
  uidRangeMin: 0
seLinuxContext:
  type: RunAsAny
seccompProfiles: null
supplementalGroups:
  type: MustRunAs
  ranges:
  - max: 65535
    min: 1
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
## Configuration
### RBAC
clusterrole_binding.yaml file needs to be modified to include the correct Maximo visualinspection namespace (Change from system)
* clusterrole.yaml
```
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: ibm-mas-visualinspection-clusterrole
rules:
- apiGroups:
  - 'security.openshift.io'
  resources:
  - 'securitycontextconstraints'
  resourceNames:
  - 'ibm-mas-visualinspection-scc'
  verbs:
  - use
- apiGroups:
  - ""
  resources:
  - nodes
  - pods
  verbs:
  - list
```
* clusterrole_binding.yaml
```
kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  name: ibm-mas-visualinspection-clusterrolebinding
subjects:
- kind: ServiceAccount
  name: ibm-mas-visualinspection-operator
  namespace: system
roleRef:
  kind: ClusterRole
  name: ibm-mas-visualinspection-clusterrole
  apiGroup: rbac.authorization.k8s.io
```
Once modifications have been made to the various yaml, login to the cluster and apply:
```
$ oc login # login as cluster admin
$ oc apply -f clusterrole.yaml
$ oc apply -f clusterrole_binding.yaml
$ oc apply -f customscc.yaml
```
### PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
The operator runs in OpenShift so no PodSecurityPolicy configuration is required.
```
## Storage
  - IBM Maximo Visual Inspection requires storage (at least 100Gi) in the OpenShift cluster. The storage is dynamically created during deployment.
## Limitations
  - The operator only supports single namespace deployment
  - The operator will only watch for resources in its own namespace
  - Multiple instances of the operator can be deployed in a single cluster
  - Each Visual Inspection resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-visualinspection`
## Documentation
 The Maximo Visual Inspection documentation is available [here](https://www.ibm.com/docs/en/maximo-vi)

## License
Maximo Application Suite 8.9 License is available [here](https://ibm.biz/MAS89-License)

## Reason Codes
### Application
* CertificateError: Certificate creation failed
* CertificateNotReady: Public secret cannot be found when used in manual cert mode
* ServiceBindingError: Service binding creation failed
* SecretsError: Secret creation failed
* GrafanaError: Grafana dashboard creation failed
* PVCNotReady: PVC is not ready yet
* InvalidConfiguration: Yaml template configuration failed
* ValidationFailed: Not all pods are in ready state
* ConfigMapError: Config map creation failed
* CronJobError: CronJob creation failed
* JobError: Job creation failed
* DeploymentFailed: Deployment creation failed
* ServiceFailed: Service creation failed
* ServiceMonitorFailed: Servicemonitor creation failed
* NetworkError: Network policy creation failed
* RoleFailed: Role creation failed
* RoleBindingFailed: RoleBinding creation failed
* AppPointsReservationFailed: Catalog reservation failed
* CoreCompatibilityCheckFailure: Compatibility with MAS Core failed
* FoundationCompatibilityCheckFailure: Compatibility with MAS Manage Foundation failed
* COSBucketNameMissing: COS bucket name cannot be found when ObjectStorage is enabled
* COSBucketLookupFailed: COS bucket lookup failed
* Ready: Application is ready

### Workspace
* CertificateNotReady: Public secret cannot be found when used in manual cert mode
* NetworkError: Route creation failed
* RouteNotReady: Route not ready due to secret issues
* WorkspaceSynchronizationFailed: Workspace synchronization failed
* InvalidConfiguration: OIDC Client registration failed
* COSBucketWorkspaceMismatch: COS bucket not associated with workspaceID
* Ready: Workspace is ready



