# OMServer Custom Resource

OMServer defines the specification to run applications or agent and integration servers.  

Each server can refer its own profile, property, affinityAndTolerations etc.  

## OMServer configuration parameters

  The following table explains all the attributes applicable for OMServer CR.
  | Property | Default value | Value type | Required |Description |
  | ---------| --------------| ------------- | ------------------------- | ------------- |
  | `name` |    |  string | Yes | Specify the name of the OMServer. |
  | `affinityAndTolerations` |    |  string | No | Use the name of the affinityAndTolerations from attribute `affinityAndTolerations[].name` to be used by the server.  |
  | `agentServer.names` |   |  array | Yes |  Specify the list of agent servers to run. For ex : `[searchCatalogIndex, scheduleAgent]` |
  | `agentServer.readinessFailRestartAfterMinutes` | `10` | integer | No | Specify the approximate time period in minutes after which the agent restarts if readiness check keeps failing for this period. |
  | `agentServer.terminationGracePeriodSeconds` | `60`   | integer | No |  Specify the time period in seconds allowed for the pod to terminate gracefully, after which the processes running in the pod will be forcibly terminated. |
  | `appServer.dataSource.maxPoolSize` | `50`   | integer | Yes | Specify the dataSource max pool size.              |
  | `appServer.dataSource.minPoolSize` | `10` | integer | Yes | Specify the dataSource min pool size.               |
  | `appServer.ingress.annotations` |    | object | No | Specify any additional annotations for ingress or routes resource as key-value pair. |
  | `appServer.ingress.labels` |    | object | No | Specify any additional labels for ingress or routes resource as key-value pair. |
  | `appServer.ingress.contextRoots` | `[smcfs, sbc, sma, isccs, wsc, adminCenter]`   | array | No | Specify the context roots that can be accessed through ingress. |
  | `appServer.libertyServerXml` | `default-server-xml` | string | No | Provide the configmap containing server.xml for Liberty. |
  | `appServer.livenessCheckBeginAfterSeconds` | `900` | integer | No | Specify the approximate wait time in seconds to begin the liveness check. |
  | `appServer.livenessFailRestartAfterMinutes` | `10` | integer | No | Specify the approximate time period in minutes after which the server restarts, if liveness check keeps failing for this period. |
  | `appServer.serverName` | `DefaultAppServer` | string | No | Specify the name of the app server. |
  | `appServer.service.annotations` |    | object | No | Specify the additional annotations for service resource as key-value pair. |
  | `appServer.service.labels` |    | object | No | Specify the additional labels for service resource as key-value pair. |
  | `appServer.terminationGracePeriodSeconds` | `60` | integer | No | Specify the time period in seconds allowed for the pod to terminate gracefully, after which the processes running in the pod will be forcibly terminated. |
  | `appServer.threads.max` | `100` | integer | Yes | Specify the maximum number of threads for app server. |
  | `appServer.threads.min` | `20` | integer | Yes | Specify the minimum number of threads for app server. |
  | `appServer.vendor` | `websphere` | string | No | Specify the vendor type. |
  | `appServer.vendorFile` | `servers.properties` | string | No | Specify the vendor file. |
  | `image.name` |  | string | No | Specify the name of the image if different from OMEnvironment:spec.image.oms.(app/agent)DefaultName.. |
  | `image.variant` |  | string | No | Image variation to be used as a suffix. For ex: `wsc`, this will be combined with image name to form complete image name `<imageName>-wsc`. |
  | `integration.names` |   |  array | Yes | Specify the list of agent or integration servers to run. |
  | `integration.readinessFailRestartAfterMinutes` | `10` | integer | No | Specify the approximate time period in minutes after which the server restarts if readiness check keeps failing for this period. |
  | `integration.terminationGracePeriodSeconds` | `60`   | integer | No |  Specify the time period in seconds allowed for the pod to terminate gracefully, after which the processes running in the pod will be forcibly terminated. |
  | `podLabels` |    | object | No | Specify additional pod labels as key-value pair. |
  | `profile` |    | string | No | Use the name of the profile from attribute `serverProfiles[].name` to be used by the server.               |
  | `property.customerOverrides` |    | string | No | Use the name of  customerOverrides from attribute `serverProperties.customerOverrides[].groupName` or `serverProperties.customerOverrides[].derivatives[].groupName` |
  | `property.envVars` |    | string | No | Use the name of envVars from attribute `serverProperties.envVars[].groupName` or `serverProperties.envVars[].derivatives[].groupName`  . |
  | `property.jvmArgs` |    | string | No | Use the name of jvmArgs from attribute `serverProperties.jvmArgs[].groupName` or `serverProperties.jvmArgs[].derivatives[].groupName`. |
  | `replicaCount` | `1` | integer | Yes | Specify the number of instances to be deployed for this server. |  

## Sample OMServer schema

  ```yaml
  apiVersion: apps.oms.ibm.com/v1beta1
  kind: OMServer
  metadata:
    name: ""
  spec:
    name: ""
    replicaCount: 1
    # podLabels: {}
    # profile: balanced
    # property:
      # customerOverrides: ""
      # envVars: ""
      # jvmArgs: ""
    # image:
      # name: ""
      # variant: ""

    appServer:
      # serverName: DefaultAppServer
      # dataSource:
        # minPoolSize: 10
        # maxPoolSize: 50
      # threads:
        # min: 20
        # max: 100
      # libertyServerXml: default-server-xml
      # livenessCheckBeginAfterSeconds: 900
      # livenessFailRestartAfterMinutes: 10
      # terminationGracePeriodSeconds: 60
      # ingress:
        # contextRoots: [smcfs, sbc, sma, isccs, wsc, adminCenter]
        # annotations: {}
        # labels: {}
      # service:
        # annotations: {}
        # labels: {}
      # vendor: websphere
      # vendorFile: servers.properties

    agentServer:
      names: []
      # readinessFailRestartAfterMinutes: 10
      # terminationGracePeriodSeconds: 60

    integration:
      names: []
      # readinessFailRestartAfterMinutes: 10
      # terminationGracePeriodSeconds: 60
    # affinityAndTolerations: ""
  ```

  **NOTE**: The commented params are optional for creating omserver.
