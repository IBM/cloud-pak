# IBM Sterling OMS Operator

## Important notes

  1. oc commands are interchangeable with kubectl
  2. Security context constraints(SCC) is defaulted to `restricted`. If someone wants to change it use this annotation in omenvironment `openshift.io/scc: <scc_name>`.
  3. Supported architecture is Intel/AMD

## Prerequisites

Before deploying OMS operator, review and complete the following prerequisites:

- Install Db2 or Oracle database. For more information about the database versions, see [Software Product Compatibility Reports.](https://www.ibm.com/software/reports/compatibility/clarity/index.html) Ensure that the database is accessible from within the cluster.
- Install MQ or any other JMS server. For more information about the system requirements, see [Software Product Compatibility Reports.](https://www.ibm.com/software/reports/compatibility/clarity/index.html) Ensure that the MQ server is accessible from within the cluster.
- [Create a Persistent Volume](#create-a-persistent-volume) with access mode as 'Read write many' and having a minimum of 10 GB hard disk space. Ensure that the PersistentVolume storage is accessible by all containers across the cluster and  the owner group of the PersistenceVolume directory has write access, and the owner group ID is specified in the spec `storage.securityContext.fsGroup` parameter of the OMEnvironment CRD.
- [Create a Secret](#create-a-secret) with the datasource connectivity details.
- [Configuring IBM MQ for agent and integration servers.](#configuring-ibm-mq-for-agent-and-integration-servers)
- If the image to be pulled is in a private registry, add the image pull secret to the namespace and refer the secret name in `image.imagePullSecrets`.

For example:

  ```yaml
  image:
    imagePullSecrets:
    - name: image-pull-credential
  ```

### Create a Secret

To create a Secret, complete the following steps:

1. Configure the values as illustrated in the following <sample_secret_file>.yaml file:

    ```yaml
    apiVersion: v1
    kind: Secret
    metadata:
      name: '<Release-name>-oms-secret'
    type: Opaque
    stringData:
      consoleAdminPassword: '<liberty console admin password>'
      consoleNonAdminPassword: '<liberty console non admin password>'
      dbPassword: '<password for database user>'
      trustStorePassword: '<password for custom TrustStore>'
      keyStorePassword: '<password for custom KeyStore>'
    ```

    **NOTE:** Please check the case of `stringData` params, it is different from what we use in helm chart, like here it is `dbPassword` but in helm chart it is `dbpassword`.
  
2. If you are deploying orderService with OMS add these extra params in the `<sample_secret_file>.yaml`

    ```yaml
    es_username: '<username for elasticsearch>'
    es_password: '<password for elasticsearch>'
    cassandra_username: '<username for cassandra>'
    cassandra_password: '<password for cassandra>'
    ```

    **NOTE:** if you are deploying orderservice independently you need to add the JWT public key. `jwt_oms_public_key` with the value of `<public key for jwt authentication>`

3. Pass the name of the Secret as a value to the `secret` parameter of OMEnvironment spec.
     **NOTE:** For the Secret name, it is recommended that you prefix release name.

4. Run the following command:

     ```sh
       oc create -f <sample_secret_file>.yaml  -n <namespace>
     ```

     A Secret based on the values entered in the <sample_secret_file>.yaml is created and encoded.

### Create a Persistent Volume

To create a PV which will be used to store logs, product files etc. of a pod, complete the following steps:

1. Configure the values as illustrated in the following <sample_pv_file>.yaml file:

    ```yaml
    kind: PersistentVolume
    apiVersion: v1
    metadata:
      name: '<Release-name>-pv-oms'
    spec:
      capacity:
        storage: 10Gi
      accessModes:
        - ReadWriteMany
      storageClassName: default
    ```

   **NOTE:** For more information about PV [see](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)  

2. Pass the name of the PVC as a value to the `storage.name` parameter of OMEnvironment spec, so that this PV can be claimed. Make sure spec of PV should match with the parameters of `storage` spec of OMEnvironment.

3. Run the following command:

     ```sh
       oc create -f <sample_pv_file>.yaml  -n <namespace>
     ```

     A PersistentVolume based on the values entered in the <sample_pv_file>.yaml is created.

### Configuring IBM MQ for agent and integration servers

To configure IBM MQ, complete the following steps:

1. Ensure that the JMS resources that are required for agent and integration servers are configured in IBM MQ and the corresponding `.bindings` file is generated.

2. Create a ConfigMap to store the IBM MQ bindings. For example, run the following command to create a ConfigMap for the  `.bindings` file.

    ```sh
    oc create configmap <config map name> --from-file=<path_to_.bindings_file> -n <namespace>
    ```

3. Specify the ConfigMap name in `mq.bindingConfigName` parameter of OMEnvironment.

### Install Operator Lifecycle Manager

**NOTE:** These instructions are applications only for vanilla Kubernetes platform.

- Follow the steps [here](https://sdk.operatorframework.io/docs/installation/) to install Operator SDK CLI.
- Run the following command to install Operator Lifecycle Manager in your cluster:

  ```bash
  operator-sdk olm install
  ```

## Custom Resources

1. [OMEnvironment](./docs/OMENVIRONMENT_CR.md)
2. [OMServer](./docs/OMSERVER_CR.md)
3. [OrderService](./docs/ORDER_SERVICE_CR.md)

## Installing and uninstalling OMS Operator

For installing and uninstalling the oms operator check [this](./docs/INSTALL_OPERATOR.md).

## Air gap Installation

For installing OMS operator in airgap environment check [this](./docs/AIRGAP.md).

## Status Matrix for CRs

- Each CR has 3 status conditions which are Progressing, Available and Failed.
- A CR can be in Progressing state because of many reasons, such as waiting for some condition to complete, executing some resource , initializing etc.
- For a CR to be in Available state it must complete all of its conditions.

  The following table explains the different CRs statuses with a sample message and reason for that status.

  | Type                      | Status | Reason                       | Message (Sample)                              |
  | ------------------------- | ------ | ---------------------------- | --------------------------------------------- |
  | ***OMEnvironment***
  | **Executing**
  | OMEnvironmentProgressing  | True   | Initialised                  | OMEnvironment Initialized                     |
  | OMEnvironmentProgressing  | True   | Waiting                      | Waiting for PVC to bind                       |
  | OMEnvironmentProgressing  | True   | Executing                    | Created ConfigMap: common-server-xml          |
  | **Completed (Terminal)**
  | OMEnvironmentAvailable    | True   | ExecutionCompleted           | OMEnvironment is Ready                        |
  | OMEnvironmentProgressing  | False  | ExecutionCompleted           | Created ConfigMap: common-server-xml          |
  | **Failed/Retrying**
  | OMEnvironmentFailed       | True   | ExecutionFailed              | Failed to create OMServer: server1            |
  | OMEnvironmentProgressing  | True   | ExecutionFailed              | Failed to create OMServer: server1            |
  | **Failed (Terminal)**
  | OMEnvironmentFailed       | True   | ExecutionFailed              | Failed to create OMServer: server1            |
  | OMEnvironmentProgressing  | False  | ExecutionFailed              | Failed to create OMServer: server1            |
  | |
  | ***DataManager***
  | **Executing**
  | DataSetupProgressing      | True   | Initialised                  | Data setup Initialized                        |
  | OMEnvironmentProgressing  | True   | Executing                    | Executing Datasetup                           |
  | **Completed (Terminal)**
  | DataSetupCompleted        | True   | ExecutionCompleted           | Data setup Completed                          |
  | DataSetupProgressing      | False  | ExecutionCompleted           | Data setup Completed                          |
  | **Failed/Retrying**
  | DataSetupFailed           | True   | ExecutionFailed              | Data setup Failed                             |
  | DataSetupProgressing      | True   | ExecutionFailed              | Data setup Failed                             |
  | **Failed (Terminal)**
  | DataSetupFailed           | True   | ExecutionFailed              | Data setup Failed                             |
  | DataSetupProgressing      | False  | ExecutionFailed              | Data setup Failed                             |
  | |
  | ***OMServer***
  | **Executing**
  | OMServerProgressing       | True   | Initialised                  | OMServer Initialized                          |
  | OMServerProgressing       | True   | WaitingOnDatasetupCompletion | Waiting data setup completion                 |
  | OMServerProgressing       | True   | Waiting                      | Waiting for ingress creation                  |
  | OMServerProgressing       | True   | Executing                    | Created Deployment: omserver1                 |
  | **Completed (Terminal)**
  | OMServerAvailable         | True   | ExecutionCompleted           | OMServer is Ready                             |
  | OMServerProgressing       | False  | ExecutionCompleted           | Created Deployment: omserver1                 |
  | **Failed/Retrying**
  | OMServerFailed            | True   | ExecutionFailed              | Failed to create Deployment: server1          |
  | OMServerProgressing       | True   | ExecutionFailed              | Failed to create Deployment: server1          |
  | **Failed (Terminal)**
  | OMServerFailed            | True   | ExecutionFailed              | Failed to create Deployment: server1          |
  | OMServerProgressing       | False  | ExecutionFailed              | Failed to create Deployment: server1          |
