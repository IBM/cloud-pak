# Configuring Server Profile

Server profiles allow you to define common configurations for CPU and Memory requirements that can be applied to a set of OMS workloads like appserver, agent/integration servers etc. Workloads that requires a specific set of CPU and Memory resources can be grouped under a single profile. Server profiles allows you  to easily manage resoure requirements for a set of workloads in a common location.

By default, 3 server profiles are available

## balanced

`balanced` profile can be used for typical OMS workloads that has small to moderate use of CPU and Memory resources. Following is the resource requests and limits for `balanced` profile.

```yaml
  requests:
    memory: "1Gi"
    cpu: "100m"
  limits:
    memory: "1.5Gi"
    cpu: "1000m"
```

## memory

`memory` profile can be used for workloads that need more memory for processing. Following is the resource requests and limits for `memory` profile.

```yaml
  requests:
    memory: "1.5Gi"
    cpu: "100m"
  limits:
    memory: "4.5Gi"
    cpu: "2000m"
```

## compute

`compute` profile can be used for workloads that need more CPU cycles for processing. Following is the resource requests and limits for `compute` profile.

```yaml
  requests:
    memory: "1Gi"
    cpu: "1000m"
  limits:
    memory: "2.5Gi"
    cpu: "4000m"
```

## Custom Server Profiles

You can also define custom server profiles apart from the default profiles provided, to configure resource requirements for your specific needs. You can configure `serverProfiles` property of `OMEnvironment` custom resource. For more information on configuring custom server profiles, click here
