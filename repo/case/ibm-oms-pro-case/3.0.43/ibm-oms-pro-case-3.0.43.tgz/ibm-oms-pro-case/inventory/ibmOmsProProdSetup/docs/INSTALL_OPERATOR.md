# Install the IBM Sterling OMS Operator

The IBM Sterling OMS Operator simplifies the deployment and management of the OMS application on Kubernetes-based platforms, including Red Hat OpenShift. Depending on your environment and requirements, there are multiple ways to install the operator. In this documentation, we will cover the installation of the OMS operator both with and without the [**Operator Lifecycle Manager (OLM)**](https://olm.operatorframework.io/).

## Table of Contents

- [Install the IBM Sterling OMS Operator](#install-the-ibm-sterling-oms-operator)
  - [Table of Contents](#table-of-contents)
  - [Prerequisites](#prerequisites)
  - [Installing the OMS Operator **With OLM**](#installing-the-oms-operator-with-olm)
    - [Using the OpenShift Console](#using-the-openshift-console)
      - [Create the OMS Operator catalog source](#create-the-oms-operator-catalog-source)
      - [Installing the OMS Operator](#installing-the-oms-operator)
      - [Uninstalling the OMS Operator](#uninstalling-the-oms-operator)
    - [Using the Command Line](#using-the-command-line)
      - [Install the OMS Operator using the Command Line](#install-the-oms-operator-using-the-command-line)
      - [Uninstalling the OMS Operator using the Command Line](#uninstalling-the-oms-operator-using-the-command-line)
    - [Rolling Back or Installing a Specific OMS Operator Version](#rolling-back-or-installing-a-specific-oms-operator-version)
  - [Installing the OMS Operator **Without OLM**](#installing-the-oms-operator-without-olm)
    - [Generate the key and certificate for the Webhook](#generate-the-key-and-certificate-for-the-webhook)
    - [Download the case](#download-the-case)
    - [Install the OMS Operator](#install-the-oms-operator)
    - [Upgrade or roll back to a specific Operator Version (**without OLM**)](#upgrade-or-roll-back-to-a-specific-operator-version-without-olm)
    - [Uninstall the OMS Operator](#uninstall-the-oms-operator)

## Prerequisites

1. Install the OpenShift CLI (`oc`) [[↗]](https://docs.openshift.com/container-platform/latest/cli_reference/openshift_cli/getting-started-cli.html) or the Kubernetes command-line tool (`kubectl`) [[↗]](https://kubernetes.io/docs/tasks/tools/#kubectl).
2. Install the Operator SDK command-line tool (`operator-sdk`) [[↗]](https://docs.openshift.com/container-platform/latest/cli_reference/openshift_cli/getting-started-cli.html).
3. Install (`yq`) [[↗]](https://github.com/mikefarah/yq).

> **Important:**
>
> - Ensure that you have administrator authority or have been granted the appropriate role-based access control (RBAC) to administer the cluster before installing OLM. For more information, see [role-based access control good practices](https://www.ibm.com/links?url=https%3A%2F%2Fkubernetes.io%2Fdocs%2Fconcepts%2Fsecurity%2Frbac-good-practices%2F).
>
> - If you are using OpenShift, OLM [[↗]](https://olm.operatorframework.io/) is installed by default, so you do not need to install the Operator SDK command-line tool.
>
> - The OLM is not included in the out-of-the-box offering. For inquiries about OLM, you must contact the OLM product team.
>
> - If you want to [install the OMS Operator **without OLM**](#installing-the-oms-operator-without-olm), you do not need to install the Operator SDK command-line tool.
>
> - If you choose to install the OMS Operator using OLM, the `yq` tool is not required.
>
> - If you choose to install the OMS Operator without using OLM, the `yq` tool is required to automate the setup process. If you prefer not to install `yq`, you can manually set the required environment variables  `OPERATOR_VERSION`, `OPERATOR_DIGEST`, `ODS_DIGEST`. You can locate the necessary values for these variables from the case.
>
>   To set the variables manually, use the following commands:
>
>   ```bash
>   export OPERATOR_VERSION=<version_value>
>   export OPERATOR_DIGEST=<digest_value>
>   export ODS_DIGEST=<digest_value>
>   ```

## Installing the OMS Operator **With OLM**

### Using the OpenShift Console

#### Create the OMS Operator catalog source

1. Log in to the Red Hat OpenShift Container Platform web console.
2. If you are not in the Administrator perspective, from the context selector in the navigation menu, select Administrator.
3. Click the **plus** icon on the top right corner of the screen. Click **Import YAML** and add the following catalog:

    ```yaml
    apiVersion: operators.coreos.com/v1alpha1
    kind: CatalogSource
    metadata:
      name: ibm-oms-catalog
      namespace: <catalog_source_namespace>
    spec:
      displayName: IBM OMS Operator Catalog
      image: <image_name>
      publisher: IBM
      sourceType: grpc
    ```

    - Replace `<catalog_source_namespace>` with the namespace where you want to install the operator.  
      Example: `openshift-marketplace`.

    - Replace `<image_name>` with the appropriate IBM OMS Operator catalog image based on your needs:  
      - **Enterprise Edition**: `icr.io/cpopen/ibm-oms-ent-case-catalog:v1.0`  
      - **Professional Edition**: `icr.io/cpopen/ibm-oms-pro-case-catalog:v1.0`
      - **IBM Operator Catalog**: `icr.io/cpopen/ibm-operator-catalog:latest`

4. Click **Create** to apply the CatalogSource.

5. Make sure the newly created catalog source is in **READY** status before moving to the next step.

#### Installing the OMS Operator

1. Navigate to **Operators** > **OperatorHub** from the context selector in the navigation menu.  
   - The **OperatorHub** page will open, displaying available operators.

2. In the search bar, type **IBM Sterling Order Management** (or part of the name) to locate the OMS Operator.

3. Click on the **IBM Sterling OMS Operator** card to open its details.

4. Click **Install** to proceed with the installation.

5. Configure the installation settings:
   - **Version**: Select the version of the operator to install.
   - **Installation Mode**: Choose where to deploy the operator:
     - **All namespaces** (Cluster-wide installation).
     - **Single namespace** (Specific to a project/namespace).
   - **Update Approval**: Choose either **Automatic** (for auto-updates) or **Manual** (requires approval for updates).

6. Click **Install** to start the installation process.

7. Wait for a minute or two. Once completed, you will see the message **"Installed operator: ready for use"** in the status section.
    ![image info](./imgs/op-installed.png)


#### Uninstalling the OMS Operator

1. Navigate to **Operators** > **Installed Operators** from the context selector in the navigation menu.  
   - The **Installed Operators** page will open, displaying the list of installed operators.

2. Locate the **IBM Sterling OMS Operator** in the list of installed operators.

3. Click the **three-dot menu icon** (⋮) on the right of the operator, and select **Uninstall Operator** from the dropdown menu.

4. Confirm the uninstallation to remove the operator from the cluster.

5. Navigate to **Administration** > **CustomResourceDefinitions** in the navigation menu.  
   - The list of custom resource definitions (CRDs) will open.

6. In the search bar, type **"apps.oms.ibm.com"** to filter the CRDs created by the OMS Operator.

7. Locate and delete the following CRDs created by the OMS Operator:  
   - `CallCenter`  
   - `OMEnvironment`  
   - `OMServer`  
   - `OrderHub`  
   - `OrderService`

### Using the Command Line

#### Install the OMS Operator using the Command Line

> **Important:**
>
> - The following steps apply to both Vanilla Kubernetes and Red Hat OpenShift.
> - If you are using Vanilla Kubernetes, install OLM by running the following command:  
>
>   ```bash
>   operator-sdk olm install
>   ```

1. Create the catalog source as described in [Create the OMS Operator Catalog Source](#create-the-oms-operator-catalog-source) and save it in a file `oms_catsrc.yaml`.

2. Run this command `oc apply -f oms_catsrc.yaml` to create the catalog source.

3. Run the following command to check the newly created catalog source and ensure it is in the **READY** state before proceeding to the next steps:

    ```bash
    kubectl describe catalogsource <catalog_source_name> -n <namespace>
    ```

4. If you are using a non-OpenShift Kubernetes cluster, you must create an `OperatorGroup` to define the scope (cluster-wide or namespace-specific) in which the operator will run. Follow these steps:

    - **Cluster-Wide Scope**:

        ```bash
        oc apply -f - <<EOF
        apiVersion: operators.coreos.com/v1
        kind: OperatorGroup
        metadata:
          name: oms-operator-global
          namespace: <namespace>
        spec: {}
        EOF
        ```

    - **Namespace-Specific Scope**:

        ```bash
        oc apply -f - <<EOF
        apiVersion: operators.coreos.com/v1
        kind: OperatorGroup
        metadata:
            name: oms-operator-local
            namespace: <namespace>
        spec:
            targetNamespaces:
            - <target_namespace>
        EOF
        ```

    > **Note:**
    >
    > - Replace `<namespace>` with the desired namespace.
    > - For namespace-specific scope, replace `<target_namespace>` with the actual namespace name to be monitored.
    > - As of now, we only support either a **single namespace** or **all namespaces**.

5. Create a subscription by running this command:

    ```bash
    oc apply -f - <<EOF
    apiVersion: operators.coreos.com/v1alpha1
    kind: Subscription
    metadata:
        name: <subscription_name>
        namespace: <namespace>
    spec:
        channel: v1.0
        installPlanApproval: <plan_approval>
        name: ibm-oms-<edition>
        source: <catalog_source_name>
        sourceNamespace: <CatalogSource_namespace>
    EOF
    ```

    - Replace `<subscription_name>` with the desired subscription name.
    - Replace `<namespace>` with the namespace where you want to install the operator.
    - Set `<plan_approval>` to either **Manual** or **Automatic**:
        - **Manual**: You must manually approve pending upgrades.
        - **Automatic**: Upgrades initiate automatically as soon as a new operator version is available in the selected channel.
    - Set `<edition>` to either `ent` (Enterprise) or `pro` (Professional), depending on the catalog source configured in the previous step.
    - Replace `<catalog_source_name>` with the catalog source name you created in previous step.
    - Replace `<CatalogSource_namespace>` with the namespace where you installed the catalog source.

6. Wait for a minute or two. Then, verify the installed operator using one of the following commands:

    - **Check the Subscription**:

        ```bash
        oc describe sub <subscription_name> -n <namespace>
        ```

    - **Check the OMS operator manager pod**:

        ```bash
        oc get po |grep "ibm-oms-controller-manager" -n <namespace>
        ```

#### Uninstalling the OMS Operator using the Command Line

To uninstall the OMS Operator, run the following commands:

1. Delete the ClusterServiceVersion (CSV):

    ```bash
    oc delete csv ibm-oms-<edition>.v<version> -n <namespace>
    ```

    Replace `<edition>` with either `ent` (Enterprise) or `pro` (Professional), `<version>` with the installed operator version, and `<namespace>` with the namespace where the operator is installed.

2. Delete the Subscription:

    ```bash
    oc delete sub <subscription_name> -n <namespace>
    ```

    Replace `<subscription_name>` with the name of your subscription and `<namespace>` with the namespace where it was created.

3. Delete the CustomResourceDefinitions (CRDs):

    ```bash
    oc delete crd callcenters.apps.oms.ibm.com \
                  omenvironments.apps.oms.ibm.com \
                  omservers.apps.oms.ibm.com \
                  orderhubs.apps.oms.ibm.com \
                  orderservices.apps.oms.ibm.com
    ```

    This will remove all CRDs created by the OMS Operator.

### Rolling Back or Installing a Specific OMS Operator Version

To roll back to a previous operator version, you need to delete the currently installed operator and reinstall the desired version.

If your installed operator version is not the latest, you will have the option to upgrade to the latest version.

## Installing the OMS Operator **Without OLM**

### Generate the key and certificate for the Webhook

In the OMS Operator, we use webhooks to perform validation and mutation. For these webhooks to work, a key and certificate must be manually generated. You can generate them using the following commands:

```bash
# Set the installation namespace
export INSTALL_NAMESPACE="oms"

# Generate the root CA and cert
openssl req -x509 \
            -sha256 -days 35600 \
            -nodes \
            -newkey rsa:2048 \
            -subj "/CN=oms.ibm.com/C=US/L=Boston" \
            -keyout rootCA.key -out rootCA.crt

# Generate the key for the service
openssl genrsa -out tls.key 2048

# Generate certificate signing request (CSR) using server private key
openssl req -newkey rsa:2048 -nodes -keyout tls.key \
            -subj "/C=US/ST=MA/O=IBM/CN=oms-webhook-service" \
            -out tls.csr

# Generate SSL certificate with self signed CA
openssl x509 -req \
        -extfile <(printf "subjectAltName=DNS:oms-webhook-service.$INSTALL_NAMESPACE.svc,DNS:www.oms-webhook-service.$INSTALL_NAMESPACE.svc") \
        -days 36500 \
        -in tls.csr \
        -CA rootCA.crt -CAkey rootCA.key -CAcreateserial \
        -out tls.crt

# Create the TLS secret
oc create secret generic ibm-oms-controller-manager-service-cert \
                        --from-file=tls.key=$(pwd)/tls.key \
                        --from-file=tls.crt=$(pwd)/tls.crt \
                        -n $INSTALL_NAMESPACE
```

> **Note:**
>
> - The **-days** flag determines the validity of the certificates. Adjust it based on your requirements.
> - Replace **INSTALL_NAMESPACE** with the namespace where the OMS Operator is installed.

### Download the case

Use the following commands to download and extract the IBM OMS Operator case:

```bash
# Set the version and edition variables
export CASE_VERSION="3.0.26"
export EDITION="ent"

# Download the case
curl -O https://raw.githubusercontent.com/IBM/cloud-pak/master/repo/case/ibm-oms-$EDITION-case/$CASE_VERSION/ibm-oms-$EDITION-case-$CASE_VERSION.tgz

# Extract the case
tar -xzf ibm-oms-$EDITION-case-$CASE_VERSION.tgz 
```

> **Important:** Ensure that you update the CASE_VERSION and EDITION variables to match your requirements.
>
> - CASE_VERSION: Use the specific version of the operator you want to install.
> - EDITION: Use **ent** for **Enterprise Edition** or **pro** for **Professional Edition**.

### Install the OMS Operator

Install the OMS operator by running the following commands:

```bash
export IMAGE_REPO="icr.io/cpopen"
export EDITION="ent"
export INSTALL_NAMESPACE="oms"
export CAP_EDITION=$(echo "$EDITION" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
export CA_BUNDLE=$(cat $(pwd)/rootCA.crt | base64)
export RESOURCE_FILE_PATH="ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}ProdSetup/resources.yaml"
export OPERATOR_VERSION=$(yq e '.resources.resourceDefs.containerImages[] | select(.image == "cpopen/ibm-oms-operator") | .tag' $RESOURCE_FILE_PATH | cut -d'-' -f1)
export OPERATOR_DIGEST=$(yq e '.resources.resourceDefs.containerImages[] | select(.image == "cpopen/ibm-oms-operator") | .digest' $RESOURCE_FILE_PATH)
export ODS_DIGEST=$(yq e '.resources.resourceDefs.containerImages[] | select(.image == "cpopen/ibm-oms-ods") | .digest' $RESOURCE_FILE_PATH)

# Create the Custom Resource Definitions (CRDs)
oc apply -f ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}ProdSetup/files/crds

# Create the required RBAC
oc apply -f ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}ProdSetup/files/rbac

# Create the webhooks
sed -e 's|CA_BUNDLE|'$CA_BUNDLE'|g' \
    -e 's|INSTALL_NAMESPACE|'$INSTALL_NAMESPACE'|g' \   
    ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}ProdSetup/files/webhook.yaml | kubectl apply -n $INSTALL_NAMESPACE -f -

# Create the OMS Operator deployment
sed -e 's|OPERATOR_VERSION|'$OPERATOR_VERSION'|g' \
    -e 's|EDITION|'$EDITION'|g' \
    -e 's|OPERATOR_DIGEST|'$OPERATOR_DIGEST'|g' \
    -e 's|ODS_DIGEST|'$ODS_DIGEST'|g' \
    -e 's|IMAGE_REPO|'$IMAGE_REPO'|g' \
    ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}ProdSetup/files/deploy.yaml | kubectl apply -n $INSTALL_NAMESPACE -f -
```

> - Replace **EDITION**, **INSTALL_NAMESPACE**, and **IMAGE_REPO** with the edition, the namespace, and the repository you want.
> - If you want to install a specific version of the operator, manually set **OPERATOR_VERSION**, **OPERATOR_CHECKSUM**, and **ODS_CHECKSUM** with the desired values.
> - Ensure that the **rootCA.crt** file exists in the current working directory when setting **CA_BUNDLE**.

### Upgrade or roll back to a specific Operator Version (**without OLM**)

If you want to upgrade or roll back to a specific OMS Operator version. You can [download the respective case](#download-the-case) and follow the [Install the OMS Operator](#install-the-oms-operator) with the updated version and digests details.

> **Note:** The `deploy.yaml`, `rbac.yaml`, and `webhooks.yaml` files are included only in case version `3.0.26` and later. If you are rolling back to an earlier version, ensure you download the corresponding case with the necessary CRDs and also retrieve the files from case version `3.0.26` or later before proceeding.

### Uninstall the OMS Operator

To uninstall the OMS Operator when it was installed **without OLM**, follow the steps outlined in [Uninstalling the OMS Operator using the Command Line](#install-the-oms-operator-using-the-command-line), with a few additional actions:

1. Set the Namespace

    Export the namespace where the OMS Operator is installed:

    ```bash
    export INSTALL_NAMESPACE="oms"
    ```

2. Delete the secret

    Remove the service certificate secret:

    ```bash
    oc delete secret ibm-oms-controller-manager-service-cert -n $INSTALL_NAMESPACE
    ```

3. Delete the service

    Delete the webhook service:

    ```bash
    oc delete svc oms-webhook-service -n $INSTALL_NAMESPACE
    ```

4. Delete the Webhook Configurations

    Remove both the mutating and validating webhook configurations:

    ```bash
    oc delete MutatingWebhookConfiguration oms-mutating-webhook-configuration -n $INSTALL_NAMESPACE
    oc delete ValidatingWebhookConfiguration oms-validating-webhook-configuration -n $INSTALL_NAMESPACE
    ```
