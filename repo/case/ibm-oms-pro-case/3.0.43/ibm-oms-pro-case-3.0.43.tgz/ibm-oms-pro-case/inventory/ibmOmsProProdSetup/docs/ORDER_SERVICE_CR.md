# OrderService Custom Resource

Used for deployment of orderService servers.  

## Orderservice configuration parameters

  The following table explains all the attributes applicable for orderService spec of OMEnvironment.
  | Property | Default value | Value type | Required | Description |
  | ---------| --------------| ------------- | ------------------------- | ------------- |
  | `cassandra.keyspace` |   | string | Yes | Keyspace for cassandra. |
  | `configuration.additionalConfig` |   | object | No | Specify any additional properties. |
  | `configuration.jwt_algorithm` | `RS256` | string | Yes | Specify the algorithm that is used for signing the JWT token. |
  | `configuration.jwt_audience` |   |  string | Yes | Specify to whom you intend to send the JWT token. |
  | `configuration.jwt_ignore_expiration` |   | boolean | Yes | Specify whether to ignore expired token or not.|
  | `configuration.jwt_issuer` |   | string | Yes | Specify the issuer name when creating a JWT token for a current user. |
  | `elasticsearch` |   | object | Yes | Specify elasticsearch Configuration. |
  | `orderServiceVersion` |   | string | No | Specify order service app version. |
  | `profile` |   | string | No | Name of serverProfile to be used for the instance. |
  | `replicaCount` |   | integer | No | Specify the number of server instances to be deployed. |
  | `podLabels` |    | object | No | Specify labels for pod as key-value pair. |  

  The following table explains all the attributes applicable for both cassandra and elasticsearch.
  | Property | Default value | Value type | Required | Description |
  | ---------| --------------| ------------- | ------------------------- | ------------- |
  | `contactPoints` |   | string | No | Contact Points for cassandra and elasticsearch. |
  | `createDevInstance.profile` |  | string | Yes | Name of serverProfile to be used for the instance.|
  | `createDevInstance.storage.accessMode` | `ReadWriteMany` | string | No   | Specify the access mode for the Persistent Volume claim. |
  | `createDevInstance.storage.capacity` | `10Gi` | string or integer | No | Specify the capacity for the Persistent Volume claim. |
  | `createDevInstance.storage.name` |   | string | Yes |  Name of Persistent Volume claim. |
  | `createDevInstance.storage.storageClassName` | `default` | string | No | Specify the storage class for the Persistent Volume claim. |  

## Sample Orderservice schema

  ```yaml
  apiVersion: apps.oms.ibm.com/v1beta1
  kind: OrderService
  metadata:
    name: ""
  spec:
    license:
      accept: false
    secret: ""
    replicaCount: 1
    # profile: balanced
    # orderServiceVersion: ""
    # podLabels: {}

    image:
      tag: ""
      repository: ""
      # pullPolicy: IfNotPresent
      # imageName: orderservice
      # imagePullSecrets:
      # - name: ""

    networking:
      ingress:
        host: ""
        # annotations: {}
        # labels: {}
        # ssl:
          # enabled: false
          # identitySecretName: ""

    networkPolicy:
      <kubernetes-network-policy-spec>

    security:
      trust:
        # storeLocation: ""
        # trustedCertDir: ""
        storeType: PKCS12
        trustJavaCACerts: true

    # serverProfiles:
    # - name: ""
      # resources:
        # limits:
          # cpu: 
          # memory: 
        # requests:
          # cpu: 
          # memory: 

    configuration:
      jwt_algorithm: ""
      jwt_audience: ""
      jwt_ignore_expiration: 
      jwt_issuer: ""
      # additionalConfig: {}

    cassandra:
      keyspace: ""
      # contactPoints: ""
      # createDevInstance:
        # profile: balanced
        # storage:
          # name: ""
          # accessMode: ""
          # capacity: 
          # storageClassName: ""

    elasticsearch:
      # contactPoints: ""
      # createDevInstance:
        # profile: balanced
        # storage:
          # name: ""
          # accessMode: ""
          # capacity: 
          # storageClassName: ""

    # additionalMounts:
      # configMaps:
      # - name: ""
        # mountPath: ""
        # subPath: ""
        # subPathExpr: ""
        # readOnly: false
        # mountPropagation: ""
        # matchLabels: {}
      # secrets:
      # - name: ""
        # mountPath: ""
        # subPath: ""
        # subPathExpr: ""
        # readOnly: false
        # mountPropagation: ""
        # matchLabels: {}
      # storages:
      # - name: ""
        # mountPath: ""
        # storageClassName: ""
        # accessMode: ""
        # capacity: 
        # matchLabels: {}
  ```

  **NOTE**: The commented params are optional for creating orderservice.
