# Air Gap Installation

You can install certified containers in an air gap environment where your Kubernetes cluster does not have access to the internet. Therefore, it is important to properly configure and install the certified containers in such an environment.

## Table of Contents

- [Air Gap Installation](#air-gap-installation)
  - [Table of Contents](#table-of-contents)
  - [Preparation](#preparation)
    - [Prerequisites](#prerequisites)
    - [Downloading Sterling Order Management Software case](#downloading-sterling-order-management-software-case)
    - [Log In to Source and Target Repositories](#log-in-to-source-and-target-repositories)
      - [Log In to the Entitled Registry](#log-in-to-the-entitled-registry)
      - [Log In to Your Local Registry (If Applicable)](#log-in-to-your-local-registry-if-applicable)
    - [Mirroring the container images](#mirroring-the-container-images)
  - [Installation Methods](#installation-methods)
    - [Installing the OMS Operator **With OLM**](#installing-the-oms-operator-with-olm)
      - [Using the out-of-the-box OMS Operator Catalog Image](#using-the-out-of-the-box-oms-operator-catalog-image)
        - [OpenShift Clusters](#openshift-clusters)
        - [Vanilla Kubernetes Clusters](#vanilla-kubernetes-clusters)
      - [Rebuild the OMS Operator Catalog image](#rebuild-the-oms-operator-catalog-image)
      - [Install the OMS Operator](#install-the-oms-operator)
    - [Installing the OMS Operator **Without OLM**](#installing-the-oms-operator-without-olm)

## Preparation

### Prerequisites

1. Install the command-line YAML processor (`yq`) [[↗]](https://github.com/mikefarah/yq).
2. Install the container tool (`docker`) [[↗]](https://docs.docker.com/engine/install) or (`podman`) [[↗]](https://podman.io/docs/installation).
3. Install the utility that performs various operations on container images and image repositories (`skopeo`) [[↗]](https://github.com/containers/skopeo/blob/main/install.md).
4. A local registry to store the mirrored images.

> You can use **docker**, **podman**, **skopeo** to mirror the images. However, this guide will use **skopeo** to ensure digests remain consistent.

### Downloading Sterling Order Management Software case

Use the following commands to download and extract the IBM OMS Operator case:

```bash
# Set the version and edition variables
export CASE_VERSION="3.0.25"
export EDITION="ent"

# Download the case
curl -O https://raw.githubusercontent.com/IBM/cloud-pak/master/repo/case/ibm-oms-$EDITION-case/$CASE_VERSION/ibm-oms-$EDITION-case-$CASE_VERSION.tgz

# Extract the case
tar -xzf ibm-oms-$EDITION-case-$CASE_VERSION.tgz 
```

> **Important:** Ensure that you update the CASE_VERSION and EDITION variables to match your requirements.
>
> - CASE_VERSION: Use the specific version of the operator you want to install.
> - EDITION: Use **ent** for **Enterprise Edition** or **pro** for **Professional Edition**.

### Log In to Source and Target Repositories

To mirror the images, you'll need to log in to the appropriate repositories:

#### Log In to the Entitled Registry

Run the following command to authenticate with the entitled registry and enable image pulls:

```bash
skopeo login icr.io
```

#### Log In to Your Local Registry (If Applicable)

If your local registry requires authentication to push images, use the following command:

```bash
skopeo login your-local-registry
```

>
> Replace **your-local-registry** with the URL of your local registry.
>

### Mirroring the container images

The container images are retrieved from the source registry and uploaded to your local registry to enable offline installation. Use the following commands to perform this process:

```bash
export TARGET_REPO="docker.io/my_username/my_repo"
export EDITION="ent"

export SOURCE_REPO="icr.io"
export CAP_EDITION=$(echo "$EDITION" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
export OP_CASE_INVENTORY="ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}ProdSetup"
export APP_CASE_INVENTORY="ibm-oms-${EDITION}-case/inventory/ibmOms${CAP_EDITION}Prod"
export CASE_INVENTORIES=("$OP_CASE_INVENTORY" "$APP_CASE_INVENTORY")

echo "Mirroring images from $SOURCE_REPO to $TARGET_REPO..."
for INVENTORY in "${CASE_INVENTORIES[@]}"; do
  echo -e "\nProcessing inventory: $INVENTORY"
  IMAGES_AND_TAGS=$(
    yq e '
    .resources.resourceDefs.containerImages[].image
    + ":"
    + .resources.resourceDefs.containerImages[].tag
    ' $APP_CASE_INVENTORY/resources.yaml
  )
  while IFS= read -r img; do
    tgt_img_and_tag=$(echo "$img" | awk -F'/' '{print $NF}')
    echo "Copy $SOURCE_REPO/$img to $TARGET_REPO/$tgt_img_and_tag"
    skopeo copy --all --remove-signatures \
           docker://$SOURCE_REPO/$img \
           docker://$TARGET_REPO/$tgt_img_and_tag
  done <<< "$IMAGES_AND_TAGS"
done
```

> Replace **EDITION** and **TARGET_REPO** with the edition and the repository you want.

## Installation Methods

### Installing the OMS Operator **With OLM**

> **Important:**
>
> To install the OMS Operator With OLM in an air-gapped environment, you must either configure a registry mirror on your Kubernetes nodes or rebuild the catalog image to reference your local registry.
>
> If you are using the out-of-the-box catalog image, follow the steps in [Using the out of the box OMS Operator Catalog image](#using-the-out-of-the-box-oms-operator-catalog-image). Otherwise, follow the steps in [Rebuild the OMS Operator Catalog image](#rebuild-the-oms-operator-catalog-image).

#### Using the out-of-the-box OMS Operator Catalog Image

You will need to configure the **registry mirror rules** in order for it to be used in an airgap environment.

In air-gapped environments, **registry mirror rules** ensure Kubernetes nodes can pull container images from a local or mirrored registry. The setup process varies depending on the platform and container runtime.

##### OpenShift Clusters

For OpenShift clusters, use the **ImageContentSourcePolicy** to define cluster-wide registry mirror rules [[↗]](https://docs.openshift.com/container-platform/latest/rest_api/operator_apis/imagecontentsourcepolicy-operator-openshift-io-v1alpha1.html).

##### Vanilla Kubernetes Clusters

For Vanilla Kubernetes clusters, the method to configure registry mirrors depends on the container runtime:

1. **containerd** - configure registry mirrors in the containerd configuration file (**config.toml**) [[↗]](https://github.com/containerd/containerd/blob/main/docs/cri/registry.md).
2. **CRI-O** - configure registry mirrors in the **registries.conf** file [[↗]](https://github.com/containers/image/tree/main/docs).
3. **Docker** - configure registry mirrors in the Docker daemon configuration (**daemon.json**) [[↗]](https://docs.docker.com/docker-hub/mirror/).
4. Other Runtimes - for other container runtimes, refer to their respective documentation for configuring registry mirrors.

#### Rebuild the OMS Operator Catalog image

If you choose to rebuild the catalog image using our provided bundle images (available within the case), you will need to execute the following commands and script. This process will update the entitled repository (`icr.io`) to your target repository, rebuild and push the modified bundle images, generate a new catalog image from the updated bundles, and push the catalog image to your target registry.

By default, the following commands will rebuild only the latest bundle. Modify `NUM_LATEST_BUNDLES` them if you need to include additional bundles.

```bash
# The number of the latest bundles to include in the new catalog image
export NUM_LATEST_BUNDLES=1

# Export some require environment variables
export RESOURCE_FILE_PATH="$OP_CASE_INVENTORY/resources.yaml"
export BUNDLE_VERSIONS=$(yq e '.resources.resourceDefs.containerImages[] | select(.image == "cpopen/ibm-oms-operator-bundle") | .tag' "$RESOURCE_FILE_PATH" \
                            | sort -Vr \
                            | head -n "$NUM_LATEST_BUNDLES" \
                            | paste -sd ',' -)

# Rebuild the new catalog image from the specified bundles (the source images for the bundle will always be icr.io/cpopen)
$OP_CASE_INVENTORY/scripts/byoc.sh \
          --source-repo "icr.io/cpopen" \
          --bundle-versions "$BUNDLE_VERSIONS" \
          --target-repo "$TARGET_REPO"
```

#### Install the OMS Operator

The installation of the OMS Operator in an air-gapped environment is similar to the standard installation process. If you opt for the [Rebuild the OMS Operator Catalog image](#rebuild-the-oms-operator-catalog-image) option, you must update the catalog source's image to use the newly generated catalog image. The remaining steps are identical. Refer to the detailed instructions in the [Installing the OMS Operator **With OLM**](./installing-the-oms-operator-with-olm) documentation.

### Installing the OMS Operator **Without OLM**

The installation of the OMS Operator without OLM in an air-gapped environment is similar to the standard installation process, with the key difference being that you need to replace the image repository with your local repository. Refer to the detailed instructions in the [Installing the OMS Operator Without OLM](./INSTALL_OPERATOR.md#install-the-oms-operator) documentation.
