# OMEnvironment Custom Resource

OMEnvironment defines the specification to create an OMS Environment including database configurations, custom properties, server configurations etc...

## OMEnvironment configuration parameters

1. **additionalMounts**
  
    List of additional mounts like configmaps, secrets, and PVC with volume mount configuration to be mounted into each pods.  

    The following table explains all the attributes applicable for both **configMaps and secrets properties** of additionalMounts spec.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `name` |    |  string  | Yes | Specify the name and make sure it matches the name of a volume. |
    | `mountPath` |    |  string  | Yes | Specify the path within the container where the volume should be mounted. **Must not contain ':' in the path.** |
    | `mountPropagation` |    |  string | No | This determines how mounts are propagated from the host to container and the other way around. When not set, MountPropagationNone is used. |
    | `readOnly` | `false`  |  boolean | No | Mounted read-only if true, read-write otherwise (false or unspecified). |
    | `subPath` |  `"" (volumes's root)`  | string | No | Path within the volume from which the container's volume should be mounted.  |
    | `subPathExpr` | `"" (volumes's root)`  |  string |  No | Expanded path within the volume from which the container's volume should be mounted. Behaves similarly to SubPath but environment variable references $(VAR_NAME) are expanded using the container's environment. SubPathExpr and SubPath are mutually exclusive. |
    | `matchLabels` | | object | No | Specify labels as key-value pair.|  

    The following table explains all the attributes applicable for **storages property** of additionalMounts spec.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `name` | | string  | Yes | Specify the name of the Persistent Volume claim.  |
    | `accessMode` | `ReadWriteMany`  | string  |  No | Specify the access mode for the Persistent Volume.     |
    | `capacity` | `10Gi`   | string or integer  | No | Specify the capacity for the Persistent Volume.  |
    | `mountPath` |  | string |  Yes | Specify the path to mount a PV onto the pod. **Do not set this to /shared.** |
    | `storageClassName` | `default`  |  string | No | Specify the storage class for the Persistent Volume claim. |
    | `matchLabels` | | object | No | Specify labels as key-value pair.|  

    **NOTE**: If `matchLabels` are empty then the volume will be mounted to every pod, otherwise the additional volume will be mounted to only those pods where key-value pair of `matchLabels` matches with key-value pair of `podLabels`.  

2. **affinityAndTolerations**

    Used to define list of affinity and toleration spec, server can refer this using the name used to define the group.  

    For more information on configuring affinityAndTolerations spec see [affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/) and [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/)  

    The following table explains all the attributes applicable for affinityAndTolerations spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `name` |    |  string  | Yes | Specify the affinityAndTolerations group name. |
    | `affinity` |    | object | No | For more information see [affinity](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/) |
    | `tolerations` |    | array | No | For more information see [toleration](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) |  
  
3. **common**

    Used to define common ingress and service properties that can be applicable to all the appServer instances.  

    Pods can be selected using podLabels to apply the common properties.  

    The following table explains all the attributes applicable for common  spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `ingress.annotations` |   | object   | No | Specify any additional annotations for ingress or routes resource as key-value pair.    |
    | `ingress.host` |   | string   | Yes | Specify the Ingress host. |
    | `ingress.labels` |   | object   | No | Specify any additional labels for ingress or routes resource as key-value pair.  |
    | `ingress.ssl.enabled` |  |  boolean  | Yes | Specify whether SSL is enabled for Ingress or not. |
    | `ingress.ssl.identitySecretName` |   | string | No | Specify the name of the secret holding TLS certificate to be used as identity.  |
    | `service.annotations` |   | object   | No | Specify the additional annotations for service resource as key-value pair.    |
    | `service.labels` |   | object   | No| Specify the additional labels for service resource as key-value pair.  |
    | `appServer.ports.http` | `9080`  |  integer   |  Yes | Specify the HTTP container port.  |
    | `appServer.ports.https` | `9443`  |  integer   |  Yes | Specify the HTTPS container port.  |
    | `pod.podLabels` |    | object | No | Specify any additional labels for pod as key-value pair. |  

4. **dataManagement**

    Used to configure data management properties for loading or upgrading factory data.  

    The following table explains all the attributes applicable for dataManagement spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `mode` |  | string | Yes | Specify `create` as the mode for loading the factory data. Available options are `create` and `upgrade`  |
    | `podLabels` |    | object | No | Specify labels for pod as key-value pair. |
    | `property.customerOverrides` |    | string | No | Use the name of  customerOverrides from attribute `serverProperties.customerOverrides[].groupName` or `serverProperties.customerOverrides[].derivatives[].groupName` |
    | `property.envVars` |    | string | No | Use the name of envVars from attribute `serverProperties.envVars[].groupName` or `serverProperties.envVars[].derivatives[].groupName` . |  

5. **database**

    Used to configure database connection parameters.  

    The following table explains all the attributes applicable for database spec of OMEnvironment.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `db2` |   | object | No |  DB2 configuration  |
    | `oracle` |  | object | No | Oracle configuration  |
    | `postgresql` |  | object | No | Postgresql configuration  |  

    The following table explains all the attributes applicable for both db2 and oracle database spec.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `dataSourceName` | `jdbc/OMDS` | string | No | Specify the name of the dataSource to be used in liberty.|
    | `host` |       |  string  | Yes | Specify the IP address or hostname of database server. |
    | `name` |       |  string | Yes | Specify the database name. |
    | `port` |  |  integer |  Yes | Specify the database port.           |
    | `schema` |       |   string | Yes | Specify the database schema name.            |
    | `secure` | `false` |  boolean | No | Specify whether database connection is SSL enabled or not.            |
    | `user` |       | string | Yes | Specify the database user name. **Make sure that the password for the database is provided under data.dbPassword attribute, in the secret filename provided at spec.secret** |  

6. **healthMonitor**

    Used for healthMonitor server configuration.  

    It can use serverprofile and serverproperties by referring group name.  

    The following table explains all the attributes applicable for healthMonitor spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `profile`  |   | string | No | Use the name of the profile from attribute `serverProfiles[].name` to be used by the server. |
    | `property.customerOverrides` |   | string | No | Use the name of  customerOverrides from attribute `serverProperties.customerOverrides[].groupName` or `serverProperties.customerOverrides[].derivatives[].groupName`            |
    | `property.envVars` |   | string | No | Use the name of envVars from attribute `serverProperties.envVars[].groupName` or `serverProperties.envVars[].derivatives[].groupName`. |
    | `property.jvmArgs`  |   |  string | No | Use the name of jvmArgs from attribute `serverProperties.jvmArgs[].groupName` or `serverProperties.jvmArgs[].derivatives[].groupName`. |
    | `replicaCount` |  | integer | Yes | Specify the number of server instances to be deployed. Available options are `0 and 1`. |
    | `podLabels` |    | object | No | Specify labels for pod as key-value pair. |  

7. **image**

    Used to define image configuration for deployment of servers.  

    The following table explains all the attributes applicable for image spec of OMEnvironment.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `imagePullSecrets` |  | array | No | References to secrets in the same namespace for pulling the images. It can be refer as `name-value pair`. |
    | `oms` |  | object | Yes | OMS image configuration. |
    | `orderHub` |  | object | No | OrderHub and OrderHubExt image configuration. |
    | `orderService` |  | object | No | OrderService image configuration. |
    | `pullPolicy` | `IfNotPresent` | string | No | Specify the image pull policy for if/when to pull container image. Available options are `IfNotPresent, Always and Never.` |
    | `repository` |  | string | No | Specify the repository for container images. |  

    The following table explains all the attributes applicable for oms, orderHub and orderService image spec.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `oms.agentDefaultName` | `om-agent`  | string | No | Specify agent image name for tasks like datasetup, pre-install etc. |
    | `oms.appDefaultName` | `om-app` | string | No | Specify app image name for tasks like appServer and xapiServer deployments. |
    | `oms.pullPolicy` | `image.pullPolicy` | string | No | Specify the image pull policy for if/when to pull container image. Available options are `IfNotPresent, Always and Never.` |
    | `oms.repository` | `image.repository` | string | No | Specify the repository for container images. |
    | `oms.tag` |  | string | Yes | Specify the tag for app and agent images. |
    | `orderHub.base.imageName` | `om-orderhub-base`  | string | No | Specify the orderHub base image name. |
    | `orderHub.base.pullPolicy` | `image.pullPolicy` | string | No | Specify the image pull policy for if/when to pull container image. Available options are `IfNotPresent, Always and Never.` |
    | `orderHub.base.repository` | `image.repository` | string | No | Specify the repository for container images. |
    | `orderHub.base.tag` |  | string | Yes | Specify the tag for orderHub base image. |
    | `orderHub.extn.imageName` | `om-orderhub-ext`  | string | No | Specify the orderHub extn image name. |
    | `orderHub.extn.pullPolicy` | `image.pullPolicy` | string | No | Specify the image pull policy for if/when to pull container image. Available options are `IfNotPresent, Always and Never.` |
    | `orderHub.extn.repository` | `image.repository` | string | No | Specify the repository for container images. |
    | `orderHub.extn.tag` |  | string | Yes | Specify the tag for orderHub extn image. |
    | `orderService.imageName` | `orderservice` | string | No | Specify the orderService image name. |
    | `orderService.pullPolicy` | `image.pullPolicy` | string | No | Specify the image pull policy for if/when to pull container image. Available options are `IfNotPresent, Always and Never.` |
    | `orderService.repository` | `image.repository` | string | No | Specify the repository for container images. |
    | `orderService.tag` |  | string | Yes | Specify the tag for orderService image. |  

8. **jms**

    Used for MQ bindings configuration.  

    The following table explains all the attributes applicable for jms spec of OMEnvironment.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `mq.bindingConfigName` |  | string | Yes | Specify the name of the ConfigMap that contains MQ bindings. |
    | `mq.bindingMountPath` | `/opt/ssfs/.bindings`  | string | No | Specify the path where the bindings file needs to be mounted. |  

9. **license**

    Used to accept oms, store and call center license.  

    The following table explains all the attributes applicable for license spec of OMEnvironment.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `accept` |    | boolean | Yes |  Accept OMS license. Available option is true.|
    | `acceptCallCenterStore` |    |  boolean | Yes | Accept Store and Call Center license. Available option is true.|  

10. **networkPolicy**

    Used to configure network policies to control the traffic flow of pods.  

    The following table explains all the attributes applicable for networkPolicy spec of OMEnvironment.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `egress` |   | array | No | List of egress rules to be applied to the selected pods. For more info [see](https://kubernetes.io/docs/concepts/services-networking/network-policies/) |
    | `ingress` |   | array | No | List of ingress rules to be applied to the selected pods. For more info [see](https://kubernetes.io/docs/concepts/services-networking/network-policies/) |
    | `podSelector` |   | object | Yes | Selects the pods to which this NetworkPolicy object applies. For more info [see](https://kubernetes.io/docs/concepts/services-networking/network-policies/) |
    | `policyTypes` |   | array | No | List of rule types that the NetworkPolicy relates to. Valid options are ["Ingress"], ["Egress"], or ["Ingress","Egress"]. If this field is not specified, it will default based on the existence of Ingress or Egress rules. |  

11. **orderHub**

    Orderhub defines the configurations to run orderhub base and extension servers.  

    Each server can refer its own profile, environemt variable group, affinityAndTolerations etc.  

    The following table explains all the attributes applicable for orderhub spec of OMEnvironment.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `bindingAppServerName` |  | string | Yes | Name of appServer instance to which this orderhub instance will be bound to |
    | `base` |  | object | No | orderhub base server configuration |
    | `extn` |  | object | No | orderhub extn server configuration |  

    The following table explains all the attributes applicable for both orderHub base and extn.
    | Property | Default value | Value type | Required | Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `affinityAndTolerations` |    |  string | No | Use the name of the affinityAndTolerations from attribute `affinityAndTolerations[].name` to be used by the server.  |
    | `envVars` |    | string | No | Use the name of envVars from attribute `serverProperties.envVars[].groupName` or `serverProperties.envVars[].derivatives[].groupName`  . |
    | `podLabels` |    | object | No | Specify additional pod labels as key-value pair. |
    | `ingress.annotations` |    | object | No | Specify any additional annotations for ingress or routes resource as key-value pair. |
    | `ingress.labels` |    | object | No | Specify any additional labels for ingress or routes resource as key-value pair. |
    | `livenessCheckBeginAfterSeconds` | `900` | integer | No | Specify the approximate wait time in seconds to begin the liveness check. |
    | `livenessFailRestartAfterMinutes` | `10` | integer | No | Specify the approximate time period in minutes after which the server restarts, if liveness check keeps failing for this period. |
    | `profile` |    | string | No | Use the name of the profile from attribute `serverProfiles[].name` to be used by the server. |
    | `replicaCount` |  | integer | Yes | Specify the number of server instances to be deployed.|
    | `service.annotations` |    | object | No | Specify the additional annotations for service resource as key-value pair. |
    | `service.labels` |    | object | No | Specify the additional labels for service resource as key-value pair. |
    | `terminationGracePeriodSeconds` | `60` | integer | No | Specify the time period in seconds allowed for the pod to terminate gracefully, after which the processes running in the pod will be forcibly terminated. |  

12. **orderService**

    Refer [OrderService](./ORDERSERVICE_CR.md) for configuring orderService spec.  

13. **restService**

    Used for Rest API server configuration.  

    The following table explains all the attributes applicable for restService spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `appServer.dataSource.maxPoolSize` | `50`   | integer | Yes | Specify the dataSource max pool size.              |
    | `appServer.dataSource.minPoolSize` | `10` | integer | Yes | Specify the dataSource min pool size.               |
    | `appServer.ingress.annotations` |    | object | No | Specify any additional annotations for ingress or routes resource as key-value pair. |
    | `appServer.ingress.labels` |    | object | No | Specify any additional labels for ingress or routes resource as key-value pair.               |
    | `appServer.ingress.contextRoots` | `[smcfs, sbc, sma, isccs, wsc, adminCenter]`   | array | No | Specify the context roots that can be accessed through ingress. |
    | `appServer.libertyServerXml` | `default-server-xml` | string | No | Provide the configmap containing server.xml for Liberty. |
    | `appServer.livenessCheckBeginAfterSeconds` | `900` | integer | No | Specify the approximate wait time in seconds to begin the liveness check. |
    | `appServer.livenessFailRestartAfterMinutes` | `10` | integer | No | Specify the approximate time period in minutes after which the server restarts, if liveness check keeps failing for this period. |
    | `appServer.serverName` | `DefaultAppServer` | string | No | Specify the name of the app server. |
    | `appServer.service.annotations` |    | object | No | Specify the additional annotations for service resource as key-value pair. |
    | `appServer.service.labels` |    | object | No | Specify the additional labels for service resource as key-value pair. |
    | `appServer.terminationGracePeriodSeconds` | `60` | integer | No | Specify the time period in seconds allowed for the pod to terminate gracefully, after which the processes running in the pod will be forcibly terminated. |
    | `appServer.threads.max` | `100` | integer | Yes | Specify the maximum number of threads for app server. |
    | `appServer.threads.min` | `20` | integer | Yes | Specify the minimum number of threads for app server. |
    | `appServer.vendor` | `websphere` | string | No | Specify the vendor type. |
    | `appServer.vendorFile` | `servers.properties` | string | No | Specify the vendor file. |
    | `profile` |    | string | No | Use the name of the profile from attribute `serverProfiles[].name` to be used by the server.               |
    | `property.customerOverrides` |    | string | No | Use the name of  customerOverrides from attribute `serverProperties.customerOverrides[].groupName` or `serverProperties.customerOverrides[].derivatives[].groupName` |
    | `property.envVars` |    | string | No | Use the name of envVars from attribute `serverProperties.envVars[].groupName` or `serverProperties.envVars[].derivatives[].groupName`  . |
    | `property.jvmArgs` |    | string | No | Use the name of jvmArgs from attribute `serverProperties.jvmArgs[].groupName` or `serverProperties.jvmArgs[].derivatives[].groupName`. |
    | `replicaCount` |  | integer | Yes | Specify the number of server instances to be deployed. |
    | `podLabels` |    | object | No | Specify labels for pod as key-value pair. |
    | `authstyle` |    | string | No | Xapirest property to set the authentication process. Available options are `STANDARD`, `BASIC` and `EXTENDED`.|
    | `userid` |    | string | No | Xapirest property to define userid to call the API's. |  

14. **security**
  
    Used for SSL configurations to specify the trust store and key store for OMS containers. By default OMS containers will trust the java CA certs.  

    The following table explains all the attributes applicable for security spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `ssl.trust.storeLocation` |  | string  | No | Specify the path to JVM trust store. Make sure to pass the TLS truststore password is provided under `data.trustStorePassword` attribute of secret provided at `spec.secret`. |
    | `ssl.trust.storeType` | `PKCS12` | string | No | Specify the type of truststore. Available options are `PKCS12 and JKS`.|
    | `ssl.trust.trustJavaCACerts` | `true` | boolean | No | Set the value to true if you want the servers to trust the default Java CA certificates. The value is ignored if storeLocation property is specified. |
    | `ssl.trust.trustedCertDir` |   |  string | No | Specify the directory in shared volume, which contains the certificates that OMS containers should trust. The value is ignored if storeLocation property is specified. |  

15. **serverProfiles**

    Used to define list of server profile definition.  

    Each profile can define its own request and limit values of CPU and memory.  

    Servers can refer these profiles by just using profile name.  

    The following table explains all the attributes applicable for serverProfiles spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `name` |  | string | Yes | Specify the server profile name. |
    | `resources` |  |  object |  Yes | Specify the CPU and memory resource requests and limits. For more info [check here](https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/). |  

16. **serverProperties**

    Used to define server properties definitions which includes customerOverrides, envVars and jvmArgs.  

    Each property can define its propertylist and associate it with a group name, server can refer these properties using that group name.  

    Each property can define child properties too, which can inherit and override its parent property.  

    The following table explains all the attributes applicable for **customerOverrides, envVars and jvmArgs properties** of serverProperties spec.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `groupName` |   | string | Yes | Specify the name of the property group. |
    | `propertyList` |   | array | Yes | Specify additional properties as key-value pair. |
    | `derivatives` |   | array | No | Specify list of derived properties. It includes groupName, propertyList and additional list of derived properties. |  

17. **servers**

    Refer [OMServer](./OMSERVER_CR.md) for configuring servers spec.  

18. **storage**

    Configuration to use the persistent volume for storage.  

    The following table explains all the attributes applicable for storage spec of OMEnvironment.
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `name` |  | string  | Yes | Specify the name of the Persistent Volume claim.  |
    | `accessMode` | `ReadWriteMany`  | string  |  No | Specify the access mode for the Persistent Volume claim.     |
    | `capacity` | `10Gi`   | string or integer  | No | Specify the capacity for the Persistent Volume claim.  |
    | `storageClassName` | `default`  |  string | No | Specify the storage class for the Persistent Volume claim. |
    | `securityContext.fsGroup` |   |  integer |  No | Specify the file system group ID to access the Persistent Volume claim.   |
    | `securityContext.supplementalGroups` |  | array | No | Specify the list of supplemental group ID to access the Persistent Volume claim, `ex : [9999]`. |  

## Remaining configuration parameters

    The following table describes the remaining spec of OMEnvironment:
    | Property | Default value | Value type | Required |Description |
    | ---------| --------------| ------------- | ------------------------- | ------------- |
    | `secret` |   |   string   | Yes | Provide the name of the secret containing sensitive properties for deployment. |
    | `serviceAccount` |  `default` |  string | No | Specify the name of the service account used for deployment. |
    | `upgradeStrategy` | `RollingUpdate` | string |  No | Specify the deploymment strategy to be used for upgrading the OMServer deployments. Available options are `RollingUpdate and Recreate.` |  

## Sample OMEnvironment schema

    ```yaml
    apiVersion: apps.oms.ibm.com/v1beta1
    kind: OMEnvironment
    metadata:
      name: ""
    spec:
      license:
        accept: false
        acceptCallCenterStore: false
      secret: ""
      # serviceAccount: default
      # upgradeStrategy: RollingUpdate

      storage:
        name: ""
        # accessMode: ReadWriteMany
        # capacity: 10Gi
        # storageClassName: default
        # securityContext:
          # fsGroup: 
          # supplementalGroups: []

      image:
        # repository: ""
        # pullPolicy: IfNotPresent
        # imagePullSecrets:
        # - name: ""
        oms:
          tag: ""
          # repository: ""
          # pullPolicy: IfNotPresent
          # agentDefaultName: om-agent
          # appDefaultName: om-app
        # orderHub:
          # base:
            # tag: ""
            # repository: ""
            # pullPolicy: IfNotPresent
            # imageName: om-orderhub-base
          # extn:
            # tag: ""
            # repository: ""
            # pullPolicy: IfNotPresent
            # imageName: om-orderhub-ext
        # orderService:
          # tag: ""
          # repository: ""
          # pullPolicy: IfNotPresent
          # imageName: orderservice

      database:
        # db2:
          # host: ""
          # port: 
          # name: ""
          # schema: ""
          # user: ""
          # secure: false
          # dataSourceName: jdbc/OMDS
        # oracle:
          # host: ""
          # port: 
          # name: ""
          # schema: ""
          # user: ""
          # secure: false
          # dataSourceName: jdbc/OMDS
        # postgresql:
          # host: ""
          # port: 
          # name: ""
          # schema: ""
          # user: ""
          # secure: false
          # dataSourceName: jdbc/OMDS

      common:
        ingress:
          host: ""
          # annotations: {}
          # labels: {}
          # ssl:
            # enabled: false
            # identitySecretName: ""
        # service:
          # annotations: {}
          # labels: {}
        # appServer:
          # ports:
            # http: 9080
            # https: 9443
        # pod:
          # podLabels: {}

      networkPolicy:
        <kubernetes-network-policy-spec>

      # jms:
        # mq:
          # bindingConfigName: ""
          # bindingMountPath: /opt/ssfs/.bindings

      # security:
        # ssl:
          # trust:
            # storeLocation: ""
            # storeType: PKCS12
            # trustJavaCACerts: true
            # trustedCertDir: ""

      # dataManagement:
        # mode: <create/upgrade>
        # podLabels: {}
        # property:
          # customerOverrides: ""
          # envVars: ""

      # serverProfiles:
      # - name: ""
        # resources:
          # limits:
            # cpu: 
            # memory: 
          # requests:
            # cpu: 
            # memory: 

      # serverProperties:
        # customerOverrides:
        # - groupName: ""
          # propertyList: ""
          # propertyRef:
          # - name: ""
            # valueFrom:
              # configMapKeyRef:
                # key: ""
                # name: ""
                # optional: 
              # fieldRef:
                # apiVersion: ""
                # fieldPath: ""
              # resourceFieldRef:
                # containerName: ""
                # divisor: "1"
                # resource: ""
              # secretKeyRef:
                # key: ""
                # name: ""
                # optional: 
          # derivatives: []
        # envVars:
        # - groupName: ""
          # propertyList: ""
          # propertyRef:
          # - name: ""
            # valueFrom:
              # configMapKeyRef:
                # key: ""
                # name: ""
                # optional: 
              # fieldRef:
                # apiVersion: ""
                # fieldPath: ""
              # resourceFieldRef:
                # containerName: ""
                # divisor: "1"
                # resource: ""
              # secretKeyRef:
                # key: ""
                # name: ""
                # optional: 
          # derivatives: []
        # jvmArgs:
        # - groupName: ""
          # propertyList: ""
          # propertyRef:
          # - name: ""
            # valueFrom:
              # configMapKeyRef:
                # key: ""
                # name: ""
                # optional: 
              # fieldRef:
                # apiVersion: ""
                # fieldPath: ""
              # resourceFieldRef:
                # containerName: ""
                # divisor: "1"
                # resource: ""
              # secretKeyRef:
                # key: ""
                # name: ""
                # optional: 
          # derivatives: []

      # servers:
      # - name: ""
        # replicaCount: 1
        # podLabels: {}
        # profile: balanced
        # property:
          # customerOverrides: ""
          # envVars: ""
          # jvmArgs: ""
        # image:
          # name: ""
          # variant: ""
        # appServer:
          # serverName: DefaultAppServer
          # dataSource:
            # minPoolSize: 10
            # maxPoolSize: 50
          # threads:
            # min: 20
            # max: 100
          # libertyServerXml: default-server-xml
          # livenessCheckBeginAfterSeconds: 900
          # livenessFailRestartAfterMinutes: 10
          # terminationGracePeriodSeconds: 60
          # ingress:
            # contextRoots: [smcfs, sbc, sma, isccs, wsc, adminCenter]
            # annotations: {}
            # labels: {}
          # service:
            # annotations: {}
            # labels: {}
          # vendor: websphere
          # vendorFile: servers.properties
        # agentServer:
          # names: []
          # readinessFailRestartAfterMinutes: 10
          # terminationGracePeriodSeconds: 60
        # integration:
          # names: []
          # readinessFailRestartAfterMinutes: 10 
          # terminationGracePeriodSeconds: 60
        # affinityAndTolerations: ""

      # healthMonitor:
        # podLabels: {}
        # profile: balanced
        # property:
          # customerOverrides: ""
          # envVars: ""
          # jvmArgs: ""
        # replicaCount: 1

      # restService:
        # replicaCount: 
        # authstyle: 
        # userid: ""
        # podLabels: {}
        # profile: balanced
        # property:
          # customerOverrides: ""
          # envVars: ""
          # jvmArgs: ""
        # appServer:
          # serverName: DefaultAppServer
          # dataSource:
            # minPoolSize: 10
            # maxPoolSize: 50
          # threads:
            # min: 20
            # max: 100
          # libertyServerXml: default-server-xml
          # livenessCheckBeginAfterSeconds: 900
          # livenessFailRestartAfterMinutes: 10
          # terminationGracePeriodSeconds: 60
          # ingress:
            # contextRoots: [smcfs]
            # annotations: {}
            # labels: {}
          # service:
            # annotations: {}
            # labels: {}
          # vendor: websphere
          # vendorFile: servers.properties

      # orderHub:
        # bindingAppServerName: ""
        # base:
          # replicaCount: 1
          # profile: balanced
          # envVars: ""
          # podLabels: {}
          # ingress:
            # annotations: {}
            # labels: {}
          # service:
            # annotations: {}
            # labels: {}
          # livenessCheckBeginAfterSeconds: 900
          # livenessFailRestartAfterMinutes: 10
          # terminationGracePeriodSeconds: 60
          # affinityAndTolerations: ""
        # extn:
          # replicaCount: 1
          # profile: balanced
          # envVars: ""
          # podLabels: {}
          # ingress:
            # annotations: {}
            # labels: {}
          # service:
            # annotations: {}
            # labels: {}
          # livenessCheckBeginAfterSeconds: 900
          # livenessFailRestartAfterMinutes: 10
          # terminationGracePeriodSeconds: 60
          # affinityAndTolerations: ""

      # orderService:
        # replicaCount: 1
        # profile: balanced
        # orderServiceVersion: ""
        # podLabels: {}
        # configuration:
          # jwt_algorithm: ""
          # jwt_audience: ""
          # jwt_ignore_expiration: 
          # jwt_issuer: ""
          # additionalConfig: {}
        # cassandra:
          # keyspace: ""
          # contactPoints: ""
          # createDevInstance:
            # profile: balanced
            # storage:
              # name: ""
              # accessMode: ""
              # capacity: 
              # storageClassName: ""
        # elasticsearch:
          # contactPoints: ""
          # createDevInstance:
            # profile: balanced
            # storage:
              # name: ""
              # accessMode: ""
              # capacity: 
              # storageClassName: ""

      # additionalMounts:
        # configMaps:
        # - name: ""
          # mountPath: ""
          # subPath: ""
          # subPathExpr: ""
          # readOnly: false
          # mountPropagation: ""
          # matchLabels: {}
        # secrets:
        # - name: ""
          # mountPath: ""
          # subPath: ""
          # subPathExpr: ""
          # readOnly: false
          # mountPropagation: ""
          # matchLabels: {}
        # storages:
        # - name: ""
          # mountPath: ""
          # storageClassName: ""
          # accessMode: ""
          # capacity: 
          # matchLabels: {}

      # affinityAndTolerations:
      # - name: ""
      #   affinity:
      #     <kubernetes-affinity-spec>
      #   tolerations:
      #   - <kubernetes-toleration-spec>
    ```

  **NOTE**: The commented params are optional for creating omenvironment.
