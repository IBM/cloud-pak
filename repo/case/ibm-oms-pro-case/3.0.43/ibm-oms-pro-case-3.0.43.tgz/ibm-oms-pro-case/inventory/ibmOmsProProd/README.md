# IBM Sterling OMS Professional Edition

This inventory item `ibmOmsProProd` can be used to install the IBM Sterling Order Management Software Professional Edition.

For more infomation, see [README](../../README.md)
