# IBM OMS Professsional Case

  IBM Sterling Order Management Software Professional Edition, version 10.0 CASE Bundle.

## Introduction

This CASE provides an Operator to install IBM Order Management Software Professional Edition v10. The Operator does not install database server or messaging server. Both these middlewares need to be setup and configured separately.

**NOTE**: This CASE supports deployment of IBM Order Management Software Professional Edition with DB2 database and MQ messaging.

## Details

This CASE contains the following inventory items:

- **ibmOmsProProd** can be used to install/uninstall IBM Order Management Software Professional Edition v10.
- **ibmOmsProProdSetup** can be used to download the case, set up registry credentials, mirror images, install/uninstall catalog source, and install/uninstall IBM Sterling Order Management Software Operator.

## Prerequisites

  Before you begin, ensure that you complete the prerequisites as mentioned in [IBM Knowledge Center.](https://www.ibm.com/docs/en/order-management-sw/10.0?topic=operator-installation-prerequisites)

## PodSecurityPolicy Requirements

**NOTE:** These instructions are applications only for vanilla Kubernetes platform.

The operator requires a `PodSecurityPolicy` to be bound to the target namespace prior to installation. You can select either a predefined `PodSecurityPolicy` or custom `PodSecurityPolicy` that is shared by your cluster administrator.

Custom PodSecurityPolicy definition:

```yaml
apiVersion: extensions/v1beta1
kind: PodSecurityPolicy
metadata:
  annotations:
    kubernetes.io/description: 'This policy allows pods to run with
      any UID and GID, but preventing access to the host.'
  name: ibm-oms-anyuid-psp
spec:
  allowPrivilegeEscalation: true
  fsGroup:
    rule: RunAsAny
  requiredDropCapabilities:
    - MKNOD
  allowedCapabilities:
    - SETPCAP
    - AUDIT_WRITE
    - CHOWN
    - NET_RAW
    - DAC_OVERRIDE
    - FOWNER
    - FSETID
    - KILL
    - SETUID
    - SETGID
    - NET_BIND_SERVICE
    - SYS_CHROOT
    - SETFCAP
  runAsUser:
    rule: RunAsAny
  seLinux:
    rule: RunAsAny
  supplementalGroups:
    rule: RunAsAny
  volumes:
    - configMap
    - emptyDir
    - projected
    - secret
    - downwardAPI
    - persistentVolumeClaim
  forbiddenSysctls:
    - '*'
```

To create a custom `PodSecurityPolicy`, create a yaml file with the custom `PodSecurityPolicy` definition and run the following command:

```sh
kubectl create -f <custom_psp.yaml>
```

## Red Hat OpenShift SecurityContextConstraints Requirements

The Operator is verified with the predefined `SecurityContextConstraints` named [`ibm-anyuid-scc.`](https://ibm.biz/cpkspec-scc) Alternatively, you can use a custom `SecurityContextConstraints.` Ensure that you bind the `SecurityContextConstraints` resource to the target namespace prior to installation.

### SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
  name: ibm-oms-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: []
allowedFlexVolumes: []
defaultAddCapabilities: []
fsGroup:
  type: MustRunAs
  ranges:
    - max: 65535
      min: 1
readOnlyRootFilesystem: false
requiredDropCapabilities:
  - ALL
runAsUser:
  type: MustRunAsRange
seccompProfiles:
  - docker/default
seLinuxContext:
  type: RunAsAny
supplementalGroups:
  type: MustRunAs
  ranges:
    - max: 65535
      min: 1
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
priority: 0
```

To create a custom `SecurityContextConstraints`, create a yaml file with the custom `SecurityContextConstraints` definition and run the following command:

```sh
kubectl create -f <custom-scc.yaml>
```

## Resources Required

For minimum and recommended list of hardware requirements, see [README document.](./inventory/ibmOmsProProdSetup/README.md#resources)

## Installing

### Installation Prerequisites

For the list of prerequisites to install the inventory items present in this CASE, see the [README document.](./inventory/ibmOmsProProdSetup/README.md#prerequisites)

### Installing the CASE

For instructions on installing the inventory items present in this CASE, see the [README document.](./inventory/ibmOmsProProdSetup/README.md#Installing-and-uninstalling-OMS-Operator)

### Uninstalling the CASE

For instructions on removing the inventory items present in this CASE, see [README document.](./inventory/ibmOmsProProdSetup/README.md#Installing-and-uninstalling-OMS-Operator)

### Air gap installation

For instructions on performing air gap installation, see [README document.](./inventory/ibmOmsProProdSetup/README.md#air-gap-installation)

## Configuration

For the list of configurable parameters that are applicable for the operator, see [README document.](./inventory/ibmOmsProProdSetup/README.md)

## Limitations

The database must be installed in UTC timezone.

## Documentation

For product documentation, see [IBM Knowledge Center](https://www.ibm.com/support/knowledgecenter/SS6PEW_10.0.0/om_maps/omV10_welcome.html)

For more information on certified container images, see [IBM Sterling Order Management Software on OpenShift Container platform](https://www.ibm.com/support/knowledgecenter/SS6PEW_10.0.0/installation/c_OMRHOC_installing.html)
