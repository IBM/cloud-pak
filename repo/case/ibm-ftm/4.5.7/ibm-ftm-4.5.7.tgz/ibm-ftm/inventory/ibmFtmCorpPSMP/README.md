# ibmFtmCorpPSMP

This inventory item contains the FTM CPS MP solution

