# ibmFtmCommonServicesMP

This inventory item contain the FTM Common Services Multi Platform solution

