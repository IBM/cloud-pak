# ibmFtmDPMP

This inventory item contains the FTM DP MP solution

