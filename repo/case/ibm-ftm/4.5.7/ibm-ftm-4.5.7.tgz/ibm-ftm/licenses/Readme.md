# FTM License Files

This directory contains license files for IBM Financial Transaction Manager (FTM) and its components.

## Automatic License Download

**License files are automatically downloaded during the build process** from the `doc-ftm-licenses` repository published to Artifactory. This directory should remain empty in the Git repository.

### Build Process

1. **Download Phase** (`build/download_artifacts.py`):
   - Fetches license files from **two versions** of `ftm-licenses.zip` from Artifactory
   - Downloads from both `3.2.13` and `ftm_release` (e.g., `4.0.10.0`) branches
   - Extracts and maps license files to this directory
   - **Fails immediately** if download or extraction fails (no fallback mechanism)

2. **CASE Bundle Phase** (`build/build_case.py`):
   - Copies the entire CASE structure including downloaded licenses
   - Packages everything into the final CASE bundle

### Dual Version Download Strategy

The build process downloads licenses from **two separate versions**:

#### Version 1: 3.2.13 (Legacy Licenses)
Downloads from `3.2.13/ftm_license.zip` and extracts **3 legacy license files**:

| Source File (in zip) | Target File (in CASE) | Component |
|----------------------|----------------------|-----------|
| `HVP/HVP` | `LICENSE_HVP` | High Value Payments (3.2.13 only) |
| `CPS/CPS` | `LICENSE_CPS` | Corporate Payment Services (3.2.13 only) |
| `DP/DP` | `LICENSE_DP` | Digital Payments (3.2.13 only) |

> **⚠️ IMPORTANT NOTE**: If there is a new 3.2.X release (e.g., 3.2.14, 3.2.15), update the version in `download_artifacts.py` line 462:
> ```python
> license_versions = ["3.2.13", ftm_release]  # Update "3.2.13" to new version
> ```
> Also update the version check in line 488:
> ```python
> if license_version == "3.2.13":  # Update "3.2.13" to new version
> ```

#### Version 2: ftm_release (Current Licenses)
Downloads from `{ftm_release}/ftm_license.zip` (e.g., `4.0.10.0`) and extracts **11 current license files**:

| Source File (in zip) | Target File (in CASE) | Component |
|----------------------|----------------------|-----------|
| `FTM/FTM` | `LICENSE_Base` | FTM Base |
| `FTM/FTM_EXISTING` | `LICENSE_Existing_Base` | FTM Base for Existing 3.x Clients |
| `CHECK/CHECK` | `LICENSE_Check` | Check Processing |
| `CBPRPLUS/CBPRPLUS` | `LICENSE_CBPRPLUS` | CBPR+ |
| `COMMONSERVICES/COMMONSERVICES` | `LICENSE_Common_Services` | Common Services |
| `EURO1-T2/EURO1-T2` | `LICENSE_T2_EURO1` | T2/EURO1 |
| `FEDWIRE/FEDWIRE` | `LICENSE_Fedwire` | Fedwire |
| `NACHA/NACHA` | `LICENSE_NACHA` | NACHA |
| `NORDIC/NORDIC` | `LICENSE_Nordic` | Nordic RTGS |
| `SCTInst/SCTInst` | `LICENSE_SCTInst` | SCT Inst |
| `TCHRTP/TCHRTP` | `LICENSE_TchRtp` | TCH RTP |

**Total: 14 license files** (3 from 3.2.13 + 11 from ftm_release)

### Artifactory Configuration

The license download uses the following Artifactory configuration:

- **Repository**: `ip-ftm-v4-team-misc-generic-local/Misc/ftm-licenses`
- **Base URL**: `https://na.artifactory.swg-devops.com/artifactory/`
- **Versions Downloaded**:
  - `3.2.13/{build_label}/ftm-licenses.zip` (for legacy licenses)
  - `{ftm_release}/{build_label}/ftm-licenses.zip` (for current licenses)

The build script automatically:
1. Queries Artifactory for the latest build label for each version
2. Downloads the corresponding `ftm-licenses.zip` files
3. Extracts version-specific files to this directory

### Dependencies on doc-ftm-licenses Repository

**CRITICAL**: This build process depends on the `doc-ftm-licenses` repository having **published artifacts for multiple branches**:

#### Required Branches in doc-ftm-licenses:
1. **`release/v3.2.13` branch** (or newer 3.2.X version):
   - Must contain: `HVP/HVP`, `CPS/CPS`, `DP/DP` license files
   - Published to: `3.2.13/{build_label}/ftm-licenses.zip`
   - Used for: Legacy 3.2.13 components
   - **Note**: If a new 3.2.X release is created, update the version in `download_artifacts.py`

2. **Current release branch** (e.g., `release/v4.0.10.0`):
   - Must contain: All 11 common license files
   - Published to: `{ftm_release}/{build_label}/ftm-licenses.zip`
   - Used for: Current FTM components

#### Publishing Requirements:
- Both branches must be published to Artifactory
- Each branch must have its own build label
- The `ftm-licenses.zip` must contain the correct license files for that version
- Build labels must follow the format: `YYYYMMDD-HHMM`

#### Verification:
Before building the operator, verify both versions are available:
```bash
# Check 3.2.13 is published
curl -u :$ARTIFACTORY_TOKEN \
  https://na.artifactory.swg-devops.com/artifactory/ip-ftm-v4-team-misc-generic-local/Misc/ftm-licenses/3.2.13/

# Check current release is published
curl -u :$ARTIFACTORY_TOKEN \
  https://na.artifactory.swg-devops.com/artifactory/ip-ftm-v4-team-misc-generic-local/Misc/ftm-licenses/4.0.10.0/
```

### Error Handling

**The build process uses strict error handling:**

- ❌ **No fallback mechanism** - If license download fails for either version, the build fails immediately
- ❌ **No default licenses** - All license files must be downloaded successfully from both versions
- ❌ **No partial extraction** - All required license files must be present in each zip
- ❌ **Missing branch** - If either 3.2.13 or ftm_release branch is not published, build fails

This ensures that:
- CASE bundles always contain the latest license files from both versions
- License updates are automatically propagated
- Build failures are detected early and clearly
- No stale or missing licenses in production

### Troubleshooting

If the build fails during license download:

1. **Check Artifactory Access**:
   - Verify `ARTIFACTORY_TOKEN` environment variable is set
   - Ensure token has read access to `ip-ftm-v4-team-misc-generic-local`

2. **Verify License Repository Branches**:
   - Check that `doc-ftm-licenses` **release/v3.2.13** branch has been published
   - Check that `doc-ftm-licenses` current release branch has been published
   - Confirm both versions contain all required license files
   - Verify build labels exist for both versions

3. **Check Network Connectivity**:
   - Ensure build environment can reach Artifactory
   - Verify no proxy or firewall issues

4. **Review Build Logs**:
   - Look for specific error messages from `download_artifacts.py`
   - Check which version (3.2.13 or ftm_release) failed
   - Check which license files are missing or failed to download

5. **Verify doc-ftm-licenses Repository**:
   - Ensure `release/v3.2.13` branch exists and is published
   - Ensure current release branch exists and is published
   - Check that GitHub Actions workflows completed successfully for both branches
   - Verify Artifactory contains artifacts for both versions

### Manual Verification

After a successful build, verify all licenses are present:

```bash
# Check that all 14 license files exist
ls -l case/stable/ibm-ftm-operator-case-bundle/case/ibm-ftm/licenses/

# Should show 14 files:
# From 3.2.13:
# LICENSE_CPS
# LICENSE_DP
# LICENSE_HVP
#
# From ftm_release (e.g., 4.0.10.0):
# LICENSE_Base
# LICENSE_CBPRPLUS
# LICENSE_Check
# LICENSE_Common_Services
# LICENSE_Existing_Base
# LICENSE_Fedwire
# LICENSE_NACHA
# LICENSE_Nordic
# LICENSE_SCTInst
# LICENSE_T2_EURO1
# LICENSE_TchRtp

# Verify count
ls -1 case/stable/ibm-ftm-operator-case-bundle/case/ibm-ftm/licenses/LICENSE_* | wc -l
# Should output: 14
```

### Integration with case.yaml

The `case.yaml` file references these license files in the `licenses` section. The license download process ensures all referenced files are present before the CASE bundle is built.

### Development Notes

- **Do not commit license files** to this directory in Git
- **Do not add fallback mechanisms** - builds should fail if licenses are unavailable from either version
- **Keep this README** to document the process for developers
- **Update license_mapping** in `download_artifacts.py` if new components are added
- **Maintain both branches** in doc-ftm-licenses repository (3.2.13 and current release)
- **Publish both branches** to Artifactory before building the operator
- **Update version numbers** if a new 3.2.X release is created (see note above)

### Related Files

- `build/download_artifacts.py` - License download implementation (lines 434-527)
  - Downloads from both 3.2.13 and ftm_release versions
  - Uses version-specific mappings for each
  - **Lines to update for new 3.2.X releases**: 462, 488
- `build/build_case.py` - CASE bundle creation (uses `shutil.copytree()`)
- `case.yaml` - License file references
- `doc-ftm-licenses` repository:
  - `release/v3.2.13` branch - Legacy licenses (HVP, CPS, DP)
  - Current release branch - Current licenses (11 files)

### Version-Specific Logic

The download logic is **version-string based**, not order-based:

```python
if license_version == "3.2.13":
    # Extract only HVP, CPS, DP
    current_license_mapping = license_mapping_3_2_13
else:
    # Extract all 11 common licenses
    current_license_mapping = license_mapping
```

This means:
- Order in `license_versions` list doesn't matter
- Works whether versions are hardcoded or from variables
- Always extracts the correct files for each version
- Flexible for future version changes

---

**Last Updated**: Sep 2026  
**Maintained By**: FTM Operator Team  
**Dependencies**: doc-ftm-licenses repository (branches: release/v3.2.13, release/v{ftm_release})
