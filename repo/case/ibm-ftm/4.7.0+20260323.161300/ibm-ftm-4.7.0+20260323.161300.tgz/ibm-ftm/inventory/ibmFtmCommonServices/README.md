# ibmFtmCommonServices

This inventory item contain the FTM Common Services solution

