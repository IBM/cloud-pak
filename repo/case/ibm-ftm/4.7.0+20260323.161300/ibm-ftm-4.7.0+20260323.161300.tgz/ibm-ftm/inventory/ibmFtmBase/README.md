# ibmFtmBase

This inventory item contain the FTM Base solution

