# ibmFtmRIX

This inventory item contain the FTM RIX solution

