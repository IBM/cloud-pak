# ibmFtmT2EURO1

This inventory item contains the FTM T2-EURO1 solution

