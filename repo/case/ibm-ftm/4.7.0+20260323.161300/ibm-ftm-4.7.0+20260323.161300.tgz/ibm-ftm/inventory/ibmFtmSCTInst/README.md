# ibmFtmSCTInst

This inventory item contain the FTM SCT Inst solution
