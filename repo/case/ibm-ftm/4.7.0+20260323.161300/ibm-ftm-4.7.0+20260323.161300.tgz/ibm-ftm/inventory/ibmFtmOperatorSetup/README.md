# ibmFtmBaseOperatorSetup

This inventory item contains all of the files necessary to deploy the Operator. This includes the controller Deployment, the Roles, Rolebindings, and Service Accounts, and the Custom Resource Definition.
