#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# launch-impl.sh
#
# Defines overrides for standard CASE actions.

# ----- GLOBAL VARS -----
caseCatalogName="ibm-ftm-operator-case-bundle"
catalogNamespace="openshift-marketplace"
catalogSourceYaml="${scriptDir:?}/op-olm/catalog_source.yaml"
subscriptionYaml="${scriptDir}/op-olm/subscription.yaml"
operatorGroupYaml="${scriptDir}/op-olm/operator_group.yaml"
inventory="ibmFtmBaseOperatorSetup"

crds="${scriptDir}/deploy/crds"

# ----- INSTALL ACTIONS -----

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}' ) -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply -n "${namespace}" -f -

    echo "done"
}

# Installs the catalog source
install_catalog() {

    validate_install_catalog

    echo "-------------Installing catalog source-------------"

    # Verify expected yaml files for install exit
    validate_file_exists "${catalogSourceYaml}"

    # Replace registry if one is provided, otherwise use default icr.io
    if [[ "${registry:=""}" != "" ]]; then
        # Apply yaml files manipulate variable input as required

        local catsrc_image_orig
        catsrc_image_orig=$(grep "image:" "${catalogSourceYaml}" | awk '{ print $2 }')

        # replace original registry with local registry
        local catsrc_image_mod
        catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s|icr.io/||g")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catalogSourceYaml}" | tee >( $kubernetesCLI apply ${dryRun} -f -) | cat
    else
        $kubernetesCLI apply ${dryRun} -f "${catalogSourceYaml}"
    fi

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    # Proceed with install
    echo "-------------Installing via OLM-------------"
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml ]] && { err_exit "Missing required subscription yaml, exiting deployment."; }

    # check if catalog source is installed ?
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # - subscription
    sed <"${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | $kubernetesCLI apply -n "${namespace}" -f -
}

# Install utilizing default CLI method
install_operator_native() {
    # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing native-------------"
    # Verify expected yaml files for install exist
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml ]] && { err_exit "Missing required service accout yaml, exiting deployment."; }
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml ]] && { err_exit "Missing required role yaml, exiting deployment."; }
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml ]] && { err_exit "Missing required rol binding yaml, exiting deployment."; }
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml ]] && { err_exit "Missing required operator yaml, exiting deployment."; }

    # Apply yaml files manipulate variable input as required
    # - service account
    #sed <"${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml "s|REPLACE_SECRET|$secret|g" | $kubernetesCLI apply -n "${namespace}" -f -
    $kubernetesCLI apply -n "${namespace}" -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml
	# - crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/deploy/crds/*_crd.yaml; do
        $kubernetesCLI apply -n "${namespace}" -f "${crdYaml}"
    done
    # - role
    $kubernetesCLI apply -n "${namespace}" -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml
    # - role binding
    #sed <"${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply -n "${namespace}" -f -
    $kubernetesCLI apply -n "${namespace}" -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml
	# - operator
    $kubernetesCLI apply -n "${namespace}" -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"

    local cr_artifact="${casePath}"/inventory/"${inventory}"/files/deploy/crds/ftm.ibm.com_v1_ftmbaseartifact_cr.yaml
    [[ ! -f ${cr_artifact} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    local cr="${casePath}"/inventory/"${inventory}"/files/deploy/crds/ftm.ibm.com_v1_ftmbase_cr.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
        temp_base_cr=$(mktemp)
	temp_artifact_cr=$(mktemp)
	cp "$cr" "${temp_base_cr}";
	cp "$cr_artifact" "${temp_artifact_cr}"

	accept_license()
	{
	    echo "Accepting all licenses";
	    sed -i "s/accept: false/accept: true/g" "$1"

	}

	if [[ $accept_license -eq 1 ]]; then
	echo "Accepting CRD License"
	accept_license $temp_base_cr
	accept_license $temp_artifact_cr

	fi
	#Interactive prompt for license accept
	check_license()
	{
		accept_base=$(grep "accept" $1 | cut -d: -f2 | tr -d ' ' )
		echo "Value of Operator license in $2: $accept_base"
		if [ "$accept_base" = "true" ] ;then
		accept="true";
		echo "All Licenses accepted $accept"
		else
		accept="false";
		echo "Accept license Agreement value :$accept Please accept License  Exiting!"
		exit 1;

		fi
	}


	echo "Checking license for Operator CR file:-"
	check_license $temp_base_cr Base_file
	echo "Checking license for artfact CR file:-"
	check_license $temp_artifact_cr Artifact_file

       # Add the detailsfor cr file
       sed -i "s|secret_name: ''|secret_name: 'ftm-application-secret'|g" "${temp_base_cr}"

	echo "Continuing Installing CR"
	# artifact cr
	$kubernetesCLI apply -n "${namespace}" -f "${temp_artifact_cr}"
	# cr
	$kubernetesCLI apply -n "${namespace}" -f "${temp_base_cr}"


	#Add in script to delete the temporary files.
	rm $temp_base_cr
	rm $temp_artifact_cr


}

# ----- MIRROR ACTIONS -----

# Validates that the required args were specified for image mirroring
validate_mirror_images_args() {
    # Verify arguments required to mirror correct image-group subset were provided
    local foundError=0
    [[ -z "${image_groups}" ]] && {
            foundError=1
            err "'--groups <image-group>' was not supplied to the '--args' parameter for --action mirror-images"
    }
    # Exit if missing --groups flag and supplied argument
    [[ $foundError -eq 1 ]] && exit 1;
}

# Mirror required images
mirror_images() {
    echo "-------------Mirroring images-------------"

    get_case_name
    get_case_version

    case_archive="${caseName}-${caseVersion}.tgz"

    validate_configure_cluster_airgap_args

    # handle conversion from --filter to --groups
    [[ -n "${image_filters}" ]] && { translate_filters ; }
    validate_mirror_images_args

    "${scriptDir}"/airgap.sh image mirror \
        --dir "${inputcasedir}" \
        ${src_registry:+'--from-registry' "$src_registry"} \
        --to-registry "${registry}" \
        ${mirror_image_chunks:+'--split-size' "$mirror_image_chunks"} \
        ${image_groups:+'--groups' "$image_groups"} \
        ${image_arch:+'--arch' "$image_arch"} \
        ${skip_delta:+'--skip-delta' "$skip_delta"} \
        ${case_archive:+'--archive' "$case_archive"} \
        ${ns_prefix:+'--ns-prefix' "$ns_prefix"} \
        ${dryRunOutput:+'--dry-run-output' "$dryRunOutput"} \
        "${dryRun}" \
        ${log_level:+'--log-level' "$log_level"}
}


# ----- UNINSTALL ACTIONS -----

uninstall() {
    echo "Action not supported"
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    #if [[ ${recursive_action} -eq 1 ]]; then
    #    uninstall_dependent_catalogs
   # fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml
    local opgrp_file="${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/deploy/crds/*_crd.yaml; do
        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true
    done

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    echo "-------------Uninstalling operator-------------"
    # Verify expected yaml files for uninstall and delete resources for each
    [[ -f "${casePath}/inventory/${inventory}/files/deploy/service_account.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/deploy/service_account.yaml" --ignore-not-found=true; }
    [[ -f "${casePath}/inventory/${inventory}/files/deploy/role.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/deploy/role.yaml" --ignore-not-found=true; }
    [[ -f "${casePath}/inventory/${inventory}/files/deploy/role_binding.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/deploy/role_binding.yaml" --ignore-not-found=true; }
    [[ -f "${casePath}/inventory/${inventory}/files/deploy/operator.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/deploy/operator.yaml" --ignore-not-found=true; }

    # - crds
    if [[ $deleteCRDs -eq 1 ]]; then
        echo "deleting crds"
        for crdYaml in "${casePath}"/inventory/"${inventory}"/files/deploy/crds/*_crd.yaml; do
            $kubernetesCLI delete -n "${namespace}" -f "${crdYaml}" --ignore-not-found=true
        done
    fi

}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr_artifact="${casePath}"/inventory/"${inventory}"/files/deploy/crds/ftm.ibm.com_v1_ftmbaseartifact_cr.yaml
    [[ ! -f ${cr_artifact} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    local cr="${casePath}"/inventory/"${inventory}"/files/deploy/crds/ftm.ibm.com_v1_ftmbase_cr.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
	# Deleting crs
	$kubernetesCLI delete -n "${namespace}" -f "${cr_artifact}"
    $kubernetesCLI delete -n "${namespace}" -f "${cr}"
}

# ----- REGISTRY ACTIONS -----

init_registry() {
    "${scriptDir}"/airgap.sh registry service init \
        ${user:+'--username' "$user"} \
        ${pass:+'--password' "$pass"} \
        ${registry_dir:+'--dir' "$registry_dir"} \
        ${registry_subject:+'--subject' "$registry_subject"} \
        ${registry:+'--registry' "$registry"} \
        ${registry_clean:+'--clean'}
}

start_registry() {
    "${scriptDir}"/airgap.sh registry service start \
        ${registry_dir:+'--dir' "$registry_dir"} \
        ${registry_engine:+'--engine' "$registry_engine"} \
        ${registry_port:+'--port' "$registry_port"} \
        ${registry_image:+'--image' "$registry_image"}
}

stop_registry() {
    "${scriptDir}"/airgap.sh registry service stop \
        ${registry_engine:+'--engine' "$registry_engine"}
}

# ***** END ACTIONS *****

