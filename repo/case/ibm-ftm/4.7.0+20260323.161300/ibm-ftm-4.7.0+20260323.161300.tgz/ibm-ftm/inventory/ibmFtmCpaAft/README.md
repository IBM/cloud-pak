# ibmFtmCpaAft

This inventory item contain the FTM CPA AFT solution

