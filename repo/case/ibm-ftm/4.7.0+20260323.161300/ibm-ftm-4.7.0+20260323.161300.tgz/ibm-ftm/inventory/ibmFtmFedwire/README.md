# ibmFtmFedwire

This inventory item contain the FTM Fedwire solution

