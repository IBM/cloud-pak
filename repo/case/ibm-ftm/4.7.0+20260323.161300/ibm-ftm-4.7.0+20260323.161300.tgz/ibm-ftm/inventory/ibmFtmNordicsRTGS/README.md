# ibmFtmNordicsRTGS

This inventory item contain the FTM Nordics RTGS Systems solution

