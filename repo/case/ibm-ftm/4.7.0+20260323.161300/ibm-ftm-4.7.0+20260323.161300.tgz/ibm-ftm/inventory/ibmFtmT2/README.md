# ibmFtmT2

This inventory item contain the FTM T2 solution

