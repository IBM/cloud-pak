# ibmFtmCBPRPlus

This inventory item contain the FTM CBPR+ solution

