# ibmFtmTchRtp

This inventory item contain the FTM TCH-RTP