# ibmFtmCheck

This inventory item contain the FTM NACHA solution

