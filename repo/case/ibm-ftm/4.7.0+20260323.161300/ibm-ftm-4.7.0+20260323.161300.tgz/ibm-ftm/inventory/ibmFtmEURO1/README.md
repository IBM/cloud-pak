# ibmFtmEURO1

This inventory item contain the FTM EURO1 solution

