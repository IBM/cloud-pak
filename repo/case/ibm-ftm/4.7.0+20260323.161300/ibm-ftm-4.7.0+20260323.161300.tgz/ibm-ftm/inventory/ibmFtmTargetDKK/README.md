# ibmFtmTargetDKK

This inventory item contain the FTM TARGET DKK solution

