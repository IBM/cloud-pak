# ibmFtmCheck

This inventory item contain the FTM Check solution

