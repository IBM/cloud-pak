# ibmFtmFednow

This inventory item contain the FTM Fednow solution

