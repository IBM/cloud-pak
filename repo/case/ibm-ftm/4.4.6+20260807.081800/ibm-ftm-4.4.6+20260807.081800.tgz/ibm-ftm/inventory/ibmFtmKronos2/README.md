# ibmFtmKronos2

This inventory item contain the FTM Kronos2 solution

