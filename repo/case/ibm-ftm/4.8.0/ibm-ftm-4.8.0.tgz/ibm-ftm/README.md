# Name

IBM&reg; Financial Transaction Manager for Red Hat OpenShift 4.0.6

## Introduction
IBM® Financial Transaction Manager 4.0.6 integrates, orchestrates, and monitors financial transactions. It delivers consistent processing across multiple payment types, enabling banks and financial institutions to converge their payment operations on to a single platform. Financial Transaction Manager can accelerate the delivery of improved financial products and services to customers.

## Details
FTM provides a framework through which management of the integration of existing and new applications and services can be achieved through a financial-markets-enabled integration platform.
* Supports provision of services that can be reused across many processes.
* Enables the rapid assembly, integration, and modification of business processes.
* Employs IBM®'s market-leading SOA foundation products.

## Prerequisites
* Deployment of OpenShift
* Deployment of the IBM Cloud Pak foundational services operator and IBM Licensing Operator
* Setup and Configure Network Storage
* Setup HAProxy server
* Configure the pids_limit value

**For more information about prerequisites, see** [https://www.ibm.com/support/pages/node/712995](https://www.ibm.com/support/pages/node/712995)

## Resources Required
PFor more information about resources required, see [https://www.ibm.com/support/pages/node/712995](https://www.ibm.com/support/pages/node/712995)

## Configuration
For more information about configuration details, see https://www.ibm.com/docs/SSRH46_4.0.6/fosdeployovr.html

## Installing
For more information about deploying FTM Offerings, see https://www.ibm.com/docs/SSRH46_4.0.6/fosdeployovr.html

## Limitations
For more information about FTM limitations, see https://www.ibm.com/docs/SSRH46_4.0.6/fosdeployovr.html

## SecurityContextConstraints Requirements
For more information about FTM Security Context Constraints, see https://www.ibm.com/docs/en/SSRH46_4.0.6/fosdplyprerqinstcsscc.html
