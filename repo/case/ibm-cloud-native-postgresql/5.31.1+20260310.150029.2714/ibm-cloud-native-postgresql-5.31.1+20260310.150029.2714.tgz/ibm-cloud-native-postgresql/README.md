# Name

IBM&reg; ibm-cloud-native-postgresql

# Introduction

The case bundle installs the EnterpriseDB Cloud Native PostgreSQL operator, which can be used to deploy EnterpriseDB Standard and Enterprise instances of PostgreSQL.

## Details

N/A

### Configuration

No special configuration is necessary

## Installing the Chart

Install the catalog source for this operator by running the "installCatalog" action in the "ibmCloudNativePostgresqlOperator" inventory:

```
cloudctl case launch               \
    --case ./ibm-cpd-edb           \
    --namespace openshift-marketplace \
    --inventory ibmCloudNativePostgresqlOperator     \
    --action installCatalog       \
    --args "--recursive --inputDir ."
```

Then install the operator by running the "install" action:

```
cloudctl case launch               \
    --case ./ibm-cpd-edb           \
    --namespace <target namespace> \
    --inventory ibmCloudNativePostgresqlOperator     \
    --action installOperator       \
    --args "--recursive --inputDir ."
```

Use "openshift-operators" as your target namespace to install cluster wide.  Otherwise, provide the name of the namespace in which to create the operator.

# Limitations

**Namespace Scoping**:

The operator is supported for AllNamespaces or OwnNamespace support.  By deploying into the openshift-operators, the operator will watch all namespaces.  In order to watch individual namespaces, deploy a subscription of the operator to that namespace.

## Prerequisites

N/A

### Resources Required

Minimum memory - 2 GB
Minimum CPU - 1 vCPU
Minimum storage - 100 GB

# PodSecurityPolicy Requirements

This release is only for Openshift, and uses SecurityContextConstraints

# SecurityContextConstraints Requirements

Custom PodSecurityPolicy definition:
```
```

Custom SecurityContextConstraints definition:
```
```

No custom SCC is used. This case bundle uses the "restricted" default SCC:

```
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: []
apiVersion: v1
defaultAddCapabilities: []
fsGroup:
  type: MustRunAs
groups:
- system:authenticated
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
  creationTimestamp: null
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SYS_CHROOT
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
