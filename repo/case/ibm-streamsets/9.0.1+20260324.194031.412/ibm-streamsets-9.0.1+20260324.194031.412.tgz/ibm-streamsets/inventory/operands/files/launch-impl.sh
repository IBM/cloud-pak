# IBM Confidential
# PID 5900-BAF
# Copyright IBM Corp., Year 2025

# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this dp operator

# dp operator specific variables
caseName="ibm-streamsets"
inventory="streamsets"
caseCatalogName="ibm-streamsets-operator-catalog"
channelName="alpha"
# - variables specific to catalog/operator installation
case_depedencies=""
pvcName="data-ibm-streamsets-mysql-deploy-0"


parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageclass)
        storageclass=$val
        ;;
    --service)
        service=$val
        ;;
    --license-accept)
        license_accept=1
        ;;
    --license-type)
        license_type=$val
      ;;
    --production)
        production=$val
        ;;
    esac
}

# ----- INSTALL ACTIONS -----
# install operand custom resources
apply_custom_resources() {
    echo "start apply_custom_resources()"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/config/samples

    # apply stand alone resources required for bootstrapping other resources
    ls -1d $cr/*_misc-resources.yaml | xargs -I {} sh -c 'sed "s#PRODUCTION_LICENSE#${2}#g" < "$1" | ${3} apply -n ${4} -f -' _ {} "$production" "$kubernetesCLI" "$namespace"
    ls -1d $cr/*_static-resources.yaml | xargs -I {} sh -c 'sed "s#PRODUCTION_LICENSE#${2}#g" < "$1" | ${3} apply -n ${4} -f -' _ {} "$production" "$kubernetesCLI" "$namespace"

    wait_for_resource_create "secret/ibm-streamsets-db-service-account" 30
    ls -1d $cr/*_mysql.yaml | xargs -I {} sh -c 'sed "s#PRODUCTION_LICENSE#${2}#g" < "$1" | ${3} apply -n ${4} -f -' _ {} "$production" "$kubernetesCLI" "$namespace"

    wait_for_resource_create "statefulset/ibm-streamsets-mysql-deploy" 30
    $kubernetesCLI rollout status -n ${namespace} --timeout=900s statefulset/ibm-streamsets-mysql-deploy

    ls -1d $cr/*_security.yaml | xargs -I {} sh -c 'sed "s#PRODUCTION_LICENSE#${2}#g" < "$1" | ${3} apply -n ${4} -f -' _ {} "$production" "$kubernetesCLI" "$namespace"
    # wait for security and static-content to rollout to complete before starting additional services
    wait_for_resource_create "job/ibm-streamsets-security-bootstrap" 30
    $kubernetesCLI wait -n ${namespace} --for=condition=complete --timeout=900s job/ibm-streamsets-security-bootstrap
    wait_for_resource_create "job/ibm-streamsets-security-dbinit" 30
    $kubernetesCLI wait -n ${namespace} --for=condition=complete --timeout=900s job/ibm-streamsets-security-dbinit
    wait_for_resource_create "deployment/ibm-streamsets-security" 30
    $kubernetesCLI rollout status -n ${namespace} --timeout=900s deployment/ibm-streamsets-security
    wait_for_resource_create "deployment/ibm-streamsets-static-content" 300
    $kubernetesCLI rollout status -n ${namespace} --timeout=900s deployment/ibm-streamsets-static-content

    # apply everything not currently rolled out
    find $cr -name "*.yaml" ! \( -name "*_security.yaml" -o -name "*_mysql.yaml" -o -name "*_misc-resources.yaml" -o -name "*_static-resources.yaml"  -o -name "*_service-status.yaml" -o -name "*_icp4data.yaml" \) | xargs -I {} sh -c 'sed "s#PRODUCTION_LICENSE#${2}#g" < "$1" | ${3} apply -n ${4} -f -' _ {} "$production" "$kubernetesCLI" "$namespace"
    sleep 120
    $kubernetesCLI wait -n ${namespace} --for=condition=complete --selector=icpdsupport/addOnId=streamsets --timeout=900s job
    $kubernetesCLI rollout status -n ${namespace} --selector=icpdsupport/addOnId=streamsets --timeout=900s deployment

    # Install servicestatus
    $kubernetesCLI apply -f $cr/*_service-status.yaml -n ${namespace}

    # Install zenextension
    $kubernetesCLI apply -f $cr/*_icp4data.yaml -n ${namespace}

    echo "Registering service"
    local service_url=$($kubernetesCLI get cm product-configmap -o json -n ${namespace} | jq -r '.data.URL_PREFIX')
    local zen_broker_token=$($kubernetesCLI get secret zen-service-broker-secret -o json -n ${namespace} | jq -r '.data.token' | base64 -d)
    local admin_user=$($kubernetesCLI get secret ibm-iam-bindinfo-platform-auth-idp-credentials -o json -n ${namespace} | jq -r '.data.admin_username' | base64 -d)

    local zen_bearer_token=$(curl -k --request GET \
      --url "https://${service_url}/zen-data/internal/v1/service_token?permissions=administrator%2Ccan_provision&expiration_time=20" \
      --header "secret: ${zen_broker_token}" | jq -r '.token')

    curl -k --request PUT \
      --url "https://${service_url}/zen-data/v1/addons/sources/file/zen-addon-cm-streamsets" \
      --header "Authorization: Bearer ${zen_bearer_token}" \
      --header 'content-type: multipart/form-data' \
      --form 'add_ons_tar=@./ibm-streamsets/inventory/streamsets/files/op-cli/config/resources/add-on.tgz'


    local admin_uid=$(curl -k --request GET \
      --url "https://${service_url}/usermgmt/v1/user/${admin_user}" \
      --header "Authorization: Bearer ${zen_bearer_token}" | jq -r '.uid')

    local zen_admin_token=$(curl -k --request GET \
      --url "https://${service_url}/zen-data/internal/v1/service_token?permissions=administrator%2Ccan_provision&expiration_time=20&uid=${admin_uid}" \
      --header "secret: ${zen_broker_token}" | jq -r '.token')

    local service_creation_status=$(curl -k -s -o /dev/null -w "%{http_code}" --request POST \
      --url "https://${service_url}/zen-data/v3/service_instances" \
      --header "Content-Type: application/json" \
      --header "Authorization: Bearer ${zen_admin_token}" \
      --data '{"addon_type":"streamsets","display_name":"streamsets","namespace":"'"$namespace"'","addon_version":"5.3.0","create_arguments":{"resources":{},"parameters":{},"description":"","metadata":{},"owner_username":""},"pre_existing_owner":false,"transientFields":{}}')

    if [ "$service_creation_status" == "200" ]; then
      echo "service creation failed."
      exit 1
    fi

    echo "complete apply_custom_resources()"
}

delete_custom_resources() {
    echo "start delete_custom_resources()"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/config/samples
    $kubernetesCLI delete -n "${namespace}" -f "${cr}"

    # delete pvc
    $kubernetesCLI delete pvc ${pvcName}
    echo "complete delete_custom_resources()"
}

wait_for_resource_create() {
  local resource=$1
  local max_wait_secs=$2
  local interval_secs=2
  local start_time=$(date +%s)
  while true; do
    current_time=$(date +%s)
    if (( (current_time - start_time) > max_wait_secs )); then
      echo "Polling for resource $resource failed to find resource"
      return 1
    fi

    if $kubernetesCLI -n "${namespace}" get "$resource" &> /dev/null; then
      echo "Resource found, $resource, continuing."
      break
    else
      sleep $interval_secs
    fi
  done
}
