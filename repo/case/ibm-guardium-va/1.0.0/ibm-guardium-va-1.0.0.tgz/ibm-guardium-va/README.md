# Name

IBM Guardium Vulnerability Assessment

# Introduction
IBM® Guardium® Vulnerability Assessment software scans on-premises and cloud database infrastructure to detect vulnerabilities and orchestrate remedial actions. It is part of the IBM Guardium family of data security software.

Identifying vulnerabilities in your data environments is key to understanding and managing your data security posture. IBM Guardium Vulnerability Assessment scans data infrastructure such as databases, data warehouses, and big data environments — both on-premises and in the cloud — to detect vulnerabilities and suggest remedial actions based on benchmarks from STIG, CIS, CVE, and other configuration standards.

Guardium Vulnerability Assessment identifies security gaps in databases such as missing patches, weak passwords, unauthorized changes, misconfigured privileges, excessive administrative logins, unusual after-hours activity, and other behavioral vulnerabilities such as account sharing. It then provides full reports as well as actionable recommendations to address vulnerabilities to harden your database environments.

Guardium Vulnerability Assessment is delivered as a part of Guardium Data Protection, but can be implemented as a stand-alone offering that serves its own use case.
