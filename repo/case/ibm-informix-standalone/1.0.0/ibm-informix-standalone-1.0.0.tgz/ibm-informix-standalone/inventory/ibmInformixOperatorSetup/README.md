# ibmInformixOperatorSetup
Informix Operator Setup images