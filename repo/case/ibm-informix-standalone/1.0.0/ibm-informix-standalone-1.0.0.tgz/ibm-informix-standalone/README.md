# Name

IBM&reg; Informix Operator for IBM Cloud Pak for Data

# Introduction

## Summary

The IBM Informix Operator packages, deploys, and manages IBM Informix as a Kubernetes application. IBM Informix is an embeddable database that is optimized for online transaction processing (OLTP) data and Internet of Things (IoT) data. Informix seamlessly integrates time series, spatial, NoSQL, and SQL data. Its versatility and ease of use make Informix the ideal solution, whether you need a database for individual application development or an enterprise data warehouse.

## Features

- [Knowledge Center](https://www.ibm.com/docs/en/informix-servers/14.10)
- Supports an HADR (High availability disaster recovery) configuration
- Automatic upgrades 
- Customizable persistent storage
- Custom Labels and Annotations for integration with other services
- Includes MQTT, REST & MongoDB APIs

# Details

## Prerequisites
# PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:

```
   apiVersion: policy/v1beta1
   kind: PodSecurityPolicy
   metadata:
     name: informix-psp
   spec:
     allowPrivilegeEscalation: true
     readOnlyRootFilesystem: false
     privileged: false
     allowedCapabilities:
       - "SYS_RESOURCE"
       - "IPC_OWNER"
       - "SYS_NICE"
       - "NET_RAW"    
       - "CHOWN"
       - "DAC_OVERRIDE"
       - "FSETID"
       - "FOWNER"
       - "SETGID"
       - "SETUID"
       - "SETFCAP"
       - "SETPCAP"
       - "NET_BIND_SERVICE"
       - "SYS_CHROOT"
       - "KILL"
       - "AUDIT_WRITE"
     fsGroup:
       rule: RunAsAny
     hostIPC: true
     hostNetwork: false
     hostPID: false
     hostPorts:
     - max: 65535
       min: 1
     runAsUser:
       rule: RunAsAny
     seLinux:
       rule: RunAsAny
     supplementalGroups:
       rule: RunAsAny
     volumes:
     - '*'
```
# SecurityContextConstraints Requirements
### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

 ```
   kind: SecurityContextConstraints
   apiVersion: security.openshift.io/v1
   metadata:
     name: informix-scc
   allowHostDirVolumePlugin: false
   allowHostIPC: false
   allowHostNetwork: false
   allowHostPID: false
   allowHostPorts: false
   allowPrivilegedContainer: false
   allowedCapabilities:
   - "SYS_RESOURCE"
   - "IPC_OWNER"
   - "SYS_NICE"
   - "NET_RAW"
   - "CHOWN"
   - "DAC_OVERRIDE"
   - "FSETID"
   - "FOWNER"
   - "SETGID"
   - "SETUID"
   - "SETFCAP"
   - "SETPCAP"
   - "NET_BIND_SERVICE"
   - "SYS_CHROOT"
   - "KILL"
   - "AUDIT_WRITE"
   readOnlyRootFilesystem: false
   runAsUser:
     type: RunAsAny
   seLinuxContext:
     type: MustRunAs
   fsGroup:
     type: RunAsAny
   supplementalGroups:
     type: RunAsAny
 ```
### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |             |             |           |       |

# Installing

* Include installation instructions or links to documentation
* Include the basic things necessary to install the product
* Include environment setup or any other items required

## Configuration

* Provide configuration instructions if any

## Storage

* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## Limitations

* Deployment limits - can you deploy more than once, can you deploy into different namespace
* List specific limitations such as platforms, security, replica's, scaling, upgrades etc.. - noteworthy limits identified
* List deployment limitations such as : restrictions on deploying more than once or into custom namespaces.
* Not intended to provide chart nuances, but more a state of what is supported and not - key items in simple bullet form.
* Does it work on IBM Kubernetes Services, IBM Private Cloud ?

## Documentation

* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.