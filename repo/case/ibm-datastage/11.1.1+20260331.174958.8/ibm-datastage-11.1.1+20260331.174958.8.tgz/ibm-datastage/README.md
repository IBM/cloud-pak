# Name

IBM&reg; DataStage Enterprise Plus on Cloud Pak for Data

# Introduction

## Summary

Use DataStage Enterprise Plus to access all the capabilities that DataStage Enterprise has, but with additional useful data quality features.

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=SSQNUZ_4.0/svc-welcome/dsentplus.html)

## Features

* A best-in-breed parallel processing engine that enables you to process your data where it resides
* Automated job design
* Simple integration with cloud data lakes, real-time data sources, relational databases, big data, and NoSQL data stores
* Cleansing data by identifying potential anomalies and metadata discrepancies
* Identifying duplicates by using data matching and probabilistic matching of data entities between two data sets

# Details

## Prerequisites

- OpenShift Version >= 4.6
- IBM Cloud Pak for Data >= 4.0.2
- IBM Cloud Pak for Data Common Core Services (CCS) >= 2.0.2 (The DataStage service automatically installs the CCS if they are not already installed.)

### Resources Required

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=requirements-hardware)

# Installing

The installation includes the following major steps:

1. Configuring your cluster to pull Cloud Pak for Data images
2. Configuring an image content source policy
3. Creating the catalog source
4. Creating operator subscriptions
5. Creating a custom resource

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=datastage-installing)

## Configuration

To scale DataStage services, you can specify spec.scaleConfig in the DataStage custom resource to small, medium, or large.

## Storage

The DataStage service is configured to use dynamic provisioning. The installation will require about 300GB of your storage. Make sure to select a storageclass with enough resources available.

DataStage supports the following storage classes:

- OpenShift Container Storage: ocs-storagecluster-cephfs
- IBM Spectrum Scale Container Native: ibm-spectrum-scale-sc
- NFS: managed-nfs-storage
- Portworx: portworx-shared-gp3
- IBM Cloud File Storage: ibmc-file-gold-gid or ibm-file-custom-gold-gid

See [details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=requirements-storage)


## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```
### Custom PodSecurityPolicy definition:

```
Not Applicable
```

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restrict denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restrict
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Limitations

- Only the`x86-64` platform is supported by this operator.
- See [Limitations and known issues in DataStage](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=issues-datastage)

## Documentation

- Product documentation for IBM DataStage Enterprise Plus on Cloud Pak for Data can be found [here](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=SSQNUZ_4.0/svc-welcome/dsentplus.html)
