# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ds operator

# ds operator specific variables
#caseName="ibm-sample-panamax"
caseName="ibm-datastage"
#inventory="panamaxOperatorSetup"
inventory="dsOperatorSetup"
#caseCatalogName="ibm-sample-panamax-catalog"
caseCatalogName="ibm-ds-operator-catalog"
catalogNamespace="openshift-marketplace"

channelName="v10.6"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ds-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:tbd}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-wcp-datastage-team-docker-local.artifactory.swg-devops.com}"
CATALOG_IMAGE="${CATALOG_IMAGE:-ds-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:tbd}"
BUILD_NUMBER="3"
entitledRegistry="wcp-datastage-team-docker-local.artifactory.swg-devops.com"
storageclass=""
backupstorageclass=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}


# install operand custom resources
apply_custom_resources() {
    echo "start apply_custom_resources()"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/ds_v1_datastage.yaml

    echo "storageclass: ${storageclass}"
    if [[ -z ${storageclass} ]]; then
        echo "storageclass is empty"
        storageclass="nfs-client"
    fi

    sed -i "s/namespace: ds/namespace: ${namespace}/g" $cr
    sed -i "s/storageClass: nfs-client/storageClass: ${storageclass}/g" $cr

    oc apply -f $cr -n ${namespace}

    echo "wating for DS pods to be ready ..."
    waitForDSPods
    echo "complete apply_custom_resources()" 
}

waitForDSPods()
{
    echo "start waitForDSPods()"
    waitIteration=120
    waitSeconds=10
    sleep 60
    for ((i=1; i<=${waitIteration}; i++))
    do
        dsCount=`kubectl get pods -n ${namespace} | grep -c datastage` || true
        if [[ $dsCount -eq 1 || $dsCount -eq 9 ]]; then
            sleep 30
        fi
        kubectl get pods -n ${namespace} | grep datastage | egrep -v "1/1|2/2|3/3|Completed" > /tmp/pods_in_progress.tmp || true
        count=`cat /tmp/pods_in_progress.tmp | wc -l`
        if [ $count -eq 0 ]; then
           runningPod=`kubectl get pods -n ${namespace} | grep datastage | egrep -c "1/1|2/2|3/3"` || true
           if [ $runningPod -eq 9 ]; then
               break
           fi
        else
           echo "Pods in progress: $count, iter: $i"
           cat /tmp/pods_in_progress.tmp
           sleep ${waitSeconds}
        fi
    done
    if [ $count -gt 0 ]; then
        echo "The following pods are still not ready or have issues:"
        cat /tmp/pods_in_progress.tmp
        exit 1
    fi
    echo "complete waitForDSPods()"
}

delete_custom_resources() {
    echo "start delete_custom_resources()"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/ds_v1_datastage.yaml
    sed -i "s/namespace: ds/namespace: ${namespace}/g" $cr
    sed -i "s/storageClass: nfs-client/storageClass: ${storageclass}/g" $cr
    oc delete -n "${namespace}" -f "${cr}"
    oc delete -n "${namespace}" pxruntimes ds-px-default
    echo "wait for datastage resources to be deleted ..."
    waitForDSPodsDeletion
    echo "complete delete_custom_resources()"
}

waitForDSPodsDeletion()
{
    echo "start waitForDSPodsDeletion()"
    waitIteration=120
    waitSeconds=10
    sleep 60
    for ((i=1; i<=${waitIteration}; i++))
    do
        dsCount=`kubectl get pods -n ${namespace} | grep -c datastage` || true
        if [ $dsCount -eq 0 ]; then
           break
        else
           echo "Pods in progress: $dsCount, iter: $i"
           kubectl get pods -n ${namespace} | grep datastage || true
           sleep ${waitSeconds}
        fi
    done
    if [ $dsCount -gt 0 ]; then
        echo "The following pods are still not deleted:"
        kubectl get pods -n ${namespace} | grep datastage || true
        exit 1
    fi
    echo "complete waitForDSPodsDeletion()"
}
