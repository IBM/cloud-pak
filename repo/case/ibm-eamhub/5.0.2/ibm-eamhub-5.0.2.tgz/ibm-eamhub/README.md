## Introduction

IBM Edge Application Manager (IEAM) provides a fully autonomous, secure, end-to-end **Application Management Platform** for applications deployed to the edge (devices, gateways and edge clusters). The platform frees up operations from the tedious task of securely deploying edge workloads on thousands of field-deployed edge nodes. It also enables application developers to focus on the task of writing containerized application code without concern for deployment details. Edge workloads are written in any programming language, and packaged and deployed as containers. The platform also deploys machine learning models autonomously and independently to enable edge workloads to perform AI tasks at the time and place where the most business impact can be realized.

[IBM Edge Application Manager](https://www.ibm.com/cloud/edge-application-manager)

## Details

This Operator deploys and configures the IEAM container workload onto an OpenShift Container Platform.

## Prerequisites

See the following for [Prerequisites](https://www.ibm.com/docs/en/eam/5.0?topic=installation-install-ieam#prereq).

## Resources Required

See the following for [Sizing Information](https://www.ibm.com/docs/en/eam/5.0?topic=hub-sizing-system-requirements).

## Installing

See the following for [Installation Instructions](https://www.ibm.com/docs/en/eam/5.0?topic=hub-installation).

## Configuration

See the following for [Configuration Options](https://www.ibm.com/docs/en/eam/5.0?topic=hub-configuration).

## Limitations

- A cluster admin role and OpenShift 4.8 or higher is required to run this workload.
- Only one instance of IEAM can be deployed to a single cluster.
- Secure Device Onboarding, MongoDB, and Secrets Manager are deployed without High Availability support.

## Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

This workload requires the OpenShift nonroot and restricted Security Context Constraints to run.

