#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script is a utility to install a product bundled in CASE in online and air gap environment
# This script can be invoked using cloudctl tool (github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli)
# This script serves as an interface which defines install actions, functions and their inputs

# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="installOperator"
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName=""

# - optional parameter / argument defaults
dryRun=""
namespace=""
channelName="v5.0"
catalogNamespace=""
registry=""
pass=""
secret=""
user=""

# script version
version=0.7.0

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --args \"args\" --namespace namespace

OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace

 ARGS per Action:
    installCatalog:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry (icr.io/cpopen used if not specified)

    installOperator:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --catalogNamespace       : namespace where CatalogSource instance is located (openshift-marketplace by default)
      --channelName            : name of channel for subscription (packagemanifest default used if not specified)
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)

    uninstallCatalog          : uninstalls the catalog source and operator group
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations

    uninstallOperator         : delete the operator deployment via OLM
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ----- Actions -----
# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"

    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --channelName)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            channelName="${v}"
            ;;
        --catalogNamespace)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            catalogNamespace="${v}"
            ;;
        --registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry="${v}"
            ;;
        --user)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            user="${v}"
            ;;
        --pass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pass="${v}"
            ;;
        --secret)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            secret="${v}"
            ;;
        --help)
            print_usage 0
            ;;
        *)
            err_exit "Invalid Option ${v}"
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    check_kube_connection
    check_kube_namespace
}

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exit "No oc or kubectl found in path"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

check_kube_namespace() {
    [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
    if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
        err_exit "Unable to retrieve namespace specified ${namespace}"
    fi
}

# Validates that the required args were specified for install action
validate_install_args() {
    if [[ -z ${catalogNamespace} ]]; then
        err "catalogNamespace value missing"
        print_usage 1
    fi
    
    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" && -n "${user}" && -n "${pass}" && -n "${secret}" ]]; then
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    else
        err "Please provide combination of a registry name, a username, a password and a secret name in order to log in to a Docker registry or the name of an already existing secret"
        print_usage 1
    fi
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** UTILS *****

# Print version
print_version() {
    echo "[INFO] Version ${version}"
    exit 0
}

# Error reporting functions
err() {
    echo >&2 "[ERROR] $1"
}
err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

# ----- ABSTRACT FUNCTIONS -----
# the below functions can be overridden in launch implementation script

# ----- INSTALL ACTIONS -----

install_catalog() {
    echo "Action not supported"
}

install_operator() {
    echo "Action not supported"
}

# ----- UNINSTALL ACTIONS -----

uninstall_catalog() {
    echo "Action not supported"
}

uninstall_operator() {
    echo "Action not supported"
}

# ----- END ACTIONS -----

##
# Main
##
source "$scriptDir"/launch-impl.sh

# Parse CLI parameters
while [ "${1-}" != "" ]; do
    case $1 in
    # Supported parameters for cloudctl & direct script invocation
    --casePath | -c)
        shift
        casePath="${1}"
        ;;
    --caseJsonFile)
        shift
        caseJsonFile="${1}"
        ;;
    --inventory | -e)
        shift
        inventory="${1}"
        ;;
    --action | -a)
        shift
        action="${1}"
        ;;
    --namespace | -n)
        shift
        namespace="${1}"
        ;;
    --args | -r | --)
        shift
        parse_dynamic_args "${1}"
        ;;
    # Additional supported parameters for direct script invocation ONLY
    --help)
        print_usage 0
        ;;
    --debug)
        set -x
        ;;
    --version)
        print_version
        ;;
    *)
        echo "Invalid Option ${1}" >&2
        exit 1
        ;;
    esac
    shift
done

# Execution order
check_cli_args
run_action