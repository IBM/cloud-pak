# Name

IBM&reg; Watson Speech

# Introduction

This document contains installation instructions for both IBM Watson™ Speech to Text and Text to Speech solutions.

IBM Watson™ Speech to Text (STT) provides speech recognition capabilities for your solutions. The service leverages machine learning to combine knowledge of grammar, language structure, and the composition of audio and voice signals to accurately transcribe the human voice. It continuously updates and refines its transcription as it receives more speech.

IBM Watson™ Text to Speech (TTS) service converts written text to natural-sounding speech to provide speech-synthesis capabilities for applications. It gives you the freedom to customize your own preferred speech in different languages. This cURL-based tutorial can help you get started quickly with the service.

## Summary

This CASE can be used to install a single instance of both the STT and TTS solutions. The solutions can be installed separately, however if both are installed together they share datastores for a more efficient utilization of resources and simplified support.

## Details

The CASE contains two inventory items:

    speechOperator - applying Watson Speech custom resource
    speechOperatorSetup - installing Watson Speech operator by OLM


## Features

* Speech to Text
* Text to Speech

## Prerequisites

* For updated information on prerequisites refer to Before you begin page in [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=text-installing-watson-speech)

Dependent Datastores CASES:

Minio: https://github.com/IBM/cloud-pak/tree/master/repo/case/ibm-minio-operator

RabbitMq: https://github.com/IBM/cloud-pak/tree/master/repo/case/ibm-rabbitmq-operator

EDB Cloud Native Postgres: https://github.com/IBM/cloud-pak/tree/master/repo/case/ibm-cloud-native-postgresql

Watson Gateway: https://github.com/IBM/cloud-pak/tree/master/repo/case/ibm-watson-gateway-operator

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
This product runs with the 'restricted' SCC

### Resources Required

Updated information on hardware requirements can be found in [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=requirements-hardware)  
The following table provides system requirements for the various supported deployment sizes for Speech to Text:

| Resource | Large   | Medium | Small  | xsmall | custom |
| -------- | ------- | ------ | ------ | -------|--------|
| vCPU     |    42   |   26   |    18  |  11    |  18+   |
| Memory   |  120 GB | 77 GB  | 63 GB  |  35 GB | 63+ GB |

Disk Storage: Depends on the selected models and usage pattern 

The following table provides system requirements for the various supported deployment sizes for Text to Speech:

| Resource | Large   | Medium | Small  | xsmall | custom |
| -------- | ------- | ------ | ------ | -------|--------|
| vCPU     |    35   |   19   |    11  |  6     |  11+   |
| Memory   |  70 GB  | 37 GB  | 24 GB  |  12 GB | 24+ GB |

Disk Storage: Depends on the selected voices and usage pattern

### Supported Platforms

Updated information on software requirements can be found in [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=requirements-software)



# Installing Watson Speech

Installation guidelines for Watson Speech can be found in [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=text-installing-watson-speech).


## Configuration

* For updated information on configuring Watson Speech, please refer to [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=text-specifying-custom-resource-watson-speech).

## Storage

The storage class for the dependent datastores needs to be setup before installation. Updated information on storage requirements can be found in [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=requirements-storage)

## Limitations

The product supports the following:
* Supports `x86_64` architecture only
* CPUs must support the AVX2 instruction set.

## Documentation

* [IBM Watson Speech Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=text-installing-watson-speech)
