# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this watson speech operator

# speech operator specific variables
caseName="ibm-watson-speech"
inventory="speechOperatorSetup"
caseCatalogName="${caseName}-operator-catalog"
caseSubscriptionName="${caseName}-operator-subscription"
catalogNamespace="cpd-operator"
channelName="alpha"
#cr_system_status="betterThanYesterday"
case_depedencies=( "ibm-cloud-native-postgresql" "ibm-minio-operator" "ibm-rabbitmq-operator" "ibm-watson-gateway-operator" )

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="
  --tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}

OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}

 ARGS per Action:
    configure-creds-airgap
      --registry               : source/target container image registry (required)
      --user                   : login user name for the container image registry (required)
      --pass                   : login password for the container image registry (required)

    configure-cluster-airgap
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory
      --registry               : target container image registry (required)

    configure-cluster
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry (required)

    image-info                 : list image registries and namespaces used in mirroring
      --inputDir               : path to saved CASE directory (required)

    mirror-images
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)
      --fromRegistry           : override the source image registry in the CASE
      --registry               : target container image registry (required)
      --chunks                 : mirror the images in batches with a given size. Default is 100
      --groups                 : list of image groups to mirror
      --skipDelta              : copy all of the images and not just the delta

    install
      --registry               : source/target container image registry
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --secret                 : name of existing image pull secret for the container image registry
      --groups                 : list of image groups to install

    install-catalog:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
      --groups                 : list of image groups to filter catalog

    install-operator:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --channelName            : name of channel for subscription (packagemanifest default used if not specified)
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)

    uninstall                  : uninstall the product

    uninstall-catalog          : uninstalls the catalog source and operator group
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)

    uninstall-operator         : delete the operator deployment via OLM
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations

    apply-custom-resources     : creates the sample custom resource

    delete-custom-resources    : deletes the same custom resource

    init-registry              : configure a local docker registry with self-sign certificate
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --subject                : self-sign TLS certificate subject
      --registry               : IP or FQDN for the docker registry ( default: $(hostname -f))
      --clean                  : clean up all existing repositories data


    start-registry             : start a local docker registry container
      --port                   : registry service port (default: 5000 )
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --engine                 : container engine to run the container (docker or podman)
      --image                  : docker registry image (default: docker.io/library/registry:2.6)

    stop-registry              : stop a local docker registry container
      --engine                 : container engine to run the container (docker or podman)

    create-postgres-licensekey : creates the license key secret for PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations

    delete-postgres-licensekey : deletes the license key secret for PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations

    install-postgres-operator  : installs PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)

    uninstall-postgres-operator: Uninstalls PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ----- Actions -----
# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    configureCluster)
        configure_cluster
        ;;
    configureClusterAirgap)
        configure_cluster_airgap
        ;;
    configureCredsAirgap)
        configure_creds_airgap
        ;;
    install)
        install
        ;;
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    # installOperatorNative)
    #     install_operator_native
    #     ;;
    imageInfo)
        image_info
        ;;
    mirrorImages)
        mirror_images
        ;;
    uninstall)
        uninstall
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    # uninstallOperatorNative)
    #     uninstall_operator_native
    #     ;;
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    initRegistry)
        init_registry
        ;;
    startRegistry)
        start_registry
        ;;
    stopRegistry)
        stop_registry
        ;;
    createPostgresLicensekey)
        create_postgres_licensekey
        ;;
    deletePostgresLicensekey)
        delete_postgres_licensekey
        ;;
    installPostgresOperator)
        install_postgres_operator
        ;;
    uninstallPostgresOperator)
        uninstall_postgres_operator
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# parse additional dynamic args
# parse_custom_dynamic_args() {
#     key=$1
#     val=$2
#     case $key in
#     --systemStatus)
#         cr_system_status=$val
#         ;;
#     esac
# }

# TODO - not clear
# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-minio-operator)
        echo "ibmMinioOperatorSetup"
        return 0
        ;;
    ibm-rabbitmq-operator)
        echo "ibmRabbitmqOperatorSetup"
        return 0
        ;;
    ibm-cloud-native-postgresql)
        echo "ibmCloudNativePostgresqlOperator"
        return 0
        ;;
    ibm-watson-gateway-operator)
        echo "ibmWatsonGatewayOperatorSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# TODO - not clear
# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    if [ ! -z "$registry" ]; then
        registry_arg="--registry ${registry}"
    else
        registry_arg=""
    fi

    for dep in ${case_depedencies[@]}; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")



        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in ${case_depedencies[@]}; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        # tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
        sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
# install_operator_native() {
#     # Verfiy arguments are valid
#     validate_install_args

#     # Proceed with install
#     echo "-------------Installing native sdk1-------------"

#     # Verify expected yaml files for install exist
#     local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
#     local manifest_file="${op_cli_files}/manifestsNativeDeploy.yaml"

#     validate_file_exists "${manifest_file}"

#     # Apply yaml files manipulate variable input as required
#     $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${manifest_file}"
# }

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/speech_v1_watsonspeech.yaml

    validate_file_exists "$cr"

    sed -e "s|speech-prod-.*|speech-prod-${instance}|g" -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in ${case_depedencies[@]}; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in ${case_depedencies[@]}; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${catsrc_file}" | tee >($kubernetesCLI delete --ignore-not-found=true  ${dryRun} -n "${namespace}" -f -) | cat
    # $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseSubscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseSubscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
# uninstall_operator_native() {
#    # Verfiy arguments are valid
#     validate_install_args

#     # Proceed with install
#     echo "-------------Uninstalling native -------------"

#     # Verify expected yaml files for install exist
#     local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
#     local manifest_file="${op_cli_files}/manifestsNativeDeploy.yaml"

#     validate_file_exists "${manifest_file}"

#     # Apply yaml files manipulate variable input as required
#     $kubernetesCLI delete ${dryRun} -n "${namespace}" -f "${manifest_file}"
# }

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/speech_v1_watsonspeech.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    sed -e "s|speech-prod-.*|speech-prod-${instance}|g" "${cr}" | $kubernetesCLI delete -n "${namespace}" ${dryRun} -f -
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}


# ----- Custom Postgres Actions -----
create_postgres_licensekey() {
  local -a args=(
      "--namespace"
      "$namespace"
  )
  if [[ -n "${dryRun}" ]]; then
      args+=(
          "--dry-run"
      )
  fi
  "${scriptDir}/postgres.sh" licensekey create "${args[@]}"
}

delete_postgres_licensekey() {
  local -a args=(
      "--namespace"
      "$namespace"
  )
  if [[ -n "${dryRun}" ]]; then
      args+=(
          "--dry-run"
      )
  fi
  "${scriptDir}/postgres.sh" licensekey delete "${args[@]}"
}

validate_postgres_operator_command_arg() {
    if [[ -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter"
        print_usage 1
    fi
}

run_postgres_sh_operator() {
    local action="$1"

    validate_postgres_operator_command_arg

  	local postgres_case
    postgres_case="$(dependent_case_tgz "ibm-cloud-native-postgresql" "${inputcasedir}")"
    local -a args=(
        "--namespace"
        "$namespace"
        "--tolerance"
        "${tolerance_val}"
        "--case-path"
        "${postgres_case}"
    )
    if [[ -n "${dryRun}" ]]; then
        args+=(
            "--dry-run"
        )
    fi
    "${scriptDir}/postgres.sh" operator "$action" "${args[@]}"
}

install_postgres_operator() {
    run_postgres_sh_operator install
}

uninstall_postgres_operator() {
    run_postgres_sh_operator uninstall
}

# ***** END ACTIONS *****
