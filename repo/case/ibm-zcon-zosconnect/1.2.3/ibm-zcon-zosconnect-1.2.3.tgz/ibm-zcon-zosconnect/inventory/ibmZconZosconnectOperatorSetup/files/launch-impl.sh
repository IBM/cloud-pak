# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Implements the CASE launch actions for the IBM z/OS Connect Operator.
# Sourced by launch.sh — do not invoke directly.

# ----- Operator-specific constants -----

caseName="ibm-zcon-zosconnect"
inventory="ibmZconZosconnectOperatorSetup"
caseCatalogName="ibm-zcon-zosconnect-catalog"
catalogNamespace="openshift-marketplace"
channelName="v1.0"

# ----- Install -----

# Creates an OperatorGroup in the target namespace if one does not already exist.
install_operator_group() {
    echo "Checking for existing OperatorGroup in namespace '${namespace}' ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "OperatorGroup already exists — skipping creation."
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "No OperatorGroup found — creating one."

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | \
        tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Applies the CatalogSource to openshift-marketplace.
# When --registry is supplied, the image reference is rewritten to point at the private registry.
install_catalog() {
    echo "--- Installing CatalogSource ---"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    validate_file_exists "${catsrc_file}"

    if [[ -z "${registry}" ]]; then
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        local orig_image
        orig_image=$(grep "image:" "${catsrc_file}" | awk '{print $2}')
        local new_image="${registry}/$(echo "${orig_image}" | sed -e "s/[^/]*\///")"
        sed -e "s|${orig_image}|${new_image}|g" "${catsrc_file}" | \
            tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "Done."
}

# Creates an OperatorGroup (if needed) and a Subscription for the z/OS Connect Operator.
install_operator() {
    validate_install_args

    install_operator_group

    echo "--- Installing operator via OLM ---"

    local sub_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${sub_file}"

    echo "Verifying CatalogSource '${caseCatalogName}' exists in '${catalogNamespace}' ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "CatalogSource '${caseCatalogName}' not found in namespace '${catalogNamespace}'. Run installCatalog first."
    fi

    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${sub_file}" | \
        sed "s|REPLACE_CHANNEL_NAME|${channelName}|g" | \
        tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- Uninstall -----

# Removes the CatalogSource, OperatorGroup, and Subscription.
uninstall_catalog() {
    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    local sub_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"

    echo "--- Uninstalling CatalogSource, OperatorGroup, and Subscription ---"
    $kubernetesCLI delete -f "${catsrc_file}"  --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete -f "${opgrp_file}"   --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete -f "${sub_file}"     --ignore-not-found=true ${dryRun}
}

# Removes the operator Subscription, installed CSV, OperatorGroup, and CatalogSource.
uninstall_operator() {
    echo "--- Uninstalling operator ---"

    local csvName
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}-subscription" \
        -o go-template --template '{{.status.installedCSV}}' \
        -n "${namespace}" --ignore-not-found=true)

    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" \
        -n "${namespace}" --ignore-not-found=true ${dryRun}

    [[ -n "${csvName}" ]] && \
        $kubernetesCLI delete clusterserviceversion "${csvName}" \
            -n "${namespace}" --ignore-not-found=true ${dryRun}

    $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" \
        -n "${namespace}" --ignore-not-found=true ${dryRun}

    $kubernetesCLI delete CatalogSource "${caseCatalogName}" \
        -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

uninstall() {
    uninstall_operator
}
