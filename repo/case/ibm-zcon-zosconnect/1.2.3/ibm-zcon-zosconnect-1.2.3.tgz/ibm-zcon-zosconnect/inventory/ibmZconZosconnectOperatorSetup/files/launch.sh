#!/usr/bin/env bash
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Entry point for CASE launch actions. Invoked by `oc ibm-pak launch` or directly.
# Action implementations are in launch-impl.sh, which is sourced at the bottom of this file.

# ***** GLOBALS *****

kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# CLI parameter defaults
action="installOperator"
casePath="${scriptDir}/../../.."
namespace=""

# --args parameter defaults
dryRun=""
registry=""
user=""
pass=""
secret=""
channelName=""

# script version
version=0.14.0

# ***** USAGE *****

print_usage() {
    echo "
USAGE: ${scriptName} --casePath <CASE-PATH> --inventory <INVENTORY> --action <ACTION> --namespace <NAMESPACE>
                  --args \"<ARGS>\"

OPTIONS:
   --action value, -a value    : action to run (see 'Actions' below)
   --args value, -r value      : action-specific arguments (see 'Args per Action' below)
   --casePath value, -c value  : path to the extracted CASE directory
   --inventory value, -e value : inventory item name
   --namespace value, -n value : target namespace

ACTIONS:
   installCatalog    : apply the CatalogSource to the cluster
   installOperator   : create OperatorGroup and Subscription to install the operator via OLM
   uninstallCatalog  : remove the CatalogSource, OperatorGroup, and Subscription
   uninstall         : remove the operator Subscription and CSV

ARGS per Action:
   installCatalog:
     --registry value  : private registry host (air-gap only; omit for online installs)

   installOperator:
     --channelName value : OLM subscription channel (default: v1.0)
     --registry value    : registry host (required if --user/--pass specified)
     --user value        : registry username (required if --registry/--pass specified)
     --pass value        : registry password (required if --registry/--user specified)
     --secret value      : name of an existing image pull secret to use instead of creating one
"
    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ***** ACTIONS *****

run_action() {
    echo "Running action '${action}' from inventory '${inventory}'"
    case $action in
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    uninstall)
        uninstall
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    *)
        err "Unknown action: ${action}"
        print_usage 1
        ;;
    esac
}

# ***** ARGUMENT PARSING *****

# Parses the value of the --args flag
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"
    while [ "$v" != "" ]; do
        case $v in
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --channelName)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            channelName="${v}"
            ;;
        --registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry="${v}"
            ;;
        --user)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            user="${v}"
            ;;
        --pass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pass="${v}"
            ;;
        --secret)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            secret="${v}"
            ;;
        --log-level)
            idx=$((idx + 1))
            # accepted for compatibility but not used
            ;;
        --help)
            print_usage 0
            ;;
        *)
            argVal=${arr[$((idx + 1))]}
            if [[ "$argVal" = --* ]]; then
                parse_custom_dynamic_args "${arr[${idx}]}" ""
            else
                parse_custom_dynamic_args "${arr[${idx}]}" "${arr[$((idx + 1))]}"
                idx=$((idx + 1))
            fi
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

# ***** PRE-FLIGHT CHECKS *****

check_cli_args() {
    [[ -z "${casePath}" ]]          && { err_exit "The --casePath parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml found at ${casePath}."; }

    if [[ -z "${dryRun}" ]]; then
        print_client_tool_versions "1"
        check_kube_connection
        check_kube_namespace
    else
        print_client_tool_versions
    fi
}

check_kube_connection() {
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exit "Neither oc nor kubectl found in PATH."; }
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        err_exit "${kubernetesCLI} is installed but cannot reach the cluster. Verify your kubeconfig."
    fi
}

check_kube_namespace() {
    [[ -z "${namespace}" ]] && { err_exit "The --namespace parameter was not specified."; }
    if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
        err_exit "Namespace '${namespace}' not found on the cluster."
    fi
}

# ***** VALIDATION HELPERS *****

# Validates --registry/--user/--pass/--secret combination and creates a pull secret if needed
validate_install_args() {
    if [[ -n "${registry}" && -z "${user}" && -z "${pass}" && -z "${secret}" ]]; then
        # registry only — no credentials supplied, continue
        :
    elif [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]]; then
        local err=0
        [[ -z "${secret}" ]]   && { err=1; err "'--secret' is required when creating a pull secret"; }
        [[ -z "${registry}" ]] && { err=1; err "'--registry' is required when creating a pull secret"; }
        [[ -z "${user}" ]]     && { err=1; err "'--user' is required when creating a pull secret"; }
        [[ -z "${pass}" ]]     && { err=1; err "'--pass' is required when creating a pull secret"; }
        [[ $err -eq 1 ]] && { print_usage 1; }
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n "${secret}" ]]; then
        if ! $kubernetesCLI get secret "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret '${secret}' not found in namespace '${namespace}'."
            print_usage 1
        fi
    fi
}

validate_file_exists() {
    [[ ! -f "$1" ]] && { err_exit "Required file not found: $1"; }
}

# ***** UTILS *****

print_client_tool_versions() {
    if [[ "$1" -eq 1 ]]; then
        command -v oc &>/dev/null && echo "oc: $(oc version)" || echo "oc not installed"
    else
        command -v oc &>/dev/null && echo "oc: $(oc version --client)" || echo "oc not installed"
    fi
}

print_version() {
    echo "[INFO] Version ${version}"
    exit 0
}

warn()     { echo >&2 "[WARNING] $1"; }
err()      { echo >&2 "[ERROR] $1"; }
err_exit() { echo >&2 "[ERROR] $1"; exit 1; }

# ***** ABSTRACT STUBS (overridden by launch-impl.sh) *****

parse_custom_dynamic_args() { err_exit "Unknown argument: ${1}"; }
install_catalog()           { err_exit "install_catalog not implemented"; }
install_operator()          { err_exit "install_operator not implemented"; }
uninstall()                 { err_exit "uninstall not implemented"; }
uninstall_catalog()         { err_exit "uninstall_catalog not implemented"; }

# ***** MAIN *****

source "$scriptDir"/launch-impl.sh

while [ "${1-}" != "" ]; do
    case $1 in
    --casePath | -c)    shift; casePath="${1}"   ;;
    --inventory | -e)   shift; inventory="${1}"  ;;
    --action | -a)      shift; action="${1}"     ;;
    --namespace | -n)   shift; namespace="${1}"  ;;
    --args | -r | --)   shift; parse_dynamic_args "${1}" ;;
    --caseJsonFile)     shift ;;  # accepted for oc ibm-pak launch compatibility, unused
    --tolerance | -t)   shift ;;  # accepted for oc ibm-pak launch compatibility, unused
    --instance | -i)    shift ;;  # accepted for oc ibm-pak launch compatibility, unused
    --help)             print_usage 0 ;;
    --debug)            set -x ;;
    --version)          print_version ;;
    *)
        echo "Unknown option: ${1}" >&2
        exit 1
        ;;
    esac
    shift
done

check_cli_args
run_action
