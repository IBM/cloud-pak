# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh

# operator specific variables
caseName="ibm-zcon-zosconnect"
inventory="ibmZconZosconnectOperator"
caseCatalogName="ibm-zcon-zosconnect-catalog"
catalogNamespace="openshift-marketplace"
channelName="v1.0"
cr_system_status="betterThanYesterday"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --licenseAccept)
        license=$val
        ;;
    esac
}


# ----- INSTALL ACTIONS -----



# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local zosconnectcr="${casePath}"/inventory/"${inventory}"/files/zosconnect_v1_zosconnect-cr.yaml

    validate_file_exists "$zosconnectcr"

    sed -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: ${license}/g" "${zosconnectcr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----


delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local zosconnectcr="${casePath}"/inventory/"${inventory}"/files/zosconnect_v1_zosconnect-cr.yaml

    [[ ! -f ${zosconnectcr} ]] && { err_exit "Missing required ${zosconnectcr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${zosconnectcr}" ${dryRun}
}
