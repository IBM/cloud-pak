# ibmZconZosconnectOperator

Contains the z/OS Connect Operator custom resource and launch scripts to install/delete the custom resources