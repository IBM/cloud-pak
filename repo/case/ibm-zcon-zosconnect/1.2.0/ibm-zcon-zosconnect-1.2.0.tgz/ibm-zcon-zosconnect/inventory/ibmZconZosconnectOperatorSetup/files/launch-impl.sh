# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh

# operator specific variables
caseName="ibm-zcon-zosconnect"
inventory="ibmZconZosconnectOperatorSetup"
caseCatalogName="ibm-zcon-zosconnect-catalog"
catalogNamespace="openshift-marketplace"
channelName="v1.0"
cr_system_status="betterThanYesterday"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --licenseAccept)
        license=$val
        ;;
    esac
}


# ----- INSTALL ACTIONS -----

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog


    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# deletes the catalog source, subscription and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml
    local sub_file="${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml
    local opgrp_file="${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete -f "${opgrp_file}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete -f "${sub_file}" --ignore-not-found=true ${dryRun}
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local zosconnectcr="${casePath}"/inventory/"${inventory}"/files/zosconnect_v1_zosconnect-cr.yaml

    validate_file_exists "$zosconnectcr"

    sed -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: ${license}/g" "${zosconnectcr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"


    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local zosconnectcr="${casePath}"/inventory/"${inventory}"/files/zosconnect_v1_zosconnect-cr.yaml

    [[ ! -f ${zosconnectcr} ]] && { err_exit "Missing required ${zosconnectcr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${zosconnectcr}" ${dryRun}
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
