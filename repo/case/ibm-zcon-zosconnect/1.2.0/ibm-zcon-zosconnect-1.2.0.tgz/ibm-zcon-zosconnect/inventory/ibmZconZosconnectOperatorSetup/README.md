# ibmZconZosconnectOperatorSetup

This inventory item contains resources required to install the z/OS Connect Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI) application of kubernetes manifests in both an online and offline airgap environment.