# Introduction

z/OS® Connect allows you to create truly RESTful APIs as container images, which are built on top of the z/OS®® Connect Server image. These APIs can communicate to IBM&reg; Z Subsystems: Db2&reg; and CICS&reg;.
 
For more details, visit the [IBM&reg; Documentation](https://www.ibm.com/docs/zosconn/zos-connect/3.0).

## Features

* z/OS® Connect Server Container APIs can be installed and managed through the Golang z/OS® Connect Operator.
* The z/OS® Connect Operator, and z/OS® Connect Server Container APIs can be installed on Openshift&reg; Container Platform 4.8 or higher.
* z/OS® Connect Server Container APIs are stateless applications.
* The z/OS® Connect Operator supports the linux/s390x architecture.
* The z/OS® Connect Operator can be installed in the `ibm-zcon-zosconnect-system` namespace, and is cluster-scoped.

## Details

### Configuration

Before you install IBM® z/OS® Connect, prepare your OpenShift® Container Platform environment. Configuration instructions for your environment can be found in the [IBM&reg; Documentation](https://www.ibm.com/docs/en/zos-connect/zos-connect/3.0?topic=image-preparing-red-hat-openshift-container-platform).

## Installing

After you purchase the z/OS® Connect server image, you can begin to create APIs in the z/OS® Connect designer. Once you have z/OS® Connect APIs and have prepared the OpenShift Container Platform environment, you can deploy the z/OS® Connect Operator and then create the Operand instances (z/OS Connect APIs) with the z/OS® Connect API configuration. This can be done in both an online and offline (air gap) environment. More details on setting up the z/OS® Connect Operator can be found in the [IBM&reg; Documentation](https://www.ibm.com/docs/en/zos-connect/zos-connect/3.0?topic=connect-zos-operator).

# Limitations

* The z/OS® Connect Operator does not support Horizontal Pod Autoscaling. The number of replicas can be manually scaled by increasing/decreasing the value in a z/OS® Connect API's Custom Resource Definition.
* The z/OS® Connect Operator has a minimum NetworkPolicy for namespace-port protection.
* OADP backup and recovery is not supported. All OCP configuration yaml files must be backed up manually. z/OS® Connect APIs are stateless however, and do not store any data.

## Prerequisites

### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Operator  | 256mi       | 500m        |0           |1       |
|  Operand   | 256mi     | 500m           |0 |       1|
| Total | 512mi | 1 | 0   | 1 |

# PodSecurityPolicy Requirements

IBM® z/OS® Connect only supports running on OpenShift® Container Platform 4.8 or greater.

Custom PodSecurityPolicy definition:

```
IBM® z/OS® Connect runs using the default OpenShift® Container Platform restricted SCC
```

# SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

IBM® z/OS® Connect runs using the default OpenShift® Container Platform restricted SCC
