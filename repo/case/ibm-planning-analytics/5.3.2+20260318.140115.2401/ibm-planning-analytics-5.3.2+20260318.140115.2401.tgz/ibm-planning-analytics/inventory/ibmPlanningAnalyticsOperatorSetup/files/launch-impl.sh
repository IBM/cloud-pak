# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName="ibm-planning-analytics"
pa_package_name="ibm-planning-analytics-operator"
tm1_package_name="ibm-tm1s-operator"
pass_package_name="ibm-planning-analytics-spreadsheet-operator"
inventory="ibmPlanningAnalyticsOperatorSetup"
caseCatalogName="ibm-planning-analytics-operator-catalog"
operatorGroupName="ibm-planning-analytics-operator-group"
pa_channel="v7.0"
tm1_channel="v6.0"
pass_channel="v6.1"
# variables specific to catalog installation
catalogNamespace="openshift-marketplace"

# implement functions to install or uninstall products
# example

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --foo)
        echo "$val"
        ;;
    --bar)
        echo "do something"
        ;;
    esac
}

# ----- INSTALL ACTIONS -----

# products can choose to implement the install/uninstall mechanism they support in launch_impl.sh

install() {
    echo "Action not supported"
}

install_dependent_catalogs() {
    echo "Action not supported"
}

install_operator_group() {
    
    echo "------------- Installing operator group for $namespace -------------"

    local operatorGroupFile="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${operatorGroupFile}"

    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${operatorGroupFile}" | tee >($kubernetesCLI apply -n "${namespace}" -f -) | cat
}

install_catalog() {
    echo "------------- Installing catalog source -------------"
    local catalog_source_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    validate_file_exists "${catalog_source_file}"
    cat $catalog_source_file
    $kubernetesCLI apply -f "${catalog_source_file}" ${dryRun}
}

install_operator() {
    if $kubernetesCLI get deploy -n "${namespace}" | grep -w ibm-planning-analytics-operator > /dev/null 2>&1;then 
        echo "ibm-planning-analytics-operator already deployed in ${namespace}" 
    fi

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"
    install_catalog
 
    echo "checking if operator group exists ..."
    operatorgroupexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgroupexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        echo "Did not find operator group in the namespace. Installing one now.."
        install_operator_group
    fi

    # create subscription
    # fix namespace and channel before creating subscription

    echo "Check if operator subscription exists.."
    current_subscription=$($kubernetesCLI get subscriptions  -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\n"}' | grep ${pa_package_name} | wc -l)
    if [[ ${current_subscription} -ne 0 ]];then 
        echo "Replacing the channel in the existing subscription.."
        beta_channel=$($kubernetesCLI get subscriptions  -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.spec.channel}{"\n"}' | grep ${pa_package_name} | grep beta | wc -l)
        beta_prefix=""
        if [[ ${beta_channel} -ne 0 ]]; then
            echo "Subscription for BETA channel exists.."
            beta_prefix="beta-"
        else 
            echo "Subscription for BETA channel not found.."
        fi
        channel_string="${beta_prefix}${pa_channel}"
        echo "Channel will be $channel_string"
        if [[ $beta_prefix == "beta-" ]]; then
            echo "For BETA Channel, patching the channel of the dependant operators first.."
            tm1_subscription_name=$($kubernetesCLI get subscriptions -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.metadata.name}{"\n"}' | awk '$1 ~/^'"$tm1_package_name"'.*/ {NAME = $2} END {print NAME}')
            if [[ ! -z $tm1_subscription_name ]]; then
                echo "Patching channel of TM1 operator"
                oc patch subscription "${tm1_subscription_name}" -n "${namespace}" --type merge --patch '{"spec": {"channel":"'$tm1_channel'"}}' ${dryRun}
            else
                echo "TM1 operator subscription not found."
            fi
            pass_subscription_name=$($kubernetesCLI get subscriptions -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.metadata.name}{"\n"}' | awk '$1 ~/^'"$pass_package_name"'.*/ {NAME = $2} END {print NAME}')
            if [[ ! -z $pass_subscription_name ]]; then
                echo "Patching channel of PASS operator"
                oc patch subscription "${pass_subscription_name}" -n "${namespace}" --type merge --patch '{"spec": {"channel":"'$pass_channel'"}}' ${dryRun}
            else
                echo "PASS operator subscription not found."
            fi
        else 
            echo "Updating dependant opereators not required."
        fi
        pa_subscription_name=$($kubernetesCLI get subscriptions -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.metadata.name}{"\n"}' | awk '$1 ~/^'"$pa_package_name"'.*/ {NAME = $2} END {print NAME}')
        oc patch subscription "${pa_subscription_name}" -n "${namespace}" --type merge --patch '{"spec": {"channel":"'$channel_string'"}}' ${dryRun}
    else
        echo "Existing subscription not found.. creating a new one.."
        sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$pa_channel|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi
}

install_operator_native() {

    validate_install_args

    if $kubernetesCLI get deploy --all-namespaces | grep -w ibm-planning-analytics-operator > /dev/null 2>&1;then 
        echo "ibm-planning-analytics-operator already deployed" 
        exit 1
    fi 

    sed -i -- "s#cp.icr.io/cp/cpd#${OPERATOR_REGISTRY}#g" "${casePath}"/inventory/"${inventory}"/files/config/manager/manager.yaml
    sed -i -- "s#<REPLACE_NAMESPACE>#${namespace}#g" "${casePath}"/inventory/"${inventory}"/files/config/rbac/cluster_role_binding.yaml
    sed -i -- "s#<REPLACE_NAMESPACE>#${namespace}#g" "${casePath}"/inventory/"${inventory}"/files/config/manager/manager.yaml

    echo "-------------Installing via Native-------------"
    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/config/crd/bases/pa.cpd.ibm.com_paservices.yaml
    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/config/crd/bases/pa.cpd.ibm.com_paserviceinstances.yaml
    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/config/rbac/cde_service_account.yaml
    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/config/rbac/cluster_role.yaml
    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/config/rbac/cluster_role_binding.yaml

    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/config/manager/manager.yaml

    $kubernetesCLI apply -k "${casePath}"/inventory/"${inventory}"/files/config/default/ ${dryRun}

}

apply_custom_resources() {
    echo "------------- Applying Custom Resource -------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/pa_v1_paservice.yaml

    validate_file_exists "$cr"

    sed \ #-e "s|systemStatus.*|systemStatus: ${cr_system_status}|g"\ # TODO: use system status
        -e "s/accept: false/accept: true/g"\
        -e "s|storage_class.*|storage_class: ${cr_storage_class}|g" \ 
        -e "s|namespace.*|namespace: ${namespace}|g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall() {
    echo "Action not supported"
}

uninstall_dependent_catalogs() {
    echo "Action not supported"
}

uninstall_catalog() {
    echo "-------------Uninstalling catalog source-------------"
    local catalog_source_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    validate_file_exists "${catalog_source_file}"

    $kubernetesCLI delete ${dryRun} -f "${catalog_source_file}" --ignore-not-found=true 
}

uninstall_operator() {
    echo "------------- Uninstalling operator via OLM -------------"
    # Find installed CSV
    # Remove the subscription
    echo "Deleting subscription.."
    pa_subscription_name=$($kubernetesCLI get subscriptions -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.metadata.name}{"\n"}' | awk '$1 ~/^'"$pa_package_name"'.*/ {NAME = $2} END {print NAME}')
    tm1_subscription_name=$($kubernetesCLI get subscriptions -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.metadata.name}{"\n"}' | awk '$1 ~/^'"$tm1_package_name"'.*/ {NAME = $2} END {print NAME}')
    pass_subscription_name=$($kubernetesCLI get subscriptions -n ${namespace} -o=jsonpath='{range .items[*]}{.spec.name}{"\t"}{.metadata.name}{"\n"}' | awk '$1 ~/^'"$pass_package_name"'.*/ {NAME = $2} END {print NAME}')
    [[ ! -z "${pa_subscription_name}" ]] && { $kubernetesCLI delete subscription "${pa_subscription_name}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }     
    [[ ! -z "${tm1_subscription_name}" ]] && { $kubernetesCLI delete subscription "${tm1_subscription_name}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    [[ ! -z "${pass_subscription_name}" ]] && { $kubernetesCLI delete subscription "${pass_subscription_name}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    echo "Deleting csv.."
    pa_csv_found=$($kubernetesCLI get csv -n ${namespace} | grep $pa_package_name | awk '{print $1}')
    tm1_csv_found=$($kubernetesCLI get csv -n ${namespace} | grep $tm1_package_name | awk '{print $1}')
    pass_csv_found=$($kubernetesCLI get csv -n ${namespace} | grep $pass_package_name | awk '{print $1}')
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ ! -z "${pa_csv_found}" ]] && { $kubernetesCLI delete clusterserviceversion "${pa_csv_found}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    [[ ! -z "${tm1_csv_found}" ]] && { $kubernetesCLI delete clusterserviceversion "${tm1_csv_found}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    [[ ! -z "${pass_csv_found}" ]] && { $kubernetesCLI delete clusterserviceversion "${pass_csv_found}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    echo "Deleting operatorgroup.."
    # remove operator group, some other may have a dependency
    operatorgroupexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgroupexist} -ne 0 ]]; then
        echo "Operator group exist in namespace ${namespace}, deleting now.."
        $kubernetesCLI delete operatorgroup "${operatorGroupName}" -n "${namespace}" ${dryRun} 
    else
        echo "Did not find operator group in the namespace. No need to delete."
    fi

    echo "Deleting CatalogSource"
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun} 

    echo "Deleting any resources created"
    # $kubernetesCLI delete -k "${casePath}"/inventory/"${inventory}"/files/config/default/ --ignore-not-found=true
}

uninstall_operator_native() {
    # Verfiy arguments are valid
    validate_install_args

    echo "------------- Uninstalling via Native -------------"
    
    $kubernetesCLI delete ${dryRun}  -k "${casePath}"/inventory/"${inventory}"/files/config/default/
}

delete_custom_resources() {
    echo "------------- Deleting Custom Resource -------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/pa_v1_paservice.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}

# ----- END ACTIONS -----
