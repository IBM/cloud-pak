# IBM Planning Analytics Operator Setup
Contains the IBM Planning Analytics operator and launch scripts to install/delete the operator.