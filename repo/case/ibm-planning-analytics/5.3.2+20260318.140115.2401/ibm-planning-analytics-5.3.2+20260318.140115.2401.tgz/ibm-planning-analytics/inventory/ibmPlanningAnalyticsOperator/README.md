# IBM Planning Analytics Operator
Contains the IBM Planning Analytics operator custom resource and launch scripts to install/delete the custom resources.