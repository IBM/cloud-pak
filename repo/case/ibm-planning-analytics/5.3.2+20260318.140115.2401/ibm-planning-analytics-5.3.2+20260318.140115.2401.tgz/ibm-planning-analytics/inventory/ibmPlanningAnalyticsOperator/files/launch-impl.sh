# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this panamax operator

# Change per operator
resourceName="streamsservice"
# streams-service-operator specific variables
caseName="ibm-planning-analytics"
inventory="ibmPlanningAnalyticsOperator"
caseCatalogName="ibm-planning-analytics-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="v4.6"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
case_depedencies=""
storage_class=""
cr_overrides=""
use_repo=""
force=0
license_accept=0

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --cr-overrides)
        cr_overrides=$val
        ;;
    --storage-class)
        storage_class=$val
        ;;
    --repo-override)
        use_repo="$val"
        ;;
    --force)
        force=1
        ;;
    --license-accept)
        license_accept=1
        ;;
    esac
}

function cleanup {
    if [[ ! -z ${TMP} ]]; then
#        rm -rf ${TMP}
        echo "Deleted temp working directory ${TMP}"
    fi
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"

    # Ensure the license is accepted
    if [[ "${license_accept}" -eq 1 ]]; then
        sed -i "s|  accept: false|  accept: true|g" ${casePath}/inventory/"${inventory}"/files/config/samples/pa_v1_paservice.yaml
    else
        echo "[ERROR] Please accept the license by specifying --args \"--license-accept\"."
        exit 1
    fi

    echo "Installing Planning Analytics service into namespace: $namespace"

    cat ${casePath}/inventory/"${inventory}"/files/config/samples/pa_v1_paservice.yaml

    # Update namespace
    sed -i "s|^namespace: .*|namespace: ${namespace}|g" "${casePath}"/inventory/"${inventory}"/files/config/samples/kustomization.yaml

# DEBUG
    ls  "${casePath}"/inventory/"${inventory}"/files/config/samples/

    $kubernetesCLI kustomize "${casePath}"/inventory/"${inventory}"/files/config/samples/
    $kubernetesCLI apply ${dryRun}  -k "${casePath}"/inventory/"${inventory}"/files/config/samples/
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    current_pods=$($kubernetesCLI get pods)
    echo "$current_pods"
    current_service=$($kubernetesCLI get paservice --no-headers  -n "${namespace}" | wc -l)
    echo "$current_service"
    set +e
    if [[ $current_service -gt 0 ]]; then
        echo "PAService instance found. Deleting.."
        sed -i "s|^namespace: .*|namespace: ${namespace}|g" "${casePath}"/inventory/"${inventory}"/files/config/samples/kustomization.yaml
        $kubernetesCLI delete ${dryRun} -k "${casePath}"/inventory/"${inventory}"/files/config/samples/ -n "${namespace}" --timeout=60s
    else 
        echo "No PAService instance found."
    fi
}