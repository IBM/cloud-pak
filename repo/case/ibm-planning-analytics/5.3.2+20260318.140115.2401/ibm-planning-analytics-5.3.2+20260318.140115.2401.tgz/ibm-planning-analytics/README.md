# ibm-planning-analytics

## Introduction
This CASE provides an operator to install the IBM Planning Analytics Cartridge for Cloud Pak for Data.

## Details
<!-- Describes what the workload is deploying -->
This CASE contains two inventory items:
- ibmPlanningAnalyticsOperator - actions to provision an instance of IBM Planning Analytics
- ibmPlanningAnalyticsOperatorSetup - actions for installing the IBM Planning Analytics Cartridge for Cloud Pak for Data operator

## Prerequisites
<!-- Describes Environmental pre-requisites -->
For information on resources required see the [Before you begin](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=analytics-installing-planning-add) section on [Installing the Planning Analytics add-on](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=analytics-installing-planning-add).


## PodSecurityPolicy Requirements	

Custom PodSecurityPolicy definition:	
```	
No Custom PSP is Defined	for Planning Analytics for the current release
```

## Red Hat OpenShift SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
Planning Analytics has no custom security context constraints. It only uses restricted SCC which is default in cluster. The following security context is the OCP 4.6 restricted SCC.

## Prereq scripts - How to locate (optional)
<!-- Describe where to find any pre-req scripts/yaml files -->
To install IBM Cloud Pak for Data Planning Analytics, you need to complete the pre-requisite steps outlined [here](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=installing-pre-installation-tasks).

## Resources Required
<!-- Describes Minimum System Resources Required -->

| Level | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Minimum* | 40 | 20 | 20 | 3 |
| Recommended | 40 | 20 | 20 | 3 |

\* Minimum 3 nodes with 4 cores and 8GB memory, and 10GB storage, for Planning Analytics Workspace. 

## Installing
<!-- Helm CLI way to install the CASE -->
The Planning Analytics add-on is installed using `cloudctl`. Planning Analytics Workspace is provisioned using the addon in the Cloud Pak for Data user interface.

The complete documentation for installation can be found [here](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=analytics-installing-planning).

## Configuration
<!-- Define the Parms/Configuration Option -->
After installing the IBM Planning Analytics service, you can provision an instance of the service using the Cloud Pak for Data user interface. For more information on how to provision an instance see [here](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=analytics-provisioning-planning-service).

## Storage
<!-- Define how workload storage setup and use cases -->

Planning Analytics employs a single persistent volume claim that is used for storage. It is a requirement that the underlying storage associated to the claim is available on multiple nodes within the cluster.

The supported volume access mode is RWX - ReadWriteMany.

The underlying storage associated to the claim must support a minimum capacity of 10GB.

### File system permissions

The storage pods support Openshift supplied arbitrary userids, thus no special permissions are required for file system access.

The storage pods employ the following security context with respect to file system permissions:

```
runAsNonRoot: true
capabilities:
  drop:
    - ALL
privileged: false
readOnlyRootFilesystem: false
allowPrivilegeEscalation: false
```

### Persistent volumes

In order to employ a pre-created persistent volume, you must specify a storage class name that would result in the selection of the persistent volume.

### Dynamic provisioning

Dynamic provisioning is supported. During configuration you must specify a storage class that is to be used to set up a dynamically provisioned volume.


## Limitations
<!-- Define key limitations of the CASE. -->
* Multi-tenancy: IBM Planning Analytics can be deployed in different namespaces in the same cluster, but cannot be deployed multiple times in the same namespace.
* Horizontal scaling can be enabled by editing the PAServiceInstance custom resource and setting `auto_scale_config: true`.

## Documentation
<!-- *Link to Knowledge Center and other product related material. Only required if additional documentation required* -->
For more information see [IBM Planning Analytics Cartridge for Cloud Pak for Data](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/svc-welcome/pa.html).
### Key management

Planning Analytics integrates with the Cloud Pak for Data certificate manager for TLS certificates.

All others keys employed by Planning Analytics are stored as kubernetes secrets, and are generated during the provisioning of an instance of the application.

Key management can be achieved by manually editing the following secrets:

* pa-cookie-key
* pa-credential-store-key

The value of *pa-cookie-key* is a randomly generated 64 byte hexadecimal text string. To generate a new value, please perform the following steps in bash:

1. Run *key=$( openssl rand -hex 32 2>&1 )*
2. Run *echo -n "${key}" | base64 -w 0*
3. Run *kubectl edit secret pa-cookie-key*
4. Replace the value of *tls.key* with the value from step 2
5. Delete the *wa-proxy* pods so that the new value is consumed.

The value of *pa-credential-store-key* is a randomly generated 256 byte hexadecimal text string. To generate a new value, please perform the following steps in bash:

1. Run *key=$( openssl rand -hex 128 2>&1 )*
2. Run *echo -n "${key}" | base64 -w 0*
3. Run *kubectl edit secret pa-credential-store-key*
4. Replace the value of *tls.key* with the value from step 2
5. Delete the *monitor, prism-platform, tm1proxy,* and *wa-proxy* pods so that the new value is consumed.

### Scaling
A Planning Analytics instance cluster can be scaled by editing the PAServiceInstance custom resource and setting the `scaleConfig` field. The Cloud Pak for Data Planning Analytics assembly ships with three configuration files for different size deployments: `small`, `medium`, and `large`. For example:

```bash
$ oc edit paserviceinstance <instance-name>
apiVersion: pa.cpd.ibm.com/v1
kind: PAServiceInstance
metadata:
  ...
  name: <instance-name>
  ...
spec:
  ...
  scaleConfig: small
```

### Upgrade
Cloud Pak for Data Planning Analytics is upgraded in the same was as other Cloud Pak for Data services - as documented [here](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=upgrading).

Before doing an upgrade we recommend that you do a backup, following the process described in the next section. If an issue arises during the upgrade, you will the be able to follow the recovery steps also described below.

<!--
Upgrade process (4.1.1)
Testing an upgrade (4.1.2)
Rollback methods (4.1.3)
-->

### Backup / recovery process

It is expected that all Kubernetes objects (i.e. secrets, deployments, etc.) are backed up as part of backup / recovery support for the CloudPak control plane.

The backup and restore procedure is the standard Cloud Pak for Data process documented [here](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/cpd/admin/backup_restore.html). 

For example, to backup the entire namespace using `cpdbr-oadp` and restic:
```bash
$ cpdbr-oadp backup create --include-namespaces=zen --exclude-resources='Event,Event.events.k8s.io' --default-volumes-to-restic --cleanup-completed-resources zen-backup --log-level=debug --verbose
```

To restore from a backup, you can run:

```bash
$ cpdbr-oadp restore create --from-backup=my-backup --exclude-resources='ImageTag' zen-restore --log-level=debug --verbose
```
