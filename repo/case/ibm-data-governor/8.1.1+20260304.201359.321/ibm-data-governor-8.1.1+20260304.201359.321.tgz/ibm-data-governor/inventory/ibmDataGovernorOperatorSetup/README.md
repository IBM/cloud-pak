# ibm-data-governor

IBM&reg; Data Governor

# Introduction

## Summary

* Data Governor manages both payload data as well as training data end to end to help ensure GDPR, HIPAA, SOC2, and Service
  Framework. Data Governor provides storage or manages applications’ storage. It enables applications to write data once and
  use in many ways and handles data maintenance such as backup, alerting, migrating and Right To Be Forgotten (RTBF)
  deletions.

## Features

* Capture and make use of data. Watson service runtimes or authorized users can access the data via:
    * HTTP APIs(Data Governor Proxy)
    * UI(Data Governor Kibana)
    * Export data to their own data analysis pipeline(Data Governor Archive)
    * Process data real-time in streaming fashion(Event Streams)
* Perform administration tasks
    * Data Governor accepts GDPR right-to-be-forgotten requests and performs deletion on its own storage
    * Data Governor can populate right-to-be-forgotten requests to downstream consumers
    * Data Governor uses IAM to manage accesses
    * Data Governor writes audit logs on accesses to its storages
* Data is kept in Data Governor
    * Data Governor keeps binary data(audios, non-searchable texts) received in Data Governor's Cloud Object Storage account
    * Data Governor buffers text data received in Event Streams and persists them in Data Governor's OpenSearch cluster and
      Data Governor's Cloud Object Storage account
* Data Governor helps teams to meet GDPR requirements
    * Data Governor provides GDPR compliant storage and APIs to meet GDPR's labeling and deletion requirements

# Details

## Prerequisites

### Resources Required

Overall resources required depends on the amount of data that is expected to travel through Data Governor. We recommend
reading the documentation for Elastic and Kafka to get an understanding of the data minimums for the datastores used by
Data Governor.

Data Governor itself can be sized using the `resourceSize` variable in the DataExhaust CR. This will automatically scale your
application based on pre-defined t-shirt sizes. The out-of-the-box settings are listed in the table below.

Minimum scheduling capacity:

| Software       | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
|----------------|-------------|-------------|-----------|-------|
| Elastic Search | 2GB         | 1000M       |           | 3     |
| Kafka          |             |             |           |       |
| Data Governor  |             |             |           |       |
| **Total**      |             |             |           |       |

# Installing

The primary CR that must be deployed is a DataExhaust CR which will create the dependencies (Kafka, OpenSearch) and
will install all the Data Governor microservices. A DataGovernorTenant CR will also need to be created for each consuming
service of the application.

### Case Install

To install the component using case you must either use the native install or catalog install. Upon installing the catalog you
can then use either OLM or ODLM to install but must create the OperatorGroup & Subscription for either method to avoid
conflict.

```bash
# For CLI pre-install (installs the Data Governor operator)
"$CASE_PATH/stable/ibm-data-governor-case-bundle/tests/test-op-cli/pre-install/pre-install.sh"

# For OLM pre-install (installs the Data Governor operator)
"$CASE_PATH/stable/ibm-data-governor-case-bundle/tests/test-op-olm/pre-install/pre-install.sh"
```

### Requirements

CatalogSources for:

- IBMCS Operators
- IBM Opencontent OpenSearch Catalog
- Openshift 4.6+

### CatalogSource

```yaml
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: ibm-data-governor-operator-catalog
  namespace: cpd-operator
spec:
  displayName: IBM Data Governor operator Catalog
  publisher: IBM
  sourceType: grpc
  image: icr.io/cp/ibm-data-governor-operator-catalog:latest
  updateStrategy:
    registryPoll:
      interval: 45m
```

## Configuration

This table is still a work in progress and may be missing fields. For a full list of fields until this table is listed you can
look in the CRDs that are provided with this operator.

## kind: DataGovernorTenant

| Name                     | Description                                                                                                           |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------|
| `cloud`                  | In which cloud the application is running. Should be `private` for CP4D.                                              |
| `cloudEnv`               | This should be the name of the `DataExhaust` CR that this tenant belongs to                                           |
| `purgeDays`              | The number of days of data to keep in OpenSearch for this tenant.                                                     |
| `tenantName`             | The name of the tenant service.                                                                                       |
| `topics.data.partitions` | The number of partitions for the data topic (for data topics like `ga.analytics.message_log.wa-ga.v0_wa.dataexhaust`) |
| `topics.data.replicas`   | The number of partitions for the data topic (for data topics like `ga.analytics.message_log.wa-ga.v0_wa.dataexhaust`) |

#### Example DataGovernorTenant

```yaml
apiVersion: datagovernor.ibm.com/v1
kind: DataGovernorTenant
metadata:
  name: ibm-data-governor-example-ibm-data-governor-data-ex-2980
  labels:
    app: ibm-data-governor-example
spec:
  topics:
    data:
      backupToCos: false
  cloud: private
  cloudEnv: ibm-data-governor-example
  purgeDays: 7
  tenantName: data-exhaust-internal
  version: master
  topics:
    data:
      partitions: 8
      replicas: 1

  # Important to leave for defaults to be set
  es: {}
```

## kind: DataExhaustConfigJob

| Name | Description |
| --- | --- |
| `cloudEnv` | This should be the name of the `DataExhaust` CR that this tenant belongs to |
| `command` | The command to run on the container. For Watson Assistant, use `- /app/elastic/startup.sh` |
| `esManager.aliasPrefix` | `assistant-analytics-logs` |
| `esManager.aliasSuffix` | `pmp001-v3` |
| `esManager.indexPrefix` | `assistant-analytics-logs-pmp001-v3` |
| `jobName`| `es-manager` |
| `registry` ||

#### Example DataExhaustConfigJob

```yaml
apiVersion: default.cognitivedata/v1
kind: DataExhaustConfigJob
metadata:
  name: ibm-data-governor-example
spec:
  cloudEnv: ibm-data-governor-example
  command:
  - /app/elastic/startup.sh
  esManager:
    aliasPrefix: assistant-analytics-logs
    aliasSuffix: pmp001-v3
    indexPrefix: assistant-analytics-logs-pmp001-v3
  imagePullSecret: icr.io
  jobName: es-manager
  registry: icr.io/cp/
  version: master
```

## kind: DataExhaustOverrides

If you would like to override an image, resources, role versions, or dependency settings:

- in the DataExhaust CR you can set the `overrideCustomResource` field to the name of your pre-installed override CR.
- if no `overrideCustomResource` is provided, then one will be automatically created.

Most users only need to deal with DataExhaust CR and they do not see any advanced configs that are hidden under the surface.
Users can create an empty/partial override CR. The override CR will automatically get filled with documentations and users can
use kubectl or other tools to edit it.

Example:

```yaml
apiVersion: default.cognitivedata/v1
kind: DataExhaustOverride
metadata:
  name: "default-csfdev-public"
  namespace: "cognitive-data"
spec:
  dependencies:
    kafka:
      size:
        override: 4
        default: 3
```

In the above example, we are override the default size of the Kafka deployment. The `default` field is immutable, and is just
to be used as a reference to what the default value is. If provided, the `override` value will take highest precedence when
the image gets deployed. When you create a new override CR, if you do not populate it with all of the default values, the CR
will be automatically updated with all the `default` fields that are available for override.

## Storage

Data Governor utilizes OpenSearch and Event Streams for storage

## SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```yaml
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Upgrade

Just apply an update CR/pull in the latest Operator.

## Rollback

Rollback can be accomplished by using kubectl rollback of the operator CR

```bash
kubectl rollout undo dataexhaust <cr name>
```

## Architectures Supported

1. amd64

## Operator Scope

This operator by default is namespace scoped. This can be used with ibm namespace scoped operator to support installing in
different namespaces.

Supported Install modes:

1. Single Namespace
1. Same Namespace
1. Declared Namespace
1. All Namespaces

## Limitations

## Documentation

