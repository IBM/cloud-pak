# ibm-data-governor

IBM&reg; Data Governor

# Introduction

## Summary

Data Governor manages both payload data as well as training data end to end to help ensure GDPR, HIPAA, SOC2, and Service Framework. Data Governor provides storage or manages applications’ storage. It enables applications to write data once and use in many ways and handles data maintenance such as backup, alerting, migrating and Right To Be Forgotten (RTBF) deletions.

## Features

* Capture and make use of data. Watson service runtimes or authorized users can access the data via:
    * HTTP APIs(Data Governor Proxy)
    * UI(Data Governor Kibana)
    * Export data to their own data analysis pipeline(Data Governor Archive)
    * Process data real-time in streaming fashion(Event Streams)
* Perform administration tasks
    * Data Governor accepts GDPR right-to-be-forgotten requests and performs deletion on its own storage
    * Data Governor can populate right-to-be-forgotten requests to downstream consumers
    * Data Governor uses IAM to manage accesses
    * Data Governor writes audit logs on accesses to its storages
* Data is kept in Data Governor
    * Data Governor keeps binary data(audios, non-searchable texts) received in Data Governor's Cloud Object Storage account
    * Data Governor buffers text data received in Event Streams and persists them in Data Governor's OpenSearch cluster and
      Data Governor's Cloud Object Storage account
* Data Governor helps teams to meet GDPR requirements
    * Data Governor provides GDPR compliant storage and APIs to meet GDPR's labeling and deletion requirements

# Details

## Prerequisites

### Resources Required

Overall resources required depends on the amount of data that is expected to travel through Data Governor. We recommend
reading the documentation for Elastic and Kafka to get an understanding of the data minimums for the datastores used by
Data Governor.

Data Governor itself can be sized using the `resourceSize` variable in the DataGovernor CR. This will automatically scale your
application based on pre-defined t-shirt sizes. The out-of-the-box settings are listed in the table below.

_Minimum_ scheduling capacity (each production environment may have greatly differing requirements):

| Software       | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
|----------------|-------------|-------------|-----------|-------|
| Elastic Search | 2GB         | 1000m       | 10Gi      | 3     |
| Kafka          | 1Gi         | 1000m       | 10Gi      | 3     |
| Data Governor  |             |             |           |       |
| **Total**      |             |             |           |       |

# Installing

Data Governor is an internal component. Customers should never use Data Governor on its own, there is no use case for it.
Customer support should be driven through the product team's support scenarios.

The primary CR that must be deployed is a DataGovernor CR which will create the dependencies (Kafka, OpenSearch) and
will install all the Data Governor microservices. A DataGovernorTenant CR will also need to be created for each consuming
service of the application.

### Case Install

To install the component using case you must either use the native install or catalog install. Upon installing the catalog you
can then use OLM to install.

```bash
# For OLM pre-install (installs the Data Governor operator)
"$CASE_PATH/stable/ibm-data-governor-case-bundle/tests/test-op-olm/pre-install/pre-install.sh"
```

### Requirements

- IBMCS Operators
- IBM Opencontent OpenSearch Catalog
- Storage
- Openshift 4.8+

## Configuration

For a full list of fields until this table is listed you can look in the CRDs that are provided with this operator.

### kind: DataGovernor

This section covers the required and optional configurations for all features of Data Governor offered in CP4D.

#### Example DataGovernor CR

The following example can be used as a base for configuring Data Governor. The example without any modifications will deploy Data Governor dependencies (Kafka, OpenSearch) and all microservices.

```yaml
apiVersion: datagovernor.ibm.com/v1
kind: DataGovernor
metadata:
  name: wa-data-governor
  namespace: cpd
spec:
  additionalAnnotations: {} # Optional, will be applied to all resources owned the CR
  additionalLabels: {} # Optional, will be applied to all resources owned the CR
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - key: kubernetes.io/arch
            operator: In
            values:
            - amd64
  antiAffinity:
    topologyKey: kubernetes.io/hostname
    type: soft
  auth:
    basic:
      adminSecret: # Secret for authentication to the admin container. Will be generated if not provided. This should be provided in production environments. Secret should have a USERNAME and PASSWORD field.
      clientSecret: # Secret for authentication to the proxy container. Will be generated if not provided. This should be provided in production environments. Secret should have a USERNAME and PASSWORD field.
  autoScaleConfig: true
  cloud: private
  odlmRegistryNamespace: ibm-common-services
  consumerSets:
  - name: all
    primary: true
    processBadData: false
    retryable: true
    search:
      templates: enterprise
      metrics:
        buffer: "2300"
        directory: /workdir/apps/
        enabled: false
        perfEnabled: false
        resources:
          limits:
            cpu: 100m
            ephemeral-storage: 50Mi
            memory: 64Mi
          requests:
            cpu: 50m
            ephemeral-storage: 10Mi
            memory: 10Mi
        size: 22m
        wait: 30
      resourcePlan: opensearch-operator-private
      secret: # Leave secret section blank to generate, secret should be provided in production. The secret name below is an example.
        name: wa-data-governor-ibm-elasticsearch-cred-cr-secret
        passwordKey: elastic
        username: elastic
      tls: # Leave tls section blank to generate, cert should be provided in production. The secret name below is an example.
        certKey: ca.crt
        name: wa-data-governor-ibm-elasticsearch-tls-cr-secret
    tenants:
      include:
      - '*'
  disableLanguageSupport: false
  imagePullSecret: ibm-entitlement-key
  kafka:
    config:
      log.retention.bytes: "187904850"
      log.retention.check.interval.ms: "30000"
      log.segment.bytes: "18790485"
      log.retention.ms: "604800000"
      log.roll.jitter.ms: "0"
      log.roll.ms: "604800000"
    namespace: # Optional, used for SOD
  quiesce: false
  registry: cp.icr.io/cp/
  resourceSize: small
  serviceAccountName: restricted
  shutdown: "false"
  storageClassName: ocs-storagecluster-ceph-rbd
  tls:
    issuer: wa-issuer-ca
    clientCAs:
    - key: ca_analytics.crt
      name: wa-data-governor-tls
      namespace: cpd
    mutualTLSRequired: false
    useCertificateManager: true
  topologySpreadConstraints:
    topologyKey: kubernetes.io/zone
    whenUnsatisfiable: ScheduleAnyway
  version: master
```

#### Credentials & Certificates

There are three settings needed for Data Governor basic auth credentials in CP4D.

1. The existence of a `spec.auth` field will toggle basic auth on and off
2. `spec.auth.basic.clientSecret` is the name of a secret containing a `USERNAME` and `PASSWORD` key. 
These credentials are used for authenticating with data-exhaust-proxy.
3. `spec.auth.basic.adminSecret` is the name of a secret containing a `USERNAME` and `PASSWORD` key. 
These credentials are used for authenticating with data-exhaust-admin.

If a secret is not provided to either field while basic auth is enabled, then default credentials will 
be created. **You must provide your own credentials in a production environment.** 
To change or supply your own credentials, you must pass your own secret in the proper format to their 
respective variables outlined above. To change credentials, rotate out the secret used.

To set Data Governor certificates, use `tls.serverSecret` and `tls.clientSecret` (both secrets required for mTLS).

Set your OpenSearch credentials for each consumerSet's `search.secret.name`, set certificates with `search.tls.name`. View the CP Open OpenSearch documentation for more information.

To change the Kafka certificates, please view [Strimzi documentation](https://strimzi.io/docs/operators/latest/full/configuring.html#installing-your-own-ca-certificates-str).

The recommended method for cycling secrets is to:
1. quiesce the service
2. replace the secret (preferably with a _different_ secret name)
3. un-quiesce the service

## kind: DataGovernorTenant

| Name                        | Description                                                                                                           |
|-----------------------------|-----------------------------------------------------------------------------------------------------------------------|
| `cloud`                     | In which cloud the application is running. Should be `private` for CP4D.                                              |
| `cloudEnv`                  | This should be the name of the `DataGovernor` CR that this tenant belongs to                                          |
| `purgeDays`                 | The number of days of data to keep in OpenSearch for this tenant.                                                     |
| `tenantName`                | The name of the tenant service.                                                                                       |
| `topics.data.partitions`    | The number of partitions for the data topic (for data topics like `ga.analytics.message_log.wa-ga.v0_wa.dataexhaust`) |
| `topics.data.replicas`      | The number of partitions for the data topic (for data topics like `ga.analytics.message_log.wa-ga.v0_wa.dataexhaust`) |
| `esManager.aliasSuffix`     | The suffix of the index alias (for example, `ga-v3`)                                                                  |
| `esManager.aliasPrefix`     | The prefix of the index alias (for example, `assistant-analytics-logs`)                                               |
| `esManager.languageSupport` | Whether there are multi language indices for the tenant. Set to  `true` for analytics, `false` for actions            |
| `additionalLabels`          | A list of additional labels to apply (or override) to all resources created by the operator                           |
| `additionalAnnotations`     | A list of additional annotations to apply (or override) to all resources created by the operator                      |

#### Example DataGovernorTenant

```yaml
apiVersion: datagovernor.ibm.com/v1
kind: DataGovernorTenant
metadata:
  name: example-ibm-data-governor-tenant
  labels:
    app: example
spec:
  topics:
    data:
      backupToCos: false
  cloud: private
  cloudEnv: example
  purgeDays: 90
  tenantName: assistant-analytics-logs-ga-v3
  esManager:
    aliasSuffix: ga-v3
    languageSupport: true
    aliasPrefix: assistant-analytics-logs
```

## kind: DataGovernorOverrides

If you would like to override an image, resources, role versions, or dependency settings:

- in the DataGovernor CR you can set the `overrideCustomResource` field to the name of your pre-installed override CR.
- if no `overrideCustomResource` is provided, then one will be automatically created.

Example:
```yaml
apiVersion: datagovernor.ibm.com/v1
kind: DataGovernorOverride
metadata:
  name: wa-data-governor-override
  namespace: cpd
spec:
  dependencies:
    kafka:
      size: 3
  resources:
    data-exhaust-admin:
      minReplicas: 3
```

In the above example, we are override the default size of the Kafka deployment. If provided, the new value will take the highest precedence when
the containers are deployed.

## Storage

Data Governor utilizes OpenSearch and Event Streams storage

## SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```yaml
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
  name: dg-restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Upgrade

Just apply an update CR/pull in the latest Operator.

## Rollback

Rollback can be accomplished by using kubectl rollback of the operator

## Architectures Supported

1. amd64

## Operator Scope

This operator by default is namespace scoped. This can be used with ibm namespace scoped operator to support installing in
different namespaces.

Supported Install modes:

1. Single Namespace
2. Same Namespace
3. Declared Namespace
4. All Namespaces

## Platform Delivery Models Supported

- onPrem
- IBM ROKS

## Limitations

## Documentation

Additional documentation can be found on the Data Governor wiki

### Restart Admin Jobs

You may find that an admin job (rtbf, es manager, purge job) has failed for the day and did not recover on retry. 
To restart an admin job you must hit the admin container API with curl and reset the job status to force it to rerun. To do so:

1. Get the admin credentials from the admin basic auth secret (username and password). The secret is either provided in the **DataGovernor** CR under `spec.auth.basic.adminSecret` or defaults to `<DataGovernor CR Name>-admin-cred-secret`
1. Port forward to an admin pod port 8443 or exec into an admin container.
1. To see a list of jobs curl `GET /v2/jobs/envs/{env}`

    ```shell
    curl -sk --location --request \
    GET "https://localhost:8443/v1/jobs/envs/<DG CR NAME>" \
    -u "<username:password>"
    ```

1. Use curl `PUT /v1/jobs/envs/{env}/reset/services/{service name}/job/{job name}`
    ```shell
    curl -sk --location --request \
    PUT "https://localhost:8443/v1/jobs/envs/<DG CR NAME>/reset/services/<TENANT NAME>/job/<JOB NAME>" \
    -u "<username:password>"
    ```
    
    Example:
    ```shell
    curl -sk --location --request \
    PUT "https://localhost:8443/v1/jobs/envs/wa-data-governor/reset/services/assistant-analytics-logs-wa-v3/job/assistant-analytics-logs-wa-v3_es_manager" \
    -u "root:password"
    ```
   
See the data-exhaust-admin documentation for more detail.

#### Creating ES Manager Job

```
curl -k -X PUT 'https://localhost:8443/v1/jobs/envs/wa-data-governor/services/assistant-analytics-logs-wa-v3' \
--header 'Content-Type: application/json' \
-u "root:$PASSWORD" \
--data '{"body":{"languagesupport":true,"prefix":"assistant-analytics-logs","servicename":"assistant-analytics-logs-wa-v3","suffix":"wa-v3"},"env":"wa-data-governor","name":"assistant-analytics-logs-wa-v3_es_manager","not_unique":true,"runnow":true,"runwindow":{"endtime":"23:59","repeat":"midnightly","retry":true,"starttime":"0:00"},"servicename":"assistant-analytics-logs-wa-v3","type":"alias"}'
```
