#!/bin/bash
set -e
scriptDir="${1}"
#adding this condition to allow running this script standalone on jenkins 
if [[ -f "${scriptDir}/values.linux.conf" ]]; then
    source "${scriptDir}/values.linux.conf"
fi
##check if airgapInstall is enabled
if [[ "${airgapInstall}" == "true" ]]; then
    echo "[INFO] Air-gapped installation is enabled for a non-OCP cluster. Running prerequisites"
fi 
# SSH Configuration for docker-registry VM
DOCKER_REGISTRY_HOSTNAME="${registry}"
DOCKER_REGISTRY="${DOCKER_REGISTRY_HOSTNAME%%:*}" #remove port :8443
DOCKER_REGISTRY_USERNAME="${registryUsername:-admin}"
DOCKER_REGISTRY_PASSWORD="${registryPassword:-password}"

FYRE_PASSWORD="${SshPassword}"  # Set via environment variable or prompt
k3s_version="v1.32.12+k3s1"
FYRE_USER="root"


# Check if password is provided
if [ -z "$FYRE_PASSWORD" ]; then
    echo "Error: FYRE_PASSWORD environment variable is not set"
    echo "Usage: FYRE_PASSWORD='your_password' $0"
    exit 1
fi

# Check if sshpass is installed
if ! command -v sshpass &> /dev/null; then
    echo "Error: sshpass is not installed. Please install it first."
    echo "  On RHEL/CentOS: yum install sshpass"
    echo "  On Ubuntu/Debian: apt-get install sshpass"
    exit 1
fi

echo "[INFO] Connecting to docker-registry VM: ${DOCKER_REGISTRY}"
echo "========================================"

# Execute all commands on remote docker-registry VM via SSH
sshpass -p "${FYRE_PASSWORD}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ${FYRE_USER}@${DOCKER_REGISTRY} bash -s << REMOTE_SCRIPT
set -e

#retag and push rancher images to private registry
arch="amd64"
k3s_version="${k3s_version}"

if ! podman login "https://${DOCKER_REGISTRY_HOSTNAME}" \
    -u "${DOCKER_REGISTRY_USERNAME}" \
    -p "${DOCKER_REGISTRY_PASSWORD}" --tls-verify=false >/dev/null 2>&1; then
    echo "[ERROR] Login to private Registry failed"
else
    echo "[SUCCESS] Login to private registry https://${DOCKER_REGISTRY_HOSTNAME} successful!"
fi

#check connectivity to private registry 
if ! curl -q -k https://${DOCKER_REGISTRY_HOSTNAME}/v2/ >/dev/null 2>&1; then 
    echo "[ERROR] Failed to connect to registry at \${DOCKER_REGISTRY_HOSTNAME}/v2"
    exit 1
fi


#download the k3s airgap images tar file
if ! curl -q -LO https://github.com/k3s-io/k3s/releases/download/\${k3s_version}/k3s-airgap-images-\${arch}.tar.zst >/dev/null 2>&1; then
    echo " [ERROR] Failed to download the k3s airgap images tar file"
    exit 1
fi

#decompress and load images to podman
echo "[INFO] Decompress and mirror k3s images into the private registry before the K3s setup begins..."

if ! zstd -d -c k3s-airgap-images-\${arch}.tar.zst | podman image load >/dev/null 2>&1; then
    echo "[ERROR] Failed to decompress"
    exit 1
fi

#Mirror k3s images to private registry
podman image ls --format '{{.Repository}}:{{.Tag}}' | grep rancher |
while read -r IMAGE; do

    # Only process localhost/rancher images
    [[ "\$IMAGE" == localhost/rancher/*:* ]] || continue

    # Remove localhost/
    NAME="\${IMAGE#localhost/}"

    TARGET="${DOCKER_REGISTRY_HOSTNAME}/\${NAME}"

    # Determine source prefix based on image location
    if [[ "\$IMAGE" == localhost/* ]]; then
        SOURCE="containers-storage:\${IMAGE}"
    else
        SOURCE="docker://\${IMAGE}"
    fi

    if ! skopeo copy --quiet --insecure-policy --src-tls-verify=false --dest-tls-verify=false "\${SOURCE}" docker://\${TARGET} >/dev/null 2>&1; then
        echo "[ERROR] Failed to perform skopeo copy for \${IMAGE}"
        exit 1
    fi

    #validate 
    if ! podman manifest inspect --tls-verify=false "\${TARGET}" >/dev/null 2>&1; then
        echo "[ERROR] MISSING mirror for k3s image: \${IMAGE}"
        exit 1
    fi

done

REMOTE_SCRIPT
echo "[INFO] ========================================"