#load k3s images into private-docker registry
scriptDir="$1"
source "${scriptDir}/values.linux.conf"
airgap_path="${scriptDir}/support/k3s/air-gap"

if ! bash ${airgap_path}/load_k3s_images.sh ${scriptDir}; then
    echo "[ERROR] Failed to load k3s images into the private docker registry"
    exit 1
fi

#generate registries.yaml with actual values
#validate registries.yaml file exists
if [ -f ${airgap_path}/registries.yaml.template ]; then
    echo "[SUCCESS] ${airgap_path}/registries.yaml.template found"
else
    echo "[ERROR] ${airgap_path}/registries.yaml.template not found"
    exit 1
fi

echo "[INFO] Filling registries.yaml template with actual values..."
if sed -e "s|REGISTRY_HOST_NAME_PLACEHOLDER|${registry}|g" \
    -e "s|REGISTRY_USERNAME_PLACEHOLDER|${registryUsername}|g" \
    -e "s|REGISTRY_PASSWORD_PLACEHOLDER|${registryPassword}|g" \
    ${airgap_path}/registries.yaml.template > /tmp/registries.yaml; then
    
    echo "[SUCCESS] ${airgap_path}/registries.yaml populated with actual values"
    cat /tmp/registries.yaml
else
    echo "[ERROR] Failed to populate ${airgap_path}/registries.yaml file"
    exit 1
fi

echo ""
