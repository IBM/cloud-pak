#!/bin/bash -x
DEST_CREDS="${1}"
IMAGE_FILE="${2}"
#count for summary
TOTAL=0
FAILS=0
#for retries
MAX_RETRIES=5
RETRY_DELAY=5

#check ifskopeo is present in the system
if ! command -v skopeo >/dev/null 2>&1; then
    echo "[INFO] skopeo not found. Installing..."
    exit 1
fi

#parse the image_file
while IFS='=' read -r SRC DEST; do
    # Skip blank lines and comments
    [[ -z "$SRC" || "$SRC" =~ ^[[:space:]]*# ]] && continue
    ((TOTAL++))
   
    SUCCESSFUL=false
    for ((RETRY=1; RETRY<=MAX_RETRIES; RETRY++)); do
        echo "[INFO] Attempt ${RETRY}/${MAX_RETRIES}: Source: $SRC | Destination: $DEST"

        if skopeo copy \
            "docker://${SRC}" \
            "docker://${DEST}" \
            --override-os linux \
            --override-arch amd64 \
            --dest-creds "${DEST_CREDS}" \
            --all --preserve-digests \
            --dest-tls-verify=false >/dev/null 2>&1; then

            echo "[INFO] Success"
            SUCCESSFUL=true
            break
        fi

        if [[ "$RETRY" -lt "$MAX_RETRIES" ]]; then
            echo "[WARN] Copy failed for ${SRC}. Retrying in ${RETRY_DELAY}s..."
            sleep "$RETRY_DELAY"
        fi
    done

    if [[ "$SUCCESSFUL" != true ]]; then
        ((FAILS++))
        echo "[ERROR] Failed to copy after ${MAX_RETRIES} attempts: ${SRC}" >&2
        echo "--------------------"
    fi

    echo
done < "$IMAGE_FILE"

SUCCESS=$((TOTAL - FAILS))

echo "========================================"
echo "[INFO] Summary"
echo "Total images : ${TOTAL}"
echo "Total failed : ${FAILS}"
echo "Total success: ${SUCCESS}"
echo "========================================"

if [[ "$FAILS" -gt 0 ]]; then
    echo "[ERROR] Error encountered while mirroring cyberfraud images to private registry"
    exit 1
else
    echo "[INFO] Cyberfraud image mirroring process for non-OCP air-gapped environments completed!"
    exit 0
fi
