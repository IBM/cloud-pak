#!/bin/bash
# (C) Copyright IBM Corp. 2026  All Rights Reserved.
#
# This script implements the launch interface for IBM CyberFraud deployment

# ----- LOGS -----
log_file="/tmp/cyberfraud.log-$(date +'%Y-%m-%d_%H-%M-%S')"
exec > >(tee -a "$log_file") 2>&1
# IBM CyberFraud specific variables
caseName="ibm-cyberfraud"
inventory="ibmCyberFraudOperatorSetup"
defaultConfigFile="${scriptDir}/values.conf"
linuxConfigFile="${scriptDir}/values.linux.conf"
export namespace
export kubernetesCLI="oc"
export inputcasedir

# K3s Configuration
k3sToken="k3s-cluster-token"
k3sVersion="v1.32.12+k3s1"  # K3s version to install for Linux deployments
ocVersion="4.20.0"          # OpenShift CLI version to install on k3s nodes
olmNamespace="olm"          # OLM namespace



# Flags
linuxDeployment=0      # Flag for linux-based deployment such as k3s
skipCredsValidation=0  # Flag for skipping credentials validation
force=0                # Flag for force uninstall
dev=0                  # Flag for dev mode

# Catalog configuration
catalogNamespace="openshift-marketplace"
cyberfraudComponents=("cyberfraud")


# ----- HELPER FUNCTIONS -----

function log_info() {
    echo "[INFO] $1"
}

function log_success() {
    echo "[SUCCESS] $1"
}

function log_warning() {
    echo "[WARNING] $1"
}

function log_error() {
    echo "[ERROR] $1"
}

function err_exit() {
    log_error "$1"
    exit 1
}

function validate_file_exists() 
{
    local file="$1"
    if [[ ! -f "${file}" ]]; then
        err_exit "File ${file} does not exist"
    fi
}

function run() {
    command=$1
    message=$2
    if ! bash ${command}; then
        err_exit "${message} has failed"
    fi
}

# Read OLM version from version.yaml (source of truth for downloaded OLM artifacts)
olmVersionFile="${scriptDir}/support/olm/version.yaml"
validate_file_exists "${olmVersionFile}"

olmVersion=$(grep -E '^version:' "${olmVersionFile}" | awk '{print $2}' | tr -d '[:space:]')

if [[ -z "${olmVersion}" ]]; then
    err_exit "Could not parse OLM version from ${olmVersionFile}"
fi

# ----- VALIDATION FUNCTIONS -----

function validate_parameters() {

    ## check if oc cli is available and set kubernetesCLI to oc or kubectl accordingly
    if command -v oc &> /dev/null; then
        kubernetesCLI="oc"
        log_info "Using 'oc' as the Kubernetes CLI"
    elif command -v kubectl &> /dev/null; then
        kubernetesCLI="kubectl"
        log_info "Using 'kubectl' as the Kubernetes CLI"
    else
        err_exit "Neither 'oc' nor 'kubectl' command-line tools are available. Please install one of them to proceed."
    fi

    # Validation for the actions and the parameters
    if [[ "${action}" == "install" ]] || [[ "${action}" == "upgrade" ]]; then
        validate_file_exists "${configFile}"
        source "${configFile}"

        # Check if license has been accepted (after sourcing values configuration file)
        if [[ -z "${acceptLicense}" ]] || [[ "${acceptLicense}" != "true" ]]; then
            err_exit "License was not accepted. Please read the license and accept by setting 'acceptLicense=true' in ${configFile}"
        fi

        # Validate mandatory parameters

        [[ -z "${deploymentType}" ]] && err_exit "deploymentType parameter is empty. Please set deploymentType in ${configFile}"

        # Validate deploymentType
        if [[ "${deploymentType}" != "demo" ]] && [[ "${deploymentType}" != "production" ]]; then
            err_exit "deploymentType must be either 'demo' or 'production'"
        fi

        # Domain/cert checks.
        if [[ "${linuxDeployment}" -eq 1 ]] || [[ "${linuxDeployment}" == "true" ]]; then
            linuxDeployment=1
            # Non-ocp deployment
            log_info "Non-OCP deployment mode enabled"
            
            # Set catalog namespace to 'olm' for Linux deployments
            catalogNamespace="olm"
            log_info "Catalog namespace set to: ${catalogNamespace}"
            
            # For Linux deployments, domain is mandatory
            if [[ -z "${domain}" ]]; then
                err_exit "domain parameter is required for Linux deployments. Please set domain in ${configFile}"
            fi
            
            # Validate that the domain is properly formatted
            log_info "Domain specified: ${domain}"
            if [[ ! "${domain}" =~ ^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])(.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]))*$ ]]; then
                err_exit "The domain '${domain}' set in ${configFile} is invalid. Please provide a valid domain name."
            fi

            #Ensure cert/keys are provided
            if [[ -z "${domainCertificatePath}" ]]; then
                    err_exit "domainCertificatePath parameter is empty. Please specify the domainCertificatePath in the ${configFile}."
            elif [[ -z "${domainCertificateKeyPath}" ]]; then
                err_exit "domainCertificateKeyPath parameter is empty. Please specify the domainCertificateKeyPath in the ${configFile}."
            fi

            # Check if the provided certificate files exist
            validate_file_exists "${domainCertificatePath}"
            validate_file_exists "${domainCertificateKeyPath}"
            if [[ -n "${customCaFilePath}" ]]; then
                validate_file_exists "${customCaFilePath}"
            fi

            # Validate that the domain and subdomains can be resolved (DNS check)
            log_info "Validating domain and subdomains can be resolved..."
            
            # Define subdomains to check
            local subdomains=("keycloak-${domain}" "s3-${domain}")
            local dns_tool=""
            local all_resolved=true
            
            # Determine which DNS tool is available
            if command -v dig &> /dev/null; then
                dns_tool="dig"
            elif command -v host &> /dev/null; then
                dns_tool="host"
            elif command -v nslookup &> /dev/null; then
                dns_tool="nslookup"
            else
                log_warning "DNS lookup tools (dig/host/nslookup) not available. Skipping domain resolution check."
            fi
            # Check base domain and all subdomains if DNS tool is available
            if [[ -n "${dns_tool}" ]]; then
                # Check base domain
                log_info "Checking base domain: ${domain}"
                if ! ${dns_tool} "${domain}" &> /dev/null; then
                      log_warning "Base domain '${domain}' cannot be resolved via DNS."
                      all_resolved=false
                else
                    log_success "Base domain '${domain}' successfully resolved"
                fi
                
                # Check each subdomain
                for subdomain in "${subdomains[@]}"; do
                    log_info "Checking subdomain: ${subdomain}"
                    if ! ${dns_tool} "${subdomain}" &> /dev/null; then
                        log_warning "Subdomain '${subdomain}' cannot be resolved via DNS."
                        all_resolved=false
                    else
                        log_success "Subdomain '${subdomain}' successfully resolved"
                    fi
                done
                
                # Final warning if any domain failed to resolve
                if [[ "${all_resolved}" == false ]]; then
                    err_exit "One or more domains could not be resolved. Ensure all domains are properly configured in DNS."
                else
                    log_success "All domains successfully resolved"
                fi
            fi
        else
            # ocp deployment.
            log_info "OCP mode enabled (OpenShift Deployment)"
            
            # Set catalog namespace to 'openshift-marketplace' for OCP deployments
            catalogNamespace="openshift-marketplace"
            log_info "Catalog namespace set to: ${catalogNamespace}"

            if [[ -n "${domain}" ]]; then
                log_info "Domain specified: ${domain}"

                 # Validate that the domain is properly formatted
                if [[ ! "${domain}" =~ ^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])(.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]))*$ ]]; then
                    err_exit "The domain set in the ${configFile} is invalid."
                fi
                # If domain is valid then check if the certificate files are provided
                if [[ -z "${domainCertificatePath}" ]]; then
                    err_exit "domainCertificatePath parameter is empty. Please specify the domainCertificatePath in the ${configFile}."
                elif [[ -z "${domainCertificateKeyPath}" ]]; then
                    err_exit "domainCertificateKeyPath parameter is empty. Please specify the domainCertificateKeyPath in the ${configFile}."
                fi

                # Check if the provided certificate files exist
                validate_file_exists "${domainCertificatePath}"
                validate_file_exists "${domainCertificateKeyPath}"
                if [[ -n "${customCaFilePath}" ]]; then
                    validate_file_exists "${customCaFilePath}"
                fi
            fi
        fi

        # Validate the storage class
        validate_storage_class "${storageClass}"

        # Check if registryUsername is empty
        [[ -z "${registryUsername}" ]] && { err_exit "registryUsername parameter is empty. Please set registryUsername in the ${configFile}."; }

        # Check if registryPassword is empty
        [[ -z "${registryPassword}" ]] && { err_exit "registryPassword parameter is empty. Please set registryPassword in the ${configFile}."; }

        # Check if registry is empty
        [[ -z "${registry}" ]] && { err_exit "registry parameter is empty. Please set registry in the ${configFile}."; }
        
        #if dev install set entitled registry parameters and ensure password is provided. Skip for airgapInstall since the production registry is not needed for airgapInstall
        if [[ "${dev}" -eq 1 && "${airgapInstall}" != "true"  ]]; then
            # Check if prod_registry is empty
            [[ -z "${prod_registry}" ]] && { prod_registry="cp.icr.io"; }

            # Check if user is empty
            [[ -z "${user}" ]] && { user="cp"; }

            # Check if pass is empty. skip for airgapInstall since the production registry is not needed for airgapInstall
            if [[ -z "${pass}" ]]; then
                err_exit "Password for the production registry are needed when running ${action} action. Please use --pass flag within the '--args' parameter."
            fi

            if [[ "${skipCredsValidation}" -eq 0 ]]; then
                verify_registry "${prod_registry}" "${user}" "${pass}"
            fi
        fi 
        ##check if airgapInstall is enabled
        if [[ "${airgapInstall}" == "true" ]]; then
            log_info "Airgap installation is enabled."
        fi  
        # Verify registry credentials
        if [[ "${skipCredsValidation}" -eq 0 ]]; then
            verify_registry "${registry}" "${registryUsername}" "${registryPassword}"
        fi
    fi
}
function validate_storage_class() {
    # Check if there a default storage class, if none found exit out
    storageClass="$1"

    # Check the storage class passed in the values configuration file
    if [[ -n "${storageClass}" ]]; then
        local checkStorage=$($kubernetesCLI get sc "${storageClass}" --no-headers --ignore-not-found=true | awk '{print $1;exit;}')
        if [[ -z "${checkStorage}" ]]; then
            availableStorage=$($kubernetesCLI get sc --no-headers | awk '{print $1}')
            log_error "Storage class ${storageClass} not found"
            log_error "Select from available storage classes:"
            echo "${availableStorage}"
            exit 1
        else
            log_info "Storage class ${storageClass} will be used."
            return
        fi
    else
        log_info "storageClass parameter in ${configFile} is empty, checking for default storage class..."
        
        # Check if a default storage class exists
        storageClass=$($kubernetesCLI get sc --no-headers 2>/dev/null | grep '(default)' | awk '{print $1;exit;}')
        
        if [[ -z "${storageClass}" ]]; then
            log_error "No default storage class found in the cluster"
            log_error "Please either:"
            log_error "  1. Set a default storage class in your cluster, or"
            log_error "  2. Specify a storage class in ${configFile}"
            log_error ""
            log_error "Available storage classes:"
            $kubernetesCLI get sc --no-headers | awk '{print "  - " $1}'
            exit 1
        else
            log_success "Default storage class '${storageClass}' found and will be used."
        fi
    fi
    export storageClass
}
function validate_accountsetup_parameters() {
    log_info "Validating account setup parameters..."
    
    if [[ "${linuxDeployment}" -eq 1 ]]; then
        configFile="${linuxConfigFile}"
        log_info "Non-OCP environment detected, using config file: ${configFile}"
    else
        configFile="${defaultConfigFile}"
        log_info "OpenShift environment detected, using config file: ${configFile}"
    fi
    
    # Check if values configuration file file exists and source it
    validate_file_exists "${configFile}"
    source "${configFile}"
    
    # Validate mandatory parameters for account setup
    if [[ -z "${accountName}" ]]; then
        err_exit "accountName parameter is empty. Please pass --accountName <value> as a command-line argument"
    fi
    
    if [[ -z "${accountUser}" ]]; then
        err_exit "accountUser parameter is empty. Please pass --accountUser <value> as a command-line argument"
    fi
    
    # Set default value for piiDisabled if not provided
    if [[ -z "${piiDisabled}" ]]; then
        piiDisabled="false"
        log_info "piiDisabled not provided, using default value: false"
    fi
    
    log_success "Account setup parameters validated successfully"
    log_info "Account Name: ${accountName}"
    log_info "Account User: ${accountUser}"
    log_info "PII Disabled: ${piiDisabled}"
}


function verify_registry() {
    local reg="$1"
    local user="$2"
    local pass="$3"
    local cli="docker"
    local skipTls=""

    echo "[INFO] Verifying registry credentials for ${reg}..."
    if ! docker version >/dev/null 2>&1; then
        cli="podman"
        skipTls="--tls-verify=false"
        
    fi

    if ! $cli login -u "${user}" -p "${pass}" "${reg}" $skipTls >/dev/null 2>&1; then
        err_exit "Registry validation failed. Please check registry credentials or if docker/podman is running."
    else
        echo "[INFO] Registry validation successful."
    fi
}

# ----- NAMESPACE FUNCTIONS -----

function setup_namespace() {
    local ns="$1"
    local checkNamespace=$($kubernetesCLI get namespace "${ns}" -o name --ignore-not-found 2>/dev/null)

    if [[ -n "${checkNamespace}" ]]; then
        log_info "Found namespace ${ns}"
    else
        if [[ "${action}" == "uninstall" || "${action}" == "account_setup" || "${action}" == "upgrade" ]]; then
            err_exit "Unable to retrieve namespace ${namespace}"
        else
            log_info "Creating namespace ${ns}"
            if ! $kubernetesCLI create namespace "${ns}" 2>/dev/null; then
                err_exit "Failed to create ${ns} namespace"
            fi
            log_success "Namespace ${ns} created"
        fi
    fi
 
}

# ----- SECRET FUNCTIONS -----

function create_pull_secret() {
    local secretName="$1"
    local secretNamespace="$2"
    local registry="$3"
    local username="$4"
    local password="$5"
    local DevMergeRegistries="${6:-false}"  # Optional parameter to merge values configuration file creds with Entitled registry creds and dev registries

    # Check if secret already exists
    local secret=$($kubernetesCLI get secret "${secretName}" -n "${secretNamespace}" --no-headers --ignore-not-found=true 2>/dev/null | awk '{print $1}')
    if [[ -n "${secret}" ]]; then
        log_warning "${secret} already exists in ${secretNamespace} namespace. It will be deleted and recreated."
        $kubernetesCLI delete secret "${secret}" -n "${secretNamespace}" --ignore-not-found=true
    fi

    log_info "Creating pull secret ${secretName} in ${secretNamespace} namespace"
    
    # Determine base64 flag based on OS
    local base64Flag=""
    if [ "$(uname)" != "Darwin" ]; then
        base64Flag="-w 0"
    fi
    
    # Create dockerconfigjson with proper auth encoding
    local secretData
    if [[ "${DevMergeRegistries}" == "true" ]]; then
        # Create merged credentials with both prod registry and dev registries
        log_info "Creating pull secret with merged credentials (prod + dev registries)"
        # Add icr.io/ibm-cyberfraud-preprod/cpopen/cf registry with same credentials from values configuration file (assuming icr.io/ibm-cyberfraud-preprod/cf in values configuration file)
        local preprodCpopenRegistry="icr.io/ibm-cyberfraud-preprod/cpopen/cf"
        secretData="{\"auths\":{\"${prod_registry}\":{\"username\":\"${user}\",\"password\":\"${pass}\",\"auth\":\"$(echo -n ${user}:${pass} | base64 ${base64Flag})\"},\"${registry}\":{\"username\":\"${username}\",\"password\":\"${password}\",\"auth\":\"$(echo -n ${username}:${password} | base64 ${base64Flag})\"},\"${preprodCpopenRegistry}\":{\"username\":\"${username}\",\"password\":\"${password}\",\"auth\":\"$(echo -n ${username}:${password} | base64 ${base64Flag})\"}}}"
    else
        # Create single registry credentials
        secretData="{\"auths\":{\"${registry}\":{\"username\":\"${username}\",\"password\":\"${password}\",\"auth\":\"$(echo -n ${username}:${password} | base64 ${base64Flag})\"}}}"
    fi
    
    # Use generic secret with --from-literal to properly handle the JSON data
    if ! $kubernetesCLI create secret generic "${secretName}" \
        -n "${secretNamespace}" \
        --from-literal=.dockerconfigjson="${secretData}" \
        --type=kubernetes.io/dockerconfigjson \
        --dry-run=client -o yaml | $kubernetesCLI apply -f -; then
        err_exit "Failed to create ${secretName} secret in ${secretNamespace} namespace"
    fi
    log_success "Pull secret ${secretName} created in ${secretNamespace}"
}

function setup_registry_credentials() {
    # Grab credentials from values configuration file
    local Registry="${registry}"
    local User="${registryUsername}"
    local Pass="${registryPassword}"
    
    if [[ "${dev}" -eq 1  ]]; then
        log_info "[INFO] Dev mode is enabled"

        # Create pull secret in catalogNamespace (openshift-marketplace/olm) ith merged credentials (prod/entitled + dev registries)
        create_pull_secret "ibm-entitlement-key" "${catalogNamespace}" "${Registry}" "${User}" "${Pass}" "true"

        # Create pull secret in namespace with merged credentials (prod/entitled + dev registries)
        create_pull_secret "ibm-entitlement-key" "${namespace}" "${Registry}" "${User}" "${Pass}" "true"
    else
        log_info "Production install, creating pull secret for in ${namespace} namespace". # Change here when full production catalog is avalable, entitlement key in catalogNamespace (openshift-marketplace/olm) may not be needed.
        create_pull_secret "ibm-entitlement-key" "${namespace}" "${Registry}" "${User}" "${Pass}" "false"
    fi

}

# Copy registries.yaml to all nodes for airgapInstall installations
function nonocp_copy_registries_yaml_airgap() {
    log_info "========================================="
    log_info "Copying registries.yaml to all nodes for airgapInstall installation"
    log_info "========================================="
    
    # Validate that registries.yaml exists
    local registries_yaml="/tmp/registries.yaml"
    if [[ ! -f "${registries_yaml}" ]]; then
        err_exit "registries.yaml not found at ${registries_yaml}. Please ensure the file exists before running airgapInstall installation."
    fi
    
    log_info "Found registries.yaml at ${registries_yaml}"
    
    source "${configFile}"
    
    local failed_nodes=()
    local all_hosts="${MasterHosts}"
    
    # Add worker hosts if they exist
    if [[ -n "${WorkerHosts}" ]]; then
        all_hosts="${all_hosts},${WorkerHosts}"
    fi
    
    log_info "Copying registries.yaml to all cluster nodes..."
    IFS=',' read -ra HOSTS <<< "${all_hosts}"
    
    for host in "${HOSTS[@]}"; do
        host=$(echo "${host}" | xargs)  # trim whitespace
        
        if ! sshpass -p "${SshPassword}" ssh -o StrictHostKeyChecking=no "root@${host}" \
            "mkdir -p /etc/rancher/k3s && cat > /etc/rancher/k3s/registries.yaml" \
            < "${registries_yaml}"; then
            log_error "Failed to configure registries.yaml on ${host}"
            failed_nodes+=("${host}")
            continue
        fi
        log_success "Copied registries.yaml to ${host}"
    done
    
    # Check if any nodes failed
    if [ ${#failed_nodes[@]} -gt 0 ]; then
        log_error "Failed to configure registries.yaml on the following nodes:"
        for node in "${failed_nodes[@]}"; do
            log_error "  - ${node}"
        done
        err_exit "Airgap registry configuration failed on ${#failed_nodes[@]} node(s). Installation cannot continue."
    fi
}

# Validate OCP nodes are in Ready state
function validate_ocp_nodes() {
    log_info "Validating OpenShift nodes status..."
    
    local timeout=600  # 10 minutes timeout
    local elapsed=0
    local interval=30
    
    while [ ${elapsed} -lt ${timeout} ]; do
        # Check if all nodes are Ready
        local not_ready=$(${kubernetesCLI} get nodes --no-headers | grep -v " Ready" | wc -l)
        
        if [ "${not_ready}" -eq 0 ]; then
            log_success "All nodes are in Ready state"
            ${kubernetesCLI} get nodes
            return 0
        fi
        
        log_info "Waiting for nodes to be Ready... (${elapsed}s/${timeout}s)"
        ${kubernetesCLI} get nodes
        sleep ${interval}
        elapsed=$((elapsed + interval))
    done
    
    log_error "Timeout waiting for nodes to be Ready"
    ${kubernetesCLI} get nodes
    return 1
}

# Validate K3s nodes are in Ready state
function validate_k3s_nodes() {
    log_info "Validating K3s nodes status..."
    
    local timeout=300  # 5 minutes timeout
    local elapsed=0
    local interval=15
    
    while [ ${elapsed} -lt ${timeout} ]; do
        # Check if all nodes are Ready
        local not_ready=$(${kubernetesCLI} get nodes --no-headers 2>/dev/null | grep -v " Ready" | wc -l)
        
        if [ "${not_ready}" -eq 0 ]; then
            local total_nodes=$(${kubernetesCLI} get nodes --no-headers 2>/dev/null | wc -l)
            if [ "${total_nodes}" -gt 0 ]; then
                log_success "All K3s nodes are in Ready state"
                ${kubernetesCLI} get nodes
                return 0
            fi
        fi
        
        log_info "Waiting for K3s nodes to be Ready... (${elapsed}s/${timeout}s)"
        ${kubernetesCLI} get nodes 2>/dev/null || log_warning "Unable to connect to cluster yet"
        sleep ${interval}
        elapsed=$((elapsed + interval))
    done
    
    log_error "Timeout waiting for K3s nodes to be Ready"
    ${kubernetesCLI} get nodes 2>/dev/null
    return 1
}


# ----- TLS/CERTIFICATE FUNCTIONS -----

function set_domain() {
    # Check if a domain has been passed in, if so return to main function
    if [[ -n "${domain}" ]]; then
        log_info "Domain set to ${domain} from ${configFile}" 
        return
    fi

    # Show the Cyberfraud domain name based on the route of the cluster
    local cyfrDomain="cyberfraud.$($kubernetesCLI get -n openshift-console route console -o jsonpath="{.spec.host}" | sed -e 's/^[^\.]*\.//')"
    echo "[INFO] Cyberfraud domain will be set to ${cyfrDomain}"
}

function setup_tls_secret() {

    if [[ -z "${domain}" ]] || [[ "${skipTLSCreation}" -eq 1 ]]; then
        log_info "Skipping TLS secret creation"
        return
    fi

    log_info "Creating TLS secret for domain ${domain}"
    
    local tlsSecretName="domain-cert"
    
    # Delete existing secret if present
    $kubernetesCLI delete secret "${tlsSecretName}" -n "${namespace}" --ignore-not-found=true 2>/dev/null
    
    # Create TLS secret
    if [[ -z "${customCaFilePath}" ]]; then
        if ! $kubernetesCLI create secret tls "${tlsSecretName}" \
            -n "${namespace}" \
            --cert="${domainCertificatePath}" \
            --key="${domainCertificateKeyPath}"; then
            err_exit "Failed to create TLS secret"
        fi
    else
    # Create the TLS secret with the custom CA file
        if ! $kubernetesCLI create secret generic "${tlsSecretName}" --type=kubernetes.io/tls -n "${namespace}" \
            --from-file=ca.crt="${customCaFilePath}" \
            --from-file=tls.crt="${domainCertificatePath}" \
            --from-file=tls.key="${domainCertificateKeyPath}"; then
            err_exit "Failed to create TLS secret."
        fi
    fi
    log_success "TLS secret created"
}
# ----- REPOSITORY FUNCTIONS -----

# Sets global cpOpenBaseRegistryPath/repositoryMod based on dev/airgapInstall/registry, used by multiple functions
function set_repository_mod() {
    if [[ "${dev}" -eq 1 ]]; then
        cpOpenBaseRegistryPath="ibm-cyberfraud-preprod/cpopen/cf"
        cpBaseRegistryPath="ibm-cyberfraud-preprod/cf"
    else
        cpOpenBaseRegistryPath="cpopen/cf"
        cpBaseRegistryPath="cp/cf"
    fi
}

# ----- CATALOG FUNCTIONS -----

function install_catalogs() {
    log_info "========================================="
    log_info "Installing Operator Catalog"
    log_info "========================================="
    
    local catalog=""
    catalog=("cyberfraud")

    create_catalog_source "${catalog}"
    wait_for_catalog_ready "${catalog}"
    log_success "Catalog installation completed"

}
function create_catalog_source {
    local catalog_source_name="$1"
    log_info "Creating  catalog source for ${catalog_source_name}"

    local catSrcFile="${casePath}/inventory/${inventory}/files/op-olm/${catalog_source_name}CatalogSource.yaml"
    # Verify if expected yaml files exists
    validate_file_exists "${catSrcFile}"
    if [[ "${airgapInstall}" == "true" ]]; then
        repositoryMod="${registry}/${cpOpenBaseRegistryPath}"
    else
        repositoryMod="icr.io/${cpOpenBaseRegistryPath}"
    fi
    # Retain a record for the original catalog source image
    local catSrcImgOriginal=$(grep "image:" "${catSrcFile}" | awk '{print $2}')
    local ogImg=$(cut -d "@" -f 1 <<<"$catSrcImgOriginal")

    # Build the new catalog source image
    ogImgNameAndTags="${ogImg##*/}"     #image name + tag
    ogImgName="${ogImgNameAndTags%:*}"  #image name
    ogCatsrcTag="${ogImgNameAndTags#*:}"  #extract tag from image name

    if [[ -n "${catalogSrcTag}" ]]; then
        if [[ $catalogSrcTag == *"sha256"* ]]; then
            catSrcImage="${repositoryMod}/${ogImgName}@${catalogSrcTag}" 
        else
            catSrcImage="${repositoryMod}/${ogImgName}:${catalogSrcTag}"
        fi
    else
        if [[ $catSrcImgOriginal == *"sha256"* ]]; then
            currentSha=$(cut -d "@" -f 2 <<<"$catSrcImgOriginal")
            catSrcImage="${repositoryMod}/${ogImgName}@${currentSha}"
        else
            catSrcImage="${repositoryMod}/${ogImgNameAndTags}"
        fi
    fi
    validate_file_exists "${casePath}/inventory/${inventory}/files/op-olm/${catalog_source_name}CatalogSource.yaml"
    if ! sed -e "s|image:.*|image: ${catSrcImage}|g" \
        -e "s|REPLACE_NAMESPACE|${catalogNamespace}|g" \
        "${casePath}"/inventory/"${inventory}"/files/op-olm/${catalog_source_name}CatalogSource.yaml | $kubernetesCLI apply -n "${catalogNamespace}" -f -; then
        err_exit "Failed to apply ${catalog_source_name} catalog source in ${catalogNamespace} namespace"
    fi
}

function wait_for_catalog_ready() {
    local catalog="$1"
    local timeout=180
    local elapsed=0

    if [[ "${catalog}" == "cyberfraud" ]]; then
        catalogName="ibm-cyberfraud-release-catalog"
    elif [[ "${catalog}" == "ibmoperator" ]]; then
        catalogName="ibm-operator-catalog"
    fi
    
    log_info "Waiting for catalog source ${catalogName} to be ready..."
    
    while [ $elapsed -lt $timeout ]; do
        local status=$($kubernetesCLI get catalogsource "${catalogName}" -n "${catalogNamespace}" -o jsonpath='{.status.connectionState.lastObservedState}' 2>/dev/null || echo "")
        
        if [[ "${status}" == "READY" ]]; then
            log_success "Catalog source ${catalogName} is ready"
            return 0
        fi
        
        sleep 5
        elapsed=$((elapsed + 5))
        echo -n "."
    done
    
    echo ""
    err_exit "Timeout waiting for catalog source ${catalogName} to be ready"
}

# ----- OPERATOR FUNCTIONS -----

function install_operators() {
    log_info "========================================="
    log_info "Installing CyberFraud Operator"
    log_info "========================================="
    
    # Create operator group
    create_operator_group
    
    # Create subscription
    create_subscriptions
    
    log_success "Operator installation completed"
}

function create_operator_group() {
    log_info "Creating operator group"
    
    # Check if operator group already exists
    local existingOG=$($kubernetesCLI get operatorgroup -n "${namespace}" --no-headers --ignore-not-found=true 2>/dev/null | awk '{print $1}' | head -1)
    
    if [[ -n "${existingOG}" ]]; then
        log_info "Operator group already exists: ${existingOG}"
        return 0
    fi
    
    validate_file_exists "${casePath}/inventory/${inventory}/files/op-olm/operatorGroup.yaml"
    if ! sed -e "s|REPLACE_NAMESPACE|${namespace}|g" \
        "${casePath}"/inventory/"${inventory}"/files/op-olm/operatorGroup.yaml | $kubernetesCLI apply -n "${namespace}" -f -; then
        err_exit "Failed to create operator group in ${namespace} namespace"
    fi
    log_success "Operator group created"
}

function create_subscriptions() {
    log_info "Creating subscriptions"
    local subscriptionNamespace="${namespace}"
    local subscriptionName="ibm-cyberfraud-operator"
    local components=("")

    #Create the operator subscription

    validate_file_exists "${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    subscriptionSource="ibm-cyberfraud-release-catalog"
    # ## Set the subscriptionSource to ibm-cyberfraud-release-catalog if airgapInstall is set to true or catalogsource is set to ibm-cyberfraud-release-catalog or dev is set to true
    # if [[ "${airgapInstall}" -eq 1 ]] || [[ "${catalogSource}" == "ibm-cyberfraud-release-catalog" ]] || [[ "${dev}" -eq 1 ]]; then
    #     subscriptionSource="ibm-cyberfraud-release-catalog"
    # else
    #     subscriptionSource="ibm-operator-catalog"
    # fi
    if ! sed -e "s|REPLACE_NAMESPACE|${subscriptionNamespace}|g" \
        -e "s|REPLACE_NAME|${subscriptionName}|g" \
        -e "s|REPLACE_SOURCE|${subscriptionSource}|g" \
        -e "s|REPLACE_SRC_NAMESPACE|${catalogNamespace}|g" \
        "${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml | $kubernetesCLI apply -n "${subscriptionNamespace}" -f -; then
        err_exit "Failed to create subscription ${subscriptionName} in namespace ${subscriptionNamespace}"
    fi

    while true; do
        $kubernetesCLI -n "${subscriptionNamespace}" get subscription.operators.coreos.com ${subscriptionName} &>/dev/null && break
        sleep $wait
    done
    wait_for_csv ${subscriptionName}
    log_success "Subscription ${subscriptionName} created"
}

function wait_for_csv() {
    local timeout=300
    local elapsed=0
    operatorName="$1"
    
    log_info "Waiting for ClusterServiceVersion for ${operatorName} to be ready..."
    
    while [ $elapsed -lt $timeout ]; do
        local csv=$($kubernetesCLI get csv -n "${namespace}" 2>/dev/null | grep "${operatorName}" | awk '{print $1}' | head -1)
        
        if [[ -n "${csv}" ]]; then
            local phase=$($kubernetesCLI get csv "${csv}" -n "${namespace}" -o jsonpath='{.status.phase}' 2>/dev/null)
            
            if [[ "${phase}" == "Succeeded" ]]; then
                log_success "ClusterServiceVersion ${csv} is ready"
                return 0
            fi
            
            log_info "${operatorName} CSV phase: ${phase}"
        fi
        
        sleep 10
        elapsed=$((elapsed + 10))
    done
    
    err_exit "Timeout waiting for ClusterServiceVersion to be ready"
}

# ----- CUSTOM RESOURCE FUNCTIONS -----

function deploy_custom_resources() {
    log_info "========================================="
    log_info "Deploying Custom Resources"
    log_info "========================================="
    
    # Deploy CyberfraudDeployment CR
    deploy_cyberfraud_deployment_cr
    
    # Wait for deployment to be ready
    wait_for_deployment_ready
    
    log_success "Custom resources deployed successfully"
}

function deploy_cyberfraud_deployment_cr() {
    log_info "Deploying CyberfraudDeployment CR"
    validate_file_exists "${casePath}/inventory/${inventory}/files/op-olm/cyberfraudDeployment.yaml"
    
    # Build parameters based on linuxDeployment flag
    local parameters=""
    
    # Add serviceability repository parameter in dev installs. no need to set registry under the else statement because the default is defined in the values file
    if [[ "${airgapInstall}" == "true" ]]; then
        serviceabilityRepository="${registry}/${cpOpenBaseRegistryPath}"
        registry="${registry}/${cpBaseRegistryPath}"
    else
        serviceabilityRepository="icr.io/${cpOpenBaseRegistryPath}"
    fi
    if [[ "${dev}" -eq 1  || "${airgapInstall}" == "true" ]]; then
        if [[ -n "${parameters}" ]]; then
        parameters="${parameters}\\n    - serviceability.repository=${serviceabilityRepository}"
        else
            parameters="- serviceability.repository=${serviceabilityRepository}"
        fi
    fi
    
    # This will use a parameter to pass in a dev middleware image.
    # Change - Can be removed when decided we do not need this flexibility

    if sed -e "s|REPLACE_NAMESPACE|${namespace}|g" \
        -e "s|REPLACE_ACCEPT_LICENSE|${acceptLicense}|g" \
        -e "s|REPLACE_DOMAIN|${domain}|g" \
        -e "s|REPLACE_STORAGE_CLASS|${storageClass}|g" \
        -e "s|REPLACE_IMAGEPULL_POLICY|${imagePullPolicy}|g" \
        -e "s|REPLACE_REPOSITORY|${registry}|g" \
        -e "s|REPLACE_PII_DISABLED|${piiDisabled}|g" \
        -e "s|REPLACE_PARAMETERS|${parameters}|g" \
        -e "s|REPLACE_DEPLOYMENT_TYPE|${deploymentType}|g" \
        "${casePath}"/inventory/"${inventory}"/files/op-olm/cyberfraudDeployment.yaml | $kubernetesCLI apply -n "${namespace}" -f -; then
        log_success "CyberfraudDeployment CR applied"
    else
        err_exit "Failed to apply CyberfraudDeployment CR."
    fi
}

function deploy_cyberfraud_account_cr() {
    log_info "Deploying CyberfraudAccount CR"

    account_cr_name="cyberfraudaccount"

    validate_file_exists "${casePath}/inventory/${inventory}/files/op-olm/cyberfraudAccount.yaml"
    if sed -e "s|REPLACE_NAMESPACE|${namespace}|g" \
        -e "s|REPLACE_ACCOUNT_CR_NAME|${account_cr_name}|g" \
        -e "s|REPLACE_ACCOUNT_NAME|${accountName}|g" \
        -e "s|REPLACE_ACCOUNT_USER|${accountUser}|g" \
        -e "s|REPLACE_PII_DISABLED|${piiDisabled}|g" \
        "${casePath}"/inventory/"${inventory}"/files/op-olm/cyberfraudAccount.yaml | $kubernetesCLI apply -n "${namespace}" -f -; then
        log_success "CyberfraudAccount CR applied"
    else
        err_exit "Failed to apply CyberfraudAccount CR"
    fi
}

function wait_for_deployment_ready() {
    local timeout=3600
    local elapsed=0
    
    log_info "Waiting for CyberfraudDeployment to be ready..."
    
    while [ $elapsed -lt $timeout ]; do
        local status=$($kubernetesCLI get cyberfrauddeployment -n "${namespace}" -o jsonpath='{.items[0].status.conditions[0].type}' 2>/dev/null || echo "")
        local message=$($kubernetesCLI get cyberfrauddeployment -n "${namespace}" -o jsonpath='{.items[0].status.conditions[0].message}' 2>/dev/null || echo "")
        
        if [[ "${status}" == "Success" ]]; then
            log_success "CyberfraudDeployment is ready"
            return 0
        fi
        
        if [[ -n "${status}" ]]; then
            log_info "Status: ${status} - ${message}"
        fi
        
        sleep 30
        elapsed=$((elapsed + 30))
    done
    
    err_exit "Timeout waiting for CyberfraudDeployment to be ready"
}

function wait_for_account_ready() {
    local timeout=600
    local elapsed=0
    
    log_info "Waiting for CyberfraudAccount to be ready..."
    
    while [ $elapsed -lt $timeout ]; do
        local status=$($kubernetesCLI get cyberfraudaccount -n "${namespace}" -o jsonpath='{.items[0].status.conditions[0].type}' 2>/dev/null || echo "")
        local message=$($kubernetesCLI get cyberfraudaccount -n "${namespace}" -o jsonpath='{.items[0].status.conditions[0].message}' 2>/dev/null || echo "")
        
        if [[ "${status}" == "Success" ]]; then
            log_success "CyberfraudAccount is ready"
            return 0
        fi
        
        if [[ -n "${status}" ]]; then
            log_info "Status: ${status} - ${message}"
        fi
        
        sleep 30
        elapsed=$((elapsed + 30))
    done
    
    err_exit "Timeout waiting for CyberfraudAccount to be ready"
}

# ----- K3S INSTALLATION FUNCTIONS -----
function copy_kubeconfig() {
    log_info "Copying kubeconfig from first master node..."
    
    local first_master="${1}"
    local ssh_password="${2}"
    local kubeconfig_dest="${scriptDir}/${first_master}-kubeconfig.yaml"
    
    # Add small delay before kubeconfig copy to avoid rapid successive connections
    sleep 2
    
    # Copy kubeconfig from first master with improved connection settings
    if sshpass -p "${ssh_password}" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
        -o ConnectTimeout=10 -o ConnectionAttempts=3 \
        "root@${first_master}:/etc/rancher/k3s/k3s.yaml" "${kubeconfig_dest}"; then
        
        # Replace localhost with actual master hostname
        sed -i.bak "s/127.0.0.1/${first_master}/g" "${kubeconfig_dest}"
        rm -f "${kubeconfig_dest}.bak"
        
        log_success "Kubeconfig copied to: ${kubeconfig_dest}"
        return 0
    else
        log_error "Failed to copy kubeconfig from ${first_master}"
        return 1
    fi
}
function label_annotate_nodes() {
    export KUBECONFIG="${scriptDir}/${first_master}-kubeconfig.yaml"
    
    # Get all nodes once
    local worker_nodes=$(kubectl get nodes --no-headers | awk '/-w/ {print $1}')
    local master_nodes=$(kubectl get nodes --no-headers | awk '/-m/ {print $1}')
    
    # Process worker nodes (label + annotate)
    if [[ -n "$worker_nodes" ]]; then
        log_info "Processing worker nodes..."
        for n in $worker_nodes; do
            kubectl label node "$n" node-role.kubernetes.io/worker=worker --overwrite || {
                err_exit "Failed to label worker node: $n"
                exit 1
            }
            kubectl annotate node "$n" kubernetes.io/role=worker --overwrite || {
                err_exit "Failed to annotate worker node: $n"
                exit 1
            }
        done
        log_info "Worker nodes labeled and annotated successfully!"
    fi
    
    # Process master nodes (annotate only)
    if [[ -n "$master_nodes" ]]; then
        log_info "Processing master nodes..."
        for n in $master_nodes; do
            kubectl annotate node "$n" kubernetes.io/role=master --overwrite || {
                err_exit "Failed to annotate master node: $n"
                exit 1
            }
            kubectl taint nodes "$n" node-role.kubernetes.io/master=true:NoSchedule --overwrite || {
                err_exit "Failed to annotate master node: $n"
                exit 1
            }
        done
        log_info "Master nodes annotated successfully!"
    fi
    
    # Display final state once
    kubectl get nodes --show-labels
}
#mirror all images required for cyberfraud deployment in airgap non-ocp
function linuxMirror_nonocp()
{
    
    #Load configuration from values configuration file

    if [[ "${action}" == "linuxMirror" ]]; then
        configFile="${linuxConfigFile}"
        validate_file_exists "${configFile}"
        source "${configFile}"
    fi
    image_map="$HOME/.ibm-pak/data/mirror/$CASE_NAME/$CASE_VERSION/images-mapping.txt"
    validate_file_exists ${image_map}
    chmod +x "${scriptDir}/support/k3s/air-gap/linuxMirror_nonocp.sh"
    if ! bash ${scriptDir}/support/k3s/air-gap/linuxMirror_nonocp.sh "${registryUsername}:${registryPassword}" ${image_map}; then
        exit 1
    fi
}
function install_k3s_cluster() {
    log_info "========================================="
    log_info "Starting k3s Cluster Installation"
    log_info "========================================="
    
    # Select config file based on deployment type
    if [[ "${linuxDeployment}" -eq 1 ]]; then
        configFile="${linuxConfigFile}"
        log_info "Non-OCP environment detected, using config file: ${configFile}"
    else
        err_exit "clusterInstall action can only be run with linuxDeployment = true"
    fi
    
    # Load configuration from values configuration file
    validate_file_exists "${configFile}"
    source "${configFile}"
    
    # Validate parameters
    if [[ -z "${MasterHosts}" ]]; then
        err_exit "MasterHosts must be set in values.linux.conf for non ocp cluster installation"
    fi
    
    if [[ -z "${SshPassword}" ]]; then
        err_exit "SshPassword must be set in values.linux.conf for non ocp cluster installation"
    fi

    if [[ -z "${k3sToken}" ]]; then
        err_exit "k3sToken must be set in values.linux.conf for non ocp cluster installation"
    fi

    if [[ "${linuxDeployment}" != "1" ]] && [[ "${linuxDeployment}" != "true" ]]; then
        err_exit "linuxDeployment must be set to 1 or true in values.linux.conf for non ocp cluster installation"
    fi
    
    # Run the k3s installation script with environment variables
    local k3s_install_script="${scriptDir}/support/k3s/install_k3s.sh"
    if [[ "${airgapInstall}" == "true" && ( "${linuxDeployment}" != "1" || "${linuxDeployment}" != "true" ) ]]; then
        set -e
        if ! bash ${scriptDir}/support/k3s/air-gap/prerequiste_nonocp_airgap.sh ${scriptDir}; then
            err_exit "Prerequisites for non-ocp airgap setup failed"
        fi
    fi

    validate_file_exists "${k3s_install_script}"
    
    # Export k3s configuration
    export K3S_VERSION="${k3sVersion}"
    export K3S_MASTER_HOSTS="${MasterHosts}"
    export K3S_WORKER_HOSTS="${WorkerHosts:-}"
    export K3S_SSH_PASSWORD="${SshPassword}"
    export K3S_TOKEN="${k3sToken:-k3s-cluster-token}"
    export OC_VERSION="${ocVersion}"
    
    log_info "K3s configuration:"
    log_info "  K3s Version: ${K3S_VERSION}"
    log_info "  Master Hosts: ${K3S_MASTER_HOSTS}"
    log_info "  Worker Hosts: ${K3S_WORKER_HOSTS:-none}"
    log_info ""
    
    # Copy registries.yaml for airgapInstall installations before k3s installation
    if [[ "${airgapInstall}" == "true" && ( "${linuxDeployment}" != "1" || "${linuxDeployment}" != "true" ) ]]; then
        log_info ""
        nonocp_copy_registries_yaml_airgap
        log_info ""
    fi
    if bash "${k3s_install_script}"; then
        log_info ""
        
        # Copy kubeconfig from first master
        IFS=',' read -ra MASTERS <<< "${MasterHosts}"
        local first_master="${MASTERS[0]}"
        first_master=$(echo "${first_master}" | xargs)
        
        copy_kubeconfig "${first_master}" "${SshPassword}"
        log_info ""
        
        # Install Rook-Ceph storage
        local rook_ceph_script="${scriptDir}/support/k3s/install_rook_ceph.sh"
        validate_file_exists "${rook_ceph_script}"
        if bash "${rook_ceph_script}" "${first_master}" "${SshPassword}" "${deploymentType}"; then
            log_success "Rook-Ceph storage configured successfully"
        else
            err_exit "Rook-Ceph installation failed, but k3s cluster is operational"
        fi
        log_info "========================================="
        #Add labels and annotations to the nodes
        label_annotate_nodes

        ###
        log_info "========================================="
        log_info "Initiating the Cyberfraud image mirroring process for the non-ocp air-gapped environments..."
        log_info "========================================="

        if [[ "${airgapInstall}" == "true" && ( "${linuxDeployment}" != "1" || "${linuxDeployment}" != "true" ) ]]; then
            log_info ""
            linuxMirror_nonocp 
            log_info ""
        fi

        ###
        log_info "========================================="
            log_success "k3s installation completed successfully"
            log_info "Log file: ${log_file}"
            log_info "Next Steps:"
            log_info "========================================="
            log_info "1. Export the kubeconfig to connect to cluster:"
            log_info "   export KUBECONFIG=${scriptDir}/${first_master}-kubeconfig.yaml"
            log_info ""
            log_info "2. Verify cluster is ready:"
            log_info "   kubectl get nodes"
            log_info ""
            log_info "3. Run the CyberFraud installation"
            log_info "========================================="
    else
        err_exit "k3s installation failed"
    fi
    
}

# ----- OLM INSTALLATION FUNCTION -----

function install_olm() {
    log_info "========================================="
    log_info "Installing Operator Lifecycle Manager (OLM)"
    log_info "========================================="
    
    # Check if OLM is already installed
    if $kubernetesCLI get deployment olm-operator -n "${olmNamespace}" &> /dev/null; then
        log_info "OLM is already installed"
        return 0
    fi
    
    log_info "OLM not found. Installing OLM version ${olmVersion}..."
    
    # Use local OLM install script
    local install_script="${scriptDir}/support/olm/install_olm.sh"
    validate_file_exists "${install_script}"
    
    # Install OLM using the local script
    if ! bash "${install_script}" "${olmVersion}"; then
        err_exit "OLM installation failed"
    fi
    
    log_success "OLM installation completed successfully"
}

function add_encryption_secret() {
    log_info "Copying encryption secret from rook-ceph namespace to ${namespace}"
    
    # Check if secret exists in rook-ceph namespace
    if ! $kubernetesCLI get secret rook-csi-encryption-passphrase -n rook-ceph > /dev/null 2>&1; then
        log_error "Secret rook-csi-encryption-passphrase not found in rook-ceph namespace"
        log_error "Failed to copy encryption secret, secret rook-csi-encryption-passphrase not found"
        log_error "Please ensure Rook-Ceph is installed and the encryption secret exists"
    else 
        # Copy secret from rook-ceph to target namespace
        log_info "Copying secret rook-csi-encryption-passphrase from rook-ceph to ${namespace}"
        if ! $kubernetesCLI get secret rook-csi-encryption-passphrase -n rook-ceph -o yaml \
            | sed 's/namespace: rook-ceph/namespace: '"${namespace}"'/' \
            | sed '/resourceVersion:/d;/uid:/d;/creationTimestamp:/d;/managedFields:/d' \
            | $kubernetesCLI apply -f -; then
            err_exit "Failed to copy encryption secret to namespace ${namespace}"
        fi
        log_success "Encryption secret rook-csi-encryption-passphrase copied successfully to namespace ${namespace}"
    fi
}
# ----- INSTALL FUNCTION -----

function install() {
    log_info "========================================="
    log_info "Starting CyberFraud Installation"
    log_info "========================================="
    
    # Select config file based on deployment type
    if [[ "${linuxDeployment}" -eq 1 ]]; then
        configFile="${linuxConfigFile}"
        log_info "Non-OCP environment detected, using config file: ${configFile}"
    else
        configFile="${defaultConfigFile}"
        log_info "OpenShift environment detected, using config file: ${configFile}"
    fi
    
    validate_parameters

    # Compute repositoryMod/cpOpenBaseRegistryPath for use across install functions
    set_repository_mod
    
    # Install OLM for Linux deployments
    if [[ "${linuxDeployment}" -eq 1 ]] || [[ "${linuxDeployment}" == "true" ]]; then
        install_olm
    fi
    
    # Setup namespace
    setup_namespace "${namespace}"
   
    if [[ "${storageClass}" == *"rook-ceph"* ]]; then
        add_encryption_secret
    fi
    
    # Setup registry credentials
    setup_registry_credentials
    

    # Setup TLS secret if provided
    set_domain
    setup_tls_secret
    
    # Install catalog
    install_catalogs
    
    # Install operators
    install_operators
    
    # Deploy custom resources
    deploy_custom_resources
    
    log_success "========================================="
    log_success "CyberFraud Deployment Complete!"
    log_success "========================================="
    log_info ""
    log_info "Next Steps:"
    log_info "1. Configure your LDAP provider in the CyberFraud deployment"
    log_info "2. Once LDAP is configured, run the accountSetup action to onboard the user specified"
    log_info ""
    log_info "Log file: ${log_file}"
}

function account_setup() {
    log_info "========================================="
    log_info "Starting CyberFraud Account Setup"
    log_info "========================================="
        

    ## check namespace 
    setup_namespace "${namespace}"
    # Deploy CyberfraudAccount CR
    deploy_cyberfraud_account_cr
    
    # Wait for account to be ready
    wait_for_account_ready
    
    log_success "========================================="
    log_success "CyberFraud Account Setup Completed!"
    log_success "========================================="
    log_info "Account '${accountName}' has been successfully created"
    log_info "User '${accountUser}' has been onboarded"
    log_info "Log file: ${log_file}"
}

# ----- UPGRADE FUNCTION -----

function upgrade() {
    log_info "========================================="
    log_info "Starting CyberFraud Upgrade"
    log_info "========================================="

    # Select config file based on deployment type
    if [[ "${linuxDeployment}" -eq 1 ]]; then
        configFile="${linuxConfigFile}"
        log_info "Non-OCP environment detected, using config file: ${configFile}"
    else
        configFile="${defaultConfigFile}"
        log_info "OpenShift environment detected, using config file: ${configFile}"
    fi

    validate_parameters

    # Verify IBM Cyber Fraud is installed before attempting upgrade
    local cr_name
    cr_name=$($kubernetesCLI get cyberfrauddeployment -n "${namespace}" \
        -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [[ -z "${cr_name}" ]]; then
        err_exit "No IBM Cyber Fraud installation found in namespace ${namespace}. Please run the install action first."
    fi

    local current_csv
    current_csv=$($kubernetesCLI get csv -n "${namespace}" 2>/dev/null \
        | grep "ibm-cyberfraud-operator" | awk '{print $1}' | head -1)
    if [[ -z "${current_csv}" ]]; then
        err_exit "No IBM Cyber Fraud ClusterServiceVersion found in namespace ${namespace}. Please run the install action first."
    fi
    log_info "Current IBM Cyber Fraud ClusterServiceVersion: ${current_csv}"

    # Patch the CR registry fields when dev is set.
    if [[ "${dev}" -eq 1 ]]; then
        setup_registry_credentials

        log_info "Updating IBM Cyber Fraud deployment registry configuration..."
        set_repository_mod
        local upgradeRegistry
        local upgradeServiceabilityRegistry
        if [[ "${airgapInstall}" == "true" ]]; then
            upgradeRegistry="${registry}/${cpBaseRegistryPath}"
            upgradeServiceabilityRegistry="${registry}/${cpOpenBaseRegistryPath}"
        else
            upgradeRegistry="icr.io/${cpBaseRegistryPath}"
            upgradeServiceabilityRegistry="icr.io/${cpOpenBaseRegistryPath}"
        fi
        if ! $kubernetesCLI patch cyberfrauddeployment "${cr_name}" -n "${namespace}" \
            --type=merge \
            -p "{\"spec\":{\"basicDeploymentConfiguration\":{\"repository\":\"${upgradeRegistry}\"},\"extendedProperties\":[\"serviceability.repository=${upgradeServiceabilityRegistry}\"]}}"; then
            err_exit "Failed to patch CyberfraudDeployment for dev upgrade"
        fi
        log_success "CyberfraudDeployment updated for dev upgrade"
    fi

    # Update the catalog source image to the new version
    log_info "Updating IBM Cyber Fraud catalog source..."
    update_catalog_source "cyberfraud"
    wait_for_catalog_ready "cyberfraud"

    # Wait for OLM to install the replacement CSV
    wait_for_upgraded_csv "ibm-cyberfraud-operator" "${current_csv}"

    # Wait for the CyberfraudDeployment CR to complete reconciliation
    log_info "Waiting for IBM Cyber Fraud upgrade to complete..."
    wait_for_deployment_upgrade

    log_success "========================================="
    log_success "IBM Cyber Fraud Upgrade Complete!"
    log_success "========================================="
    log_info "Log file: ${log_file}"
}

function update_catalog_source() {
    local catalog_source_name="$1"
    log_info "Updating catalog source image for ${catalog_source_name}"

    local catSrcFile="${casePath}/inventory/${inventory}/files/op-olm/${catalog_source_name}CatalogSource.yaml"
    validate_file_exists "${catSrcFile}"

    set_repository_mod
    if [[ "${airgapInstall}" == "true" ]]; then
        repositoryMod="${registry}/${cpOpenBaseRegistryPath}"
    else
        repositoryMod="icr.io/${cpOpenBaseRegistryPath}"
    fi

    local catSrcImgOriginal
    catSrcImgOriginal=$(grep "image:" "${catSrcFile}" | awk '{print $2}')
    local ogImgName="${catSrcImgOriginal##*/}"
    local ogImgBaseName="${ogImgName%:*}"
    
    # Use --catalogSrcTag override if provided, otherwise use the tag from the YAML
    local catSrcImage
    if [[ -n "${catalogSrcTag}" ]]; then
        catSrcImage="${repositoryMod}/${ogImgBaseName}:${catalogSrcTag}"
    else
        catSrcImage="${repositoryMod}/${ogImgName}"
    fi

    log_info "Patching catalog source image to: ${catSrcImage}"
    if ! $kubernetesCLI patch catalogsource "ibm-cyberfraud-release-catalog" \
        -n "${catalogNamespace}" \
        --type=merge \
        -p "{\"spec\":{\"image\":\"${catSrcImage}\"}}"; then
        err_exit "Failed to patch catalog source image in ${catalogNamespace} namespace"
    fi
    log_success "Catalog source image updated"
}

function wait_for_upgraded_csv() {
    local operatorName="$1"
    local previous_csv="$2"
    local timeout=300
    local elapsed=0

    log_info "Waiting for IBM Cyber Fraud ClusterServiceVersion to be replaced..."

    while [ $elapsed -lt $timeout ]; do
        local csv
        csv=$($kubernetesCLI get csv -n "${namespace}" 2>/dev/null \
            | grep "${operatorName}" | awk '{print $1}' | head -1)

        if [[ -n "${csv}" ]] && [[ "${csv}" != "${previous_csv}" ]]; then
            local phase
            phase=$($kubernetesCLI get csv "${csv}" -n "${namespace}" \
                -o jsonpath='{.status.phase}' 2>/dev/null)

            if [[ "${phase}" == "Succeeded" ]]; then
                log_success "IBM Cyber Fraud ClusterServiceVersion ${csv} installed successfully"
                return 0
            fi

            log_info "IBM Cyber Fraud ClusterServiceVersion ${csv} installing... (${elapsed}s elapsed)"
        else
            log_info "Waiting for new IBM Cyber Fraud ClusterServiceVersion to be installed... (${elapsed}s elapsed)"
        fi

        sleep 10
        elapsed=$((elapsed + 10))
    done

    err_exit "Timed out waiting for IBM Cyber Fraud upgrade to complete."
}

function wait_for_deployment_upgrade() {
    local timeout=3600
    local elapsed=0
    local reconciling=0

    log_info "Waiting for IBM Cyber Fraud upgrade to complete..."

    while [ $elapsed -lt $timeout ]; do
        local status
        status=$($kubernetesCLI get cyberfrauddeployment -n "${namespace}" \
            -o jsonpath='{.items[0].status.conditions[0].type}' 2>/dev/null || echo "")
        local message
        message=$($kubernetesCLI get cyberfrauddeployment -n "${namespace}" \
            -o jsonpath='{.items[0].status.conditions[0].message}' 2>/dev/null || echo "")

        if [[ "${status}" != "Success" ]]; then
            reconciling=1
            if [[ -n "${status}" ]]; then
                log_info "Status: ${status} - ${message}"
            fi
        elif [[ "${reconciling}" -eq 1 ]]; then
            log_success "IBM Cyber Fraud upgrade is complete"
            return 0
        fi

        sleep 30
        elapsed=$((elapsed + 30))
    done

    err_exit "Timed out waiting for IBM Cyber Fraud upgrade to complete. Check the cluster for errors and try again."
}

# ----- UNINSTALL FUNCTION -----

function uninstall() {
    local scriptFile="${scriptDir}/support/uninstall.sh"
    validate_file_exists "${scriptFile}"
    local uninstall_args="--namespace ${namespace}"
    if [[ $force -eq 1 ]]; then
        uninstall_args="${uninstall_args} --force"
    fi
    run "${scriptFile} ${uninstall_args}" "Uninstall CyberFraud in ${namespace} namespace"
}

# ----- VALIDATE FUNCTION -----

function validate() {
    local scriptFile="${scriptDir}/support/validate.sh"
    validate_file_exists "${scriptFile}"
    run "${scriptFile} --namespace ${namespace}" "CyberFraud validation"
}

# ----- ACTION DISPATCHER -----

run_action() {
    log_info "Executing inventory item ${inventory}, action ${action}"
    case $action in
    install)
        install
        ;;
    upgrade)
        upgrade
        ;;
    accountSetup)
        account_setup
        ;;
    clusterInstall)
        linuxDeployment=1
        install_k3s_cluster
        ;;
    linuxMirror)
        linuxMirror=1
        linuxMirror_nonocp
        ;;
    uninstall)
        uninstall
        ;;
    validate)
        validate
        ;;
    *)
        log_error "Invalid Action ${action}"
        log_error "Supported actions: install, accountSetup, clusterInstall, uninstall, validate, linuxMirror"
        exit 1
        ;;
    esac
}

# ----- CUSTOM ARGUMENT PARSER -----

parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --accountName)
        accountName="$val"
        ;;
    --accountUser)
        accountUser="$val"
        ;;
    --piiDisabled)
        piiDisabled="$val"
        ;;
    --catalogSrcTag)
        catalogSrcTag="$val"
        ;;
    --dev)
        dev=1
        ;;
    --force)
        force=1
        ;;
    --linuxDeployment)
        linuxDeployment=1
        ;;
    --skipCredsValidation)
        skipCredsValidation=1
        ;;

    esac
}
