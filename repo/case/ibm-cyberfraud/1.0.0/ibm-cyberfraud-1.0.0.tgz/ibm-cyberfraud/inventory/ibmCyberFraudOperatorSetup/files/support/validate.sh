#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2026. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

kubernetesCLI=oc
namespace=""

## This function returns the route of cyberfraud
function get_route() {
    ROUTE="$($kubernetesCLI get route cf --no-headers -n $namespace 2>/dev/null | awk '{print $2}')"
    echo "$ROUTE"
}

### This function checks the status of the CyberfraudDeployment CR
function check_deployment_status() {
    CR=$($kubernetesCLI get cyberfrauddeployment -n $namespace -o name 2>/dev/null | head -1)

    [[ -z $CR ]] && {
        printf "CyberFraud Deployment CR is not deployed, exiting\n"
        exit 1
    }

    DEPLOYMENT_STATUS=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{.status.conditions[0].type}' 2>/dev/null)

    if [[ $DEPLOYMENT_STATUS != "Success" ]]; then
        maxRetry=100

        printf "%s\n" "[INFO] CyberFraud deployment is $DEPLOYMENT_STATUS"
        for ((retry = 0; retry <= maxRetry; retry++)); do
            TIME=$(date "+%Y/%m/%d-%H:%M:%S")
            DEPLOYMENT_STATUS_MESSAGE=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{.status.conditions[0].message}' 2>/dev/null)
            DEPLOYMENT_STATUS=$($kubernetesCLI get $CR -n $namespace -o jsonpath='{.status.conditions[0].type}' 2>/dev/null)
            
            if [[ $DEPLOYMENT_STATUS == "Success" ]]; then
                cyberfraud_route=$(get_route)
                printf "\n---------------------------------------------------------------------\n"
                printf "%s\n" "$TIME: [SUCCESS] CyberFraud deployment is complete."
                if [[ -n "$cyberfraud_route" ]]; then
                    printf "%s\n" "$TIME: [INFO] Your CyberFraud console is available at: https://$cyberfraud_route"
                fi
                break
            elif [[ "${DEPLOYMENT_STATUS}" == "Degraded" ]]; then
                cyberfraud_route=$(get_route)
                printf "\n---------------------------------------------------------------------\n"
                printf "${TIME}:[WARN] CyberFraud deployment is complete but some components may be degraded.\n"
                printf "${TIME}:[INFO] Message: ${DEPLOYMENT_STATUS_MESSAGE}\n"
                if [[ -n "$cyberfraud_route" ]]; then
                    printf "${TIME}:[INFO] Your CyberFraud console is available at: https://${cyberfraud_route}\n"
                fi
                break
            else
                printf "\n------------------------------------------------------------\n"
                printf "%s\n" "$TIME:[INFO] $DEPLOYMENT_STATUS_MESSAGE"
                printf "%s\n" "$TIME:[INFO] Status: $DEPLOYMENT_STATUS"
                sleep 30
            fi

            if [ ${retry} -eq ${maxRetry} ]; then
                printf "${TIME}:[ERROR] Timed out waiting for CyberFraud deployment to complete\n"
                exit 1
            fi
        done
    else
        cyberfraud_route=$(get_route)
        printf "[SUCCESS] CyberFraud deployment is complete.\n"
        if [[ -n "$cyberfraud_route" ]]; then
            printf "[INFO] Your CyberFraud console is available at: https://$cyberfraud_route\n"
        fi
    fi
}

### This function checks the status of the CyberfraudAccount CR
function check_account_status() {
    local max_wait_time=1800  # 30 minutes in seconds
    local check_interval=10   # Check every 10 seconds
    local elapsed_time=0
    local start_time=$(date +%s)

    printf "[INFO] Checking CyberFraud Account status (will retry for up to 30 minutes)...\n"

    while [ $elapsed_time -lt $max_wait_time ]; do
        ACCOUNT_CR=$($kubernetesCLI get cyberfraudaccount -n $namespace -o name 2>/dev/null | head -1)

        if [[ -z $ACCOUNT_CR ]]; then
            printf "[INFO] CyberFraud Account CR is not deployed (elapsed: ${elapsed_time}s)\n"
            return 0
        fi

        ACCOUNT_STATUS=$($kubernetesCLI get $ACCOUNT_CR -n $namespace -o jsonpath='{.status.conditions[0].type}' 2>/dev/null)
        ACCOUNT_MESSAGE=$($kubernetesCLI get $ACCOUNT_CR -n $namespace -o jsonpath='{.status.conditions[0].message}' 2>/dev/null)

        if [[ $ACCOUNT_STATUS == "Success" ]]; then
            printf "[SUCCESS] CyberFraud Account is ready (elapsed: ${elapsed_time}s)\n"
            return 0
        elif [[ $ACCOUNT_STATUS == "Error" ]]; then
            printf "[ERROR] CyberFraud Account failed: $ACCOUNT_MESSAGE (elapsed: ${elapsed_time}s)\n"
            return 1
        else
            printf "[INFO] CyberFraud Account status: $ACCOUNT_STATUS - $ACCOUNT_MESSAGE (elapsed: ${elapsed_time}s, retrying...)\n"
        fi

        # Wait before next check
        sleep $check_interval
        
        # Update elapsed time
        local current_time=$(date +%s)
        elapsed_time=$((current_time - start_time))
    done

    # Timeout reached
    printf "[ERROR] Timeout: CyberFraud Account did not reach Success status after 30 minutes\n"
    printf "[ERROR] Last status: $ACCOUNT_STATUS - $ACCOUNT_MESSAGE\n"
    return 1
}

### Main validation function
function validate_installation() {
    echo "========================================="
    echo "Validating CyberFraud Installation"
    echo "========================================="
    
    # Check namespace
    if ! $kubernetesCLI get namespace "$namespace" &>/dev/null; then
        echo "[ERROR] Namespace $namespace does not exist"
        exit 1
    fi
    echo "[SUCCESS] Namespace $namespace exists"
    
    # Check CyberfraudDeployment CR
    check_deployment_status
    
    # Check CyberfraudAccount CR
    check_account_status
    
    echo "========================================="
    echo "[SUCCESS] Validation completed"
    echo "========================================="
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    key="$1"
    case $key in
        --namespace)
            namespace="$2"
            shift
            shift
            ;;
        *)
            echo "[ERROR] Unknown option: $1"
            echo "Usage: $0 --namespace <NAMESPACE>"
            exit 1
            ;;
    esac
done

# Validate namespace parameter
if [[ -z "$namespace" ]]; then
    echo "[ERROR] Namespace parameter is required"
    echo "Usage: $0 --namespace <NAMESPACE>"
    exit 1
fi

# Run validation
validate_installation