#!/bin/bash
# (C) Copyright IBM Corp. 2026  All Rights Reserved.
#
# This script installs k3s on customer Linux environment for CyberFraud deployment
# Supports HA multi-node deployments (N masters + N workers)
# Runs from a remote control machine via SSH

set -e

# ----- HELPER FUNCTIONS -----

function log_info() {
    echo "[INFO] $1"
}

function log_success() {
    echo "[SUCCESS] $1"
}

function log_warning() {
    echo "[WARNING] $1"
}

function log_error() {
    echo "[ERROR] $1"
}

function err_exit() {
    log_error "$1"
    exit 1
}

function validate_hostname_resolution() {
    local host="${1}"
    local password="${2}"
    
    log_info "Validating SSH connectivity and hostname resolution for ${host}..."
    
    # Temporarily disable exit on error to capture SSH output
    set +e
    
    # Capture SSH error output with retry logic
    local ssh_error
    local ssh_exit_code
    local max_retries=3
    local retry_count=0
    
    while [ ${retry_count} -lt ${max_retries} ]; do
        ssh_error=$(sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
            -o PubkeyAuthentication=no -o LogLevel=ERROR \
            -o ConnectTimeout=10 -o ConnectionAttempts=2 \
            root@"${host}" "echo 'SSH test successful'" 2>&1)
        ssh_exit_code=$?
        
        if [ ${ssh_exit_code} -eq 0 ]; then
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ ${retry_count} -lt ${max_retries} ]; then
            log_warning "SSH connection attempt ${retry_count} failed, retrying in 2 seconds..."
            sleep 2
        fi
    done
    
    # Re-enable exit on error
    set -e
    
    # Test SSH connectivity with a simple command - this will fail if hostname cannot be resolved by SSH
    if [ ${ssh_exit_code} -ne 0 ]; then
        log_error "SSH connection to ${host} failed after ${max_retries} attempts"
        log_error "SSH error output: ${ssh_error}"
        
        # If SSH fails, try basic hostname resolution to provide better error message
        if ! getent hosts "${host}" &> /dev/null && ! ping -c 1 -W 2 "${host}" &> /dev/null; then
            err_exit "Cannot resolve hostname: ${host}. Please check DNS configuration or add entry to /etc/hosts file."
        else
            err_exit "Hostname ${host} resolves locally but SSH cannot connect."
        fi
    fi
    
    log_success "SSH connectivity to ${host} verified successfully"
}

# ----- K3S INSTALLATION FUNCTIONS -----

function check_k3s_installed() {
    local host="${1}"
    local password="${2}"
    local max_retries=3
    local retry_delay=3
    
    log_info "Checking if k3s is already installed on ${host}..."
    
    # Temporarily disable exit on error
    set +e
    
    local retry_count=0
    local ssh_exit_code=255
    
    # Try to check if k3s is installed with retry logic
    while [ ${retry_count} -lt ${max_retries} ]; do
        sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
            -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
            -o ConnectTimeout=10 -o ConnectionAttempts=2 -o ServerAliveInterval=10 \
            root@"${host}" "command -v k3s &> /dev/null"
        ssh_exit_code=$?
        
        # Exit code 0 means k3s command exists (installed)
        # Exit code 1 means k3s command not found (not installed)
        # Exit code 255 or other means SSH connection failed
        if [ ${ssh_exit_code} -eq 0 ] || [ ${ssh_exit_code} -eq 1 ]; then
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ ${retry_count} -lt ${max_retries} ]; then
            log_warning "SSH connection failed when checking k3s on ${host} (attempt ${retry_count}/${max_retries}), retrying in ${retry_delay} seconds..."
            sleep ${retry_delay}
        fi
    done
    
    # Re-enable exit on error
    set -e
    
    if [ ${ssh_exit_code} -eq 0 ]; then
        log_info "k3s is already installed on ${host}"
        return 0
    elif [ ${ssh_exit_code} -eq 1 ]; then
        log_info "k3s is not installed on ${host}"
        return 1
    else
        log_error "SSH connection failed when checking k3s on ${host} after ${max_retries} attempts (exit code: ${ssh_exit_code})"
        err_exit "Failed to connect to ${host}. Please verify SSH connectivity."
    fi
}

function download_k3s_artifacts() {
    local version="${1:-v1.32.12+k3s1}"
    local arch="${2:-amd64}"
    
    log_info "Downloading k3s artifacts for version ${version}..."
    
    # Determine download tool (curl or wget)
    local download_cmd=""
    if command -v curl &> /dev/null; then
        download_cmd="curl"
    elif command -v wget &> /dev/null; then
        download_cmd="wget"
    else
        err_exit "Neither curl nor wget found. Please install one of them."
    fi
    log_info "Using ${download_cmd} for downloads"
    
    # Create artifact directories
    mkdir -p "${K3S_ARTIFACT_DIR}" || err_exit "Failed to create ${K3S_ARTIFACT_DIR}"
    mkdir -p "${K3S_SELINUX_DIR}" || err_exit "Failed to create ${K3S_SELINUX_DIR}"
    
    # Download k3s binary if not exists
    if [ ! -f "${K3S_ARTIFACT_DIR}/k3s" ]; then
        log_info "Downloading k3s binary..."
        if [ "${download_cmd}" = "curl" ]; then
            if ! curl -L --progress-bar \
                "https://github.com/k3s-io/k3s/releases/download/${version}/k3s" \
                -o "${K3S_ARTIFACT_DIR}/k3s"; then
                err_exit "Failed to download k3s binary"
            fi
        else
            if ! wget -q --show-progress \
                "https://github.com/k3s-io/k3s/releases/download/${version}/k3s" \
                -O "${K3S_ARTIFACT_DIR}/k3s"; then
                err_exit "Failed to download k3s binary"
            fi
        fi
        chmod +x "${K3S_ARTIFACT_DIR}/k3s"
        log_success "Downloaded k3s binary"
    else
        log_info "k3s binary already exists"
    fi
    
    # Download SHA256 hash if not exists
    if [ ! -f "${K3S_ARTIFACT_DIR}/sha256sum-amd64.txt" ]; then
        log_info "Downloading SHA256 hash..."
        if [ "${download_cmd}" = "curl" ]; then
            if ! curl -L --progress-bar \
                "https://github.com/k3s-io/k3s/releases/download/${version}/sha256sum-amd64.txt" \
                -o "${K3S_ARTIFACT_DIR}/sha256sum-amd64.txt"; then
                err_exit "Failed to download SHA256 hash"
            fi
        else
            if ! wget -q --show-progress \
                "https://github.com/k3s-io/k3s/releases/download/${version}/sha256sum-amd64.txt" \
                -O "${K3S_ARTIFACT_DIR}/sha256sum-amd64.txt"; then
                err_exit "Failed to download SHA256 hash"
            fi
        fi
        log_success "Downloaded SHA256 hash"
    else
        log_info "SHA256 hash already exists"
    fi
    
    log_success "All artifacts downloaded"
}

function stage_k3s_artifacts() {
    local host="$1"
    local password="$2"
    local max_retries=3
    local retry_delay=3
    
    log_info "Staging artifacts on ${host}..."
    
    # Create remote directories first with retry logic
    local retry_count=0
    local mkdir_success=false
    
    while [ ${retry_count} -lt ${max_retries} ]; do
        if sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
            -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
            -o ConnectionAttempts=3 -o ConnectTimeout=10 \
            root@"${host}" "mkdir -p ${K3S_ARTIFACT_DIR} ${K3S_SELINUX_DIR}"; then
            mkdir_success=true
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ ${retry_count} -lt ${max_retries} ]; then
            log_warning "Failed to create directories on ${host} (attempt ${retry_count}/${max_retries}), retrying in ${retry_delay} seconds..."
            sleep ${retry_delay}
        fi
    done
    
    if [ "${mkdir_success}" = false ]; then
        err_exit "Failed to create directories on ${host}"
    fi
    
    # Copy all files in a single SCP command using ControlMaster for connection reuse
    local configure_script="${SCRIPT_DIR}/configure_k3s.sh"
    local ssh_control_path="/tmp/ssh-k3s-${host}-$$"
    
    # Use ControlMaster to reuse SSH connection for multiple file transfers with retry logic
    retry_count=0
    local scp_success=false
    
    while [ ${retry_count} -lt ${max_retries} ]; do
        if sshpass -p "${password}" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
            -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
            -o ControlMaster=auto -o ControlPath="${ssh_control_path}" -o ControlPersist=60s \
            -o ConnectionAttempts=3 -o ConnectTimeout=10 \
            "${K3S_ARTIFACT_DIR}/k3s" \
            "${K3S_ARTIFACT_DIR}/sha256sum-amd64.txt" \
            "${configure_script}" \
            root@"${host}:/tmp/"; then
            scp_success=true
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ ${retry_count} -lt ${max_retries} ]; then
            log_warning "Failed to copy artifacts to ${host} (attempt ${retry_count}/${max_retries}), retrying in ${retry_delay} seconds..."
            # Clean up control socket before retry
            rm -f "${ssh_control_path}"
            sleep ${retry_delay}
        fi
    done
    
    if [ "${scp_success}" = false ]; then
        # Clean up control socket on failure
        rm -f "${ssh_control_path}"
        err_exit "Failed to copy artifacts to ${host}"
    fi
    
    # Move files to correct locations in a single SSH command with retry logic
    retry_count=0
    local mv_success=false
    
    while [ ${retry_count} -lt ${max_retries} ]; do
        if sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
            -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
            -o ControlMaster=auto -o ControlPath="${ssh_control_path}" -o ControlPersist=60s \
            root@"${host}" "mv /tmp/k3s ${K3S_ARTIFACT_DIR}/ && mv /tmp/sha256sum-amd64.txt ${K3S_ARTIFACT_DIR}/ && mv /tmp/configure_k3s.sh /root/"; then
            mv_success=true
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ ${retry_count} -lt ${max_retries} ]; then
            log_warning "Failed to move artifacts on ${host} (attempt ${retry_count}/${max_retries}), retrying in ${retry_delay} seconds..."
            sleep ${retry_delay}
        fi
    done
    
    if [ "${mv_success}" = false ]; then
        rm -f "${ssh_control_path}"
        err_exit "Failed to move artifacts on ${host}"
    fi
    
    # Clean up control socket
    rm -f "${ssh_control_path}"
    
    log_success "Artifacts staged on ${host}"
}

function cleanup_remote_artifacts() {
    local host="$1"
    local password="$2"
    
    log_info "Cleaning up installation artifacts on ${host}..."
    
    # Add small delay before cleanup to avoid rapid successive connections
    sleep 1
    
    sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
        -o ConnectTimeout=10 -o ConnectionAttempts=2 \
        root@"${host}" "rm -f /root/configure_k3s.sh" 2>/dev/null || true
    
    log_info "Cleanup completed on ${host}"
}

function install_binaries_on_node() {
    local host="$1"
    local password="$2"
    local oc_version="${OC_VERSION:-4.17.0}"
    local max_retries=3
    local retry_delay=3
    
    log_info "Installing required binaries on ${host}..."
    
    local retry_count=0
    local install_success=false
    
    while [ ${retry_count} -lt ${max_retries} ]; do
        if sshpass -p "${password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
            -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
            -o ConnectTimeout=10 -o ConnectionAttempts=2 \
            root@"${host}" << EOF
set -e

echo "--------------------------------------------------"
echo "[INFO] Identifying the OS..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=\$ID
    VERSION_OS=\$VERSION_ID
    echo "[INFO] Working in [ \$OS ] system."
else
    echo "[ERROR] Cannot determine the OS."
    exit 1
fi

install_package() {
    local package=\$1
    echo "[INFO] Installing \${package}..."
    case "\${OS}" in
        ubuntu | debian)
            sudo apt-get update -y > /dev/null 2>&1
            sudo apt-get install -y \${package} > /dev/null 2>&1
            ;;
        rhel | centos | fedora)
            sudo yum install -y \${package} > /dev/null 2>&1
            ;;
        sles)
            sudo zypper install -y \${package} > /dev/null 2>&1
            ;;
        *)
            echo "[ERROR] Unknown Distro \${OS}"
            return 1
            ;;
    esac
    return \$?
}

if ! command -v wget &> /dev/null; then
    if ! install_package wget; then
        echo "[ERROR] Failed to install wget"
        exit 1
    fi
fi

echo "--------------------------------------------------"
echo "[INFO] Installing binaries for \$OS system."
echo "--------------------------------------------------"

echo ""
echo "Installing JQ..."
if ! command -v jq &> /dev/null; then
    if ! install_package jq; then
        echo "[ERROR] Failed to install JQ"
        exit 1
    fi
fi
echo "📣 JQ version = \$(jq --version)"

echo ""
echo "Installing OC and kubectl... version ${oc_version}"
if ! command -v oc &> /dev/null; then
    if ! wget -q https://mirror.openshift.com/pub/openshift-v4/x86_64/clients/ocp/${oc_version}/openshift-client-linux.tar.gz; then
        echo "[ERROR] Failed to download OpenShift CLI"
        exit 1
    fi
    tar -xzf openshift-client-linux.tar.gz
    chmod +x oc kubectl
    sudo mv oc kubectl /usr/local/bin/
    rm -f openshift-client-linux.tar.gz README.md
fi
echo "📣 OC version = \$(oc version --client)"
echo "📣 KUBECTL version = \$(kubectl version --client --short 2>/dev/null || kubectl version --client)"

echo ""
echo "--------------------------------------------------"
echo "[INFO] Binary installation completed successfully"
echo "--------------------------------------------------"
EOF
        then
            install_success=true
            break
        fi
        
        retry_count=$((retry_count + 1))
        if [ ${retry_count} -lt ${max_retries} ]; then
            log_warning "Failed to install binaries on ${host} (attempt ${retry_count}/${max_retries}), retrying in ${retry_delay} seconds..."
            sleep ${retry_delay}
        fi
    done
    
    if [ "${install_success}" = true ]; then
        log_success "Binaries installed on ${host}"
        return 0
    else
        log_error "Failed to install binaries on ${host} after ${max_retries} attempts"
        return 1
    fi
}

function install_k3s_multi_node() {
    local master_hosts="$1"  # Comma-separated list
    local worker_hosts="$2"  # Comma-separated list
    local ssh_password="$3"
    local k3s_token="${4:-k3s-cluster-token}"
    
    log_info "========================================="
    log_info "Starting Multi-Node k3s Installation"
    log_info "========================================="
    log_info "Masters: ${master_hosts}"
    log_info "Workers: ${worker_hosts}"
    log_info "Version: ${K3S_VERSION}"
    
    # Parse master hosts into array
    IFS=',' read -ra MASTERS <<< "${master_hosts}"
    local master_count=${#MASTERS[@]}
    local first_master="${MASTERS[0]}"
    first_master=$(echo "${first_master}" | xargs)  # Trim whitespace
    
    log_info "Master count: ${master_count}"
    log_info "First master: ${first_master}"
    
    # Download artifacts locally first
    download_k3s_artifacts "${K3S_VERSION}" "amd64"
    
    # Install binaries only on first master node
    log_info "Installing binaries on first master node (${first_master})..."
    install_binaries_on_node "${first_master}" "${ssh_password}"
    
    # Stage artifacts on all master nodes with delay between nodes
    log_info "Staging artifacts on all master nodes..."
    for master in "${MASTERS[@]}"; do
        master=$(echo "${master}" | xargs)  # Trim whitespace
        stage_k3s_artifacts "${master}" "${ssh_password}"
        # Small delay between nodes to avoid overwhelming SSH server
        sleep 2
    done
    
    # Stage artifacts on all worker nodes (no binaries)
    if [ -n "${worker_hosts}" ]; then
        log_info "Staging artifacts on all worker nodes..."
        IFS=',' read -ra WORKERS <<< "${worker_hosts}"
        for worker in "${WORKERS[@]}"; do
            worker=$(echo "${worker}" | xargs)  # Trim whitespace
            stage_k3s_artifacts "${worker}" "${ssh_password}"
            # Small delay between nodes to avoid overwhelming SSH server
            sleep 2
        done
    fi
    
    # Install master nodes
    local master_index=1
    for master in "${MASTERS[@]}"; do
        master=$(echo "${master}" | xargs)  # Trim whitespace
        
        if [ ${master_index} -eq 1 ]; then
            # First master: Initialize cluster with --cluster-init
            log_info "=========================================="
            log_info "  Installing K3s Master Node ${master_index}/${master_count}"
            log_info "  Host: ${master}"
            log_info "  Role: Cluster Initializer"
            log_info "=========================================="
            
            if sshpass -p "${ssh_password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
                -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
                root@"${master}" << EOF
set -e
chmod +x /root/configure_k3s.sh
INSTALL_K3S_VERSION="${K3S_VERSION}" \
INSTALL_K3S_EXEC="server --cluster-init --disable traefik --tls-san ${master}" \
K3S_TOKEN="${k3s_token}" \
INSTALL_K3S_SKIP_DOWNLOAD="true" \
INSTALL_K3S_ARTIFACT_DIR="${K3S_ARTIFACT_DIR}" \
bash /root/configure_k3s.sh

sleep 30
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
kubectl wait --for=condition=Ready node/"${master}" --timeout=600s || {
    echo "Node ${master} is not in Ready state"
    exit 1
}
echo "Master node ${master_index} ready"
EOF
            then
                log_success "Master node ${master_index} installed successfully"
                cleanup_remote_artifacts "${master}" "${ssh_password}"
            else
                log_error "Master node ${master_index} installation failed"
                cleanup_remote_artifacts "${master}" "${ssh_password}"
                err_exit "Failed to install first master node"
            fi
            
        else
            # Additional masters: Join the first master
            log_info "=========================================="
            log_info "  Installing K3s Master Node ${master_index}/${master_count}"
            log_info "  Host: ${master}"
            log_info "  Role: Additional Master (joining ${first_master})"
            log_info "=========================================="
            
            if sshpass -p "${ssh_password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
                -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
                root@"${master}" << EOF
set -e
chmod +x /root/configure_k3s.sh
INSTALL_K3S_VERSION="${K3S_VERSION}" \
INSTALL_K3S_EXEC="server --disable traefik --tls-san ${master}" \
K3S_TOKEN="${k3s_token}" \
K3S_URL="https://${first_master}:6443" \
INSTALL_K3S_SKIP_DOWNLOAD="true" \
INSTALL_K3S_ARTIFACT_DIR="${K3S_ARTIFACT_DIR}" \
bash /root/configure_k3s.sh

sleep 30
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
kubectl wait --for=condition=Ready node/"${master}" --timeout=600s || {
    echo "Node ${master} is not in Ready state"
    exit 1
}
echo "Master node ${master_index} ready"
EOF
            then
                log_success "Master node ${master_index} installed successfully"
                cleanup_remote_artifacts "${master}" "${ssh_password}"
            else
                log_error "Master node ${master_index} installation failed"
                cleanup_remote_artifacts "${master}" "${ssh_password}"
                err_exit "Failed to install master node ${master_index}"
            fi
        fi
        
        master_index=$((master_index + 1))
    done
    
    log_success "All ${master_count} master nodes installed successfully"
    
    # Install worker nodes
    if [ -n "${worker_hosts}" ]; then
        IFS=',' read -ra WORKERS <<< "${worker_hosts}"
        local worker_count=${#WORKERS[@]}
        local worker_index=1
        
        for worker in "${WORKERS[@]}"; do
            worker=$(echo "${worker}" | xargs)  # Trim whitespace
            
            log_info "=========================================="
            log_info "  Installing K3s Worker Node ${worker_index}/${worker_count}"
            log_info "  Host: ${worker}"
            log_info "=========================================="
            
            if sshpass -p "${ssh_password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
                -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
                root@"${worker}" << EOF
set -e
chmod +x /root/configure_k3s.sh
INSTALL_K3S_VERSION="${K3S_VERSION}" \
INSTALL_K3S_EXEC="agent" \
K3S_TOKEN="${k3s_token}" \
K3S_URL="https://${first_master}:6443" \
INSTALL_K3S_SKIP_DOWNLOAD="true" \
INSTALL_K3S_ARTIFACT_DIR="${K3S_ARTIFACT_DIR}" \
bash /root/configure_k3s.sh

sleep 30
echo "Worker node ${worker_index} installed"
EOF
            then
                log_success "Worker node ${worker_index} installed successfully"
                cleanup_remote_artifacts "${worker}" "${ssh_password}"
            else
                log_error "Worker node ${worker_index} installation failed"
                cleanup_remote_artifacts "${worker}" "${ssh_password}"
                log_warning "Continuing with remaining workers..."
            fi
            
            worker_index=$((worker_index + 1))
        done
        
        log_success "All ${worker_count} worker nodes installed successfully"
    fi
    
    # Verify all nodes are ready
    log_info "=========================================="
    log_info "  Verifying K3s Cluster"
    log_info "=========================================="
    
    sshpass -p "${ssh_password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
        root@"${first_master}" << 'EOF'
set -e
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

timeout=300
interval=10
elapsed=0

echo "Checking K3s node readiness (timeout: ${timeout}s)..."

while true; do
    not_ready_count=$(kubectl get nodes --no-headers 2>/dev/null | awk '$2 != "Ready" {count++} END {print count+0}')
    
    if [[ "$not_ready_count" -eq 0 ]]; then
        echo "All nodes are Ready"
        kubectl get nodes
        exit 0
    fi
    
    if [[ "$elapsed" -ge "$timeout" ]]; then
        echo "Timeout reached - Some nodes are still NotReady"
        kubectl get nodes
        exit 1
    fi
    
    echo "Waiting... (${elapsed}s elapsed)"
    sleep "$interval"
    elapsed=$((elapsed + interval))
done
EOF
    
    log_success "========================================="
    log_success "Multi-Node k3s Cluster Installed!"
    log_success "Masters: ${master_count}"
    if [ -n "${worker_hosts}" ]; then
        IFS=',' read -ra WORKERS <<< "${worker_hosts}"
        log_success "Workers: ${#WORKERS[@]}"
    else
        log_success "Workers: 0"
    fi
    log_success "========================================="
}

# ----- MAIN EXECUTION -----

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Define artifact directories in /tmp (user-writable)
K3S_ARTIFACT_DIR="/tmp/k3s-artifacts"
K3S_SELINUX_DIR="/tmp/k3s-selinux"

# Set default values from environment variables
K3S_VERSION="${K3S_VERSION:-v1.28.5+k3s1}"
K3S_MASTER_HOSTS="${K3S_MASTER_HOSTS:-}"
K3S_WORKER_HOSTS="${K3S_WORKER_HOSTS:-}"
K3S_SSH_PASSWORD="${K3S_SSH_PASSWORD:-}"
K3S_TOKEN="${K3S_TOKEN:-k3s-cluster-token}"
OC_VERSION="${OC_VERSION:-4.17.0}"

log_info "========================================="
log_info "k3s Installation Script for CyberFraud"
log_info "Version: ${K3S_VERSION}"
log_info "Mode: Multi-Node"
log_info "========================================="

# Check for sshpass before proceeding
if ! command -v sshpass &> /dev/null; then
    err_exit "sshpass is required for k3s installation but not found. Please install sshpass first."
fi
log_info "sshpass found"

# Validate required parameters
if [ -z "${K3S_MASTER_HOSTS}" ]; then
    err_exit "K3S_MASTER_HOSTS must be set for multi-node deployment"
fi

if [ -z "${K3S_SSH_PASSWORD}" ]; then
    err_exit "K3S_SSH_PASSWORD must be set for multi-node deployment"
fi

# Count masters
IFS=',' read -ra MASTERS <<< "${K3S_MASTER_HOSTS}"
master_count=${#MASTERS[@]}

log_info "Multi-node deployment:"
log_info "  Masters: ${master_count} (${K3S_MASTER_HOSTS})"
log_info "  Workers: ${K3S_WORKER_HOSTS:-none}"
log_info "  OC Version: ${OC_VERSION}"

# Validate SSH connectivity and hostname resolution for all hosts before proceeding
log_info "Validating SSH connectivity and hostname resolution for all nodes..."
for master in "${MASTERS[@]}"; do
    master=$(echo "${master}" | xargs)
    validate_hostname_resolution "${master}" "${K3S_SSH_PASSWORD}"
done

if [ -n "${K3S_WORKER_HOSTS}" ]; then
    IFS=',' read -ra WORKERS <<< "${K3S_WORKER_HOSTS}"
    for worker in "${WORKERS[@]}"; do
        worker=$(echo "${worker}" | xargs)
        validate_hostname_resolution "${worker}" "${K3S_SSH_PASSWORD}"
    done
fi
log_success "All nodes are accessible via SSH"

# Check if k3s is already installed on first master
first_master="${MASTERS[0]}"
first_master=$(echo "${first_master}" | xargs)
if check_k3s_installed "${first_master}" "${K3S_SSH_PASSWORD}"; then
    log_info "k3s is already installed on first master node. Skipping installation."
    exit 0
fi

# Install multi-node cluster
install_k3s_multi_node "${K3S_MASTER_HOSTS}" "${K3S_WORKER_HOSTS}" "${K3S_SSH_PASSWORD}" "${K3S_TOKEN}"

log_success "=========================================="
log_success "  K3s Installation Complete!"
log_success "=========================================="

exit 0

