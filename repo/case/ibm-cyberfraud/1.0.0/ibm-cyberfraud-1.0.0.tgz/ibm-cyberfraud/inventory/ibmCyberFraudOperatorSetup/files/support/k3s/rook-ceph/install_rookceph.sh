#!/bin/bash
# (C) Copyright IBM Corp. 2026  All Rights Reserved.
#
# This script installs Rook-Ceph storage on k3s cluster

set -e

# ----- CONFIGURATION -----
# Validate kubernetesCLI variable is set
if [[ -z "${kubernetesCLI}" ]]; then
    echo "[ERROR] kubernetesCLI variable is not set. This script must be called with kubernetesCLI exported."
    exit 1
fi

ROOK_NAMESPACE="rook-ceph"
OPERATOR_TIMEOUT="300s"
CLUSTER_TIMEOUT=300  # seconds (integer for arithmetic operations)
POD_CREATION_TIMEOUT=300  # seconds (integer for arithmetic operations)
POD_READY_TIMEOUT="300s"

## deployment_type default to "demo" if not provided
deployment_type="${1:-demo}"
# ----- HELPER FUNCTIONS -----

function log_info() {
    echo "[INFO] $1"
}

function log_success() {
    echo "[SUCCESS] $1"
}

function log_error() {
    echo "[ERROR] $1"
}

function err_exit() {
    log_error "$1"
    exit 1
}


# ----- WAIT FUNCTIONS -----

wait_for_pods_created() {
    local selector="$1"
    local timeout="$2"
    local elapsed=0
    
    log_info "Waiting for pods with selector: ${selector} to be created..."
    while [ $elapsed -lt $timeout ]; do
        # Filter out canary pods (temporary test pods)
        if $kubernetesCLI -n ${ROOK_NAMESPACE} get pod --selector="${selector}" --no-headers 2>/dev/null | grep -v "canary" | grep -q .; then
            log_success "Pods found for ${selector}"
            return 0
        fi
        sleep 5
        elapsed=$((elapsed + 5))
    done
    
    log_error "Timeout waiting for pods with selector: ${selector} to be created"
    return 1
}

wait_for_ceph_health() {
    local timeout=${CLUSTER_TIMEOUT}
    local elapsed=0
    
    log_info "Waiting for Ceph cluster to become healthy..."
    while [ $elapsed -lt $timeout ]; do
        # Check if toolbox pod is ready
        if $kubernetesCLI -n ${ROOK_NAMESPACE} get pod -l app=rook-ceph-tools --no-headers 2>/dev/null | grep -q "Running"; then
            # Try to get ceph status
            local ceph_status=$($kubernetesCLI -n ${ROOK_NAMESPACE} exec -it deploy/rook-ceph-tools -- ceph status 2>/dev/null | grep "health:" | awk '{print $2}' || echo "")
            if [[ "${ceph_status}" == "HEALTH_OK" ]]; then
                log_success "Ceph cluster is healthy"
                return 0
            fi
        fi
        sleep 10
        elapsed=$((elapsed + 10))
    done
    
    log_error "Timeout waiting for Ceph cluster to become healthy"
    return 1
}

# ----- MAIN INSTALLATION -----

# Check if Rook-Ceph StorageClass already exists
if $kubernetesCLI get sc 2>/dev/null | grep -q 'rook-ceph'; then
    log_info "Rook Ceph StorageClass exists. Skipping installation."
    exit 0
fi

# Check if rook-ceph namespace exists, create if it doesn't
if ! $kubernetesCLI get namespace ${ROOK_NAMESPACE} > /dev/null 2>&1; then
    log_info "Creating ${ROOK_NAMESPACE} namespace..."
    $kubernetesCLI create namespace ${ROOK_NAMESPACE}
    log_success "${ROOK_NAMESPACE} namespace created"
else
    log_info "${ROOK_NAMESPACE} namespace already exists"
fi

log_info "Starting Rook-Ceph installation..."
log_info "Using Kubernetes CLI: ${kubernetesCLI}"

# Create encryption resources BEFORE operator starts (operator reconciles CSI secrets on startup)
log_info "Creating CSI encryption resources"

# Generate encryption passphrase
if $kubernetesCLI get secret rook-csi-encryption-passphrase -n ${ROOK_NAMESPACE} > /dev/null 2>&1; then
    log_info "Secret rook-csi-encryption-passphrase already exists. Skipping creation."
else
    log_info "Generating encryption passphrase secret"
    PASSPHRASE_B64=$(openssl rand -base64 32 | tr -d '\n' | base64 -w 0)
    $kubernetesCLI create secret generic rook-csi-encryption-passphrase -n ${ROOK_NAMESPACE} --from-literal=encryptionPassphrase="$PASSPHRASE_B64"
    log_success "Encryption passphrase secret created"
fi

$kubernetesCLI create configmap rook-ceph-csi-kms-config -n ${ROOK_NAMESPACE} \
  --from-literal=config.json='{"secrets-metadata":{"encryptionKMSType":"metadata","secretName":"rook-csi-encryption-passphrase"}}' \
  --dry-run=client -o yaml | $kubernetesCLI apply -f -

$kubernetesCLI create configmap csi-kms-connection-details -n ${ROOK_NAMESPACE} \
  --from-literal=config.json='{"secrets-metadata":{"encryptionKMSType":"metadata","secretName":"rook-csi-encryption-passphrase"}}' \
  --dry-run=client -o yaml | $kubernetesCLI apply -f -

log_success "CSI encryption resources created"

# Step 1: Apply CRDs, common resources, and operator
log_info "Applying CRDs, common resources, and operator..."
$kubernetesCLI apply -f crds.yaml -f common.yaml -f operator.yaml || {
    log_error "Failed to apply CRDs/operator"
    exit 1
}
log_success "CRDs and operator applied"

# Step 2: Wait for operator to be ready
log_info "Waiting for operator to be ready (timeout: ${OPERATOR_TIMEOUT})..."
if ! $kubernetesCLI -n ${ROOK_NAMESPACE} wait --for=condition=Ready --selector=app=rook-ceph-operator pod --timeout=${OPERATOR_TIMEOUT}; then
    log_error "Operator failed to become ready"
    exit 1
fi
log_success "Operator is ready"

# Step 3: Apply cluster
log_info "Applying Rook-Ceph cluster..."
$kubernetesCLI apply -f "$deployment_type/cluster.yaml" || {
    log_error "Failed to apply cluster"
    exit 1
}
log_success "Cluster resource applied"

# Step 4: Wait for cluster initialization with proper checks
log_info "Waiting for cluster initialization (${CLUSTER_TIMEOUT}s)..."
elapsed=0
while [ $elapsed -lt $CLUSTER_TIMEOUT ]; do
    # Check if any mon pods are starting to appear
    if $kubernetesCLI -n ${ROOK_NAMESPACE} get pods -l app=rook-ceph-mon --no-headers 2>/dev/null | grep -q .; then
        log_info "Cluster initialization in progress..."
        break
    fi
    sleep 5
    elapsed=$((elapsed + 5))
done

if [ $elapsed -ge $CLUSTER_TIMEOUT ]; then
    log_error "Cluster initialization timeout - no mon pods appeared"
    exit 1
fi

# Step 5: Wait for Ceph cluster pods to be ready
log_info "Waiting for Ceph cluster pods to be ready..."

# Track background job PIDs and their selectors
declare -A wait_pids
failed_selectors=()
timeout_selectors=()

# Define pod selectors in order of dependency
selectors=(
    "app=rook-ceph-mon"
    "app=rook-ceph-mgr"
    "app=rook-ceph-osd"
    # "app=csi-cephfsplugin-provisioner"
    "app=csi-rbdplugin-provisioner"
    # "app=csi-cephfsplugin"
    "app=csi-rbdplugin"
)

# Wait for pods to be created first, then wait for them to be ready
for selector in "${selectors[@]}"; do
    if ! wait_for_pods_created "${selector}" ${POD_CREATION_TIMEOUT}; then
        timeout_selectors+=("${selector}")
        continue
    fi
    
    log_info "Waiting for pods with selector: ${selector} to be ready..."
    # Get list of non-canary pods and wait for them specifically
    pod_names=$($kubernetesCLI -n ${ROOK_NAMESPACE} get pod --selector="${selector}" --no-headers 2>/dev/null | grep -v "canary" | awk '{print $1}' | tr '\n' ' ')
    if [ -n "$pod_names" ]; then
        for pod_name in $pod_names; do
            $kubernetesCLI -n ${ROOK_NAMESPACE} wait --for=condition=Ready pod/${pod_name} --timeout=${POD_READY_TIMEOUT} 2>/dev/null || true
        done &
        wait_pids[$!]="${selector}"
    fi
done

# Wait for all background wait commands and check their exit status
log_info "Waiting for all pods to become ready..."
for pid in "${!wait_pids[@]}"; do
    selector="${wait_pids[$pid]}"
    if wait "$pid"; then
        log_success "Pods with selector ${selector} are ready"
    else
        log_error "Failed waiting for pods with selector: ${selector}"
        failed_selectors+=("${selector}")
    fi
done

# Check if any selectors failed or timed out
if [ ${#timeout_selectors[@]} -gt 0 ] || [ ${#failed_selectors[@]} -gt 0 ]; then
    log_error "Rook-Ceph installation failed!"
    if [ ${#timeout_selectors[@]} -gt 0 ]; then
        log_error "Pods never created for selectors: ${timeout_selectors[*]}"
    fi
    if [ ${#failed_selectors[@]} -gt 0 ]; then
        log_error "Pods failed to become ready for selectors: ${failed_selectors[*]}"
    fi
    log_error "Check pod status with: ${kubernetesCLI} -n ${ROOK_NAMESPACE} get pods"
    log_error "Check pod logs for details"
    exit 1
fi

log_success "All Ceph cluster pods are ready"

# Step 6: Apply file system
# log_info "Applying CephFS file system..."
# $kubernetesCLI apply -f production/filesystem.yaml -n ${ROOK_NAMESPACE} || {
#     log_error "Failed to apply filesystem"
#     exit 1
# }
# log_success "Filesystem applied"

# Step 7: Apply toolbox
log_info "Applying Rook-Ceph toolbox..."
$kubernetesCLI apply -f toolbox.yaml -n ${ROOK_NAMESPACE} || {
    log_error "Failed to apply toolbox"
    exit 1
}
log_success "Toolbox applied"

# Step 8: Wait for toolbox to be ready
log_info "Waiting for toolbox to be ready..."
if ! $kubernetesCLI -n ${ROOK_NAMESPACE} wait --for=condition=Ready --selector=app=rook-ceph-tools pod --timeout=300s; then
    log_error "Toolbox failed to become ready"
    exit 1
fi
log_success "Toolbox is ready"

# Step 9: Apply storage classes
log_info "Applying storage classes..."
$kubernetesCLI get storageclass

$kubernetesCLI apply -f "$deployment_type/storageclass_rbd.yaml" || {
    log_error "Failed to apply RBD storage class"
    exit 1
}
log_success "RBD storage class applied"

# $kubernetesCLI apply -f "$deployment_type/storageclass_cephfs.yaml" || {
#     log_error "Failed to apply CephFS storage class"
#     exit 1
# }
# log_success "CephFS storage class applied"

$kubernetesCLI get storageclass
# Step 10: Wait for Ceph cluster health
wait_for_ceph_health || {
    log_error "Ceph cluster did not become healthy"
    exit 1
}

# Step 11: Set default storage class
log_info "Configuring default storage class..."
$kubernetesCLI patch storageclass local-path -p '{"metadata": {"annotations": {"storageclass.kubernetes.io/is-default-class": "false"}}}' || {
    log_error "Failed to patch local-path storage class"
    exit 1
}

# leaving out rook-cephfs until support for it is added to the demo cluster configuration
# $kubernetesCLI patch storageclass rook-cephfs -p '{"metadata": {"annotations": {"storageclass.kubernetes.io/is-default-class": "false"}}}' || {
#     log_error "Failed to patch rook-cephfs storage class"
#     exit 1
# }

$kubernetesCLI patch storageclass rook-ceph-block -p '{"metadata": {"annotations": {"storageclass.kubernetes.io/is-default-class": "true"}}}' || {
    log_error "Failed to patch rook-ceph-block storage class"
    exit 1
}

log_success "Default storage class configured"
$kubernetesCLI get storageclass
