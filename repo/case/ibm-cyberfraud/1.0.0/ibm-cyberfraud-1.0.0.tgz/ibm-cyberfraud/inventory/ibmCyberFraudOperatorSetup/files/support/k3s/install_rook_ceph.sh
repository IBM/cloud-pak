#!/bin/bash
# (C) Copyright IBM Corp. 2026  All Rights Reserved.
#
# This script installs Rook-Ceph storage on k3s cluster
# Runs from a remote control machine via SSH

set -e

# ----- HELPER FUNCTIONS -----

function log_info() {
    echo "[INFO] $1"
}

function log_success() {
    echo "[SUCCESS] $1"
}

function log_warning() {
    echo "[WARNING] $1"
}

function log_error() {
    echo "[ERROR] $1"
}

function err_exit() {
    log_error "$1"
    exit 1
}

# ----- ROOK-CEPH INSTALLATION FUNCTION -----

function install_rook_ceph() {
    local first_master="${1}"
    local ssh_password="${2}"
    local rook_ceph_dir="${SCRIPT_DIR}/rook-ceph"
    local deployment_type="${3:-demo}"  # Default to "demo" if not provided
    local sleep_time=60
    
    log_info "========================================="
    log_info "Installing Rook-Ceph Storage"
    log_info "========================================="
    
    # Check if rook-ceph directory exists
    if [ ! -d "${rook_ceph_dir}" ]; then
        log_error "Rook-Ceph directory not found: ${rook_ceph_dir}"
        return 1
    fi
    
    # Check if installation script exists locally
    if [ ! -f "${rook_ceph_dir}/install_rookceph.sh" ]; then
        log_error "Installation script not found: ${rook_ceph_dir}/install_rookceph.sh"
        return 1
    fi
    
    # Add delay before rook-ceph operations
    sleep 2
    
    # Copy rook_ceph directory to first master
    log_info "Copying rook-ceph files to ${first_master}..."
    local ssh_control_path="/tmp/ssh-rook-${first_master}-$$"
    
    if ! sshpass -p "${ssh_password}" scp -r -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
        -o ControlMaster=auto -o ControlPath="${ssh_control_path}" -o ControlPersist=60s \
        -o ConnectTimeout=10 -o ConnectionAttempts=3 \
        "${rook_ceph_dir}" root@"${first_master}:/root/"; then
        rm -f "${ssh_control_path}"
        log_error "Failed to copy rook-ceph files to ${first_master}"
        return 1
    fi
    
    log_success "Rook-Ceph files copied successfully"
    
    # Install rook-ceph on first master
    log_info "Installing Rook-Ceph on ${first_master}..."
    
    if sshpass -p "${ssh_password}" ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
        -o PubkeyAuthentication=no -o PreferredAuthentications=password -o LogLevel=ERROR \
        -o ControlMaster=auto -o ControlPath="${ssh_control_path}" -o ControlPersist=60s \
        root@"${first_master}" << EOF
set -e
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml
export kubernetesCLI="${kubernetesCLI}"

cd /root/rook-ceph/

# Check if installation script exists on the cluster
if [ ! -f "install_rookceph.sh" ]; then
    echo "[ERROR] Installation script not found on cluster: /root/rook-ceph/install_rookceph.sh"
    exit 1
fi

chmod +x install_rookceph.sh
bash install_rookceph.sh "${deployment_type}" 

EOF
    then
        rm -f "${ssh_control_path}"
        return 0
    else
        rm -f "${ssh_control_path}"
        log_error "Failed to install Rook-Ceph on ${first_master}"
        return 1
    fi
}

# ----- MAIN EXECUTION -----

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Get parameters from command line arguments
ROOK_CEPH_MASTER_HOST="${1:-}"
ROOK_CEPH_SSH_PASSWORD="${2:-}"
ROOK_CEPH_DEPLOYMENT_TYPE="${3:-demo}"  # Default to "demo" if not provided

log_info "========================================="
log_info "Rook-Ceph Installation Script"
log_info "========================================="


# Validate required parameters
if [ -z "${ROOK_CEPH_MASTER_HOST}" ]; then
    err_exit "No host set for rook-ceph installation"
fi

if [ -z "${ROOK_CEPH_SSH_PASSWORD}" ]; then
    err_exit "No node password set for rook-ceph installation"
fi

log_info "Master host: ${ROOK_CEPH_MASTER_HOST}"

# Install Rook-Ceph
if install_rook_ceph "${ROOK_CEPH_MASTER_HOST}" "${ROOK_CEPH_SSH_PASSWORD}" "${ROOK_CEPH_DEPLOYMENT_TYPE}" ; then
    log_success "=========================================="
    log_success "  Rook-Ceph Installation Complete!"
    log_success "=========================================="
    exit 0
else
    log_error "=========================================="
    log_error "  Rook-Ceph Installation Failed!"
    log_error "=========================================="
    exit 1
fi
