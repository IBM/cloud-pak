# IBM CyberFraud Operands

This inventory contains a list of operand images used to deploy IBM CyberFraud
