#!/usr/bin/env bash


# This script is for installing OLM from local YAML files

set -e

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if $kubernetesCLI get deployment olm-operator -n openshift-operator-lifecycle-manager > /dev/null 2>&1; then
    echo "OLM is already installed in a different configuration. This is common if you are not running a vanilla Kubernetes cluster. Exiting..."
    exit 1
fi

namespace=olm

if $kubernetesCLI get deployment olm-operator -n ${namespace} > /dev/null 2>&1; then
    echo "OLM is already installed in ${namespace} namespace. Exiting..."
    exit 1
fi

# Apply a manifest without hitting the client-side apply limitations:
#  - "missing the last-applied-configuration annotation" warning on resources
#    that were created imperatively
#  - "metadata.annotations: Too long: may not be more than 262144 bytes" on
#    large CRDs (e.g. clusterserviceversions.operators.coreos.com)
apply_manifest() {
    local file="$1"

    # Drop any stale last-applied-configuration annotation left by a previous
    # client-side apply. Errors are ignored (resources may not exist yet).
    $kubernetesCLI annotate -f "${file}" \
        kubectl.kubernetes.io/last-applied-configuration- > /dev/null 2>&1 || true

    # Preferred: server-side apply (does not use the annotation at all)
    if $kubernetesCLI apply --server-side --force-conflicts -f "${file}"; then
        return 0
    fi

    # Fallback for CLIs/clusters without server-side apply support:
    # create missing resources, then replace the ones that already exist.
    echo "Server-side apply failed for ${file}, falling back to create/replace..."
    $kubernetesCLI create -f "${file}" > /dev/null 2>&1 || true
    $kubernetesCLI replace -f "${file}"
}

apply_manifest "${SCRIPT_DIR}/crds.yaml"
$kubernetesCLI wait --for=condition=Established -f "${SCRIPT_DIR}/crds.yaml" --timeout=120s
apply_manifest "${SCRIPT_DIR}/olm.yaml"

# wait for deployments to be ready
$kubernetesCLI rollout status -w deployment/olm-operator --namespace="${namespace}"
$kubernetesCLI rollout status -w deployment/catalog-operator --namespace="${namespace}"

retries=30
until [[ $retries == 0 ]]; do
    new_csv_phase=$($kubernetesCLI get csv -n "${namespace}" packageserver -o jsonpath='{.status.phase}' 2>/dev/null || echo "Waiting for CSV to appear")
    if [[ $new_csv_phase != "$csv_phase" ]]; then
        csv_phase=$new_csv_phase
        echo "Package server phase: $csv_phase"
    fi
    if [[ "$new_csv_phase" == "Succeeded" ]]; then
	break
    fi
    sleep 10
    retries=$((retries - 1))
done

if [ $retries == 0 ]; then
    echo "CSV \"packageserver\" failed to reach phase succeeded"
    exit 1
fi

$kubernetesCLI rollout status -w deployment/packageserver --namespace="${namespace}"
