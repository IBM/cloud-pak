#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2026. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

kubernetesCLI=oc
namespace=""
force="false"
airgap=""
action=""
uninstall_cyberfraud="false"

usage() {
    echo "
Please pass one of the following arguments:
    --namespace <NAMESPACE>         [mandatory option - the namespace where CyberFraud is installed. If no other flags are passed, this initiates a complete cleanup of CyberFraud and terminates the namespace]
    --force                         [if this flag is set, this option will force delete all the remaining objects and terminate namespace]
    --airgap                        [if this flag is set, indicates airgap installation]
    "
}

####################################################################
# Logging functions
log_info() {
    echo "[INFO] $@"
}

log_success() {
    echo "[SUCCESS] $@"
}

log_error() {
    echo "[ERROR] $@" >&2
}

log_warning() {
    echo "[WARNING] $@"
}

####################################################################
# Check if namespace exists
function ns_exists() {
    local ns=$1
    $kubernetesCLI get namespace "$ns" 2>/dev/null
}

####################################################################
# Check if namespace was provided in arguments
function ns_provided() {
    function check_ns_exist() {
        # Use 'get namespace' instead of 'get project' for K3s compatibility
        r=$($kubernetesCLI get namespace $@ 2>/dev/null)
        if [[ -z $r ]]; then
            log_error "Namespace '$@' does not exist"
            usage
            exit 77
        else
            log_info "Namespace '$@' exists"
            # Try to set context to namespace (works in OpenShift, gracefully fails in K3s)
            $kubernetesCLI project $@ 2>/dev/null || log_info "Using namespace: $@"
        fi
    }
    
    message='[ERROR] Namespace not provided'
    if [[ $@ == 'cyberfraud' ]]; then
        if [[ -z $namespace ]]; then
            log_error "Namespace not provided"
            usage
            exit 77
        else
            check_ns_exist $namespace
        fi
    fi
}

####################################################################
# Terminate namespace with proper cleanup
function terminate_ns() {
    ns=$1
    wait=5
    local force_local=true

    delwh() {
        local kind="$1"
        local ns="$2"

        mh=$($kubernetesCLI get $kind -o jsonpath='{ range .items[*]}{.metadata.name}{" "}{.webhooks[0].clientConfig.service.namespace}{"\n"}{ end }' | awk -v ns=$ns '{ if ( $2 == ns) { printf "%s ", $1 }}')
        if [ -n "$mh" ]; then
            $kubernetesCLI delete $kind $mh --wait=0 --ignore-not-found=true 2>/dev/null
        fi
    }

    remaining() {
        local ns="$1"

        $kubernetesCLI get ns $ns -o jsonpath="{.status.conditions[?(@.reason=='SomeResourcesRemain')].message}" --ignore-not-found 2>/dev/null |\
        sed -e 's/Some resources are remaining://' -e 's/,/\n/' |\
        sed -e 's/ has .*$//'
    }

    get_ns() {
        $kubernetesCLI get namespace $ns -o name 2>/dev/null
    }

    function graceful() {
        local ns="$1"
        local wait="$2"

        iter=$(( wait * 6 ))
        $kubernetesCLI delete ns $ns --ignore-not-found --wait=0 >& /dev/null
         for i in $(seq 0 $iter)
            do
                if [ -z "$($kubernetesCLI get ns $ns -o name 2>/dev/null)" ]; then
                    echo ""
                    return 0
                fi
                sleep 10
        done

        echo "$(remaining $ns)"
    }

    if [[ "X$(get_ns $ns)" != "X" ]]; then
        log_info "-------------Deleting namespace $ns-------------"
        result=$(graceful "$ns" "$wait")
        if [ -n "$result" ]; then
            if [ -z "$force_local" ]; then
                log_error "Failed to remove namespace: $ns"
                log_error "Remaining resources: $result"
                return 1
            fi
        fi

        delwh "mutatingwebhookconfiguration" "$ns"
        delwh "validatingwebhookconfiguration" "$ns"

        if [ -z "$result" ]; then
            log_info "Namespace $ns has been removed"
            return 0
        fi

        for i in $(seq 1 30); do
            result=$(remaining $ns)
            if [ -z "$result" ]; then
                echo "INFO: Namespace $ns has been removed"
                return 0
            fi
            for crd in $result; do
                for cr in $($kubernetesCLI get $crd -o name -n $ns 2>/dev/null); do
                    $kubernetesCLI patch $cr -n $ns --type=merge -p '{"metadata":{"finalizers":null}}' 2>/dev/null
                done
            done
            sleep 5
        done      

        log_error "Failed to delete $ns"
        log_error "Remaining resources: $result"
        return 1
    fi
}

####################################################################
# Remove finalizers from objects
function remove_finaliser() {
    ns=$1
    obj_type=$2
    get_obj=($($kubernetesCLI get $obj_type -o name -n $ns --ignore-not-found 2>/dev/null))

    if [[ $obj_type == 'pods' ]]; then
        $kubernetesCLI get pod -n $ns --no-headers 2>/dev/null | awk '{print $1}' | xargs -r $kubernetesCLI delete pod -n $ns --force --grace-period=0 2>/dev/null || true
    fi

    if [ -z "$get_obj" ]; then
        log_info "No $obj_type to patch"
    else
        for c in ${get_obj[@]}; do
            $kubernetesCLI delete $c -n $ns --wait=false --ignore-not-found=true 2>/dev/null
            $kubernetesCLI patch $c -n $ns --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
        done
    fi
}

####################################################################
# Delete objects from namespace
function deleteObject() {
    ns=$1
    object_type=$2
    log_info "-------------Deleting $object_type from $ns namespace-------------"
    pending_objs=($($kubernetesCLI get $object_type -n $ns -o name 2>/dev/null))
    if [[ ! -z $pending_objs ]]; then
        $kubernetesCLI delete $object_type -n $ns --all --wait=false --ignore-not-found=true 2>/dev/null
    else
        log_info "No $object_type found"
    fi
}

####################################################################
# Wait for object deletion
function wait_for_object_deletion() {
    local ns=$1
    local object_type=$2
    local timeout=${3:-300}  # Default 5 minutes
    local exclude_pattern=${4:-}  # Optional exclusion pattern
    local elapsed=0
    
    log_info "Waiting for $object_type to be deleted from namespace $ns..."
    
    while true; do
        local remaining
        if [ -n "$exclude_pattern" ]; then
            # Count objects excluding the pattern
            remaining=$($kubernetesCLI get $object_type -n $ns --no-headers --ignore-not-found 2>/dev/null | grep -v "$exclude_pattern" | wc -l | tr -d ' ')
        else
            remaining=$($kubernetesCLI get $object_type -n $ns --no-headers --ignore-not-found 2>/dev/null | wc -l | tr -d ' ')
        fi
        
        if [ "$remaining" -eq 0 ]; then
            log_success "All $object_type deleted successfully"
            return 0
        fi
        
        if [ $elapsed -ge $timeout ]; then
            log_warning "Timeout waiting for $object_type deletion. $remaining object(s) remaining"
            if [[ $force == 'true' ]]; then
                log_info "Force removing finalizers from remaining $object_type..."
                remove_finaliser "$ns" "$object_type"
                sleep 5
                if [ -n "$exclude_pattern" ]; then
                    remaining=$($kubernetesCLI get $object_type -n $ns --no-headers --ignore-not-found 2>/dev/null | grep -v "$exclude_pattern" | wc -l | tr -d ' ')
                else
                    remaining=$($kubernetesCLI get $object_type -n $ns --no-headers --ignore-not-found 2>/dev/null | wc -l | tr -d ' ')
                fi
                if [ "$remaining" -eq 0 ]; then
                    log_success "All $object_type deleted after force removal"
                    return 0
                else
                    log_error "Failed to delete all $object_type even after force removal"
                    return 1
                fi
            fi
            return 1
        fi
        
        sleep 5
        elapsed=$((elapsed + 5))
        
        # Log every 30 seconds
        if [ $((elapsed % 30)) -eq 0 ]; then
            log_info "Still waiting... $remaining $object_type remaining (${elapsed}s elapsed)"
        fi
    done
}

####################################################################
# Delete Custom Resources
function delete_custom_resources() {
    local ns=$1
    local crd_pattern=$2
    local timeout=${3:-300}
    
    log_info "-------------Deleting Custom Resources matching pattern: $crd_pattern-------------"
    
    # Get all CRDs matching the pattern
    local crds=$($kubernetesCLI get crd --no-headers --ignore-not-found 2>/dev/null | grep -E "$crd_pattern" | awk '{print $1}')
    
    if [ -z "$crds" ]; then
        log_info "No CRDs found matching pattern: $crd_pattern"
        return 0
    fi
    
    # Delete CRs for each CRD
    for crd in $crds; do
        local crs=$($kubernetesCLI get $crd -n $ns --no-headers --ignore-not-found 2>/dev/null | awk '{print $1}')
        
        if [ -z "$crs" ]; then
            log_info "No CRs found for CRD: $crd"
            continue
        fi
        
        log_info "Deleting CRs for CRD: $crd"
        for cr in $crs; do
            log_info "  Deleting CR: $cr"
            $kubernetesCLI delete $crd $cr -n $ns --wait=false --ignore-not-found=true 2>/dev/null
        done
        
        # Wait for CRs to be deleted
        wait_for_object_deletion "$ns" "$crd" "$timeout"
    done
}

####################################################################
# Delete CyberfraudDeployment CR
function delete_cyberfraud_deployment() {
    log_info "-------------Deleting CyberfraudDeployment CR-------------"
    $kubernetesCLI delete cyberfrauddeployments.cf.ibm.com --all -n "$namespace" --wait=false --ignore-not-found=true 2>/dev/null || true
    
    if [[ $force == 'true' ]]; then
        remove_finaliser "$namespace" cyberfrauddeployment
    fi
    
    # Wait for CR to be deleted
    local timeout=300
    local elapsed=0
    while $kubernetesCLI get cyberfrauddeployment -n "$namespace" 2>/dev/null | grep -q .; do
        if [ $elapsed -ge $timeout ]; then
            log_warning "Timeout waiting for CyberfraudDeployment deletion"
            if [[ $force == 'true' ]]; then
                log_info "Force removing finalizers..."
                remove_finaliser "$namespace" cyberfrauddeployment
            fi
            break
        fi
        sleep 5
        elapsed=$((elapsed + 5))
    done
}

####################################################################
# Delete CyberfraudAccount CR
function delete_cyberfraud_account() {
    log_info "-------------Deleting CyberfraudAccount CR-------------"
    
    # Get count of CyberfraudAccount CRs
    local account_count=$($kubernetesCLI get cyberfraudaccount -n "$namespace" --no-headers 2>/dev/null | wc -l | tr -d ' ')
    
    if [ "$account_count" -eq 0 ]; then
        log_info "No CyberfraudAccount CRs found"
        return 0
    fi
    
    log_info "Found $account_count CyberfraudAccount CR(s)"
    $kubernetesCLI delete cyberfraudaccount --all -n "$namespace" --wait=false --ignore-not-found=true 2>/dev/null || true
    
    if [[ $force == 'true' ]]; then
        remove_finaliser "$namespace" cyberfraudaccount
    fi
    
    # Wait for all CRs to be deleted
    local timeout=300
    local elapsed=0
    while $kubernetesCLI get cyberfraudaccount -n "$namespace" 2>/dev/null | grep -q .; do
        if [ $elapsed -ge $timeout ]; then
            log_warning "Timeout waiting for CyberfraudAccount deletion"
            if [[ $force == 'true' ]]; then
                log_info "Force removing finalizers..."
                remove_finaliser "$namespace" cyberfraudaccount
            fi
            break
        fi
        sleep 5
        elapsed=$((elapsed + 5))
    done
    
    log_success "All CyberfraudAccount CRs deleted successfully"
}

# Function to uninstall resources in each namespace
function uninstall_resources_in_namespace() {
    local namespace="$1"

    log_info "------------- Uninstalling Resources in Namespace: $namespace -------------"

    # Remove Subscriptions, CSVs, and Install Plans
    log_info "Removing Subs, CSVs, and InstallPlans for $namespace..."
    $kubernetesCLI delete subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        log_info "Some Subscriptions, CSVs, or Install Plans still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" subscriptions.operators.coreos.com
        remove_finaliser "$namespace" clusterserviceversions.operators.coreos.com
    fi

    # Remove Deployments, DaemonSets, StatefulSets
    log_info "Removing Deployments, DaemonSets, and StatefulSets in $namespace..."
    $kubernetesCLI delete deployment,daemonset,statefulset --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get deployment,daemonset,statefulset -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        log_info "Some Deployments, DaemonSets, or StatefulSets still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" deployment
        remove_finaliser "$namespace" daemonset
        remove_finaliser "$namespace" statefulset
    fi

    # Remove ConfigMaps and Secrets (excluding system resources)
    log_info "Removing ConfigMaps and Secrets in $namespace..."
    
    # Delete ConfigMaps excluding system ones
    $kubernetesCLI get configmap -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "kube-root-ca" | grep -v "openshift-service-ca" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete configmap -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    
    # Delete Secrets excluding system ones
    $kubernetesCLI get secret -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "token" | grep -v "dockercfg" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete secret -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true

    # Check for remaining non-system resources
    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get configmap,secret -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "kube-root-ca" | grep -v "openshift-service-ca" | grep -v "token" | grep -v "dockercfg" | awk '{print $1}')

    if [[ -n "${pending_objs[*]}" ]]; then
        log_info "Some ConfigMaps or Secrets still present, proceeding to remove finalizers..."
        # Only remove finalizers from non-system resources
        $kubernetesCLI get configmap -n "$namespace" --no-headers 2>/dev/null | \
            grep -v "kube-root-ca" | grep -v "openshift-service-ca" | awk '{print $1}' | \
            xargs -r -I {} $kubernetesCLI patch configmap {} -n "$namespace" --type json \
            -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null || true
        
        $kubernetesCLI get secret -n "$namespace" --no-headers 2>/dev/null | \
            grep -v "token" | grep -v "dockercfg" | awk '{print $1}' | \
            xargs -r -I {} $kubernetesCLI patch secret {} -n "$namespace" --type json \
            -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null || true
    fi

    # Remove remaining resources (Pods, CRs, etc.)
    log_info "Removing Pods, and other resources in $namespace..."
    $kubernetesCLI delete all --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get all -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        log_info "Some resources still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" all
    fi

    log_success "------------- Finished Uninstalling Resources in Namespace: $namespace -------------"
}
####################################################################
# Cleanup catalog sources
function cleanup_catalogsources() {
    log_info "-------------Cleaning up CatalogSources-------------"
    
    # Determine the namespace to use
    local catalog_namespace="openshift-marketplace"
    
    # Check if openshift-marketplace namespace exists
    if ! $kubernetesCLI get namespace "$catalog_namespace" &>/dev/null; then
        log_info "Namespace $catalog_namespace not found, checking olm namespace..."
        catalog_namespace="olm"
        
        # Check if olm namespace exists
        if ! $kubernetesCLI get namespace "$catalog_namespace" &>/dev/null; then
            log_warning "Neither openshift-marketplace nor olm namespace found. Skipping catalog source cleanup."
            return 0
        fi
    fi
    
    log_info "Using namespace: $catalog_namespace for catalog source cleanup"
    
    # Get the specific catalog sources by name
    local specific_catalog_sources=""
    if $kubernetesCLI get catalogsource ibm-cyberfraud-release-catalog -n "$catalog_namespace" --ignore-not-found 2>/dev/null | grep -q ibm-cyberfraud-release-catalog; then
        specific_catalog_sources="ibm-cyberfraud-release-catalog"
    fi
    if $kubernetesCLI get catalogsource ibm-operator-catalog -n "$catalog_namespace" --ignore-not-found 2>/dev/null | grep -q ibm-operator-catalog; then
        specific_catalog_sources="${specific_catalog_sources} ibm-operator-catalog"
    fi
    
    # Get catalog sources managed by cyberfraud-operator
    local managed_catalog_sources=$($kubernetesCLI get catalogsource -n "$catalog_namespace" -l "app.kubernetes.io/managed-by=ibm-cyberfraud-operator" --no-headers --ignore-not-found 2>/dev/null | awk '{print $1}')
    
    # Combine both lists and remove duplicates
    local all_catalog_sources=$(echo -e "${specific_catalog_sources}\n${managed_catalog_sources}" | tr ' ' '\n' | sort -u | grep -v '^$')
    
    if [ -z "$all_catalog_sources" ]; then
        log_info "No CatalogSources found"
        return 0
    fi
    
    log_info "Found CatalogSources to delete:"
    echo "$all_catalog_sources"
    
    # Delete each catalog source
    for cs in $all_catalog_sources; do
        log_info "Deleting CatalogSource: $cs"
        $kubernetesCLI delete catalogsource "$cs" -n "$catalog_namespace" --wait=false --ignore-not-found=true 2>/dev/null
        
        if [[ $force == 'true' ]]; then
            $kubernetesCLI patch catalogsource "$cs" -n "$catalog_namespace" --ignore-not-found=true --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
        fi
    done
    
    # Wait a bit for deletion to propagate
    sleep 5
    
    # Check if any remain
    local remaining_specific=""
    if $kubernetesCLI get catalogsource ibm-cyberfraud-release-catalog -n "$catalog_namespace" --ignore-not-found 2>/dev/null | grep -q ibm-cyberfraud-release-catalog; then
        remaining_specific="ibm-cyberfraud-release-catalog"
    fi
    if $kubernetesCLI get catalogsource ibm-operator-catalog -n "$catalog_namespace" --ignore-not-found 2>/dev/null | grep -q ibm-operator-catalog; then
        remaining_specific="${remaining_specific} ibm-operator-catalog"
    fi
    local remaining_managed=$($kubernetesCLI get catalogsource -n "$catalog_namespace" -l "app.kubernetes.io/managed-by=ibm-cyberfraud-operator" --no-headers --ignore-not-found 2>/dev/null | awk '{print $1}')
    local remaining=$(echo -e "${remaining_specific}\n${remaining_managed}" | tr ' ' '\n' | sort -u | grep -v '^$')
    
    if [ -n "$remaining" ]; then
        log_warning "Some CatalogSources still present after deletion attempt"
        if [[ $force == 'true' ]]; then
            log_info "Force removing finalizers from remaining CatalogSources..."
            for cs in $remaining; do
                $kubernetesCLI patch catalogsource "$cs" -n "$catalog_namespace" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null || true
            done
        fi
    else
        log_success "All matching CatalogSources deleted successfully"
    fi
}

# ####################################################################
# # Delete operator group
# function delete_operator_group() {
#     log_info "-------------Deleting OperatorGroup-------------"
#     $kubernetesCLI delete operatorgroup cf-operator-group -n "$namespace" --ignore-not-found=true 2>/dev/null || true
#     if [[ $force == 'true' ]]; then
#         $kubernetesCLI patch operatorgroup cf-operator-group -n "$namespace" --ignore-not-found=true --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
#     fi
# }

####################################################################
# Delete CRs
function delete_crs() {
    set_crd_name1=$1
    cr_name1=$2

    $kubernetesCLI delete $set_crd_name1 $cr_name1 -n $cp4s_namespace --wait=false --ignore-not-found
    if [[ $force == 'true' ]]; then
        $kubernetesCLI patch $set_crd_name1 $cr_name1 -n $cp4s_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
}

####################################################################
function run_delete_crs() {
    if [[ $@ == 'all' ]]; then
        log_info "-------------Uninstalling $@ CRs from $namespace namespace-------------"
        crd=$($kubernetesCLI get crd --no-headers | awk '{print $1}' | grep cf.ibm.com)

        for crds in ${crd[*]}; do
            cr_name=($($kubernetesCLI get $crds -n $cp4s_namespace --no-headers --ignore-not-found | awk '{print $1}'))
            if [[ ! -z $cr_name ]]; then
                for i in ${cr_name[*]}; do
                    delete_crs $crds $i
                done
            else
                log_info "No CR found belonging to $crds"
            fi
        done
    fi
}
###################################################################
#Delete CRDS
function delete_crds() {
    $kubernetesCLI delete crd $@ --ignore-not-found --wait=false
    if [[ $force == 'true' ]]; then
        $kubernetesCLI patch crd $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
}
###################################################################
run_delete_crds() {
    log_info "Deleting CyberFraud CRDs..."
    
    local crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'cf.ibm.com' | awk '{print $1}')
    
    if [ -z "$crds" ]; then
        log_info "No CRDs found matching pattern: 'cf.ibm.com'"
        return 0
    fi
    
    for crd in $crds; do
        log_info "Deleting CRD: $crd"
        delete_crds $crd
    done
    
    # Wait a bit for CRD deletion to propagate
    sleep 10
    
    # Check if any remain and force delete
    local remaining=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'cf.ibm.com' | awk '{print $1}')
    if [ -n "$remaining" ]; then
        log_warning "Some CRDs still present, forcing deletion..."
        for crd in $remaining; do
            $kubernetesCLI patch crd $crd -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null || true
        done
    fi
    
    log_success "CyberFraud CRDs deletion completed"
}

###################################################################
#cert manager
function remove_certmanager() {
    log_info "-------------Deleting Certmanagers from $namespace namespace-------------"
    #remove certmanagers
    cm_default=($($kubernetesCLI get certmanagers cluster))
    if [[ -z $cm_default ]]; then
        log_info "Default certmanager not found"
    else
        $kubernetesCLI delete certmanagerconfigs.operator.ibm.com default --wait=false --ignore-not-found
        $kubernetesCLI patch certmanagerconfigs.operator.ibm.com default --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
    $kubernetesCLI delete validatingwebhookconfiguration cert-manager-webhook 2>/dev/null
}

delete_cert_manager() {
    log_info ""
    log_info "========================================="
    log_info "Clean Cert-Manager Resources and Namespace"
    log_info "========================================="
    remove_certmanager
    
    local cert_manager_namespaces=("ibm-cert-manager")
    
    for ns in "${cert_manager_namespaces[@]}"; do
        if $kubernetesCLI  get namespace $ns &>/dev/null; then
            log_info "Cleaning up resources in namespace: $ns"
            
            # Use generic functions to clean up namespace
            uninstall_resources_in_namespace "$ns"
            
            # Wait a bit for resources to be deleted
            sleep 10
            
            # Now delete the namespace
            terminate_ns "$ns"

        else
            log_info "Namespace $ns not found"
        fi
    done
}

####################################################################

function uninstall_mcg() {
    mcg_namespace="openshift-storage"

    # Check if openshift-storage is managed by middleware
    if ! [[ $($kubernetesCLI get namespace "${mcg_namespace}" -o json | jq -r '.metadata.labels["app.kubernetes.io/managed-by"]') == "middleware-operator" ]]; then
        log_info "Openshift-storage not managed by middleware-operator. Skipping namespace deletion."
        return
    fi

    log_info "-------------Uninstalling Multi Cloud Gateway and Noobaa Resources-------------"
    if [[ $force == 'true' ]]; then
        #  configmap default has finalizer objectbucket.io/finalize
        remove_finaliser "${mcg_namespace}" configmaps
        #  secrets default has finalizer objectbucket.io/finalize
        remove_finaliser "${mcg_namespace}" secrets
        remove_finaliser "${mcg_namespace}" bucketclass
        remove_finaliser "${mcg_namespace}" backingstore
    fi

    # Scale down operators
    $kubernetesCLI -n "${mcg_namespace}" scale deploy rook-ceph-operator odf-operator-controller-manager noobaa-operator --replicas=0 2>/dev/null

    # Patch the noobaa CR to allow deletion of the CR
    $kubernetesCLI patch noobaas.noobaa.io noobaa -n "${mcg_namespace}" --type merge -p '{"spec":{"cleanupPolicy":{"allowNoobaaDeletion":true}}}'
    # Delete validation webhook to allow deletion of Noobaa resources
    $kubernetesCLI delete ValidatingWebhookConfiguration -lolm.webhook-description-generate-name=admissionwebhook.noobaa.io

    # Delete noobaa resources
    deleteObject "${mcg_namespace}" bucketclass
    deleteObject "${mcg_namespace}" backingstore
    $kubernetesCLI delete storageclass openshift-storage.noobaa.io --ignore-not-found=true

    # Remove Noobaa CR
    remove_finaliser "${mcg_namespace}" "noobaas.noobaa.io"

    # Delete storagecluster & storagesystem
    remove_finaliser "${mcg_namespace}" "storagecluster"
    remove_finaliser "${mcg_namespace}" "storagesystem"

    # Delete remaining resources
    uninstall_resources_in_namespace "openshift-storage"

    # Delete Noobaa & odf CRDs
    local mcg_crds
    mcg_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'noobaa.io|odf|ocs' | awk '{print $1}')
    for crd in "${mcg_crds[@]}"; do
        delete_crds "${crd}"
    done

    # terminate the namespace
    terminate_ns "${mcg_namespace}"
}

####################################################################
# Main uninstall function
function uninstall_cyberfraud() {
    ns_provided cyberfraud
    
    log_info "========================================="
    log_info "Starting CyberFraud Uninstallation"
    log_info "========================================="
    
    if [[ $force == 'true' ]]; then
        log_info "Force cleanup is enabled"
    fi
    
    
    # Delete Custom Resources
    log_info "-------------Deleting Custom Resources-------------"
    delete_cyberfraud_deployment
    delete_cyberfraud_account
    delete_custom_resources "$namespace" "cf.ibm.com" 300
    
    # Delete Certificates
    log_info "Deleting Certificate CRs..."
    $kubernetesCLI delete certificates.cert-manager.io --all -n "$namespace" --wait=false --ignore-not-found=true 2>/dev/null || true
    wait_for_object_deletion "$namespace" "certificates.cert-manager.io" 120
    
    # Delete application resources
    log_info "-------------Deleting Application Resources-------------"
    
    # Delete non-operator deployments
    log_info "Deleting application deployments (excluding operator deployments)..."
    $kubernetesCLI get deployment -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "operator" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete deployment -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    
    # Wait for non-operator deployments to be deleted
    local timeout=180
    local elapsed=0
    while true; do
        local remaining=$($kubernetesCLI get deployment -n "$namespace" --no-headers 2>/dev/null | \
            grep -v "operator" | wc -l | tr -d ' ')
        
        if [ "$remaining" -eq 0 ]; then
            log_success "All application deployments deleted"
            break
        fi
        
        if [ $elapsed -ge $timeout ]; then
            log_warning "Timeout waiting for deployment deletion. $remaining remaining"
            if [[ $force == 'true' ]]; then
                log_info "Force removing finalizers from remaining deployments..."
                $kubernetesCLI get deployment -n "$namespace" --no-headers 2>/dev/null | \
                    grep -v "operator" | awk '{print $1}' | \
                    xargs -r -I {} $kubernetesCLI patch deployment {} -n "$namespace" --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null || true
            fi
            break
        fi
        
        sleep 5
        elapsed=$((elapsed + 5))
        
        if [ $((elapsed % 30)) -eq 0 ]; then
            log_info "Still waiting... $remaining deployment(s) remaining (${elapsed}s elapsed)"
        fi
    done
    
    deleteObject "$namespace" statefulset
    wait_for_object_deletion "$namespace" "statefulset" 180
    deleteObject "$namespace" daemonset
    wait_for_object_deletion "$namespace" "daemonset" 180
    
    # Delete non-operator pods
    log_info "Deleting application pods (excluding operator pods)..."
    $kubernetesCLI get pod -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "operator" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete pod -n "$namespace" --wait=false --ignore-not-found --force --grace-period=0 2>/dev/null || true
    
    # Wait for non-operator pods to be deleted
    timeout=120
    elapsed=0
    while true; do
        local remaining=$($kubernetesCLI get pod -n "$namespace" --no-headers 2>/dev/null | \
            grep -v "operator" | wc -l | tr -d ' ')
        
        if [ "$remaining" -eq 0 ]; then
            log_success "All application pods deleted"
            break
        fi
        
        if [ $elapsed -ge $timeout ]; then
            log_warning "Timeout waiting for pod deletion. $remaining remaining"
            break
        fi
        
        sleep 5
        elapsed=$((elapsed + 5))
        
        if [ $((elapsed % 30)) -eq 0 ]; then
            log_info "Still waiting... $remaining pod(s) remaining (${elapsed}s elapsed)"
        fi
    done
    
    deleteObject "$namespace" service
    wait_for_object_deletion "$namespace" "service" 120
    deleteObject "$namespace" route
    wait_for_object_deletion "$namespace" "route" 60
    deleteObject "$namespace" ingress
    wait_for_object_deletion "$namespace" "ingress" 60
    
    # Delete ServiceAccounts
    log_info "-------------Deleting ServiceAccounts-------------"
    $kubernetesCLI get serviceaccount -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "default" | grep -v "builder" | grep -v "deployer" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete serviceaccount -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    wait_for_object_deletion "$namespace" "serviceaccount" 60
    
    # Delete ConfigMaps and Secrets
    log_info "-------------Deleting Application ConfigMaps and Secrets-------------"
    $kubernetesCLI get configmap -n "$namespace" --no-headers 2>/dev/null | grep -v "operator" | grep -v "kube-root-ca" | grep -v "openshift-service-ca" | awk '{print $1}' | xargs -r $kubernetesCLI delete configmap -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    local timeout=120; local elapsed=0
    while true; do
        local remaining=$($kubernetesCLI get configmap -n "$namespace" --no-headers 2>/dev/null | grep -v "operator" | grep -v "kube-root-ca" | grep -v "openshift-service-ca" | wc -l | tr -d ' ')
        [ "$remaining" -eq 0 ] && log_success "All application ConfigMaps deleted" && break
        [ $elapsed -ge $timeout ] && log_warning "Timeout waiting for ConfigMap deletion" && [[ $force == 'true' ]] && remove_finaliser "$namespace" "configmap" && break
        sleep 5; elapsed=$((elapsed + 5))
    done
    $kubernetesCLI get secret -n "$namespace" --no-headers 2>/dev/null | grep -v "operator" | grep -v "token" | grep -v "dockercfg" | grep -v "\-tls\-" | awk '{print $1}' | xargs -r $kubernetesCLI delete secret -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    timeout=120; elapsed=0
    while true; do
        local remaining=$($kubernetesCLI get secret -n "$namespace" --no-headers 2>/dev/null | grep -v "operator" | grep -v "token" | grep -v "dockercfg" | grep -v "\-tls\-" | wc -l | tr -d ' ')
        [ "$remaining" -eq 0 ] && log_success "All application Secrets deleted" && break
        [ $elapsed -ge $timeout ] && log_warning "Timeout waiting for Secret deletion" && [[ $force == 'true' ]] && remove_finaliser "$namespace" "secret" && break
        sleep 5; elapsed=$((elapsed + 5))
    done
    
    # Delete PVCs, Jobs, CronJobs
    log_info "-------------Deleting PVCs, Jobs, and CronJobs-------------"
    deleteObject "$namespace" pvc
    wait_for_object_deletion "$namespace" "pvc" 180
    deleteObject "$namespace" job
    wait_for_object_deletion "$namespace" "job" 120
    deleteObject "$namespace" cronjob
    wait_for_object_deletion "$namespace" "cronjob" 60
    
    if ns_exists "openshift-storage"; then
        uninstall_mcg
    fi
    
    # Verify application resources deleted before removing operators (exclude operator resources)
    log_info "-------------Verifying Application Resources Deleted-------------"
    local remaining_resources=$($kubernetesCLI get all -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "service/kubernetes" | grep -v "operator" | wc -l | tr -d ' ')
    
    if [ "$remaining_resources" -gt 0 ]; then
        log_warning "Found $remaining_resources remaining application resources"
        $kubernetesCLI get all -n "$namespace" 2>/dev/null | grep -v "service/kubernetes" | grep -v "operator" || true
        
        if [[ $force == 'true' ]]; then
            log_info "Force cleaning remaining application resources..."
            # Delete non-operator resources
            $kubernetesCLI get all -n "$namespace" --no-headers 2>/dev/null | \
                grep -v "service/kubernetes" | grep -v "operator" | awk '{print $1}' | \
                xargs -r $kubernetesCLI delete -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
        fi
    else
        log_success "All application resources deleted"
    fi
    
    # Delete Operators (excluding cert-manager which will be deleted later)
    log_info "-------------Deleting Operators (Subscriptions and CSVs, excluding cert-manager)-------------"
    
    # Delete subscriptions except cert-manager
    log_info "Deleting subscriptions (excluding cert-manager)..."
    $kubernetesCLI get subscriptions.operators.coreos.com -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "ibm-cert-manager" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete subscriptions.operators.coreos.com -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    wait_for_object_deletion "$namespace" "subscriptions.operators.coreos.com" 120 "ibm-cert-manager"
    
    # Delete CSVs except cert-manager
    log_info "Deleting CSVs (excluding cert-manager)..."
    $kubernetesCLI get clusterserviceversions.operators.coreos.com -n "$namespace" --no-headers 2>/dev/null | \
        grep -v "ibm-cert-manager" | awk '{print $1}' | \
        xargs -r $kubernetesCLI delete clusterserviceversions.operators.coreos.com -n "$namespace" --wait=false --ignore-not-found 2>/dev/null || true
    wait_for_object_deletion "$namespace" "clusterserviceversions.operators.coreos.com" 180 "ibm-cert-manager"
    
    # Delete all installplans
    deleteObject "$namespace" "installplans.operators.coreos.com"
    wait_for_object_deletion "$namespace" "installplans.operators.coreos.com" 60
    
    [[ $force == 'true' ]] && log_info "Force deleting remaining resources..." && remove_finaliser "$namespace" "sa" && remove_finaliser "$namespace" "configmap" && remove_finaliser "$namespace" "secret"
    
    delete_cert_manager
    run_delete_crds
    cleanup_catalogsources
    terminate_ns "$namespace"
    
    log_success "========================================="
    log_success "CyberFraud Uninstallation Completed"
    log_success "========================================="
}

####################################################################
# Execute actions based on flags
function execute_actions() {
    uninstall_cyberfraud
}

####################################################################
# Function to store flags
function read_flags() {
    if [[ $@ == '' ]]; then
        log_error "Incorrect way of passing arguments!"
        usage
        exit 77
    elif [[ $@ == 'delete_crd' ]]; then
        delete_crd='true'
    elif [[ $@ == 'uninstall_cyberfraud' ]]; then
        uninstall_cyberfraud='true'
    fi
}

####################################################################
# Parse arguments
while true; do
    flag="$1"
    shift
    if [ -z "$flag" ]; then
        break
    fi
    case $flag in
    --namespace)
        namespace=$1
        shift
        ;;
    --airgap)
        airgap='true'
        shift
        ;;
    --force)
        force='true'
        shift
        ;;
    *)
        log_error "Invalid flag $flag"
        usage
        exit 77
        ;;
    esac
done

# Call execute actions
execute_actions

