# Name

IBM OpenRAG

# Introduction

## Summary

OpenRAG -- TBU

## Features

* TBU

# Details

## Prerequisites

### Resources Required

* See the [OpenRAG documentation](TBU)

# Installing

* This component is installed as a dependency of Watsonx.data Premium

## Storage

* See the [OpenRAG documentation](TBU)

## Limitations

* See the [OpenRAG documentation](TBU)

## Documentation

* See the [OpenRAG documentation](TBU)
