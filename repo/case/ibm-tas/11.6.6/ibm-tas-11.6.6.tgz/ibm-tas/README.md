# IBM&reg; TRIRIGA Application Suite

# Introduction

The TRIRIGA Application Suite Kubernetes Operator manages TRIRIGA Application Suite instances.

# Details

TRIRIGA Application Suite is an integrated workplace management system that enables access
to a full set of real estate and facilities applications, with flexibility to start with any
real estate or facilities discipline and expand into other areas. This release offers a
simplified, suite-based licensing structure that provides a single point of access to the full suite of real estate and facilities management capabilities.

## Prerequisites

- Any 64-bit Intel/AMD x86 Red Hat OpenShift Container Platform 4.12 or higher cluster, included, but not limited to
  - Any Customer managed cluster
  - Any IBM cloud managed cluster (ROKS and satellite)  
- The OCP cluster must be equipped with a StorageClass able to grant read-write permission to the Linux root group and to support Kubernates ReadWriteMany or ReadWriteOnce access mode
- A DBMS (DB2, Oracle or MS-SQL) instance accessible from the Openshift cluster using TLS. An instance of DB2 can be deployed using the [Cloud Pak for Data Platform](https://www.ibm.com/docs/en/cloud-paks/cp-data) or using the [IBM DB2 Operator](https://www.ibm.com/docs/en/db2/11.5?topic=deployments-db2-rhos-k8s). Both are available in the IBM Operator Catalog
- An instance of IBM Suite License Service accessible from the Openshift cluster using TLS, where your license entitlement file has been loaded. The IBM SLS instance must be configured to enforce client authentication. The IBM Suite License Service operator is available in the IBM Operator Catalog
- The [IBM Data Reporter Operator](https://github.com/redhat-marketplace/redhat-marketplace-operator/blob/develop/datareporter/v2/README.md) (DRO) installed and configured on the cluster. The IBM Data Reporter Operator is available in the Certified Operators Catalog (registry.redhat.io/redhat/certified-operator-index)
- Cert-manager operator deployed on the target Openshift cluster, managing certificates.cert-manager.io/v1 and issuers.cert-manager.io/v1 CRDs. The [cert-manager Operator for Red Hat Openshift](https://docs.redhat.com/en/documentation/openshift_container_platform/4.12/html/security_and_compliance/cert-manager-operator-for-red-hat-openshift) is availabe in the Red Hat Operators catalog (registry.redhat.io/redhat/redhat-operator-index) 
- An IBM Entitled Registry key

## Resources Required

IBM TRIRIGA Application Suite supports 3 deployment sizes:

- small: 1 pod + 1 pod for each defined [Dedicated Workflow Agent](#dedicated-tririga-workflow-agents)
  
  | Pod name | Hosted components |
  | ---- | -------- |
  |<tas-instance-name\>-s1-deploy-\*| UI, agents: data-connect, extended-formula, formula-recalc, incoming-mail, platform-maintenance-scheduler, report-queue, reserve-smtp, scheduler, wf-agent, wf-future, wf-notification; BIRT Engine |
  |<tas-instance-name\>-wfa-<dwfa-name\>-deploy-\*| agents: (dedicated) wf-agent |

- medium: 2 pods + 1 pod for each defined [Dedicated Workflow Agent](#dedicated-tririga-workflow-agents)
  
  | Pod name | Hosted components |
  | ---- | -------- |
  |<tas-instance-name\>-s1-deploy-\*| UI; agents: data-import, object-publish, object-migration |
  |<tas-instance-name\>-s3-deploy-\*| agents: data-connect, extended-formula, formula-recalc, incoming-mail, platform-maintenance-scheduler, report-queue, reserve-smtp, scheduler, wf-agent, wf-future, wf-notification; BIRT Engine |
  |<tas-instance-name\>-wfa-<dwfa-name\>-deploy-\*| agents: (dedicated) wf-agent |

- large: 6 pods + 1 pod for each defined [Dedicated Workflow Agent](#dedicated-tririga-workflow-agents)
  
  | Pod name | Hosted components |
  | ---- | -------- |
  |<tas-instance-name\>-s1-deploy-\*| UI; agents: data-import, object-publish, object-migration |
  |<tas-instance-name\>-s2-deploy-\*| UI; agents: data-import |
  |<tas-instance-name\>-s3-deploy-\*| agents: extended-formula, formula-recalc, wf-future, wf-notification |
  |<tas-instance-name\>-s4-deploy-\*| agents: platform-maintenance-scheduler, scheduler, wf-agent |
  |<tas-instance-name\>-s5-deploy-\*| agents: reserve-smtp, data-connect, incoming-mail |
  |<tas-instance-name\>-s6-deploy-\*| agents: report-queue; BIRT Engine |
  |<tas-instance-name\>-wfa-<dwfa-name\>-deploy-\*| agents: (dedicated) wf-agent |  

### Resources Required by containers and initContainers per Pod

| Pod name | containers | initContainers | Memory request (MB) | Memory limit (MB) | CPU request (cores) | CPU limit (cores) | Ephemeral-storage request (MB) | Ephemeral-storage limit (MB) | Storage (GB) |
| --------- | ----------- | ----------- | :---------: | :---------: | :---------: | :---------: | :---------: | :---------: | :---------: |
| <tas-instance-name\>-s1-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-s2-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-s3-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-s4-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-s5-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-s6-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-wfa-<dwfa-name\>-deploy-\* | tririga | datazip, update | javamin+2048 | javamax+2048 | 2 | 4 | (javamin+2048)*3 | (javamax+2048)*3 | 1+30+50 |
| <tas-instance-name\>-accapppoints-cronjob\* | accapppoints | - | 64 | 512 | 100m | 800m | 1024 | 8192 | - |
| tririga-controller-manager-\* | manager | - | 256 | 768 | 10m | 500m | 128 | 512 | - | 

Starting from version 11.6.5 it is possible to configure resources (memory, cpu and ephemeral-storage) requests and limits of containers and initContainers of TAS Pods using the *spec.podTemplates* attribute of the the TAS instance CR. See [Pods Resources Customization](#pods-resources-customization) for details.

**Warning:** memory and ephemeral-storage requirements for java based containers (tririga) and initContainers (datazip and update) of any TAS pod are calculated based on the values of *spec.jvm.javamin* (java heap minimum size) and *spec.jvm.javamax* (java heap maximum size) attributes of the TAS instance CR. These values are common for all java based containers and initContainers of any TAS Pod. The attributes *spec.jvm.javamin* and *spec.jvm.javamax* are ignored when a *spec.podTemplates* is used to provide resources specifications for a java based container or initicontainer of any particular pod, and for that container or initContainer the *java heap minimum size* is calculated as the 80% of the *resources.requests.memory* value and the *java heap maximum size* as the 80% of the *resources.limits.memory* value.       


### PersistenceVolumeClaims

IBM TRIRIGA Application Suite makes use of dynamic persistent storage provisioning.

For each Deployment named *<tas-instance-name\>-s[1|2|3|4|5|6]-deploy*, 3 PersistenceVolumeClaims are created and named:
- *<tas-instance-name\>-s[1|2|3|4|5|6]-log-pvc*
- *<tas-instance-name\>-s[1|2|3|4|5|6]-config-pvc*
- *<tas-instance-name\>-s[1|2|3|4|5|6]-userfiles-pvc*

For each Deployment named *<tas-instance-name\>-wfa-<dwfa-name\>-deploy*, 3 PersistenceVolumeClaims are created and named:
- *<tas-instance-name\>-wfa-<dwfa-name\>-log-pvc*
- *<tas-instance-name\>-wfa-<dwfa-name\>-config-pvc*
- *<tas-instance-name\>-wfa-<dwfa-name\>-userfiles-pvc*

*StorageClass*, *Size* and *AccessMode* for *log*, *config* and *userfiles* *PersistenceVolumeClaims* are specified using the corresponding attribute *spec.storage.log*, *spec.storage.config*, *spec.storage.userfiles* of the TAS instance CR.   

The StorageClasses in use must be able to grant read-write permission to the Linux root group and to support Kubernates ReadWriteMany or ReadWriteOnce access mode.

### Operator, Platform and Applications Versions

When the TRIRIGA Application Suite Operator at version 11.x.y is used to create a fresh TRIRIGA Application Suite instance, the TRIRIGA platform is version 4.x.y, if the operator version is less than 11.6.0, or 5.0.y if the operator version is 11.6.y. The TRIRIGA applications are at version 11.x.y. When TRIRIGA Application Suite Operator 11.x.y starts to manage an existing TRIRIGA Application Suite instance, the TRIRIGA platform is upgraded to the version managed by the operator, while TRIRIGA applications remain unchanged.

## Installing

In the following sections we are assuming you want to deploy IBM TRIRIGA Application Suite in a project named ibm-tas. If you want to deploy in a different project replace ibm-tas with the name of your choice.

### Create ibm-tas project

```bash
oc new-project ibm-tas
```

### Create tas-operatorgroup

```bash
cat <<EOF | oc create -f -
apiVersion: operators.coreos.com/v1alpha2
kind: OperatorGroup
metadata:
  name: tas-operator-group
  namespace: ibm-tas
spec:
  targetNamespaces:
    - ibm-tas
EOF    
```

### Create image pull secret ibm-entitlement-key to access the IBM Entitled registry

```bash
oc create secret docker-registry ibm-entitlement-key --docker-server=cp.icr.io --docker-username=cp --docker-password=<apikey> --docker-email=<email address> -n ibm-tas
```

### Install TAS operator

This can be done using the OperatorHub UI or using the oc cli

```bash
cat <<EOF | oc create -f -
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: tririga
  namespace: ibm-tas
spec:
  channel: v11.6
  installPlanApproval: Automatic
  name: tririga
  source: ibm-operator-catalog
  sourceNamespace: openshift-marketplace
  startingCSV: ibm-tririga.v11.6.6
EOF  
```

See the following notes:

- You can decide on the approval strategy by setting the subscription installPlanApproval to either Automatic or Manual. By default, the installPlanApproval is set to Automatic, when working with the OperatorHub UI or if you not specify the value in the Subscription spec. If the approval strategy is set to Automatic, the operator is automatically installed or upgraded when a new version is available. If you set the installPlanApproval parameter to Manual, the operator is not automatically installed or upgraded. Instead, you get an install plan that needs to be manually approved. Opting for a Manual approval allow you to plan for any activity you need to carry on before the installation or upgrade of the operator.

- If you install the IBM TRIRIGA Application Suite operator in a namespace where another operator is installed that already has the installPlanApproval: Manual set in its subscription, then the IBM TRIRIGA Application Suite operator inherits this setting. The approval plan is set to Manual and the IBM TRIRIGA Application Suite operator will not be automatically installed or upgraded.

- If you install the IBM TRIRIGA Application Suite operator with installPlanApproval set to Manual, this setting is applied to all the operators already installed in the same namespace or that will be installed in the future.

- You can initially set installPlanApproval to Automatic, then you can switch to Manual, when the installation of the IBM TRIRIGA Application Suite operator completes. In this way you can control when any update is going to be applied and plan for any activity you need to carry on before the upgrade of the operator.

# Configuration

## Minimal Configuration

### Create a secret to hold information needed to connect to the TRIRIGA DB (assuming tas-db-secret name)

```bash
cat <<EOF | oc apply -f - 
kind: Secret
apiVersion: v1
metadata:
  name: tas-db-secret
stringData:
  DB_USERNAME: <db user name>
  DB_PASSWORD: <db user password>
  DBA_USERNAME: <db administrator name>
  DBA_PASSWORD: <db administrator name>
  ca.crt: |
    -----BEGIN CERTIFICATE-----
    ...
    CA Certifificate needed to trust DBMS
    ...
    -----END CERTIFICATE-----
EOF        
```

### Create a secret to hold information needed to connect to the IBM Suite License Service instance (assuming tas-sls-secret name)

Warning: the IBM Suite License Service instance must be enforcing client authentication (spec.settings.auth.enforce=true in the SLS service custom resource)

The tas-sls-secret must respect the following template

```bash
cat <<EOF | oc create -f -
kind: Secret
apiVersion: v1
metadata:
  name: tas-sls-secret
stringData:
  url: https://sls.ibm-sls.svc.cluster.local
  ca.crt: |
    -----BEGIN CERTIFICATE-----
    ...
    CA Certifificate needed to trust SLS server
    ...
    -----END CERTIFICATE-----  
  registrationKey: your_sls_client_registration_key
  api.crt: |
    -----BEGIN CERTIFICATE-----
    ...
    SLS api server certificate
    ...
    -----END CERTIFICATE-----  
EOF     
```  

- Copy the above url, registrationKey and ca.crt fields from the sls-suite-registration ConfigMap presents in the namespace of your IBM Suite License Service instance.

- Copy the api.crt field from the tls.crt field of the sls-cert-api secret present in the namespace of your IBM Suite License Service instance. The api.crt field is required only when your IBM Suite License Service instance is installed in a remote cluster, and you need to access it through an Openshift route. As Suite License Service does not create an externally accessible route by default, you can trigger its creation by setting the spec.domain property of the IBM Suite License Service CR equal to the dns subdomain of the fully qualified hostname of the route to be created.

- Adjust the url field to match the url exposed by your IBM Suite License Service instance.

### Create a secret to hold information needed to connect to the IBM Data Reporter Operator service (assuming tas-dro-secret name)

```bash
cat <<EOF | oc create -f -
kind: Secret
apiVersion: v1
metadata:
  name: tas-dro-secret
  namespace: ibm-tas
stringData:
  api_url: https://<api_host>
  api_key: <token>
  ca-bundle.pem: |
    -----BEGIN CERTIFICATE-----
    ...
    CA Certifificate needed to trust DRO endpoint
    ...
    -----END CERTIFICATE-----
EOF    
```

- Get the value of api_url field from the field *spec.host* of the Route *ibm-data-reporter* available in the namespace where the IBM Data Reporter Operator is deployed (default: ibm-software-central).

- You can generate the token to be used as value of the field *api_key* by creating a secret named *ibm-data-reporter-operator-api-token* in the namespace where the IBM Data Reporter Operator is deployed, as in the following example. The token will be stored in the field *data.token* of the secret. 

```bash
cat <<EOF | oc apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: ibm-data-reporter-operator-api-token
  namespace: ibm-software-central
  labels:
    secret-owner: ibm-data-reporter-operator-api
  annotations:
    kubernetes.io/service-account.name: ibm-data-reporter-operator-api
type: kubernetes.io/service-account-token
EOF
```

- The Route *ibm-data-reporter* is secured by the cluster [default ingress certificate](https://docs.openshift.com/container-platform/4.12/security/certificates/replacing-default-ingress-certificate.html#understanding-default-ingress_replacing-default-ingress). The *ca-bundle.pem* field is required if the default cluster ingress is using a self-signed certificate.

### Create a secret holding the password for the AES Encryption Keystore (assuming tas-vault-secret name)

```bash
cat <<EOF | oc create -f -
kind: Secret
apiVersion: v1
metadata:
  name: tas-vault-secret
  namespace: ibm-tas
stringData:
  password: <your_password>
EOF    
```

- The password value must be longer than 5 characters, shorter than 21 characters, and must contain at least one upper case letter, at least one lower case letter, and at least one digit or special characters.

- It is a user responsability to update the password value in case of changes. 

### Create a TAS instance

This can be done using the Operator UI or using the oc cli

```bash
cat <<EOF | oc create -f -
apiVersion: tririga.ibm.com/v1
kind: Tririga
metadata:
  name: my-tririga
  namespace: ibm-tas
spec:
  env:
    size: medium
    use: development    
  license:
    accept: true
  db:
    db_secret: 'tas-db-secret'
    dbtype: db2
    dbdnsname: s-tridb-cp4d.tririga-np-prodman-5ced500bd618bccfff9050949ce1a15e-0000.us-east.containers.appdomain.cloud
    dbport: 31249
    dbname: TRIDB
    sid: default
  jvm:
    javamin: 4096
    javamax: 8192
  rt:
    contextpath: ''
    domain: default
    routes_crt: ''
  sls:
    sls_host: sls.ibm-sls.svc.cluster.local
    sls_secret: 'tas-sls-secret'
  uds:
    uds_host: uds-endpoint-ibm-uds.apps.enigma.cp.fyre.ibm.com
    uds_secret: 'tas-uds-secret'  
  storage: 
    log:
      class: 'ibmc-file-gold-gid'
      size: 30
      mode: 'ReadWriteOnce'
    config: 
      class: 'ibmc-file-bronze-gid'
      size: 1
      mode: 'ReadWriteOnce'
    userfiles: 
      class: 'ibmc-file-gold-gid'
      size: 50
      mode: 'ReadWriteOnce'
  vault_secret: 'tas-vault-secret'      
  version: 1.0.0
EOF  
```

- ReadWriteMany access mode is required for IBM TRIRIGA Application Suite PVCs only if you wish to simultaneously mount them in other pods.

- **warnig**: Since version 11.6.0 of TRIRIGA Application Suite, the Tririga Custom Resource Definition (CRD) introduces the field *spec.vault_secret*. While the CRD doesn't enforce the presence of this new field, the reconcilition of existing CR objects will fail until they are updated with the new field.

## Advanced Configuration

### Dedicated TRIRIGA Workflow Agents

Since version 11.3.0 TRIRIGA Application Suite allows you to create additional dedicated TRIRIGA Workflow Agents using the optional *wfagents* property of the *spec* of the Tririga CR.

```yaml
apiVersion: tririga.ibm.com/v1
kind: Tririga
metadata:
  name: my-tririga
  namespace: ibm-tas
spec:
  ...
  wfagents:
    - name: dwfa1
      members:
        - class: user
          name: myUserName1
        - class: user
          name: myUserName2
        - class: group
          name: myGroupName1
        - class: group
          name: myGroupName2
    - name: dwfa2
      members:
        - class: user
          name: myUserName3
    - name: dwfa3
      members:
        - class: group
          name: myGroupName3                   
  ...
```

Each item in the *spec.wfagents* array represents a dedicated workflow agent. The *spec.wfagents[i].name* string is the name of the dedicated workflow agent and the *spec.wfagents[i].members* array is the list of users and groups which the workflow agent is dedicated to. Set the *spec.wfagents[i].members[j].class* property equal to **user** if the item represents a user, while if the item represents a group, set the *spec.wfagents[i].members[j].class* property equal to **group**. In both cases, the *spec.wfagents[i].members[j].name* property is the name of the user or of the group. If the *spec.wfagents* array is present, it cannot be empty, i.e. at least one item must be defined. As well, the *members* array of each one of the included items, cannot be empty, i.e. at least one user or group must be assigned to the dedicated workflow agent.

### Additional CA certificates

If your TRIRIGA Application Suite instance needs to integrate with external servers over TLS, you can provide additional CA certificates using the truststores.truststore-mgr.ibm.com/v1 api. Note that this can also be used to import any certificates required for single sign-on (SSO).

```bash
cat <<EOF | oc create -f -
apiVersion: truststore-mgr.ibm.com/v1
kind: Truststore
metadata:
    name: my-tas-truststore
spec:
    license:
        accept: true
    includeDefaultCAs: true
    servers:
    - "google.com:443"
    - "ibm.com:443"
    certificates:
    - alias: alias_1 
      crt: |
        -----BEGIN CERTIFICATE-----
        ...
        Certificate 1   
        ...
        -----END CERTIFICATE-----

        ...

    - alias: alias_n 
      crt: |
        -----BEGIN CERTIFICATE-----
        ...
        Certificate n   
        ...
        -----END CERTIFICATE-----
EOF        
```

A secret with the same name of the Truststore CR is generated when it is processed by the operator. This secret holds the generated keystore in jks and p12 formats.

### server.xml extensions

A secret can be used to pass a sequence of XML elements to be added to the server.xml file of the Liberty application server

```bash
cat <<EOF | oc create -f -
kind: Secret
apiVersion: v1
metadata:
  name: tas-server-xml-ext-secret
stringData:
  extentions.xml: |
    <logging consoleLogLevel=“AUDIT” traceSpecifcation=“*=audit:com.ibm.ws.security.saml.*=all” />
    ...
    <extention_n ... /> 
EOF    
```

### Single Sign-On

IBM TRIRIGA Application Suite supports single sign-on using OIDC or SAML. Single sign-on configurations are applied to all PODs in the environment, and so mixed mode authentication (i.e. the capability to still use TRIRIGA native passwords) is not supported when single sign-on is enabled.

#### OIDC

Create a secret like the following one to enable OIDC:

```bash
cat <<EOF | oc create -f -
kind: Secret
apiVersion: v1
metadata:
  name: tas-oidc-secret
stringData:
  method: oidc
  cfg: |
    <openidConnectClient
      clientId="<application id from your registered app>"
      clientSecret="<client secret that you created for your app>"
      id="Azure"
      issuerIdentifier="<issuer from OpenID Connect metadata document>"
      tokenEndpointUrl="<token_endpoint from OpenID Connect metadata document>"
      jwkEndpointUrl="<jwks_uri from OpenID Connect metadata document>"
      authorizationEndpointUrl="<authorization_endpoint from OpenID Connect metadata document>"
      signatureAlgorithm="RS256"
      userIdentityToCreateSubject="preferred_username"
      redirectToRPHostAndPort="https://<public host name>:<ssl port>"
      >
    </openidConnectClient>
EOF 
```

#### SAML

Create a secret like the following one to enable SAML:

```bash
cat <<EOF | oc create -f -
kind: Secret
apiVersion: v1
metadata:
  name: tas-saml-secret
stringData:
  method: saml
  cfg: |
    <samlWebSso20 id="defaultSP" spLogout="true" authFilterRef="tasFilter"/>
    <authFilter id="tasFilter">
      <host id="myHost" name="<hostname to protect>" matchType="equals"/>
    </authFilter>
  idpMetadata.xml: |
    <?xml version="1.0" encoding="UTF-8"?>
    <md:EntityDescriptor entityID=...>
    </md:EntityDescriptor>
EOF      
```

### Pods Resources Customization

Starting from version 11.6.5 it is possible to configure resources (memory, cpu and ephemeral-storage) requests and limits of initContainers and containers of pods s1, s2, s3, s4, s5, s6, accapppoints and wfa-\<name of a dedicated workflow agent\> using the *spec.podTemplates* attribute of the TAS instance CR. Pods s1, s2, s3, s4, s5, s6, and wfa-\<name of a dedicated workflow agent\> have two initContainers, datazip and update, and one container, tririga, while the pod accapppoints have only one container named accapppoints.

- **cpu** request and limit are expressed using a string representing a decimal number, with an optional decimal part that allows at most 3 digits. The string can be suffixed using an *m* to indicate that the value must be interpreted as thousandths.

- **ephemeral-storage** and **memory** request and limit are expressed using a string representing an integer number. The string must be suffixed using *Gi* to indicate that the value must be interpreted as GigaBytes or *Mi* to indicate that the value must be interpreted as MegaBytes.

- A limit value cannot be lower of the corresponding request value.

```yaml
apiVersion: tririga.ibm.com/v1
kind: Tririga
metadata:
  name: my-tririga
  namespace: ibm-tas
spec:
  ...
  wfagents:
    - name: dwfa1
      members:
        - class: user
          name: myUserName1
        - class: user
          name: myUserName2
        - class: group
          name: myGroupName1
        - class: group
          name: myGroupName2
  ...
  podTemplates:
    - name: s2
      initContainers:
        - name: datazip
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '48Gi'
              memory: '4512Mi'            
            requests:
              cpu: '1'
              ephemeral-storage: '24000Mi'
              memory: '2Gi'
        - name: update
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '64Gi'
              memory: '8Gi'            
            requests:
              cpu: '1'
              ephemeral-storage: '48Gi'
              memory: '6Gi'                        
      containers:
        - name: tririga
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '64Gi'
              memory: '8Gi'            
            requests:
              cpu: '1'
              ephemeral-storage: '48Gi'
              memory: '6Gi'
    - name: wfa-dwfa1                       
      containers:
        - name: tririga
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '64Gi'
              memory: '8Gi'            
            requests:
              cpu: '1'
              ephemeral-storage: '48Gi'
              memory: '6Gi'
    - name: accapppoints                       
      containers:
        - name: accapppoints
          resources:
            limits:
              cpu: '500m'
              ephemeral-storage: '256Mi'
              memory: '256Mi'            
            requests:
              cpu: '200m'
              ephemeral-storage: '128Mi'
              memory: '64Mi'
    ...                                                       
  ...
```


### Create a TAS instance with advanced configurations

This can be done using the Operator UI or using the oc cli

```bash
cat <<EOF | oc create -f -
apiVersion: tririga.ibm.com/v1
kind: Tririga
metadata:
  name: my-tririga
  namespace: ibm-tas
spec:
  env:
    size: medium
    use: development    
  license:
    accept: true
  db:
    db_secret: 'tas-db-secret'
    dbtype: db2
    dbdnsname: s-tridb-cp4d.tririga-np-prodman-5ced500bd618bccfff9050949ce1a15e-0000.us-east.containers.appdomain.cloud
    dbport: 31249
    dbname: TRIDB
    sid: default
  jvm:
    javamin: 4096
    javamax: 8192
  rt:
    contextpath: ''
    domain: default
    routes_crt: ''
  sls:
    sls_host: sls.ibm-sls.svc.cluster.local
    sls_secret: 'tas-sls-secret'
  uds:
    uds_host: uds-endpoint-ibm-uds.apps.enigma.cp.fyre.ibm.com
    uds_secret: 'tas-uds-secret'  
  storage: 
    log:
      class: 'ibmc-file-gold-gid'
      size: 30
      mode: 'ReadWriteOnce'
    config: 
      class: 'ibmc-file-bronze-gid'
      size: 1
      mode: 'ReadWriteOnce'
    userfiles: 
      class: 'ibmc-file-gold-gid'
      size: 50
      mode: 'ReadWriteMany'
  vault_secret: 'tas-vault-secret'        
  version: 1.0.0
  integration:
    truststore: 'my-tas-truststore'
    sso:
      method: oidc
      cfg_secret: 'tas-oidc-secret-ex'
    server_xml_ext: 'tas-server-xml-ext-secret'
  wfagents:
    - name: dwfa1
      members:
        - class: user
          name: myUserName1
        - class: user
          name: myUserName2
        - class: group
          name: myGroupName1
  podTemplates:
    - name: s2
      initContainers:
        - name: datazip
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '48Gi'
              memory: '4512Mi'            
            requests:
              cpu: '1'
              ephemeral-storage: '24000Mi'
              memory: '2Gi'
        - name: update
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '64Gi'
              memory: '8Gi'            
            requests:
              cpu: '1'
              ephemeral-storage: '48Gi'
              memory: '6Gi'                        
      containers:
        - name: tririga
          resources:
            limits:
              cpu: '2000m'
              ephemeral-storage: '64Gi'
              memory: '8Gi'            
            requests:
              cpu: '1'
              ephemeral-storage: '48Gi'
              memory: '6Gi'              
EOF  
```

- ReadWriteMany access mode is required for IBM TRIRIGA Application Suite PVCs only if you wish to simultaneously mount them in other pods.

### Network considerations

#### IBM TRIRIGA Application Suite HTTPS endpoints

All the IBM TRIRIGA Application Suite network HTTPS endpoints are exposed using secure Openshift
routes of *reencrypt* termination type. The fully qualified domain name of TAS network endpoints
has the form ```<route-name>-<namespace>.<domain>```. If the field rt.domain of the TAS instance is
equal to *default*, then the default subdomain of OCP cluster is used, and the routes are secured
using the default cluster certificate. If rt.domain is set to a custom domain, then you need to
provide a certificate able to secure the custom domain using a Kubernetes secret of tls type.
The ca.crt field of this secret can be left empty, but must be present, while the tls.key and
tls.crt fields are required. It is user responsibility ensuring that the DNS is correctly configured,
in case of the adoption of a custom domain.

All the IBM TRIRIGA Application Suite routes are annotated with a default timeout of 600 seconds (600s). This value can be overridden using the optional attribute *spec.rt.timeout* of the custom resource, a string with the structure ```<timeout_value><time_unit>```, where ```<timeout_value>``` is any non-zero unsigned integer number and the supported ```<time_unit>``` are microseconds (us), milliseconds (ms), seconds (s), minutes (m), hours (h), or days (d).

#### IBM TRIRIGA Application Suite SMTP server endpoint

Starting from version 11.3.0, the TAS Operator does not create anymore the Nodeport Service ```<TAS-instance-name>-smtp-service```. It is a user responsibility to decide and implement how to expose the SMTP server endpoint needed by the integration between the TRIRIGA Reserve application and Microsoft&reg; Exchange, based on the available networking capabilities and in respect of the local security standards. For more information on how to publish outside the cluster a non HTTP service look to [Publishing Services](https://kubernetes.io/docs/concepts/services-networking/service/#publishing-services-service-types). The selector needed to identify the PODs implementing the TRIRIGA SMTP server endpoint is ```tas.ibm.com/smtp: '<TAS-instance-name>``` and the ```spec.ports``` array of the Service object must include the following item, independently of the chosen service type:

```yaml
    - name: 'smtp'
      protocol: TCP
      port: <incoming-port>
      targetPort: 1025
```

The integration between the TRIRIGA Reserve application and Microsoft&reg; Exchange needs to send network traffic to port 25. You can set ```<incoming-port>``` to 25, if the underlying network provider allows for network traffic to be directly sent to your cluster on port 25. If this is not the case, then you need to establish port address translation for incoming traffic on port 25 directed to your cluster, following the processes and using the tools established by your underlying network provider. The ```<incoming-port>``` value will be the one agreed with your underlying network provider.

Until version 11.6.1 the traffic to ports 1025 and 587 for the TAS instance POD with label tas.ibm.com/smtp=```<TAS-instance-name>``` was allowed by default from any peer. Starting from version 11.6.2 the user must must explicitly enable this traffic, when and if the SMTP server endpoint is exposed. This can be accomplished by creating an appropriate NetworkPolicy in the ibm-tas namespace:

```bash
cat <<EOF | oc create -f -
kind: NetworkPolicy
apiVersion: networking.k8s.io/v1
metadata:
  name: <TAS-instance-name>-user-tas-allow-smtp-external
  namespace: ibm-tas
spec:
  podSelector:
    matchLabels:
      tas.ibm.com/smtp: <TAS-instance-name>
  ingress:
    - ports:
        - protocol: TCP
          port: 1025
        - protocol: TCP
          port: 587
      from: []
  policyTypes:
    - Ingress
EOF      
```
The empty array used above as value of the ```spec.ingress[0].from``` field opens the ports 1025 and 587 to any peer. It should be replaced by a list of criteria, as described in [kubernetes documentation](https://kubernetes.io/docs/concepts/services-networking/network-policies/), that restricts the set of allowed peers as much as possible and respects the way that has been used to espose the TRIRIGA SMTP server endpoint and the rules, the processes and the tools of your underlying network and cluster providers.      

### Initial TRIRIGA *system* user password 

The operator generates an initial password for the TRIRIGA *system* user to be used for the first access to the service. This password is stored in a secret named ```<TAS-instance-name>-tas-system-user```.

### Limitations

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
IBM TRIRIGA Application Suite runs with the Openshift default 'restricted' SCC (Security Context Constraints).

### Custom Resource Status

The TAS operator maintains a *status* subresource for each *Tririga.tririga.ibm.com* instance it manages. This status includes both Kubernetes conditions and properties.

#### Conditions

- **Running** - it is true when the operator is currently running the reconciliation for the custom resource instance.
- **Successful** - it is true when the reconciliation cycle for the custom resource instance has finished and there were no errors. The operator will then wait for the next reconciliation action, either the reconcile period, dependent watches triggers or the resource is updated.
- **Failed** - it is true if there is any error during the reconciliation run for the custom resource instance, and the error message from the error that caused this condition is reported. The error message is the raw output from the run for reconciliation. If the Failure is intermittent, often the situation can be resolved when the operator reruns the reconciliation loop.
- **Initialized** - it is true when all the IBM TRIRIGA resources, including all the application PODs, have been created
- **Ready** - it is true when all the IBM TRIRIGA application PODs have reached the Ready condition

#### Properties

- **tasOperatorVersion** - Version of IBM TRIRIGA Application Suite operator performing the reconciliation
- **tririgaPlatformVersion** - IBM TRIRIGA platform version
- **operandImages** - list of operand images currently in use
- **url** - main IBM TRIRIGA instance url
- **slsClientInfo** - Information about the registered IBM Suite License Service. This field is relevant only if the IBM Suite License Service instance in use enforces client authentication.

## Operator Upgrade and Rollback

### Upgrade

The upgrade of the IBM TRIRIGA Application Suite is managed by the Operator Lifecycle Manager. The subscription of an installed TAS Operator specifies the update channel in the IBM Operator Catalog source, which is used to track and receive updates for the Operator. You can change the update channel in the subscription, to have the Operator to start tracking and receiving updates from a newer channel.

If the approval strategy in the subscription is set to Automatic, the upgrade process initiates as soon as a new Operator version is available in the selected channel. If the approval strategy is set to Manual, you must manually approve pending upgrades.

For details about Operator Lifecycle Manager managed upgrades refer to the [official Red Hat documentation](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.12/html/operators/administrator-tasks#olm-upgrading-operators).

### Rollback

IBM TRIRIGA Application Suite does not support downgrades as it is not supported by the Operator Lifecycle Manager. To rollback to version x.y.z:

1. Uninstall the TAS Operator without deleting the CRs
2. Create a CatalogSource pointing to the icr.io/cpopen/ibm-tas-catalog:x.y.z index image
  
    ```bash
    cat <<EOF | oc create -f -
    apiVersion: operators.coreos.com/v1alpha1
    kind: CatalogSource
    metadata:
      name: tas-catalogsource-xyz
      namespace: openshift-marketplace
    spec:
      sourceType: grpc
      image: icr.io/cpopen/ibm-tas-catalog:x.y.z
      displayName: 'TAS Operator - x.y.z'
      publisher: IBM
      updateStrategy:
        registryPoll:
          interval: 5m
    EOF
    ```

3. Install TAS operator by creating a Subscription pointing to the new CatalogSource

## Backup and Restore

### Backup

- Scale to 0 the tririga-control-manager deployment
- Scale to 0 each one of the *tas-instance-name*-sX-deploy deployments (s1 if the environment size is small, s1 and s3 if the environment size is medium, and s1 ... s6 if the environment size is large)
- Backup the TRIRIGA database, using the procedure provided by the DBMS technology that you adopt
- Backup the TAS instance CR
- Backup all the secrets referenced by the TAS instance CR
- Scale to 1 the tririga-control-manager deployment

### Restore

- Scale to 0 the tririga-control-manager deployment
- Scale to 0 each one of the *tas-instance-name*-sX-deploy deployments (s1 if the environment size is small, s1 and s3 if the environment size is medium, and s1 ... s6 if the environment size is large)
- Restore the TRIRIGA database, using the procedure provided by the DBMS technology that you adopted
- Apply all the secrets referenced by the TAS instance CR backup
- Apply the TAS instance CR backup
- Scale to 1 the tririga-control-manager deployment

## Uninstall

To unistall a TRIRIGA Application Suite instance, delete the corresponding Tririga CR. 

To unistall the TRIRIGA Application Suite operator from a project:

- Delete all the Tririga CR.
- Delete the TRIRIGA Application Suite operator Subscription from the project

After that the TRIRIGA Application Suite operator has been uninstalled from all the namespaces, the Tririga CustomResourceDefinition can be deleted from the cluster.

About unistall procedures of IBM Suite License Service, IBM User Data Service, and IBM CloudPak for Data refer to their respective user documentation.

## Deploying to a disconnected OCP cluster (Air-gap)

OpenShift Container Platform clusters that are installed on restricted networks, also known as disconnected clusters, cannot access icr.io and cp.icr.io registries where TRIRIGA Application Suite (TAS) images are available. Operator Lifecycle Manager (OLM) operations can be enabled through the use of a local registry, where TAS images can be mirrored.

### Air-gap prerequisites

- A client workstation with unrestricted network access with
  - oc cli version 4.12.0 or greater
  - podman version 5.1.2 or greater
- A mirror registry that supports Docker v2-2, accessible from both the client workstation and the disconnected target cluster  

### Log to the cp.icr.io registry using your ibm-entitlement-key credentials

```bash
podman login --authfile ./auths.json cp.icr.io
```

### Log to the mirror registry using your credentials

```bash
podman login --authfile ./auths.json <mirror_registry>
```

### Mirror TRIRIGA Application Suite related images to the mirror server

```bash
oc adm catalog mirror \
   icr.io/cpopen/ibm-tas-catalog:1.6.6 \
   <mirror_registry>:<port>/<namespace> \
   -a ./auths.json 
```

- Add --insecure flag if you don't want to configure trust for the target registry
- Add --manifests-only flag to generate only the manifests required for mirroring, and do not actually mirror the image content to a registry. This option can be useful for reviewing what will be mirrored, before doing that

The last output line will be: *wrote mirroring manifests to manifests-ibm-tas-catalog-<random_number\>*

The manifests directory contains the following files:

- The catalogSource.yaml file is a basic definition for a CatalogSource object that is pre-populated with your index image tag and other relevant metadata. This file can be used as is or modified to add the catalog source to your cluster.
  
- The imageContentSourcePolicy.yaml file defines an ImageContentSourcePolicy object that can configure nodes to translate between the image references stored in Operator manifests and the mirrored registry.
  
- The mapping.txt file contains all the source images and where to map them in the target registry.

### Create ImageContentSourcePolicy object that can configure nodes to translate between the image references stored in Operator manifests and the mirrored registry

```bash
oc create -f manifests-ibm-tas-catalog-<random_number>/imageContentSourcePolicy.yaml
```

### Create a CatalogSource object to reference the mirrored index image

```bash
oc create -f manifests-ibm-tas-catalog-<random_number>/catalogSource.yaml
```

At this point TRIRIGA Application Suite operator can be deployed using the normal procedure.

### Air-gap deployment of prerequisites

For information about air-gap deployment of:

- IBM Truststore Manager
- IBM Data Reporter Operator
- IBM Suite License Service
- cert-manager Operator for Red Hat Openshift
- IBM Cloudpak for Data
- IBM DB2 Operator 

please, refer to their user documentation. 

# Documentation

Additional information is available in the official [TRRIGA Application Suite documentation](https://www.ibm.com/docs/tas/11.6) and [TRIRGA product documentation](https://www.ibm.com/docs/tririga/11.6).
