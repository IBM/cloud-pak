# Name

IBM DataStax Mission Control / HCD

# Introduction

## Summary

Mission Control is the next generation operations platform for DataStax products. It simplifies management of all Hyper-Converged Database (HCD), DataStax Enterprise (DSE), and Apache Cassandra® operations across an array of hosting options from the cloud to on-premises and everything in-between. Manage HCD, DSE, and Cassandra environments on bare-metal or virtual machines (VMs). Powered by the advanced automation running DataStax Astra DB, Mission Control provides 24/7 automated operations of DSE clusters, datacenters, and nodes.

## Features

* Creation and management of DataStax Hyper Converged Database (HCD) clusters
* Orchestration of the [Data API](https://docs.datastax.com/en/dse/6.9/api-reference/dataapiclient.html) for HCD
* Automated anti-entropy repair scheduling and orchestration using Cassandra Reaper

# Details

## Prerequisites

### Resources Required

* See the [Mission Control documentation](https://docs.datastax.com/en/mission-control)

# Installing

* This component is installed as a dependency of Watsonx.data Premium

## Storage

* See the [Mission Control documentation](https://docs.datastax.com/en/mission-control)

## Limitations

* See the [Mission Control documentation](https://docs.datastax.com/en/mission-control)

## Documentation

* See the [Mission Control documentation](https://docs.datastax.com/en/mission-control)
