# Event Endpoint Management

## Introduction

Event Endpoint Management provides the capability to describe and catalog the APIs of Kafka event sources, and to socialize those APIs with application developers.

## Links to External Documentation

For more information about installing Event Endpoint Management, see the installation instructions in the [documentation](https://ibm.biz/eem-documentation).
