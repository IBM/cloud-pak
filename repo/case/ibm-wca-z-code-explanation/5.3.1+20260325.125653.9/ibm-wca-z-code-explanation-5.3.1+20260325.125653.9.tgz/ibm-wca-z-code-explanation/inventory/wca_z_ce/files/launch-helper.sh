#!/bin/bash

##################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2024 - 2025. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
##################################################################

scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

casePath="${scriptDir}/../../.."

# ----- FUNCTIONS -----

info() {
    echo >&2 "[INFO] ---------------"
    echo >&2 "[INFO] ------------- $1"
    echo >&2 "[INFO] ---------------"
}

getCaseName() {

    local caseName=""

    caseName="$(grep '^name: ' $casePath/case.yaml)"
    caseName=$(echo $caseName | awk -F':' '{print $2}')
    caseName="$(echo -e "${caseName}" | tr -d '[:space:]')"
    echo "$caseName"
}

getCaseVersion() {

    local caseVersion=""

    caseVersion="$(grep '^version: ' $casePath/case.yaml)"
    caseVersion=$(echo $caseVersion | awk -F':' '{print $2}')
    caseVersion="$(echo -e "${caseVersion}" | tr -d '[:space:]')"
    echo "$caseVersion"
}

getAppVersion() {

    local app_version=""

    app_version="$(grep '^appVersion: ' $casePath/case.yaml)" 
    app_version=$(echo $app_version | awk -F':' '{print $2}')
    app_version="$(echo -e "${app_version}" | tr -d '[:space:]')"
    echo "$app_version"
}

getShortAppVersion() {

    local app_version=$(getAppVersion)

    echo ${app_version%.*}
}

getAppName() {

    local app_name=""

    app_name="$(grep '^displayName: ' $casePath/case.yaml)" 
    app_name=$(echo $app_name | awk -F':' '{print $2}')
    app_name="$(echo -e "${app_name}" | xargs)"
    echo "$app_name"
}

getCatalogName() {
    
    local catalog_name=""
    local catsrc_file="$1"
    
    catalog_name="$(grep -m 1 '[[:space:]]name: ' ${catsrc_file})" 
    catalog_name=$(echo $catalog_name | awk -F':' '{print $2}')
    catalog_name="$(echo -e "${catalog_name}" | xargs)"
    echo "$catalog_name"
}

getCatalogNameSpace() {
    
    local catalog_namespace=""
    local catsrc_file="$1"
    
    catalog_namespace="$(grep -m 1 '[[:space:]]namespace: ' ${catsrc_file})" 
    catalog_namespace=$(echo $catalog_namespace | awk -F':' '{print $2}')
    catalog_namespace="$(echo -e "${catalog_namespace}" | xargs)"
    echo "$catalog_namespace"
}

###

getOperatorGroup() {

    local ns="$1"
    local operator_group_name="$2"
    local operator_group=""
    
    read -r -d '' operator_group <<-EOF
			apiVersion: operators.coreos.com/v1
			kind: OperatorGroup
			metadata:
			  name: ${operator_group_name}
			  labels:
			    app: ibm-code-explanation-operator-group
			    name: ibm-wca-z-code-explanation
			    app.kubernetes.io/name: ${operator_group_name}
			    app.kubernetes.io/instance: ibm-code-explanation
			    app.kubernetes.io/component: wca_z_ce
			    app.kubernetes.io/part-of: wcaz
			    app.kubernetes.io/managed-by: olm
			spec:
			  targetNamespaces:
			    - ${ns}
			EOF
    
    echo "$operator_group"
}

getSubscription() {

    local ns="$1"
    local src_ns="$2"
    local channel="v$3"
    local subscription_name="$4"
    local source_name="$5"
    local metadata_name="${subscription_name}"
    local subscription=""
    
    read -r -d '' subscription <<-EOF
			apiVersion: operators.coreos.com/v1alpha1
			kind: Subscription
			metadata:
			  name: ${metadata_name}
			  namespace: ${ns}
			spec:
			  channel: ${channel}
			  name: ${subscription_name}
			  installPlanApproval: Automatic
			  source: ${source_name}
			  sourceNamespace: ${src_ns}
			EOF
    
    echo "$subscription"
}