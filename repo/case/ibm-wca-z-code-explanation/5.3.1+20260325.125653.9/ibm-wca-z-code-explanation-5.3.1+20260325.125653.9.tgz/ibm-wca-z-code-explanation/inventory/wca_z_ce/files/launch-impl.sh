#!/bin/bash

##################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2024 - 2025. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
##################################################################

# Command line tooling & path
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ***** GLOBALS *****
source "$scriptDir"/launch-helper.sh
USE_AIIFM="${USE_AIIFM:-true}"
CAT_SRC_FILE="$scriptDir"/op-olm/catalog-source.yaml
PKG_NAME="ibm-code-explanation"

# ----- DEFAULTS -----

# parse additional dynamic args
# parse_custom_dynamic_args() {
#     key=$1
#     val=$2
#     case $key in
#     --useWatsonxaiifm)
#         USE_AIIFM=$val
#         ;;
#     esac
# }

# ----- ACTIONS (INSTALL) -----

install_catalog() {

    validate_install_catalog

    info "Installing catalog source"
    
    validate_file_exists "${CAT_SRC_FILE}"

    if [[ -z $registry ]]; then
      tee >($kubernetesCLI apply ${dryRun} -f -) < "${CAT_SRC_FILE}"
    else
      local catalog_source_img_orig=$(grep "image:" "${CAT_SRC_FILE}" | awk '{print$2}')
      local catalog_source_img_mod="${registry}/$(echo "${catalog_source_img_orig}" | sed -e "s/[^/]*\///")"
      sed -e "s|${catalog_source_img_orig}|${catalog_source_img_mod}|g" "${CAT_SRC_FILE}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    info "Done installing catalog source"
}

install_operator_group() {

    local ns="$1"
    
    echo >&2 "[INFO] Verifying the existence of any operator group in the namespace ${ns}..."
    if [[ $($kubernetesCLI get og -n "${ns}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
      echo >&2 "[INFO] Found an existing operator group..."
      $kubernetesCLI get og -n "${ns}" -o yaml
      return
    fi

    local ogName=$(getCatalogName $CAT_SRC_FILE)
    ogName=${ogName%-*}-operator-group

    local operator_group="$(getOperatorGroup ${ns} ${ogName})"

    info "No operator group found in the namespace ${ns}..."
    info "Installing the operator group into the namespace ${ns}"
    echo "$operator_group" | tee >($kubernetesCLI apply ${dryRun} -n "${ns}" -f -) | cat
    info "Done installing the operator group into the namespace ${ns}"
}

install_operator() {

    validate_install_args

    local catalogNameSpace=$(getCatalogNameSpace $CAT_SRC_FILE)
    local catalogName=$(getCatalogName $CAT_SRC_FILE)
    local shortVersion=$(getShortAppVersion)

    install_operator_group "${catalogNameSpace}"
 
    info "Installing $(getAppName) (v$(getAppVersion))"
    info "Verifying the catalog source exists..."

    if ! $kubernetesCLI get catsrc "${catalogName}" -n "${catalogNameSpace}"; then
      err_exit "The catalog source '${catalogName}' does not exist in the namespace '${catalogNameSpace}'"
    fi

    local subscription_content="$(getSubscription ${namespace} ${catalogNameSpace} ${shortVersion} ${PKG_NAME} ${catalogName})"
    echo "$subscription_content" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    info "Finished installing $(getAppName) (v$(getAppVersion))"
}

install() {

    install_catalog
    install_operator
}

# ----- ACTIONS (UNINSTALL) -----

uninstall_catalog() {
    
    validate_install_catalog "uninstall"
    info "Uninstalling $(getAppName) catalog source"

    $kubernetesCLI delete -f "${CAT_SRC_FILE}" --ignore-not-found=true ${dryRun}

    info "Finished uninstalling $(getAppName) catalog source"
}

uninstall_operator() {

    info "Uninstalling $(getAppName) (v$(getAppVersion))"
    
    local csvName=$($kubernetesCLI get subscription "${PKG_NAME}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)

    $kubernetesCLI delete subscription "${PKG_NAME}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    info "Finished uninstalling $(getAppName) (v$(getAppVersion))"
}

uninstall() {

    uninstall_operator
    uninstall_catalog

    #####
    # Leftovers: (not unisntalled)
    #    The Operator Group (in case others have installed in the same namespace)
    #    Any CRDs (in case there are other instances)
    #####
}
