# Name
IBM watsonx Code Assistant for Z Code Explanation

## Introduction
IBM watsonx™ Code Assistant for Z is a generative AI-assisted product built to accelerate the mainframe application lifecycle and streamline modernization at lower cost and with less risk than today’s alternatives.

## Details
watsonx Code Assistant for Z supports the end-to-end application developer lifecycle with capabilities for application discovery and analysis, code explanation, automated code refactoring, code optimization advice, COBOL to Java transformation, and validation. Developers can automatically refactor selected elements of an application, optimize code to increase performance, and continue modernizing in COBOL. Or, they can transform code to Java with generative AI leveraging a highly tuned state-of-the-art large language model.

## Prerequisites
The prerequisites for IBM watsonx Code Assistant for Z Code Explanation are:

* IBM Cloud Pak for Data common core services - [Shared components](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=planning-shared-components)
* IBM Cloud Pak for Data - [IBM watsonx.ai](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=services-watsonxai)

### Resources Required
* IBM Cloud Pak for Data [System requirements](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=planning-system-requirements)
* IBM Cloud Pak for Data [Hardware requirements](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=requirements-hardware)
* IBM Cloud Pak for Data [Software requirements](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=requirements-software)
* IBM Cloud Pak for Data [Private container registry requirements](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=requirements-private-container-registry)
* IBM Cloud Pak for Data [Client workstation requirements](https://www.ibm.com/docs/en/cloud-paks/cp-data/5.0.x?topic=requirements-client-workstation)

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Server    |  4 GB RAM   | 2 CPU       |  0 GB     | 1     |
| LLM       | 96 GB RAM   | 2 CPU,1 GPU | 70 GB     | 1     |
| **Total** | 100 GB RAM  | 4 CPU,1 GPU | 70 GB     | 2     |

### SecurityContextConstraints Requirements

```yaml
Name: restricted
Priority: <none>
Access:
  Users: <none>
  Groups: <none>
Settings:
  Allow Privileged: false
  Allow Privilege Escalation: true
  Default Add Capabilities: <none>
  Required Drop Capabilities: KILL,MKNOD,SETUID,SETGID
  Allowed Capabilities: <none>
  Allowed Seccomp Profiles: <none>
  Allowed Volume Types: configMap,csi,downwardAPI,emptyDir,ephemeral,persistentVolumeClaim,projected,secret
  Allowed Flexvolumes: <all>
  Allowed Unsafe Sysctls: <none>
  Forbidden Sysctls: <none>
  Allow Host Network: false
  Allow Host Ports: false
  Allow Host PID: false
  Allow Host IPC: false
  Read Only Root Filesystem: false
  Run As User Strategy: MustRunAsRange
    UID: <none>
    UID Range Min: <none>
    UID Range Max: <none>
  SELinux Context Strategy: MustRunAs
    User: <none>
    Role: <none>
    Type: <none>
    Level: <none>
  FSGroup Strategy: MustRunAs
    Ranges: <none>
  Supplemental Groups Strategy: RunAsAny
    Ranges: <none>
```

### Storage
IBM watsonx Code Assistant for Z Code Explanation has no storage requirements. The prerequisites does have storage requirements.

## Installing
1. Install the operator
1. Create an instance (Accept the license agreement)
1. Configure the connection to watsonx.ai

### Configuration
* Provision a space in watsonx.ai
* Configure JWT authentication 

### Limitations
See the [product page](https://ibm.biz/wcaz-ce-product) for limitations and known issues.
