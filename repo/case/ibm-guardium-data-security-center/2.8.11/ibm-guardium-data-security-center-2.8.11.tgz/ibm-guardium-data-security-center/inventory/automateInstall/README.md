# IBM Guardium Data Security Center setup

## Details
### Hardware and resources required
Refer to the [product hardware requirements documentation](1. https://www.ibm.com/docs/en/gdsc/saas?topic=planning-guardium-insights-saas-system-requirements-prerequisites) for resource requirements.

### Storage
Refer to the [Storage table in the install folder](../install/README.md#storage)

### Prerequisites

Refer to the [Prerequisites section in the install folder](../install/README.md#prerequisites)

### SecurityContextConstraints requirements
This workflow uses an operator that requires SecurityContextConstraints to be bound to the target namespace prior to installation. To meet this requirement, there may be cluster-scoped as well as namespace-scoped pre- and post- actions that need to occur.
The predefined SecurityContextConstraints named [nonroot](https://ibm.biz/cpkspec-scc) that comes pre-installed with Openshift has been verified for this operator.

If your target namespace is bound to these SecurityContextConstraints, you can proceed with installing the operator.

## IBM Guardium Data Security Center operator - Auto-Installation(Online and/or Airgapped/Offline) on an OpenShift cluster

### Preparation

#### Part I: Log in to your Openshift cluster instance
 - oc login <URL> -u <KUBE_USER> -p <KUBE_PASS> [--insecure-skip-tls-verify=true]
 - example: `oc login api.example.ibm.com:6443 -u kubeadmin -p xxxxx-xxxxx-xxxxx-xxxxx`

#### Part II: Obtain the CASE bundle
1. Create a local directory for the installation:
```
export LOCAL_INSTALL_DIR=$HOME/guardium-data-security-center
mkdir $LOCAL_INSTALL_DIR
```
2. Choose the CASE version that you want to use. For example, to use version 2.8.11, specify the 2.8.11 bundle file:
```
  export CASE_NAME=ibm-guardium-data-security-center
  export CASE_VERSION=2.8.11
  export CASE_ARCHIVE=ibm-guardium-data-security-center-$CASE_VERSION.tgz
```
3. Create a local directory for the CASE bundle:
```
export LOCAL_CASE_DIR=$HOME/.ibm-pak/data/cases/$CASE_NAME/$CASE_VERSION
```
4. Save the CASE bundle locally:
```
oc ibm-pak get $CASE_NAME \
--version $CASE_VERSION \
--skip-verify
```

<i><b>Note:</b></i> If you encounter an error similar to this:
```
No Case registries found for case ibm-cert-manager->=1.3.0 <1.3.1.tgz with the given repository URL information
FAILED
```

You may be experiencing a temporary communication problem with the remote repository. Wait a few minutes and try again.

5. Extract case in the local directory for the CASE bundle:
```
tar -xvf $LOCAL_CASE_DIR/$CASE_ARCHIVE --dir $LOCAL_CASE_DIR
```

#### Part III: Edit the Configuration file and set the environment variables/parameters

1. Edit the configuration file (`values.conf`) located in `$LOCAL_CASE_DIR/$CASE_NAME/inventory/automateInstall/files` by providing the mandatory parameters for an online and/or air-gapped/offline installation.
2. Editing the optional parameters is not required for standard deployment, but you will have more customization options if you edit them. The optional parameters have an impact on the installation process - it is recommended that they be edited only by advanced users.

### Installation

**Run the autoInstall script**

1. Run the following command to start the installation process of IBM Guardium Data Security Center and its dependencies:
```

  oc ibm-pak launch $CASE_NAME \
  --version $CASE_VERSION \
  --namespace ${NAMESPACE} \
  --inventory automateInstall \
  --action autoInstall \
  --tolerance 1 | tee -a ${LOCAL_INSTALL_DIR}/installation.log
```
- **Troubleshooting** - If the script fails, consult the installation.log file. In this file, these error messages can safely be ignored:
```
  Error from server (AlreadyExists): secrets "ibm-entitlement-key" already exists
```


2. After successful execution of the script, you will be prompted to provide a sample YAML file for IBM Guardium Data Security Center custom resource (CR) creation if the optional SKIP_GI_INSTANCE parameter is set to default in `values.conf`. Provide appropriate input for this. If you specify 'yes', skip steps 3 and 4 below.

3. To customise the CR for IBM Guardium Data Security Center, edit the sample-cr.yaml file.

4. To apply the custom CR, run this command:
```
   oc apply -f ${LOCAL_INSTALL_DIR}/sample-cr.yaml
```

5. Check the status of the instance creation:
```
   oc get gdsc
```
* Example output:
```
NAME      TYPE      STATUS   REASON                               MESSAGE                                                DESIRED_VERSION   INSTALLED_VERSION
staging   Running   True     GuardiumDataSecurityInstallRunning   Running installation of Guardium Data Security Center   3.8.11
```
* Example output when installation is complete by looking at the INSTALLED_VERSION column:
```
NAME      TYPE    STATUS   REASON      MESSAGE                         DESIRED_VERSION   INSTALLED_VERSION
staging   Ready   True     Successful  Last reconciliation succeeded   3.8.11             3.8.11
```

## Uninstallation
Refer to the [Uninstallation section in the install folder](../install/README.md#uninstallation)
