# IBM Guardium Data Security Center setup

## Details
### Hardware and resources required
Refer to the [product hardware requirements documentation](https://www.ibm.com/docs/en/gdsc/3.x?topic=planning-system-requirements-prerequisites) for resource requirements.
### Storage
Here is a table depicting the storage specifications required for a small tier installation. For information on specifications for larger installations, see the [product hardware requirements documentation](https://www.ibm.com/docs/en/gdsc/3.x?topic=planning-storage-considerations#storage_considerations__stg-classes__title__1).

| Components | Storage type (Block/File) | Access mode (RWO/RWX) | Deployment replicas | Recommended storage |
| :---: | :---:| :---: | :---: | :---: |
| IBM Events Operator (Kafka) | Block | RWO | 3 | 250 GB |
| IBM Events Operator (Zookeeper) | Block | RWO | 3 | 20 GB |
| MongoDB (data)| Block | RWO | 3 | 250 GB |
| MongoDB (log)| Block | RWO | 3 | 250 GB |
| Db2U (data) | Block | RWO | 2 | 5 TB |
| Universal connector (UC) | Block | RWO | 1 | 50 Gi |
| Sniffer | Block | RWO | 1 | 50 Gi |
| Redis | Block | RWO | 3 | 20 Gi |
| Redis Sentinel | Block | RWO | 3 | 20 Gi |
| Db2U shared | File | RWX | 1 | 1 TB |
| Noobaa (S3 Storage)| Block | RWO | 2 | 500 Gi |
| Ticketing shared | File | RWX | 1 | 20 Gi |
| UC shared | File | RWX | 1 | 50 Gi |
| Sniffer shared| File | RWX | 1 | 50 Gi |
| UC plug-in configs shared | File | RWX | 1 | 20 GB  |
| Backup Storage | File | RWX | 1 | 5TB+ |
| Backup Support Storage | File | RWX | 1 | 5TB+ |

### Prerequisites
- [Hardware requirements met](#hardware-and-resources-required)
- Openshift >= 4.20 (Validated against 4.20.23)

**Workstation prerequisites**
- Workstation needs to have a amd64 processor architecture.
- `oc login <OCP endpoint>` (Workstation must be logged in to the Openshift cluster)
- `IBM Cloud Pak(oc ibm-pak) = v1.10.0` [Download link](https://github.com/IBM/ibm-pak#download-and-verify-software)
- `oc >= 4.10.35` [Download link](https://mirror.openshift.com/pub/openshift-v4/x86_64/clients/ocp/4.10.35/)
- `kubectl >= 1.16` [Download link](https://mirror.openshift.com/pub/openshift-v4/clients/ocp/4.4.6/)
- `yq` [Download link](https://github.com/mikefarah/yq/#install)
- `openssl=3.3.1, ssh-keygen, base64, cat, echo, grep, awk, rm, tr, cut, tar`
- `python --version` (@ version 3.9.x) with `PyYAML` installed
- You must have cluster administrator privileges to run the setup scripts.
- Your login credentials to cp.icr.io
  - CP_REPO_USER="cp"
  - CP_REPO_PASS=entitlement key available at https://myibm.ibm.com/products-services/containerlibrary .



** Additional Workstation Prerequisites for Non-OCP Environments
- For non-OCP environments, ensure that you have the necessary tool to install the Operator Lifecycle Manager (OLM). Version 1.3.0 is required:  `https://github.com/operator-framework/operator-sdk/tags`

**Additional workstation prerequisites for air-gapped installations**
- `skopeo >= 1.0.0` For more information, see [Installing skopeo from packages](https://github.com/containers/skopeo/blob/master/install.md).

*If you do not have a private docker registry and wish to stand up a private docker registry:*
- `docker >= v17.03` or `podman`
- `htpasswd`

### SecurityContextConstraints requirements

This workflow uses an operator that requires SecurityContextConstraints to be bound to the target namespace prior to installation. To meet this requirement, there may be cluster-scoped as well as namespace-scoped pre- and post- actions that need to occur.
The predefined SecurityContextConstraints named [nonroot](https://ibm.biz/cpkspec-scc) that comes pre-installed with Openshift has been verified for this operator.

If your target namespace is bound to these SecurityContextConstraints, you can proceed with installing the operator.

## IBM Guardium Data Security Center operator - Online installation on an OpenShift cluster

### Preparation:
1. Log in to your Openshift cluster instance:
 - oc login <URL> -u <KUBE_USER> -p <KUBE_PASS> [--insecure-skip-tls-verify=true]
 - example: `oc login api.example.ibm.com:6443 -u kubeadmin -p xxxxx-xxxxx-xxxxx-xxxxx`
2. Choose a namespace for the IBM Guardium Data Security Center instance.
3. Set these environment variables:

```
export CP_REPO_USER=<Your Username to cp.icr.io>
export CP_REPO_PASS=<Your Password / Entitlement Key to cp.icr.io>
export NAMESPACE=<your chosen namespace>
```

### Installation

#### Part I: Obtain the CASE bundle
1. Create the following environment variables with the installer image name and the version. For example, to use version 3.8.11, specify the 2.8.11 bundle file:
```
export CASE_NAME=ibm-guardium-data-security-center
export CASE_VERSION=2.8.11
export LOCAL_CASE_DIR=$HOME/.ibm-pak/data/cases/$CASE_NAME/$CASE_VERSION
```
2. Save the CASE bundle locally:
```
oc ibm-pak get $CASE_NAME \
--version $CASE_VERSION \
--skip-verify
```
Tip: If you do not specify the CASE version, it will download the latest CASE.

<i><b>Note:</b></i> If you encounter an error similar to this:
```
No Case registries found for case ibm-cert-manager->=1.3.0 <1.3.1.tgz with the given repository URL information
FAILED
```

You may be experiencing a temporary communication problem with the remote repository. Wait a few minutes and try again.

#### Part II: Install IBM Cert Manager and IBM Common Services

1. Create a namespace for IBM Cert manager. The recommended namespace is `ibm-cert-manager`
```
oc create namespace ibm-cert-manager
```
2. Set the environment variable for --inventory parameter:
```
export CERT_MANAGER_INVENTORY_SETUP=ibmCertManagerOperatorSetup
```
3. Install the IBM Cert Manager Catalog:
```
   oc ibm-pak launch $CASE_NAME \
     --version $CASE_VERSION \
     --action install-catalog \
     --inventory $CERT_MANAGER_INVENTORY_SETUP \
     --namespace openshift-marketplace \
     --args "--inputDir ${LOCAL_CASE_DIR}"
```
4. Check the pod and catalog source status:
```
oc get pods -n openshift-marketplace
oc get catalogsource -n openshift-marketplace
```
Example output:
```
NAME                                    READY   STATUS    RESTARTS   AGE
ibm-cert-manager-catalog-bxjjb             1/1     Running   0          49s

NAME                          DISPLAY               TYPE   PUBLISHER   AGE
ibm-cert-manager-catalog    ibm-cert-manager-4.2.15    grpc   IBM         52s
```
5. Install IBM Cert Manager operators:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $CERT_MANAGER_INVENTORY_SETUP \
   --action install-operator \
   --namespace ibm-cert-manager \
   --args "--inputDir ${LOCAL_CASE_DIR}"
```
6. Ensure that the csv for IBM Cert Manager is in Succeeded phase.
```
  oc get csv -n ibm-cert-manager
```
7. Create a namespace for in which you want to install IBM Common Services. This same namespace will be used further for IBM Guardium Data Security Center installation as well. Example - staging
```
export NAMESPACE=staging
oc create namespace ${NAMESPACE}
```
8. Set the environment variable for --inventory parameter:
```
export ICS_INVENTORY_SETUP=ibmCommonServiceOperatorSetup
```
### For `non-OCP` (OpenShift Container Platform) environments

Please ensure that you disable the prerequisite checks using the following command:
```
export IBMPAK_LAUNCH_SKIP_PREREQ_CHECK=true #only for non-ocp
```
Additionally, we need to verify that the Operator Lifecycle Manager (OLM) is installed on non-OCP environments. You can check this by running the following command:
```
oc get deployment -A | grep 'olm-operator'

# olm                olm-operator                                     1/1     1            1           54d
```

If you don't have the OLM installed on your `non-ocp` enviroment, please perform the following command:

Confirm the version, first:

```
operator-sdk version

operator-sdk version: "v1.33.0", commit: "542966812906456a8d67cf7284fc6410b104e118", kubernetes version: "v1.27.0", go version: "go1.21.5", GOOS: "darwin", GOARCH: "arm64"
```
Also make sure that you have the latest version for the kubeconfig:

At the time of writing this document, the latrest is `v1beta1`

```
cat ~/.kube/config | grep client.authentication.k8s.io

      apiVersion: client.authentication.k8s.io/v1beta1
```

To install `OLM` in `non-ocp` enviroments, use the following command

```
operator-sdk olm install
```

Please confirm that the OLM has been successfully installed and the version is above 0.27.0:
```
kubectl get csv -n olm | grep packageserver
packageserver                      Package Server     0.27.0
```

We also need to verify that the `NginX controller` for ingress routing, is installed on the non-OCP environment. Unlike OCP, which comes with routes by default, non-OCP environments require manual installation.

An example could be:

```
ingress-nginx      ingress-nginx-controller                         1/1     1            1           54d
```

 Please also ensure that `OLM` is configured to use the `openshift-marketplace` as the default catalog namespace by running this command:

```
oc set env deploy/catalog-operator GLOBAL_CATALOG_NAMESPACE=openshift-marketplace -n openshift-operator-lifecycle-manager
```



9. Install the IBM Common Services Catalog:


```
   oc ibm-pak launch $CASE_NAME \
    --version $CASE_VERSION \
    --action install-catalog \
    --inventory $ICS_INVENTORY_SETUP \
    --namespace ${NAMESPACE} \
    --args "--registry icr.io \
            --recursive \
            --inputDir ${LOCAL_CASE_DIR}"
```
10. Check the pod and catalog source status:
```
oc get pods -n openshift-marketplace
oc get catalogsource -n openshift-marketplace
```
Example output:
```
NAME                                    READY   STATUS    RESTARTS   AGE
opencloud-operators-6czqp               1/1     Running   0          49s

NAME                  DISPLAY               TYPE   PUBLISHER   AGE
opencloud-operators   IBMCS Operators       grpc   IBM         52s
```
11. Install IBM Common Services operators:

For `non-OCP` environments, you will need to export the hostname and set the `ks_flag`. Ensure that your hostname begins with `apps.`. First, export `ks_flag` as `true` and then export the `hostname` pointing to your domain name, for example, `apps.reza.guardium-data-security-center.com`. An e.g. could be : `oc ibm-pak launch $CASE_NAME --version $CASE_VERSION --inventory $ICS_INVENTORY_SETUP --action install-operator --namespace ${NAMESPACE} --args "--size ${ICS_SIZE} --hostname domain.com --ks_flag true  --user ${CP_REPO_USER} --pass ${CP_REPO_PASS} --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR}"`

```
#Set ICS_SIZE to small if installing a GuardiumDataSecurityCenter size of values-xsmall or values-small
#Set ICS_SIZE to medium if installing a GuardiumDataSecurityCenter size of values-medium or higher
$ export ICS_SIZE=<[medium|large]>

oc ibm-pak launch $CASE_NAME \
  --version $CASE_VERSION \
  --action install-operator \
  --inventory $ICS_INVENTORY_SETUP \
  --namespace ${NAMESPACE} \
  --args "--size ${ICS_SIZE} --registry cp.icr.io --user ${CP_REPO_USER} --pass ${CP_REPO_PASS} --secret ibm-entitlement-key --recursive \
  --inputDir ${LOCAL_CASE_DIR}"

```
12. Ensure that all Common Services pods are in the "Running" or "Completed" state (this should take between 10 and 20 minutes):
```
  oc get pods -n ${NAMESPACE}
```
13. Retrieve the IBM Common Services Console credentials
(required for IBM Guardium Data Security Center installation):

* The default username to access the console is `cpadmin`.
You can get the password for the admin username by running this command:
```
  oc -n ${NAMESPACE} get secret platform-auth-idp-credentials -o jsonpath='{.data.admin_password}' | base64 -d
```
* The following is sample output:
```
  EwK9dj_example_password_lZSzVsA
```
* Based on the sample output, you would use `EwK9dj_example_password_lZSzVsA` as the password.
* You can change the default password at any time. For more information, see [Changing the cluster administrator password](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.5?topic=configurations-changing-cluster-administrator-access-credentials).

#### Part III: Install IBM Guardium Data Security Center operator and related components
1. Switch the namespace in which you had installed IBM Common Services in the previous step for your installation (for example, "staging"), and change the context into it:
```
oc project ${NAMESPACE}
```
2. Run the pre-install script. This script sets up secrets and parameters for the IBM Guardium Data Security Center instance. Make sure your workstation has met all of the prerequistes listed [above](#prerequisites) before running the script. For GDSC installs on AWS (non ROSA systems) and Azure (non ARO) with ODF 4.16, Set the -z option to true to create the SCC, required in the Noobaa upgrade process.
```
export GI_INVENTORY_SETUP=install
```

```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action pre-install \
   --namespace $NAMESPACE \
   --args "-n ${NAMESPACE} -h <DB worker host> -l <true/false> -z true"
```

The parameters used in the script are described here:
```
MANDATORY PARAMETERS:
    -n --i-namespace      : IBM Guardium Data Security Center Openshift namespace

    -h --host-datanodes   : Hostpath of the data node or nodes (comma-delimited).

    -l --label-datanodes  : If you specify 'true', data nodes will be labeled as dedicated for data service usage. If you specify 'false', labeling will be skipped.
```

```
OPTIONAL PARAMETERS:
    -t --taint-datanodes  : If you specify 'true', data nodes will be tainted and dedicated for data service usage. If you specify 'false', tainting will be skipped. Defaults to 'false'.

    -k --ingress-keystore : If you will supply a custom Ingress [Recommended], provide the path to its key file. The file must be \n delimited only. If you do not include this, a default of 'none' will be assumed (this is not recommended).

    -z --custom-nb-scc : If you specify 'true', a custom scc with a default name of 'noobaa-db-scc' will be created. Defaults to 'false' with no custom scc applied.

    -f --ingress-cert     : If you will supply a custom Ingress [Recommended], provide the path to its cert file. The file must be \n delimited only. If you do not include this, a default of 'none' will be assumed (this is not recommended).

    -c --ingress-ca       : If you will supply a custom Ingress [Recommended], provide the path to its certificate authority (CA) file. If you do not include this, a default of 'none' will be assumed (this is not recommended).
```
3. Install the catalogs:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action install-catalog \
   --namespace openshift-marketplace \
   --args "--inputDir ${LOCAL_CASE_DIR}"

```
* Check that the catalogs are installed:
```
oc get catsrc
NAME                                         DISPLAY                                   TYPE   PUBLISHER   AGE
certified-operators                          Certified Operators                       grpc   Red Hat     29h
community-operators                          Community Operators                       grpc   Red Hat     29h
ibm-redis-cp-operator-catalog                IBM Redis CP Catalog                     grpc   IBM         10d
ibm-db2uoperator-catalog                     IBM Db2U Catalog                          grpc   IBM         29h
ibm-guardium-data-security-center-operator-catalog       ibm-guardium-data-security-center-2.8.11-linux-amd64   grpc   IBM         29h
opencloud-operators                          IBMCS Operators                           grpc   IBM         29h
redhat-marketplace                           Red Hat Marketplace                       grpc   Red Hat     29h
redhat-operators                             Red Hat Operators                         grpc   Red Hat     29h
```
4. Install the operators:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action install-operator \
   --namespace ${NAMESPACE} \
   --args "--registry cp.icr.io --user ${CP_REPO_USER} --pass ${CP_REPO_PASS} --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR}"
```
* Check that the operators are installed:
```
oc get sub
NAME                                              PACKAGE                              SOURCE                                       CHANNEL
ibm-redis-cp-operator-catalog-subscription        ibm-redis-cp                         ibm-cloud-databases-redis-operator-catalog   v1.2
ibm-db2uoperator-catalog-subscription             db2u-operator                        ibm-db2uoperator-catalog                     v120102.0
ibm-guardium-insights-operator-subscription       ibm-guardium-insights-operator       ibm-guardium-insights-operator-catalog       v3.8
```
```
oc get csv
NAME                                    DISPLAY                                        VERSION      REPLACES                           PHASE
db2u-operator.v120102.0.0               IBM Db2                                        120102.0.0                                      Succeeded
ibm-redis-cp.v1.2.8                     ibm-redis-cp-controller                        1.2.8                                           Succeeded
ibm-guardium-insights-operator.v3.8.11   IBM Guardium Data Security Center              3.8.11                                           Succeeded
```
```
oc get pods
```
<!-- This output should be checked before publishing once the GDSC Operator is ready for production release -->
Example output:
```
NAME                                                      READY      STATUS       RESTARTS      AGE
db2u-day2-ops-controller-manager-5488d5c844-vvhgt     1/1     Running   0          24h
db2u-operator-manager-5fc886d4bc-wwcrv                1/1     Running   0          24h
ibm-cloud-databases-redis-operator-6d668d7b88-z7fzh   1/1     Running   0          24h
ibm-guardium-insights-operator-75d6c489fd-qfkss       1/1     Running   0          24h
mongodb-kubernetes-operator-856bc86746-lfk69          1/1     Running   0          24h
```
### Deploy the IBM Guardium Data Security Center instance
Please refer to [README](../../README.md#configuration) for information about creating the IBM Guardium Data Security Center custom resources to deploy IBM Guardium Data Security Center.

## IBM Guardium Data Security Center operator - Air-gapped installation on an OpenShift cluster
<a name="airgap_prereqs"></a>

### Preparation:

1. Log in to your Openshift cluster instance:
 - oc login <URL> -u <KUBE_USER> -p <KUBE_PASS> [--insecure-skip-tls-verify=true]
 - example: `oc login api.example.ibm.com:6443 -u kubeadmin -p xxxxx-xxxxx-xxxxx-xxxxx`
2. Prepare a private Docker registry that is accessible both from your local machine and the air-gapped cluster.
3. Choose a namespace for the IBM Guardium Data Security Center instance.
4. Set these environment variables:
```
export LOCAL_REGISTRY_HOST=<host IP or FQDN:Listening port>
export LOCAL_REGISTRY_USER=<Username for your private registry>
export LOCAL_REGISTRY_PASS=<Password for your private registry>
export CP_REPO_USER=<Your Username to cp.icr.io>
export CP_REPO_PASS=<Your Password / Entitlement Key to cp.icr.io>
export NAMESPACE=<your chosen namespace>
```
### Installation
### Mirroring images to your private container registry
#### Part I: Obtain the CASE bundle and mirror the images
1. Choose the CASE version & update pre-defined local directory that you want to use. For CASE Version: example, to use version 3.8.11, specify the 2.8.11 bundle file:
```
  export CASE_NAME=ibm-guardium-data-security-center
  export CASE_VERSION=2.8.11   #<YOUR_CASE_VERSION>
  export LOCAL_CASE_DIR=$HOME/.ibm-pak/data/cases/$CASE_NAME/$CASE_VERSION
```
2. Save the CASE bundle locally:
```
oc ibm-pak get $CASE_NAME \
--version $CASE_VERSION \
--skip-verify
```
Tip: If you do not specify the CASE version, it will download the latest CASE.

<i><b>Note:</b></i> If you encounter an error similar to this:
```
No Case registries found for case ibm-cert-manager->=1.3.0 <1.3.1.tgz with the given repository URL information
FAILED
```
You may be experiencing a temporary communication problem with the remote repository.
Wait a few minutes and try again.

3. Create a namespace for the IBM Guardium Data Security Center installation (using your chosen namespace - see [Prerequisites](#ibm-guardium-data-security-center-operator---air-gapped-installation-on-an-openshift-cluster)):
```
oc create namespace ${NAMESPACE}
```

4. Generate mirror manifests:
```
oc ibm-pak generate mirror-manifests \
   $CASE_NAME \
   $LOCAL_REGISTRY_HOST \
   --version $CASE_VERSION
```
You can use the following command to list all the images that will be mirrored and the publicly accessible registries from where those images will be pulled from:
```
oc ibm-pak describe $CASE_NAME --version $CASE_VERSION --list-mirror-images
```
5. Authenticating cp.icr.io external registry:

- Important: When you log in to cp.icr.io, you must specify the user as cp and the password which is your Entitlement key from the IBM Cloud Container Registry. For example:

```
docker login cp.icr.io -u  $CP_REPO_USER -p $CP_REPO_PASS
```

6. Authenticating internal registry air gap credentials:

- You must run the following command to configure credentials for all target registries that require authentication. Run the command separately for each registry:
```
docker login $LOCAL_REGISTRY_HOST -u $LOCAL_REGISTRY_USER -p $LOCAL_REGISTRY_PASS
```

7. Store authentication credentials for all source Docker registries.

<b><i>Note: </i></b>The mirroring process depends on network bandwidth and may take up to a few hours to complete:

If you use docker login, the authentication file is typically located at `$HOME/.docker/config.json` on Linux or `%USERPROFILE%/.docker/config.json` on Windows. After docker login you should

Examples:export REGISTRY_AUTH_FILE to point to that location. For example in Linux you can issue the following command:
```
export REGISTRY_AUTH_FILE=$HOME/.docker/config.json
```
NOTE: If you use podman login, issue below command after performing podman login, you can see that the file is populated with registry credentials.
```
export REGISTRY_AUTH_FILE=$HOME/.ibm-pak/auth.json
```

8. Mirror images to the final location
Note: The mirroring process depends on network bandwidth and may take up to a few hours to complete:
```
oc image mirror \
 -f $HOME/.ibm-pak/data/mirror/$CASE_NAME/$CASE_VERSION/images-mapping.txt \
 -a $REGISTRY_AUTH_FILE \
 --filter-by-os '.*' \
 --insecure \
 --skip-multiple-scopes \
 --max-per-registry=1 \
 --continue-on-error=false > my-mirror-progress.txt
```

9. Configure the cluster and content image source policy for air gap installation.

<b><i>Note: </i></b> This section will cause all nodes to reboot. During reboot, nodes will show as "Ready,SchedulingDisabled" or "NotReady,SchedulingDisabled".

- Update your Global Pull Secret by using your LOCAL_REGISTRY_HOST, LOCAL_REGISTRY_USERNAME, LOCAL_REGISTRY_PASSWORD and following these instructions [Global Pull Secret](https://docs.openshift.com/container-platform/4.12/openshift_images/managing_images/using-image-pull-secrets.html#images-update-global-pull-secret_using-image-pull-secrets)

- Apply the ImageContentSourcePolicy
```
   oc apply -f  $HOME/.ibm-pak/data/mirror/$CASE_NAME/$CASE_VERSION/image-content-source-policy.yaml
```
This step might cause your cluster nodes to drain and restart sequentially to apply the configuration changes.

Verify that the ImageContentSourcePolicy resource is created.
```
oc get imageContentSourcePolicy
```
Verify your cluster node status and wait for all the nodes to be restarted before proceeding.
```
oc get MachineConfigPool

$ oc get MachineConfigPool -w
NAME     CONFIG                                             UPDATED   UPDATING   DEGRADED   MACHINECOUNT   READYMACHINECOUNT   UPDATEDMACHINECOUNT   DEGRADEDMACHINECOUNT   AGE
master   rendered-master-53bda7041038b8007b038c08014626dc   True      False      False      3              3                   3                     0                      10d
worker   rendered-worker-b54afa4063414a9038958c766e8109f7   True      False      False      3              3                   3                     0                      10d
```
After the ImageContentsourcePolicy and global image pull secret are applied, the configuration of your nodes will be updated sequentially. Wait until all MachineConfigPools are in the UPDATED=True status before proceeding.

* Optional: If you are using an unsecure registry (no TLS or a self-signed certificate), configure the cluster to allow the unsecure registry:
```
oc patch image.config.openshift.io/cluster --type=merge -p '{"spec":{"registrySources":{"insecureRegistries":["'${LOCAL_REGISTRY_HOST}'"]}}}'
```

10. Wait and verify that all nodes have returned to the "Ready" state:
```
oc get nodes
This should result in all the nodes in Ready State, this can take a minimum of 5 minutes.
```

#### Part II: Install IBM Cert Manager and IBM Common Services

1. Create a namespace for IBM Cert manager. The recommended namespace is `ibm-cert-manager`
```
oc create namespace ibm-cert-manager
```
2. Set the environment variable for --inventory parameter:
```
export CERT_MANAGER_INVENTORY_SETUP=ibmCertManagerOperatorSetup
```
3. Install the IBM Cert Manager Catalog:
```
   oc ibm-pak launch $CASE_NAME \
     --version $CASE_VERSION \
     --action install-catalog \
     --inventory $CERT_MANAGER_INVENTORY_SETUP \
     --namespace openshift-marketplace \
     --args "--inputDir ${LOCAL_CASE_DIR}"
```
4. Check the pod and catalog source status:
```
oc get pods -n openshift-marketplace
oc get catalogsource -n openshift-marketplace
```
Example output:
```
NAME                                    READY   STATUS    RESTARTS   AGE
ibm-cert-manager-catalog-bxjjb             1/1     Running   0          49s

NAME                          DISPLAY               TYPE   PUBLISHER   AGE
ibm-cert-manager-catalog    ibm-cert-manager-4.2.1    grpc   IBM         52s
```
5. Install IBM Cert Manager operators:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $CERT_MANAGER_INVENTORY_SETUP \
   --action install-operator \
   --namespace ibm-cert-manager \
   --args "--inputDir ${LOCAL_CASE_DIR}"
```
6. Ensure that the csv for IBM Cert Manager is in Succeeded phase.
```
  oc get csv -n ibm-cert-manager
```
7. Create a namespace for in which you want to install IBM Common Services. This same namespace will be used further for IBM Guardium Data Security Center installation as well. Example - staging
```
export NAMESPACE=staging
oc create namespace ${NAMESPACE}
```
8. Set the environment variable for --inventory parameter:
```
export ICS_INVENTORY_SETUP=ibmCommonServiceOperatorSetup
```
9. Install the IBM Common Services Catalog:
```
   oc ibm-pak launch $CASE_NAME \
     --version $CASE_VERSION \
     --action install-catalog \
     --inventory $ICS_INVENTORY_SETUP \
     --namespace ${NAMESPACE} \
     --args "--registry icr.io --recursive \
     --inputDir ${LOCAL_CASE_DIR}"
```
10. Check the pod and catalog source status:
```
oc get pods -n openshift-marketplace
oc get catalogsource -n openshift-marketplace
```
Example output:
```
NAME                                    READY   STATUS    RESTARTS   AGE
opencloud-operators-6czqp               1/1     Running   0          49s

NAME                  DISPLAY               TYPE   PUBLISHER   AGE
opencloud-operators   IBMCS Operators       grpc   IBM         52s
```
11. Install IBM Common Services operators:

```
#Set ICS_SIZE to small if installing a GuardiumDataSecurityCenter size of values-xsmall or values-small
#Set ICS_SIZE to medium if installing a GuardiumDataSecurityCenter size of values-medium or higher
$ export ICS_SIZE=<[medium|large]>

oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $ICS_INVENTORY_SETUP \
   --action install-operator \
   --namespace ${NAMESPACE} \
   --args "--size ${ICS_SIZE} --inputDir ${LOCAL_CASE_DIR}"
```
12. Ensure that all Common Services pods are in the "Running" or "Completed" state (this should take between 10 and 20 minutes):
```
  oc get pods -n ${NAMESPACE}
```
13. Retrieve the IBM Common Services Console credentials
(required for IBM Guardium Data Security Center installation):

* The default username to access the console is `cpadmin`.
You can get the password for the admin username by running this command:
```
  oc -n ${NAMESPACE} get secret platform-auth-idp-credentials -o jsonpath='{.data.admin_password}' | base64 -d
```
* The following is sample output:
```
  EwK9dj_example_password_lZSzVsA
```
* Based on the sample output, you would use `EwK9dj_example_password_lZSzVsA` as the password.
* You can change the default password at any time. For more information, see [Changing the cluster administrator password](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.5?topic=configurations-changing-cluster-administrator-access-credentials).

#### Part III: Install IBM Guardium Data Security Center operator and related components
1. Switch the namespace in which you had installed IBM Common Services in the previous step for your installation (for example, "staging"), and change the context into it:
```
oc project ${NAMESPACE}
```
2. Run the pre-install script. This script sets up secrets and parameters for the IBM Guardium Data Security Center instance. Make sure your workstation has met all of the prerequistes listed [above](#prerequisites) before running the script. For GDSC installs on AWS (non ROSA systems) and Azure (non ARO) with ODF 4.16. Set the -z option to true to create the SCC, required in the Noobaa upgrade process.
```
export GI_INVENTORY_SETUP=install
```

```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action pre-install \
   --namespace $NAMESPACE \
   --args "-n ${NAMESPACE} -h <DB worker host> -l <true/false> -z true"
```

The parameters used in the script are described here:
```
MANDATORY PARAMETERS:
    -n --i-namespace      : IBM Guardium Data Security Center Openshift namespace

    -h --host-datanodes   : Hostpath of the data node or nodes (comma-delimited).

    -l --label-datanodes  : If you specify 'true', data nodes will be labeled as dedicated for data service usage. If you specify 'false', labeling will be skipped.
```

```
OPTIONAL PARAMETERS:
    -t --taint-datanodes  : If you specify 'true', data nodes will be tainted and dedicated for data service usage. If you specify 'false', tainting will be skipped. Defaults to 'false'.

    -k --ingress-keystore : If you will supply a custom Ingress [Recommended], provide the path to its key file. The file must be \n delimited only. If you do not include this, a default of 'none' will be assumed (this is not recommended).

    -z --custom-nb-scc : If you specify 'true', a custom scc with a default name of 'noobaa-db-scc' will be created. Defaults to 'false' with no custom scc applied.

    -f --ingress-cert     : If you will supply a custom Ingress [Recommended], provide the path to its cert file. The file must be delimited only. If you do not include this, a default of 'none' will be assumed (this is not recommended).

    -c --ingress-ca       : If you will supply a custom Ingress [Recommended], provide the path to its certificate authority (CA) file. If you do not include this, a default of 'none' will be assumed (this is not recommended).
```
3. Install the catalogs:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action install-catalog \
   --namespace openshift-marketplace \
   --args "--inputDir ${LOCAL_CASE_DIR}"

```
* Check that the catalogs are installed:
```
oc get catsrc
NAME                                         DISPLAY                                   TYPE   PUBLISHER   AGE
certified-operators                          Certified Operators                       grpc   Red Hat     29h
community-operators                          Community Operators                       grpc   Red Hat     29h
ibm-redis-cp-operator-catalog                IBM Redis CP Catalog                     grpc   IBM         10d
ibm-db2uoperator-catalog                     IBM Db2U Catalog                          grpc   IBM         29h
ibm-guardium-data-security-center-operator-catalog       ibm-guardium-data-security-center-2.8.11-linux-amd64   grpc   IBM         29h
opencloud-operators                          IBMCS Operators                           grpc   IBM         29h
redhat-marketplace                           Red Hat Marketplace                       grpc   Red Hat     29h
redhat-operators                             Red Hat Operators                         grpc   Red Hat     29h
```
4. Install the operators:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action install-operator \
   --namespace ${NAMESPACE} \
   --args "--registry cp.icr.io --user ${CP_REPO_USER} --pass ${CP_REPO_PASS} --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR}"
```
* Check that the operators are installed:
```
oc get sub
NAME                                              PACKAGE                              SOURCE                                       CHANNEL
ibm-redis-cp-operator-catalog-subscription        ibm-redis-cp                         ibm-cloud-databases-redis-operator-catalog   v1.2
ibm-db2uoperator-catalog-subscription             db2u-operator                        ibm-db2uoperator-catalog                     v120102.0
ibm-guardium-insights-operator-subscription       ibm-guardium-insights-operator       ibm-guardium-insights-operator-catalog       v3.8
```
```
oc get csv
NAME                                    DISPLAY                                        VERSION      REPLACES                           PHASE
db2u-operator.v120102.0.0               IBM Db2                                        120102.0.0                                      Succeeded
ibm-redis-cp.v1.2.8                     ibm-redis-cp-controller                        1.2.8                                           Succeeded
ibm-guardium-insights-operator.v3.8.11   IBM Guardium Data Security Center              3.8.11                                           Succeeded
```
```
oc get pods
```
<!-- This output should be checked before publishing once the GDSC Operator is ready for production release -->
Example output:
```
NAME                                                      READY      STATUS       RESTARTS      AGE
db2u-day2-ops-controller-manager-5488d5c844-vvhgt     1/1     Running   0          24h
db2u-operator-manager-5fc886d4bc-wwcrv                1/1     Running   0          24h
ibm-cloud-databases-redis-operator-6d668d7b88-z7fzh   1/1     Running   0          24h
ibm-guardium-insights-operator-75d6c489fd-qfkss       1/1     Running   0          24h
mongodb-kubernetes-operator-856bc86746-lfk69          1/1     Running   0          24h
```

### Deploy the IBM Guardium Data Security Center instance
Please refer to [README](../../README.md#configuration) for information about creating IBM Guardium Data Security Center custom resources to deploy IBM Guardium Data Security Center.

## Bring Your Own Key (BYOK) consideration for the secrets

By default, the IBM Guardium Data Security Center Operator creates the required secrets during the deployment. Bring Your Own Key (BYOK) enables businesses to retain better control over access to their encrypted data or regulatory compliance. If you wish to create a secret of your choice ahead of the deployment of IBM Guardium Data Security Center instance, it can be created based on the steps provided here.

The following table depicts the full list of secrets that can be created. You can choose any one of the secrets or selected combinations or all of them manually using the provided commands. The rest of the secret creation will be performed by the IBM Guardium Data Security Center Operator.

| Sr No | Secret name | Secret data name | Secret length (In character) |
|---|---|---|---|
| 1 | insights-master-key | _MASTER_KEY | 17
| 2 | ibm-ticketing-keystore | _TICKETING_KEYSTORE_PASSWORD | 17
| 3 | data-encryption-password | _DATA_ENCRYPTION_PASSWORD | 24
| 4 | insights-gcm-aad | _GCM_AAD | 17
| 5 | insights-tenant-user-secret | _TENANT_USER_SECRET | 65
| 6 | insights-api-password | _ENCRYPTION_PASSWORD | 17
| 7 | insights-uc | _UNIVERSAL_CONNECTOR_KEYSTORE_PASSWORD | 17
| 8 | insights-fetch | _FETCH_KEYSTORE_PASSWORD | 17
| 9 | insights-fetch | _FETCH_TRUSTSTORE_PASSWORD | 17

The command to create secrets when they do not exist in the system is provided below.

```
NAMESPACE=<your chosen namespace>
SECRET_NAME=<secret name>
SECRET_DATA_NAME=<secret data name>
SECRET_DATA_VALUE=$(echo -n 'alphanumeric value')

kubectl create secret generic ${SECRET_NAME} -n ${NAMESPACE} --from-literal=${SECRET_DATA_NAME}=${SECRET_DATA_VALUE}

```
Repeat these steps for each secret that you want to create.

The command to patch the secret data when the secret has already been created.

```
NAMESPACE=<your chosen namespace>
SECRET_NAME=<secret name>
SECRET_DATA_NAME=<secret data name>
SECRET_DATA_VALUE=$(echo -n 'alphanumeric value')
SECRET_DATA_VALUE_ENC=$(echo -n ${SECRET_DATA_VALUE} | base64 )

kubectl patch secret $SECRET_NAME --type merge -n $NAMESPACE -p '{"data":{"'$SECRET_DATA_NAME'":"'$SECRET_DATA_VALUE_ENC'"}}'

```
Execute these steps for all secrets that have already been created, such as insights-fetch.


The value for SECRET_DATA_VALUE should have the character length specified in the above table for a given secret. Otherwise, you can choose the following command to create an alpha numeric random string that sets the password for a given character length:

```
SECRET_LENGTH=<secret length>
SECRET_DATA_VALUE_PLAIN=$(openssl rand -base64 1024 | tr -d [:space:] | tr -d [:punct:] | cut -c1-$SECRET_LENGTH )
```

## Prometheus monitoring
Prometheus is an open-source monitoring solution that IBM Guardium Data Security Center uses to collect important information (such as memory and CPU usage) that IBM support can use to aid in diagnosing problems.

You can enable Prometheus via Openshift Monitoring (oc apply) or via IBM CASE bundle.
For IBM CASE bundle, please follow [these instructions](../prometheusSetup/README.md).

## Uninstallation
This section explains how to uninstall the IBM Guardium Data Security Center instance, operators, and catalogs.

<b><i>Important note</i></b>: These actions are IRREVERSIBLE. Make sure you back up any data you wish to keep or move to a new installation.

1. Remove the IBM Guardium Data Security Center instance:
```
oc delete `oc get guardiumdatasecuritycenter -oname -n ${NAMESPACE}` -n ${NAMESPACE}
```
Example output:
```
guardiumdatasecuritycenters.gi.ds.isc.ibm.com "staging" deleted
```
2. Clean up IBM Guardium Data Security Center dependencies and restart the operator:
```
oc delete $(oc get tenantguc -oname) || true
oc delete $(oc get tenantminisnif -oname) || true
oc rollout restart deploy/ibm-guardium-data-security-center-operator -n ${NAMESPACE}
```

3. Remove remaining persistent volume claims:
```
oc delete `oc get pvc -oname -n ${NAMESPACE} | grep -v icp-mongodb | grep -v common-service-db ` -n ${NAMESPACE}
```

4. Remove the remaining secrets:
```
oc delete `oc get secrets -oname -n ${NAMESPACE} | grep <GDSC-INSTANCE-NAME> ` -n ${NAMESPACE}
Example : oc delete `oc get secrets -oname -n ${NAMESPACE} | grep staging ` -n ${NAMESPACE}

oc delete `oc get secrets -oname -n ${NAMESPACE} | grep insights ` -n ${NAMESPACE}
```

5. Remove the remaining configmaps:
```
oc delete `oc get cm -oname -n ${NAMESPACE} | grep <GDSC-INSTANCE-NAME> ` -n ${NAMESPACE}
Example : oc delete `oc get cm -oname -n ${NAMESPACE} | grep staging ` -n ${NAMESPACE}

oc delete `oc get cm -oname -n ${NAMESPACE} | grep insights ` -n ${NAMESPACE}
```

6. Uninstall the operators:
```
export GI_INVENTORY_SETUP=install

oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action uninstall-operator \
   --namespace  ${NAMESPACE} \
   --args "--registry cp.icr.io --user ${CP_REPO_USER} --pass ${CP_REPO_PASS} --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR}"
```

7. Uninstall the catalogs:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action uninstall-catalog \
   --namespace openshift-marketplace \
   --args "--inputDir ${LOCAL_CASE_DIR}"

```

8. If you wish to also uninstall the Cloud Pak Foundational Services
- Follow the published [Cloud Pak Foundational Services uninstall](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.5?topic=online-uninstalling-foundational-services)
- Additional Resources for [Cloud Pak Foundational Services uninstall troubleshooting](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.5?topic=issues-uninstallation-is-not-successful)

9. Delete the IBM Guardium Data Security Center namespace if both Guardium Data Security Center and Cloud Pak Foundational Services are removed.
```
oc project default
oc delete project ${NAMESPACE}
```
*This action may take a few minutes to complete; During this time the project will appear as "Terminating".*
