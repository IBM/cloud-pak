#!/usr/bin/env bash

# Installs dependencies shared between unit tests and e2e tests ie.. Golang
# All the installation here should be moved to the custom image build once available.
echo "Running installation for shared dependencies."

# Setup environment variables with parity for Travis.

echo "Installing go-toolset"
dnf install go-toolset -y

echo "Install docker compose"
sudo dnf -y -d 0 install dnf-plugins-core
sudo dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
dnf install docker-compose-plugin -y -d 0
echo "Install ibmcloud cli"
curl -fsSL https://clis.cloud.ibm.com/install/linux | sh
# Install libxcrypt for db2cli driver in UBI 9
sudo yum -y install libxcrypt-compat
