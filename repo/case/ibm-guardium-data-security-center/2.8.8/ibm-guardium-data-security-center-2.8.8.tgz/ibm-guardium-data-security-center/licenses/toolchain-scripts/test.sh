#!/usr/bin/env bash

#Workaround for SPS sudo issue
chmod u+r /etc/shadow

# .env and install not needed for what was run in Travis.
#source toolchain-scripts/.env
#source toolchain-scripts/install.sh

cd Licenses  
if [ $(find . -type f -exec file --mime {} \; | grep -v utf-8 | grep -v us-ascii  | wc -l) -gt 0 ] ; then echo error; exit 1; fi