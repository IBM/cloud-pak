# Install mongodbOperator

* Login to case:
```
  cloudctl login -a https://cp-console.apps.<env>.example.ibm.com --skip-ssl-validation -u <user> -p <password> -n <namespase>
```

* Install Operator:
```
  cloudctl case launch -case <case.yaml> --namespace <<namespace> --inventory mongodbOperator --action install-operator -t 1
```