# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the redis operator

inventory="mongodbOperator" # default inventory item

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    echo "no dependent catalogs"
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {
    echo "N/A"
}

# Installs the catalog source and operator group
install_catalog() {
    echo "No Actions required for this CASE"
}
# Migration helper: Scale down old community operator if it exists
scale_down_old_operator() {
    echo "-------------Checking for old MongoDB Community Operator-------------"
    
    # Check if operator deployment exists
    local existing_deployment=$($kubernetesCLI get deployment mongodb-kubernetes-operator -n "${namespace}" -o name 2>/dev/null || echo "")
    
    if [[ -n "${existing_deployment}" ]]; then
        echo "Found existing MongoDB Community Operator deployment"
        
        # Check if it's the old version by checking labels
        # Old operator uses: name=mongodb-kubernetes-operator
        # New operator uses: app.kubernetes.io/name=mongodb-kubernetes-operator
        local has_old_labels=$($kubernetesCLI get deployment mongodb-kubernetes-operator -n "${namespace}" -o jsonpath='{.spec.selector.matchLabels.name}' 2>/dev/null || echo "")
        local has_new_labels=$($kubernetesCLI get deployment mongodb-kubernetes-operator -n "${namespace}" -o jsonpath='{.spec.selector.matchLabels.app\.kubernetes\.io/name}' 2>/dev/null || echo "")
        
        # Determine if this is old or new operator based on label selectors
        if [[ "${has_old_labels}" == "mongodb-kubernetes-operator" ]] && [[ -z "${has_new_labels}" ]]; then
            echo "Detected old MongoDB Community Operator (pre-1.6.1)"
            echo "  - Uses old label selector: name=mongodb-kubernetes-operator"
            echo ""
            echo "Migrating to new operator (v1.6.1+) as per migration guide..."
            echo "See: https://github.com/mongodb/mongodb-kubernetes/blob/master/docs/migration/community-operator-migration.md"
            echo ""
            
            # Scale down the old operator first
            echo "Step 1: Scaling down old operator to 0 replicas..."
            $kubernetesCLI scale deployment mongodb-kubernetes-operator --replicas=0 -n "${namespace}" ${dryRun}
            
            if [[ -z "${dryRun}" ]]; then
                echo "Waiting for old operator pods to terminate..."
                $kubernetesCLI wait --for=delete pod -l name=mongodb-kubernetes-operator -n "${namespace}" --timeout=120s 2>/dev/null || true
                echo "Old operator pods terminated successfully"
                echo ""
                
                # Delete the old deployment to allow new one with different label selectors
                # This is required because Kubernetes doesn't allow changing spec.selector.matchLabels
                echo "Step 2: Deleting old deployment to allow label selector change..."
                echo "  Reason: Kubernetes spec.selector.matchLabels is immutable"
                echo "  Old labels: name=mongodb-kubernetes-operator"
                echo "  New labels: app.kubernetes.io/name=mongodb-kubernetes-operator"
                echo ""
                $kubernetesCLI delete deployment mongodb-kubernetes-operator -n "${namespace}" --wait=true
                echo "Old deployment deleted successfully"
                echo ""
                echo "Step 3: New operator deployment will be created with updated configuration"
                echo "  - New label selectors (app.kubernetes.io/*)"
                echo "  - Updated images (v1.6.1)"
                echo "  - Enhanced RBAC resources"
                echo ""
            fi
        else
            echo "Existing operator appears to be new version (1.6.1+) based on label selectors"
            echo "  - Has new labels: app.kubernetes.io/name=mongodb-kubernetes-operator"
            echo "Skipping scale down. Deployment will be updated in place."
        fi
    else
        echo "No existing MongoDB operator found, proceeding with fresh installation"
    fi
}

# Install utilizing default yaml files method
install_operator() {
    # Verfiy arguments are valid
    ##validate_install_args

    echo "-------------Installing via K8 Operator-------------"

    local mongodb_file="${casePath}/inventory/${inventory}/files/mongodb.yaml"
    validate_file_exists "${mongodb_file}"

    # Migration step: Scale down old operator if it exists
    scale_down_old_operator

    # fix namespace
    $kubernetesCLI annotate customresourcedefinitions "mongodbcommunity.mongodbcommunity.mongodb.com" kubectl.kubernetes.io/last-applied-configuration- || true
    sed <"${mongodb_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "-------------MongoDB Operator Installation Complete-------------"
    echo "Note: If you migrated from an older operator version, the old deployment has been scaled to 0."
    echo "You can safely delete it after verifying the new operator is working correctly."
    
    # Configure Security Context Constraints (OpenShift only)
    # Check if this is an OpenShift cluster by testing for SCC resource
    if $kubernetesCLI api-resources | grep -q "securitycontextconstraints"; then
        echo "OpenShift detected - configuring Security Context Constraints..."
        
        # Verify mongodb-scc exists
        if ! $kubernetesCLI get scc mongodb-scc >/dev/null 2>&1; then
            echo "Warning: mongodb-scc not found. It should be created by mongodb.yaml"
            echo "SCC bindings complete (skipped - SCC not found)."
            return 0
        fi
        
        # Bind mongodb-scc to ServiceAccounts (mongodb.yaml includes the SCC definition)
        echo "Binding mongodb-scc to ServiceAccounts..."
        $kubernetesCLI adm policy add-scc-to-user mongodb-scc -z mongodb-kubernetes-operator -n "${namespace}" ${dryRun} || true
        $kubernetesCLI adm policy add-scc-to-user mongodb-scc -z mongodb-database -n "${namespace}" ${dryRun} || true
        
        # Configure mongodb-scc for OpenShift 4.18+ compatibility
        if [[ -z "${dryRun}" ]]; then
            echo "Verifying mongodb-scc configuration..."
            
            fsgroup_type=$($kubernetesCLI get scc mongodb-scc -o jsonpath='{.fsGroup.type}' 2>/dev/null | tr -d '[:space:]')
            scc_priority=$($kubernetesCLI get scc mongodb-scc -o jsonpath='{.priority}' 2>/dev/null | tr -d '[:space:]')
            uid_max=$($kubernetesCLI get scc mongodb-scc -o jsonpath='{.runAsUser.uidRangeMax}' 2>/dev/null | tr -d '[:space:]')
            
            # Update SCC if configuration is incorrect
            if [[ "${fsgroup_type}" != "RunAsAny" ]] || [[ "${scc_priority}" != "10" ]] || [[ "${uid_max}" != "2001" ]]; then
                echo "Updating mongodb-scc for OpenShift 4.18+ compatibility..."
                if $kubernetesCLI patch scc mongodb-scc --type=merge -p '{
                  "fsGroup": {"type":"RunAsAny"},
                  "runAsUser": {"type":"MustRunAsRange","uidRangeMin":1000,"uidRangeMax":2001},
                  "priority": 10
                }' 2>&1; then
                    echo "mongodb-scc configured: fsGroup=RunAsAny, runAsUser=1000-2001, priority=10"
                else
                    echo "Warning: Failed to update mongodb-scc. Manual configuration may be required."
                fi
            else
                echo "mongodb-scc already configured correctly."
            fi
            
            # Grant mongodb-kubernetes-appdb ServiceAccount permission to use mongodb-scc
            echo "Binding mongodb-scc to ServiceAccount mongodb-kubernetes-appdb..."
            if $kubernetesCLI adm policy add-scc-to-user mongodb-scc -z mongodb-kubernetes-appdb -n "${namespace}" 2>&1; then
                echo "SCC binding applied to mongodb-kubernetes-appdb ServiceAccount."
            else
                echo "Warning: Failed to bind SCC to mongodb-kubernetes-appdb. Manual binding may be required."
            fi
        fi
        
        echo "SCC bindings complete."
    else
        echo "Non-OpenShift cluster detected - skipping SCC configuration."
        echo "Note: Ensure your cluster's Pod Security Standards allow MongoDB's security requirements."
    fi
    
}

# Install utilizing default CLI method
install_operator_native() {
    # Verfiy arguments are valid
    ##sh##validate_install_args

    # # Proceed with install
    # echo "-------------Installing native-------------"

    # # Verify expected yaml files for install exist
    # local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    # local sa_file="${op_cli_files}/service_account.yaml"
    # local role_file="${op_cli_files}/role.yaml"
    # local role_binding_file="${op_cli_files}/role_binding.yaml"
    # local operator_file="${op_cli_files}/operator.yaml"

    # validate_file_exists "${sa_file}"
    # validate_file_exists "${role_file}"
    # validate_file_exists "${role_binding_file}"
    # validate_file_exists "${operator_file}"

    # # Apply yaml files manipulate variable input as required
    # # - service account
    # sed <"${sa_file}" "s|REPLACE_SECRET|$secret|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # # create crds
    # for crdYaml in "${op_cli_files}"/*_crd.yaml; do
    #     $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${crdYaml}"
    # done
    # # create role
    # $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${role_file}"
    # # create role binding, after fixing namespace
    # sed <"${role_binding_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # # create operator deployment
    # $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${operator_file}"

    install_operator
}

# install operand custom resources
apply_custom_resources() {
    echo "No Actions required for this CASE"
    # echo "-------------Applying custom resources-------------"

    # local cr="${casePath}"/inventory/"${inventory}"/files/redis.databases.cloud.ibm.com_v1_redissentinel_cr.yaml

    # validate_file_exists "$cr"

    # sed <"${cr}" -e "s/accept: false/accept: true/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "No Actions required for this CASE"
    # validate_install_catalog "uninstall"

    # # uninstall all catalogs of subcases first
    # if [[ ${recursive_action} -eq 1 ]]; then
    #     uninstall_dependent_catalogs
    # fi

    # local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    # echo "-------------Uninstalling catalog source-------------"
    # $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "No Actions required for this CASE"
    # echo "-------------Uninstalling operator-------------"
    # # Find installed CSV
    # csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # # Remove the subscription
    # $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # # Remove the CSV which was generated by the subscription but does not get garbage collected
    # [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency

    # delete crds
    ##for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    ##    $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    ##done
    local mongodb_file="${casePath}/inventory/${inventory}/files/mongodb.yaml"
    validate_file_exists "${mongodb_file}"

    # fix namespace
    sed <"${mongodb_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -f -) | cat
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    # validate_install_args "uninstall"

    # if [[ ${recursive_action} -eq 1 ]]; then
    #     uninstall_dependent_operators
    # fi

    # echo "-------------Uninstalling operator-------------"
    # # Verify expected yaml files for uninstall and delete resources for each
    # [[ -f "${casePath}/inventory/${inventory}/files/op-cli/service_account.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/service_account.yaml" --ignore-not-found=true ${dryRun}; }
    # [[ -f "${casePath}/inventory/${inventory}/files/op-cli/role.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/role.yaml" --ignore-not-found=true ${dryRun}; }
    # [[ -f "${casePath}/inventory/${inventory}/files/op-cli/role_binding.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/role_binding.yaml" --ignore-not-found=true ${dryRun}; }
    # [[ -f "${casePath}/inventory/${inventory}/files/op-cli/operator.yaml" ]] && { $kubernetesCLI delete -n "${namespace}" -f "${casePath}/inventory/${inventory}/files/op-cli/operator.yaml" --ignore-not-found=true ${dryRun}; }

    # # delete crds
    # if [[ $deleteCRDs -eq 1 ]]; then
    #     echo "deleting crds"
    #     for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    #         $kubernetesCLI delete -n "${namespace}" -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    #     done
    # fi
    uninstall_operator
}

delete_custom_resources() {
    echo "No Actions required for this CASE"
    # echo "-------------Deleting custom resources-------------"
    # local cr="${casePath}"/inventory/"${inventory}"/files/redis.databases.cloud.ibm.com_v1_redissentinel_cr.yaml
    # validate_file_exists "$cr"
    # $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --catalogSource)
        catalogSource="$val"
        ;;
    esac
}