# Redis Operator Setup

This inventory item contains resources required to install the Redis Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI) application of kubernetes manifests in both an online and offline airgap environment.

## Features

* It provisions a Redis Sentinel implementation
* Always-on TLS
* Support Single node installation
* Architectures: x86_64,s390x,ppc64le
* Different scaleconfig as small,medium and large for resource optimization
* Supported persistence using filestorage and blockstorage types
* Non-persistent Installation is supported

## Installing (Guidance)

* catalogsource, which makes the redis package available in embedded openshift catalog
* Use olm to create a subscription or install operator from the operator hub

verify the operator deployment by checking the operator pod
```bash
 $ oc get po
NAME                                     READY   STATUS    RESTARTS   AGE
ibm-redis-cp-operator-6d88f7bfb8-sdrvh   1/1     Running   0          21h
