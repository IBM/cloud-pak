#!/bin/bash
#
# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh and
# launch-impl.sh
# This implementation is specific to this IBM Guardium Data Security Center Operator
# Installation.

# Install complete case bundle
kubernetesCLI="oc"
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

err_exit() {
    echo >&2 -e "[ERROR] $1\n==================================================================================================================================\nFor TROUBLESHOOTING of IBM Common Services refer - https://www.ibm.com/docs/en/cpfs?topic=operator-troubleshooting\n==================================================================================================================================\nFor UNINSTALLATION of IBM Common Services refer - https://www.ibm.com/docs/en/cpfs?topic=online-uninstalling-foundational-services\n==================================================================================================================================\nFor PREPARATION, INSTALLTION and UNINSTALLATION of IBM Guardium Data Security Center and dependency services refer - https://www.ibm.com/docs/gdsc"
    exit 1
}

get_registryCLI() {
    if command -v docker >/dev/null 2>&1; then
        echo "docker"
    elif command -v podman >/dev/null 2>&1; then
        echo "podman"
    else
        err_exit "Neither Docker nor Podman is installed."
    fi
}
registryCLI="$(get_registryCLI)"

validate_pyyaml() {
    if ! python3 -c "import yaml" &>/dev/null ; then
        err_exit "The PyYAML python package is required but was not found on your system."
    fi
}

validate_config() {
    
    source "$scriptDir"/values.conf

    #validating cloud infra and online requirements.
    if [ -z $ONLINE_INSTALL ]; then
        err_exit "Mandatory parameter ONLINE_INSTALL is missing. Please verify configuration file contents are valid."
    elif [ $ONLINE_INSTALL != "true" ] && [ $ONLINE_INSTALL != "false" ]; then
        err_exit "Mandatory parameter ONLINE_INSTALL can only be true or false. Please verify configuration file contents are valid."
    elif [ -z $SKIP_INSTALL_ICS ]; then
        err_exit "Mandatory parameter SKIP_INSTALL_ICS is missing. Please verify configuration file contents are valid."   
    elif [ $SKIP_INSTALL_ICS != "true" ] && [ $SKIP_INSTALL_ICS != "false" ]; then
        err_exit "Mandatory parameter SKIP_INSTALL_ICS can only be true or false. Please verify configuration file contents are valid."
    elif [ -z $ENTITLED_REGISTRY ] || [ -z $ENTITLED_REGISTRY_USER ] || [ -z $ENTITLED_REGISTRY_PASS ] || [ -z $ICS_CATALOG_REGISTRY ]; then
        err_exit "Entitled Registry login information missing. Please verify configuration file contents are valid."
    elif [ $ENTITLED_REGISTRY_PASS = "change_this_to_your_entitlement_key" ]; then
        err_exit "Entitled registry password or entitlement key is not provided. Please verify configuration file contents are valid."
    elif [ -z $ICS_POSTGRES_REGISTRY_URL ] || [ -z $ICS_POSTGRES_REGISTRY_USER ] || [ -z $ICS_POSTGRES_REGISTRY_PASS ]; then
        err_exit "ICS Postgres Registry login information missing. Please verify configuration file contents are valid."
    elif [ $ICS_POSTGRES_REGISTRY_PASS = "change_this_to_your_entitlement_key" ]; then
        err_exit "ICS postgres registry password or entitlement key is not provided. Please verify configuration file contents are valid."
    elif [ -z $GI_DATA_NODE ]; then
        err_exit "Mandatory parameter GI_DATA_NODE is missing. Please verify configuration file contents are valid."
    elif [ -z $LABEL_DATA_NODE ]; then
        err_exit "Mandatory parameter LABEL_DATA_NODE is missing. Please verify configuration file contents are valid."
    elif [ $LABEL_DATA_NODE != "true" ] && [ $LABEL_DATA_NODE != "false" ]; then
        err_exit "Mandatory parameter LABEL_DATA_NODE can only be true or false. Please verify configuration file contents are valid."
    elif [ -z $NAMESPACE ]; then
        err_exit "Mandatory parameter NAMESPACE is missing, please verify configuration file contents are valid"
    elif [ -z $ICS_SIZE ]; then 
        err_exit "Missing mandatory parameters for ICS installation/validation. Please verify configuration file contents are valid."
    elif [ -z $CLOUD_INFRA ]; then
        err_exit "Mandatory parameter CLOUD_INFRA is missing, please verify configuration file contents are valid"
    elif [ -z $GI_INSTANCE_NAME ]; then
        err_exit "Mandatory parameter GI_INSTANCE_NAME is missing, please verify configuration file contents are valid"
    elif [ -z $GI_SIZE ]; then
        err_exit "Mandatory parameter GI_SIZE is missing, please verify configuration file contents are valid"
    elif [ $GI_SIZE != "values-xsmall" ] && [ $GI_SIZE != "values-small" ] && [ $GI_SIZE != "values-med" ] && [ $GI_SIZE != "values-large" ]; then
        err_exit "Mandatory parameter GI_SIZE can only be one of values-xsmall,values-small, values-med or values-large. Please verify configuration file contents are valid."
    elif [ -z $DOMAIN_NAME ] || [ -z $HOST_NAME ]; then
        err_exit "Mandatory parameters DOMAIN_NAME or HOST_NAME or both are missing. Please verify configuration file contents are valid."
    elif [ $CLOUD_INFRA != "ocp-generic" ] && [ -n $CLOUD_INFRA ]; then
        if [ -z $STORAGE_CLASS_RWO ] || [ -z $STORAGE_CLASS_RWX ]; then
            err_exit "Using cloud infrastructre $CLOUD_INFRA requires that you specify storage classes. Please verify configuration file contents are valid."
        fi
        if [ -z $BACKUP_STORAGECLASS_RWX ]; then
            err_exit "Using cloud infrastructre $CLOUD_INFRA requires that you specify backup storage classes. Please verify configuration file contents are valid."
        fi
    elif [ -z $APPLY_GI_CR ]; then
        err_exit "Mandatory parameter APPLY_GI_CR is missing. Please verify configuration file contents are valid."
    elif [ $APPLY_GI_CR != "true" ] && [ $APPLY_GI_CR != "false" ]; then
        err_exit "Mandatory parameter APPLY_GI_CR can only be true or false. Please verify configuration file contents are valid."
    fi

    #validating offline requirements.
    if [ $ONLINE_INSTALL == "false" ]; then
        if [ -z $LOCAL_REGISTRY_HOST ] || [ -z $LOCAL_REGISTRY_USER ] || [ -z $LOCAL_REGISTRY_PASS ]; then
            err_exit "Airgapped/Offline installation requires local registry information. Please verify configuration file contents are valid."
        fi
        if [ $LOCAL_REGISTRY_PASS = "change_this_to_your_local_registry_password" ]; then
            err_exit "Local registry password not provided. Please verify configuration file contents are valid."
        fi
    fi

    #validating optional parameters
    if [ -z $TAINT_DATA_NODE ] || [ -z $INGRESS_KEYSTORE ] || [ -z $INGRESS_CERT ] || [ -z $CUSTOM_NB_SCC ] || [ -z $INGRESS_CA ] || [ -z $SKIP_GI_PREINSTALL ] || [ -z $SKIP_GI_CATALOGS ] || [ -z $SKIP_GI_OPERATORS ] || [ -z $SKIP_GI_CR_TEMPLATE_CREATION ]; then 
        err_exit "Missing optional parameters. Please verify configuration file contents are valid." 
    elif [ $TAINT_DATA_NODE != "true" ] && [ $TAINT_DATA_NODE != "false" ]; then
        err_exit "Optional parameter TAINT_DATA_NODE can only be true or false. Please verify configuration file contents are valid."
    elif [ $SKIP_GI_PREINSTALL != "true" ] && [ $SKIP_GI_PREINSTALL != "false" ]; then
        err_exit "Optional parameter SKIP_GI_PREINSTALL can only be true or false. Please verify configuration file contents are valid."
    elif [ $SKIP_GI_CATALOGS != "true" ] && [ $SKIP_GI_CATALOGS != "false" ]; then
        err_exit "Optional parameter SKIP_GI_CATALOGS can only be true or false. Please verify configuration file contents are valid."
    elif [ $SKIP_GI_OPERATORS != "true" ] && [ $SKIP_GI_OPERATORS != "false" ]; then
        err_exit "Optional parameter SKIP_GI_OPERATORS can only be true or false. Please verify configuration file contents are valid."
    elif [ $SKIP_GI_CR_TEMPLATE_CREATION != "true" ] && [ $SKIP_GI_CR_TEMPLATE_CREATION != "false" ]; then
        err_exit "Optional parameter SKIP_GI_CR_TEMPLATE_CREATION can only be true or false. Please verify configuration file contents are valid."
    elif [ $ONLINE_INSTALL == "false" ]; then
        if [ -z $INSECURE_REGISTRY ]; then 
            err_exit "Missing optional parameter INSECURE_REGISTRY required for Airgapped/Offline installation. Please verify configuration file contents are valid."
        elif [ $INSECURE_REGISTRY != "true" ] && [ $INSECURE_REGISTRY != "false" ]; then
            err_exit "Optional parameter INSECURE_REGISTRY can only be true or false. Please verify configuration file contents are valid."
        fi
    fi
}

validate_registries() {
    #validating docker/podman login to the ics postgres,entitled and local registry.
    $registryCLI login $ICS_POSTGRES_REGISTRY_URL -u $ICS_POSTGRES_REGISTRY_USER -p $ICS_POSTGRES_REGISTRY_PASS
    if [ $? -eq 0 ]; then
       echo "[INFO] ICS postgres registry credentials validated with docker login"
    else
        err_exit "REGISTRY LOGIN FAILED: Invalid ICS postgres registry credentials provided, please verify the configuration file contents"
    fi

    $registryCLI login $ENTITLED_REGISTRY -u $ENTITLED_REGISTRY_USER -p $ENTITLED_REGISTRY_PASS
    if [ $? -eq 0 ]; then
        echo "[INFO] Entitled registry credentials validated with docker login"
    else
        err_exit "REGISTRY LOGIN FAILED: Invalid entitled registry credentials provided, please verify the configuration file contents"
    fi
    if [ $ONLINE_INSTALL == "false" ]; then
        $registryCLI login $LOCAL_REGISTRY_HOST -u $LOCAL_REGISTRY_USER -p $LOCAL_REGISTRY_PASS
        if [ $? -eq 0 ]; then 
            echo "[INFO] Local registry credentials validated with docker login"
        else
            err_exit "REGISTRY LOGIN FAILED: Invalid local registry credentials provided, please verify the configuration file contents"
        fi
    fi

    #preparing variables to inject into functions.
    if [ $ONLINE_INSTALL == "false" ]; then
        R1=$LOCAL_REGISTRY_HOST
        R2=$LOCAL_REGISTRY_HOST
        R_USER=$LOCAL_REGISTRY_USER
        R_PASS=$LOCAL_REGISTRY_PASS
    else
        R1=$ENTITLED_REGISTRY
        R2=$ICS_CATALOG_REGISTRY
        R_USER=$ENTITLED_REGISTRY_USER
        R_PASS=$ENTITLED_REGISTRY_PASS
    fi
}

airgap_setup() {
    echo "[INFO] Generate mirror manifests"
    #Generate mirror manifests
    $kubernetesCLI ibm-pak generate mirror-manifests \
    $CASE_NAME \
    $LOCAL_REGISTRY_HOST \
    --version $CASE_VERSION
    sleep 30

    echo "[INFO] Mirror the installation images to the local registry"
    #Mirror the installation images to the local registry.
    $kubernetesCLI image mirror \
    -f ~/.ibm-pak/data/mirror/$CASE_NAME/$CASE_VERSION/images-mapping.txt \
    -a $REGISTRY_AUTH_FILE \
    --filter-by-os '.*' \
    --insecure \
    --skip-multiple-scopes \
    --max-per-registry=1 \
    --continue-on-error=false > "${LOCAL_INSTALL_DIR}/my-mirror-progress.txt"
    if [ $? -ne 0 ]; then
        err_exit "Auto-install failed mirroring the installation images to the local registry during the airgap-setup, check the mirroring logs in '${LOCAL_INSTALL_DIR}/my-mirror-progress.txt'"
    fi

    #Configure the cluster and content image source policy for air gap installation.
    $kubernetesCLI apply -f  $HOME/.ibm-pak/data/mirror/$CASE_NAME/$CASE_VERSION/image-content-source-policy.yaml
    if [ $? -ne 0 ]; then
    err_exit "Auto-install failed to configure the cluster and content image source policy during the airgap-setup"
    fi

    #configuring the cluster to allow insecure registry.
    if [ $INSECURE_REGISTRY == "true" ]; then
        echo "[INFO] The cluster is configured to allow insecure registry"
        $kubernetesCLI patch image.config.openshift.io/cluster --type=merge -p '{"spec":{"registrySources":{"insecureRegistries":["'$LOCAL_REGISTRY_HOST'"]}}}'
    fi

    for (( count=0; count<=30; count++ )); do
        nodesStatus="$(kubectl get nodes --no-headers)"
        healthy="true"
        while IFS= read -r line; do
            nodeName="$(echo "$line" | awk '{print $1}')"
            nodeStatus="$(echo "$line" | awk '{print $2}')"
            if [[ $nodeStatus != "Ready" ]]; then
            echo "[INFO] Node $nodeName is in '$nodeStatus' state."
            healthy="false"
            fi
        done <<< "$nodesStatus"
        if [[ $healthy == "true" ]]; then
            echo "[INFO] All nodes are in a healthy state, will continue checking for 5 minutes"
        else
            echo "[INFO] Some nodes are not healthy, will continue checking for 5 minutes"
        fi
        if [[ $healthy == "false" ]] && [[ $count == 30 ]]; then
            err_exit "Timeout waiting for nodes Ready status."
        fi
        sleep 10
    done
    echo "[SUCCESS] Mirroring the installation images to local registry completed and cluster nodes are in a healthy state"
}

namespace_setup(){
    local namespace=$1
    if ! $kubernetesCLI get namespace $namespace; then
        $kubernetesCLI create namespace $namespace
    else 
        echo "[INFO] Namespace $namespace already exist, skipping creation"
    fi
}

check_catsrc(){
    local namespace=$1
    catalog=$2
    for (( count=0; count<=30; count++ )); do
        catsrcName="$($kubernetesCLI get catsrc --no-headers -n "$namespace" | grep "$catalog" | awk -F " " '{print $1}')"  
        catsrcStatus="$($kubernetesCLI get catsrc $catsrcName -n "$namespace" -o jsonpath='{.status.connectionState.lastObservedState}' --ignore-not-found=true)"
        if [[ $catsrcStatus != "READY" ]]; then
            if [[ $count -eq 30 ]]; then
                err_exit "Timeout for Catalog Source $catsrcName to be READY, current status - $catsrcStatus"
            else
                echo "[INFO] Waiting for Catalog Source $catsrcName to be READY, current status - $catsrcStatus"
                sleep 10
            fi
        else
            echo "[INFO] Catalog Source $catsrcName is READY"
            break
        fi
    done
}

check_csv(){
    local namespace=$1
    operator=$2
    for (( count=0; count<=30; count++ )); do
        csvName="$($kubernetesCLI get csv --no-headers -n "$namespace" | grep "$operator" | awk -F " " '{print $1}')"  
        csvStatus="$($kubernetesCLI get csv $csvName -n "$namespace" -o jsonpath='{.status.phase}' --ignore-not-found=true)"
        if [[ $csvStatus != "Succeeded" ]]; then
            if [[ $count -eq 30 ]]; then
                err_exit "Timeout waiting for CSV installation : $csvName : $csvStatus"
            else
                echo "[INFO] Waiting for CSV installation : $csvName : $csvStatus"
                sleep 10
            fi
        else
            echo "[INFO] CSV installation successful : $csvName : $csvStatus"
            break
        fi
    done
}

install_cert-manager(){
    export CERT_MANAGER_INVENTORY_SETUP=ibmCertManagerOperatorSetup
    if [ "$CLOUD_INFRA" == "eks" ]; then
        if ! $kubernetesCLI get csv -n olm | grep packageserver; then
            err_exit "OLM resources not found"
        fi
        if ! $kubernetesCLI get svc -n ingress-nginx >/dev/null 2>&1; then
            err_exit "ingress-nginx service not found"
        fi
    fi
    #Install IBM Cert Manager using the installation commands
    echo "[INFO] Installing IBM Cert Manager"
    $kubernetesCLI ibm-pak launch $CASE_NAME \
        --version $CASE_VERSION \
        --namespace openshift-marketplace \
        --inventory $CERT_MANAGER_INVENTORY_SETUP \
        --action install-catalog \
        --args "--inputDir ${LOCAL_CASE_DIR}"
    if [ $? -ne 0 ]; then
        err_exit "IBM Cert Manager Catalog Source installation failed"
    fi
    check_catsrc "openshift-marketplace" "ibm-cert-manager"

    $kubernetesCLI ibm-pak launch $CASE_NAME \
        --version $CASE_VERSION \
        --namespace ibm-cert-manager \
        --inventory $CERT_MANAGER_INVENTORY_SETUP \
        --action install-operator \
        --args "--inputDir ${LOCAL_CASE_DIR}"
    if [ $? -ne 0 ]; then
        err_exit "Auto-install failed to install the operator for IBM Cert Manager"
    fi
    check_csv "ibm-cert-manager" "ibm-cert-manager-operator"
    echo "[SUCCESS] IBM Cert Manager Installation Completed"
}

install_ics() {
    if [ $SKIP_INSTALL_ICS == "false" ]; then
        export ICS_CASE_INVENTORY_SETUP=ibmCommonServiceOperatorSetup

        #Install ICS using the installation commands
        echo "[INFO] Installing IBM Common Services"
        $kubernetesCLI ibm-pak launch $CASE_NAME \
            --version $CASE_VERSION \
            --namespace $NAMESPACE\
            --inventory $ICS_CASE_INVENTORY_SETUP \
            --action install-catalog \
            --args "--registry ${R2} --inputDir ${LOCAL_CASE_DIR}"
        if [ $? -ne 0 ]; then
            err_exit "IBM Common Services Catalog Source installation failed"
        fi
        check_catsrc "openshift-marketplace" "opencloud-operators"

        KS_FLAG="false"
        if [ "$CLOUD_INFRA" == "eks" ]; then
            KS_FLAG="true"
        fi
        $kubernetesCLI ibm-pak launch $CASE_NAME \
            --version $CASE_VERSION \
            --namespace $NAMESPACE \
            --inventory $ICS_CASE_INVENTORY_SETUP \
            --action install-operator \
            --args "--size $ICS_SIZE --ks_flag $KS_FLAG --hostname $HOST_NAME --registry $ICS_POSTGRES_REGISTRY_URL --user $ICS_POSTGRES_REGISTRY_USER --pass $ICS_POSTGRES_REGISTRY_PASS --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR}"
        if [ $? -ne 0 ]; then
            err_exit "IBM Common Services Operator installation failed"
        fi
        for icsOperator in "ibm-common-service-operator" "operand-deployment-lifecycle-manager" "ibm-events-operator"; do
            check_csv "$NAMESPACE" "$icsOperator"
        done
        for (( count=0; count<=30; count++ )); do
            icsCredsSecret="$($kubernetesCLI get secret platform-auth-idp-credentials -n $NAMESPACE --no-headers --ignore-not-found | wc -l )"
            operandRegistryStatus="$($kubernetesCLI get operandRegistry common-service -n $NAMESPACE -ojsonpath="{.status.phase}")"
            operandRequestStatus="$($kubernetesCLI get operandRequest common-service -n $NAMESPACE -ojsonpath="{.status.phase}")"

            if [ $icsCredsSecret -eq 1 ] && [ $operandRegistryStatus = "Running" ] && [ $operandRequestStatus = "Running" ]; then
                echo "[INFO] IBM Common Services is Ready."
                break
            elif [ $count -eq 30 ]; then
                err_exit "Timeout waiting for IBM Common Services resources to be in ready status."
            else
                echo "[INFO] Waiting for IBM Common Services resources to be ready"
                sleep 10
            fi
        done 
        echo "[SUCCESS] IBM Common Services Installation Completed" 
    else
       $kubernetesCLI get project $NAMESPACE &> /dev/null || err_exit "IBM Common Services namespace not found. Verify parameter NAMESPACE in configuration file, or enable IBM Common Services automatic installation".
        echo "[INFO] Skipping ICS Installation"
    fi  
}

install_gi_pre-install(){ 
    EKS_CLUSTER="false"
    ODF="false"
    if [ "$CLOUD_INFRA" == "eks" ]; then
        EKS_CLUSTER="true"
    fi  
    ]
    if [ "$CLOUD_INFRA" = "aws-odf" ] || \
    [ "$CLOUD_INFRA" = "ibm-vpc-odf" ] || \
    [ "$CLOUD_INFRA" = "gcp-dedicated-odf" ]; then
        ODF="true"
    fi

    $kubernetesCLI ibm-pak launch $CASE_NAME \
    --version "$CASE_VERSION" \
    --namespace "$NAMESPACE" \
    --inventory "$GI_CASE_INVENTORY_SETUP" \
    --action pre-install \
    --args "-n $NAMESPACE \
            -h $GI_DATA_NODE \
            -l $LABEL_DATA_NODE \
            -t $TAINT_DATA_NODE \
            -k $INGRESS_KEYSTORE \
            -f $INGRESS_CERT \
            -c $INGRESS_CA \
            -z $CUSTOM_NB_SCC \
            -e $EKS_CLUSTER \
            -z $ODF"
    if [ $? -ne 0 ]; then
        err_exit "Auto-install failed to successfully complete the pre-install step while deploying IBM Guardium Data Security Center"
    fi
}

install_gi_catalogs(){
    if [ $ONLINE_INSTALL == "true" ]; then
        $kubernetesCLI ibm-pak launch $CASE_NAME \
            --version $CASE_VERSION \
            --namespace openshift-marketplace \
            --inventory $GI_CASE_INVENTORY_SETUP \
            --action install-catalog \
            --args "--inputDir ${LOCAL_CASE_DIR}"
    else 
        $kubernetesCLI ibm-pak launch $CASE_NAME \
            --version $CASE_VERSION \
            --namespace openshift-marketplace \
            --inventory $GI_CASE_INVENTORY_SETUP \
            --action install-catalog \
            --args "--registry $LOCAL_REGISTRY_HOST --inputDir ${LOCAL_CASE_DIR}"
    fi
    if [ $? -ne 0 ]; then
        err_exit "Auto-install failed to successfully complete the dependency catalog service installation while deploying IBM Guardium Data Security Center"
    fi
    for depCatsrc in "ibm-redis-cp" "db2u" "ibm-guardium-insights"; do
        check_catsrc "openshift-marketplace" "$depCatsrc"
    done     
}

install_gi_operators(){    
    $kubernetesCLI ibm-pak launch $CASE_NAME \
        --version $CASE_VERSION \
        --namespace $NAMESPACE \
        --inventory $GI_CASE_INVENTORY_SETUP \
        --action install-operator \
        --args "--registry ${R1} --user ${R_USER} --pass ${R_PASS} --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR} --ks_flag ${EKS_CLUSTER}"
    if [ $? -ne 0 ]; then
        err_exit "Auto-install failed to successfully complete the dependency operator installation while deploying IBM Guardium Data Security Center"
    fi
    for depOperators in "ibm-redis-cp" "db2u" "ibm-guardium-insights"; do
        check_csv "$NAMESPACE" "$depOperators"
    done 
}

create_gi_cr_template(){
    CLOUD_INFRA="$(echo "$CLOUD_INFRA" | tr '[:upper:]' '[:lower:]')"

    if [ $CLOUD_INFRA == "aws-efs" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-aws-efs.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "aws-odf" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-aws-odf.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "aro-csi-driver" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-aro-csi-driver.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "gcp-iaas-csi-driver" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-gcp-Iaas-csi-driver.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "gcp-dedicated-csi-driver" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-gcp-dedicated-csi-driver.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "gcp-dedicated-odf" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-gcp-dedicated-odf.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "non-aro-csi-driver" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-non-aro-csi-driver.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "vsphere" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-vsphere.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "ibm-classic" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-ibm-classic.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "ibm-vpc-odf" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" "${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-ibm-vpc-odf.yaml" > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "ocp-generic" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" ${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-ocp-generic.yaml > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    elif [ $CLOUD_INFRA == "eks" ]; then
        sed -e "s|GI_INSTANCE_NAME|$GI_INSTANCE_NAME|g" -e "s|GI_SIZE|$GI_SIZE|g" -e "s|NAMESPACE|$NAMESPACE|g" -e "s|HOST_NAME|$HOST_NAME|g" -e "s|DOMAIN_NAME|$DOMAIN_NAME|g" -e "s|STORAGE_CLASS_RWO|$STORAGE_CLASS_RWO|g" -e "s|STORAGE_CLASS_RWX|$STORAGE_CLASS_RWX|g" -e "s|BACKUP_STORAGECLASS_RWX|$BACKUP_STORAGECLASS_RWX|g" ${LOCAL_CASE_DIR}/ibm-guardium-data-security-center/inventory/guardiumDataSecurityCenterOperator/files/samples/AIO/gdsc-custom-eks.yaml > "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
        if [ $? -ne 0 ]; then
            err_exit "Sample CR creation failed for IBM Guardium Data Security Center "
        fi
    else
        err_exit "Invalid infrastructure options provided, please verify from the values.conf file"
    fi
    echo "[INFO] Sample CR for IBM Guardium Data Security Center created"
    echo -e "\n==================================================================================================================================\n"
    cat "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
    echo -e "\n==================================================================================================================================\n"
    echo "[INFO] Sample CR shown above is present here - ${LOCAL_INSTALL_DIR}/sample-cr.yaml"
    if [ $APPLY_GI_CR == "true" ]; then
        echo "[INFO] Applying the sample CR for IBM Guardium Data Security Center instance creation"
        $kubernetesCLI apply -f "${LOCAL_INSTALL_DIR}/sample-cr.yaml"
    else
        echo "[INFO] Not applying the sample CR for IBM Guardium Data Security Center instance creation"
    fi
}

install_gi() {
    export GI_CASE_INVENTORY_SETUP=install
    if [ $SKIP_GI_PREINSTALL == "false" ]; then
        install_gi_pre-install
    else
        echo "[INFO] Skipping pre-install step for IBM Guardium Data Security Center"
    fi
    if [ $SKIP_GI_CATALOGS == "false" ]; then
        install_gi_catalogs
    else 
        echo "[INFO] Skipping catalog installation of dependencies for IBM Guardium Data Security Center"
    fi
    if [ $SKIP_GI_OPERATORS == "false" ]; then
        install_gi_operators
    else 
        echo "[INFO] Skipping operators installation for IBM Guardium Data Security Center"
    fi
    if [ $SKIP_GI_CR_TEMPLATE_CREATION == "false" ]; then
        create_gi_cr_template
    else 
        echo "[INFO] Skipping instance deployment for IBM Guardium Data Security Center"
    fi
}

autoinstall() {
    validate_pyyaml
    validate_config
    validate_registries
    if [ $ONLINE_INSTALL == "false" ]; then
        echo "[INFO] Airgapped Installation of IBM Guardium Data Security Center"
        airgap_setup
    else
        echo "[INFO] Online Installation of IBM Guardium Data Security Center"
    fi
    if [ $CLOUD_INFRA == "eks" ]; then
        export IBMPAK_LAUNCH_SKIP_PREREQ_CHECK=true
    fi
    namespace_setup "ibm-cert-manager"
    install_cert-manager
    namespace_setup "$NAMESPACE"
    install_ics
    install_gi
    echo "[SUCCESS] IBM Guardium Data Security Center Installation Completed"
}

autoinstall
