# (C) Copyright IBM Corp. 2023  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the redis operator
 
inventory="guardiumDataSecurityCenterOperator" # default inventory item
crd_file="${casePath}/inventory/${inventory}/files/deploy/crds.yaml"
rbac_file="${casePath}/inventory/${inventory}/files/deploy/rbac.yaml"
manager_file="${casePath}/inventory/${inventory}/files/deploy/manager.yaml"

#Inventory for installing via OLM
subscriptionName="ibm-guardium-insights-operator-subscription"
channelName="v3.5"
catalogNamespace="openshift-marketplace"
catalogSource="ibm-guardium-insights-operator-catalog"

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    echo "no dependent catalogs"
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operatorgroup.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    # if [[ ${recursive_action} -eq 1 ]]; then
    #     install_dependent_catalogs
    # fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    if [[ -z $registry ]]; then
        tee >($kubernetesCLI apply ${dryRun} -f -) <"${catsrc_file}" | cat
    else
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
        # local catsrc_image_tmp="$(echo "${catsrc_image_orig}" | sed -e "s#.*/##")"
        # local catsrc_image_mod="${registry}/${catsrc_image_tmp}"
        
        # apply catalog source
         sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}


# Install utilizing via OLM
install_operator() {

    echo "-------------Installing guardiumDataSecurityCenterOperator-------------"

    # Verify arguments are valid
    validate_install_args

    # install all operators of subcases first
    # if [[ ${recursive_action} -eq 1 ]]; then
    #     install_dependent_operators
    # fi

    ext_deploy=$($kubernetesCLI get deploy -n "${namespace}" | grep guardiuminsights-controller-manager | wc -l)

    # Uninstall the NON-OLM GDSC Operator
    if [[ ext_deploy -ne 0 ]]; then
        echo "Detected non-OLM Guardium Data Security Center Operator, Running Migration code"

        # Step 1: Delete Deployment and Service Account of NON-OLM Operator
        $kubernetesCLI delete sa -n "${namespace}" guardiuminsights-manager-sa --ignore-not-found=true ${dryRun}
        $kubernetesCLI delete deploy -n "${namespace}" guardiuminsights-controller-manager --ignore-not-found=true ${dryRun}

        # Step 2: Apply the updated resources (manager_file, rbac_file)
        validate_file_exists "${rbac_file}"
        sed <"${rbac_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat
        validate_file_exists "${manager_file}"
        sed <"${manager_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat
    fi
    
    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${catalogSource}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${catalogSource}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" "s|REPLACE_NAMESPACE|${namespace}|g; s|REPLACE_CHANNEL_NAME|$channelName|g; s|REPLACE_CATALOG_SOURCE|${catalogSource}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    check_crd

    gicrDeployed=$($kubernetesCLI get guardiuminsights.gi.ds.isc.ibm.com --no-headers --ignore-not-found -n "$namespace" -oname)
    gsp=$($kubernetesCLI get guardiumdatasecuritycenters.gi.ds.isc.ibm.com --no-headers --ignore-not-found -n "$namespace" -oname)
    if [[ -z "$gicrDeployed" || -n "$gsp" ]]; then
      echo "[INFO] Custom Resource upgrade not applicable. Operator installed successfully"
      return
    fi

    gicrJson=$($kubernetesCLI get -n "$namespace" $gicrDeployed -ojson)
    name=$(jq '.metadata.name' <<< $gicrJson)
    knownKeys="guardiumInsightsGlobal license version"

    # shellcheck disable=SC2089
    gdsc='{
      "apiVersion": "gi.ds.isc.ibm.com/v1",
      "kind": "GuardiumDataSecurityCenter",
      "metadata": {
        "name": '"$name"'
      },
      "spec": {
        "capabilities": [
          {
            "name": "platform",
            "enabled": true,
            "configurations": {}
          }
        ]
      }
    }'

    for key in $(jq -r '.spec | keys[]' <<< $gicrJson); do
      value=$(jq -cr --arg key $key '.spec[$key]' <<< $gicrJson)

      argType="arg"
      if jq -e . > /dev/null 2>&1 <<< "$value"; then
        argType="argjson"
      fi

      # if its a known key in the new cr we can do a straight drop to the new cr
      if [[ $knownKeys =~ $key ]]; then
        if [[ "$key" == "guardiumInsightsGlobal" ]]; then
            key="guardiumGlobal"
            insights=$(jq '.insights' <<< "$value")
            if [[ $insights != "null" ]]; then
              value=$(jq -r --$argType insights "$insights" '.instance=$insights | del(.insights)' <<< $value)
            fi
        fi

        gdsc=$(jq -r --arg key $key --$argType value "$value" '.spec[$key]=$value' <<< $gdsc)
      else
        # for the initial upgrade it will just be platform and qspm supported, this will need to handle other overrides when we cross that bridge
        gdsc=$(jq  -c --arg key $key --$argType value $value '(.spec.capabilities | .[] | select(.name=="platform") | .configurations[$key]) |= $value' <<< $gdsc)
      fi
    done

    if ! $kubernetesCLI apply -n $namespace -f - <<< $gdsc; then
      echo "[ERROR] Failed to apply Guardium Data Security Center upgraded custom resource"
      exit 1
    fi
    echo "[INFO] Guardium Data Security Center upgraded custom resource successfully upgraded"
}

function check_csv() {
    local maxRetry=20
    local operatorName="$1"
    local subscriptionNamespace="$2"

    # Check if the CSV for a specific operator has been successfully created
    for ((retry = 0; retry <= ${maxRetry}; retry++)); do
        csv=$($kubernetesCLI get clusterserviceversions.operators.coreos.com --no-headers -n "${subscriptionNamespace}" | grep "${operatorName}" | awk '{print $1}')
        status=$($kubernetesCLI get clusterserviceversions.operators.coreos.com "${csv}" -n "${subscriptionNamespace}" -o jsonpath='{.status.phase}' 2>/dev/null)
        if [[ "${status}" != "Succeeded" ]]; then
            if [[ ${retry} -eq ${maxRetry} ]]; then
                err_exit "${operatorName} CSV was not created."
            else
                echo "[INFO] Waiting for ${operatorName} CSV to be created..."
                sleep 60
                continue
            fi
        else
            echo "[INFO] ${operatorName} CSV has been successfully created."
            break
        fi
    done
}

# wait for the crd to be deployed
function check_crd() {
    local maxRetry=20

    # Check if the CSV for a specific operator has been successfully created
    for ((retry = 0; retry <= ${maxRetry}; retry++)); do
        if $kubernetesCLI get customresourcedefinitions.apiextensions.k8s.io guardiumdatasecuritycenters.gi.ds.isc.ibm.com --no-headers; then
          return 0
        else
          echo "[INFO] Waiting for guardiumdatasecuritycenters CRD to be created..."
          sleep 60
          continue
        fi

    done
    err_exit "guardiumdatasecuritycenters.gi.ds.isc.ibm.com CRD was not deployed."
}

# Install utilizing default CLI method
install_operator_native() {

    install_operator

    # echo "-------------Installing guardiumDataSecurityCenterOperator-------------"

    # validate_file_exists "${crd_file}"
    # validate_file_exists "${rbac_file}"
    # validate_file_exists "${manager_file}"
    # sed <"${crd_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    # sed <"${rbac_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    # sed <"${manager_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# install operand custom resources
apply_custom_resources() {
    echo "No Actions required for this CASE"
    # echo "-------------Applying custom resources-------------"

    # local cr="${casePath}"/inventory/"${inventory}"/files/redis.databases.cloud.ibm.com_v1_redissentinel_cr.yaml

    # validate_file_exists "$cr"

    # sed <"${cr}" -e "s/accept: false/accept: true/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# deletes the catalog source and operator group
uninstall_catalog() {
    # echo "No Actions required for this CASE"
    # validate_install_catalog "uninstall"

    # # uninstall all catalogs of subcases first
    # if [[ ${recursive_action} -eq 1 ]]; then
    #     uninstall_dependent_catalogs
    # fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true 
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling guardiumDataSecurityCenterOperator-------------"

    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency

    # delete crds (not OLM stuff)
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/deploy/crds.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done    
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
     echo "-------------Uninstalling guardiumDataSecurityCenterOperator-------------"
     
     validate_file_exists "${crd_file}"
     sed <"${crd_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat
     validate_file_exists "${rbac_file}"
     sed <"${rbac_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat
     validate_file_exists "${manager_file}"
     sed <"${manager_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat

}

delete_custom_resources() {
    $kubernetesCLI get $($kubernetesCLI get backups.gi.ds.isc.ibm.com -oname -n=${namespace}) -n=${namespace}
    $kubernetesCLI get $($kubernetesCLI get restores.gi.ds.isc.ibm.com -oname -n=${namespace}) -n=${namespace}
    $kubernetesCLI get $($kubernetesCLI get tenantgucs.gi.ds.isc.ibm.com -oname -n=${namespace}) -n=${namespace}
    $kubernetesCLI get $($kubernetesCLI get tenantminisnifs.gi.ds.isc.ibm.com -oname -n=${namespace}) -n=${namespace}
    $kubernetesCLI get $($kubernetesCLI get guardiumdatasecuritycenters.gi.ds.isc.ibm.com -oname -n=${namespace}) -n=${namespace}
}
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --catalogSource)
        catalogSource="$val"
        ;;
    esac
}
