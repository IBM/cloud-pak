# Install IBM Guardium Data Security Center Operator

* Login to case:
```
  oc login -a https://cp-console.apps.<env>.example.ibm.com --skip-ssl-validation -u <user> -p <password> -n <namespase>
```

* Install Operator:
```
  oc ibm-pak launch -case <case.yaml> --namespace <<namespace> --inventory guardiumDataSecurityCenterOperator --action install-operator
```