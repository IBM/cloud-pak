# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the redis operator

inventory="kedaOperator" # default inventory item
subscriptionName="openshift-custom-metrics-autoscaler-operator"
channelName="stable" # need to change ? 
catalogNamespace="openshift-marketplace"
catalogSource="redhat-operators"
kedanamespace="openshift-keda"

# ----- INSTALL ACTIONS -----

# # Installs the catalog source and operator group of any dependencies
# install_dependent_catalogs() {
#     echo "no dependent catalogs"
# }

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {
    # oc create ns ${kedanamespace}

    # echo "check for any existing operator group in ${kedanamespace} ..."

    # if [[ $($kubernetesCLI get og -n "${kedanamespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
    #     echo "found operator group"
    #     $kubernetesCLI get og -n "${kedanamespace}" -o yaml
    #     return
    # fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    operator_groups=$(oc get operatorgroup -n "$namespace" --no-headers | wc -l)
    if [ "$operator_groups" -gt 0 ]; then
        echo "Operator groups exist in namespace $namespace, skipping."
    else
        echo "No operator groups found in namespace $namespace, creating."
        sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
        echo "done"

    fi
}

install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    parse_dynamic_args
    if [[ "${non_ocp}" == "true" ]]; then
        return 0
    fi
    
    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${catalogSource}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${catalogSource}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" "s|REPLACE_NAMESPACE|${namespace}|g; s|REPLACE_CHANNEL_NAME|$channelName|g; s|REPLACE_CATALOG_SOURCE|${catalogSource}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    # sleep 20
    # echo "patching"
    # echo ${namespace}
    # oc patch ip -n ${namespace} `oc get ip -n ${namespace}  | grep custom-metrics-autoscaler.v2 | awk '$1 {print $1}'` --type merge --patch '{"spec":{"approved":true}}'
    # # apply_custom_resources
    keda_custom_resource_validation
}

# install operand custom resources
apply_custom_resources() {
    # echo "No Actions required for this CASE"

    echo "-------------Applying custom resources-------------"

    local cr="${casePath}"/inventory/"${inventory}"/files/all/keda_controller.yaml

    validate_file_exists "$cr"

    sed <"${cr}" "s|REPLACE_KEDA_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

}

keda_custom_resource_validation() {  
deployment_name=custom-metrics-autoscaler-operator
retries=50
interval=10
index=0

echo "-------------Applying KEDA resources-------------"
# Initial sleep
sleep 10
# Initial check of pod status
Z=$(oc get deployment/"$deployment_name" -n "$namespace" --output=jsonpath='{.status.conditions[?(@.type=="Available")].status}' | grep "True" |  wc -l) 
X=$?
# echo "i am x" $X
# echo "i am z:" $Z 
while [ "X$X" != "X0" -o $Z -eq 0 ]
do
    echo "Waiting for KEDA pods to be ready, Number should be not 0, number: $Z"

    if [ "$index" -eq "$retries" ]; then
        echo "error while installing KEDA GI"
        exit 1
    fi
    sleep "$interval"
    ((index++))
    # Check pod status in each iteration
    Z=$(oc get deployment/"$deployment_name" -n "$namespace" --output=jsonpath='{.status.conditions[?(@.type=="Available")].status}' | grep "True" |  wc -l)
    X=$?;
    if [[ $Z -ne 0 ]]; then
        echo "running"
        break
    fi
    echo "Waiting for KEDA pods to be in ready stage [$(($retries - $index)) retries left]"
done

echo "----------------------KEDA Resource Completed---------------------------" 
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency

    # delete crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    done
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/all/keda_controller.yaml
    validate_file_exists "$cr"
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --catalogSource)
        catalogSource="$val"
        ;;
    esac
}
