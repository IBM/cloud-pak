# kedaOperator


This guide explains how to install the CMA(KEDA) Operator on OpenShift, including both connected and disconnected (airgap) environments.
`kedaOperator` inventory item contains the resources required for installing the IBM Operator for Openshift cma(keda). A cluster scoped permissions is required while installing this inventory item since it involves installing cluster resources like crds, clusterroles and clusterrolebindings.

## Prerequisites

- OpenShift 4.16.x or higher
- For disconnected installation:
  - Linux machine with:
    - `oc-mirror` plugin
    - `podman` or `docker`
    - Internet access (for initial image mirroring)

## Installation Methods

### Connected Environment

In a connected environment, the CMA(Openshift KEDA) Operator will be installed automatically via the IBM CASE bundle. No additional steps are required.

### Disconnected Environment (Airgap)

Follow these steps to install the KEDA Operator in a disconnected environment.

If you are using `oc adm catalog mirror` or `oc adm release mirror` to clone `redhat-operator-index` , you can skip this guide. This means you already have all redhat-operator-index images, including the CMA image, as part of the operator list. In this case, we expect you to have both ImageContentSourcePolicy and CatalogSource configured correctly to enable proper image pulling and operator catalog availability.

before start please go to notes and read about disconnected installations, refer to the [OpenShift Documentation](https://docs.openshift.com/container-platform/4.16/installing/disconnected_install/

#### 1. Install Required Tools

##### Install oc-mirror
Option 1: Download from Red Hat OpenShift Console
- Visit [OpenShift Downloads](https://console.redhat.com/openshift/downloads)
- Download "OpenShift Client (oc) mirror plugin"

Option 2: Direct download via CLI
```bash
curl -O https://mirror.openshift.com/pub/openshift-v4/x86_64/clients/ocp/stable/oc-mirror.tar.gz
tar -xvf oc-mirror.tar.gz
chmod +x ./oc-mirror
sudo mv ./oc-mirror /usr/local/bin/
```

##### Configure Registry Access
1. Log in to your private registry:
```bash
MIRROR_REGISTRY=docker.registry.example.net:5000
podman login ${MIRROR_REGISTRY}
```

#### 2. Prepare Pull Secret

1. Download your pull secret from [Red Hat Console](https://console.redhat.com/openshift/install/pull-secret)

2. Convert pull secret to JSON format:
```bash
cat ./pull-secret | jq . > /path/to/pull-secret.json
```

3. Extract registry.redhat.io credentials:
```bash
# Decode the auth string
echo -n "YOUR_AUTH_STRING" | base64 -d
# This will output: username:password
```

4. Log in to registry.redhat.io:
```bash
podman login registry.redhat.io
```

#### 3. Mirror Images

Choose one of the following methods based on your environment:

##### Method A: Direct Mirroring (with registry access)

1. Create imageset configuration:
```yaml
apiVersion: mirror.openshift.io/v1alpha2
kind: ImageSetConfiguration
storageConfig:
  registry:
    imageURL: ${MIRROR_REGISTRY}
    skipTLS: true
mirror:
  operators:
    - catalog: registry.redhat.io/redhat/redhat-operator-index:v4.16
      packages:
        - name: openshift-custom-metrics-autoscaler-operator
          channels:
            - name: stable
              minVersion: 2.14.1-467
              maxVersion: 2.14.1-467
```
- Replace `${MIRROR_REGISTRY}` with your actual registry URL

2. Mirror the images:
```bash
oc mirror --config=./imageset-config.yaml docker://${MIRROR_REGISTRY}
```
or another example with skip-tls
```bash
oc mirror --config=./imageset-config.yaml docker://${MIRROR_REGISTRY} --dest-skip-tls
```
- Replace `${MIRROR_REGISTRY}` with your actual registry URL

##### Method B: Indirect Mirroring (without registry access)

1. Create imageset configuration:
```yaml
apiVersion: mirror.openshift.io/v1alpha2
kind: ImageSetConfiguration
storageConfig:
  local:
    path: ./mirror-data
mirror:
  operators:
    - catalog: registry.redhat.io/redhat/redhat-operator-index:v4.16
      packages:
        - name: openshift-custom-metrics-autoscaler-operator
          channels:
            - name: stable
              minVersion: 2.14.1-467
              maxVersion: 2.14.1-467
```

2. Download images to local storage:
```bash
oc mirror --config=imageset-config.yaml file://mirror-data
```

3. Transfer the mirror-data directory to a machine with registry access

4. Upload images to registry:
```bash
oc-mirror --from mirror_seq1_000000.tar docker://${MIRROR_REGISTRY}
```
or another example with skip-tls
```bash
oc-mirror --from mirror_seq1_000000.tar docker://${MIRROR_REGISTRY} --dest-skip-tls
```

#### 4. Configure Image Content Source Policy
After oc-mirror command completes, move into the workspace directory that was generated:
```bash
cd oc-mirror-workspace/
```
Cd into the results directory. The directory name will vary, but it typically follows the format `results-<timestamp>/`.

Example:
```bash
cd results-1639608409/  # Replace with your generated directory name
```

Check if the required YAML files for `ImageContentSourcePolicy` and `CatalogSource` are present:

```bash
ls -l | grep -E "ImageContentSourcePolicy|CatalogSource"
```

Copy and apply the configurations to your OpenShift cluster:

```bash
oc apply -f ImageContentSourcePolicy.yaml
oc apply -f CatalogSource.yaml
```

**Note**: After applying the ICSP, the OpenShift nodes will automatically reload to apply the new image policy. This process may take several minutes.



## Notes

- Replace `${MIRROR_REGISTRY}` with your actual registry URL
- Adjust OpenShift version (v4.16) and KEDA operator version as needed
- For detailed information about disconnected installations, refer to the [OpenShift Documentation](https://docs.openshift.com/container-platform/4.16/installing/disconnected_install/installing-mirroring-disconnected.html) 
- How to use the oc-mirror plug-in to mirror operators, refer to the [How to use the oc-mirror plug-in to mirror operators](https://access.redhat.com/solutions/6994677)

## Troubleshooting

If you encounter TLS-related issues for oc-mirror, ensure your registry's certificates are properly configured and consider using `--dest-skip-tls` only in test environments.