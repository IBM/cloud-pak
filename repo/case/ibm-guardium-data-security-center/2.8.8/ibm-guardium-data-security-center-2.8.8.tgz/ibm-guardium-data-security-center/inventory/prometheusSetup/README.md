# Configure Prometheus

Prometheus is an open-source systems monitoring and alerting toolkit.
Prometheus collects and stores its metrics as time series data (metrics information is stored with the timestamp at which it was recorded, alongside optional key-value pairs called labels).

#### Considerations

In the event that you raise an issue with IBM support, the metrics will be collected with the mustgather feature. These metrics include system metrics, such as memory and CPU usage of mini-snif pods, and mini-snif internal metrics. This crucial information is used by the support team to diagnose mini-snif related issues. Since many issues, such as mini-snif performance issues, would be very difficult to diagnose without these metrics, it is highly recommended that you enable Prometheus when installing Guardium Data Security Center.

To ensure that the metrics cover the time frame in which an issue occurs, it is recommended that you configure the retention period of metrics for user-defined projects to be at least 15 days.

Prometheus requires additional resources to run in your cluster. The requirements document for Openshift Prometheus can be found [here](https://docs.openshift.com/container-platform/4.8/scalability_and_performance/scaling-cluster-monitoring-operator.html#scaling-cluster-monitoring-operator).


## Prerequisites
Openshift 4.18.x +

### Preparation

#### Part I: Log in to your Openshift cluster instance

* Login to case:
```
  cloudctl login -a https://cp-console.apps.<env>.example.ibm.com --skip-ssl-validation -u <user> -p <password> -n <namespase>
```

or
 - oc login <URL> -u <KUBE_USER> -p <KUBE_PASS> [--insecure-skip-tls-verify=true]
 - example: `oc login api.example.ibm.com:6443 -u kubeadmin -p xxxxx-xxxxx-xxxxx-xxxxx`

#### Part II: Obtain the CASE bundle
1. Create the following environment variables with the installer image name and the version:
```
export CASE_NAME=ibm-guardium-data-security-center
export CASE_VERSION=2.7.2
export LOCAL_CASE_DIR=$HOME/.ibm-pak/data/cases/$CASE_NAME/$CASE_VERSION
export CASE_ARCHIVE=ibm-guardium-data-security-center-${CASE_VERSION}.tgz
```
2. Enable color output (optional with v1.4.0 and later):
```
oc ibm-pak config color --enable true
```
3. Save the CASE bundle locally:
```
oc ibm-pak get $CASE_NAME \
--version $CASE_VERSION \
--skip-verify
```

<i><b>Note:</b></i> If you encounter an error similar to this:
```
No Case registries found for case ibm-cert-manager->=1.3.0 <1.3.1.tgz with the given repository URL information
FAILED
```

You may be experiencing a temporary communication problem with the remote repository. Wait a few minutes and try again.


### Installation
This section explains how to apply the Prometheus custom resource (CR).

* <i><b>Important note:</b></i> Please read Storage, Documentation and Labels before applying.

Prometheus can be installed via oc apply or via IBM CASE bundle. These instructions cover IBM CASE bundle installation:

* Add customer changes for Prometheus yamls(e.g storage , labels , retentions and more):
1. Extract ibm-guardium-data-security-center-2.7.2.tgz:
```
tar zxvf $LOCAL_CASE_DIR/$CASE_ARCHIVE
```

2. Change directory to the extracted folder:
```
cd $LOCAL_CASE_DIR/ibm-guardium-data-security-center/inventory/prometheusSetup/files
```

3. Edit the prometheus.yaml file and add customer-recomended changes from the Openshift Prometheus site.

4. Change directory and tar files from the $LOCAL_CASE_DIR/ibm-guardium-data-security-center folder:
```
cd $LOCAL_CASE_DIR
tar czvf $LOCAL_CASE_DIR/$CASE_ARCHIVE ibm-guardium-data-security-center
```

* Apply the Prometheus yaml files:
```
oc ibm-pak $CASE_NAME \
  --version $CASE_VERSION --namespace default \
  --inventory prometheusSetup  --action applyCustomResources
```

### Storage
Running cluster monitoring with persistent storage means that your metrics are stored to a persistent volume (PV) and can survive a pod being restarted or recreated. This is ideal if you require your metrics or alerting data to be guarded from data loss. For production environments, it is highly recommended to configure persistent storage.

Documentation for persistent storage OCP Prometheus can be found [here](https://docs.openshift.com/container-platform/4.8/monitoring/configuring-the-monitoring-stack.html).

Example of PVC configuration: (please check the OCP Prometheus documentation)
Add your PVC configuration:
edit file ```ibm-guardium-data-security-center/inventory/prometheusSetup/files/prometheus.yaml``` , ConfigMap: cluster-monitoring-config

```
apiVersion: v1
kind: ConfigMap
metadata:
  name: cluster-monitoring-config
  namespace: openshift-monitoring
data:
  config.yaml: |
    enableUserWorkload: true
    prometheusK8s:
      externalLabels:
        cluster_name: gi
      volumeClaimTemplate:
        spec:
          storageClassName: <storage_class>
          resources:
            requests:
              storage: 50Gi
    alertmanagerMain:
      volumeClaimTemplate:
        spec:
          storageClassName: <storage_class>
          resources:
            requests:
              storage: 20Gi
```

ConfigMap: user-workload-monitoring-config

```
apiVersion: v1
kind: ConfigMap
metadata:
  name: user-workload-monitoring-config
  namespace: openshift-user-workload-monitoring
data:
  config.yaml: |
    prometheus:
      retention: 15d
      externalLabels:
        cluster_name: gi
      volumeClaimTemplate:
        spec:
          storageClassName: <storage_class>
          resources:
            requests:
              storage: 50Gi
    thanosRuler:
      volumeClaimTemplate:
        spec:
          storageClassName: <storage_class>
          resources:
            requests:
              storage: 20Gi
```

* replace ```<storage_class> ``` with your storage class
* Check Documentation for Prometheus best practice, i.e. persistent storage information
* retention (user-workload-monitoring-config) = retention period for Prometheus storage(for user data).


### Labels
To attach custom labels to all time series and alerts leaving the Prometheus instance that monitors core OpenShift Container Platform projects

Edit the ConfigMap ```cluster-monitoring-config``` and add:

```
externalLabels:
  <key>: <value>
```


To attach custom labels to all time series and alerts leaving the Prometheus instance that monitors user-defined projects:

Edit the ConfigMap ```user-workload-monitoring-config``` and add:

```
externalLabels:
  <key>: <value>
```

*Substitute <key>: <value> with a map of key-value pairs where <key> is a unique name for the new label and <value> is its value.

*In case of multiple GDSC clusters add unique key/value to segregate between GDSC environment.

### Accessing metrics from thanos dashboard
Thanos is open source, highly available Prometheus setup with long term storage capabilities

Extract your thanos dashboard host
```
oc get route thanos-querier -n openshift-monitoring
```

### Uninstallation
This section explains how to delete the Prometheus CustomResources.
* Delete prometheus yamls:
```
oc ibm-pak $CASE_NAME \
  --version $CASE_VERSION --namespace default \
  --inventory prometheusSetup  --action deleteCustomResources
```

### Documentation
Documentation for OCP Prometheus can be found here :
(https://docs.openshift.com/container-platform/4.8/monitoring/configuring-the-monitoring-stack.html) or (https://docs.openshift.com/container-platform/4.8/monitoring/enabling-monitoring-for-user-defined-projects.html#enabling-monitoring-for-user-defined-projects).
