#!/bin/bash
#
# (C) Copyright IBM Corp. 2021, 2024  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh and
# launch-impl.sh
# This implementation is specific to this Guardium Data Security Center Operator
# Installation.

# Install complete case bundle
#scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

inventory="prometheusSetup"
prometheus_yaml="${casePath}/inventory/${inventory}/files/prometheus.yaml"
USERWORKLOAD_NAMESPACE="openshift-user-workload-monitoring"

apply_custom_resources() {
    prometheus_apply_custom_resource
    prometheus_custom_resource_validation
}

delete_custom_resources() {
    prometheus_delete_custom_resource
}

prometheus_apply_custom_resource() { 
    validate_file_exists "${prometheus_yaml}"
    echo ${prometheus_yaml}
    command='oc apply -f '${prometheus_yaml}
    max_retry=5
    counter=0
    until $command
    do
    sleep 1
    [[ counter -eq $max_retry ]] && echo "Failed!" && exit 1
    echo "Trying again. Try #$counter"
    ((counter++))
    done

}

prometheus_delete_custom_resource() {    
    echo ${prometheus_yaml}
    command='oc delete -f '${prometheus_yaml}
    max_retry=5
    counter=0
    until $command
    do
    sleep 1
    [[ counter -eq $max_retry ]] && echo "Failed!" && exit 1
    echo "Trying again. Try #$counter"
    ((counter++))
    done
}

prometheus_custom_resource_validation() {  
echo "Starting PROMETHEUS Custom Resource Validation"
sleep 25
Z=$(oc get pods -n ${USERWORKLOAD_NAMESPACE} --no-headers=true | grep -v Running | wc -l)
X=$?;
while [ "X$X" != "X0" -o $Z -ne 0 ]
do
  echo "Waiting for PROMETHEUS user-workload pods to be ready, Number should be 0 , number: $Z"
  Z=$(oc get pods -n openshift-user-workload-monitoring --no-headers=true | grep -v Running | wc -l)
  if [[ $Z -eq 0 ]]; then
    break
  fi
done

echo "----------------------PROMETHEUS Apply Custom Resource Completed---------------------------" 
}