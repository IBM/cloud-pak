#!/bin/bash
# (C) Copyright IBM Corp. 2023  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this Cert Manager Operator Installation.
 
inventory="ibmCertManagerOperatorSetup" # default inventory item
# crd_file="${casePath}/inventory/${inventory}/files/deploy/crds.yaml"
# rbac_file="${casePath}/inventory/${inventory}/files/deploy/rbac.yaml"
# manager_file="${casePath}/inventory/${inventory}/files/deploy/manager.yaml"

#Inventory for installing via OLM
subscriptionName="ibm-cert-manager-operator"
channelName="v4.2"
catalogNamespace="openshift-marketplace"
catalogSource="ibm-cert-manager-catalog"

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    echo "no dependent catalogs"
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operatorGroup.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    # if [[ ${recursive_action} -eq 1 ]]; then
    #     install_dependent_catalogs
    # fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    if [[ -z $registry ]]; then
        tee >($kubernetesCLI apply ${dryRun} -f -) <"${catsrc_file}" | cat
    else
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
        # local catsrc_image_tmp="$(echo "${catsrc_image_orig}" | sed -e "s#.*/##")"
        # local catsrc_image_mod="${registry}/${catsrc_image_tmp}"
        
        # apply catalog source
         sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}


# Install utilizing via OLM
install_operator() {

    echo "-------------Installing ibm-cert-manager-operator-------------"

    # Verify arguments are valid
    validate_install_args

    # Deploying operator group before applying subscription
    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${catalogSource}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${catalogSource}' expected to be installed namespace '${catalogNamespace}'"
    fi
    # check if subscription already exist
    echo "checking if subscription already exist ..."
    if $kubernetesCLI get subscription -n "${namespace}" | grep "ibm-cert-manager" > /dev/null 2>&1; then
    echo "Subscription '${subscriptionName}' already exists in namespace '${namespace}'. No action needed."
    else
    echo "create cert manager subscription......."
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" "s|REPLACE_NAMESPACE|${namespace}|g; s|REPLACE_CHANNEL_NAME|$channelName|g; s|REPLACE_CATALOG_SOURCE|${catalogSource}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
     fi
}

# Install utilizing default CLI method
install_operator_native() {
    # Verfiy arguments are valid
    echo "-------------Installing native-------------"
    echo "[INFO] Operator Native installation is similar to Operator installation."
    echo "[INFO] Continuing with operator install."
    install_operator
}

# install operand custom resources
apply_custom_resources() {
    echo "No Actions required for this CASE"
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "No Actions required for this CASE"
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling ibm-cert-manager-operator-------------"

    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    uninstall_operator
}

delete_custom_resources() {
    echo "No action required for this CASE."
}
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --catalogSource)
        catalogSource="$val"
        ;;
    esac
}
