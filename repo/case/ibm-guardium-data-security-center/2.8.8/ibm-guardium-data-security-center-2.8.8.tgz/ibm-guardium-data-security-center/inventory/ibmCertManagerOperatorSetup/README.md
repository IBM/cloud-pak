# Install the IBM Cert Manager Operator
This document explains steps to install IBM Cert Manager Operator which is a prerequisite for CPFS v4 and GDSC installation.


## Prerequisites
- Target openshift cluster with login details
- Obtain/create the GDSC case bundle and setup the vars CASE_NAME, CASE_VERSION, LOCAL_CASE_DIR

## Steps for Installation

1. Install Catalog:
```
oc ibm-pak launch $CASE_NAME --version $CASE_VERSION --inventory ibmCertManagerOperatorSetup --action install-catalog --namespace openshift-marketplace --args "--inputDir ${LOCAL_CASE_DIR}"
```

2. Create the Cert Manager Namespace:
``` 
oc create ns ibm-cert-manager
```

3. Install Operator:
```
oc ibm-pak launch $CASE_NAME --version $CASE_VERSION --inventory ibmCertManagerOperatorSetup --action install-operator --namespace ibm-cert-manager --args " --inputDir ${LOCAL_CASE_DIR}"
```

