# (C) Copyright IBM Corp. 2024  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this panamax operator
# panamax operator specific variables
inventory="ibmCommonServiceOperatorSetup"
caseName="ibm-cp-common-services"
cr_system_status="betterThanYesterday"
caseCatalogName="ibm-common-services-catalog"
catalogNamespace="openshift-marketplace"
certNamespace="ibm-cert-manager"
licNamespace="ibm-licensing"
channelName="v3"
catalogTag="latest"
declare -a case_depedencies=("ibm-cloud-native-postgresql" "ibm-cp-common-services")
# ----- INSTALL ACTIONS -----
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-cp-common-services)
        echo "ibmCommonServiceOperatorSetup"
        return 0
        ;;
    ibm-cloud-native-postgresql)
         echo "ibmCloudNativePostgresqlOperator"
         return 0
         ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}


# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2
    
    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# Installs the catalog source and operator group
install_catalog() {
    if [[ -n ${inputcasedir} ]]; then
        #not empty
        inputDirParam="--inputDir $inputcasedir "
        recursiveParam="--recursive "
    fi
    if [[ -n ${registry} ]]; then
        #not empty
        registryParam="--registry $registry "
    fi


    for dep in ${case_depedencies[@]}; do
        ##local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep}-------------"

        if [[ ${dep} == "ibm-cp-common-services" ]]; then
          local dep_case="$(dependent_case_tgz "ibm-cp-common-services" "${inputcasedir}")"
        elif [[ ${dep} == "ibm-cloud-native-postgresql" ]]; then
          local dep_case="$(dependent_case_tgz "ibm-cloud-native-postgresql" "${inputcasedir}")"
        else
            local dep_case="$casePath"
        fi

        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action "install-catalog" \
            --tolerance "${tolerance_val}" \
            --args "${registryParam}${recursiveParam}${inputDirParam}${dryRun:+--dryRun }"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
    case_depedencies=("")
}

# Install utilizing default OLM method
install_operator() {
    check_installed_ics_status
    validate_install_args
    wait=30
    echo "EKS: ${ks_flag}" 
    echo "Hostname: ${HOSTNAME}"

    if [[ "$ks_flag" != true ]]; then
        # Applying network policies before operator installation
        echo "-------------Applying Network Policies for IBM Common Services-------------"
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/cert-manager/allow-webhook-access-from-apiserver.yaml" "s|certNamespace|${certNamespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/cert-manager/bedrock-access-to-cert-manager-webhook.yaml" "s|certNamespace|${certNamespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        $kubernetesCLI get ns $licNamespace
        if [[ $? -eq 0 ]]; then
            echo "Found ibm-licensing namespace, creating network policies"
            sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/license-service/bedrock-access-to-license-service-reporter.yaml" "s|licNamespace|${licNamespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
            sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/license-service/bedrock-access-to-license-service.yaml" "s|licNamespace|${licNamespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        else
            echo "ibm-licensing namespace not found, skipping network policies creation"
        fi
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/operators/access-to-edb-postgres-webhooks.yaml" "s|opNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/operators/access-to-zen-meta-api.yaml" "s|opNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/operators/access-to-ibm-common-service-operator.yaml" "s|opNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/operators/allow-webhook-access-from-apiserver.yaml" "s|opNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/access-to-common-web-ui.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/access-to-edb-postgres.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/access-to-icp-mongodb.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/access-to-platform-auth-service.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/access-to-platform-identity-management.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/access-to-platform-identity-provider.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-audit-svc.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-nginx.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-usermgmt.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-zen-core-api.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-zen-core.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-zen-minio.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-zen-volumes.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-access-to-zen-watchdog.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/services/zen-allow-iam-config-job.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        # Adding the netpol for ldap fix, INS-40855
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/ldap/gi-egress-allow-internet-identity-provider.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/ldap/gi-egress-allow-internet-identity-management.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed <"${casePath}/inventory/${inventory}/files/cp3-networkpolicy/ingress/ldap/gi-egress-allow-internet-auth-service.yaml" "s|csNamespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi
    if [[ "$ks_flag" = true ]]; then
        echo "------------- Installing Non-OCP CM  for $namespace -------------"
        local cm="${casePath}/inventory/${inventory}/files/op-olm/cm.yaml"
        echo "Namespace: ${namespace}"
        echo "Hostname: ${HOSTNAME}"
        sed "s#REPLACE_NAMESPACE#${namespace}#g; s#REPLACE_HOSTNAME#${HOSTNAME}#g" "${cm}" | $kubernetesCLI apply -f -

    fi

    # Proceed with install
    echo "-------------Installing common services via OLM-------------"
    local dep_case="$casePath"

    if [[ -n ${inputcasedir} ]]; then
        #not empty
        inputDirParam="--inputDir $inputcasedir "
        recursiveParam="--recursive "
    fi
    for dep in ${case_depedencies[@]}; do
            echo "-------------Installing dependent operator: ${dep} -------------"

            if [[ ${dep} == "ibm-cp-common-services" ]]; then
                local dep_case="$(dependent_case_tgz "ibm-cp-common-services" "${inputcasedir}")"
            elif [[ ${dep} == "ibm-cloud-native-postgresql" ]]; then
                continue
            else
                local dep_case="$casePath"
            fi
            local inventory=""
            inventory=$(dependent_inventory_item "ibm-cp-common-services")

            oc ibm-pak launch \
                --case "${dep_case}" \
                --namespace "${namespace}" \
                --inventory "${inventory}" \
                --action "install-operator"  \
                --args "--size ${ICS_SIZE} ${recursiveParam}${inputDirParam}${dryRun:+--dryRun }" \
                --tolerance "${tolerance_val}"

            if [[ $? -ne 0 ]]; then
                err_exit "installing dependent operator for '${dep_case}' failed"
            fi
    done

    # Modify subscription file if ks flag is true
    if [[ "$ks_flag" = true ]]; then
        echo "-------------Installing Operator Lifecycle Manager-------------"
        # checking whether OLM is already installed on the cluster or not
        if $kubernetesCLI get deployment -A | grep 'olm-operator'; then
            echo "OLM is already installed in '${namespace}' namespace. Skipping installation..."
        else
            echo "Please follow the documentations to install Operator Lifecycle Manager (OLM) on your cluster "

            # checking the package server CSV creation
            local retries=30
            until [[ $retries == 0 ]]; do
                csv_phase=$("$kubernetesCLI" get csv -n olm packageserver -o jsonpath='{.status.phase}' 2>/dev/null || echo "Waiting for CSV to appear")
                operatorhub_catalog=$("$kubernetesCLI" get po -n olm | grep -c "operatorhubio.*1/1")
                if [[ "$csv_phase" == "Succeeded" ]] && [[ "$operatorhub_catalog" == 1 ]]; then
                    echo "Package server CSV phase: $csv_phase, Operatorhub Catalog pod: Ready"
                    break
                else
                    echo "Package server CSV phase: $csv_phase, Operatorhub Catalog pod: NotReady"
                    sleep 10
                fi
                retries=$((retries - 1))
            done
        fi
        echo "------------- Installing Non-OCP operandrequest for $namespace -------------"
        local opreq_file="${casePath}/inventory/${inventory}/files/op-olm/eksoperandrequest.yaml"
        validate_file_exists "${opreq_file}"

        local CRD_NAME="commonservices.operator.ibm.com"
        local attempt_counter=0
        local max_attempts=20
        local success=false

        echo "Checking if CRD ${CRD_NAME} exists..."

        while [ $attempt_counter -lt $max_attempts ]; do
            $kubernetesCLI get crd | grep "${CRD_NAME}" > /dev/null 2>&1
            if [ $? -eq 0 ]; then
                echo "CRD ${CRD_NAME} exists."
                break
            else
                echo "Waiting for CRD ${CRD_NAME} to be created in namespace ${namespace}... Attempt $((attempt_counter + 1))/$max_attempts"
                attempt_counter=$((attempt_counter + 1))
                sleep 30
            fi
        done

        if [ $attempt_counter -eq $max_attempts ]; then
            echo "CRD ${CRD_NAME} not found after $max_attempts attempts. Exiting."
            exit 1
        fi

        attempt_counter=0
        while [ $attempt_counter -lt $max_attempts ]; do
            echo "Attempt $((attempt_counter + 1)) to apply operandrequest"

            sed "s|REPLACE_NAMESPACE|${namespace}|g" "${opreq_file}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

            if [ $? -eq 0 ]; then
                echo "Operandrequest successfully applied"
                success=true
                break
            else
                echo "Attempt $((attempt_counter + 1)) failed, retrying in 30 seconds..."
                attempt_counter=$((attempt_counter + 1))
                sleep 30
            fi
        done

        if [ "$success" = false ]; then
            echo "Failed to apply operandrequest after $max_attempts attempts. Exiting."
            exit 1
        fi

        echo "done"
        $kubernetesCLI patch commonservices common-service -n $namespace --type='merge' -p "{\"spec\": {\"license\": {\"accept\": true}, \"operatorNamespace\": \"$namespace\", \"servicesNamespace\": \"$namespace\", \"size\": \"starterset\"}}"

        # Only set up IBM Events operator when EKS flag is true
        if [[ "$ks_flag" == "true" ]]; then
            echo "------------- Setting up IBM Events operator for EKS -------------"
            
            # Define variables for Events operator setup
            local events_sub_file="${casePath}/inventory/${inventory}/files/op-olm/events-operator-subscription.yaml"
            validate_file_exists "${events_sub_file}"
            local NAME="ibm-events-operator"
            local LABEL="operators.coreos.com/${NAME}.${namespace}"
            
            echo "==> [Events] Ensuring OperatorGroup exists in ${namespace} ..."
            $kubernetesCLI -n "${namespace}" get operatorgroup >/dev/null 2>&1 || { echo "No OperatorGroup found in ${namespace}"; exit 1; }
            
            echo "==> [Events] Cleaning previous resources..."
            $kubernetesCLI -n "${namespace}" delete subscription "$NAME" --ignore-not-found=true
            $kubernetesCLI -n "${namespace}" delete csv -l "$LABEL" --ignore-not-found=true
            $kubernetesCLI -n "${namespace}" delete deploy -l "$LABEL" --ignore-not-found=true
            $kubernetesCLI -n "${namespace}" delete pod -l "$LABEL" --ignore-not-found=true
            
            echo "==> [Events] Creating Subscription (channel=v5.1)..."
            sed "s|REPLACE_NAMESPACE|${namespace}|g" "${events_sub_file}" | $kubernetesCLI apply -f -
            
            echo "==> [Events] Waiting for CSV to be available..."
            local retries=60
            local EVT_CSV=""
            while [ $retries -gt 0 ] && [ -z "$EVT_CSV" ]; do
                EVT_CSV=$($kubernetesCLI -n "${namespace}" get subscription "$NAME" -o jsonpath="{.status.installedCSV}" 2>/dev/null || true)
                [ -z "$EVT_CSV" ] && EVT_CSV=$($kubernetesCLI -n "${namespace}" get subscription "$NAME" -o jsonpath="{.status.currentCSV}" 2>/dev/null || true)
                [ -n "$EVT_CSV" ] && break
                sleep 2
                retries=$((retries - 1))
            done
            
            if [ -z "$EVT_CSV" ]; then
                echo "Warning: Could not determine CSV name for Events operator"
            else
                echo "✅ Events CSV: $EVT_CSV"
                
                # Wait for deployment to be available
                local EVT_DEP=$($kubernetesCLI -n "${namespace}" get csv "$EVT_CSV" -o jsonpath="{.spec.install.spec.deployments[0].name}" 2>/dev/null || true)
                if [ -n "$EVT_DEP" ]; then
                    echo "==> [Events] Waiting for deployment rollout..."
                    $kubernetesCLI -n "${namespace}" rollout status deploy "$EVT_DEP" --timeout=300s || true
                    echo "✅ Deployment: $EVT_DEP"
                fi
                
                # Wait for CSV to reach Succeeded phase
                echo "==> [Events] Waiting for CSV to reach Succeeded phase..."
                local timeout=600  # 10 minute timeout
                local end_time=$(($(date +%s) + timeout))
                local success=false
                
                while [ $(date +%s) -lt $end_time ]; do
                    local phase=$($kubernetesCLI -n "${namespace}" get csv "$EVT_CSV" -o jsonpath="{.status.phase}" 2>/dev/null || echo "")
                    
                    if [ "$phase" == "Succeeded" ]; then
                        echo "✅ CSV $EVT_CSV is now in Succeeded phase"
                        success=true
                        break
                    fi
                    
                    echo "Current phase: $phase"
                    sleep 10
                done
                
                if [ "$success" = true ]; then
                    echo "IBM Events operator setup completed successfully"
                else
                    echo "Warning: IBM Events operator CSV did not reach Succeeded phase within timeout"
                fi
            fi
        fi

        echo "------------- Installing ingress for $namespace -------------"

        local secret_name="platform-oidc-credentials"
        local secret_key="WLP_CLIENT_SECRET"
        local secret_id_key="WLP_CLIENT_ID"
        local max_attempts=10
        local attempt_counter=0

        while [[ $($kubernetesCLI get secret $secret_name -n ${namespace} -ojsonpath="{.data.$secret_key}" | base64 -d | wc -c) -eq 0 ]]; do
            if [ $attempt_counter -ge $max_attempts ]; then
                echo "Secret $secret_name not created with the correct content after $max_attempts attempts. Exiting."
                exit 1
            fi
            echo "Waiting 30 seconds for $secret_name to be created with the correct content... Attempt $((attempt_counter + 1))/$max_attempts"
            attempt_counter=$((attempt_counter + 1))
            sleep 30
        done

        client_id="$($kubernetesCLI get secret $secret_name -n ${namespace} -o yaml | grep "$secret_id_key:" | sed 's/'$secret_id_key': *//')"
        client_id=$(echo $client_id | base64 --decode)
        echo "Client ID: $client_id"

        local ingress_template="${casePath}/inventory/${inventory}/files/op-olm/cpfs-ingress-template.yaml"
        validate_file_exists "${ingress_template}"

        sed "s#REPLACE_CLIENT_ID#${client_id}#g; s#REPLACE_NAMESPACE#${namespace}#g; s#REPLACE_HOSTNAME#${HOSTNAME}#g" "${ingress_template}" | $kubernetesCLI apply -f -

        echo "done"

        echo "------------- Installing network policies for $namespace -------------"

        local netpol_file="${casePath}/inventory/${inventory}/files/op-olm/install_networkpolicy.sh"
        validate_file_exists "${netpol_file}"

        export CS_NAMESPACE=$namespace

        bash "${netpol_file}" -n $CS_NAMESPACE

        if [ $? -eq 0 ]; then
            echo "Network policies successfully installed"
        else
            echo "Failed to install network policies. Exiting."
            exit 1
        fi

        echo "done"
    fi

    if [[ "$ks_flag" != true ]]; then
        echo "Patching IBM Cloudpak Foundational Services CommonService Custom Resource "
        for (( count=0 ; count <= 10 ; count++ )); do
            ics_cr_exist=$($kubernetesCLI get CommonService common-service -n "$namespace" --no-headers 2>/dev/null | wc -l)
            if [ $ics_cr_exist -eq 1 ]; then
                $kubernetesCLI patch CommonService common-service -n "$namespace" -p "{\"spec\":{\"operatorNamespace\":\"$namespace\",\"servicesNamespace\":\"$namespace\"}}" --type=merge
                break
            elif [ ${count} -eq 10 ]; then
                echo "[ERROR] Timeout waiting for IBM Cloudpak Foundational Services CommonService Custom Resource to be created."
                exit 1
            else
                echo "Waiting for IBM Cloudpak Foundational Services CommonService Custom Resource to be created."
                sleep 10
            fi
        done

        echo "Installing Operand_request from Guardium"
        local opreq_file="${casePath}/inventory/${inventory}/files/op-olm/operand_request.yaml"
        validate_file_exists "${opreq_file}"
        sed "s|REPLACE_NAMESPACE|${namespace}|g" "${opreq_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

        # echo "patching ibm-events-operator to be approved as part of Operand_request from Guardium"
        # echo ${namespace}
        # oc patch ip `oc get ip -n ${namespace} | grep ibm-events-operator.v4 |  awk '$1 {print $1}'` --type merge --patch '{"spec":{"approved":true}}'
        # echo "end of patching ibm-events-operator"

    fi
        check_ics_oprequest_status
        check_ics_installation_status
        echo "-------------Install complete-------------"
}


# Install utilizing default CLI method
install_operator_native() {
    echo "Please use OLM install/uninstall"
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------No custom resources need to apply-------------"
}

# ----- UNINSTALL ACTIONS -----

function delete_sub_csv() {
  subs=$1
  ns=$2
  for sub in ${subs}; do
    csv=$(oc get sub ${sub} -n ${ns} -o=jsonpath='{.status.installedCSV}' --ignore-not-found)
    [[ "X${csv}" != "X" ]] && oc delete csv ${csv}  -n ${ns} --ignore-not-found
    oc delete sub ${sub} -n ${ns} --ignore-not-found
  done
}

# Get remaining resource with kinds
function get_remaining_resources() {
  local remaining=$1
  local ns="--all-namespaces"
  local new_remaining=
  [[ "X$2" != "X" ]] && ns="-n $2"
  for kind in ${remaining}; do
    if [[ "X$($kubernetesCLI get ${kind} --all-namespaces)" != "X" ]]; then
      new_remaining="${new_remaining} ${kind}"
    fi
  done
  echo $new_remaining
}

function wait_for_deleted() {
  local remaining=${1}
  retries=${2:-10}
  interval=${3:-30}
  index=0
  while true; do
    remaining=$(get_remaining_resources "$remaining")
    if [[ "X$remaining" != "X" ]]; then
      if [[ ${index} -eq ${retries} ]]; then
        echo "Timeout delete resources: $remaining"
        return 1
      fi
      sleep $interval
      ((index++))
      echo "DELETE - Waiting: resource ${remaining} delete complete [$(($retries - $index)) retries left]"
    else
      break
    fi
  done
}

function delete_operator() {
  local subs=$1
  local namespace=$2
  for sub in ${subs}; do
    csv=$($kubernetesCLI get sub ${sub} -n ${namespace} -o=jsonpath='{.status.installedCSV}' --ignore-not-found)
    if [[ "X${csv}" != "X" ]]; then
      echo "Delete operator ${sub} from namespace ${namespace}"
      $kubernetesCLI delete csv ${csv} -n ${namespace} --ignore-not-found
      $kubernetesCLI delete sub ${sub} -n ${namespace} --ignore-not-found
    fi
  done
}

function delete_operand() {
  local crds=$1
  for crd in ${crds}; do
    if $kubernetesCLI api-resources | grep $crd &>/dev/null; then
      for ns in $($kubernetesCLI get $crd --no-headers --all-namespaces --ignore-not-found | awk '{print $1}' | sort -n | uniq); do
        crs=$($kubernetesCLI get ${crd} --no-headers --ignore-not-found -n ${ns} 2>/dev/null | awk '{print $1}')
        if [[ "X${crs}" != "X" ]]; then
          echo "Deleting ${crd} from namespace ${ns}"
          $kubernetesCLI delete ${crd} --all -n ${ns} --ignore-not-found &
        fi
      done
    fi
  done
}

function delete_operand_finalizer() {
  local crds=$1
  local ns=$2
  for crd in ${crds}; do
    crs=$($kubernetesCLI get ${crd} --no-headers --ignore-not-found -n ${ns} 2>/dev/null | awk '{print $1}')
    for cr in ${crs}; do
      echo "Removing the finalizers for resource: ${crd}/${cr}"
      $kubernetesCLI patch ${crd} ${cr} -n ${ns} --type="json" -p '[{"op": "remove", "path":"/metadata/finalizers"}]' 2>/dev/null
    done
  done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    echo "-------------Deleting catalog source-------------"
    $kubernetesCLI delete CatalogSource opencloud-operators -n openshift-marketplace --ignore-not-found=true

    echo "-------------Deleting operatorGroup-------------"
    $kubernetesCLI delete OperatorGroup common-service -n "${namespace}" --ignore-not-found=true

}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling common services-------------"

    echo "-------------Deleting common services operand from all namespaces-------------"
    delete_operand "OperandRequest" && wait_for_deleted "OperandRequest" 30 40
    delete_operand "CommonService OperandRegistry OperandConfig"
    delete_operand "NamespaceScope" && wait_for_deleted "NamespaceScope"

    echo "-------------Deleting common service operator-------------"
    for sub in $($kubernetesCLI get sub --all-namespaces --ignore-not-found | awk '{if ($3 =="ibm-common-service-operator") print $1"/"$2}'); do
        namespace=$(echo $sub | awk -F'/' '{print $1}')
        name=$(echo $sub | awk -F'/' '{print $2}')
        delete_operator "$name" "$namespace"
    done

    echo "-------------Deleting ODLM-------------"
    for sub in $($kubernetesCLI get sub --all-namespaces --ignore-not-found | awk '{if ($3 =="ibm-odlm") print $1"/"$2}'); do
        namespace=$(echo $sub | awk -F'/' '{print $1}')
        name=$(echo $sub | awk -F'/' '{print $2}')
        delete_operator "$name" "$namespace"
        cs_ns="$namespace"
    done
    cs_ns=${cs_ns:-ibm-common-services}

    echo "-------------Deleting RBAC resource-------------"
    $kubernetesCLI delete ClusterRole ibm-common-service-webhook --ignore-not-found
    $kubernetesCLI delete ClusterRoleBinding ibm-common-service-webhook --ignore-not-found
    $kubernetesCLI delete RoleBinding ibmcloud-cluster-info -n kube-public --ignore-not-found
    $kubernetesCLI delete Role ibmcloud-cluster-info -n kube-public --ignore-not-found

    $kubernetesCLI delete RoleBinding ibmcloud-cluster-ca-cert -n kube-public --ignore-not-found
    $kubernetesCLI delete Role ibmcloud-cluster-ca-cert -n kube-public --ignore-not-found

    $kubernetesCLI delete ClusterRole nginx-ingress-clusterrole --ignore-not-found
    cluster_role_binding=$(oc get ClusterRoleBinding | grep nginx-ingress-clusterrole | awk '{print $1}')
    if [[ ! -z $cluster_role_binding ]]
    then
      $kubernetesCLI delete ClusterRoleBinding $cluster_role_binding --ignore-not-found
    fi
    $kubernetesCLI delete scc nginx-ingress-scc --ignore-not-found

    subs=$(oc get sub --no-headers -n ${cs_ns} 2>/dev/null | awk '{print $1}')
    delete_sub_csv "${subs}" "${cs_ns}"

    echo "-------------Deleting webhook-------------"
    $kubernetesCLI delete ValidatingWebhookConfiguration cert-manager-webhook ibm-cs-ns-mapping-webhook-configuration --ignore-not-found
    $kubernetesCLI delete MutatingWebhookConfiguration cert-manager-webhook ibm-common-service-webhook-configuration namespace-admission-config ibm-operandrequest-webhook-configuration --ignore-not-found
  
    echo "-------------Deleting configmap-------------"
    $kubernetesCLI -n kube-public delete cm ibm-common-services-status --ignore-not-found

    echo "-------------Deleting API-------------"
    $kubernetesCLI delete apiservice v1.metering.ibm.com --ignore-not-found
    $kubernetesCLI delete apiservice v1beta1.webhook.certmanager.k8s.io --ignore-not-found

    echo "-------------Deleting catalog source-------------"
    $kubernetesCLI delete CatalogSource opencloud-operators -n openshift-marketplace --ignore-not-found

    echo "-------------Deleting namespace-------------"
    $kubernetesCLI delete namespace ${cs_ns} --ignore-not-found &
    if wait_for_namespace_deleted ${cs_ns}; then
      echo "-------------Uninstall successful-------------"
    fi

    if $ks_flag; then
    echo "-------------Cleaning up IBM Events operator resources-------------"
    # Clean up IBM Events operator resources
    NAME=ibm-events-operator
    LABEL="operators.coreos.com/${NAME}.${namespace}"
    
    echo "Deleting IBM Events operator subscription and related resources..."
    $kubernetesCLI -n "${namespace}" delete subscription "$NAME" --ignore-not-found=true
    $kubernetesCLI -n "${namespace}" delete csv -l "$LABEL" --ignore-not-found=true
    $kubernetesCLI -n "${namespace}" delete deploy -l "$LABEL" --ignore-not-found=true
    $kubernetesCLI -n "${namespace}" delete pod -l "$LABEL" --ignore-not-found=true
    
    echo "-------------Deleting specific ingress resources-------------"
    ingress_names=(
        "cncf-social-login-callback"
        "cncf-saml-ui-callback"
        "cncf-platform-oidc"
        "cncf-platform-login"
        "cncf-platform-id-provider"
        "cncf-platform-id-auth"
        "cncf-platform-auth"
        "cncf-id-mgmt"
        "cncf-common-web-ui"
    )
    for ingress_name in "${ingress_names[@]}"; do
        if $kubernetesCLI get ingress "${ingress_name}" -n "${namespace}" --ignore-not-found=true > /dev/null 2>&1; then
            echo "Deleting ingress ${ingress_name}..."
            $kubernetesCLI delete ingress "${ingress_name}" -n "${namespace}" --ignore-not-found=true ${dryRun}
        else
            echo "Ingress ${ingress_name} does not exist, skipping."
        fi
    done
    
    echo "-------------Deleting specific network policy resources-------------"
    netpol_names=(
        "access-to-common-web-ui"
        "access-to-edb-postgres"
        "access-to-icp-mongodb"
        "access-to-platform-auth-service"
        "access-to-platform-identity-management"
        "access-to-platform-identity-provider"
        "access-to-audit-svc"
        "access-to-ibm-nginx"
        "access-to-usermgmt"
        "access-to-zen-core-api"
        "access-to-zen-core"
        "access-to-zen-minio"
        "access-to-volumes"
        "access-to-zen-watchdog"
        "allow-iam-config-job"
        "access-to-edb-postgres-webhooks"
        "access-to-ibm-common-service-operator"
        "access-to-zen-meta-api"
        "allow-webhook-access-from-apiserver"
    )
    for netpol_name in "${netpol_names[@]}"; do
        if $kubernetesCLI get networkpolicy "${netpol_name}" -n "${namespace}" --ignore-not-found=true > /dev/null 2>&1; then
            echo "Deleting network policy ${netpol_name}..."
            $kubernetesCLI delete networkpolicy "${netpol_name}" -n "${namespace}" --ignore-not-found=true ${dryRun}
        else
            echo "Network policy ${netpol_name} does not exist, skipping."
        fi
    done
fi


    echo "-------------Force delete remaining resources-------------"
    delete_unavailable_apiservice
    force_delete "${cs_ns}"
    if [[ ($? -ne 0)]]; then
      err_exit "Failed to forced uninstall the common services, please re-try the uninstallation again."
    fi
    echo "-------------Uninstall successful-------------"
}

function wait_for_namespace_deleted() {
  local namespace=$1
  retries=30
  interval=5
  index=0
  while true; do
    if $kubernetesCLI get namespace ${namespace} &>/dev/null; then
      if [[ ${index} -eq ${retries} ]]; then
        echo "Timeout delete namespace: $namespace"
        return 1
      fi
      sleep $interval
      ((index++))
      echo "DELETE - Waiting: namespace ${namespace} delete complete [$(($retries - $index)) retries left]"
    else
      break
    fi
  done
  return 0
}

function delete_unavailable_apiservice() {
  rc=0
  apis=$($kubernetesCLI get apiservice | grep False | awk '{print $1}')
  if [ "X${apis}" != "X" ]; then
    echo "Found some unavailable apiservices, deleting ..."
    for api in ${apis}; do
      echo "$kubernetesCLI delete apiservice ${api}"
      $kubernetesCLI delete apiservice ${api}
      if [[ "$?" != "0" ]]; then
        echo "Delete apiservcie ${api} failed"
        rc=$((rc + 1))
        continue
      fi
    done
  fi
  return $rc
}

# Sometime delete namespace stuck due to some reousces remaining, use this method to get these
# remaining resources to force delete them.
function get_remaining_resources_from_namespace() {
  local namespace=$1
  local remaining=
  if $kubernetesCLI get namespace ${namespace} &>/dev/null; then
    message=$($kubernetesCLI get namespace ${namespace} -o=jsonpath='{.status.conditions[?(@.type=="NamespaceContentRemaining")].message}' | awk -F': ' '{print $2}')
    [[ "X$message" == "X" ]] && return 0
    remaining=$(echo $message | awk '{len=split($0, a, ", ");for(i=1;i<=len;i++)print a[i]" "}' | while read res; do
      [[ "$res" =~ "pod" ]] && continue
      echo ${res} | awk '{print $1}'
    done)
  fi
  echo $remaining
}
function force_delete() {
  local namespace=$1
  local remaining=$(get_remaining_resources_from_namespace "$namespace")
  if [[ "X$remaining" != "X" ]]; then
    echo "Some resources are remaining: $remaining"
    echo "Deleting finalizer for these resources ..."
    delete_operand_finalizer "${remaining}" "$namespace"
    wait_for_deleted "${remaining}" 5 10
  fi
}
# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --size)
        size=$val
        ;;
    --ks_flag)
        ks_flag=$val
        echo "Parsed ks_flag: $ks_flag"
        ;;
    --hostname)
        HOSTNAME=$val
        echo "Parsed hostname: $HOSTNAME"
        ;;
    esac
}

migrate_45_46() {
    echo "Starting Inplace migration"
    currentdir=$(pwd)
    echo $currentDir
    #migration step1- ./setup_singleton.sh --license-accept  -c v4.2
    scriptPath="${casePath}/inventory/${inventory}/files/scripts/cp3pt0-deployment"
    "${scriptPath}"/setup_singleton.sh --license-accept -c v4.2
    if [ $? -ne 0 ]; then
        echo "Migration script failed!"
        exit 1
    fi
    #migration step2 # ./setup_tenant.sh --license-accept --operator-namespace staging -c v4.6 -i Automatic -s opencloud-operators -n openshift-marketplace -v 1
    "${scriptPath}"/setup_tenant.sh --license-accept --operator-namespace "$namespace" -c v4.6 -i Automatic -s opencloud-operators -n openshift-marketplace -v 1
    if [ $? -ne 0 ]; then
        echo "Migration script failed!"
        exit 1
    fi
    echo "Migration tasks completed successfully!"
}
#ICS Migration v3.xxto v4.x.x.
migrate_isolation() {
  echo "TBD"
  #3.19.x to 4.x.x [both 4.5 and 4.6 should be done] & Note 4.6.x needs postgres catsrc
}
check_installed_ics_status() {
csv_name=$(oc get csv -n "$namespace" --no-headers | grep ibm-common-service-operator | awk '{print $1}')
if [ -z "$csv_name" ]; then
  echo "No CSV found matching the pattern - proceed to fresh install"
  return
fi
operator_version=$(oc get csv "$csv_name" -n "$namespace" -o jsonpath='{.metadata.annotations.operatorVersion}')
if [[ "$operator_version" == 4.5.* ]]; then
  echo "ICS version is 4.5.x, migrate to 4.6.x with inplace migration"
  check_installed_icspods_status
  migrate_45_46
elif [[ "$operator_version" == 4.6.* ]]; then
  echo "Do nothing."
  check_installed_icspods_status
# elif [[ "$operator_version" == 3.19.* ]]; then
#   echo "Do nothing. #In future add isolation migration if csv is 3.91.x--TBD migrate_isolation()"
else
  echo "Operator version does not match 4.5.x or 4.6.x range."
fi
}
check_installed_icspods_status() {
  pod_name=$(oc get pod -n "$namespace" --no-headers | grep ibm-common-service-operator | awk '{print $1}')
  pod_status=$(oc get pod "$pod_name" -n "$namespace" -o jsonpath='{.status.phase}')
  # Check if the pod status is 'Running'
  if [[ "$pod_status" == "Running" ]]; then
    echo "ICS Pods are in the Running state"
    container_statuses=$(oc get pod "$pod_name" -n "$namespace" -o jsonpath='{.status.containerStatuses[*].state}')
    if [[ "$container_statuses" == *"running"* && "$container_statuses" != *"waiting"* && "$container_statuses" != *"terminated"* ]]; then
      return 0
    else
      echo "Some containers are not running correctly."
      return 1
    fi
  else
    echo "Pod is not in the Running state. Current status: $pod_status"
    return 1
  fi
}

check_ics_oprequest_status() {
for (( count=0; count <= 20; count++ )); do
  opreq_name=$(oc get opreq -n "$namespace" --no-headers | grep ibm-iam-request | awk '{print $1}')
  echo "Attempt $count: opreq_name='$opreq_name'"
  if [ -z "$opreq_name" ]; then
    echo "Warning: No opreq found. Waiting for the next check..."
  else
    opreq_status=$(oc get opreq "$opreq_name" -n "$namespace" -o jsonpath='{.status.phase}' 2>/dev/null)
    if [[ "$opreq_status" == "Running" ]]; then
      echo "opreq is in the Running state."
      return 0
    fi
  fi
  if [ ${count} -eq 20 ]; then
    echo "opreq is not in the Running state after 20 attempts."
    if [ -n "$opreq_status" ]; then
      echo "Current status: $opreq_status"
    else
      echo "Could not determine the status; no opreq found."
    fi
    echo "Refer to the troubleshooting link: https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.6?topic=installer-troubleshooting"
    return 1
  else
    echo "Waiting for IBM Cloudpak Foundational Services pods to be created."
    sleep 60
  fi
done
}

check_ics_installation_status(){
echo "validating CPFSv4.x installation succeeded"
get_pod_names() {
  oc get pods -n "$namespace" --no-headers | grep platform | awk '{print $1}'
}
#validating running state
for (( count=0 ; count <= 20 ; count++ )); do
  pods=($(get_pod_names))
  total_pods=${#pods[@]}
  if [ "$total_pods" -eq 3 ]; then
    allpods_running=true
    for pod in "${pods[@]}"; do
      status=$(oc get pod "$pod" -n "$namespace" -o jsonpath='{.status.phase}')
      if [ "$status" != "Running" ]; then
        echo "Pod $pod is not Running. Current status: $status"
        allpods_running=false
      fi
    done
    if $allpods_running; then
      echo "All specified pods are running."
      return
    else
      echo "Not all pods are running. Waiting for 10 seconds before next check..."
    fi
  else
    echo "Waiting for the correct number of IBM Cloudpak Foundational Services pods to be created. Current count: $total_pods"
  fi
  sleep 60
done
echo "[ERROR] Timeout waiting for IBM Cloudpak Foundational Services pods to be created or all pods to be running."
echo "Refer the troubleshooting link: https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.6?topic=installer-troubleshooting"
return 1
}
