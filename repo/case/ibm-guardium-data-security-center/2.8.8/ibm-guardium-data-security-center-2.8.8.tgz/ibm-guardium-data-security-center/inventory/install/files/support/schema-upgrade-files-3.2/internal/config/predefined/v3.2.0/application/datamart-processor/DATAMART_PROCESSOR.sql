-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."CHANGE_FILE_PERMISSION" (
    IN FILE_NAME CLOB,
    OUT STATUS_CODE INT )
EXTERNAL NAME 'DB2INST1.FILEPERMISSIONCHANGE:FilePermissionChange.changePermission'
LANGUAGE JAVA PARAMETER STYLE JAVA