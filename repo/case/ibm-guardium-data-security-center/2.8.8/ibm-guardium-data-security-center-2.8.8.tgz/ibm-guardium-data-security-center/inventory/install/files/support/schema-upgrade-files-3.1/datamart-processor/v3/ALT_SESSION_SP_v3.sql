-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_SESSION_v3" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)

  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
    -- IF YOU GET STRANGE ERRORS, LOOK HERE FIRST!
	DECLARE CREATE_STMT VARCHAR(7000);
	DECLARE INSERT_STMT VARCHAR(7000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset           	DOUBLE
        ,SessionId				DECIMAL(20)
        ,AccessId				VARCHAR(40)
        ,SessionStart			TIMESTAMP
        ,SessionStartUTC        TIMESTAMP
        ,SessionEnd				TIMESTAMP
        ,SessionEndUTC          TIMESTAMP
        ,DatabaseName			VARCHAR(255)
        ,UidChain				VARCHAR(500)
        ,LoginSucceeded			DECIMAL(11)
        ,DBUserName				VARCHAR(255)
        ,OSUser				    VARCHAR(255)
        ,SourceProgram			VARCHAR(255)
        ,ServerIP				VARCHAR(50)
        ,AnalyzedClientIP		VARCHAR(50)
        ,ServiceName			VARCHAR(80)
        ,ClientHostName			VARCHAR(255)
        ,ServerType				VARCHAR(30)
        ,ServerHostName			VARCHAR(255)
        ,ServerPort				VARCHAR(10)
        ,ClientPort				VARCHAR(30)
        ,NetworkProtocol		VARCHAR(20)
        ,TapIdentifier			VARCHAR(255)
        ,SessionIgnored			VARCHAR(10)
        ,SenderIP				VARCHAR(50)
        ,InactiveFlag           DECIMAL(11)
        ,ProcessID             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'MERGE
	  INTO  "'||TNT_ID||'"."SESSION" AS "SESSION"
      USING "'||TNT_ID||'"."'||TABLENAME||'" AS "SESSION_MERGE" ("UTCOFFSET","SESSIONID","ACCESSID","SESSIONSTART","SESSIONSTARTUTC","SESSIONEND","SESSIONENDUTC","DATABASENAME","UIDCHAIN","LOGINSUCCEEDED","DBUSERNAME","OSUSER","SOURCEPROGRAM","SERVERIP","ANALYZEDCLIENTIP","SERVICENAME","CLIENTHOSTNAME","SERVERTYPE","SERVERHOSTNAME","SERVERPORT","CLIENTPORT","NETWORKPROTOCOL","TAPIDENTIFIER","SESSIONIGNORED","SENDERIP","INACTIVEFLAG", "PROCESSID")
      ON(
        "SESSION"."SessionID" = "SESSION_MERGE"."SESSIONID" AND
        "SESSION"."ConfigID"  = ''0'' AND
        "SESSION"."GlobalID"  = '''||GLOBALID||'''
        )
    WHEN MATCHED THEN
        UPDATE SET
            "SESSION"."ClientID" = "SESSION_MERGE"."ANALYZEDCLIENTIP",
            "SESSION"."NetworkProtocol" = "SESSION_MERGE"."NETWORKPROTOCOL",
            "SESSION"."DBUserName" = "SESSION_MERGE"."DBUSERNAME",
            "SESSION"."OSUser" = "SESSION_MERGE"."OSUSER",
            "SESSION"."SourceProgram" = "SESSION_MERGE"."SOURCEPROGRAM",
            "SESSION"."ClientHostName" = "SESSION_MERGE"."CLIENTHOSTNAME",
            "SESSION"."ServerHostName" = "SESSION_MERGE"."SERVERHOSTNAME",
            "SESSION"."ServiceName" = "SESSION_MERGE"."SERVICENAME",
            "SESSION"."DatabaseName" = "SESSION_MERGE"."DATABASENAME",
            "SESSION"."SessionStart" = "SESSION_MERGE"."SESSIONSTART",
            "SESSION"."SessionStartUTC" = "SESSION_MERGE"."SESSIONSTARTUTC",
            "SESSION"."SessionEnd" =  "SESSION_MERGE"."SESSIONEND",
            "SESSION"."SessionEndUTC" =  "SESSION_MERGE"."SESSIONENDUTC",
            "SESSION"."InactiveFlag" = "SESSION_MERGE"."INACTIVEFLAG",
            "SESSION"."SessionIgnored" = "SESSION_MERGE"."SESSIONIGNORED",
            "SESSION"."LoginSucceeded" = "SESSION_MERGE"."LOGINSUCCEEDED"
    WHEN NOT MATCHED THEN
        INSERT ("MessageType","ID","SessionID","DatabaseType","ServerOS","ClientOS","ServerID","ClientID","NetworkProtocol","DBProtocol","DBProtocolVersion","DBUserName","OSUser","SourceProgram","ClientHostName","ServerHostName","ServiceName","KeyValue","DatabaseName","ClientPort","ServerPort","SourceID","UTCOffset","OldSessionID","SessionStart","SessionStartUTC","SessionEnd","SessionEndUTC","TTL","SessionInfo","InactiveFlag","SessionIgnored","IgnoreSince","IgnoreSinceUTC","UIDChain","UIDChainCompressed","FailOverFlag","FailoverTimestamp","FailoverTimestampUTC","Mills","RequiredUIDChainFromParent","LoginSucceeded","SenderIP","SessionKey","CharEncoding","TapIdentifier","AccessID","ServerIP","ServerType","ConfigID","GlobalID","ProcessID")
        VALUES (
            ''SESSION'',
            NULL,
            "SESSION_MERGE"."SESSIONID",
            NULL,
            NULL,
            NULL,
            NULL,
            "SESSION_MERGE"."ANALYZEDCLIENTIP",
            "SESSION_MERGE"."NETWORKPROTOCOL",
            NULL,
            NULL,
            "SESSION_MERGE"."DBUSERNAME",
            "SESSION_MERGE"."OSUSER",
            "SESSION_MERGE"."SOURCEPROGRAM",
            "SESSION_MERGE"."CLIENTHOSTNAME",
            "SESSION_MERGE"."SERVERHOSTNAME",
            "SESSION_MERGE"."SERVICENAME",
            NULL,
            "SESSION_MERGE"."DATABASENAME",
            "SESSION_MERGE"."CLIENTPORT",
            "SESSION_MERGE"."SERVERPORT",
            NULL,
            "SESSION_MERGE"."UTCOFFSET",
            NULL,
            "SESSION_MERGE"."SESSIONSTART",
            "SESSION_MERGE"."SESSIONSTARTUTC",
            "SESSION_MERGE"."SESSIONEND",
            "SESSION_MERGE"."SESSIONENDUTC",
            NULL,
            NULL,
            "SESSION_MERGE"."INACTIVEFLAG",
            "SESSION_MERGE"."SESSIONIGNORED",
            NULL,
            NULL,
            "SESSION_MERGE"."UIDCHAIN",
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            "SESSION_MERGE"."LOGINSUCCEEDED",
            "SESSION_MERGE"."SENDERIP",
            NULL,
            NULL,
            "SESSION_MERGE"."TAPIDENTIFIER",
            "SESSION_MERGE"."ACCESSID",
            "SESSION_MERGE"."SERVERIP",
            "SESSION_MERGE"."SERVERTYPE",
            ''0'',
            '''||GLOBALID||''',
            "SESSION_MERGE"."PROCESSID")';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1
