-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."INSERT_FULL_SQL_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  DECLARE INSERT_STMT_OF VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(32000),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20),
    BindVariablesValues VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

  -- insert the records into overflow table that are larger than 8192
  SET INSERT_STMT_OF = '
    INSERT INTO "'||TNT_ID||'"."OVERFLOW_FIELDS" (
        "TableName",
        "ID",
        "ColumnName",
        "Value",
        "ConfigID",
        "GlobalID"
    )
    SELECT
        ''FULL_SQL'',
        FullSQLID,
        ''FullStatement'',
        CLOB(FullSql),
        ''0'',
        '''||GLOBALID||'''
    FROM "'||TNT_ID||'"."'||TABLENAME||'"
    WHERE LENGTH(TRIM(FullSql))>8192
    AND NOT EXISTS (
        SELECT 1 FROM "'||TNT_ID||'"."OVERFLOW_FIELDS" of
        WHERE of."TableName" = ''FULL_SQL'' AND of."ID" = FullSQLID AND of."ColumnName" = ''FullStatement''
        AND ''0'' = of."ConfigID" AND '''||GLOBALID||''' = of."GlobalID"
    );';
  PREPARE STMT_2 FROM INSERT_STMT_OF;
  EXECUTE STMT_2;

  SET INSERT_STMT = 'INSERT
    INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues","OverflowFlagFullStatement")
    SELECT
        ''FULL_SQL'',
        NULL,
        FullSQLID,
        SessionId,
        Timestamp,
        TimestampUTC,
        UTCOffset,
        InstanceID,
        AccessRuleDescription,
        VARCHAR(FullSql,8192),
        RecordsAffected,
        Succeeded,
        NULL,
        ResponseTime,
        NULL,
        ''0'',
        '''||GLOBALID||''',
        VARCHAR(BindVariablesValues,255),
        CASE WHEN LENGTH(TRIM(FullSql))>8192 THEN 1 ELSE 0 END
    FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  PREPARE STMT_3 FROM INSERT_STMT;
  EXECUTE STMT_3;
  END S1
