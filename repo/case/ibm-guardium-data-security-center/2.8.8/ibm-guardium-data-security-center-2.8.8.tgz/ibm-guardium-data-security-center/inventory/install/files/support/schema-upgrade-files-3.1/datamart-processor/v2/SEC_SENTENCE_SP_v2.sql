-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."SEC_INSERT_SENTENCE_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE SENTENCEMERGE VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset               FLOAT
        ,SentenceId             VARCHAR(40)
        ,ConstructId            VARCHAR(40)
        ,Verb                   VARCHAR(40)
        ,Depth                  DECIMAL(11)
        ,ParentSentence         VARCHAR(40)
        ,Timestamp              TIMESTAMP
        ,TimestampUTC           TIMESTAMP)
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

  -- merge the sentence (verb) rows from the temp table
  SET SENTENCEMERGE = 'INSERT INTO "' || TNT_ID || '"."SENTENCE" ("MessageType", "UTCOffset","SentenceID", "ConstructID", "Verb", "Depth", "ParentSentenceID", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
                      SELECT ''SENTENCE'',
                      UTCOffset,
                      SentenceId,
                      ConstructId,
                      Verb,
                      Depth,
                      ParentSentence,
                      Timestamp,
                      TimestampUTC,
                      ''0'', ''' || GLOBALID || ''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "SentenceID","ConfigID","GlobalID" from "'||TNT_ID||'"."SENTENCE" mt where mt."SentenceID" = Ext.SentenceId AND mt."ConstructID" = Ext.ConstructId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE SMERGE FROM SENTENCEMERGE;
  EXECUTE SMERGE;

  END S1
