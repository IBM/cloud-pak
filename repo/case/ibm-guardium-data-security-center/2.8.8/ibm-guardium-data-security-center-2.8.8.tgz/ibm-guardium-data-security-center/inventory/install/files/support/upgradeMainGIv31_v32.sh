#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2022. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeMainGIv31_v32.sh
#
# DESCRIPTION:   Main upgrade script for Guardium Insights v3.1.x to v3.2
#
# USAGE:         This script takes no argument.
#
# PREREQUISITES: This script should be run at GI v3.2 level.
#
#----------------------------------------------------------------------------

# Retrieve current namespace
NAME_SPACE=$(oc config view --minify -o 'jsonpath={..namespace}' 2>/dev/null)
status=$?
if [ $status != 0 ]; then
	echo "Error trying to retrieve Guardium Insights current namespace"
	echo "Make sure you are logged into the cluster before running this script"
	exit 1
fi

# Use gi-cr-name in place of namespace (INS-24743)
GI_CR_NAME=$(oc -n $NAME_SPACE get pods | grep '\-mongodb' | head -n 1 | awk {'print $1'} | cut -d '-' -f 1)

# Global constants
THIS_SCRIPT=$(basename "$0")
REQUIRED_VERSION="3.2.0"
SOURCE_DIR=$(pwd)
UPGRADE_CATALOG_SCRIPT="$SOURCE_DIR/upgradeCatalogGIv31_v32.sh"
UPGRADE_SCHEMA_SCRIPT="$SOURCE_DIR/upgradeDB2SchemaGIv31_v32.sh"
UPGRADE_CONFIG_SCRIPT="$SOURCE_DIR/upgradeConfigGIv31_v32.sh"
UPGRADE_POSTGRES_SCRIPT="$SOURCE_DIR/upgradePostgresGIv31_v32.sh"
UPGRADE_MONGO_SCRIPT="$SOURCE_DIR/upgradeMongoData.sh"

# Tally number of failed scripts
failed_count=0

# Write a timestamped message to the log file
LOG_TIMESTAMP=$(date "+%Y%m%d%H%M%S")
LOG_DIR="$SOURCE_DIR/logs"
MASTER_LOG_FILE="$LOG_DIR/${THIS_SCRIPT%.*}_$LOG_TIMESTAMP.log"
function write_log() {
	message=$1
	output_terminal=${2:-0}
	timestamp=$(date "+%Y-%m-%d %H:%M:%S")
	timestamped_msg="$timestamp $THIS_SCRIPT: $message"

	echo "$timestamped_msg" >> $MASTER_LOG_FILE
	if [ $output_terminal = 1 ]; then
		echo "$message"
	fi
}

# Run an upgrade script and tally its failure status
# Two arguments are always passed down to the child script:
# 1) current namespace, 2) name of master log file
function run_script() {
	SCRIPT_NAME=$1

	$SCRIPT_NAME $GI_CR_NAME $MASTER_LOG_FILE
	status=$?
	if [ $status != 0 ]; then
		let "failed_count++"
	fi
}

# Create log directory as needed
[[ -d $LOG_DIR ]] || mkdir $LOG_DIR

# Upgrade process begins here
write_log "Start upgrading Guardium Insights v3.1.x to v3.2.0 for namespace '$GI_CR_NAME'" 1
write_log "Please wait..." 1

# Check to make sure current cluster has correct GI version
release_info=$(oc get guardiuminsights)
release_array=($release_info)
array_count=${#release_array[@]}

# Installed-version is the last item of the release info
if (( $array_count > 0 )); then
	installed_version=${release_array[$array_count-1]}
else
	write_log "Error trying to retrieve Guardium Insights current version" 1
	write_log "Upgrade aborted" 1
	exit 1
fi

# Cluster needs to be at 3.2.0 before running this upgrade script
if [ "$installed_version" = "$REQUIRED_VERSION" ]; then
    write_log "Required GI version $installed_version is installed"
else
    write_log "This upgrade requires Guardium Insights version $REQUIRED_VERSION but found $installed_version" 1
    write_log "Upgrade aborted" 1
	exit 1
fi

# Run each upgrade script
write_log "Running script $UPGRADE_SCHEMA_SCRIPT..." 1
run_script $UPGRADE_SCHEMA_SCRIPT
write_log "Running script $UPGRADE_CATALOG_SCRIPT..." 1
run_script $UPGRADE_CATALOG_SCRIPT
write_log "Running script $UPGRADE_CONFIG_SCRIPT..." 1
run_script $UPGRADE_CONFIG_SCRIPT
write_log "Running script $UPGRADE_POSTGRES_SCRIPT..." 1
run_script $UPGRADE_POSTGRES_SCRIPT
write_log "Running script $UPGRADE_MONGO_SCRIPT..." 1
run_script $UPGRADE_MONGO_SCRIPT

# Exit upgrade with the final status 
write_log "Log files are located in directory $SOURCE_DIR/logs" 1
if [ $failed_count = 0 ]; then
    message="Upgrade completed successfully"
else
    message="Upgrade completed with $failed_count failed scripts"
fi
write_log "$message" 1

exit $status
