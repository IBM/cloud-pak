# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this Event Streams operator

# ibm event streams operator specific variables
caseName="ibm-guardium-data-security-center"
inventory="install"
caseCatalogName="ibm-guardium-insights-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName=""
declare -a case_depedencies=("cloundNativePostgresOperator" "ibm-db2uoperator" "noobaaOperator" "ibm-redis-cp" "mongodbOperator" "guardiumDataSecurityCenterOperator")

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --ks_flag)
        ks_flag=$val
        echo "Parsed ks_flag: $ks_flag"
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item_catalog() {
    local case_name=$1
    case $case_name in
    ibm-redis-cp)
        echo "ibmRedisCPOperator"
        return 0
        ;;
    ibm-db2uoperator)
        echo "db2uOperatorSetup"
        return 0
        ;;
    cloundNativePostgresOperator)
        echo "cloundNativePostgresOperator"
        return 0
        ;;
    mongodbOperator)
        echo "mongodbOperator"
        return 0
        ;;
    noobaaOperator)
        echo "noobaaOperator"
        return 0
        ;;
    guardiumDataSecurityCenterOperator)
        echo "guardiumDataSecurityCenterOperator"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

dependent_inventory_item_operator() {
    local case_name=$1
    case $case_name in
    ibm-redis-cp)
        echo "ibmRedisCPOperator"
        return 0
        ;;
    ibm-db2uoperator)
        echo "db2uOperatorStandaloneSetup"
        return 0
        ;;
    cloundNativePostgresOperator)
        echo "cloundNativePostgresOperator"
        return 0
        ;;
    mongodbOperator)
        echo "mongodbOperator"
        return 0
        ;;
    noobaaOperator)
        echo "noobaaOperator"
        return 0
        ;;
    guardiumDataSecurityCenterOperator)
        echo "guardiumDataSecurityCenterOperator"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

undependent_inventory_item_catalog() {
    local case_name=$1
    case $case_name in
    ibm-redis-cp)
        echo "ibm-redis-cp-operator"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2
    
    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

check_ics(){
    # inputcasedir is already checked by parent function
    # no need to check if it's empty
    # Use inputcasedir to unpack ibm-cp-common-services
    # find required version from case.yml

    ICS_CASE_NAME="ibm-cp-common-services"
    ICS_TEMP_DIR="$inputcasedir/ics_temp"
    CASE_FILEPATH="$ICS_TEMP_DIR/ibm-cp-common-services/case.yaml"

    # Get latest ics case bundle tgz path
    get_ics_case_path=$(dependent_case_tgz $ICS_CASE_NAME $inputcasedir)
    create_tmp=$(mkdir $ICS_TEMP_DIR)
    extract_case=$(tar -xzf $get_ics_case_path -C $ICS_TEMP_DIR)

    # By unpacking case bundle and looking at case.yaml
    # We can find the required ics version for insights at the time

    echo -e "\n"
    echo "****************** ICS CHECK STARTED ******************"
    echo -e "\n"
 
    if [ -f "${CASE_FILEPATH}" ]; then
        ICS_APP_VERSION=$(cat "${CASE_FILEPATH}" | grep appVersion | awk '{print $2}')
        echo "Required version of IBM Common Services: $ICS_APP_VERSION"
        rm_temp=$(rm -rf $ICS_TEMP_DIR)
    else
        echo "********************** ERROR **********************"
        echo -e "\n"
        echo "Unable to find required IBM Common Services version"
        echo "Please make sure path for inputDir is correct"
        echo "If it is, re-run oc ibm-pak get and check ibm-cp-common-services tgz file is present"
        echo "in the path for outputdir"
        print_done
        exit 1
    fi

    # Get version(s) and put output in an array
    # so we can loop and warn if earlier
    # ics versions are installed 
    ics_installed_appversion=$(oc get csv -n ${namespace} | grep ibm-common-service-operator | awk {'print $2'} | sed 's/[^v0-9.]*//g' )
    ics_arr=( $ics_installed_appversion )
    vcount=${#ics_installed_appversion[@]}

    for versions in ${ics_installed_appversion[@]}; do
        ics_current_appversion=${versions:3} # strip leading letters to get version

        if [ "$(printf '%s\n' "$ics_current_appversion" "$ICS_APP_VERSION" | sort -V | head -n 1)" != "$ICS_APP_VERSION" ]; then
            if (( vcount > 1 )); then
                echo "WARNING: Found earlier version: $ics_current_appversion"
                ((vcount=vcount-1))
                continue
            else
                echo "Installed ICS version: $ics_current_appversion"
                echo -e  "\n"
                echo "********************** ERROR **********************"
                echo -e  "\n"
                echo "IBM Common Services version $ics_current_appversion is lower than the required version $ICS_APP_VERSION"
                echo "Please install IBM Common Services at the minimum required version" 
                print_done
                exit 1
            fi
        fi
    
        # -- Workaround for ICS versions being affected by Kafka 4.6.1
        if [[ $ics_current_appversion == '3.19.12' || $ics_current_appversion == '3.23.4' ]]; then
            echo "Version of IBM Common Services (ICS) installed ($ics_current_appversion) is not supported"
            exit 1
        else
            echo "Supported version of IBM Common Services (ICS) is installed: $ics_current_appversion"
        fi
        # -- End workaround

        if [ $ics_current_appversion == $ICS_APP_VERSION ]; then
            echo "Found required IBM Common Services version: $ics_current_appversion, installed"
            print_done
            return
        else
            # version installed is higher than required version 
            # which is fine
            echo "Found installed IBM Common Services version: $ics_current_appversion"
        fi
    done
    print_done
}

print_done(){
   echo -e "\n"
   echo "****************** IBM Common Services CHECK DONE ******************"
   echo -e "\n"
}

pre_install() {

    local dep_case="$casePath"
    ##local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

    echo "-------------Installing dependent GDSC preinstall: ${dep_case}-------------"

    #local inventory="install"
    echo "PRE-INSTALL VALUES:"
    printf "$PRE_INSTALL_PARAMS\n"
    source "$scriptDir"/pre-install/preInstall.sh $PRE_INSTALL_PARAMS
    
}

#----- DOWNLOAD ACTIONS -----
#oc ibm-pak get $case_name --version $case_version --skip-verify

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    ##local dep_case=""
    ##local dep_case="$casePath"

    if [[ -n ${inputcasedir} ]]; then
        #not empty
        inputDirParam="--inputDir $inputcasedir "
        recursiveParam="--recursive "
    fi
    if [[ -n ${registry} ]]; then
        #not empty
        registryParam="--registry $registry "
    fi

    # check for ics version before installing catalogs
    check_ics

    for dep in ${case_depedencies[@]}; do
        ##local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep}-------------"

        if [[ ${dep} == "noobaaOperator" ]]; then
            continue
        fi

        if [[ ${dep} == "ibm-db2uoperator" ]]; then
            local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        else
            local dep_case="$casePath"
        fi

        local inventory=""
        inventory=$(dependent_inventory_item_catalog "${dep}")

        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action "install-catalog" \
            --args "${registryParam}${recursiveParam}${nonOCPParam}${inputDirParam}${dryRun:+--dryRun }${ks_flag:+--ks_flag ${ks_flag}}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
    case_depedencies=("")
}

install_dependent_odlm_db2u() {

    #If there is ICS installed, get the namespace
    ICSNAMESPACE=$($kubernetesCLI get operandregistry -A -ocustom-columns=namespace:'metadata.namespace',name:'metadata.name' --no-headers=true | grep common-service | awk 'NR==1 {print $1;}' | tr -d '[:space:]') || true

    db2mng=$($kubernetesCLI get subscription ibm-db2u-operator -n $ICSNAMESPACE)
    if [[ -n ${db2mng} ]]; then
        # Copy configmap to GDSC namespace.
        $kubernetesCLI get configmap db2u-release -n $ICSNAMESPACE -o yaml | sed 's/namespace: '$ICSNAMESPACE'/ namespace: '$INSIGHTS_NAMESPACE'/' | $kubernetesCLI create -f -

        # Delete db2u release configmap in ICS namespace
        # $kubernetesCLI delete configmap db2u-release -n $ICSNAMESPACE

        # Back up operandregistry file in original state
        # $kubernetesCLI get operandregistry common-service -n $ICSNAMESPACE -o yaml > common-service-backup-original.yaml

        # Change name
        # $kubernetesCLI get operandregistry common-service -n $ICSNAMESPACE -o yaml | sed 's/name: common-service/name: common-service-backup/' | $kubernetesCLI create -f -

        # Delete Operand Registry
        # $kubernetesCLI delete operandregistry common-service -n $ICSNAMESPACE

        # Change db2u entry to backup
        # cat common-service-backup.yaml | sed -e "s/name: ibm-db2u-operator/name: ibm-db2u-operatorbak/"
        # cat common-service-backup-original.yaml | sed 's/ibm-db2u-operator/ibm-db2u-operator-backup/g' > common-service-new.yaml 

        # Reapply opreg with backedupdb2
        # $kubernetesCLI create -f common-service-new.yaml

        # Delete db2u subscription
        # $kubernetesCLI delete subscription ibm-db2u-operator -n $ICSNAMESPACE

        # Get db2 csv version in ICS
        # csvver=$($kubernetesCLI get csv | grep db2 | awk '{print $1;}' )

        # Delete db2 csv in ICS
        # $kubernetesCLI delete csv $csvver -n ICSNAMESPACE

        # Scale down db2u deploy in ICS namespace
        $kubernetesCLI scale deployment db2u-operator-manager --replicas=0 -n $ICSNAMESPACE || true
    fi 
}

# Function to patch DB2 operator for EKS compatibility
patch_db2_for_eks() {
    if [[ "$ks_flag" != "true" ]]; then
        echo "EKS flag not set, skipping DB2 patching"
        return
    fi
    
    echo "Applying EKS-specific configurations for DB2 operator"
    
    # Find the DB2 CSV that's in Succeeded phase
    CSV=$($kubernetesCLI -n "${namespace}" get csv \
      -l "operators.coreos.com/db2u-operator.${namespace}" \
      -o jsonpath='{range .items[?(@.status.phase=="Succeeded")]}{.metadata.name}{"\n"}{end}')
    
    if [[ -n "$CSV" ]]; then
        echo "Found DB2 CSV: $CSV"
        
        # Define the new image with EKS-specific configuration
        NEW_IMG="icr.io/cpopen/db2u-operator@sha256:b7c5c9f8f4738e32de61e76271de4faf122a911a8879ce17c8213f6e619cc5d6"
        
        # Patch the CSV to use the EKS-compatible image
        echo "Patching DB2 CSV to use EKS-compatible image"
        $kubernetesCLI -n "${namespace}" patch csv "$CSV" --type='json' -p="[
          {
            \"op\": \"replace\",
            \"path\": \"/spec/install/spec/deployments/0/spec/template/spec/containers/0/image\",
            \"value\": \"${NEW_IMG}\"
          }
        ]"
        
        if [ $? -eq 0 ]; then
            echo "Successfully patched DB2 CSV for EKS compatibility"
        else
            echo "Warning: Failed to patch DB2 CSV"
        fi
    else
        echo "Warning: Could not find DB2 CSV in Succeeded phase"
    fi
}

# Function to patch db2u-release configmap (minimal)
patch_db2u_configmap() {
    echo "[INFO] Checking db2u-release configmap for registry issues..."
    
    # Wait up to 6 minutes for configmap
    for i in {1..12}; do
        if $kubernetesCLI get configmap db2u-release -n "${namespace}" >/dev/null 2>&1; then
            if $kubernetesCLI get configmap db2u-release -n "${namespace}" -o yaml | grep -q "icr\.io//"; then
                echo "[INFO] Patching db2u-release configmap to fix 'icr.io//' → 'icr.io/db2u/'..."
                # Use POSIX-compliant awk with explicit print
                if $kubernetesCLI get configmap db2u-release -n "${namespace}" -o yaml | \
                    awk '{gsub(/icr\.io\/\//, "icr.io/db2u/"); print}' | \
                    $kubernetesCLI apply -f -; then
                    echo "[INFO] Patch applied successfully"
                    return 0
                else
                    echo "[ERROR] Failed to patch db2u-release configmap"
                    err_exit "db2u-release configmap patch failed"
                fi
            else
                echo "[INFO] No patch needed for db2u-release configmap"
            fi
            return 0
        fi
        echo "[INFO] Waiting for db2u-release configmap... (attempt $i/12)"
        sleep 30
    done
    echo "[ERROR] db2u-release configmap not found after 6 minutes"
    echo "[ERROR] The db2u-release configmap should be created by the DB2 operator"
    echo "[ERROR] Please verify that the DB2 operator is running correctly in namespace: ${namespace}"
    err_exit "Could not find db2u-release configmap created by DB2 operator after waiting 6 minutes"
}

# Installs the operators of any dependencies
install_dependent_operators() {

    if [[ -n ${inputcasedir} ]]; then
        #not empty
        inputDirParam="--inputDir $inputcasedir "
        recursiveParam="--recursive "
    fi

    for dep in ${case_depedencies[@]}; do
        local arg_secret="--secret ibm-entitlement-key --user ${user} --pass ${pass}"
        local registry_param="${registry}"

        ##check if DB2U stand-alone exists and uninstall ODLM type
        if [[ ${dep} == "ibm-db2uoperator" ]]; then
            local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
            install_dependent_odlm_db2u
            arg_secret=""
            # Use icr.io registry for DB2U operator
            registry_param="icr.io"
            echo "[INFO] Using icr.io registry for DB2U operator"
        else
            local dep_case="$casePath"
        fi

        echo "-------------Installing dependent operator: ${dep} -------------"

        local inventory=""
        inventory=$(dependent_inventory_item_operator "${dep}")
        
        # Build args - DB2U uses icr.io registry, others use ${registry}
        local install_args="--registry ${registry_param} ${arg_secret} ${recursiveParam}${nonOCPParam}${inputDirParam}${dryRun:+--dryRun } --inputDir ${inputcasedir}"
        
        # Add operand-image-namespace for DB2U operator (commented out for now)
        # if [[ ${dep} == "ibm-db2uoperator" ]]; then
        #     local target_namespace="${operand_image_namespace:-${namespace}}"
        #     install_args="${install_args} --operand-image-namespace ${target_namespace}"
        #     echo "[INFO] Using operand-image-namespace: ${target_namespace}"
        # fi
        
        install_args="${install_args} ${ks_flag:+--ks_flag ${ks_flag}}"
        
        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action "install-operator"  \
            --args "${install_args}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent operator for '${dep_case}' failed"
        fi
        
        # Patch db2u-release configmap if this was the DB2U operator
        if [[ ${dep} == "ibm-db2uoperator" ]]; then
            patch_db2u_configmap
        fi
    done
    case_depedencies=("")
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    #local opgrp_file="${casePath}/inventory/${inventory}/files/OperatorGroup.yaml"

    #sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    ##validate_install_catalog

    # Display EKS flag status
    echo "EKS Flag: ${ks_flag}"

    echo "-------------Installing catalog source-------------"
    install_dependent_catalogs
    # install all catalogs of subcases first
    #if [[ ${recursive_action} -eq 1 ]]; then
    #    install_dependent_catalogs
    #fi
    echo "done"
}

# Install utilizing default OLM method

install_operator() {
    # Verfiy arguments are valid in secret
    echo "-------------Validate Secret----------------"
    validate_install_secret

    echo "-------------Validate mirror inputdir----------------"
    # Verfiy arguments are valid in inputdir.
    if [[ "${inputcasedir}" ]]; then
        validate_install_args
    fi
    # Display EKS flag status
    echo "EKS Flag: ${ks_flag}. More patches are required"
    
    # Apply DB2 patch for EKS if needed - checking only ks_flag
    if [[ "$ks_flag" == "true" ]]; then
        echo "EKS flag is set, applying DB2 patch"
        patch_db2_for_eks
    fi

    
    #install_operator_group
    echo "-------------Installing via OLM-------------"
    install_dependent_operators
    

}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    for dep in ${case_depedencies[@]}; do
        echo "-------------Uninstalling dependent catalog source: ${dep}-------------"
        local inventory=""
        inventory=$(dependent_inventory_item_catalog "${dep}")

        if [[ ${dep} == "noobaaOperator" ]]; then
            continue
        fi

        if [[ ${dep} == "ibm-db2uoperator" ]]; then
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action "uninstall-catalog" \
            --args "${ks_flag:+--ks_flag ${ks_flag}}"
        $kubernetesCLI get catsrc -n openshift-marketplace
        else
        local dep_case="$casePath"
        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action "uninstall-catalog" \
            --args "${ks_flag:+--ks_flag ${ks_flag}}"
        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

        fi
    done
}

uninstall_dependent_operators() {

    #local dep_case="$casePath"

    if [[ -n ${inputcasedir} ]]; then
       #not empty
       inputDirParam="--inputDir $inputcasedir "
       recursiveParam="--recursive "
    fi

    ## --args "${recursiveParam}${inputDirParam}${dryRun:+--dryRun }" \

    for dep in ${case_depedencies[@]}; do

        echo "-------------Uninstalling dependent operator: ${dep}-------------"
        if [[ ${dep} == "ibm-db2uoperator" ]]; then
            local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        else
            local dep_case="$casePath"
        fi
        local inventory=""

        inventory=$(dependent_inventory_item_operator "${dep}")
         oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action "uninstall-operator" \
            --args "--inputDir ${LOCAL_CASE_DIR} ${ks_flag:+--ks_flag ${ks_flag}}"
        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi
    done

    if $kubernetesCLI get secret ibm-entitlement-key -n "${namespace}" >/dev/null 2>&1; then
        $kubernetesCLI delete secret ibm-entitlement-key --ignore-not-found=true
    fi
}

# deletes the catalog source and operator group
uninstall_catalog() {

    #validate_install_catalog "uninstall"

    # Display EKS flag status
    echo "EKS Flag: ${ks_flag}"

    echo "-------------Uninstalling catalog source-------------"
    uninstall_dependent_catalogs
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    
    # Display EKS flag status
    echo "EKS Flag: ${ks_flag}"

    # Remove the subscription
    uninstall_dependent_operators
}

# Install operator
install() {
    echo "-------------installing-------------"
}

# Uninstall operator
uninstall() {
    echo "-------------Uninstalling-------------"
}
