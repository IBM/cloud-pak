-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

------------------------------------------------
-- DDL Statements for Table "MY_TENANT_SCHEMA"."DM_INGESTION_STATUS"
------------------------------------------------

CREATE TABLE "MY_TENANT_SCHEMA"."DM_INGESTION_STATUS"  (
    "IngestionID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH + 1 INCREMENT BY + 1 MINVALUE + 1 NO MAXVALUE NO CYCLE CACHE 20 NO ORDER),
    "GDPHostname" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '',
    "DataType" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '',
    "PeriodStart" TIMESTAMP NOT NULL,
    "PeriodEnd" TIMESTAMP,
    "ExportRecordCount" INTEGER NOT NULL WITH DEFAULT 0,
    "ExportStatus" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '',
    "IngestStatus" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '',
    "TotalFileCount" INTEGER NOT NULL WITH DEFAULT 0,
    "SuccessFileCount" INTEGER NOT NULL WITH DEFAULT 0,
    "FailureFileCount" INTEGER NOT NULL WITH DEFAULT 0,
    "Error" VARCHAR(8192) NOT NULL WITH DEFAULT '',
    "CurrentTS" TIMESTAMP NOT NULL WITH DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY ("IngestionID") NOT ENFORCED
)
ORGANIZE BY ROW
IN DMSTAT_<TENANT_SHORT_ID>
INDEX IN IGEN4_<TENANT_SHORT_ID>;

CREATE UNIQUE INDEX "MY_TENANT_SCHEMA"."DM_INGESTION_STATUS_IDX_1"
    ON "MY_TENANT_SCHEMA"."DM_INGESTION_STATUS"
    ("GDPHostname", "PeriodStart", "DataType")
    ALLOW REVERSE SCANS;
