-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_OVERFLOW_FIELDS_v3" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
    DECLARE duplicate CONDITION FOR SQLSTATE '23505';
  DECLARE CONDITION_COUNT INT;
  DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
    SET CONDITION_COUNT = 0;

  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
  EXECUTE IMMEDIATE CREATE_STMT;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  EXECUTE IMMEDIATE INSERT_STMT;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
      Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
  EXECUTE IMMEDIATE INSERT_STMT;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT DISTINCT 
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
      Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
  EXECUTE IMMEDIATE INSERT_STMT;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 

exit:
  SET ROWCOUNT = AFFECTED_ROWS; 
END S1
