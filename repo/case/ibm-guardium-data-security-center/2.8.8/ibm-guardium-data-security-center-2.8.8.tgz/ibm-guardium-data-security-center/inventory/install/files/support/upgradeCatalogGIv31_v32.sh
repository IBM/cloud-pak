#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2022. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeCatalogGIv31_v32.sh
#
# DESCRIPTION:   Upgrade script to migrate MongoDB catalog
#
# USAGE:         This script takes two arguments:
#                   1) namespace
#                   2) master log filename
#
# PREREQUISITES: This script should be run at GI v3.2 level.
#
#----------------------------------------------------------------------------

# Check for required NAME_SPACE and MASTER_LOG_FILE parameters
NAME_SPACE="$1"
MASTER_LOG_FILE="$2"
THIS_SCRIPT=$(basename "$0")
if [ "$#" -ne 2 ]; then
	echo "Usage: $THIS_SCRIPT <namespace> <logfile>"
	exit 1
fi

# Local
SOURCE_DIR=$(pwd)

# MongoDB pod
UPGRADE_SCRIPT="connections-migration"
LOG_TIMESTAMP=$(date "+%Y%m%d%H%M%S")
UPGRADE_SCRIPT_LOG="${SOURCE_DIR}/logs/${THIS_SCRIPT%.*}_${LOG_TIMESTAMP}.log"
POD_NAME=""
oc_output=""

# Write a timestamped message to the log file
function write_log() {
	message=$1
	timestamp=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$timestamp $THIS_SCRIPT: $message" >> $MASTER_LOG_FILE
}

# Identify the catalog podname
function identify_podname() {
	write_log "Identifying catalog podname..."

	# Get a list of podnames matching search criteria
	name=$(kubectl get pods -o=name | grep $NAME_SPACE-connections | sed "s/^.\{4\}//")
	if [ -z "$name" ]; then
		write_log "Warning: Unable to identify any podname with string '$NAME_SPACE-connections'"
		return 1
	else
		# Pick the first podname in the list
		POD_NAME=$(echo "$name" | head -n1 | awk '{print $1;}')
		write_log "Catalog podname identified as $POD_NAME"
	fi
}

# Execute upgrade script on pod 
function execute_upgrade() {
    write_log "Executing connections upgrade..."

    oc_output=$(oc exec -t $POD_NAME -- "./${UPGRADE_SCRIPT}")
    status=$?

    if [ $status = 0 ]; then
        write_log "Connections upgraded successfully"
        return 0
    else
        write_log "Connections failed to upgrade"
        return 1
    fi
}

# Copy log file back to source run directory
function copy_log_back() {
	write_log "Copying log file back..."

    echo "$oc_output" > $UPGRADE_SCRIPT_LOG

	write_log "Log file copied to source directory $SOURCE_DIR/logs"
}

# Main function

# Go through the upgrade steps
write_log "Start connections upgrade for namespace '$NAME_SPACE'"

identify_podname
status=$?
if [ $status -ne 0 ]; then
	copy_log_back
	write_log "End connections schema upgrade for namespace '$NAME_SPACE'"
	exit 0
fi

execute_upgrade
status=$?
copy_log_back

write_log "End connections schema upgrade for namespace '$NAME_SPACE'"

exit $status