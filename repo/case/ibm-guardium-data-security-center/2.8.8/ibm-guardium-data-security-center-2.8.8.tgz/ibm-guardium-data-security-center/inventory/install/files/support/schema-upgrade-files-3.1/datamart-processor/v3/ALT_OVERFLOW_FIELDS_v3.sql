-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_OVERFLOW_FIELDS_v3" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1
