#!/bin/bash
#################################################################
#
# Source Components
#
# 5737-L66
#
# (C) Copyright IBM Corp. 2019, 2023
#################################################################

# This script is to refresh the files needed for the database schema upgrade
# from their respective repositories. Run if any of the files have been updated
# upstream.
FILES="internal/config/predefined/v3.2.0/application/datamart-processor/DATAMART_PROCESSOR.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_CLASSIFICATION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_EXCEPTION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_FULL_SQL_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_INSTANCE_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_OBJECT_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_OVERFLOW_FIELDS_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_POLICY_VIOLATION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_SENTENCE_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_SESSION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/ALT_VULNERABILITY_ASSESSMENT_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/CLASSIFICATION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/EXCEPTION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/FULL_SQL_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/INSTANCE_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/OBJECT_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/OVERFLOW_FIELDS_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/POLICY_VIOLATION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/SENTENCE_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/SESSION_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v3/VULNERABILITY_ASSESSMENT_SP_v3.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/AGG_ANALYTIC_INPUT_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_AGG_ANALYTIC_INPUT_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_ANALYTIC_OUTLIERS_DETAILS_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_ANALYTIC_OUTLIERS_SUMMARY_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_CLASSIFICATION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_EXCEPTION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_FULL_SQL_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_INSTANCE_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_OBJECT_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_OVERFLOW_FIELDS_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_POLICY_VIOLATION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_SENTENCE_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_SESSION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ALT_VULNERABILITY_ASSESSMENT_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ANALYTIC_OUTLIERS_DETAILS_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/ANALYTIC_OUTLIERS_SUMMARY_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/CLASSIFICATION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/EXCEPTION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/FULL_SQL_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/INSTANCE_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/OBJECT_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/OVERFLOW_FIELDS_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/POLICY_VIOLATION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/SENTENCE_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/SESSION_SP_v4.sql
internal/config/predefined/v3.2.0/application/datamart-processor/v4/VULNERABILITY_ASSESSMENT_SP_v4.sql
internal/config/predefined/v3.2.0/application/group-builder/GROUP_BUILDER_INSERT_DATA.sql
internal/config/predefined/v3.2.0/application/outlier/AGG_ANALYTIC_INPUT.sql
internal/config/predefined/v3.2.0/application/outlier/ALERT_BUDGET.sql
internal/config/predefined/v3.2.0/application/outlier/ANALYTIC_LOG.sql
internal/config/predefined/v3.2.0/application/outlier/ANALYTIC_VERB_GROUP.sql
internal/config/predefined/v3.2.0/application/outlier/CLUSTERS.sql
internal/config/predefined/v3.2.0/application/outlier/MESSAGE_SUMMARY.sql
internal/config/predefined/v3.2.0/application/outlier/SOURCES.sql
internal/config/predefined/v3.2.0/application/outlier/SOURCE_MESSAGE_STATS.sql
internal/config/predefined/v3.2.0/application/outlier/SYSTEM_PARAMS.sql
internal/config/predefined/v3.2.0/application/outlier/USER_FEEDBACK.sql
internal/config/predefined/v3.2.0/application/outlier/WORKING_HOURS.sql"
REPO="Activity-Insights/pipeline-config.git"
BRANCH=$1
TMPDIR=/tmp/gitrepo

if [ "$BRANCH" = "" ]; then
  BRANCH="master"
fi

header='-- **************************************************************\n--\n-- Source Components\n--\n-- 5737-L66\n--\n-- (C) Copyright IBM Corp. 2019, 2022\n--\n-- **************************************************************\n'

OLDPWD=$(pwd)
cd "$(dirname "$0")"

# Start with the clean slate
rm -rf "$TMPDIR"
rm -rf ./internal

echo "cloning $REPO, branch $BRANCH"
git clone -q --sparse --depth 1 --branch ${BRANCH} git@github.ibm.com:"$REPO" "$TMPDIR"
echo "$FILES" >> "$TMPDIR"/.git/info/sparse-checkout
( cd "$TMPDIR" && git checkout -q $BRANCH )

echo Copying files:
for f in $FILES; do
  echo "$f"
  SUBDIR="$(dirname "$f")"
  test -d "$SUBDIR" || mkdir -p "$SUBDIR"
  cp "$TMPDIR"/"$f" ./"$f"
  sed -i '' '/^.*--/d' "$f"
  sed -i '' "1s/^/${header}/" "$f"
done

cd "$OLDPWD"
echo "All done"