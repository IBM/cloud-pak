#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2022. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeDB2SchemaGIv31_v32.sh
#
# DESCRIPTION:   Upgrade script to upgrade DB2 schema
#
# USAGE:         This script takes two arguments:
#                   1) namespace
#                   2) master log filename
#
# PREREQUISITES: This script should be run at GI v3.2 level.
#
#----------------------------------------------------------------------------

NAME_SPACE="$1"
MASTER_LOG_FILE="$2"

# Check for required NAME_SPACE and MASTER_LOG_FILE parameters
THIS_SCRIPT=$(basename "$0")
if [ "$#" -ne 2 ]; then
	echo "Usage: $THIS_SCRIPT <namespace> <logfile>"
	exit 1
fi

# Local
SOURCE_DIR=$(pwd)

# DB2 pod
SCHEMA_DIR="schema-upgrade-files-3.2"
SCHEMA_SCRIPT="upgradeSchemaGIv31_v32.sh"
LOG_TIMESTAMP=$(date "+%Y%m%d%H%M%S")
SCHEMA_SCRIPT_LOG="upgradeSchemaGIv31_v32_${LOG_TIMESTAMP}.log"
POD_NAME="c-$NAME_SPACE-db2-db2u-0"
TMP_DIR="/tmp"
MOUNT_DIR="/mnt/blumeta0/db2"
catalog_node=""

# Write a timestamped message to the log file
function write_log() {
	message=$1
	timestamp=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$timestamp $THIS_SCRIPT: $message" >> $MASTER_LOG_FILE
}

# Identify the catalog node
function identify_catalog_node() {
	write_log "Identifying catalog node..."

	catalog_node=$(oc exec -t $POD_NAME -- su -l -c "awk '/^0/{split(\$2,a,\"[.]\"); print a[1]}' sqllib/db2nodes.cfg" db2inst1)
	if [ -z "$catalog_node" ]; then
		write_log "Unable to identify catalog node for $NAME_SPACE"
		exit 1
	else
		write_log "Catalog node identified as $catalog_node"
	fi
}

# Copy files up to catalog node to /tmp, keeping file structure
function copy_files() {
	write_log "Copying files to catalog node..."

	oc cp ${SOURCE_DIR}/$SCHEMA_SCRIPT $catalog_node:$TMP_DIR
	oc rsync -q ${SOURCE_DIR}/$SCHEMA_DIR $catalog_node:$TMP_DIR
	write_log "Files copied"
	write_log "Move files to final directory..."
	oc exec -t $POD_NAME -- su -l -c "cp $TMP_DIR/$SCHEMA_SCRIPT $MOUNT_DIR" db2inst1
	oc exec -t $POD_NAME -- su -l -c "chmod +x $MOUNT_DIR/$SCHEMA_SCRIPT" db2inst1
	oc exec -t $POD_NAME -- su -l -c "cp -R $TMP_DIR/$SCHEMA_DIR $MOUNT_DIR" db2inst1

	write_log "Files moved"
}

# Execute upgrade script on pod 
function execute_upgrade() {
	write_log "Executing schema upgrade..."

	WAIT_SECONDS=5
	COUNTER_MAX=12
	current_counter=1

	pid=$(oc exec -t $POD_NAME -- su -l -c "nohup sh $MOUNT_DIR/$SCHEMA_SCRIPT > $MOUNT_DIR/$SCHEMA_SCRIPT_LOG 2>&1 </dev/null &;echo \$!" db2inst1)

	while true
	do
		oc exec -t $POD_NAME -- su -l -c "ps -p $pid" db2inst1 > /dev/null 2>&1
		status=$?
		if [ $status -eq 0 ]; then
			write_log "Schema upgrade script (pid=$pid) is still running. Recheck after $WAIT_SECONDS seconds..."
			if (( $current_counter >= $COUNTER_MAX )); then
				write_log "Script is still active after $current_counter x $WAIT_SECONDS seconds rechecks"
				write_log "Main script has stopped monitoring this schema upgrade script"
				break
			fi
			sleep $WAIT_SECONDS
			let "current_counter+=1"
		else
			write_log "Upgrade script finished after $current_counter rechecks"
			break
		fi
	done

	write_log "Schema upgraded"
}

# Copy log file back to source run directory
function copy_log_back() {
	write_log "Copying log file back..."

	oc cp $catalog_node:$MOUNT_DIR/${SCHEMA_SCRIPT_LOG} ${SOURCE_DIR}/logs/${SCHEMA_SCRIPT_LOG} > /dev/null 2>&1

	write_log "Log file copied to source directory $SOURCE_DIR/logs"
}

# Main function

# Go through the upgrade steps
write_log "Start DB2 schema upgrade for namespace '$NAME_SPACE'"

identify_catalog_node
copy_files
execute_upgrade
status=$?
copy_log_back

write_log "End DB2 schema upgrade for namespace '$NAME_SPACE'"

exit $status
