#!/bin/bash
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2020, 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
################################################################# 

SELF_FILE=`basename $0`

if [[ $# -lt 1 ]]; then
    echo "Usage: $SELF_FILE [start/stop]"
    echo ""
    echo "- stop will write a .previousGuardiumDSCsReplicas file used for restarting the services"
    echo "- start will use the .previousGuardiumDSCsReplicas file created from stop"
    exit 1
fi

X=`oc get deployments,statefulsets -lproject=insights -oname`
if [ "X$1" == "Xstop" ]; then
    echo '' > .previousGuardiumDSCsReplicas
    for i in $X; do 
        Y=`oc get $i -ogo-template='{{ .spec.replicas }}'`; 
        I=`echo $i | sed -e 's#[-\./]#_#g'`; 
        echo $I=$Y >> .previousGuardiumDSCsReplicas;
    done
    oc scale `oc get deployments,statefulsets -lproject=insights -oname` --replicas=0
    echo "Successfully Stopped Guardium Data Security Center microservices"
elif [ "X$1" == "Xstart" ]; then
    if [ ! -f .previousGuardiumDSCsReplicas ]; then
        echo "Error cannot find .previousGuardiumDSCsReplicas previously created by '$SELF_FILE stop' used to scale back up to the previous number"
        echo ""
        echo "Please run to get a list of Guardium Data Security Center deployments | statefulsets:"
        echo "> oc get deployments,statefulsets -lproject=insights -oname"
        echo "for each entry, please scale Each deployment | statefulset up manually by running:" 
        echo "> oc scale <output from previous command> --replicas=<replica_number>" 
        echo "where replica_number matches the value located in values-small/med/large.yaml depending on your deployment | statefulsets"
        exit 1

    fi
    source .previousGuardiumDSCsReplicas
    for i in $X; do 
        I=`echo $i | sed -e 's#[-\./]#_#g'`; 
        oc scale $i --replicas=${!I};
    done 
    echo Successfully Started Guardium Data Security Center microservices
fi
