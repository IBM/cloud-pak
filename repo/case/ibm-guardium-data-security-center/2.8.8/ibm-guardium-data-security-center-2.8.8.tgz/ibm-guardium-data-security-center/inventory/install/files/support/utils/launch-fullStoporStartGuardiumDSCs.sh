#!/bin/bash

#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export NAMESPACE= [ namespace for cloudctl login, e.g. gi ]
export ICP_ADDR= [ Cloudpak ICP address, e.g. cp-console.apps.guardium-insights.ibm.com ]   
export ICP_USER= [ Cloudpak ICP account, e.g. admin ] 
export ICP_PASSWD= [ Cloudpak ICP account password ]

## Check input parms 
if [ "$#" -ne 1 ] || [ "$1" != "stop" -a "$1" != "start" ]; then
    echo "Usage: $0 [stop|start]"
    exit 1
fi

cloudctl login -a https://${ICP_ADDR} --skip-ssl-validation -u ${ICP_USER} -p ${ICP_PASSWD} -n ${NAMESPACE}

## Check if the login was successful
if [ $? -ne 0 ]; then
    echo "Login failed. Please check your system status and try it again "
    exit 2 
fi

## Detect Guardium Data Security Center Resource Name 
GI_CR_NAME=`oc get guardiuminsights | awk 'NR>1 {print $1}'`
export GI_CR_NAME
echo "Detected Guardium Data Security Center Resource Name : $GI_CR_NAME "

## invoke stop or start  
if [ "X$1" == "Xstop" ]; then
	echo "STOPPING Guardium Data Security Center ..."
	. ${BASE_DIR}/fullStoporStartGuardiumDSCs.sh stop $NAMESPACE $GI_CR_NAME
elif [ "X$1" == "Xstart" ]; then
	echo "STARTING Guardium Data Security Center ..."
	. ${BASE_DIR}/fullStoporStartGuardiumDSCs.sh start $NAMESPACE $GI_CR_NAME
fi
