#!/bin/bash

NAMESPACE="ibm-cert-manager"
DISPLAY_NAME="ibm-cert-manager-4.2.2"
CHANNEL="v4.2"

# Define the YAML for the Namespace
namespace=$(cat <<EOF
apiVersion: v1
kind: Namespace
metadata:
  name: $NAMESPACE
EOF
)

# Define the YAML for the OperatorGroup
operatorgroup=$(cat <<EOF
apiVersion: operators.coreos.com/v1alpha2
kind: OperatorGroup
metadata:
  name: operatorgroup
  namespace: $NAMESPACE
EOF
)

# Define the combined YAML for the CatalogSource and Subscription
certmanager=$(cat <<EOF
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: ibm-cert-manager-catalog
  namespace: $NAMESPACE
spec:
  displayName: $DISPLAY_NAME
  publisher: IBM
  sourceType: grpc
  image: icr.io/cpopen/ibm-cert-manager-operator-catalog
  updateStrategy:
    registryPoll:
      interval: 45m
---
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: ibm-cert-manager-operator
  namespace: $NAMESPACE
spec:
  channel: $CHANNEL
  installPlanApproval: Automatic
  name: ibm-cert-manager-operator
  source: ibm-cert-manager-catalog
  sourceNamespace: $NAMESPACE
EOF
)

# Create the Namespace
echo "Creating namespace $NAMESPACE"
echo "$namespace" | kubectl apply -f -

# Check if any OperatorGroup exists before creating
echo "Check if any OperatorGroup exists before creating"
if kubectl get operatorgroup -n $NAMESPACE | grep -q .; then
  echo "An OperatorGroup already exists in namespace $NAMESPACE."
else
  echo "Creating OperatorGroup in namespace $NAMESPACE"
  echo "$operatorgroup" | kubectl apply -f -
fi

# Apply the CatalogSource and Subscription
echo "Applying CatalogSource and Subscription"
echo "$certmanager" | kubectl apply -f -
