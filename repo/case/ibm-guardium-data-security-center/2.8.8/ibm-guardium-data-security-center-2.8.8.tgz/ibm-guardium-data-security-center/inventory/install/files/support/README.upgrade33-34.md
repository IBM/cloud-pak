# Upgrade GI 3.3.x to 3.4.0 with Cloud Pak Foundational Services upgrade

## Prereqs
- Installed 3.3.x version with v3.19 IBM Common Services

## Upgrade to Cloud Pak Foundational Services v4

### Part I: Obtain the CASE bundle

Create the following environment variables with the installer image name and the version. For example, to use version 3.4.0, specify the 2.4.0 bundle file:
```
export CASE_NAME=ibm-guardium-insights
export CASE_VERSION=2.4.0
export LOCAL_CASE_DIR=$HOME/.ibm-pak/data/cases/$CASE_NAME/$CASE_VERSION
```
Save the CASE bundle locally:
```
oc ibm-pak get $CASE_NAME \
--version $CASE_VERSION \
--skip-verify
```
Tip: If you do not specify the CASE version, it will download the latest CASE.
Note: If you encounter an error similar to this:
```
No Case registries found for case ibm-cert-manager->=1.3.0 <1.3.1.tgz with the given repository URL information
FAILED
```
You may be experiencing a temporary communication problem with the remote repository. Wait a few minutes and try again.

### Part II: Install IBM Cert Manager and CPFSv4 Catalog

Note: Only catalog source creation for Cert manager  & CPFSv4 should be done.
Create a namespace for IBM Cert manager. The recommended namespace is ibm-cert-manager
```
oc create namespace ibm-cert-manager
```
Set the environment variable for --inventory parameter:
```
export CERT_MANAGER_INVENTORY_SETUP=ibmCertManagerOperatorSetup
```
Install the IBM Cert Manager Catalog:
```
oc ibm-pak launch $CASE_NAME \
  --version $CASE_VERSION \
  --action install-catalog \
  --inventory $CERT_MANAGER_INVENTORY_SETUP \
  --namespace openshift-marketplace \
  --args "--inputDir ${LOCAL_CASE_DIR}"
```
Check the pod and catalog source status:
```
oc get pods -n openshift-marketplace
oc get catalogsource -n openshift-marketplace
```

As we have to install CPFSv4 in same namespace as that of Guardium Insights 3.3.X is installed.

Note: Guardium Insights and CPFSv4 should reside on same namespace. 

e.g  gistaging  in below example is <The namespace where GI 3.3.X is already deployed/installed>

```
export NAMESPACE=gistaging
```
Set the environment variable for --inventory parameter:
```
export ICS_INVENTORY_SETUP=ibmCommonServiceOperatorSetup
```
Install the IBM Common Services Catalog:
```
oc ibm-pak launch $CASE_NAME \
  --version $CASE_VERSION \
  --action install-catalog \
  --inventory $ICS_INVENTORY_SETUP \
  --namespace ${NAMESPACE} \
  --args "--registry icr.io --recursive \
  --inputDir ${LOCAL_CASE_DIR}"

```
Check the pod and catalog source status:
```
oc get pods -n openshift-marketplace
oc get catalogsource -n openshift-marketplace
```

### Part III: Manually run the v3.19 ->v4 isolated Migration

Source reference - [Document link](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.4?topic=4x-isolated-migration)   

#### Prerequisites
Ensure cert manager catalog source is present (handled by Part II)
    
#### Isolation Migration Steps:

1. Download scripts and go to the installer_scripts directory.[Downloading Scripts Information](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.4?topic=co-downloading-scripts-additional-configuration-from-specific-version-case-bundle)

2. Isolate IBM Common Services
- Isolate the original instance of foundational services by running the isolate.sh script.
- Run the following command where  ics v3 -namespace is ibm-common-services & CPFSv4 - namespace is same as <The namespace where GI 3.3.0 is already deployed/installed>
 
```
./isolate.sh --original-cs-ns ibm-common-services --control-ns cs-control --excluded-ns ${NAMESPACE}
```

3. Migrate several standalone components of IBM Common Services 

```
./cp3pt0-deployment/setup_singleton.sh --operator-namespace ibm-common-services --cert-manager-source ibm-cert-manager-catalog --licensing-source ibm-licensing-catalog --license-accept -v 1 
```

#### Migrate IBM Common Services data to Cloud Pak Foundational Services

This step will copy data in the isolated original foundational services version 3.x scope and preload it into the foundational services version 4.x tenant's services namespace, and will be ready to be used by the new foundational services version 4.x services whenever they are installed

```
./preload_data.sh --original-cs-ns ibm-common-services --services-ns ${NAMESPACE}
```

#### Fresh Install Foundational services Version 4.5

As this is upgrade flow, the same namespace will be used further for IBM Guardium Insights installation as well. Example - gistaging
```
export NAMESPACE=gistaging
```
Set the environment variable for --inventory parameter:
  
```
export ICS_INVENTORY_SETUP=ibmCommonServiceOperatorSetup
```
Install IBM Common Services operators:

#Set ICS_SIZE to small if installing a GuardiumInsights size of values-xsmall or values-small
#Set ICS_SIZE to medium if installing a GuardiumInsights size of values-medium or higher
```
export ICS_SIZE=small
```
  
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $ICS_INVENTORY_SETUP \
   --action install-operator \
   --namespace ${NAMESPACE} \
   --args "--size ${ICS_SIZE} --inputDir ${LOCAL_CASE_DIR}"
 ```  
Run patch command.
```
oc patch CommonService common-service -p "{\"spec\":{\"operatorNamespace\":\"$NAMESPACE\",\"servicesNamespace\":\"$NAMESPACE\"}}" --type=merge
```
Ensure that all Common Services pods are in the "Running" or "Completed" state (this should take between 10 and 20 minutes):
```
oc get pods -n ${NAMESPACE}
```
**Validations.** .Retrieve the IBM Common Services Console [CPFSv4] credentials (required for IBM Security Guardium Insights installation):

The default username to access the console is cpadmin. You can get the password for the admin username by running this command:
```
oc -n ${NAMESPACE} get secret platform-auth-idp-credentials -o jsonpath='{.data.admin_password}' | base64 -d
```
The following is sample output:
```
EwK9dj_example_password_lZSzVsA
```
Based on the sample output, you would use EwK9dj_example_password_lZSzVsA as the password.

You can verify the status of the operators by running the following commands:
```
oc -n <operator-namespace> get csv
```
Following is a sample command and output:

```
 NAME                       DISPLAY                          VERSION   REPLACES                   PHASE
ibm-common-service-operator.v4.5             IBM Cloud Pak foundational services            4.5       ibm-common-service-operator.v3.23.0            Succeeded
```

Verify whether the CustomResourceDefinitions (CRDs) are created.
```
oc get crd | grep operandrequest
```
Following is a sample output:
```
NAME                               CREATED AT
operandrequests.operator.ibm.com   2020-09-18T10:10:22Z
```
Verify that common-service-maps has a new tenant with namespaces for foundational services version 4.x and the to-be-upgraded IBM Cloud Pak.
```
oc get cm common-service-maps -n kube-public -o yaml
```
#### Uninstall ICS v3.19
  
##NOTE: Before upgrading GI to 3.4.0, **Uninstall** ICSv3 in namespace ibm-common-services
  Refer [ICS Doc](https://www.ibm.com/docs/en/cloud-paks/foundational-services/3.19?topic=online-uninstalling-foundational-services)
 
1. Download the CASE package and extract installer-scripts directory. For more information, see [Downloading scripts for additional configuration from   specific version CASE bundle](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.5?topic=co-downloading-scripts-additional-configuration-from-specific-version-case-bundle)

2. Go to the ${installer-scripts}/cp3pt0-deployment directory.
```
./uninstall_tenant.sh --operator-namespace ibm-common-services
```
3. To uninstall the remaining components, you can download the following script from the scripts-adopter branch of the ibm-common-service-operator GitHub repository: [cleanup_cp2_control.sh.](https://github.com/IBM/ibm-common-service-operator/blob/scripts-adopter/cp3pt0-deployment/common/cleanup_cp2_control.sh)
``` 
./cleanup_cp2_control.sh
```
## Upgrade IBM Security Guardium Insights Operator and related components

Switch the namespace in which you had installed IBM Common Services in the previous step for your installation (for example, "gistaging"), and change the context into it. There are two ways to upgrade the guardium-insights operator as mentioned below:
1. Manual Installation
2. All in One Script Installation

### Manual Installation:
- Switch the namespace in which you had installed IBM Common Services in the previous step for your installation (for example, "staging"), and change the context into it:
```
oc project ${NAMESPACE}
```
- Run the pre-install script. This script sets up secrets and parameters for the IBM Security Guardium Insights instance. Make sure your workstation has met all of the prerequistes listed above before running the script.
```
export GI_INVENTORY_SETUP=install
```
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action pre-install \
   --namespace $NAMESPACE \
   --args "-n ${NAMESPACE} -h <DB worker host> -l <true/false>"
```
The parameters used in the script are described here:
```
MANDATORY PARAMETERS:
    -n --i-namespace      : IBM Security Guardium Insights Openshift namespace

    -h --host-datanodes   : Hostpath of the data node or nodes (comma-delimited).

    -l --label-datanodes  : If you specify 'true', data nodes will be labeled as dedicated for data service usage. If you specify 'false', labeling will be skipped.

OPTIONAL PARAMETERS:
    -t --taint-datanodes  : If you specify 'true', data nodes will be tainted and dedicated for data service usage. If you specify 'false', tainting will be skipped. Defaults to 'false'.

    -k --ingress-keystore : If you will supply a custom Ingress [Recommended], provide the path to its key file. The file must be \n delimited only. If you do not include this, a default of 'none' will be assumed (this is not recommended).

    -f --ingress-cert     : If you will supply a custom Ingress [Recommended], provide the path to its cert file. The file must be \n delimited only. If you do not include this, a default of 'none' will be assumed (this is not recommended).

    -c --ingress-ca       : If you will supply a custom Ingress [Recommended], provide the path to its certificate authority (CA) file. If you do not include this, a default of 'none' will be assumed (this is not recommended).
```
- Install the catalogs:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action install-catalog \
   --namespace openshift-marketplace \
   --args "--inputDir ${LOCAL_CASE_DIR}"
```
- Check that the catalogs are installed:
```
oc get catsrc                              
NAME                                         DISPLAY                                   TYPE   PUBLISHER   AGE
certified-operators                          Certified Operators                       grpc   Red Hat     29h
community-operators                          Community Operators                       grpc   Red Hat     29h
ibm-cloud-databases-redis-operator-catalog   ibm-cloud-databases-redis-1.6.5           grpc   IBM         29h
ibm-db2uoperator-catalog                     ibm-db2uoperator-5.1.4                    grpc   IBM         29h
ibm-guardium-insights-operator-catalog       ibm-guardium-insights-2.4.0-linux-amd64   grpc   IBM         29h
opencloud-operators                          IBMCS Operators                           grpc   IBM         29h
redhat-marketplace                           Red Hat Marketplace                       grpc   Red Hat     29h
redhat-operators                             Red Hat Operators                         grpc   Red Hat     29h
```
- Install the operators:
```
oc ibm-pak launch $CASE_NAME \
   --version $CASE_VERSION \
   --inventory $GI_INVENTORY_SETUP \
   --action install-operator \
   --namespace ${NAMESPACE} \
   --args "--registry cp.icr.io --user ${CP_REPO_USER} --pass ${CP_REPO_PASS} --secret ibm-entitlement-key --inputDir ${LOCAL_CASE_DIR}"
```
- Check that the operators are installed:
```
oc get sub        
NAME                                              PACKAGE                              SOURCE                                       CHANNEL
ibm-cloud-databases-redis-operator-subscription   ibm-cloud-databases-redis-operator   ibm-cloud-databases-redis-operator-catalog   v1.6
ibm-db2uoperator-catalog-subscription             db2u-operator                        ibm-db2uoperator-catalog                     v110508.0
ibm-guardium-insights-operator-subscription       ibm-guardium-insights-operator       ibm-guardium-insights-operator-catalog       v3.3
```
```
oc get csv          
NAME                                    DISPLAY                                                         VERSION      REPLACES                           PHASE
db2u-operator.v110508.0.2               IBM Db2                                                         110508.0.2                                      Succeeded
ibm-cloud-databases-redis.v1.6.5        IBM Operator for Redis                                          1.6.5        ibm-cloud-databases-redis.v1.6.4   Succeeded
ibm-guardium-insights-operator.v3.4.0   IBM Security Guardium Insights for IBM Cloud Pak for Security   3.4.0                                           Succeeded
```
```
oc get pods
```
Example output:
```
NAME                                                      READY      STATUS       RESTARTS      AGE
db2u-day2-ops-controller-manager-5488d5c844-vvhgt     1/1     Running   0          24h
db2u-operator-manager-5fc886d4bc-wwcrv                1/1     Running   0          24h
ibm-cloud-databases-redis-operator-6d668d7b88-z7fzh   1/1     Running   0          24h
ibm-guardium-insights-operator-75d6c489fd-qfkss       1/1     Running   0          24h
mongodb-kubernetes-operator-856bc86746-lfk69          1/1     Running   0          24h
```

- Upgrade the IBM Security Guardium Insights instance:
  - `oc edit guardiuminsights -n=<GI_NAMESPACE>`
    - Change the `version` to 3.4.0
    - Change the `license.licenseType` to a value that works for 3.4.0
    - Change the `guardiumInsightsGlobal.insights.ics.namespace` to GI_NAMESPACE e.g. gistaging

- Check the status of the instance upgrade:
```
   oc get guardiuminsights
```
* Example output:
```
NAME      TYPE      STATUS   REASON                           MESSAGE                                     DESIRED_VERSION   INSTALLED_VERSION
staging   Running   True     GuardiumInsightsInstallRunning   Running installation of Guardium Insights   3.4.0
```
* Example output when upgrade is complete:
```
NAME      TYPE    STATUS   REASON      MESSAGE                    DESIRED_VERSION   INSTALLED_VERSION
staging   Ready   True     Completed   Completed Reconciliation   3.4.0             3.4.0
```

### All in One Script Installation:

- Export all the required variables
```
export LOCAL_INSTALL_DIR=$HOME/guardium-insights
mkdir $LOCAL_INSTALL_DIR
export CASE_NAME=ibm-guardium-insights
export CASE_VERSION=2.4.0
export CASE_ARCHIVE=ibm-guardium-insights-$CASE_VERSION.tgz
export LOCAL_CASE_DIR=$HOME/.ibm-pak/data/cases/$CASE_NAME/$CASE_VERSION
```
- Extract case in the local directory for the CASE bundle
```
tar -xvf $LOCAL_CASE_DIR/$CASE_ARCHIVE --dir $LOCAL_CASE_DIR
```
- Edit the Configuration file and set the environment variables/parameters:
  - Edit the configuration file (`values.conf`) located in `$LOCAL_CASE_DIR/$CASE_NAME/inventory/automateInstall/files` by providing the mandatory parameters for an online and/or air-gapped/offline installation. 
  - Set **SKIP_INSTALL_ICS** in the configuration file to **'true'** because in the above steps we already installed ICS/CPFS v4 as a part of ICS/CPFS upgrade process.
  - Set **APPLY_CR** to **false** because the CR/GI-instance already exists on the system and we need to manually modify it.
  - Editing the optional parameters is not required for standard deployment, but you will have more customization options if you edit them. The optional parameters have an impact on the installation process - it is recommended that they should be edited only by advanced users.

- Run the following command to start the installation process of IBM Security Guardium Insights and its dependencies via all in one script 
```
  oc ibm-pak launch $CASE_NAME \
  --version $CASE_VERSION \
  --namespace ${NAMESPACE} \
  --inventory automateInstall \
  --action autoInstall \
  --tolerance 1 | tee -a ${LOCAL_INSTALL_DIR}/installation.log
```
- **Troubleshooting** - If the script fails, consult the installation.log file. In this file, these error messages can safely be ignored:
```
  Error from server (AlreadyExists): secrets "ibm-entitlement-key" already exists
```

- Upgrade the IBM Security Guardium Insights instance:
  - `oc edit guardiuminsights -n=<GI_NAMESPACE>`
    - Change the `version` to 3.4.0
    - Change the `license.licenseType` to a value that works for 3.4.0
    - Change the `guardiumInsightsGlobal.insights.ics.namespace` to GI_NAMESPACE e.g. gistaging

- Check the status of the instance upgrade:
```
   oc get guardiuminsights
```
* Example output:
```
NAME      TYPE      STATUS   REASON                           MESSAGE                                     DESIRED_VERSION   INSTALLED_VERSION
staging   Running   True     GuardiumInsightsInstallRunning   Running installation of Guardium Insights   3.4.0
```
* Example output when upgrade is complete:
```
NAME      TYPE    STATUS   REASON      MESSAGE                    DESIRED_VERSION   INSTALLED_VERSION
staging   Ready   True     Completed   Completed Reconciliation   3.4.0             3.4.0
```