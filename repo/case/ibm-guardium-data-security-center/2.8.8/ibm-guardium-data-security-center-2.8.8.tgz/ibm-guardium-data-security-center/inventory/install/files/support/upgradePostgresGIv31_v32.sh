#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2022. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeRiskCockpitGIv31_v32.sh
#
# DESCRIPTION:   Upgrade script to create risk cockpit tenants for Postgres
#
# USAGE:         This script takes two arguments:
#                   1) namespace
#                   2) master log filename
#
# PREREQUISITES: This script should be run at GI v3.2 level.
#
#----------------------------------------------------------------------------

NAME_SPACE="$1"
MASTER_LOG_FILE="$2"

# Check for required NAME_SPACE and MASTER_LOG_FILE parameters
THIS_SCRIPT=$(basename "$0")
if [ "$#" -ne 2 ]; then
	echo "Usage: $THIS_SCRIPT <namespace> <logfile>"
	exit 1
fi

# Local
SOURCE_DIR=$(pwd)

# DB2 pod
POD_NAME="c-$NAME_SPACE-db2-db2u-0"
PROGRES_SCRIPT="upgradePostgresGIv31_v32.sh"
LOG_TIMESTAMP=$(date "+%Y%m%d%H%M%S")
PROGRES_SCRIPT_LOG="${SOURCE_DIR}/logs/${THIS_SCRIPT%.*}_${LOG_TIMESTAMP}.log"
tenant_ids=""

# Write a timestamped message to the log file
function write_log() {
	message=$1
	timestamp=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$timestamp $THIS_SCRIPT: $message" >> $MASTER_LOG_FILE
}

# Retrieve list of tenants from database
function retrieve_tenants_list() {
	write_log "Start retrieving tenants list..."

	tenant_ids=`oc exec -t ${POD_NAME} -- bash -c "su - db2inst1 -c '<< EOF db2 -t
    CONNECT TO BLUDB;
    select schemaname from syscat.schemata;
    TERMINATE;
EOF'"  |awk '/TNT_.*/{printf "%s ", $1;}'`

	for tnt_id in $tenant_ids; do
		id="${tnt_id#TNT_}"
		write_log "${id}"
	done

	write_log "End retrieving tenants list..."
}

# Copy log file back to source run directory
function copy_log_back() {
	write_log "Copying log file back..."

	echo "$tenant_ids" > $PROGRES_SCRIPT_LOG

	write_log "Log file copied to source directory $SOURCE_DIR/logs"
}

# Initialize pg parameters

function initPgParams() {

    write_log "Getting Postgres Pods..."
    getPGPods=$(oc get pods | grep -e ${NAME_SPACE}-postgres-keeper-[0-9] | awk '{print $1}' | cut -d ' ' -f 2)
    pgPODS=( $getPGPods )

    PGPRIMARY_POD=${pgPODS[0]}

    DBUSER=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.username}" | base64 -d)
    DBUSERPWD=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.password}" | base64 -d)

    PGUSER=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.pgSUUser}" | base64 --decode)
    PGPASSWORD=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.pgSUPassword}"| base64 --decode)
    PGHOST=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.endpoint}" | base64 --decode)
    PGPORT=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.port}" | base64 --decode)
    PGDB=$(oc get secret ibm-postgres-authsecret -o jsonpath="{.data.database}" | base64 -d)
}

# Runs remote pg/sql commands to postgres
    
function pgRemoteCMD() {

    pg_remote_login="PGPASSWORD=${1} ${2} -h ${PGHOST} -p ${PGPORT} -U ${3} \
    -d ${4}"
    pg_remote_login_logdisplay="PGPASSWORD=***** ${2} -h ***** -p ***** -U ***** \
    -d ${4}"
    cmd=${5}
	
	write_log "cmd: oc exec -t ${PGPRIMARY_POD} -- /bin/bash -c \"${pg_remote_login_logdisplay} ${cmd}\""
	
    for i in {1..3}; do
        oc exec -t ${PGPRIMARY_POD} -- /bin/bash -c "${pg_remote_login} ${cmd}"
        rt=$?
        [[ ${rt} -eq 0 ]] && break
        write_log "Command ${cmd} failed with return code ${rt}, retry in 60 seconds"
        sleep 60
    done
}

function rmschemacreation() {

	for tnt_id in $tenant_ids; do
		accountid="${tnt_id,,}"
		schema_name="ra_$accountid"
		
		#commands to be run in postgres 
		check_schema_cmd="SELECT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name = '""\'$schema_name\'""');"
		clone_schema_cmd="SET search_path TO $schema_name,public; select ra_template.clone_schema('""\'ra_template\'""','""\'$schema_name\'""',false);"
		create_primary_scripts_cmd="SET search_path TO $schema_name,public; select $schema_name.create_primaryscripts();"
		
		exists=$(pgRemoteCMD "${PGPASSWORD}" "psql" "${PGUSER}" "${PGDB}" " -AXqtc '${check_schema_cmd}' ")
		if [ $exists = "t" ]  ; then
			write_log "Schema for account:$accountid already exists!! $(date +%F-%T)"
		else
			write_log "Proceeding.. as schema does not exists: $(date +%F-%T) "
			write_log "Creating schema for $accountid"
			pgRemoteCMD "${PGPASSWORD}" "psql" "${PGUSER}" "${PGDB}" " -c '${clone_schema_cmd}' " >> $PROGRES_SCRIPT_LOG
			pgRemoteCMD "${PGPASSWORD}" "psql" "${PGUSER}" "${PGDB}" " -c '${create_primary_scripts_cmd}' " >> $PROGRES_SCRIPT_LOG
		fi
		write_log "Completed schema creation for account:$accountid"
		write_log "End: $(date +%F-%T) "
	done
}

# Main function

# Go through the upgrade steps
write_log "Start creating risk cockpit for namespace '$NAME_SPACE'"

retrieve_tenants_list
status=$?
if [ $status != 0 ]; then
   write_log "Error: Failed retrieving tenant list"
   exit $status
fi
copy_log_back
status=$?
if [ $status != 0 ]; then
   write_log "Error: Could not copy tenant"
   exit $status
fi
initPgParams
status=$?
if [ $status != 0 ]; then
   write_log "Error: Not able to initiate pg params"
   exit $status
fi
rmschemacreation
status=$?
if [ $status != 0 ]; then
   write_log "Error: Failure in rm tenant creation"
   exit $status
fi

write_log "End creating risk cockpit for namespace '$NAME_SPACE'"

exit $status
