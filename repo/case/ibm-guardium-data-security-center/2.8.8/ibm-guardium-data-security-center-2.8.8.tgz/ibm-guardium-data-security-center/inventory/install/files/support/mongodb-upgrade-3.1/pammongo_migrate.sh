#!/bin/bash
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2021, 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

# /*******************************************************************************************************
#  * NAME: pammongo_migrate.sh
#  * DESCRIPTION: mongo pam migration for 3.0.2 -> 3.1
#  *******************************************************************************************************/


####################################################################################################################################################################################
#                                                            GENERAL INITIALZATION
####################################################################################################################################################################################

UTIL_SCRIPT=${UTIL_SCRIPT:-.}
NAMESPACE=${NAMESPACE:-staging}

function info_msg() {
  if [[ -z "${LOG_FILE}" ]]; then
    echo "$(date) INFO: $1"
  else
    echo "$(date) INFO: $1" | tee -a ${LOG_FILE}
  fi
}

function info_msgn() {
  if [[ -z "${LOG_FILE}" ]]; then
    echo -n "$(date) INFO: $1"
  else
    echo -n "$(date) INFO: $1" | tee -a ${LOG_FILE}
  fi
}

function error_msg() {
  if [[ -z "${LOG_FILE}" ]]; then
    echo "$(date) ERROR: $1"
  else
    echo "$(date) ERROR: $1" | tee -a ${LOG_FILE}
  fi
}

function warn_msg() {
  if [[ -z "${LOG_FILE}" ]]; then
    echo "$(date) WARN: $1"
  else
    echo "$(date) WARN: $1" | tee -a ${LOG_FILE}
  fi
}

function info_file() {
  if [[ -f $1 ]]; then
    if [[ -z "${LOG_FILE}" ]]; then
      echo "$(date) WARN: $1"
      cat $1
    else
      echo "$(date) WARN: $1" | tee -a ${LOG_FILE}
      cat $1 | tee -a ${LOG_FILE}
    fi
  else
    echo "$(date) ERROR: file $1 does exist" | tee -a ${LOG_FILE}
  fi
}

function gi_exit() {
  [[ ! -z "${SYS_DEBUG}" ]] && tail -f /dev/null
  exit $1
}

####################################################################################################################################################################################
#                                                            MONGO INITIALZATION
####################################################################################################################################################################################

function initMongoParams() {
    info_msg "Initializing MongoDB parameters..."

    info_msg "Getting MongoDB Password..."
    MONGO_PASSWORD=$(oc get secret ibm-mongodb-authsecret -ojsonpath='{.data.mongodbRootPassword}'| base64 -d)
    if [ -z ${MONGO_PASSWORD+x} ]; then
        error_msg "Unable to acquire MongoDB password"
        return 1
    else
        info_msg "MongoDB password acquired"
    fi

    info_msg "Getting MongoDB Endpoint..."
    MONGO_ENDPOINT=$(oc get secret ibm-mongodb-authsecret -ojsonpath='{.data.endpoint}'| base64 -d)
    if [ -z ${MONGO_ENDPOINT+x} ]; then
        error_msg "Unable to determine MongoDB endpoint"
        return 1
    else
        info_msg "MongoDB Endpoint: $MONGO_ENDPOINT"
    fi

    info_msg "Getting MongoDB Master Pod..."
    mongoPods=$(oc get pods | grep -e ${NAMESPACE}-mongodb-[0-9] | awk '{print $1}' | cut -d ' ' -f 2)
    MONGOPODS=( $mongoPods )

    MONGO_MASTER_POD=""
    SECONDARY_PODS=()

    for mongoPod in ${MONGOPODS[@]}; do

        isTrueMaster=$(oc exec $mongoPod -c mongod -- /bin/bash -c \
"mongo --tls --tlsCAFile=/var/lib/tls/ca/ca.crt --host=${MONGO_ENDPOINT} \
-u root -p ${MONGO_PASSWORD} \
--quiet --eval \
\"db.isMaster().ismaster\"")

        if [[ $isTrueMaster == true ]]; then
            MONGO_MASTER_POD=$mongoPod
        else
            SECONDARY_PODS+=($mongoPod)
        fi
    done

    info_msg "MongoDB Master Pod: $MONGO_MASTER_POD"

    # take the master pod as a default
    MONGO_BACKUP_POD=$MONGO_MASTER_POD
    # if there are secondary pods
    # set MongoDB backup pod as last secondary pod in the array
    local secondary_pod_cnt=${#SECONDARY_PODS[@]}
    if (( secondary_pod_cnt > 0 )); then
        info_msg "MongoDB Secondary Pods:${SECONDARY_PODS[*]}"
        # convert count to index of last item
        (( secondary_pod_cnt -= 1 ))
        MONGO_BACKUP_POD=${SECONDARY_PODS[$secondary_pod_cnt]}
    else
        warn_msg "No MongoDB Secondary Pods detected"
    fi

    info_msg "MongoDB Backup Pod: $MONGO_BACKUP_POD"

    # Get primary full name
    FULL_NAME=`oc exec ${MONGO_MASTER_POD} -c mongod -- /bin/bash -c "mongo --ssl --sslCAFile=/var/lib/tls/ca/ca.crt \
    --host=${MONGO_ENDPOINT} -u root -p ${MONGO_PASSWORD} --eval \"db.isMaster()\"" | grep primary | awk -F ":" '{print $2}' | cut -d '"' -f 2`

    PORT=`oc exec ${MONGO_MASTER_POD} -c mongod -- /bin/bash -c "mongo --ssl --sslCAFile=/var/lib/tls/ca/ca.crt \
    --host=${MONGO_ENDPOINT} -u root -p ${MONGO_PASSWORD} --eval \"db.isMaster()\"" | grep primary | awk -F ":" '{print $3}' | cut -d '"' -f 1`

    PRIMARY_POD_FULL_NAME="${FULL_NAME}:${PORT}"
    info_msg "Mongo Master POD FULL NAME:${PRIMARY_POD_FULL_NAME}"

    info_msg "MongoDB parameter initialization complete"

    return 0
}

####################################################################################################################################################################################
#                                                            MAIN LOOP
####################################################################################################################################################################################

initMongoParams

# check for file:
jsfile_result=`oc exec -n ${NAMESPACE} -t $MONGO_MASTER_POD -c mongod -- /bin/bash -c "if [ -f /tmp/pammigration.js ]; then echo 0; else echo 1; fi"`

# load file if found:
if [ $jsfile_result -eq 0 ]; then
	command_result=`oc exec -n ${NAMESPACE} -t $MONGO_MASTER_POD -c mongod -- /bin/bash -c "mongo --ssl --sslCAFile=/var/lib/tls/ca/ca.crt \
	--host=${MONGO_ENDPOINT} -u root -p ${MONGO_PASSWORD} --quiet --eval \"load('/tmp/pammigration.js')\""`
	echo "$(date) INFO: The PAM Migation file was loaded."
    exit 0
else
	echo "$(date) ERROR: The PAM Migration file could not be found, please upload to the mongo primary node and re-run this script."
    exit 1
fi
