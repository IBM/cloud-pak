-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."INSERT_POLICY_VIOLATIONS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  DECLARE INSERT_STMT_OF VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(32000)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20)
        ,ConstructId           VARCHAR(40)
        ,ProcessId             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

  -- insert the records into overflow table that are larger than 8192
  SET INSERT_STMT_OF = '
    INSERT INTO "'||TNT_ID||'"."OVERFLOW_FIELDS" (
        "TableName",
        "ID",
        "ColumnName",
        "Value",
        "ConfigID",
        "GlobalID"
    )
    SELECT
        ''POLICY_VIOLATION'',
        ViolationLogId,
        ''FullSQL'',
        CLOB(FullSQLString),
        ''0'',
        '''||GLOBALID||'''
    FROM "'||TNT_ID||'"."'||TABLENAME||'"
    WHERE LENGTH(TRIM(FullSQLString))>8192
    AND NOT EXISTS (
        SELECT 1 FROM "'||TNT_ID||'"."OVERFLOW_FIELDS" of
        WHERE of."TableName" = ''POLICY_VIOLATION'' AND of."ID" = ViolationLogId AND of."ColumnName" = ''FullSQL''
        AND ''0'' = of."ConfigID" AND '''||GLOBALID||''' = of."GlobalID"
    );';

  PREPARE STMT_2 FROM INSERT_STMT_OF;
  EXECUTE STMT_2;

SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID","OverflowFlagFullSQL")
	  SELECT
        ''POLICY_VIOLATION'',
        NULL,
        ViolationLogId,
        SessionId,
        UTCOffset,
        OSUser,
        DBUserName,
        AnalyzedClientIP,
        ClientHostName,
        SourceProgram,
        ServerIP,
        ServerType,
        ServiceName,
        ConstructId,
        ObjectsandVerbs,
        NULL,
        NULL,
        AccessRuleDescription,
        NULL,
        VARCHAR(FullSQLString,8192),
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        Severity,
        NULL,
        TIMESTAMP,
        TimestampUTC,
        ServerHostName,
        ''0'',
        '''||GLOBALID||''',
        ProcessId,
        CASE WHEN LENGTH(TRIM(FullSQLString))>8192 THEN 1 ELSE 0 END
    FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  PREPARE STMT_3 FROM INSERT_STMT;
  EXECUTE STMT_3;
  END S1
