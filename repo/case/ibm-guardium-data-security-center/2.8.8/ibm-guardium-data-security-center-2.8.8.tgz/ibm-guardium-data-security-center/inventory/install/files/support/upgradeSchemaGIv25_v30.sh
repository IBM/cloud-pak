#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2021, 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeSchemaGIv25_v30.sh
#
# DESCRIPTION:   DB2 Synchronization script for Guardium Insights v2.5 to v3.0
#
# USAGE:         This script takes no arguments and will update the BLUDB DB2 
#                databse from GI v2.5 schema to GI version v3.0. It should be 
#                run only once on a database that is configured with GI v2.5
#
# PREREQUISITES: This script should be run on a BLUDB database at GI v2.5 level.
#                Please ensure there is enough space available on the system in 
#                order for the upgrade to complete
#
#----------------------------------------------------------------------------



#----------------------------------------
# Update Views for Tenant Tables
#---------------------------------------
function updateViews() {

         schema=$1

 	 cat  <<EOF > updateViews.sql
--
-- DROP VIEWS
--
DROP VIEW "${schema}"."POLICY_VIOLATION_DATA";
DROP VIEW "${schema}"."EXCEPTION_DATA";
DROP VIEW "${schema}"."ACTIVITY_DATA";

--
-- ACTIVITY_DATA
-- 

CREATE VIEW "${schema}"."ACTIVITY_DATA" ("MessageType_FULL_SQL", "ID_FULL_SQL", "FullSQLID_FULL_SQL", "SessionID_FULL_SQL", "Timestamp_FULL_SQL", "TimestampUTC_FULL_SQL", "UTCOffset_FULL_SQL", "InstanceID_FULL_SQL", "AccessRuleDescription_FULL_SQL", "FullStatement_FULL_SQL", "TotalRecordsAffected_FULL_SQL", "Succeeded_FULL_SQL", "Status_FULL_SQL", "ResponseTime_FULL_SQL", "ACKResponseTime_FULL_SQL", "ConfigID_FULL_SQL", "GlobalID_FULL_SQL", "TenantID_FULL_SQL", "IngestTimestamp_FULL_SQL", "SQLSequenceInRequest_FULL_SQL", "BindVariablesValues_FULL_SQL", "MessageType_INSTANCE", "ID_INSTANCE", "InstanceID_INSTANCE", "SessionID_INSTANCE", "UTCOffset_INSTANCE", "PeriodStart_INSTANCE", "PeriodStartUTC_INSTANCE", "PeriodEnd_INSTANCE", "PeriodEndUTC_INSTANCE", "ApplicationEventID_INSTANCE", "AppUserName_INSTANCE", "ApplicationEventType_INSTANCE", "ApplicationEventValueStr_INSTANCE", "ApplicationEventValueNum_INSTANCE", "ApplicationEventDate_INSTANCE", "ApplicationEventDateUTC_INSTANCE", "ConstructID_INSTANCE", "OriginalSQL_INSTANCE", "ObjectsandVerbs_INSTANCE", "SuccessfulSqls_INSTANCE", "FailedSqls_INSTANCE", "DBUserName_INSTANCE", "OSUser_INSTANCE", "SourceProgram_INSTANCE", "ServerIP_INSTANCE", "ClientID_INSTANCE", "ServiceName_INSTANCE", "ClientHostName_INSTANCE", "ServerType_INSTANCE", "DatabaseName_INSTANCE", "EventUserName_INSTANCE", "ServerPort_INSTANCE", "NetworkProtocol_INSTANCE", "TotalRecordsAffected_INSTANCE", "ServerHostName_INSTANCE", "Timestamp_INSTANCE", "TimestampUTC_INSTANCE", "AverageExecutionTime_INSTANCE", "ConfigID_INSTANCE", "GlobalID_INSTANCE", "TenantID_INSTANCE", "IngestTimestamp_INSTANCE", "TotalCount_INSTANCE", "Db2ClientInfo_INSTANCE", "Db2IZDatabase_INSTANCE", "Db2ICurrentUser_INSTANCE", "Db2IZProgram_INSTANCE", "ProcessID_INSTANCE", "DBProtocol_INSTANCE", "MessageType_SESSION", "ID_SESSION", "SessionID_SESSION", "DatabaseType_SESSION", "ServerOS_SESSION", "ClientOS_SESSION", "ServerID_SESSION", "ClientID_SESSION", "NetworkProtocol_SESSION", "DBProtocol_SESSION", "DBProtocolVersion_SESSION", "DBUserName_SESSION", "OSUser_SESSION", "SourceProgram_SESSION", "ClientHostName_SESSION", "ServerHostName_SESSION", "ServiceName_SESSION", "KeyValue_SESSION", "DatabaseName_SESSION", "ClientPort_SESSION", "ServerPort_SESSION", "SourceID_SESSION", "UTCOffset_SESSION", "OldSessionID_SESSION", "SessionStart_SESSION", "SessionStartUTC_SESSION", "SessionEnd_SESSION", "SessionEndUTC_SESSION", "TTL_SESSION", "SessionInfo_SESSION", "InactiveFlag_SESSION", "SessionIgnored_SESSION", "IgnoreSince_SESSION", "IgnoreSinceUTC_SESSION", "UIDChain_SESSION", "UIDChainCompressed_SESSION", "FailOverFlag_SESSION", "FailoverTimestamp_SESSION", "FailoverTimestampUTC_SESSION", "Mills_SESSION", "RequiredUIDChainFromParent_SESSION", "LoginSucceeded_SESSION", "SenderIP_SESSION", "SessionKey_SESSION", "CharEncoding_SESSION", "TapIdentifier_SESSION", "AccessID_SESSION", "ServerIP_SESSION", "ServerType_SESSION", "ConfigID_SESSION", "GlobalID_SESSION", "TenantID_SESSION", "IngestTimestamp_SESSION", "ProcessID_SESSION") AS SELECT "a"."MessageType", "a"."ID", "a"."FullSQLID", "a"."SessionID", "a"."Timestamp", "a"."TimestampUTC", "a"."UTCOffset", "a"."InstanceID", "a"."AccessRuleDescription", "a"."FullStatement", "a"."TotalRecordsAffected", "a"."Succeeded", "a"."Status", "a"."ResponseTime", "a"."ACKResponseTime", "a"."ConfigID", "a"."GlobalID", "a"."TenantID", "a"."IngestTimestamp", "a"."SQLSequenceInRequest", "a"."BindVariablesValues", "b"."MessageType", "b"."ID", "b"."InstanceID", "b"."SessionID", "b"."UTCOffset", "b"."PeriodStart", "b"."PeriodStartUTC", "b"."PeriodEnd", "b"."PeriodEndUTC", "b"."ApplicationEventID", "b"."AppUserName", "b"."ApplicationEventType", "b"."ApplicationEventValueStr", "b"."ApplicationEventValueNum", "b"."ApplicationEventDate", "b"."ApplicationEventDateUTC", "b"."ConstructID", "b"."OriginalSQL", "b"."ObjectsandVerbs", "b"."SuccessfulSqls", "b"."FailedSqls", "b"."DBUserName", "b"."OSUser", "b"."SourceProgram", "b"."ServerIP", "b"."ClientID", "b"."ServiceName", "b"."ClientHostName", "b"."ServerType", "b"."DatabaseName", "b"."EventUserName", "b"."ServerPort", "b"."NetworkProtocol", "b"."TotalRecordsAffected", "b"."ServerHostName", "b"."Timestamp", "b"."TimestampUTC", "b"."AverageExecutionTime", "b"."ConfigID", "b"."GlobalID", "b"."TenantID", "b"."IngestTimestamp", "b"."TotalCount", "b"."Db2ClientInfo", "b"."Db2IZDatabase", "b"."Db2ICurrentUser", "b"."Db2IZProgram", "b"."ProcessID", "b"."DBProtocol", "c"."MessageType", "c"."ID", "c"."SessionID", "c"."DatabaseType", "c"."ServerOS", "c"."ClientOS", "c"."ServerID", "c"."ClientID", "c"."NetworkProtocol", "c"."DBProtocol", "c"."DBProtocolVersion", "c"."DBUserName", "c"."OSUser", "c"."SourceProgram", "c"."ClientHostName", "c"."ServerHostName", "c"."ServiceName", "c"."KeyValue", "c"."DatabaseName", "c"."ClientPort", "c"."ServerPort", "c"."SourceID", "c"."UTCOffset", "c"."OldSessionID", "c"."SessionStart", "c"."SessionStartUTC", "c"."SessionEnd", "c"."SessionEndUTC", "c"."TTL", "c"."SessionInfo", "c"."InactiveFlag", "c"."SessionIgnored", "c"."IgnoreSince", "c"."IgnoreSinceUTC", "c"."UIDChain", "c"."UIDChainCompressed", "c"."FailOverFlag", "c"."FailoverTimestamp", "c"."FailoverTimestampUTC", "c"."Mills", "c"."RequiredUIDChainFromParent", "c"."LoginSucceeded", "c"."SenderIP", "c"."SessionKey", "c"."CharEncoding", "c"."TapIdentifier", "c"."AccessID", "c"."ServerIP", "c"."ServerType", "c"."ConfigID", "c"."GlobalID", "c"."TenantID", "c"."IngestTimestamp", "c"."ProcessID" FROM "${schema}"."FULL_SQL" "a" FULL OUTER JOIN "${schema}"."INSTANCE" "b" ON "a"."SessionID" = "b"."SessionID" FULL OUTER JOIN "${schema}"."SESSION" "c" ON "b"."SessionID" = "c"."SessionID";

GRANT CONTROL ON ACTIVITY_DATA TO USER DB2INST1;
GRANT SELECT ON ACTIVITY_DATA TO USER DB2INST1 WITH GRANT OPTION;

--
-- EXCEPTION_DATA
-- 

CREATE VIEW "${schema}"."EXCEPTION_DATA" ("MessageType", "ID", "ExceptionTypeID", "ExceptionID", "UserName", "SourceAddress", "DestinationAddress", "DBProtocol", "AppUserName", "ExceptionDescription", "SQLStatement", "ErrorCause", "ErrorCode", "Timestamp", "TimestampUTC", "SessionID", "InformationLink", "UTCOffset", "Count", "SourceID", "ConfigID", "GlobalID", "TenantID", "IngestTimestamp", "Db2IZDatabase", "Db2ICurrentUser", "Db2IZProgram") AS SELECT "MessageType", "ID", "ExceptionTypeID", "ExceptionID", "UserName", "SourceAddress", "DestinationAddress", "DBProtocol", "AppUserName", "ExceptionDescription", "SQLStatement", "ErrorCause", "ErrorCode", "Timestamp", "TimestampUTC", "SessionID", "InformationLink", "UTCOffset", "Count", "SourceID", "ConfigID", "GlobalID", "TenantID", "IngestTimestamp", "Db2IZDatabase", "Db2ICurrentUser", "Db2IZProgram" FROM "${schema}"."EXCEPTION";


GRANT CONTROL ON EXCEPTION_DATA TO USER DB2INST1;
GRANT SELECT ON EXCEPTION_DATA TO USER DB2INST1 WITH GRANT OPTION;
GRANT UPDATE ON EXCEPTION_DATA TO USER DB2INST1 WITH GRANT OPTION;
GRANT INSERT ON EXCEPTION_DATA TO USER DB2INST1 WITH GRANT OPTION;
GRANT DELETE ON EXCEPTION_DATA TO USER DB2INST1 WITH GRANT OPTION;

--
-- POLICY_VIOLATION_DATA
-- 

CREATE VIEW "${schema}"."POLICY_VIOLATION_DATA" ("MessageType", "ID", "ViolationID", "SessionID", "UTCOffset", "OSUser", "DBUserName", "ClientID", "ClientHostName", "SourceProgram", "ServerIP", "ServerType", "ServiceName", "ConstructID", "ObjectsandVerbs", "AppUserName", "AccessRuleID", "AccessRuleDescription", "Verdict", "FullSQL", "SendMessage", "CurrentCounter", "KeyString", "CategoryName", "ClassificationName", "Severity", "PolicyDescription", "Timestamp", "TimestampUTC", "ServerHostName", "ConfigID", "GlobalID", "TenantID", "IngestTimestamp", "ProcessID") AS SELECT "MessageType", "ID", "ViolationID", "SessionID", "UTCOffset", "OSUser", "DBUserName", "ClientID", "ClientHostName", "SourceProgram", "ServerIP", "ServerType", "ServiceName", "ConstructID", "ObjectsandVerbs", "AppUserName", "AccessRuleID", "AccessRuleDescription", "Verdict", "FullSQL", "SendMessage", "CurrentCounter", "KeyString", "CategoryName", "ClassificationName", "Severity", "PolicyDescription", "Timestamp", "TimestampUTC", "ServerHostName", "ConfigID", "GlobalID", "TenantID", "IngestTimestamp", "ProcessID" FROM "${schema}"."POLICY_VIOLATION";


GRANT CONTROL ON POLICY_VIOLATION_DATA TO USER DB2INST1;
GRANT SELECT ON POLICY_VIOLATION_DATA TO USER DB2INST1 WITH GRANT OPTION;
GRANT UPDATE ON POLICY_VIOLATION_DATA TO USER DB2INST1 WITH GRANT OPTION;
GRANT INSERT ON POLICY_VIOLATION_DATA TO USER DB2INST1 WITH GRANT OPTION;
GRANT DELETE ON POLICY_VIOLATION_DATA TO USER DB2INST1 WITH GRANT OPTION;

EOF

	db2 -tvf updateViews.sql >>$logFile 2>&1
}

#-------------------------------
# Update Tables to GI v3.0 schema
#--------------------------------
function updateTables() {

	schema=$1
	tenant_short=$2


	cat <<EOF > updateTables.sql
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','FULL_SQL','GIV3_FULL_SQL','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ADMINCONSOLE_PARAMETER','GIV3_ADMINCONSOLE_PARAMETER','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ALERTS_SENT','GIV3_ALERTS_SENT','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ALERT_BUDGET_THRESHOLD','GIV3_ALERT_BUDGET_THRESHOLD','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ALERT_BUDGET_V2','GIV3_ALERT_BUDGET_V2','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ANALYSIS_MAINTENANCE','GIV3_ANALYSIS_MAINTENANCE','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ANALYTIC_LOG','GIV3_ANALYTIC_LOG','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ANALYTIC_OUTLIER','GIV3_ANALYTIC_OUTLIER','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','ANALYTIC_OUTLIER_SUMMARY','GIV3_ANALYTIC_OUTLIER_SUMMARY','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','CLASSIFICATION','GIV3_CLASSIFICATION','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','DB_ERROR_TEXT','GIV3_DB_ERROR_TEXT','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','EXCEPTION','GIV3_EXCEPTION','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','EXCEPTION_TYPE','GIV3_EXCEPTION_TYPE','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_DESC','GIV3_GROUP_DESC','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_GDP_SYNC','GIV3_GROUP_GDP_SYNC','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_MEMBER','GIV3_GROUP_MEMBER','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_TUPLES','GIV3_GROUP_TUPLES','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_TUPLE_PARAMETERS','GIV3_GROUP_TUPLE_PARAMETERS','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_TYPE','GIV3_GROUP_TYPE','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GROUP_TYPE_MAPPING','GIV3_GROUP_TYPE_MAPPING','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','GUARD_PARAMETERS','GIV3_GUARD_PARAMETERS','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','MESSAGE_SUMMARY','GIV3_MESSAGE_SUMMARY','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','NESTED_GROUP_MEMBER','GIV3_NESTED_GROUP_MEMBER','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','OBJECT','GIV3_OBJECT','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','OVERFLOW_FIELDS','GIV3_OVERFLOW_FIELDS','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','POLICY_VIOLATION','GIV3_POLICY_VIOLATION','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SCORES_LOG','GIV3_SCORES_LOG','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SENTENCE','GIV3_SENTENCE','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SESSION','GIV3_SESSION','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SEVERITY_DESC','GIV3_SEVERITY_DESC','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SOURCES_V2','GIV3_SOURCES_V2','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SOURCE_MESSAGE_STATS','GIV3_SOURCE_MESSAGE_STATS','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','SYSTEM_PARAMS','GIV3_SYSTEM_PARAMS','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','TEMP_MESSAGE_STATS','GIV3_TEMP_MESSAGE_STATS','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','USER_FEEDBACK','GIV3_USER_FEEDBACK','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');
CALL SYSPROC.ADMIN_MOVE_TABLE('${schema}','VULNERABILITY_ASSESSMENT','GIV3_VULNERABILITY_ASSESSMENT','ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE');

INSERT INTO"${schema}"."GIV3_INSTANCE"("MessageType","ID","InstanceID","SessionID","UTCOffset","PeriodStart","PeriodStartUTC","PeriodEnd","PeriodEndUTC","ApplicationEventID","AppUserName","ApplicationEventType","ApplicationEventValueStr","ApplicationEventValueNum","ApplicationEventDate","ApplicationEventDateUTC","ConstructID","OriginalSQL","ObjectsandVerbs","SuccessfulSqls","FailedSqls","DBUserName","OSUser","SourceProgram","ServerIP","ClientID","ServiceName","ClientHostName","ServerType","DatabaseName","EventUserName","ServerPort","NetworkProtocol","TotalRecordsAffected","ServerHostName","Timestamp","TimestampUTC","AverageExecutionTime","ConfigID","GlobalID","TenantID","IngestTimestamp")SELECT"MessageType","ID","InstanceID","SessionID","UTCOffset","PeriodStart","PeriodStartUTC","PeriodEnd","PeriodEndUTC","ApplicationEventID","AppUserName","ApplicationEventType","ApplicationEventValueStr","ApplicationEventValueNum","ApplicationEventDate",   "ApplicationEventDateUTC","ConstructID","OriginalSQL","ObjectsandVerbs","SuccessfulSqls","FailedSqls","DBUserName","OSUser","SourceProgram","ServerIP","ClientID","ServiceName","ClientHostName","ServerType","DatabaseName","EventUserName","ServerPort","NetworkProtocol","TotalRecordsAffected","ServerHostName","Timestamp","TimestampUTC","AverageExecutionTime","ConfigID", "GlobalID", "TenantID", "IngestTimestamp" FROM "${schema}"."INSTANCE";
SET SCHEMA "${schema}";
RENAME TABLE "INSTANCE" TO "GIV25_INSTANCE";
RENAME TABLE "GIV3_INSTANCE" TO "INSTANCE";
RUNSTATS ON TABLE "${schema}"."INSTANCE";

EOF

	db2 -tvf updateTables.sql >>$logFile 2>&1

}

#--------------------------------------------------
# Create the Tenant tablespaces
#--------------------------------------------------
function createTablespaces() {

	tenant_short=$1

	cat <<EOF > createTableSpaces.sql
CREATE TABLESPACE IGEN4_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE IGEN8_${tenant_short} PAGESIZE 8K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_8;
CREATE TABLESPACE ILG32_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_LG_32;
CREATE TABLESPACE IRPT8_${tenant_short} PAGESIZE 8K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_8;
CREATE TABLESPACE GRP4_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE OUT4_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE OUT8_${tenant_short} PAGESIZE 8K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_8;
CREATE TABLESPACE OUT32_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE LG32_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE GEN4_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE SESS_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE INST_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE FSQL_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE OVFFM_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE EXCEP_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE PVIO_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE SENT_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE OBJ_${tenant_short} PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4;
CREATE TABLESPACE VULA_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE CLASS_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE AUDLG_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
CREATE TABLESPACE USRNT_${tenant_short} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32;
EOF

	db2 -tvf createTableSpaces.sql >>$logFile 2>&1

}


#-------------------------------------------------
# Update predefine data tables
#------------------------------------------------

function updatePredefinedData() {

	schema=$1

	cat <<EOF > PredefinedData.sql 
INSERT INTO "${schema}"."GROUP_TYPE"("GROUP_TYPE_ID", "NAME") VALUES
		(18, 'Network protocol'),
        	(19, 'Application event string');

INSERT INTO "${schema}"."GROUP_TYPE_MAPPING"("GDP_GROUP_TYPE_ID", "GI_GROUP_TYPE_ID", "TUPLE_PARAMS") VALUES
		(10, 18, NULL),
        	(37, 19, NULL);

INSERT INTO "${schema}"."NESTED_GROUP_MEMBER"("MEMBER_ID","GROUP_ID","GROUP_MEMBER") VALUES
		(3, 15, 16),
		(4, 17, 18),
		(5, 19, 2),
		(6, 19, 13);

INSERT INTO "${schema}"."GROUP_DESC"("GROUP_ID","NAME","GROUP_TYPE_ID","NESTED") VALUES  
			(13,'SELECT commands',1, 0),
                        (14,'Risk-indicative Error Messages',14, 0),
                        (15,'Authorized server IPs',3,1),
                        (16,'Authorized server IPs - default',3,0),
			(17,'Authorized  users',16,1),
                        (18,'Authorized  users - default',16,1),
                        (19,'Database DML and SELECT Commands',1,1),
			(20,'Database DML, DDL, SELECT, DROP, DELETE and MODIFY Commands',1,0);


INSERT INTO "${schema}"."GROUP_MEMBER"("MEMBER_ID","GROUP_ID","GROUP_MEMBER") VALUES 
		     (420, 13, 'SELECT'),
                     (421, 13, 'SELECT LIST'),
                     (422, 20, 'AGGREGATE'),
                     (423, 20, 'ALTER BUFFERPOOL'),
                     (424, 20, 'ALTER CLUSTER'),
                     (425, 20, 'ALTER DIMENSION'),
                     (426, 20, 'ALTER EXTERNAL PROCEDURE'),
                     (427, 20, 'ALTER FULLTEXT CATALOG'),
                     (428, 20, 'ALTER FULLTEXT INDEX'),
                     (429, 20, 'ALTER FUNCTION'),
                     (430, 20, 'ALTER GROUPBUFFERPOOL'),
                     (431, 20, 'ALTER INDEX'),
                     (432, 20, 'ALTER INDEXTYPE'),
                     (433, 20, 'ALTER MATERIALIZED VIEW'),
                     (434, 20, 'ALTER MATERIALIZED VIEW LOG'),
                     (435, 20, 'ALTER METHOD'),
                     (436, 20, 'ALTER NICKNAME'),
                     (437, 20, 'ALTER OPERATOR'),
                     (438, 20, 'ALTER PACKAGE'),
                     (439, 20, 'ALTER PARTITION FUNCTION'),
                     (440, 20, 'ALTER PARTITION SCHEME'),
                     (441, 20, 'ALTER PROCECURE'),
                     (442, 20, 'ALTER PROCEDURE'),
                     (443, 20, 'ALTER QUEUE'),
                     (444, 20, 'ALTER REPLICATION GROUP'),
                     (445, 20, 'ALTER ROUTINE'),
                     (446, 20, 'ALTER SEQUENCE'),
                     (447, 20, 'ALTER SERVER'),
                     (448, 20, 'ALTER STOGROUP'),
                     (449, 20, 'ALTER TABLE'),
                     (450, 20, 'ALTER TABLESPACE'),
                     (451, 20, 'ALTER TRIGGER'),
                     (452, 20, 'ALTER TYPE'),
                     (453, 20, 'ALTER USER MAPPING'),
                     (454, 20, 'ALTER VIEW'),
                     (455, 20, 'ALTER XML SCHEMA COLLECTION'),
                     (456, 20, 'ANALYZE'),
                     (457, 20, 'BEGIN LOGGING'),
                     (458, 20, 'BEGIN QUERY LOGGING'),
                     (459, 20, 'BULK INSERT'),
                     (460, 20, 'COLLECT DEMOGRAPHICS'),
                     (461, 20, 'COLLECT STATISTICS'),
                     (462, 20, 'COLLMOD'),
                     (463, 20, 'COLLSTATS'),
                     (464, 20, 'COMMENT'),
                     (465, 20, 'COMPACT'),
                     (466, 20, 'COUNT'),
                     (467, 20, 'CREATE ALIAS'),
                     (468, 20, 'CREATE AUTHORIZATION'),
                     (469, 20, 'CREATE CAST'),
                     (470, 20, 'CREATE CLUSTER'),
                     (471, 20, 'CREATE DATABASE'),
                     (472, 20, 'CREATE DEFAULT'),
                     (473, 20, 'CREATE DIMENSION'),
                     (474, 20, 'CREATE DISTINCT TYPE'),
                     (475, 20, 'CREATE DUPLICATE'),
                     (476, 20, 'CREATE ERROR TABLE'),
                     (477, 20, 'CREATE EXISTING TABLE'),
                     (478, 20, 'CREATE EXTERNAL PROCEDURE'),
                     (479, 20, 'CREATE EXTERNAL TABLE'),
                     (480, 20, 'CREATE FULLTEXT CATALOG'),
                     (481, 20, 'CREATE FULLTEXT INDEX'),
                     (482, 20, 'CREATE FUNCTION'),
                     (483, 20, 'CREATE FUNCTION MAPPING'),
                     (484, 20, 'CREATE GLOBAL TEMPORARY TRACE TABLE'),
                     (485, 20, 'CREATE HASH INDEX'),
                     (486, 20, 'CREATE INDEX'),
                     (487, 20, 'CREATE INDEX EXTENSION'),
                     (488, 20, 'CREATE JOIN INDEX'),
                     (489, 20, 'CREATE LIBRARY'),
                     (490, 20, 'CREATE MACRO'),
                     (491, 20, 'CREATE MATERIALIZED VIEW'),
                     (492, 20, 'CREATE MATERIALIZED VIEW LOG'),
                     (493, 20, 'CREATE METHOD'),
                     (494, 20, 'CREATE NICKNAME'),
                     (495, 20, 'CREATE OPERATOR'),
                     (496, 20, 'CREATE OR REPLACE FUNCTION'),
                     (497, 20, 'CREATE OR REPLACE PROCEDURE'),
                     (498, 20, 'CREATE OR REPLACE TRIGGER'),
                     (499, 20, 'CREATE OR REPLACE VIEW'),
                     (500, 20, 'CREATE ORDERING'),
                     (501, 20, 'CREATE PACKAGE'),
                     (502, 20, 'CREATE PACKAGE BODY'),
                     (503, 20, 'CREATE PARATITION SCHEME'),
                     (504, 20, 'CREATE PARTITION FUNCTION'),
                     (505, 20, 'CREATE PROCEDURE'),
                     (506, 20, 'CREATE PROFILE'),
                     (507, 20, 'CREATE PROXY_TABLE'),
                     (508, 20, 'CREATE PUBLIC SYNONYM'),
                     (509, 20, 'CREATE RECURSIVE VIEW'),
                     (510, 20, 'CREATE REPLICATION GROUP'),
                     (511, 20, 'CREATE ROLE'),
                     (512, 20, 'CREATE ROUTINE FROM'),
                     (513, 20, 'CREATE RULE'),
                     (514, 20, 'CREATE SCHEMA'),
                     (515, 20, 'CREATE SEQUENCE'),
                     (516, 20, 'CREATE SYNONYM'),
                     (517, 20, 'CREATE TABLE'),
                     (518, 20, 'CREATE TRANSFORM'),
                     (519, 20, 'CREATE TRIGGER'),
                     (520, 20, 'CREATE TYPE'),
                     (521, 20, 'CREATE TYPE BODY'),
                     (522, 20, 'CREATE TYPE MAPPING'),
                     (523, 20, 'CREATE USER'),
                     (524, 20, 'CREATE VIEW'),
                     (525, 20, 'CREATE XML SCHEMA COLLECTION'),
                     (526, 20, 'DATABASE'),
                     (527, 20, 'DATASIZE'),
                     (528, 20, 'DELETE'),
                     (529, 20, 'DELETE DATABASE'),
                     (530, 20, 'DELETE STATISTICS'),
                     (531, 20, 'DELETE USER'),
                     (532, 20, 'DESCRIBE'),
                     (533, 20, 'DIAGNOSTIC "VALIDATE INDEX"'),
                     (534, 20, 'DIAGNOSTIC COSTPRINT'),
                     (535, 20, 'DIAGNOSTIC DUMP COSTS'),
                     (536, 20, 'DIAGNOSTIC DUMP SAMPLES'),
                     (537, 20, 'DIAGNOSTIC HELP COSTS'),
                     (538, 20, 'DIAGNOSTIC HELP PROFILE'),
                     (539, 20, 'DIAGNOSTIC HELP SAMPLES'),
                     (540, 20, 'DIAGNOSTIC SET COSTS'),
                     (541, 20, 'DIAGNOSTIC SET PROFILE'),
                     (542, 20, 'DIAGNOSTIC SET SAMPLES'),
                     (543, 20, 'DISTINCT'),
                     (544, 20, 'DROP'),
                     (545, 20, 'DROP ALIAS'),
                     (546, 20, 'DROP AUTHORIZATION'),
                     (547, 20, 'DROP BUFFERPOOL'),
                     (548, 20, 'DROP CAST'),
                     (549, 20, 'DROP CLUSTER'),
                     (550, 20, 'DROP CONTEXT'),
                     (551, 20, 'DROP CONTROLFILE'),
                     (552, 20, 'DROP DATABASE'),
                     (553, 20, 'DROP DATABASE LINK'),
                     (554, 20, 'DROP DATABASE PARTITION GROUP'),
                     (555, 20, 'DROP DEFAULT'),
                     (556, 20, 'DROP DIMENSION'),
                     (557, 20, 'DROP DIRECTORY'),
                     (558, 20, 'DROP DUPLICATE'),
                     (559, 20, 'DROP ERROR TABLE'),
                     (560, 20, 'DROP EVENT MONITOR'),
                     (561, 20, 'DROP EXISTING TABLE'),
                     (562, 20, 'DROP FULLTEXT CATALOG'),
                     (563, 20, 'DROP FULLTEXT INDEX'),
                     (564, 20, 'DROP FUNCTION'),
                     (565, 20, 'DROP FUNCTION MAPPING'),
                     (566, 20, 'DROP HASH INDEX'),
                     (567, 20, 'DROP INDEX'),
                     (568, 20, 'DROP INDEX EXTENSION'),
                     (569, 20, 'DROP INDEX PARTITION'),
                     (570, 20, 'DROP INDEXTYPE'),
                     (571, 20, 'DROP JAVA'),
                     (572, 20, 'DROP JOIN INDEX'),
                     (573, 20, 'DROP LIBRARY'),
                     (574, 20, 'DROP LOGIN'),
                     (575, 20, 'DROP MACRO'),
                     (576, 20, 'DROP MATERIALIZED VIEW'),
                     (577, 20, 'DROP MATERIALIZED VIEW LOG'),
                     (578, 20, 'DROP METHOD'),
                     (579, 20, 'DROP NICKNAME'),
                     (580, 20, 'DROP OPERATOR'),
                     (581, 20, 'DROP ORDERING'),
                     (582, 20, 'DROP OUTLINE'),
                     (583, 20, 'DROP PACKAGE'),
                     (584, 20, 'DROP PACKAGE BODY'),
                     (585, 20, 'DROP PARTITION'),
                     (586, 20, 'DROP PARTITION FUNCTION'),
                     (587, 20, 'DROP PARTITION GROUP'),
                     (588, 20, 'DROP PARTITION SCHEME'),
                     (589, 20, 'DROP PFILE'),
                     (590, 20, 'DROP PLAN'),
                     (591, 20, 'DROP PROCEDURE'),
                     (592, 20, 'DROP PROFILE'),
                     (593, 20, 'DROP PROXY TABLE'),
                     (594, 20, 'DROP PUBLIC SYNONYM'),
                     (595, 20, 'DROP REPLICATION GROUP'),
                     (596, 20, 'DROP ROLE'),
                     (597, 20, 'DROP ROLLBACK SEGMENT'),
                     (598, 20, 'DROP ROUTINE'),
                     (599, 20, 'DROP RULE'),
                     (600, 20, 'DROP SCHEMA'),
                     (601, 20, 'DROP SEQUENCE'),
                     (602, 20, 'DROP SERVER'),
                     (603, 20, 'DROP STATISTICS'),
                     (604, 20, 'DROP SYNONYM'),
                     (605, 20, 'DROP TABLE'),
                     (606, 20, 'DROP TABLE SUBPARTITION'),
                     (607, 20, 'DROP TABLESPACE'),
                     (608, 20, 'DROP TRANSFORM'),
                     (609, 20, 'DROP TRIGGER'),
                     (610, 20, 'DROP TYPE'),
                     (611, 20, 'DROP TYPE BODY'),
                     (612, 20, 'DROP TYPE MAPPING'),
                     (613, 20, 'DROP USER'),
                     (614, 20, 'DROP USER MAPPING'),
                     (615, 20, 'DROP VIEW'),
                     (616, 20, 'DROP VIEW HIERARCHY'),
                     (617, 20, 'DROP WRAPPER'),
                     (618, 20, 'DROP XML SCHEMA COLLECTION'),
                     (619, 20, 'DROPDATABASE'),
                     (620, 20, 'DUMP EXPLAIN'),
                     (621, 20, 'EMPTYCAPPED'),
                     (622, 20, 'END LOGGING'),
                     (623, 20, 'END QUERY LOGGING'),
                     (624, 20, 'EVAL'),
                     (625, 20, 'FINDANDMODIFY'),
                     (626, 20, 'GEONEAR'),
                     (627, 20, 'GEOSEARCH'),
                     (628, 20, 'GETDBSTATS'),
                     (629, 20, 'GIVE'),
                     (630, 20, 'GRANT'),
                     (631, 20, 'GRANT LOGON'),
                     (632, 20, 'GROUP'),
                     (633, 20, 'HELP'),
                     (634, 20, 'HELP CAST'),
                     (635, 20, 'HELP COLUMN'),
                     (636, 20, 'HELP CONSTRAINT'),
                     (637, 20, 'HELP DATABASE'),
                     (638, 20, 'HELP ERROR TABLE'),
                     (639, 20, 'HELP FUNCTION'),
                     (640, 20, 'HELP HASH INDEX'),
                     (641, 20, 'HELP INDEX'),
                     (642, 20, 'HELP JOIN INDEX'),
                     (643, 20, 'HELP MACRO'),
                     (644, 20, 'HELP METHOD'),
                     (645, 20, 'HELP PROCEDURE'),
                     (646, 20, 'HELP REPLICATION GROUP'),
                     (647, 20, 'HELP SESSION'),
                     (648, 20, 'HELP STATISTICS'),
                     (649, 20, 'HELP TABLE'),
                     (650, 20, 'HELP TRANSFORM'),
                     (651, 20, 'HELP TRIGGER'),
                     (652, 20, 'HELP TYPE'),
                     (653, 20, 'HELP USER'),
                     (654, 20, 'HELP VIEW'),
                     (655, 20, 'HELP VOLATILE TABLE'),
                     (656, 20, 'INITIATE INDEX ANALYSIS'),
                     (657, 20, 'INSERT'),
                     (658, 20, 'INSERT EXPLAIN'),
                     (659, 20, 'ISDBGRID'),
                     (660, 20, 'ISMASTER'),
                     (661, 20, 'LISTCOMMANDS'),
                     (662, 20, 'LISTDATABASES'),
                     (663, 20, 'LISTSHARDS'),
                     (664, 20, 'LOCK TABLE'),
                     (665, 20, 'LOGGING ONLINE ARCHIVE OFF'),
                     (666, 20, 'LOGGING ONLINE ARCHIVE ON'),
                     (667, 20, 'MODIFY DATABASE'),
                     (668, 20, 'MODIFY PROFILE'),
                     (669, 20, 'MODIFY USER'),
                     (670, 20, 'MOVE TABLE'),
                     (671, 20, 'REMOVE JAVA'),
                     (672, 20, 'RENAME'),
                     (673, 20, 'RENAME COLUMN'),
                     (674, 20, 'RENAME FUNCTION'),
                     (675, 20, 'RENAME INDEX'),
                     (676, 20, 'RENAME MACRO'),
                     (677, 20, 'RENAME PROCEDURE'),
                     (678, 20, 'RENAME SEQUENCE'),
                     (679, 20, 'RENAME TABLE'),
                     (680, 20, 'RENAME TRIGGER'),
                     (681, 20, 'RENAME VIEW'),
                     (682, 20, 'RENAMECOLLECTION'),
                     (683, 20, 'REORG'),
                     (684, 20, 'REPLACE AUTHORIZATION'),
                     (685, 20, 'REPLACE CAST'),
                     (686, 20, 'REPLACE FUNCTION'),
                     (687, 20, 'REPLACE MACRO'),
                     (688, 20, 'REPLACE METHOD'),
                     (689, 20, 'REPLACE ORDERING'),
                     (690, 20, 'REPLACE PROCEDURE'),
                     (691, 20, 'REPLACE RECURSIVE VIEW'),
                     (692, 20, 'REPLACE TRANSFORM'),
                     (693, 20, 'REPLACE TRIGGER'),
                     (694, 20, 'REPLACE VIEW'),
                     (695, 20, 'RESTART INDEX ANALYSIS'),
                     (696, 20, 'REVOKE'),
                     (697, 20, 'REVOKE LOGON'),
                     (698, 20, 'SELECT'),
                     (699, 20, 'SELECT LIST'),
                     (700, 20, 'SET ENCRYPTION PASSWORD'),
                     (701, 20, 'SET QUERY_BAND'),
                     (702, 20, 'SET ROLE'),
                     (703, 20, 'SET SESSION'),
                     (704, 20, 'SET TIME ZONE'),
                     (705, 20, 'SHOW CAST'),
                     (706, 20, 'SHOW ERROR TABLE'),
                     (707, 20, 'SHOW FUNCTION'),
                     (708, 20, 'SHOW HASH INDEX'),
                     (709, 20, 'SHOW JOIN INDEX'),
                     (710, 20, 'SHOW MACRO'),
                     (711, 20, 'SHOW METHOD'),
                     (712, 20, 'SHOW PROCEDURE'),
                     (713, 20, 'SHOW REPLICATION GROUP'),
                     (714, 20, 'SHOW TABLE'),
                     (715, 20, 'SHOW TRIGGER'),
                     (716, 20, 'SHOW TYPE'),
                     (717, 20, 'SHOW VIEW'),
                     (718, 20, 'TRUNCATE'),
                     (719, 20, 'TRUNCATE TABLE'),
                     (720, 20, 'UPDATE'),
                     (721, 20, 'UPDATE DIMENSION MEMBER'),
                     (722, 20, 'UPDATETEXT'),
                     (723, 20, 'WRITETEXT');

INSERT INTO "${schema}"."GROUP_MEMBER"("GROUP_ID","GROUP_MEMBER") VALUES 
	(19, 'AGGREGATE'),
	(19, 'BULK INSERT'),
	(19, 'COLLSTATS'),
	(19, 'COUNT'),
	(19, 'DATASIZE'),
	(19, 'DELETE'),
	(19, 'DISTINCT'),
	(19, 'EVAL'),
	(19, 'FINDANDMODIFY'),
	(19, 'GEONEAR'),
	(19, 'GEOSEARCH'),
	(19, 'GETDBSTATS'),
	(19, 'GROUP'),
	(19, 'INSERT'),
	(19, 'ISDBGRID'),
	(19, 'ISMASTER'),
	(19, 'LISTCOMMANDS'),
	(19, 'LISTDATABASES'),
	(19, 'LISTSHARDS'),
	(19, 'TRUNCATE'),
	(19, 'TRUNCATE TABLE'),
	(19, 'UPDATE'),
	(19, 'UPDATETEXT'),
	(19, 'WRITETEXT'),
	(19, 'SELECT'),
	(19, 'SELECT LIST');


EOF

	db2 -tvf PredefinedData.sql   >>$logFile 2>&1

}

function updateStoreProcedures() {


	schema=$1

	cat <<EOF > UpdatePL.sql
-- DROP PROCEDURES -----------
DROP PROCEDURE "${schema}"."INSERT_EXCEPTION"@
DROP PROCEDURE "${schema}"."INSERT_FULL_SQL"@
DROP PROCEDURE "${schema}"."INSERT_OBJ"@
DROP PROCEDURE "${schema}"."INSERT_POLICY_VIOLATIONS"@
DROP PROCEDURE "${schema}"."INSERT_SESSION"@


/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_CLASSIFICATION_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(50),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    TableType VARCHAR(50),
    DataType VARCHAR(255),
    MinimumLength DECIMAL(11),
    SearchValuePattern VARCHAR(255),
    SkipEmptyNull VARCHAR(50),
    ShowUniqueValues VARCHAR(50),
    ConfidenceScore VARCHAR(50))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;


    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "TableType", "DataType", "MinimumLength", "SearchValuePattern", "SkipEmptyNull", "ShowUniqueValues", "ConfidenceScore", "ConfigID", "GlobalID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        TableType,
        DataType,
        MinimumLength,
        SearchValuePattern,
        SkipEmptyNull,
        ShowUniqueValues,
        ConfidenceScore,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_CLASSIFICATION_v1" TO USER DB2INST1 WITH GRANT OPTION@


/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_CLASSIFICATION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(50),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    ResultDataRowID DECIMAL(20),
    Comments VARCHAR(32000))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;


    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_CLASSIFICATION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_FULL_SQL_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(32000),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID")
	  SELECT ''FULL_SQL'',
      NULL,
FullSQLID,
SessionId,
Timestamp,
TimestampUTC,
UTCOffset,
InstanceID,
AccessRuleDescription,
FullSql,
RecordsAffected,
Succeeded,
NULL,
ResponseTime,
NULL,
''0'',
'''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "FullSQLID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."FULL_SQL" mt where mt."FullSQLID" = Ext.FullSQLID AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_FULL_SQL_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_FULL_SQL_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(32000),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20),
    BindVariablesValues VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues")
	  SELECT ''FULL_SQL'',
      NULL,
FullSQLID,
SessionId,
Timestamp,
TimestampUTC,
UTCOffset,
InstanceID,
AccessRuleDescription,
FullSql,
RecordsAffected,
Succeeded,
NULL,
ResponseTime,
NULL,
''0'',
'''||GLOBALID||''',
BindVariablesValues FROM "'||TNT_ID||'"."'||TABLENAME||'"  Ext
WHERE NOT EXISTS (
Select "FullSQLID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."FULL_SQL" mt where mt."FullSQLID" = Ext.FullSQLID AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_FULL_SQL_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_INSTANCE_v2"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(1000),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(32000), AverageExecutionTime DECIMAL(11), Db2ClientInfo VARCHAR(32000), Db2IZDatabase VARCHAR(240), Db2ICurrentUser VARCHAR(240), Db2IZProgram VARCHAR(240), ProcessID VARCHAR(255), DBProtocol VARCHAR(20))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- Insert the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID", "Db2ClientInfo", "Db2IZDatabase", "Db2ICurrentUser", "Db2IZProgram", "ProcessID", "DBProtocol")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'',
                  ''' || GLOBALID || ''',
                  Db2ClientInfo,
                  Db2IZDatabase,
                  Db2ICurrentUser,
                  Db2IZProgram,
                  ProcessID,
                  DBProtocol FROM "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_INSTANCE_v2"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
    DECLARE TEMPTABLENAME VARCHAR(1000);
    DECLARE TEMPTABLECREATE VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(1000),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(32000), AverageExecutionTime DECIMAL(11), Db2ClientInfo VARCHAR(32000), Db2IZDatabase VARCHAR(240), Db2ICurrentUser VARCHAR(240), Db2IZProgram VARCHAR(240), ProcessID VARCHAR(255), DBProtocol VARCHAR(20))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- Insert the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID", "Db2ClientInfo", "Db2IZDatabase", "Db2ICurrentUser", "Db2IZProgram", "ProcessID", "DBProtocol")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'',
                  ''' || GLOBALID || ''',
                  Db2ClientInfo,
                  Db2IZDatabase,
                  Db2ICurrentUser,
                  Db2IZProgram,
                  ProcessID,
                  DBProtocol FROM "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_INSTANCE_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_OBJECT_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE OBJECTMERGE VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset               FLOAT
        ,SentenceId             VARCHAR(40)
        ,ConstructId            VARCHAR(40)
        ,ObjectId               VARCHAR(40)
        ,ObjectName             VARCHAR(255)
        ,Timestamp              TIMESTAMP
        ,TimestampUTC           TIMESTAMP)
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

	-- merge the object rows from the temp table
	SET OBJECTMERGE = 'MERGE INTO "' || TNT_ID || '"."OBJECT" AS "OBJECT"
	                  USING (SELECT DISTINCT "UTCOFFSET", "CONSTRUCTID", "SENTENCEID", "OBJECTID", "OBJECTNAME", "TIMESTAMP", "TIMESTAMPUTC" from "'||TNT_ID||'"."'||TABLENAME||'" WHERE "OBJECTID" IS NOT NULL) AS "OBJECT_MERGE"
	                  ON "OBJECT"."ConstructID" = "OBJECT_MERGE"."CONSTRUCTID" AND "OBJECT"."SentenceID" = "OBJECT_MERGE"."SENTENCEID" AND "OBJECT"."ObjectID" = "OBJECT_MERGE"."OBJECTID"
	                  WHEN NOT MATCHED THEN
	                  INSERT ("MessageType", "UTCOffset", "SentenceID", "ConstructID", "ObjectID", "ObjectName", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
	                  VALUES (''OBJECT'',
                      "OBJECT_MERGE"."UTCOFFSET",
	                  "OBJECT_MERGE"."SENTENCEID",
	                  "OBJECT_MERGE"."CONSTRUCTID",
	                  "OBJECT_MERGE"."OBJECTID",
	                  "OBJECT_MERGE"."OBJECTNAME",
	                  "OBJECT_MERGE"."TIMESTAMP",
                      "OBJECT_MERGE"."TIMESTAMPUTC",
                      ''0'', ''' || GLOBALID || ''')';
	PREPARE OMERGE FROM OBJECTMERGE;
	EXECUTE OMERGE;

  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_OBJECT_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_OVERFLOW_FIELDS_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_OVERFLOW_FIELDS_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_OVERFLOW_FIELDS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_OVERFLOW_FIELDS_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_POLICY_VIOLATIONS_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(32000)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      NULL,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
'''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ViolationID","ConfigID","GlobalID" from "'||TNT_ID||'"."POLICY_VIOLATION" mt where mt."ViolationID" = Ext.ViolationLogId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_POLICY_VIOLATIONS_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_POLICY_VIOLATIONS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(32000)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20)
        ,ConstructId           VARCHAR(40)
        ,ProcessId             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      ConstructId,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
      '''||GLOBALID||''',
      ProcessId FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ViolationID","ConfigID","GlobalID" from "'||TNT_ID||'"."POLICY_VIOLATION" mt where mt."ViolationID" = Ext.ViolationLogId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_POLICY_VIOLATIONS_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_SENTENCE_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE SENTENCEMERGE VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset               FLOAT
        ,SentenceId             VARCHAR(40)
        ,ConstructId            VARCHAR(40)
        ,Verb                   VARCHAR(40)
        ,Depth                  DECIMAL(11)
        ,ParentSentence         VARCHAR(40)
        ,Timestamp              TIMESTAMP
        ,TimestampUTC           TIMESTAMP)
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

  -- merge the sentence (verb) rows from the temp table
  SET SENTENCEMERGE = 'MERGE INTO "' || TNT_ID || '"."SENTENCE" AS "SENTENCE"
                      USING (SELECT DISTINCT "UTCOFFSET","SENTENCEID", "CONSTRUCTID", "VERB", "DEPTH", "PARENTSENTENCE", "TIMESTAMP", "TIMESTAMPUTC" from "'||TNT_ID||'"."'||TABLENAME||'") AS "SENTENCE_MERGE"
                      ON "SENTENCE"."ConstructID" = "SENTENCE_MERGE"."CONSTRUCTID" AND "SENTENCE"."SentenceID" = "SENTENCE_MERGE"."SENTENCEID"
                      WHEN NOT MATCHED THEN
                      INSERT ("MessageType", "UTCOffset","SentenceID", "ConstructID", "Verb", "Depth", "ParentSentenceID", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
                      VALUES (''SENTENCE'',
                      "SENTENCE_MERGE"."UTCOFFSET",
                      "SENTENCE_MERGE"."SENTENCEID",
                      "SENTENCE_MERGE"."CONSTRUCTID",
                      "SENTENCE_MERGE"."VERB",
                      "SENTENCE_MERGE"."DEPTH",
                      "SENTENCE_MERGE"."PARENTSENTENCE",
                      "SENTENCE_MERGE"."TIMESTAMP",
                      "SENTENCE_MERGE"."TIMESTAMPUTC",
                      ''0'', ''' || GLOBALID || ''')';
  PREPARE SMERGE FROM SENTENCEMERGE;
  EXECUTE SMERGE;

  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_SENTENCE_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_VA_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    TestResultID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DBName VARCHAR(255),
    VersionLevel VARCHAR(255),
    PatchLevel VARCHAR(255),
    FullVersionInfo VARCHAR(32000),
    Description VARCHAR(255),
    Host VARCHAR(255),
    TestDescription VARCHAR(150),
    TestScore DECIMAL(11),
    ScoreDescription VARCHAR(255),
    ResultText VARCHAR(32000),
    Recommendation VARCHAR(32000),
    Severity VARCHAR(60),
    Category VARCHAR(60),
    ExecutionDate TIMESTAMP,
    ExecutionDateUTC TIMESTAMP,
    AssessmentDescription VARCHAR(150),
    ServiceName VARCHAR(255),
    Port DECIMAL(11),
    DataSourceID DECIMAL(11),
    ResultDetails VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    SET INSERT_STMT = 'INSERT
	INTO  "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" ("MessageType", "UTCOffset", "TestResultID", "DataSourceName", "DataSourceType", "DBName", "VersionLevel", "PatchLevel", "FullVersionInfo", "Description", "Host", "TestDescription", "TestScore", "ScoreDescription", "ResultText", "Recommendation", "Severity", "Category", "ExecutionDate", "ExecutionDateUTC", "AssessmentDescription", "ServiceName", "Port", "DataSourceID", "ResultDetails", "ConfigID", "GlobalID")
	SELECT
        ''VULNERABILITY_ASSESSMENT'',
        UTCOffset,
        TestResultID,
        DataSourceName,
        DataSourceType,
        DBName,
        VersionLevel,
        PatchLevel,
        FullVersionInfo,
        Description,
        Host,
        TestDescription,
        TestScore,
        ScoreDescription,
        ResultText,
        Recommendation,
        Severity,
        Category,
        ExecutionDate,
        ExecutionDateUTC,
        AssessmentDescription,
        ServiceName,
        Port,
        DataSourceID,
        ResultDetails,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TestResultID","ConfigID","GlobalID" from "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" mt where mt."TestResultID" = Ext.TestResultID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_VA_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_VA_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    TestResultID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DBName VARCHAR(255),
    VersionLevel VARCHAR(255),
    PatchLevel VARCHAR(255),
    FullVersionInfo VARCHAR(32000),
    Description VARCHAR(255),
    Host VARCHAR(255),
    TestDescription VARCHAR(150),
    TestScore DECIMAL(11),
    ScoreDescription VARCHAR(255),
    ResultText VARCHAR(32000),
    Recommendation VARCHAR(32000),
    Severity VARCHAR(60),
    Category VARCHAR(60),
    ExecutionDate TIMESTAMP,
    ExecutionDateUTC TIMESTAMP,
    AssessmentDescription VARCHAR(150),
    ServiceName VARCHAR(255),
    Port DECIMAL(11),
    DataSourceID DECIMAL(11),
    ResultDetails VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    SET INSERT_STMT = 'INSERT
	INTO  "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" ("MessageType", "UTCOffset", "TestResultID", "DataSourceName", "DataSourceType", "DBName", "VersionLevel", "PatchLevel", "FullVersionInfo", "Description", "Host", "TestDescription", "TestScore", "ScoreDescription", "ResultText", "Recommendation", "Severity", "Category", "ExecutionDate", "ExecutionDateUTC", "AssessmentDescription", "ServiceName", "Port", "DataSourceID", "ResultDetails", "ConfigID", "GlobalID")
	SELECT
        ''VULNERABILITY_ASSESSMENT'',
        UTCOffset,
        TestResultID,
        DataSourceName,
        DataSourceType,
        DBName,
        VersionLevel,
        PatchLevel,
        FullVersionInfo,
        Description,
        Host,
        TestDescription,
        TestScore,
        ScoreDescription,
        ResultText,
        Recommendation,
        Severity,
        Category,
        ExecutionDate,
        ExecutionDateUTC,
        AssessmentDescription,
        ServiceName,
        Port,
        DataSourceID,
        ResultDetails,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TestResultID","ConfigID","GlobalID" from "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" mt where mt."TestResultID" = Ext.TestResultID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_VA_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ASSETS_EXTRACT_SP"(
    IN TNT_ID VARCHAR(1000),
    IN PREV_INGEST_TIME VARCHAR(1000),
    IN CURR_INGEST_TIME VARCHAR(1000)
    )
LANGUAGE SQL
DYNAMIC RESULT SETS 1
BEGIN
    -- Declare variables to use
    DECLARE extract_query VARCHAR(5000);
    DECLARE MYCUR CURSOR WITH RETURN TO CLIENT FOR S1;
	SET extract_query =
	'SELECT DISTINCT
       ''BROADCAST'' AS "RecordType",
        "'||TNT_ID||'"."SESSION"."DBUserName" AS "DBUserName",
        "'||TNT_ID||'"."SESSION"."SourceProgram" AS "SourceProgram",
        "'||TNT_ID||'"."SESSION"."ServerIP" AS "ServerIP",
        "'||TNT_ID||'"."SESSION"."ServiceName" AS "ServiceName",
        "'||TNT_ID||'"."SESSION"."DatabaseName" AS "DatabaseName",
        "'||TNT_ID||'"."INSTANCE"."AppUserName" AS "ApplicationUser",
        "'||TNT_ID||'"."INSTANCE"."ObjectsandVerbs" AS "ObjectsAndVerbs",
        "'||TNT_ID||'"."SESSION"."ServerType" AS "DatabaseType",
        "'||TNT_ID||'"."SESSION"."ServerPort" AS "ServerPort",
        "'||TNT_ID||'"."SESSION"."ServerHostName" AS "ServerHostName",
        "'||TNT_ID||'"."SESSION"."OSUser" AS "OSUser",
        '''||TNT_ID||''' AS "TenantID"

    FROM "'||TNT_ID||'"."INSTANCE" INNER JOIN "'||TNT_ID||'"."SESSION" ON "'||TNT_ID||'"."SESSION"."SessionID" = "'||TNT_ID||'"."INSTANCE"."SessionID"
    WHERE "'||TNT_ID||'"."INSTANCE"."IngestTimestamp" >= '''||PREV_INGEST_TIME||''' AND "'||TNT_ID||'"."INSTANCE"."IngestTimestamp" < '''||CURR_INGEST_TIME||'''
    ';

    PREPARE S1 FROM extract_query;

    OPEN MYCUR;

END@

GRANT EXECUTE ON PROCEDURE "${schema}"."ASSETS_EXTRACT_SP" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."EXTRACT_SP"(
    IN TNT_ID VARCHAR(1000),
    IN PREV_FULLSQL_TIME VARCHAR(1000),
    IN CURR_FULLSQL_TIME VARCHAR(1000),
    IN PREV_INGEST_TIME VARCHAR(1000),
    IN CURR_INGEST_TIME VARCHAR(1000)
    )
LANGUAGE SQL
DYNAMIC RESULT SETS 1
BEGIN
    -- Declare variables to use
    DECLARE extract_query VARCHAR(5000);
    DECLARE MYCUR CURSOR WITH RETURN TO CLIENT FOR S1;
	SET extract_query =
	'SELECT
       ''BROADCAST'' AS "RecordType",
        "'||TNT_ID||'"."FULL_SQL"."TimestampUTC" AS "Timestamp",
        "'||TNT_ID||'"."utcmillis"("'||TNT_ID||'"."FULL_SQL"."TimestampUTC") AS "UnixTimestamp",
        "'||TNT_ID||'"."FULL_SQL"."IngestTimestamp" AS "IngestTimestamp",
        varchar("'||TNT_ID||'"."FULL_SQL"."FullSQLID") AS "FullSQLID",
        varchar("'||TNT_ID||'"."SESSION"."SessionID") AS "SessionID",
        "'||TNT_ID||'"."FULL_SQL"."SQLSequenceInRequest" AS "SQLSequenceInRequest",
        "'||TNT_ID||'"."SESSION"."DBUserName" AS "DBUserName",
        "'||TNT_ID||'"."SESSION"."SourceProgram" AS "SourceProgram",
        "'||TNT_ID||'"."SESSION"."ServerIP" AS "ServerIP",
        "'||TNT_ID||'"."SESSION"."ServiceName" AS "ServiceName",
        "'||TNT_ID||'"."SESSION"."UTCOffset" AS "OriginalTimezone",
        CAST("'||TNT_ID||'"."FULL_SQL"."Succeeded" AS INT) AS "Status",
        CAST("'||TNT_ID||'"."FULL_SQL"."TotalRecordsAffected" AS INT) AS "TotalRecordsAffected",
        CAST("'||TNT_ID||'"."FULL_SQL"."ResponseTime" AS INT) AS "ResponseTime",
        "'||TNT_ID||'"."SESSION"."DatabaseName" AS "DatabaseName",
        "'||TNT_ID||'"."INSTANCE"."ConstructID" AS "ConstructID",
        "'||TNT_ID||'"."SESSION"."ClientID" AS "ClientIP",
        "'||TNT_ID||'"."INSTANCE"."AppUserName" AS "ApplicationUser",
        "'||TNT_ID||'"."INSTANCE"."ObjectsandVerbs" AS "ObjectsAndVerbs",
        "'||TNT_ID||'"."SESSION"."ServerType" AS "DatabaseType",
        "'||TNT_ID||'"."SESSION"."ServerPort" AS "ServerPort",
        "'||TNT_ID||'"."SESSION"."ServerHostName" AS "ServerHostName",
        "'||TNT_ID||'"."SESSION"."OSUser" AS "OSUser",
        '''||TNT_ID||''' AS "TenantID",
        "'||TNT_ID||'"."FULL_SQL"."GlobalID" AS "GlobalID",
        "'||TNT_ID||'"."FULL_SQL"."ConfigID" AS "ConfigID"


    FROM "'||TNT_ID||'"."FULL_SQL" INNER JOIN "'||TNT_ID||'"."SESSION" ON "'||TNT_ID||'"."SESSION"."SessionID" = "'||TNT_ID||'"."FULL_SQL"."SessionID" INNER JOIN "'||TNT_ID||'"."INSTANCE" ON "'||TNT_ID||'"."SESSION"."SessionID" = "'||TNT_ID||'"."INSTANCE"."SessionID" AND "'||TNT_ID||'"."INSTANCE"."InstanceID" = "'||TNT_ID||'"."FULL_SQL"."InstanceID"
    WHERE "'||TNT_ID||'"."FULL_SQL"."TimestampUTC" >= '''||PREV_FULLSQL_TIME||''' AND  "'||TNT_ID||'"."FULL_SQL"."TimestampUTC" < '''||CURR_FULLSQL_TIME||''' AND "'||TNT_ID||'"."FULL_SQL"."IngestTimestamp" >= '''||PREV_INGEST_TIME||''' AND "'||TNT_ID||'"."FULL_SQL"."IngestTimestamp" < '''||CURR_INGEST_TIME||'''
    ORDER BY "'||TNT_ID||'"."FULL_SQL"."TimestampUTC",
        "'||TNT_ID||'"."SESSION"."SessionID",
        "'||TNT_ID||'"."FULL_SQL"."SQLSequenceInRequest",
        "'||TNT_ID||'"."FULL_SQL"."FullSQLID" ASC';

    PREPARE S1 FROM extract_query;

    OPEN MYCUR;

END@


GRANT EXECUTE ON PROCEDURE "${schema}"."EXTRACT_SP" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_CLASSIFICATION_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(50),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    TableType VARCHAR(50),
    DataType VARCHAR(255),
    MinimumLength DECIMAL(11),
    SearchValuePattern VARCHAR(255),
    SkipEmptyNull VARCHAR(50),
    ShowUniqueValues VARCHAR(50),
    ConfidenceScore VARCHAR(50))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;


    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "TableType", "DataType", "MinimumLength", "SearchValuePattern", "SkipEmptyNull", "ShowUniqueValues", "ConfidenceScore", "ConfigID", "GlobalID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        TableType,
        DataType,
        MinimumLength,
        SearchValuePattern,
        SkipEmptyNull,
        ShowUniqueValues,
        ConfidenceScore,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_CLASSIFICATION_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_CLASSIFICATION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(50),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    ResultDataRowID DECIMAL(20),
    Comments VARCHAR(32000))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;


    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_CLASSIFICATION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_EXCEPTION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(32000)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(32000)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100)
        ,Db2IZDatabase                              VARCHAR(240)
        ,Db2ICurrentUser                            VARCHAR(240)
        ,Db2IZProgram                               VARCHAR(240))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
	  SELECT ''EXCEPTION'',
NULL,
ExceptionTypeID,
ExceptionID,
UserName,
SourceAddress,
DestinationAddress,
DatabaseProtocol,
AppUserName,
ExceptionDescription,
SQLstringthatcausedtheException,
DatabaseErrorText,
ErrorCode,
ExceptionTimestamp,
ExceptionTimestampUTC,
SessionId,
Linktomoreinformationabouttheexception,
UTCOffset,
NULL,
NULL,
''0'',
'''||GLOBALID||''',
Db2IZDatabase,
Db2ICurrentUser,
Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_EXCEPTION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_FULL_SQL_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(32000),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20),
    BindVariablesValues VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues")
	  SELECT ''FULL_SQL'',
      NULL,
FullSQLID,
SessionId,
Timestamp,
TimestampUTC,
UTCOffset,
InstanceID,
AccessRuleDescription,
FullSql,
RecordsAffected,
Succeeded,
NULL,
ResponseTime,
NULL,
''0'',
'''||GLOBALID||''',
BindVariablesValues FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_FULL_SQL_v2" TO USER DB2INST1 WITH GRANT OPTION@


/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_OBJECT_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE OBJECTMERGE VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset               FLOAT
        ,SentenceId             VARCHAR(40)
        ,ConstructId            VARCHAR(40)
        ,ObjectId               VARCHAR(40)
        ,ObjectName             VARCHAR(255)
        ,Timestamp              TIMESTAMP
        ,TimestampUTC           TIMESTAMP)
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

	-- merge the object rows from the temp table
	SET OBJECTMERGE = 'MERGE INTO "' || TNT_ID || '"."OBJECT" AS "OBJECT"
	                  USING (SELECT DISTINCT "UTCOFFSET", "CONSTRUCTID", "SENTENCEID", "OBJECTID", "OBJECTNAME", "TIMESTAMP", "TIMESTAMPUTC" from "'||TNT_ID||'"."'||TABLENAME||'" WHERE "OBJECTID" IS NOT NULL) AS "OBJECT_MERGE"
	                  ON "OBJECT"."ConstructID" = "OBJECT_MERGE"."CONSTRUCTID" AND "OBJECT"."SentenceID" = "OBJECT_MERGE"."SENTENCEID" AND "OBJECT"."ObjectID" = "OBJECT_MERGE"."OBJECTID"
	                  WHEN NOT MATCHED THEN
	                  INSERT ("MessageType", "UTCOffset", "SentenceID", "ConstructID", "ObjectID", "ObjectName", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
	                  VALUES (''OBJECT'',
                      "OBJECT_MERGE"."UTCOFFSET",
	                  "OBJECT_MERGE"."SENTENCEID",
	                  "OBJECT_MERGE"."CONSTRUCTID",
	                  "OBJECT_MERGE"."OBJECTID",
	                  "OBJECT_MERGE"."OBJECTNAME",
	                  "OBJECT_MERGE"."TIMESTAMP",
                      "OBJECT_MERGE"."TIMESTAMPUTC",
                      ''0'', ''' || GLOBALID || ''')';
	PREPARE OMERGE FROM OBJECTMERGE;
	EXECUTE OMERGE;

  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_OBJECT_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_OVERFLOW_FIELDS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_OVERFLOW_FIELDS_v2" TO USER DB2INST1 WITH GRANT OPTION@


/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_POLICY_VIOLATIONS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(32000)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20)
        ,ConstructId           VARCHAR(40)
        ,ProcessId             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      ConstructId,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
      '''||GLOBALID||''',
      ProcessId FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_POLICY_VIOLATIONS_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_SENTENCE_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE SENTENCEMERGE VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset               FLOAT
        ,SentenceId             VARCHAR(40)
        ,ConstructId            VARCHAR(40)
        ,Verb                   VARCHAR(40)
        ,Depth                  DECIMAL(11)
        ,ParentSentence         VARCHAR(40)
        ,Timestamp              TIMESTAMP
        ,TimestampUTC           TIMESTAMP)
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;

  -- merge the sentence (verb) rows from the temp table
  SET SENTENCEMERGE = 'MERGE INTO "' || TNT_ID || '"."SENTENCE" AS "SENTENCE"
                      USING (SELECT DISTINCT "UTCOFFSET","SENTENCEID", "CONSTRUCTID", "VERB", "DEPTH", "PARENTSENTENCE", "TIMESTAMP", "TIMESTAMPUTC" from "'||TNT_ID||'"."'||TABLENAME||'") AS "SENTENCE_MERGE"
                      ON "SENTENCE"."ConstructID" = "SENTENCE_MERGE"."CONSTRUCTID" AND "SENTENCE"."SentenceID" = "SENTENCE_MERGE"."SENTENCEID"
                      WHEN NOT MATCHED THEN
                      INSERT ("MessageType", "UTCOffset","SentenceID", "ConstructID", "Verb", "Depth", "ParentSentenceID", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
                      VALUES (''SENTENCE'',
                      "SENTENCE_MERGE"."UTCOFFSET",
                      "SENTENCE_MERGE"."SENTENCEID",
                      "SENTENCE_MERGE"."CONSTRUCTID",
                      "SENTENCE_MERGE"."VERB",
                      "SENTENCE_MERGE"."DEPTH",
                      "SENTENCE_MERGE"."PARENTSENTENCE",
                      "SENTENCE_MERGE"."TIMESTAMP",
                      "SENTENCE_MERGE"."TIMESTAMPUTC",
                      ''0'', ''' || GLOBALID || ''')';
  PREPARE SMERGE FROM SENTENCEMERGE;
  EXECUTE SMERGE;

  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_SENTENCE_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_SESSION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)

  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
    -- IF YOU GET STRANGE ERRORS, LOOK HERE FIRST!
	DECLARE CREATE_STMT VARCHAR(7000);
	DECLARE INSERT_STMT VARCHAR(7000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset           	DOUBLE
        ,SessionId				DECIMAL(20)
        ,AccessId				VARCHAR(40)
        ,SessionStart			TIMESTAMP
        ,SessionStartUTC        TIMESTAMP
        ,SessionEnd				TIMESTAMP
        ,SessionEndUTC          TIMESTAMP
        ,DatabaseName			VARCHAR(255)
        ,UidChain				VARCHAR(500)
        ,LoginSucceeded			DECIMAL(11)
        ,DBUserName				VARCHAR(255)
        ,OSUser				    VARCHAR(255)
        ,SourceProgram			VARCHAR(255)
        ,ServerIP				VARCHAR(50)
        ,AnalyzedClientIP		VARCHAR(50)
        ,ServiceName			VARCHAR(80)
        ,ClientHostName			VARCHAR(255)
        ,ServerType				VARCHAR(30)
        ,ServerHostName			VARCHAR(255)
        ,ServerPort				VARCHAR(10)
        ,ClientPort				VARCHAR(30)
        ,NetworkProtocol		VARCHAR(20)
        ,TapIdentifier			VARCHAR(255)
        ,SessionIgnored			VARCHAR(10)
        ,SenderIP				VARCHAR(50)
        ,InactiveFlag           DECIMAL(11)
        ,ProcessID             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'MERGE
	  INTO  "'||TNT_ID||'"."SESSION" AS "SESSION"
      USING "'||TNT_ID||'"."'||TABLENAME||'" AS "SESSION_MERGE" ("UTCOFFSET","SESSIONID","ACCESSID","SESSIONSTART","SESSIONSTARTUTC","SESSIONEND","SESSIONENDUTC","DATABASENAME","UIDCHAIN","LOGINSUCCEEDED","DBUSERNAME","OSUSER","SOURCEPROGRAM","SERVERIP","ANALYZEDCLIENTIP","SERVICENAME","CLIENTHOSTNAME","SERVERTYPE","SERVERHOSTNAME","SERVERPORT","CLIENTPORT","NETWORKPROTOCOL","TAPIDENTIFIER","SESSIONIGNORED","SENDERIP","INACTIVEFLAG", "PROCESSID")
      ON(
        "SESSION"."SessionID" = "SESSION_MERGE"."SESSIONID" AND
        "SESSION"."ConfigID"  = ''0'' AND
        "SESSION"."GlobalID"  = '''||GLOBALID||'''
        )
    WHEN MATCHED THEN
        UPDATE SET
            "SESSION"."ClientID" = "SESSION_MERGE"."ANALYZEDCLIENTIP",
            "SESSION"."NetworkProtocol" = "SESSION_MERGE"."NETWORKPROTOCOL",
            "SESSION"."DBUserName" = "SESSION_MERGE"."DBUSERNAME",
            "SESSION"."OSUser" = "SESSION_MERGE"."OSUSER",
            "SESSION"."SourceProgram" = "SESSION_MERGE"."SOURCEPROGRAM",
            "SESSION"."ClientHostName" = "SESSION_MERGE"."CLIENTHOSTNAME",
            "SESSION"."ServerHostName" = "SESSION_MERGE"."SERVERHOSTNAME",
            "SESSION"."ServiceName" = "SESSION_MERGE"."SERVICENAME",
            "SESSION"."DatabaseName" = "SESSION_MERGE"."DATABASENAME",
            "SESSION"."SessionStart" = "SESSION_MERGE"."SESSIONSTART",
            "SESSION"."SessionStartUTC" = "SESSION_MERGE"."SESSIONSTARTUTC",
            "SESSION"."SessionEnd" =  "SESSION_MERGE"."SESSIONEND",
            "SESSION"."SessionEndUTC" =  "SESSION_MERGE"."SESSIONENDUTC",
            "SESSION"."InactiveFlag" = "SESSION_MERGE"."INACTIVEFLAG",
            "SESSION"."SessionIgnored" = "SESSION_MERGE"."SESSIONIGNORED",
            "SESSION"."LoginSucceeded" = "SESSION_MERGE"."LOGINSUCCEEDED"
    WHEN NOT MATCHED THEN
        INSERT ("MessageType","ID","SessionID","DatabaseType","ServerOS","ClientOS","ServerID","ClientID","NetworkProtocol","DBProtocol","DBProtocolVersion","DBUserName","OSUser","SourceProgram","ClientHostName","ServerHostName","ServiceName","KeyValue","DatabaseName","ClientPort","ServerPort","SourceID","UTCOffset","OldSessionID","SessionStart","SessionStartUTC","SessionEnd","SessionEndUTC","TTL","SessionInfo","InactiveFlag","SessionIgnored","IgnoreSince","IgnoreSinceUTC","UIDChain","UIDChainCompressed","FailOverFlag","FailoverTimestamp","FailoverTimestampUTC","Mills","RequiredUIDChainFromParent","LoginSucceeded","SenderIP","SessionKey","CharEncoding","TapIdentifier","AccessID","ServerIP","ServerType","ConfigID","GlobalID","ProcessID")
        VALUES (
            ''SESSION'',
            NULL,
            "SESSION_MERGE"."SESSIONID",
            NULL,
            NULL,
            NULL,
            NULL,
            "SESSION_MERGE"."ANALYZEDCLIENTIP",
            "SESSION_MERGE"."NETWORKPROTOCOL",
            NULL,
            NULL,
            "SESSION_MERGE"."DBUSERNAME",
            "SESSION_MERGE"."OSUSER",
            "SESSION_MERGE"."SOURCEPROGRAM",
            "SESSION_MERGE"."CLIENTHOSTNAME",
            "SESSION_MERGE"."SERVERHOSTNAME",
            "SESSION_MERGE"."SERVICENAME",
            NULL,
            "SESSION_MERGE"."DATABASENAME",
            "SESSION_MERGE"."CLIENTPORT",
            "SESSION_MERGE"."SERVERPORT",
            NULL,
            "SESSION_MERGE"."UTCOFFSET",
            NULL,
            "SESSION_MERGE"."SESSIONSTART",
            "SESSION_MERGE"."SESSIONSTARTUTC",
            "SESSION_MERGE"."SESSIONEND",
            "SESSION_MERGE"."SESSIONENDUTC",
            NULL,
            NULL,
            "SESSION_MERGE"."INACTIVEFLAG",
            "SESSION_MERGE"."SESSIONIGNORED",
            NULL,
            NULL,
            "SESSION_MERGE"."UIDCHAIN",
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            "SESSION_MERGE"."LOGINSUCCEEDED",
            "SESSION_MERGE"."SENDERIP",
            NULL,
            NULL,
            "SESSION_MERGE"."TAPIDENTIFIER",
            "SESSION_MERGE"."ACCESSID",
            "SESSION_MERGE"."SERVERIP",
            "SESSION_MERGE"."SERVERTYPE",
            ''0'',
            '''||GLOBALID||''',
            "SESSION_MERGE"."PROCESSID")';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_SESSION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_VA_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    TestResultID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DBName VARCHAR(255),
    VersionLevel VARCHAR(255),
    PatchLevel VARCHAR(255),
    FullVersionInfo VARCHAR(32000),
    Description VARCHAR(255),
    Host VARCHAR(255),
    TestDescription VARCHAR(150),
    TestScore DECIMAL(11),
    ScoreDescription VARCHAR(255),
    ResultText VARCHAR(32000),
    Recommendation VARCHAR(32000),
    Severity VARCHAR(60),
    Category VARCHAR(60),
    ExecutionDate TIMESTAMP,
    ExecutionDateUTC TIMESTAMP,
    AssessmentDescription VARCHAR(150),
    ServiceName VARCHAR(255),
    Port DECIMAL(11),
    DataSourceID DECIMAL(11),
    ResultDetails VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    SET INSERT_STMT = 'INSERT
	INTO  "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" ("MessageType", "UTCOffset", "TestResultID", "DataSourceName", "DataSourceType", "DBName", "VersionLevel", "PatchLevel", "FullVersionInfo", "Description", "Host", "TestDescription", "TestScore", "ScoreDescription", "ResultText", "Recommendation", "Severity", "Category", "ExecutionDate", "ExecutionDateUTC", "AssessmentDescription", "ServiceName", "Port", "DataSourceID", "ResultDetails", "ConfigID", "GlobalID")
	SELECT
        ''VULNERABILITY_ASSESSMENT'',
        UTCOffset,
        TestResultID,
        DataSourceName,
        DataSourceType,
        DBName,
        VersionLevel,
        PatchLevel,
        FullVersionInfo,
        Description,
        Host,
        TestDescription,
        TestScore,
        ScoreDescription,
        ResultText,
        Recommendation,
        Severity,
        Category,
        ExecutionDate,
        ExecutionDateUTC,
        AssessmentDescription,
        ServiceName,
        Port,
        DataSourceID,
        ResultDetails,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_VA_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."PARQUET_EXTRACT_SP"(
    IN TNT_ID VARCHAR(1000),
    IN PREV_INGEST_TIME VARCHAR(1000),
    IN CURR_INGEST_TIME VARCHAR(1000),
    IN TABLE_NAME VARCHAR(1000)
    )
DYNAMIC RESULT SETS 1
LANGUAGE SQL
BEGIN
    -- Declare variables to use
    DECLARE extract_query VARCHAR(5000);
    DECLARE MYCUR CURSOR WITH RETURN TO CLIENT FOR S1;

    -- build extract query based on ingest timestamp and table name
	SET extract_query =
	'SELECT * FROM "'||TNT_ID||'"."'||TABLE_NAME||'"
     WHERE "'||TNT_ID||'"."'||TABLE_NAME||'"."IngestTimestamp" >= '''||PREV_INGEST_TIME||''' AND "'||TNT_ID||'"."'||TABLE_NAME||'"."IngestTimestamp" < '''||CURR_INGEST_TIME||'''';

    -- Prepare and execute the query
     PREPARE S1 FROM extract_query;
     OPEN MYCUR;

END@

GRANT EXECUTE ON PROCEDURE "${schema}"."PARQUET_EXTRACT_SP" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_SESSION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)

  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
    -- IF YOU GET STRANGE ERRORS, LOOK HERE FIRST!
	DECLARE CREATE_STMT VARCHAR(7000);
	DECLARE INSERT_STMT VARCHAR(7000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset           	DOUBLE
        ,SessionId				DECIMAL(20)
        ,AccessId				VARCHAR(40)
        ,SessionStart			TIMESTAMP
        ,SessionStartUTC        TIMESTAMP
        ,SessionEnd				TIMESTAMP
        ,SessionEndUTC          TIMESTAMP
        ,DatabaseName			VARCHAR(255)
        ,UidChain				VARCHAR(500)
        ,LoginSucceeded			DECIMAL(11)
        ,DBUserName				VARCHAR(255)
        ,OSUser				    VARCHAR(255)
        ,SourceProgram			VARCHAR(255)
        ,ServerIP				VARCHAR(50)
        ,AnalyzedClientIP		VARCHAR(50)
        ,ServiceName			VARCHAR(80)
        ,ClientHostName			VARCHAR(255)
        ,ServerType				VARCHAR(30)
        ,ServerHostName			VARCHAR(255)
        ,ServerPort				VARCHAR(10)
        ,ClientPort				VARCHAR(30)
        ,NetworkProtocol		VARCHAR(20)
        ,TapIdentifier			VARCHAR(255)
        ,SessionIgnored			VARCHAR(10)
        ,SenderIP				VARCHAR(50)
        ,InactiveFlag           DECIMAL(11)
        ,ProcessID             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'MERGE
	  INTO  "'||TNT_ID||'"."SESSION" AS "SESSION"
      USING "'||TNT_ID||'"."'||TABLENAME||'" AS "SESSION_MERGE" ("UTCOFFSET","SESSIONID","ACCESSID","SESSIONSTART","SESSIONSTARTUTC","SESSIONEND","SESSIONENDUTC","DATABASENAME","UIDCHAIN","LOGINSUCCEEDED","DBUSERNAME","OSUSER","SOURCEPROGRAM","SERVERIP","ANALYZEDCLIENTIP","SERVICENAME","CLIENTHOSTNAME","SERVERTYPE","SERVERHOSTNAME","SERVERPORT","CLIENTPORT","NETWORKPROTOCOL","TAPIDENTIFIER","SESSIONIGNORED","SENDERIP","INACTIVEFLAG", "PROCESSID")
      ON(
        "SESSION"."SessionID" = "SESSION_MERGE"."SESSIONID" AND
        "SESSION"."ConfigID"  = ''0'' AND
        "SESSION"."GlobalID"  = '''||GLOBALID||'''
        )
    WHEN MATCHED THEN
        UPDATE SET
            "SESSION"."ClientID" = "SESSION_MERGE"."ANALYZEDCLIENTIP",
            "SESSION"."NetworkProtocol" = "SESSION_MERGE"."NETWORKPROTOCOL",
            "SESSION"."DBUserName" = "SESSION_MERGE"."DBUSERNAME",
            "SESSION"."OSUser" = "SESSION_MERGE"."OSUSER",
            "SESSION"."SourceProgram" = "SESSION_MERGE"."SOURCEPROGRAM",
            "SESSION"."ClientHostName" = "SESSION_MERGE"."CLIENTHOSTNAME",
            "SESSION"."ServerHostName" = "SESSION_MERGE"."SERVERHOSTNAME",
            "SESSION"."ServiceName" = "SESSION_MERGE"."SERVICENAME",
            "SESSION"."DatabaseName" = "SESSION_MERGE"."DATABASENAME",
            "SESSION"."SessionStart" = "SESSION_MERGE"."SESSIONSTART",
            "SESSION"."SessionStartUTC" = "SESSION_MERGE"."SESSIONSTARTUTC",
            "SESSION"."SessionEnd" =  "SESSION_MERGE"."SESSIONEND",
            "SESSION"."SessionEndUTC" =  "SESSION_MERGE"."SESSIONENDUTC",
            "SESSION"."InactiveFlag" = "SESSION_MERGE"."INACTIVEFLAG",
            "SESSION"."SessionIgnored" = "SESSION_MERGE"."SESSIONIGNORED",
            "SESSION"."LoginSucceeded" = "SESSION_MERGE"."LOGINSUCCEEDED"
    WHEN NOT MATCHED THEN
        INSERT ("MessageType","ID","SessionID","DatabaseType","ServerOS","ClientOS","ServerID","ClientID","NetworkProtocol","DBProtocol","DBProtocolVersion","DBUserName","OSUser","SourceProgram","ClientHostName","ServerHostName","ServiceName","KeyValue","DatabaseName","ClientPort","ServerPort","SourceID","UTCOffset","OldSessionID","SessionStart","SessionStartUTC","SessionEnd","SessionEndUTC","TTL","SessionInfo","InactiveFlag","SessionIgnored","IgnoreSince","IgnoreSinceUTC","UIDChain","UIDChainCompressed","FailOverFlag","FailoverTimestamp","FailoverTimestampUTC","Mills","RequiredUIDChainFromParent","LoginSucceeded","SenderIP","SessionKey","CharEncoding","TapIdentifier","AccessID","ServerIP","ServerType","ConfigID","GlobalID","ProcessID")
        VALUES (
            ''SESSION'',
            NULL,
            "SESSION_MERGE"."SESSIONID",
            NULL,
            NULL,
            NULL,
            NULL,
            "SESSION_MERGE"."ANALYZEDCLIENTIP",
            "SESSION_MERGE"."NETWORKPROTOCOL",
            NULL,
            NULL,
            "SESSION_MERGE"."DBUSERNAME",
            "SESSION_MERGE"."OSUSER",
            "SESSION_MERGE"."SOURCEPROGRAM",
            "SESSION_MERGE"."CLIENTHOSTNAME",
            "SESSION_MERGE"."SERVERHOSTNAME",
            "SESSION_MERGE"."SERVICENAME",
            NULL,
            "SESSION_MERGE"."DATABASENAME",
            "SESSION_MERGE"."CLIENTPORT",
            "SESSION_MERGE"."SERVERPORT",
            NULL,
            "SESSION_MERGE"."UTCOFFSET",
            NULL,
            "SESSION_MERGE"."SESSIONSTART",
            "SESSION_MERGE"."SESSIONSTARTUTC",
            "SESSION_MERGE"."SESSIONEND",
            "SESSION_MERGE"."SESSIONENDUTC",
            NULL,
            NULL,
            "SESSION_MERGE"."INACTIVEFLAG",
            "SESSION_MERGE"."SESSIONIGNORED",
            NULL,
            NULL,
            "SESSION_MERGE"."UIDCHAIN",
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            NULL,
            "SESSION_MERGE"."LOGINSUCCEEDED",
            "SESSION_MERGE"."SENDERIP",
            NULL,
            NULL,
            "SESSION_MERGE"."TAPIDENTIFIER",
            "SESSION_MERGE"."ACCESSID",
            "SESSION_MERGE"."SERVERIP",
            "SESSION_MERGE"."SERVERTYPE",
            ''0'',
            '''||GLOBALID||''',
            "SESSION_MERGE"."PROCESSID")';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_SESSION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_EXCEPTION_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(32000)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(32000)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID")
	  SELECT ''EXCEPTION'',
NULL,
ExceptionTypeID,
ExceptionID,
UserName,
SourceAddress,
DestinationAddress,
DatabaseProtocol,
AppUserName,
ExceptionDescription,
SQLstringthatcausedtheException,
DatabaseErrorText,
ErrorCode,
ExceptionTimestamp,
ExceptionTimestampUTC,
SessionId,
Linktomoreinformationabouttheexception,
UTCOffset,
NULL,
NULL,
''0'',
'''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_EXCEPTION_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_EXCEPTION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(32000)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(32000)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100)
        ,Db2IZDatabase                              VARCHAR(240)
        ,Db2ICurrentUser                            VARCHAR(240)
        ,Db2IZProgram                               VARCHAR(240))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
	  SELECT ''EXCEPTION'',
NULL,
ExceptionTypeID,
ExceptionID,
UserName,
SourceAddress,
DestinationAddress,
DatabaseProtocol,
AppUserName,
ExceptionDescription,
SQLstringthatcausedtheException,
DatabaseErrorText,
ErrorCode,
ExceptionTimestamp,
ExceptionTimestampUTC,
SessionId,
Linktomoreinformationabouttheexception,
UTCOffset,
NULL,
NULL,
''0'',
'''||GLOBALID||''',
Db2IZDatabase,
Db2ICurrentUser,
Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@


GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_EXCEPTION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_CLASSIFICATION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(50),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    ResultDataRowID DECIMAL(20),
    Comments VARCHAR(32000))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;


    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ResultDataRowID","ConfigID","GlobalID" from "'||TNT_ID||'"."CLASSIFICATION" mt where mt."ResultDataRowID" = Ext.ResultDataRowID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_CLASSIFICATION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_EXCEPTION_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(32000)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(32000)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID")
	  SELECT ''EXCEPTION'',
NULL,
ExceptionTypeID,
ExceptionID,
UserName,
SourceAddress,
DestinationAddress,
DatabaseProtocol,
AppUserName,
ExceptionDescription,
SQLstringthatcausedtheException,
DatabaseErrorText,
ErrorCode,
ExceptionTimestamp,
ExceptionTimestampUTC,
SessionId,
Linktomoreinformationabouttheexception,
UTCOffset,
NULL,
NULL,
''0'',
'''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_EXCEPTION_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_EXCEPTION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(32000)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(32000)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100)
        ,Db2IZDatabase                              VARCHAR(240)
        ,Db2ICurrentUser                            VARCHAR(240)
        ,Db2IZProgram                               VARCHAR(240))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
	  SELECT ''EXCEPTION'',
NULL,
ExceptionTypeID,
ExceptionID,
UserName,
SourceAddress,
DestinationAddress,
DatabaseProtocol,
AppUserName,
ExceptionDescription,
SQLstringthatcausedtheException,
DatabaseErrorText,
ErrorCode,
ExceptionTimestamp,
ExceptionTimestampUTC,
SessionId,
Linktomoreinformationabouttheexception,
UTCOffset,
NULL,
NULL,
''0'',
'''||GLOBALID||''',
Db2IZDatabase,
Db2ICurrentUser,
Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_EXCEPTION_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_FULL_SQL_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(32000),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID")
	  SELECT ''FULL_SQL'',
      NULL,
FullSQLID,
SessionId,
Timestamp,
TimestampUTC,
UTCOffset,
InstanceID,
AccessRuleDescription,
FullSql,
RecordsAffected,
Succeeded,
NULL,
ResponseTime,
NULL,
''0'',
'''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "FullSQLID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."FULL_SQL" mt where mt."FullSQLID" = Ext.FullSQLID AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_FULL_SQL_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_FULL_SQL_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(32000),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20),
    BindVariablesValues VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues")
	  SELECT ''FULL_SQL'',
      NULL,
FullSQLID,
SessionId,
Timestamp,
TimestampUTC,
UTCOffset,
InstanceID,
AccessRuleDescription,
FullSql,
RecordsAffected,
Succeeded,
NULL,
ResponseTime,
NULL,
''0'',
'''||GLOBALID||''',
BindVariablesValues FROM "'||TNT_ID||'"."'||TABLENAME||'"  Ext
WHERE NOT EXISTS (
Select "FullSQLID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."FULL_SQL" mt where mt."FullSQLID" = Ext.FullSQLID AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_FULL_SQL_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_OVERFLOW_FIELDS_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_OVERFLOW_FIELDS_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_OVERFLOW_FIELDS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        TableName      VARCHAR(20),
        Id             DECIMAL(20),
        ColumnName     VARCHAR(20),
        Value          CLOB(63K))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."OVERFLOW_FIELDS" ("TableName","ID","ColumnName","Value","ConfigID","GlobalID")
	  SELECT
        TableName,
        Id,
        ColumnName,
        Value,
        ''0'',
        ''' || GLOBALID || '''
        FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TableName","ID","ColumnName","Value","ConfigID","GlobalID" from "'||TNT_ID||'"."OVERFLOW_FIELDS" mt where mt."TableName" = Ext.TableName AND mt."ID" = Ext.Id AND mt."ColumnName" = Ext.ColumnName AND mt."Value" = Ext.Value AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_OVERFLOW_FIELDS_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_POLICY_VIOLATIONS_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(32000)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      NULL,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
'''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ViolationID","ConfigID","GlobalID" from "'||TNT_ID||'"."POLICY_VIOLATION" mt where mt."ViolationID" = Ext.ViolationLogId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_POLICY_VIOLATIONS_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_POLICY_VIOLATIONS_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(32000)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20)
        ,ConstructId           VARCHAR(40)
        ,ProcessId             VARCHAR(255))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      ConstructId,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
      '''||GLOBALID||''',
      ProcessId FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ViolationID","ConfigID","GlobalID" from "'||TNT_ID||'"."POLICY_VIOLATION" mt where mt."ViolationID" = Ext.ViolationLogId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_POLICY_VIOLATIONS_v2" TO USER DB2INST1 WITH GRANT OPTION@

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_VA_v1" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    TestResultID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DBName VARCHAR(255),
    VersionLevel VARCHAR(255),
    PatchLevel VARCHAR(255),
    FullVersionInfo VARCHAR(32000),
    Description VARCHAR(255),
    Host VARCHAR(255),
    TestDescription VARCHAR(150),
    TestScore DECIMAL(11),
    ScoreDescription VARCHAR(255),
    ResultText VARCHAR(32000),
    Recommendation VARCHAR(32000),
    Severity VARCHAR(60),
    Category VARCHAR(60),
    ExecutionDate TIMESTAMP,
    ExecutionDateUTC TIMESTAMP,
    AssessmentDescription VARCHAR(150),
    ServiceName VARCHAR(255),
    Port DECIMAL(11),
    DataSourceID DECIMAL(11),
    ResultDetails VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    SET INSERT_STMT = 'INSERT
	INTO  "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" ("MessageType", "UTCOffset", "TestResultID", "DataSourceName", "DataSourceType", "DBName", "VersionLevel", "PatchLevel", "FullVersionInfo", "Description", "Host", "TestDescription", "TestScore", "ScoreDescription", "ResultText", "Recommendation", "Severity", "Category", "ExecutionDate", "ExecutionDateUTC", "AssessmentDescription", "ServiceName", "Port", "DataSourceID", "ResultDetails", "ConfigID", "GlobalID")
	SELECT
        ''VULNERABILITY_ASSESSMENT'',
        UTCOffset,
        TestResultID,
        DataSourceName,
        DataSourceType,
        DBName,
        VersionLevel,
        PatchLevel,
        FullVersionInfo,
        Description,
        Host,
        TestDescription,
        TestScore,
        ScoreDescription,
        ResultText,
        Recommendation,
        Severity,
        Category,
        ExecutionDate,
        ExecutionDateUTC,
        AssessmentDescription,
        ServiceName,
        Port,
        DataSourceID,
        ResultDetails,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TestResultID","ConfigID","GlobalID" from "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" mt where mt."TestResultID" = Ext.TestResultID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_VA_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_VA_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    TestResultID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DBName VARCHAR(255),
    VersionLevel VARCHAR(255),
    PatchLevel VARCHAR(255),
    FullVersionInfo VARCHAR(32000),
    Description VARCHAR(255),
    Host VARCHAR(255),
    TestDescription VARCHAR(150),
    TestScore DECIMAL(11),
    ScoreDescription VARCHAR(255),
    ResultText VARCHAR(32000),
    Recommendation VARCHAR(32000),
    Severity VARCHAR(60),
    Category VARCHAR(60),
    ExecutionDate TIMESTAMP,
    ExecutionDateUTC TIMESTAMP,
    AssessmentDescription VARCHAR(150),
    ServiceName VARCHAR(255),
    Port DECIMAL(11),
    DataSourceID DECIMAL(11),
    ResultDetails VARCHAR(32000))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    SET INSERT_STMT = 'INSERT
	INTO  "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" ("MessageType", "UTCOffset", "TestResultID", "DataSourceName", "DataSourceType", "DBName", "VersionLevel", "PatchLevel", "FullVersionInfo", "Description", "Host", "TestDescription", "TestScore", "ScoreDescription", "ResultText", "Recommendation", "Severity", "Category", "ExecutionDate", "ExecutionDateUTC", "AssessmentDescription", "ServiceName", "Port", "DataSourceID", "ResultDetails", "ConfigID", "GlobalID")
	SELECT
        ''VULNERABILITY_ASSESSMENT'',
        UTCOffset,
        TestResultID,
        DataSourceName,
        DataSourceType,
        DBName,
        VersionLevel,
        PatchLevel,
        FullVersionInfo,
        Description,
        Host,
        TestDescription,
        TestScore,
        ScoreDescription,
        ResultText,
        Recommendation,
        Severity,
        Category,
        ExecutionDate,
        ExecutionDateUTC,
        AssessmentDescription,
        ServiceName,
        Port,
        DataSourceID,
        ResultDetails,
        ''0'',
        '''||GLOBALID||'''
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "TestResultID","ConfigID","GlobalID" from "'||TNT_ID||'"."VULNERABILITY_ASSESSMENT" mt where mt."TestResultID" = Ext.TestResultID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_VA_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."ALT_INSERT_INSTANCE_v1"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(1000),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(32000), AverageExecutionTime DECIMAL(11))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- merge the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'', '''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."ALT_INSERT_INSTANCE_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_INSTANCE_v1"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(1000),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(32000), AverageExecutionTime DECIMAL(11))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- Insert the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'', '''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "InstanceID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."INSTANCE" mt where mt."InstanceID" = Ext.InstanceId AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_INSTANCE_v1" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."SEC_INSERT_INSTANCE_v2"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(1000),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(32000), AverageExecutionTime DECIMAL(11), Db2ClientInfo VARCHAR(32000), Db2IZDatabase VARCHAR(240), Db2ICurrentUser VARCHAR(240), Db2IZProgram VARCHAR(240), ProcessID VARCHAR(255), DBProtocol VARCHAR(20))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- Insert the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID", "Db2ClientInfo", "Db2IZDatabase", "Db2ICurrentUser", "Db2IZProgram", "ProcessID", "DBProtocol")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'',
                  ''' || GLOBALID || ''',
                  Db2ClientInfo,
                  Db2IZDatabase,
                  Db2ICurrentUser,
                  Db2IZProgram,
                  ProcessID,
                  DBProtocol FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "InstanceID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."INSTANCE" mt where mt."InstanceID" = Ext.InstanceId AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."SEC_INSERT_INSTANCE_v2" TO USER DB2INST1 WITH GRANT OPTION@

/* -- **************************************************************
-- Licensed Materials - Property of IBM
-- (C) Copyright IBM Corp. 2021. All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp.
-- ************************************************************** */

CREATE OR REPLACE PROCEDURE "${schema}"."INSERT_INSTANCE_v1"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(1000),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(32000), AverageExecutionTime DECIMAL(11))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- Insert the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'', '''||GLOBALID||''' FROM "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1@

GRANT EXECUTE ON PROCEDURE "${schema}"."INSERT_INSTANCE_v1" TO USER DB2INST1 WITH GRANT OPTION@


EOF
	db2 -td@ -f UpdatePL.sql >>$logFile 2>&1

}




function createV3Tables() {

	schema=$1
	tenant_short=$2

cat <<EOF > createV3Tables.sql
------------------------------------------------
-- DDL Statements for Table "${schema}"."SESSION"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SESSION"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'SESSION' , 
		  "ID" VARCHAR(100 OCTETS) , 
		  "SessionID" DECIMAL(20,0) NOT NULL , 
		  "DatabaseType" VARCHAR(30 OCTETS) , 
		  "ServerOS" VARCHAR(100 OCTETS) , 
		  "ClientOS" VARCHAR(100 OCTETS) , 
		  "ServerID" VARCHAR(50 OCTETS) , 
		  "ClientID" VARCHAR(50 OCTETS) , 
		  "NetworkProtocol" VARCHAR(20 OCTETS) , 
		  "DBProtocol" VARCHAR(20 OCTETS) , 
		  "DBProtocolVersion" VARCHAR(30 OCTETS) , 
		  "DBUserName" VARCHAR(255 OCTETS) , 
		  "OSUser" VARCHAR(255 OCTETS) , 
		  "SourceProgram" VARCHAR(255 OCTETS) , 
		  "ClientHostName" VARCHAR(255 OCTETS) , 
		  "ServerHostName" VARCHAR(255 OCTETS) , 
		  "ServiceName" VARCHAR(80 OCTETS) , 
		  "KeyValue" VARCHAR(32 OCTETS) , 
		  "DatabaseName" VARCHAR(255 OCTETS) , 
		  "ClientPort" VARCHAR(30 OCTETS) , 
		  "ServerPort" VARCHAR(10 OCTETS) , 
		  "SourceID" VARCHAR(50 OCTETS) , 
		  "UTCOffset" DOUBLE , 
		  "OldSessionID" DECIMAL(20,0) , 
		  "SessionStart" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "SessionStartUTC" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "SessionEnd" TIMESTAMP WITH DEFAULT NULL , 
		  "SessionEndUTC" TIMESTAMP WITH DEFAULT NULL , 
		  "TTL" DECIMAL(5,0) , 
		  "SessionInfo" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "InactiveFlag" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "SessionIgnored" DECIMAL(5,0) WITH DEFAULT 0 , 
		  "IgnoreSince" TIMESTAMP WITH DEFAULT NULL , 
		  "IgnoreSinceUTC" TIMESTAMP WITH DEFAULT NULL , 
		  "UIDChain" VARCHAR(500 OCTETS) WITH DEFAULT NULL , 
		  "UIDChainCompressed" VARCHAR(250 OCTETS) WITH DEFAULT NULL , 
		  "FailOverFlag" DECIMAL(11,0) WITH DEFAULT NULL , 
		  "FailoverTimestamp" TIMESTAMP WITH DEFAULT NULL , 
		  "FailoverTimestampUTC" TIMESTAMP WITH DEFAULT NULL , 
		  "Mills" DECIMAL(20,0) WITH DEFAULT -1 , 
		  "RequiredUIDChainFromParent" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "LoginSucceeded" DECIMAL(11,0) WITH DEFAULT 1 , 
		  "SenderIP" VARCHAR(50 OCTETS) , 
		  "SessionKey" DECIMAL(20,0) WITH DEFAULT 0 , 
		  "CharEncoding" VARCHAR(50 OCTETS) , 
		  "TapIdentifier" VARCHAR(255 OCTETS) , 
		  "AccessID" VARCHAR(40 OCTETS) , 
		  "ServerIP" VARCHAR(50 OCTETS) , 
		  "ServerType" VARCHAR(30 OCTETS) , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "ProcessID" VARCHAR(255 OCTETS) WITH DEFAULT NULL )   
		 DISTRIBUTE BY HASH("SessionID")   
		   IN "SESS_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."SESSION"

ALTER TABLE "${schema}"."GIV3_SESSION" 
	ADD PRIMARY KEY
		("SessionID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."INSTANCE"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_INSTANCE"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'INSTANCE' , 
		  "ID" VARCHAR(100 OCTETS) , 
		  "InstanceID" DECIMAL(20,0) NOT NULL , 
		  "SessionID" DECIMAL(20,0) NOT NULL , 
		  "UTCOffset" DOUBLE , 
		  "PeriodStart" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "PeriodStartUTC" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "PeriodEnd" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "PeriodEndUTC" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "ApplicationEventID" DECIMAL(20,0) WITH DEFAULT 0 , 
		  "AppUserName" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "ApplicationEventType" VARCHAR(30 OCTETS) , 
		  "ApplicationEventValueStr" VARCHAR(1000 OCTETS) WITH DEFAULT NULL , 
		  "ApplicationEventValueNum" DOUBLE WITH DEFAULT NULL , 
		  "ApplicationEventDate" TIMESTAMP WITH DEFAULT NULL , 
		  "ApplicationEventDateUTC" TIMESTAMP WITH DEFAULT NULL , 
		  "ConstructID" VARCHAR(40 OCTETS) , 
		  "OriginalSQL" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "ObjectsandVerbs" VARCHAR(1000 OCTETS) , 
		  "SuccessfulSqls" DECIMAL(20,0) , 
		  "FailedSqls" DECIMAL(20,0) WITH DEFAULT NULL , 
		  "DBUserName" VARCHAR(255 OCTETS) , 
		  "OSUser" VARCHAR(255 OCTETS) , 
		  "SourceProgram" VARCHAR(255 OCTETS) , 
		  "ServerIP" VARCHAR(50 OCTETS) , 
		  "ClientID" VARCHAR(50 OCTETS) , 
		  "ServiceName" VARCHAR(80 OCTETS) , 
		  "ClientHostName" VARCHAR(255 OCTETS) , 
		  "ServerType" VARCHAR(30 OCTETS) , 
		  "DatabaseName" VARCHAR(255 OCTETS) , 
		  "EventUserName" VARCHAR(240 OCTETS) , 
		  "ServerPort" VARCHAR(10 OCTETS) , 
		  "NetworkProtocol" VARCHAR(20 OCTETS) , 
		  "TotalRecordsAffected" DECIMAL(11,0) WITH DEFAULT -1 , 
		  "ServerHostName" VARCHAR(255 OCTETS) , 
		  "Timestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "TimestampUTC" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "AverageExecutionTime" DECIMAL(11,0) WITH DEFAULT 1 , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "TotalCount" DECIMAL(20,0) GENERATED ALWAYS AS (ISNULL("SuccessfulSqls", 0) + ISNULL("FailedSqls", 0)) , 
		  "Db2ClientInfo" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "Db2IZDatabase" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "Db2ICurrentUser" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "Db2IZProgram" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "ProcessID" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "DBProtocol" VARCHAR(20 OCTETS) WITH DEFAULT NULL )   
		 DISTRIBUTE BY HASH("SessionID")   
		   IN "INST_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."INSTANCE"

ALTER TABLE "${schema}"."GIV3_INSTANCE" 
	ADD PRIMARY KEY
		("InstanceID",
		 "SessionID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."FULL_SQL"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_FULL_SQL"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'FULL_SQL' , 
		  "ID" VARCHAR(100 OCTETS) , 
		  "FullSQLID" DECIMAL(20,0) NOT NULL , 
		  "SessionID" DECIMAL(20,0) NOT NULL , 
		  "Timestamp" TIMESTAMP , 
		  "TimestampUTC" TIMESTAMP , 
		  "UTCOffset" DOUBLE , 
		  "InstanceID" DECIMAL(20,0) WITH DEFAULT 0 , 
		  "AccessRuleDescription" VARCHAR(100 OCTETS) , 
		  "FullStatement" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "TotalRecordsAffected" DECIMAL(11,0) , 
		  "Succeeded" DECIMAL(11,0) WITH DEFAULT 1 , 
		  "Status" DECIMAL(11,0) WITH DEFAULT 2 , 
		  "ResponseTime" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "ACKResponseTime" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "SQLSequenceInRequest" DECIMAL(11,0) , 
		  "BindVariablesValues" VARCHAR(32000 OCTETS) WITH DEFAULT NULL )   
		 DISTRIBUTE BY HASH("SessionID")   
		   IN "FSQL_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."FULL_SQL"

ALTER TABLE "${schema}"."GIV3_FULL_SQL" 
	ADD PRIMARY KEY
		("FullSQLID",
		 "SessionID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."OVERFLOW_FIELDS"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_OVERFLOW_FIELDS"  (
		  "TableName" VARCHAR(25 OCTETS) NOT NULL WITH DEFAULT  , 
		  "ID" DECIMAL(20,0) NOT NULL , 
		  "ColumnName" VARCHAR(25 OCTETS) NOT NULL WITH DEFAULT  , 
		  "Value" CLOB(2147483647 OCTETS) LOGGED NOT COMPACT WITH DEFAULT NULL , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("ID")   
		   IN "OVFFM_${tenant_short}" INDEX IN "IRPT8_${tenant_short}" LONG IN "LG32_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."OVERFLOW_FIELDS"

ALTER TABLE "${schema}"."GIV3_OVERFLOW_FIELDS" 
	ADD PRIMARY KEY
		("TableName",
		 "ID",
		 "ColumnName",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."EXCEPTION"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_EXCEPTION"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'EXCEPTION' , 
		  "ID" VARCHAR(100 OCTETS) , 
		  "ExceptionTypeID" VARCHAR(64 OCTETS) , 
		  "ExceptionID" DECIMAL(20,0) NOT NULL , 
		  "UserName" VARCHAR(255 OCTETS) , 
		  "SourceAddress" VARCHAR(255 OCTETS) , 
		  "DestinationAddress" VARCHAR(255 OCTETS) , 
		  "DBProtocol" VARCHAR(20 OCTETS) WITH DEFAULT NULL , 
		  "AppUserName" VARCHAR(240 OCTETS) , 
		  "ExceptionDescription" VARCHAR(255 OCTETS) , 
		  "SQLStatement" VARCHAR(32000 OCTETS) , 
		  "ErrorCause" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "ErrorCode" VARCHAR(100 OCTETS) , 
		  "Timestamp" TIMESTAMP , 
		  "TimestampUTC" TIMESTAMP , 
		  "SessionID" DECIMAL(20,0) , 
		  "InformationLink" VARCHAR(255 OCTETS) , 
		  "UTCOffset" DOUBLE , 
		  "Count" DECIMAL(11,0) , 
		  "SourceID" VARCHAR(50 OCTETS) WITH DEFAULT NULL , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "Db2IZDatabase" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "Db2ICurrentUser" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "Db2IZProgram" VARCHAR(240 OCTETS) WITH DEFAULT NULL )   
		 DISTRIBUTE BY HASH("ExceptionID")   
		   IN "EXCEP_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."EXCEPTION"

ALTER TABLE "${schema}"."GIV3_EXCEPTION" 
	ADD PRIMARY KEY
		("ExceptionID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."POLICY_VIOLATION"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_POLICY_VIOLATION"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'POLICY_VIOLATION' , 
		  "ID" VARCHAR(100 OCTETS) , 
		  "ViolationID" DECIMAL(20,0) NOT NULL , 
		  "SessionID" DECIMAL(20,0) WITH DEFAULT NULL , 
		  "UTCOffset" DOUBLE , 
		  "OSUser" VARCHAR(255 OCTETS) , 
		  "DBUserName" VARCHAR(255 OCTETS) , 
		  "ClientID" VARCHAR(50 OCTETS) , 
		  "ClientHostName" VARCHAR(255 OCTETS) , 
		  "SourceProgram" VARCHAR(255 OCTETS) , 
		  "ServerIP" VARCHAR(50 OCTETS) , 
		  "ServerType" VARCHAR(30 OCTETS) , 
		  "ServiceName" VARCHAR(80 OCTETS) , 
		  "ConstructID" VARCHAR(40 OCTETS) , 
		  "ObjectsandVerbs" VARCHAR(1000 OCTETS) , 
		  "AppUserName" VARCHAR(240 OCTETS) WITH DEFAULT NULL , 
		  "AccessRuleID" DECIMAL(20,0) WITH DEFAULT 0 , 
		  "AccessRuleDescription" VARCHAR(100 OCTETS) WITH DEFAULT NULL , 
		  "Verdict" DECIMAL(11,0) WITH DEFAULT NULL , 
		  "FullSQL" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "SendMessage" DECIMAL(20,0) , 
		  "CurrentCounter" DECIMAL(20,0) , 
		  "KeyString" VARCHAR(1000 OCTETS) , 
		  "CategoryName" VARCHAR(60 OCTETS) WITH DEFAULT NULL , 
		  "ClassificationName" VARCHAR(60 OCTETS) WITH DEFAULT NULL , 
		  "Severity" DECIMAL(20,0) WITH DEFAULT 0 , 
		  "PolicyDescription" VARCHAR(100 OCTETS) WITH DEFAULT NULL , 
		  "Timestamp" TIMESTAMP , 
		  "TimestampUTC" TIMESTAMP , 
		  "ServerHostName" VARCHAR(255 OCTETS) , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "ProcessID" VARCHAR(255 OCTETS) WITH DEFAULT NULL )   
		 DISTRIBUTE BY HASH("ViolationID")   
		   IN "PVIO_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."POLICY_VIOLATION"

ALTER TABLE "${schema}"."GIV3_POLICY_VIOLATION" 
	ADD PRIMARY KEY
		("ViolationID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."SENTENCE"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SENTENCE"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'SENTENCE' , 
		  "UTCOffset" DOUBLE , 
		  "SentenceID" VARCHAR(40 OCTETS) NOT NULL , 
		  "ConstructID" VARCHAR(40 OCTETS) NOT NULL , 
		  "Verb" VARCHAR(40 OCTETS) , 
		  "Depth" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "ParentSentenceID" VARCHAR(40 OCTETS) , 
		  "Timestamp" TIMESTAMP , 
		  "TimestampUTC" TIMESTAMP , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("ConstructID")   
		   IN "SENT_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."SENTENCE"

ALTER TABLE "${schema}"."GIV3_SENTENCE" 
	ADD PRIMARY KEY
		("SentenceID",
		 "ConstructID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."OBJECT"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_OBJECT"  (
		  "MessageType" VARCHAR(25 OCTETS) , 
		  "UTCOffset" DOUBLE , 
		  "SentenceID" VARCHAR(40 OCTETS) NOT NULL , 
		  "ObjectID" VARCHAR(40 OCTETS) NOT NULL , 
		  "ObjectName" VARCHAR(255 OCTETS) , 
		  "ConstructID" VARCHAR(40 OCTETS) NOT NULL , 
		  "Timestamp" TIMESTAMP , 
		  "TimestampUTC" TIMESTAMP , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("ConstructID")   
		   IN "OBJ_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."OBJECT"

ALTER TABLE "${schema}"."GIV3_OBJECT" 
	ADD PRIMARY KEY
		("ObjectID",
		 "SentenceID",
		 "ConstructID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."VULNERABILITY_ASSESSMENT"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_VULNERABILITY_ASSESSMENT"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'VULNERABILITY_ASSESSMENT' , 
		  "UTCOffset" DOUBLE , 
		  "TestResultID" DECIMAL(20,0) NOT NULL , 
		  "DataSourceName" VARCHAR(255 OCTETS) , 
		  "DataSourceType" VARCHAR(50 OCTETS) , 
		  "DBName" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "VersionLevel" VARCHAR(255 OCTETS) , 
		  "PatchLevel" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "FullVersionInfo" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "Description" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "Host" VARCHAR(255 OCTETS) , 
		  "TestDescription" VARCHAR(150 OCTETS) , 
		  "TestScore" DECIMAL(11,0) WITH DEFAULT -1 , 
		  "ScoreDescription" VARCHAR(255 OCTETS) , 
		  "ResultText" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "Recommendation" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "Severity" VARCHAR(60 OCTETS) NOT NULL , 
		  "Category" VARCHAR(60 OCTETS) WITH DEFAULT NULL , 
		  "ExecutionDate" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "ExecutionDateUTC" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "AssessmentDescription" VARCHAR(150 OCTETS) , 
		  "ServiceName" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "Port" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "DataSourceID" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "ResultDetails" VARCHAR(32000 OCTETS) WITH DEFAULT NULL , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL , 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("TestResultID")   
		   IN "VULA_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."VULNERABILITY_ASSESSMENT"

ALTER TABLE "${schema}"."GIV3_VULNERABILITY_ASSESSMENT" 
	ADD PRIMARY KEY
		("TestResultID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."CLASSIFICATION"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_CLASSIFICATION"  (
		  "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'CLASSIFICATION' , 
		  "UTCOffset" DOUBLE , 
		  "DataSourceID" DECIMAL(20,0) NOT NULL DEFAULT, 
		  "DataSourceName" VARCHAR(255 OCTETS) , 
		  "DataSourceType" VARCHAR(50 OCTETS) , 
		  "DataSourceIP" VARCHAR(50 OCTETS) , 
		  "ServiceName" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "DBName" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "Port" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "ProcessDescription" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "Catalog" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "Schema" VARCHAR(255 OCTETS) NOT NULL DEFAULT, 
		  "TableName" VARCHAR(255 OCTETS) NOT NULL DEFAULT, 
		  "ColumnName" VARCHAR(255 OCTETS) NOT NULL DEFAULT, 
		  "RuleDescription" VARCHAR(255 OCTETS) NOT NULL DEFAULT, 
		  "ClassificationName" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "Category" VARCHAR(255 OCTETS) WITH DEFAULT NULL , 
		  "StartDateTime" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "StartDateTimeUTC" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "Comprehensive" VARCHAR(50 OCTETS) WITH DEFAULT NULL , 
		  "ConfigID" VARCHAR(50 OCTETS) NOT NULL DEFAULT, 
		  "GlobalID" VARCHAR(50 OCTETS) NOT NULL DEFAULT, 
		  "TenantID" VARCHAR(50 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "ResultDataRowID" DECIMAL(20,0) NOT NULL DEFAULT,
                  "Comments" VARCHAR(32000 OCTETS) WITH DEFAULT NULL )   
		 DISTRIBUTE BY HASH("ResultDataRowID")   
		   IN "CLASS_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."CLASSIFICATION"

ALTER TABLE "${schema}"."GIV3_CLASSIFICATION" 
	ADD PRIMARY KEY
		("ResultDataRowID",
		 "ConfigID",
		 "GlobalID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."AUDIT_LOG"
------------------------------------------------
 

CREATE TABLE "${schema}"."AUDIT_LOG"  (
		  "AuditID" DECIMAL(20,0) NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +99999999999999999999  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "UserUID" VARCHAR(50 OCTETS) , 
		  "ScheduleID" VARCHAR(50 OCTETS) , 
		  "TaskID" VARCHAR(50 OCTETS) , 
		  "ReportID" VARCHAR(50 OCTETS) , 
		  "ReportName" VARCHAR(255 OCTETS) , 
		  "EntryType" VARCHAR(50 OCTETS) , 
		  "EntryID" VARCHAR(50 OCTETS) , 
		  "EntryTitle" VARCHAR(255 OCTETS) , 
		  "TimestampUTC" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "FieldUpdated" VARCHAR(255 OCTETS) , 
		  "Comment" VARCHAR(1024 OCTETS) , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("AuditID")   
		   IN "AUDLG_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."AUDIT_LOG"

ALTER TABLE "${schema}"."AUDIT_LOG" 
	ADD PRIMARY KEY
		("AuditID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."USER_NOTIFICATION"
------------------------------------------------
 

CREATE TABLE "${schema}"."USER_NOTIFICATION"  (
		  "ID" VARCHAR(100 OCTETS) NOT NULL , 
		  "Status" VARCHAR(20 OCTETS) , 
		  "Integration" VARCHAR(30 OCTETS) , 
		  "Origin" VARCHAR(30 OCTETS) , 
		  "Destination" VARCHAR(50 OCTETS) , 
		  "Title" VARCHAR(255 OCTETS) , 
		  "Contents" VARCHAR(32000 OCTETS) , 
		  "CreationTimeUTC" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "DeliveryTimeUTC" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "RetryCount" DECIMAL(11,0) WITH DEFAULT 0 , 
		  "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("ID")   
		   IN "USRNT_${tenant_short}" INDEX IN "IRPT8_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."USER_NOTIFICATION"

ALTER TABLE "${schema}"."USER_NOTIFICATION" 
	ADD PRIMARY KEY
		("ID")
	ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_DESC"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_DESC"  (
		  "GROUP_ID" INTEGER NOT NULL GENERATED BY DEFAULT AS IDENTITY (  
		    START WITH +20000  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "NAME" VARCHAR(255 CODEUNITS32) NOT NULL , 
		  "DESCRIPTION" VARCHAR(900 CODEUNITS32) , 
		  "GROUP_TYPE_ID" INTEGER NOT NULL , 
		  "NESTED" SMALLINT NOT NULL WITH DEFAULT 0 , 
		  "HIDDEN" SMALLINT NOT NULL WITH DEFAULT 0 , 
		  "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP )   
		 DISTRIBUTE BY HASH("GROUP_ID")
                   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_DESC"

ALTER TABLE "${schema}"."GIV3_GROUP_DESC" 
	ADD PRIMARY KEY
		("GROUP_ID")
	NOT ENFORCED;


-- DDL Statements for Unique Constraints on Table "${schema}"."GROUP_DESC"


ALTER TABLE "${schema}"."GIV3_GROUP_DESC" 
	ADD CONSTRAINT "GROUP_DESC_NAME" UNIQUE
		("NAME")
	NOT ENFORCED;

------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_GDP_SYNC"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_GDP_SYNC"  (
		  "GROUP_SYNC_ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "GROUP_ID" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "GDP_GROUP_ID" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "CM_ID" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "LAST_UPDATED" TIMESTAMP , 
		  "INACTIVE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP )   
                 DISTRIBUTE BY HASH("GROUP_SYNC_ID")
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_GDP_SYNC"

ALTER TABLE "${schema}"."GIV3_GROUP_GDP_SYNC" 
	ADD PRIMARY KEY
		("GROUP_SYNC_ID")
	NOT ENFORCED;


-- DDL Statements for Unique Constraints on Table "${schema}"."GROUP_GDP_SYNC"


ALTER TABLE "${schema}"."GIV3_GROUP_GDP_SYNC" 
	ADD CONSTRAINT "GROUP_GDP_SYNC_UNIQUE" UNIQUE
		("GROUP_ID")
	NOT ENFORCED;

------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_MEMBER"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_MEMBER"  (
		  "MEMBER_ID" BIGINT NOT NULL GENERATED BY DEFAULT AS IDENTITY (  
		    START WITH +1000000  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "GROUP_ID" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "GROUP_MEMBER" VARCHAR(255 CODEUNITS32) NOT NULL WITH DEFAULT '' , 
		  "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP )  
                 DISTRIBUTE BY HASH("MEMBER_ID") 
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_MEMBER"

ALTER TABLE "${schema}"."GIV3_GROUP_MEMBER" 
	ADD PRIMARY KEY
		("MEMBER_ID")
	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_TUPLE_PARAMETERS"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_TUPLE_PARAMETERS"  (
		  "PARAMETER_ID" INTEGER NOT NULL GENERATED BY DEFAULT AS IDENTITY (  
		    START WITH +20000  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "PARAMETER_DESC" VARCHAR(255 OCTETS) NOT NULL , 
		  "GROUP_ID" INTEGER NOT NULL )   
                 DISTRIBUTE BY HASH("PARAMETER_ID")
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_TUPLE_PARAMETERS"

ALTER TABLE "${schema}"."GIV3_GROUP_TUPLE_PARAMETERS" 
	ADD PRIMARY KEY
		("PARAMETER_ID")
	NOT ENFORCED;


-- DDL Statements for Unique Constraints on Table "${schema}"."GROUP_TUPLE_PARAMETERS"


ALTER TABLE "${schema}"."GIV3_GROUP_TUPLE_PARAMETERS" 
	ADD CONSTRAINT "TUPLE_PARAM_UNIQUE" UNIQUE
		("GROUP_ID")
	NOT ENFORCED;

------------------------------------------------
-- DDL Statements for Table "${schema}"."NESTED_GROUP_MEMBER"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_NESTED_GROUP_MEMBER"  (
		  "MEMBER_ID" INTEGER NOT NULL GENERATED BY DEFAULT AS IDENTITY (  
		    START WITH +20000  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "GROUP_ID" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "GROUP_MEMBER" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP ) 
                 DISTRIBUTE BY HASH("MEMBER_ID")  
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."NESTED_GROUP_MEMBER"

ALTER TABLE "${schema}"."GIV3_NESTED_GROUP_MEMBER" 
	ADD PRIMARY KEY
		("MEMBER_ID")
	NOT ENFORCED;


-- DDL Statements for Unique Constraints on Table "${schema}"."NESTED_GROUP_MEMBER"


ALTER TABLE "${schema}"."GIV3_NESTED_GROUP_MEMBER" 
	ADD CONSTRAINT "NESTED_GROUP_MEMBER_UNIQUE" UNIQUE
		("GROUP_ID",
		 "GROUP_MEMBER")
	NOT ENFORCED;

------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_TUPLES"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_TUPLES"  (
		  "GROUP_TUPLE_ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "NAME" VARCHAR(255 OCTETS) NOT NULL , 
		  "LABEL" VARCHAR(255 OCTETS) NOT NULL )
                 DISTRIBUTE BY HASH("GROUP_TUPLE_ID")   
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_TUPLES"

ALTER TABLE "${schema}"."GIV3_GROUP_TUPLES" 
	ADD PRIMARY KEY
		("GROUP_TUPLE_ID")
	NOT ENFORCED;


ALTER TABLE "${schema}"."GIV3_GROUP_TUPLES" ALTER COLUMN "GROUP_TUPLE_ID" RESTART WITH 21;

------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_TYPE"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_TYPE"  (
		  "GROUP_TYPE_ID" INTEGER NOT NULL GENERATED BY DEFAULT AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "NAME" VARCHAR(255 OCTETS) NOT NULL , 
		  "ALLOW_REGEX" INTEGER NOT NULL WITH DEFAULT 0 )
                 DISTRIBUTE BY HASH("GROUP_TYPE_ID")   
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_TYPE"

ALTER TABLE "${schema}"."GIV3_GROUP_TYPE" 
	ADD PRIMARY KEY
		("GROUP_TYPE_ID")
	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."GROUP_TYPE_MAPPING"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GROUP_TYPE_MAPPING"  (
		  "MAPPING_ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +2147483647  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "GDP_GROUP_TYPE_ID" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "GI_GROUP_TYPE_ID" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "TUPLE_PARAMS" VARCHAR(255 OCTETS) )   
                 DISTRIBUTE BY HASH("MAPPING_ID")
		   IN "GRP4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."GROUP_TYPE_MAPPING"

ALTER TABLE "${schema}"."GIV3_GROUP_TYPE_MAPPING" 
	ADD PRIMARY KEY
		("MAPPING_ID")
	NOT ENFORCED;


ALTER TABLE "${schema}"."GIV3_GROUP_TYPE_MAPPING" ALTER COLUMN "MAPPING_ID" RESTART WITH 41;

------------------------------------------------
-- DDL Statements for Table "${schema}"."ADMINCONSOLE_PARAMETER"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ADMINCONSOLE_PARAMETER"  (
		  "UNIT_TYPE" INTEGER WITH DEFAULT NULL )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("UNIT_TYPE")
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."ALERT_BUDGET_V2"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ALERT_BUDGET_V2"  (
		  "PARTITION" VARCHAR(255 OCTETS) NOT NULL , 
		  "SOURCE_ID" VARCHAR(255 OCTETS) NOT NULL , 
		  "SCORER_NAME" VARCHAR(255 OCTETS) NOT NULL , 
		  "SCORE" DOUBLE , 
		  "PERIOD" TIMESTAMP NOT NULL )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("PERIOD")
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."ALERTS_SENT"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ALERTS_SENT"  (
		  "SOURCE_ID" VARCHAR(255 OCTETS) NOT NULL , 
		  "SCORER_NAME" VARCHAR(255 OCTETS) NOT NULL , 
		  "SCORE" DOUBLE NOT NULL , 
		  "BUDGET_SCORE" DOUBLE NOT NULL , 
		  "PERIOD" TIMESTAMP NOT NULL , 
		  "PARTITION" VARCHAR(255 OCTETS) NOT NULL )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("PERIOD")
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."ALERT_BUDGET_THRESHOLD"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ALERT_BUDGET_THRESHOLD"  (
		  "PERIOD" TIMESTAMP NOT NULL , 
		  "PARTITION" VARCHAR(255 OCTETS) NOT NULL , 
		  "SCORER_NAME" VARCHAR(255 OCTETS) NOT NULL , 
		  "THRESHOLD" DOUBLE )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("PERIOD")
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."ANALYSIS_MAINTENANCE"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ANALYSIS_MAINTENANCE"  (
		  "REASON" VARCHAR(100 OCTETS) , 
		  "GO" SMALLINT , 
		  "LAST_UPDATE" TIMESTAMP NOT NULL GENERATED ALWAYS FOR EACH ROW ON UPDATE AS ROW CHANGE TIMESTAMP , 
		  "CREATED_ON" TIMESTAMP NOT NULL )   
		 COMPRESS YES STATIC 
                 DISTRIBUTE BY HASH("GO",
                 "CREATED_ON") 
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."ANALYTIC_LOG"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ANALYTIC_LOG"  (
		  "ANALYTIC_LOG_ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "PROCESS_NAME" VARCHAR(50 OCTETS) NOT NULL , 
		  "STATUS" VARCHAR(3 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DETAIL" CLOB(16777215 OCTETS) LOGGED NOT COMPACT , 
		  "ADVANCED_DETAIL" CLOB(16777215 OCTETS) LOGGED NOT COMPACT , 
		  "TIMESTAMP" TIMESTAMP NOT NULL GENERATED ALWAYS FOR EACH ROW ON UPDATE AS ROW CHANGE TIMESTAMP , 
		  "START_TIME" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "END_TIME" TIMESTAMP , 
		  "PERIOD_FROM" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "PENDING_TIME" TIMESTAMP , 
		  "RECORDS_ANALYZED" INTEGER , 
		  "ALERTS" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "SERVER_TYPE" VARCHAR(30 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "NUM_USERS" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "NUM_DATABASES" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "NUM_TABLES" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "OUTPUT_COLLECTED" SMALLINT NOT NULL WITH DEFAULT 0 )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("ANALYTIC_LOG_ID")
		   IN "OUT8_${tenant_short}" INDEX IN "IGEN8_${tenant_short}" LONG IN "LG32_${tenant_short}"  
		 ORGANIZE BY ROW; 


-- DDL Statements for Primary Key on Table "${schema}"."ANALYTIC_LOG"

ALTER TABLE "${schema}"."GIV3_ANALYTIC_LOG" 
	ADD PRIMARY KEY
		("ANALYTIC_LOG_ID")
	NOT ENFORCED;



-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_LOG"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_LOG_I1" ON "${schema}"."GIV3_ANALYTIC_LOG" 
--		("PERIOD_FROM" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_LOG"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_LOG_I2" ON "${schema}"."GIV3_ANALYTIC_LOG" 
--		("STATUS" ASC,
--		 "ALERTS" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_LOG"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."DOMAIN_PROCESS" ON "${schema}"."GIV3_ANALYTIC_LOG" 
--		("SERVER_TYPE" ASC,
--		 "PROCESS_NAME" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;
------------------------------------------------
-- DDL Statements for Table "${schema}"."ANALYTIC_OUTLIER"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ANALYTIC_OUTLIER"  (
		  "ANALYTIC_OUTLIER_ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP , 
		  "PERIOD_START" TIMESTAMP NOT NULL , 
		  "SERVER_IP" VARCHAR(50 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DB_USER" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "SOURCE_PROGRAM" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DB_NAME" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "OBJECT_VERB_TUPLES" CLOB(16777215 OCTETS) LOGGED NOT COMPACT NOT NULL WITH DEFAULT '' , 
		  "OUTLIER_TYPE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "NUMBER_OF_INSTANCES" INTEGER , 
		  "ANOMALY_SCORE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "OBJECT_NAME" VARCHAR(255 OCTETS) WITH DEFAULT '' , 
		  "VERB" VARCHAR(40 OCTETS) WITH DEFAULT '' , 
		  "IS_VOLUME" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "IS_FAILURE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "IS_TEMP_OBJECT" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "IS_TEMP_SOURCE_PROGRAM" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "IS_NEW_MESSAGE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "IS_SENSITIVE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "IS_PRIVILEGED" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "RARITY" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "SOURCE_ID" VARCHAR(200 OCTETS) , 
		  "ORIG_HOSTNAME" VARCHAR(255 OCTETS) , 
		  "ALERT_FEEDBACK_ID" BIGINT NOT NULL , 
		  "EQ_INTERVALS" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "SERVER_TYPE" VARCHAR(30 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "MESSAGE_DB_USER" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "RECORDS_AFFECTED" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "EFFECTIVE_VOLUME" INTEGER NOT NULL WITH DEFAULT 0 )   
		 COMPRESS YES STATIC 
                 DISTRIBUTE BY HASH("ANALYTIC_OUTLIER_ID") 
		   IN "OUT8_${tenant_short}" INDEX IN "IGEN8_${tenant_short}" LONG IN "LG32_${tenant_short}"  
		 ORGANIZE BY ROW; 


-- DDL Statements for Primary Key on Table "${schema}"."ANALYTIC_OUTLIER"

ALTER TABLE "${schema}"."GIV3_ANALYTIC_OUTLIER" 
	ADD PRIMARY KEY
		("ANALYTIC_OUTLIER_ID")
	NOT ENFORCED;



-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_I1" ON "${schema}"."GIV3_ANALYTIC_OUTLIER" 
--		("SERVER_IP" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_I2" ON "${schema}"."GIV3_ANALYTIC_OUTLIER" 
--		("DB_USER" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_I3" ON "${schema}"."GIV3_ANALYTIC_OUTLIER" 
--		("SOURCE_PROGRAM" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_I4" ON "${schema}"."GIV3_ANALYTIC_OUTLIER" 
--		("PERIOD_START" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_I5" ON "${schema}"."GIV3_ANALYTIC_OUTLIER" 
--		("DB_NAME" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;
------------------------------------------------
-- DDL Statements for Table "${schema}"."ANALYTIC_OUTLIER_SUMMARY"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_ANALYTIC_OUTLIER_SUMMARY"  (
		  "ANALYTIC_OUTLIER_SUMMARY_ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP , 
		  "PERIOD_START" TIMESTAMP NOT NULL , 
		  "SERVER_IP" VARCHAR(50 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DB_USER" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DB_NAME" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "ANOMALY_SCORE" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "SOURCE_ID" VARCHAR(200 OCTETS) , 
		  "RARITY_AND_VOLUME_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_OBJECTS_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_OBJECTS_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_OBJECTS_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_SOURCE_PROGRAMS_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NUM_TEMP_SOURCE_PROGRAMS" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_SOURCE_PROGRAMS_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_SOURCE_PROGRAMS_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NEW_MESSAGES_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NEW_MESSAGES_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NEW_MESSAGES_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NUM_NEW_MESSAGES" INTEGER , 
		  "NUM_TEMP_OBJECTS" INTEGER , 
		  "NUM_SENSITIVE_OBJECTS" INTEGER , 
		  "NUM_FAILS" INTEGER , 
		  "TYPE_VOLUME_RARITY" INTEGER , 
		  "TYPE_TEMP_OBJECTS" INTEGER , 
		  "TYPE_TEMP_SOURCE_PROGRAMS" INTEGER , 
		  "TYPE_NEW_MESSAGES" INTEGER , 
		  "ORIG_HOSTNAME" VARCHAR(255 OCTETS) , 
		  "ALERT_FEEDBACK_ID" BIGINT NOT NULL , 
		  "IS_PRIVILEGED" INTEGER NOT NULL WITH DEFAULT 0 , 
		  "EQ_INTERVALS" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SCORE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TYPE_VOLUME" INTEGER , 
		  "VOLUME_SUM_LOGS" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SUM_LOGS_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SUM_LOGS_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SUM_LOGS_AVE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SUM_LOGS_SD_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "VOLUME_SUM_LOGS_MAX" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TEMP_OBJECTS_SCORE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NEW_MESSAGES_SCORE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NUM_NEW_MESSAGES_SW" INTEGER , 
		  "NEW_MESSAGES_SW_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NEW_MESSAGES_SW_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "DIFF_MESSAGES_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "DIFF_MESSAGES_SCORE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NUM_DIFF_MESSAGES" INTEGER , 
		  "NUM_DIFF_MESSAGES_SW" INTEGER , 
		  "DIFF_MESSAGES_SW_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "DIFF_MESSAGES_SW_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TYPE_DIFF_MESSAGES" INTEGER , 
		  "FAILS_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "FAILS_SCORE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "NUM_FAILS_SW" INTEGER , 
		  "FAILS_SW_AVE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "FAILS_SW_SD" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TYPE_FAILS" INTEGER , 
		  "TRAINING_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TRAINING_START" TIMESTAMP WITH DEFAULT NULL , 
		  "TYPE_TRAINING_OUTLIER" INTEGER WITH DEFAULT NULL , 
		  "NUM_FEEDBACK_EVENTS" INTEGER WITH DEFAULT NULL , 
		  "TYPE_RECENT_HOURS_ACTIVITY" INTEGER , 
		  "RECENT_HOURS_ACTIVITY_SCORE" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "RECENT_HOURS_ACTIVITY_SCORE_ORIG" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "RECENT_HOURS_RATIO_VOLUME" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "RECENT_HOURS_RATIO_TEMP_OBJECTS" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "RECENT_HOURS_RATIO_NEW_MESSAGES" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "RECENT_HOURS_RATIO_DIFF_MESSAGES" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "RECENT_HOURS_RATIO_FAILS" DOUBLE NOT NULL WITH DEFAULT 0 , 
		  "TYPE_FEEDBACK" INTEGER , 
		  "SERVER_TYPE" VARCHAR(30 OCTETS) NOT NULL WITH DEFAULT '' )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("ANALYTIC_OUTLIER_SUMMARY_ID")
		   IN "OUT32_${tenant_short}" INDEX IN "IGEN8_${tenant_short}"  
		 ORGANIZE BY ROW; 


-- DDL Statements for Primary Key on Table "${schema}"."ANALYTIC_OUTLIER_SUMMARY"

ALTER TABLE "${schema}"."GIV3_ANALYTIC_OUTLIER_SUMMARY" 
	ADD PRIMARY KEY
		("ANALYTIC_OUTLIER_SUMMARY_ID")
	NOT ENFORCED;



-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER_SUMMARY"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_SUMMARY_I1" ON "${schema}"."GIV3_ANALYTIC_OUTLIER_SUMMARY" 
--		("SERVER_IP" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER_SUMMARY"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_SUMMARY_I2" ON "${schema}"."GIV3_ANALYTIC_OUTLIER_SUMMARY" 
--		("DB_USER" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER_SUMMARY"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_SUMMARY_I3" ON "${schema}"."GIV3_ANALYTIC_OUTLIER_SUMMARY" 
--		("DB_NAME" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."ANALYTIC_OUTLIER_SUMMARY"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."ANALYTIC_OUTLIER_SUMMARY_I4" ON "${schema}"."GIV3_ANALYTIC_OUTLIER_SUMMARY" 
--		("PERIOD_START" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;
------------------------------------------------
-- DDL Statements for Table "${schema}"."GUARD_PARAMETERS"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_GUARD_PARAMETERS"  (
		  "NUM_VAL" INTEGER NOT NULL WITH DEFAULT 1 , 
		  "PARAMETER_NAME" VARCHAR(200 OCTETS) NOT NULL )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("NUM_VAL")
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."MESSAGE_SUMMARY"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_MESSAGE_SUMMARY"  (
		  "SOURCE_TYPE" SMALLINT NOT NULL WITH DEFAULT 0 , 
		  "SOURCE_SERVER_IP" VARCHAR(50 OCTETS) , 
		  "SOURCE_SERVICE_NAME" VARCHAR(80 OCTETS) , 
		  "SOURCE_DB_USER" VARCHAR(255 OCTETS) , 
		  "SOURCE_SERVER_TYPE" VARCHAR(30 OCTETS) , 
		  "SOURCE_OBJECT_NAME" VARCHAR(255 OCTETS) , 
		  "SOURCE_VERB" VARCHAR(255 OCTETS) , 
		  "SOURCE_PROGRAM" VARCHAR(255 OCTETS) , 
		  "OBJECT_NAME" VARCHAR(255 OCTETS) , 
		  "VERB" VARCHAR(255 OCTETS) , 
		  "WORKING_HOURS" SMALLINT , 
		  "DB_USER" VARCHAR(255 OCTETS) , 
		  "CLIENT_HOSTNAME" VARCHAR(255 OCTETS) , 
		  "CLIENT_IP" VARCHAR(50 OCTETS) , 
		  "OS_USER" VARCHAR(255 OCTETS) , 
		  "COUNT" BIGINT , 
		  "COUNT_FAILED" BIGINT , 
		  "COUNT_RECORDS_AFFECTED" BIGINT , 
		  "COUNT_TIME" BIGINT , 
		  "TEMPLATE_NAME" VARCHAR(255 OCTETS) , 
		  "PERIOD_FROM" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "SOURCE_DATABASE_ID" VARCHAR(247 OCTETS) )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("COUNT",
                 "COUNT_FAILED",
                 "COUNT_RECORDS_AFFECTED")
		   IN "OUT8_${tenant_short}" INDEX IN "IGEN8_${tenant_short}"  
		 ORGANIZE BY ROW; 






-- DDL Statements for Indexes on Table "${schema}"."MESSAGE_SUMMARY"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."SOURCE_KEY" ON "${schema}"."GIV3_MESSAGE_SUMMARY" 
--		("SOURCE_DATABASE_ID" ASC,
--		 "SOURCE_DB_USER" ASC,
--		 "SOURCE_OBJECT_NAME" ASC,
--		 "SOURCE_VERB" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;

-- DDL Statements for Indexes on Table "${schema}"."MESSAGE_SUMMARY"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."SOURCE_TYPE_PERIOD_FROM_KEY" ON "${schema}"."GIV3_MESSAGE_SUMMARY" 
--		("SOURCE_TYPE" ASC,
--		 "PERIOD_FROM" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;
------------------------------------------------
-- DDL Statements for Table "${schema}"."SCORES_LOG"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SCORES_LOG"  (
		  "PERIOD_FROM" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' , 
		  "VOLUME_SCORE" DOUBLE , 
		  "TEMP_OBJECTS_SCORE" DOUBLE , 
		  "NEW_MESSAGES_SCORE" DOUBLE , 
		  "DIFF_MESSAGES_SCORE" DOUBLE , 
		  "FAILS_SCORE" DOUBLE , 
		  "RECENT_HOURS_ACTIVITY_SCORE" DOUBLE , 
		  "VOLUME_SOURCE_INTERNAL_ID" INTEGER NOT NULL , 
		  "TEMP_OBJECTS_SOURCE_INTERNAL_ID" INTEGER NOT NULL , 
		  "NEW_MESSAGES_SOURCE_INTERNAL_ID" INTEGER NOT NULL , 
		  "DIFF_MESSAGES_SOURCE_INTERNAL_ID" INTEGER NOT NULL , 
		  "FAILS_SOURCE_INTERNAL_ID" INTEGER NOT NULL , 
		  "RECENT_HOURS_ACTIVITY_SOURCE_INTERNAL_ID" INTEGER NOT NULL )   
		 COMPRESS YES STATIC 
                 DISTRIBUTE BY HASH("VOLUME_SOURCE_INTERNAL_ID",
                 "TEMP_OBJECTS_SOURCE_INTERNAL_ID",
                 "NEW_MESSAGES_SOURCE_INTERNAL_ID") 
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 






-- DDL Statements for Indexes on Table "${schema}"."SCORES_LOG"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."SCORES_LOG_PERIOD_FROM" ON "${schema}"."GIV3_SCORES_LOG" 
--		("PERIOD_FROM" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;
------------------------------------------------
-- DDL Statements for Table "${schema}"."SOURCES_V2"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SOURCES_V2"  (
		  "SOURCE_ID" VARCHAR(255 OCTETS) NOT NULL , 
		  "MODEL_TYPE" VARCHAR(255 OCTETS) NOT NULL , 
		  "MODEL" VARCHAR(4096 OCTETS) NOT NULL , 
		  "CREATED_ON" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP , 
		  "LAST_UPDATED" TIMESTAMP NOT NULL GENERATED ALWAYS FOR EACH ROW ON UPDATE AS ROW CHANGE TIMESTAMP , 
		  "PARTITION" VARCHAR(255 OCTETS) NOT NULL )   
     		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("SOURCE_ID",
                 "MODEL_TYPE")
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 


-- DDL Statements for Primary Key on Table "${schema}"."SOURCES_V2"

ALTER TABLE "${schema}"."GIV3_SOURCES_V2" 
	ADD PRIMARY KEY
		("SOURCE_ID",
		 "MODEL_TYPE")
	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."SOURCE_MESSAGE_STATS"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SOURCE_MESSAGE_STATS"  (
		  "SOURCE_INTERNAL_ID" BIGINT NOT NULL WITH DEFAULT '0' , 
		  "MESSAGE_ID_HASH" BIGINT NOT NULL , 
		  "SOURCE_PROGRAM" VARCHAR(255 OCTETS) , 
		  "OBJECT_NAME" VARCHAR(255 OCTETS) , 
		  "VERB" VARCHAR(255 OCTETS) , 
		  "WORKING_HOURS" SMALLINT , 
		  "DB_USER" VARCHAR(255 OCTETS) , 
		  "CLIENT_HOSTNAME" VARCHAR(255 OCTETS) , 
		  "CLIENT_IP" VARCHAR(50 OCTETS) , 
		  "OS_USER" VARCHAR(255 OCTETS) , 
		  "FAILED" BOOLEAN , 
		  "TIMESTAMP" TIMESTAMP , 
		  "SA_WEIGHT" DOUBLE , 
		  "SA_LOG_VOLUME_MEAN" DOUBLE , 
		  "SA_LOG_VOLUME_MEAN2" DOUBLE , 
		  "MAX_LOG_VOLUME1" DOUBLE , 
		  "MAX_LOG_VOLUME2" DOUBLE , 
		  "MAX_LOG_VOLUME3" DOUBLE , 
		  "MAX_LOG_VOLUME4" DOUBLE , 
		  "MAX_LOG_VOLUME5" DOUBLE , 
		  "MAX_LOG_VOLUME6" DOUBLE , 
		  "MAX_LOG_VOLUME7" DOUBLE , 
		  "MAX_LOG_VOLUME8" DOUBLE , 
		  "MAX_LOG_VOLUME9" DOUBLE , 
		  "MAX_LOG_VOLUME10" DOUBLE , 
		  "MAX_LOG_VOLUME11" DOUBLE , 
		  "MAX_LOG_VOLUME12" DOUBLE , 
		  "PROFILE_BERNOULLI" DOUBLE , 
		  "PROFILE_LOG_VOLUME_MEAN" DOUBLE , 
		  "PROFILE_LOG_VOLUME_MEAN2" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME1" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME2" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME3" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME4" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME5" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME6" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME7" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME8" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME9" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME10" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME11" DOUBLE , 
		  "PROFILE_MAX_LOG_VOLUME12" DOUBLE )   
		 COMPRESS YES STATIC  
                 DISTRIBUTE BY HASH("SOURCE_INTERNAL_ID",
                 "MESSAGE_ID_HASH")
		   IN "OUT32_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 


-- DDL Statements for Primary Key on Table "${schema}"."SOURCE_MESSAGE_STATS"

ALTER TABLE "${schema}"."GIV3_SOURCE_MESSAGE_STATS" 
	ADD PRIMARY KEY
		("SOURCE_INTERNAL_ID",
		 "MESSAGE_ID_HASH")
	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."SYSTEM_PARAMS"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SYSTEM_PARAMS"  (
		  "DELIVERY_DATE" TIMESTAMP , 
		  "DELIVERY_VERSION" VARCHAR(50 OCTETS) NOT NULL , 
		  "GIT_REVISION" VARCHAR(50 OCTETS) NOT NULL , 
		  "GIT_DATE" TIMESTAMP , 
		  "TRAINING_START" TIMESTAMP , 
		  "TRAINING_DAYS" BIGINT NOT NULL )   
		 COMPRESS YES STATIC 
                 DISTRIBUTE BY HASH("TRAINING_DAYS",
                 "DELIVERY_DATE",
                 "GIT_DATE") 
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 





------------------------------------------------
-- DDL Statements for Table "${schema}"."TEMP_MESSAGE_STATS"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_TEMP_MESSAGE_STATS"  (
		  "SOURCE_INTERNAL_ID" BIGINT , 
		  "SERVER_IP" VARCHAR(50 OCTETS) , 
		  "SERVICE_NAME" VARCHAR(80 OCTETS) , 
		  "MESSAGE_ID_HASH" BIGINT , 
		  "SA_WEIGHT" DOUBLE , 
		  "SA_LOG_VOLUME_MEAN" DOUBLE , 
		  "SA_LOG_VOLUME_MEAN2" DOUBLE )   
		 COMPRESS YES STATIC 
                 DISTRIBUTE BY HASH("SOURCE_INTERNAL_ID",
                 "MESSAGE_ID_HASH") 
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 






-- DDL Statements for Indexes on Table "${schema}"."TEMP_MESSAGE_STATS"

SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM';

--CREATE INDEX "${schema}"."SERVER_IP" ON "${schema}"."GIV3_TEMP_MESSAGE_STATS" 
--		("SERVER_IP" ASC,
--		 "SERVICE_NAME" ASC,
--		 "MESSAGE_ID_HASH" ASC)
		
--		COMPRESS NO 
--		INCLUDE NULL KEYS ALLOW REVERSE SCANS;
------------------------------------------------
-- DDL Statements for Table "${schema}"."USER_FEEDBACK"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_USER_FEEDBACK"  (
		  "FEEDBACK_ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (  
		    START WITH +1  
		    INCREMENT BY +1  
		    MINVALUE +1  
		    MAXVALUE +9223372036854775807  
		    NO CYCLE  
		    CACHE 20  
		    NO ORDER ) , 
		  "DB_USER" VARCHAR(255 OCTETS) , 
		  "AGG_SERVER_IP" VARCHAR(50 OCTETS) , 
		  "SERVICE_NAME" VARCHAR(80 OCTETS) , 
		  "OBJECT_NAME" VARCHAR(255 OCTETS) , 
		  "VERB" VARCHAR(200 OCTETS) , 
		  "SOURCE_PROGRAM" VARCHAR(255 OCTETS) , 
		  "USER_FEEDBACK" VARCHAR(200 OCTETS) )   
		 COMPRESS YES STATIC
                 DISTRIBUTE BY HASH("FEEDBACK_ID")  
		   IN "OUT4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY ROW; 


-- DDL Statements for Primary Key on Table "${schema}"."USER_FEEDBACK"

ALTER TABLE "${schema}"."GIV3_USER_FEEDBACK" 
	ADD PRIMARY KEY
		("FEEDBACK_ID")
	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."DB_ERROR_TEXT"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_DB_ERROR_TEXT"  (
		  "DB_ERROR_ID" INTEGER NOT NULL , 
		  "DB_PROTOCOL" VARCHAR(20 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DB_PROTOCOL_VERSION" VARCHAR(30 OCTETS) WITH DEFAULT '*' , 
		  "ERROR_CODE" VARCHAR(150 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "ERROR_TEXT" CLOB(1048576 OCTETS) LOGGED NOT COMPACT NOT NULL , 
		  "LANGUAGE" VARCHAR(20 OCTETS) WITH DEFAULT NULL,
		  PRIMARY KEY ("DB_ERROR_ID") ) 
                 DISTRIBUTE BY HASH("DB_ERROR_ID")  
		   IN "GEN4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 



-- DDL Statements for Primary Key on Table "${schema}"."DB_ERROR_TEXT"

--ALTER TABLE "${schema}"."GIV3_DB_ERROR_TEXT" 
--	ADD PRIMARY KEY
--		("DB_ERROR_ID")
--	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."EXCEPTION_TYPE"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_EXCEPTION_TYPE"  (
		  "EXCEPTION_TYPE_ID" VARCHAR(64 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "DESCRIPTION" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' , 
		  "ENABLED" SMALLINT NOT NULL , 
		  "SQL_RELATED" INTEGER NOT NULL WITH DEFAULT '0' )
                 DISTRIBUTE BY HASH("EXCEPTION_TYPE_ID")   
		   IN "GEN4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."EXCEPTION_TYPE"

ALTER TABLE "${schema}"."GIV3_EXCEPTION_TYPE" 
	ADD PRIMARY KEY
		("EXCEPTION_TYPE_ID")
	NOT ENFORCED;


------------------------------------------------
-- DDL Statements for Table "${schema}"."SEVERITY_DESC"
------------------------------------------------
 

CREATE TABLE "${schema}"."GIV3_SEVERITY_DESC"  (
		  "SEVERITY" INTEGER NOT NULL WITH DEFAULT '0' , 
		  "DESCRIPTION" VARCHAR(20 OCTETS) WITH DEFAULT NULL ) 
                 DISTRIBUTE BY HASH("SEVERITY")  
		   IN "GEN4_${tenant_short}" INDEX IN "IGEN4_${tenant_short}"  
		 ORGANIZE BY COLUMN; 


-- DDL Statements for Primary Key on Table "${schema}"."SEVERITY_DESC"

ALTER TABLE "${schema}"."GIV3_SEVERITY_DESC" 
	ADD PRIMARY KEY
		("SEVERITY")
	NOT ENFORCED;
EOF
	db2 -tvf createV3Tables.sql  >>$logFile 2>&1

}

function alterTables() {

        schema=$1

	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"DataSourceID\" DROP DEFAULT" >>$logFile 2>&1
        db2 -v "alter table ${schema}.CLASSIFICATION alter column \"Schema\" DROP DEFAULT" >>$logFile 2>&1
 	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"TableName\" DROP DEFAULT" >>$logFile 2>&1
	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"ColumnName\" DROP DEFAULT" >>$logFile 2>&1
	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"RuleDescription\" DROP DEFAULT" >>$logFile 2>&1
	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"ConfigID\" DROP DEFAULT" >>$logFile 2>&1
	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"GlobalID\" DROP DEFAULT" >>$logFile 2>&1
	db2 -v "alter table ${schema}.CLASSIFICATION alter column \"ResultDataRowID\" DROP DEFAULT" >>$logFile 2>&1

}

function createDirectories() {

	schema=$1
        tenant_directory=/mnt/blumeta0/scratch/insights-datamart/${schema}
	
	sudo mkdir $tenant_directory  >>$logFile 2>&1
        if [ $? -eq 0 ]; then 
		echo "Created tenant directory: ${tenant_directory}"  >>$logFile
        fi
        if [ -d ${tenant_directory} ]; then
		sudo chmod 777 ${tenant_directory}  >>$logFile 2>&1
        	if [ $? -eq 0 ]; then 
                	echo "Permission 777 set for tenant_directory"  >>$logFile
        	fi
        else
		echo "[ERROR] Failed to create tenant directory: ${tenant_directory}"  >>$logFile
	fi


}

#----------------------------------------------------------------------------------------


db2="${HOME}/sqllib/bin/db2"

logFile="${HOME}/GIv3_DB_Upgrade.log"

db2 connect to BLUDB 
if [ $? -ne 0 ]; then 
	echo "[ERROR] Failed to connmect to BLUDB database, exiting"
	exit 1
fi

echo "Upgrading DB schemas to GI version 3.0, this might take a few minutes to complete..."

echo "Run Date:  $(date +"%Y-%m-%d %T") " >$logFile

echo "Creating bufferpools"

echo "#-----------------------------------------------------"  >>$logFile
echo "# --------------Create bufferpools   ------------------"  >>$logFile
echo "#------------------------------------------------------" >>$logFile

db2 -v "CREATE BUFFERPOOL BP_4 SIZE 20000 AUTOMATIC PAGESIZE 4K"  >>$logFile 2>&1
db2 -v "CREATE BUFFERPOOL BP_8 SIZE 5000 AUTOMATIC PAGESIZE 8K"  >>$logFile 2>&1
db2 -v "CREATE BUFFERPOOL BP_32 SIZE 5000 AUTOMATIC PAGESIZE 32K"  >>$logFile 2>&1
db2 -v "CREATE BUFFERPOOL BP_LG_32 SIZE 1000 AUTOMATIC PAGESIZE 32K"  >>$logFile 2>&1


schemas=`db2 -x "select schemaname from syscat.schemata where schemaname like 'TNT_%'"`

for schema in ${schemas}; do

        tenant_short=${schema:4:11}

        echo "Updating Schema: $schema"

        echo "#-----------------------------------------------------"  >>$logFile
        echo "# ---------- Updating Schema: ${schema} --------------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile


        echo "#-----------------------------------------------------"  >>$logFile
        echo "# --------------Create Tablespaces  ------------------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile

        echo "* Creating tablespaces"
        createTablespaces $tenant_short

        echo "#-----------------------------------------------------"  >>$logFile
        echo "# --------------Create GI V3 Tables ------------------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile


        echo "* Updating GI tables" 
        createV3Tables $schema $tenant_short

        echo "#-----------------------------------------------------"  >>$logFile
        echo "# -------------- Update Tables to GI v3 ------------------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile

        echo "* Migrating tables"
        updateTables $schema $tenant_short

        echo "#-----------------------------------------------------"  >>$logFile
        echo "# -------------- Update Views  ------------------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile

        echo "* Updating views"
        updateViews $schema

        echo "#-----------------------------------------------------"  >>$logFile
        echo "# -------------- Update Predefined Data   ---------------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile

        echo "* Updating predefined data"
        updatePredefinedData $schema

        echo "#-----------------------------------------------------"  >>$logFile
        echo "# -------------- Update Store Procedures   ----------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile
	echo "* Updating stored procedures"
        updateStoreProcedures $schema

        alterTables $schema

	echo "#-----------------------------------------------------"  >>$logFile
        echo "# -------------- Creating Directories   ----------"  >>$logFile
        echo "#------------------------------------------------------" >>$logFile
        echo "* Creating tenant directory"
        createDirectories $schema

        #cleanup
	rm -f PredefinedData.sql
	rm -f createV3Tables.sql
	rm -f createTableSpaces.sql
	rm -f updateViews.sql
	rm -f updateTables.sql
	rm -f UpdatePL.sql


done


echo "Log File in: ${logFile}"

