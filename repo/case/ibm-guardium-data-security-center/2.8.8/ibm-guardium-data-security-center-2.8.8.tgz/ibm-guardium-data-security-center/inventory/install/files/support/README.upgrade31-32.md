# Db2 database schema upgrade for 3.2

`upgradeSchemaGIv31_v32.sh` is the script that upgrades the Db2 BLUDB database 
from GI v3.1 schema to GI version v3.2. This script takes no arguments and is 
generally safe to run multiple times in case of any runtime errors.

It returns exit code 0 if it completes successfully, otherwise it will return
a non-zero exit code.

Included changes:

- Updated group builder data.
- Enforced PKs and unique indexes on group builder tables. (**TODO**)
- Many data mart v3 stored procedures and all v4 SPs.
- New data mart status reporting tables and their dedicated tablespace. (**TODO** -- table definitions likely to change)
- Outlier (**TODO** development is still ongoing so tables are not final):
    - Modified tables: ANALYTIC_LOG, ANALYTIC_OUTLIER, ANALYTIC_OUTLIER_SUMMARY, MESSAGE_SUMMARY, SOURCE_MESSAGE_STATS, SYSTEM_PARAMS, USER_FEEDBACK,  
    - New tables: AGG_ANALYTIC_INPUT, ALERT_BUDGET, ANALYTIC_END_OF_HOUR, CLUSTERS, SOURCES
- Risk
- Reporting metadata
   - New table (REPORT_RESULT_SUMMARY) and indexes.
   - Modified tablespace definition.
   - Load old data from file system. (**TODO**)
   

## Development

The schema upgrade script reuses many of the pipeline configuration scripts.
If any of the affected files under `schema-upgrade-files-3.2/` are modified
in their repository (`pipeline-config`), run `schema-upgrade-files-3.2/fetch_files.sh`
to copy all files here. `master` is the default fetched pipeline-config branch.
The script takes an optional first command line parameter for the branch to
fetch. This is useful if you must prepare a release branch. In this case run
`schema-upgrade-files-3.2/fetch_files.sh <branch>`

Prior to the Insights release rerun `schema-upgrade-files-3.2/fetch_files.sh`,
with desired branch, and commit all resulting changes to ensure the latest
versions of all required DDL scripts are included.

## Upgrade

Simply execute `./upgradeSchemaGIv31_v32.sh`; redirect output to a log file
if desired.