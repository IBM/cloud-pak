#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2022. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeSchemaGIv31_v32.sh
#
# DESCRIPTION:   DB2 Synchronization script for Guardium Insights v3.1 to v3.2
#
# USAGE:         This script takes no arguments and  updates the BLUDB DB2
#                database from GI v3.1 schema to GI version v3.2. It should be
#                run only once on a database that is configured with GI v3.1.x
#
# PREREQUISITES: This script should be run on a BLUDB database at GI v3.1 level.
#
#----------------------------------------------------------------------------

# defaults
DBNAME=bludb
TMP_TBSP_SUFFIX="V32"
SQL_DIR="$(cd "$(dirname "$0")"; pwd;)/schema-upgrade-files-3.2"
LOCKFILE=/tmp/$(basename "$0").lock
db2="${HOME}/sqllib/bin/db2"

function log() {
  echo "[$1] $2"
}

function info() {
  log "INFO" "$1"
}

function err() {
  log "ERROR" "$1"
}

function debug() {
  [[ -n "$DEBUG" ]] && log "DEBUG" "$1"
}

# Create schema not present in 3.1
function createNewReportResultSchema() {
  local TNT_SCHEMA="$1"
  local RC
  RR_SCHEMA=${TNT_SCHEMA}_REPORT_RESULT
  createIfNotExists "CREATE SCHEMA ${RR_SCHEMA}" && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Error while creating new schema for tenant ${TNT_SCHEMA}_REPORT_RESULT"
    return $RC
  fi
}

# Create tablespaces not present in 3.1
# $1 - Tenant short ID
function createNewTablespaces() {
  local TNT_SHORT=$1
  local RC
  createIfNotExists "CREATE TABLESPACE DMSTAT_${TNT_SHORT} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4"  && \
  createIfNotExists "CREATE TABLESPACE REPRS_${TNT_SHORT} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32 MAXSIZE 512G"  && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Error while creating new tablespaces for tenant ${TNT_SHORT_ID}"
    return $RC
  fi
}

# Update tablespaces
# Currently update the CUSTOM tablespace
function updateTablespaces() {
  local TNT_SHORT=$1
  local RC
  STMT="ALTER TABLESPACE CUSTOM_${TNT_SHORT} MAXSIZE 16 G"
  info "Executing [${STMT}]"
  OUT=$(db2 +c "${STMT}")
  RC=$?
  if [[ $RC -ne 0 ]]; then
    err "error altering tablespace CUSTOM_${TNT_SHORT} RC: ${RC}, OUT: ${OUT}"
    return $RC
  fi
  info "Alter tablespace is successful"
}

# Execute the provided statement and ignore errors where the object already exists.
# Autocommit is off
# $1 -- statement to run (assume a connection already exists)
function createIfNotExists() {
  [[ -z "$1" ]] && return
  local RC
  local OUT
  local STMT="$1"
  info "Executing [${STMT}]"
  OUT=$(db2 +c "${STMT}")
  RC=$?
  [[ $RC -lt 2 ]] && return # OK
  [[ "$OUT" =~ SQL0601N ]] && info "Object already exists" && return # OK (The name of the object to be created is identical...)
  [[ "$OUT" =~ SQL0612N ]] && info "Object is a duplicate name" && return # OK (The name of the object to be created is identical...)
  [[ "$OUT" =~ SQL0624N ]] && info "Constraint already exists" && return # OK (already has a primary key or unique constraint...)
  [[ "$OUT" =~ SQL0605W ]] && info "Index already exists" && return # OK (index with a matching definition already exists.)
  return $RC # error
}

# Execute the provided statement and ignore errors where the object does not exist.
# Autocommit is off
# $1 -- statement to run (assume a connection already exists)
function dropIfExists() {
  [[ -z "$1" ]] && return
  local RC
  local OUT
  local STMT="$1"
  info "Executing [${STMT}]"
  OUT=$(db2 +c "${STMT}")
  RC=$?
  [[ $RC -lt 2 ]] && return # OK
  [[ "$OUT" =~ SQL2211N ]] && info "Object does not exist" && return # OK
  [[ "$OUT" =~ SQL0204N ]] && info "Object does not exist" && return # OK (no object with such name)
  [[ "$OUT" =~ SQL0539N ]] && info "Object does not exist" && return # OK (table has no primary key)
  return $RC # error
}

# Data mart status reporting tables that are new in 3.2
# $1 - Tenant schema name
# $2 - Tenant short ID
function createDMStatusTables() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  # run scripts manually created for tables defined in types/streaming/v3.2.0/normalizedMessages.go
  # along with indexes defined in pipeline-config
  for F in $(find ${SQL_DIR}/types/ingestion -type f -name "*\.sql"); do
    runScript ${TNT_SCHEMA} ${TNT_SHORT} "${F}"
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate ingestion upgrade due to error"
      return $RC
    fi
  done
  info "Creating DM status tables successful"
}

# Report status table and indexes -- new in 3.2
# $1 - Tenant schema name
# $2 - Tenant short ID
function createRptStatusTable() {
  local TNT_RR_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  info "Creating report status tables"
    for F in $(find ${SQL_DIR}/types/report -type f -name "*\.sql"); do
    runScript ${TNT_SCHEMA} ${TNT_SHORT} "${F}"
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate ingestion upgrade due to error"
      return $RC
    fi
  done
  info "Creating report status tables successful"
}

# Risk tables and indexes -- new in 3.2
# $1 - Tenant schema name
# $2 - Tenant short ID
function createRiskTables() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  info "Creating risk tables TNT_SCHEMA: ${TNT_SCHEMA}, TNT_SHORT: ${TNT_SHORT}"
  # run select scripts copied from pipeline-config/internal/config/predefined/v3.2.0/application/outlier
  # also note that outlier tables defined in types/streaming/v3.2.0/normalizedMessages.go have been
  # manually added to this directory in this repo.
  for F in $(find ${SQL_DIR}/types/risk -type f -name "*\.sql"); do
    runScript ${TNT_SCHEMA} ${TNT_SHORT} "${F}"
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate risk upgrade due to error"
      return $RC
    fi
  done
  info "Creating risk tables successful"
}

# Outlier tables
# $1 - Tenant schema name
# $2 - Tenant short ID
function upgradeCreateOutlierTables() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  # drop tables that currently exist and are to be replaced
  dropIfExists "drop table ${TNT_SCHEMA}.ANALYTIC_LOG" && \
  dropIfExists "drop table ${TNT_SCHEMA}.ANALYTIC_OUTLIER" && \
  dropIfExists "drop table ${TNT_SCHEMA}.ANALYTIC_OUTLIER_SUMMARY" && \
  dropIfExists "drop table ${TNT_SCHEMA}.MESSAGE_SUMMARY" && \
  dropIfExists "drop table ${TNT_SCHEMA}.SOURCE_MESSAGE_STATS" && \
  dropIfExists "drop table ${TNT_SCHEMA}.SOURCES_V2" && \
  dropIfExists "drop table ${TNT_SCHEMA}.SYSTEM_PARAMS" && \
  dropIfExists "drop table ${TNT_SCHEMA}.USER_FEEDBACK" && \
  db2 commit
  # run select scripts copied from pipeline-config/internal/config/predefined/v3.2.0/application/outlier
  # also note that outlier tables defined in types/streaming/v3.2.0/normalizedMessages.go have been
  # manually added to this directory in this repo.
  for F in $(find ${SQL_DIR}/internal/config/predefined/v3.2.0/application/outlier -type f -name "*\.sql"); do
    runScript ${TNT_SCHEMA} ${TNT_SHORT} "${F}"
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate outlier upgrade due to error"
      return $RC
    fi
  done
  # run scripts manually created for tables defined in types/streaming/v3.2.0/normalizedMessages.go
  # along with indexes defined in pipeline-config
  for F in $(find ${SQL_DIR}/types/outlier -type f -name "*\.sql"); do
    runScript ${TNT_SCHEMA} ${TNT_SHORT} "${F}"
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate outlier upgrade due to error"
      return $RC
    fi
  done
  info "Updated outlier tables successfully"
}

# VA table updates
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateVATable() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  createIfNotExists "alter table ${TNT_SCHEMA}.VULNERABILITY_ASSESSMENT add column \"ServerIP\" VARCHAR(50)" && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Failed to update VULNERABILITY_ASSESSMENT"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.VULNERABILITY_ASSESSMENT successful"
}

#  Run DDL from script. Assumes it has CREATE OR REPLACE
# $1 - Tenant schema name
# $2 - Script file name
function runScript() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT_ID="$2"
  local TGT_SCRIPT="$3"
  local RC
  info "Creating script from ${TGT_SCRIPT} for schema ${TNT_SCHEMA} short ${TNT_SHORT_ID}"
  if ! [[ -f $TGT_SCRIPT ]]; then
    err "Cannot find  script $TGT_SCRIPT"
    return 1
  fi
  TMP_FILE=$(basename ${TGT_SCRIPT} .sql).tmp.sql
  info "TMP_FILE: ${TMP_FILE}"
  # substitute schema
  # note files have been cleaned via fetch_files.sh
  sed 's/MY_TENANT_SCHEMA/'${TNT_SCHEMA}'/g;s/<TENANT_SHORT_ID>/'${TNT_SHORT_ID}'/g' $TGT_SCRIPT > ${TMP_FILE}
  db2 +p +c -t -f ${TMP_FILE} && \
  db2 commit
  info "rm TMP_FILE: ${TMP_FILE}"
  rm ${TMP_FILE}
  RC=$?
  if [[ $RC -ne 0 ]]; then
    db2 rollback
    err "Failed to create ${TGT_SCRIPT}"
    return $RC
  fi
  info "Executed ${TGT_SCRIPT} successfully"
}

# Move table GROUP_MEMBER
# It is required to accommodate the new unique constraint index
# # $1 - Tenant schema name
functionMoveGroupMemberTbl() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  local TNAME='GROUP_MEMBER'
  local DATA_TS=GRP4_${TNT_SHORT}
  local IDX_TS=IGEN8_${TNT_SHORT}
  local LOB_TS=GRP4_${TNT_SHORT}
  db2 -v "call sysproc.admin_move_table('${TNT_SCHEMA}', '${TNAME}', '$DATA_TS', '$IDX_TS', '$LOB_TS', '', '', '', '',  'ALLOW_READ_ACCESS','MOVE')" && \
  db2 -v "select 1 from systools.admin_move_table where tabschema = '${TNT_SCHEMA}' and tabname = '$TNAME' and key = 'STATUS' and value = 'COMPLETE'"
  RC=$?
  if [[ $RC -ne 0 ]]; then
    err "Failed to move table '$TSCHEMA'.'$TNAME'"
    return $RC
  fi
}

# Group builder constraints are made enforced in 3.2
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateGroupBuilderConstraints() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  info "Updating group builder constraints"
  # first move the GROUP_MEMBER table
  functionMoveGroupMemberTbl $TNT_SCHEMA $TNT_SHORT
  RC=$?
  if [[ $RC -ne 0 ]]; then
    err "Failed to move group builder tables"
    return $RC
  fi

  # now redefine constraints
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_TUPLES drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_TUPLES add primary key (\"GROUP_TUPLE_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_TYPE drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_TYPE add primary key (\"GROUP_TYPE_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_TYPE_MAPPING drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_TYPE_MAPPING add primary key (\"MAPPING_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_DESC drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_DESC add primary key (\"GROUP_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_DESC drop CONSTRAINT GROUP_DESC_NAME" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_DESC add CONSTRAINT GROUP_DESC_NAME unique (\"NAME\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_GDP_SYNC drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_GDP_SYNC add primary key (\"GROUP_SYNC_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_GDP_SYNC drop CONSTRAINT GROUP_GDP_SYNC_UNIQUE" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_GDP_SYNC add CONSTRAINT GROUP_GDP_SYNC_UNIQUE unique (\"GROUP_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_MEMBER drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_MEMBER add primary key (\"MEMBER_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_MEMBER drop CONSTRAINT GROUP_MEMBER_UNIQUE" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_MEMBER add CONSTRAINT GROUP_MEMBER_UNIQUE unique (\"GROUP_ID\", \"GROUP_MEMBER\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_TUPLE_PARAMETERS drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_TUPLE_PARAMETERS add primary key (\"PARAMETER_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_TUPLE_PARAMETERS drop CONSTRAINT TUPLE_PARAM_UNIQUE" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_TUPLE_PARAMETERS add CONSTRAINT TUPLE_PARAM_UNIQUE unique (\"GROUP_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.NESTED_GROUP_MEMBER drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.NESTED_GROUP_MEMBER add primary key (\"MEMBER_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.NESTED_GROUP_MEMBER drop CONSTRAINT NESTED_GROUP_MEMBER_UNIQUE" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.NESTED_GROUP_MEMBER add CONSTRAINT NESTED_GROUP_MEMBER_UNIQUE unique (\"GROUP_ID\", \"GROUP_MEMBER\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.GROUP_MEMBER_PREDEFINED drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.GROUP_MEMBER_PREDEFINED add primary key (\"MEMBER_ID\") ENFORCED" && \
  dropIfExists "alter table ${TNT_SCHEMA}.NESTED_GROUP_MEMBER_PREDEFINED drop primary key" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.NESTED_GROUP_MEMBER_PREDEFINED add primary key (\"MEMBER_ID\") ENFORCED" && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Failed to modify group builder constraints"
    return $RC
  fi
  db2 commit
  info "Modification of group builder constraints successful"
}

# Group builder predefined data upgrade
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateGroupBuilderData() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  loadGroupTable $TNT_SCHEMA $TNT_SHORT internal/config/predefined/v3.2.0/application/group-builder/GROUP_BUILDER_INSERT_DATA.sql && \
  return
  # if we're here something is wrong
  local RC=$?
  if [[ $RC -ne 0 ]]; then
    err "Migration of group builder data failed"
    return $RC
  fi
}

# Add new connection events columns
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateConnectionsEvents() {
  info "Updating connection events columns"
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local RC
  createIfNotExists "alter table ${TNT_SCHEMA}.CONNECTIONS_EVENTS add column \"ConnectionID\" VARCHAR(50) DEFAULT NULL" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.CONNECTIONS_EVENTS add column \"ConnectionName\" VARCHAR(255) DEFAULT NULL" && \
  createIfNotExists "alter table ${TNT_SCHEMA}.CONNECTIONS_EVENTS add column \"DBName\" VARCHAR(255) DEFAULT NULL" && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Failed to update CONNECTION_EVENTS"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.CONNECTION_EVENTS successful"
}

# Insert all predefined values
# $1 - Tenant schema name
# $2 - Tenant short ID
# $3 - Table name
# $4 - Insert script file name
function loadGroupTable() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local INSERT_SCRIPT="$3"
  local RC
  info "Inserting ${TNT_SCHEMA}.${TABNAME}"
  if ! [[ -f "$SQL_DIR"/$INSERT_SCRIPT ]]; then
    err "Cannot find insert script $SQL_DIR/$INSERT_SCRIPT"
    return 1
  fi
  sed 's/MY_TENANT_SCHEMA/'${TNT_SCHEMA}'/g' "$SQL_DIR"/$INSERT_SCRIPT | db2 +p +c -t
  RC=$?
  # We can ignore the "not found" warnings that can happen if the script runs more than once
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Failed to insert ${TNT_SCHEMA}.${TABNAME}"
    return $RC
  elif [[ $RC -eq 1 ]]; then
    info "No new rows to insert"
  fi
  db2 commit
  info "Insert of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Create stored procedure from script. Assumes it has CREATE OR REPLACE
# $1 - Tenant schema name
# $2 - SP script file name
function createSP() {
  local TNT_SCHEMA="$1"
  local SP_SCRIPT="$2"
  local RC
  info "Creating SP from ${SP_SCRIPT} in ${TNT_SCHEMA}"
  if ! [[ -f $SP_SCRIPT ]]; then
    err "Cannot find  script $SP_SCRIPT"
    return 1
  fi
  sed 's/MY_TENANT_SCHEMA/'${TNT_SCHEMA}'/g;$a @' $SP_SCRIPT | db2 +p +c -td@
  RC=$?
  if [[ $RC -ne 0 ]]; then
    db2 rollback
    err "Failed to create ${SP_SCRIPT}"
    return $RC
  else
    db2 commit
    info "Executed ${SP_SCRIPT} successfully"
  fi
}

# Remove old stored procedures
# $1 - Tenant schema name
function removeStoredProcs() {
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_CLASSIFICATION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_EXCEPTION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_FULL_SQL_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_INSTANCE_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_OBJECT_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_OVERFLOW_FIELDS_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_POLICY_VIOLATIONS_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_SENTENCE_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_SESSION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"ALT_INSERT_VA_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_CLASSIFICATION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_EXCEPTION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_FULL_SQL_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_INSTANCE_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_OBJECT_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_OVERFLOW_FIELDS_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_POLICY_VIOLATIONS_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_SENTENCE_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_SESSION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"INSERT_VA_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_CLASSIFICATION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_CLASSIFICATION_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_EXCEPTION_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_EXCEPTION_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_FULL_SQL_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_FULL_SQL_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_INSTANCE_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_INSTANCE_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_OBJECT_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_OBJECT_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_OVERFLOW_FIELDS_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_OVERFLOW_FIELDS_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_POLICY_VIOLATIONS_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_POLICY_VIOLATIONS_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_SENTENCE_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_SENTENCE_v3\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_VA_v2\"" && \
  dropIfExists "drop procedure ${TNT_SCHEMA}.\"SEC_INSERT_VA_v3\"" && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    err "error removing old stored procedures: ${RC}"
    return $RC
  fi
  db2 commit
  info "Successfully removed old stored procedures"
}

# Update DM stored procedures
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateStoredProcs() {
  local TNT_SCHEMA="$1"
  local RC

  # execute all scripts in ${SQL_DIR}/datamart-processor
  # v2 - only updated SPs
  # v3 - all
  for F in $(find ${SQL_DIR}/internal/config/predefined/v3.2.0/application/datamart-processor -type f -name "*\.sql"); do
    createSP ${TNT_SCHEMA} "${F}"
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate stored procedure upgrade due to earlier error"
      return $RC
    fi
  done
  db2 commit
  info "Updated stored procedures successfully"
}

function installFilePermissionChangeJar() {
  local RC
  # the setup-db2-ready job should have deposited the FilePermissionChange.jar
  # in /mnt/blumeta0/scratch/install/
  if [ ! -f /mnt/blumeta0/scratch/install/FilePermissionChange.jar ]; then
    err "failed to locate /mnt/blumeta0/scratch/install/FilePermissionChange.jar"
    err "FilePermissionChange.jar was likely not installed by db2-ready job"
    return 1
  fi
  info "located /mnt/blumeta0/scratch/install/FilePermissionChange.jar"
  # try install first
  STMT="call sqlj.install_jar ( 'file:/mnt/blumeta0/scratch/install/FilePermissionChange.jar', 'FilePermissionChange' )"
  OUT=$(db2 +c "${STMT}")
  RC=$?
  if [[ $RC -ne 0 ]]; then
    if [[ "$OUT" =~ SQL20201N ]]; then
      info "Install FilePermissionChange encountered SQL20201N, jar-id likely exists"
    else
      err "error binding jar FilePermissionChange: ${OUT}"
      return $RC #error
    fi
  fi
  # if we got here with an error, the jar-id likely exists. try an update.
  if [[ $RC -ne 0 ]]; then
    info "run replace_jar(FilePermissionChange)"
    STMT="call sqlj.replace_jar ( 'file:/mnt/blumeta0/scratch/install/FilePermissionChange.jar', 'FilePermissionChange' )"
    OUT=$(db2 +c "${STMT}")
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "error replacing jar FilePermissionChange: ${OUT}"
      return $RC #error
    fi
  fi
  db2 commit
  info "Installed jar-id FilePermissionChange"
}

function restartInstance() {
  info "Restarting instance to apply changes"
  db2stop force && db2start && db2 activate db $DBNAME
  local RC=$?
  if [[ $RC -ge 4 ]]; then
    err "Failed to restart the instance"
    return $RC
  else
    return
  fi
}

function on_exit {
  log "Clean up lock file on exit"
  rm -f "$LOCKFILE"
}
#----------------------------------------------------------------------------------------

debug "Top, shell level $SHLVL"

# address INS-17347
if [[ -f "$LOCKFILE" ]]; then
  err "Lock file $LOCKFILE found; another copy of $(basename "$0") is already running, terminating"
  info "NOTE: the lock file may have been left behind if $(basename "$0") previously has terminated abnormally"
  info "If that is the case, delete the lock file $LOCKFILE and retry"
  exit
fi

touch "$LOCKFILE"
# ensure the lock file is deleted on exit
trap on_exit EXIT

db2 connect to $DBNAME
if [[ $? -ne 0 ]]; then
  err "Failed to connect to $DBNAME database, exiting"
  exit 1
fi

info "Upgrading DB schemas to GI version 3.2. Start time: $(date +'%Y-%m-%d %T')"

info "Processing tenant schemas"
TNT_SCHEMATA=$(db2 -x "select schemaname from syscat.schemata
  where schemaname like 'TNT\\_%' escape '\\'
  and schemaname not like '%\\_CUSTOM' escape '\\'
  and schemaname not like '%\\_REPORT_RESULT' escape '\\'
  and schemaname not like '%\\_ERR_SCHEMA%' escape '\\'"
)
RC=$?
if [[ $RC -eq 1 ]]; then info "No tenant data, nothing to do" ; exit; fi
if [[ $RC -ge 4 ]]; then err "Could not list tenants" ; exit $RC; fi

RC=0
# server level update(s)
installFilePermissionChangeJar
RC=$?
if [[ $RC -ne 0 ]]; then err "Failed prereq for DB2 upgrade" ; exit $RC; fi

for TNT_SCHEMA in $TNT_SCHEMATA; do
  TNT_ID="${TNT_SCHEMA#TNT_}"
  TNT_SHORT_ID="${TNT_ID:0:11}"
  info "Processing tenant $TNT_ID"

  if [[ $RC -eq 0 ]]; then createNewReportResultSchema "${TNT_SCHEMA}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then createNewTablespaces ${TNT_SHORT_ID} ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then updateTablespaces ${TNT_SHORT_ID} ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then createDMStatusTables "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then createRptStatusTable "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then createRiskTables "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then upgradeCreateOutlierTables "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then updateGroupBuilderConstraints "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then updateGroupBuilderData "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then updateConnectionsEvents "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then updateVATable "${TNT_SCHEMA}" "${TNT_SHORT_ID}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then removeStoredProcs "${TNT_SCHEMA}" ; RC=$? ; fi
  if [[ $RC -eq 0 ]]; then updateStoredProcs "${TNT_SCHEMA}" ; RC=$? ; fi

  if [[ $RC -ne 0 ]]; then
    err "Failed to apply schema-level changes for tenant $TNT_ID"
    exit $RC
  fi
done

db2 terminate

info "Database upgrade to GI version 3.2 complete. End time: $(date +'%Y-%m-%d %T')"
