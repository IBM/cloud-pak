-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

------------------------------------------------
-- DDL Statements for Table "MY_TENANT_SCHEMA"."REPORT_RESULT_SUMMARY"
------------------------------------------------

CREATE TABLE "MY_TENANT_SCHEMA_REPORT_RESULT"."REPORT_RESULT_SUMMARY" (
    "ArtifactName" VARCHAR(255) DEFAULT NOT NULL,
    "ArtifactType" VARCHAR(50) DEFAULT NOT NULL,
    "JobType" VARCHAR(50) DEFAULT NOT NULL,
    "LastAccessedUTC" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP,
    "ReportID" VARCHAR(50),
    "Detail" VARCHAR(1024),
    "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP,
    PRIMARY KEY ("ArtifactName") ENFORCED
)
ORGANIZE BY ROW
IN GEN4_<TENANT_SHORT_ID>
INDEX IN IGEN4_<TENANT_SHORT_ID>;

CREATE INDEX "MY_TENANT_SCHEMA_REPORT_RESULT"."REPORT_RESULT_SUMMARY_I1"
    ON "MY_TENANT_SCHEMA_REPORT_RESULT"."REPORT_RESULT_SUMMARY"
        ("LastAccessedUTC");

CREATE INDEX "MY_TENANT_SCHEMA_REPORT_RESULT"."REPORT_RESULT_SUMMARY_I2"
    ON "MY_TENANT_SCHEMA_REPORT_RESULT"."REPORT_RESULT_SUMMARY"
        ("JobType");
