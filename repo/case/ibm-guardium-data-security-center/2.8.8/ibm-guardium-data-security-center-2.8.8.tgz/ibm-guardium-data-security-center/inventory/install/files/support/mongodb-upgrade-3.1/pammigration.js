//
// #################################################################
//  Licensed Materials - Property of IBM
//  (C) Copyright IBM Corp. 2021. All Rights Reserved.
//
//  US Government Users Restricted Rights - Use, duplication or
//  disclosure restricted by GSA ADP Schedule Contract with
//  IBM Corp
// #################################################################
//
// *******************************************************************************************************
//   * NAME: pammigration.js
//   * DESCRIPTION:
//      1.This script will iterate over all dbs with name TNT_
//      2.Find all pam documents from config collection (based on the field combined_configuration)
//      3.Insert those docs to config collection but append new field
// *******************************************************************************************************
//


var prefix = "TNT_";

// get all databases
db = db.getSiblingDB("admin");
var dbs = db.runCommand({ "listDatabases": 1 }).databases;

print("Searching for dbs with names like " + prefix);
dbs.forEach(function (database) {
  if (database.name.includes(prefix)){
    print("found db " + database.name);
    db = db.getSiblingDB(database.name); // use db
    var default_time_query = 2;  // default two hours
    // find any existing global settings config and update default_time_query
    var settings = db.config.find({"type": "Pam.Configuration"}).toArray();
    if (settings.length == 1){
      default_time_query= settings[0]["option"]["QUERY_TIME_RANGE"];
    }
    print("default query time duration is ",default_time_query)

    var docs = db.config.find({"type": "PAM" });
    var migrated_docs=0;
    // migratte all previous pam config docs
    docs.forEach(function (doc) {
      db.config.remove(doc); // remove will cause downgrade error, 
      migrated_docs++;
      delete doc["_id"]
      doc.option["duration"] = default_time_query
      doc.type = "WEBHOOK"
      db.config.insert(doc); // migrate to webhook config
    });
    print(migrated_docs, " are migrated.")
  }
}
);
