#!/bin/bash
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2019, 2024. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################
set -e

BASEDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

#Define number of mandatory and optional parameters.
TOTAL_MANDATORY_PARAM=3
TOTAL_OPTIONAL_PARAMS=5

#------------------------  Common functions ------------------------
function example {
    echo "Example - Deployment:-"
    echo -e "$0 [-n | --i-namespace VAL] [-h |--host-datanodes  VAL] [-l | --label-datanodes  VAL]\
 { [-t | --taint-datanodes  VAL] [-z | --custom-nb-scc VAL] [-k | --ingress-keystore  VAL] [-f | --ingress-cert VAL] [-c | --ingress-ca VAL] [-e | --non-ocp  VAL]}"
}

function usage {
    echo -e "Usage : $0 MANDATORY PARAMETERS [OPTIONAL PARAMETERS]"
}

function showHelp {
  usage
    echo -e "MANDATORY PARAMETERS:"
    echo -e "  -n | --i-namespace      : IBM Security Guardium Insights Openshift namespace."
    echo -e "  -h | --host-datanodes   : Hostpath of the data node or nodes (comma delimited)."
    echo -e "  -l | --label-datanodes  : If you specify 'true', data nodes will be labeled for dedicated for data service usage. If you specify 'false', labeling will be skipped."

    echo -e "OPTIONAL PARAMETERS:"
    echo -e "  -t | --taint-datanodes  : If you specify 'true', data nodes will be tainted and dedicated for data service usage. If you specify 'false', tainting will be skipped. Defaults to 'false'."
    echo -e "  -z | --custom-nb-scc    : If you specify 'true', a custom scc with a default name of 'noobaa-db-scc' will be created. Defaults to 'false' with no custom scc applied."
    echo -e "  -k | --ingress-keystore : If you will supply a custom Ingress [Recommended], provide the path to its key file. If you do not include this, a default of 'none' will be assumed (this is not recommended)."
    echo -e "  -f | --ingress-cert     : If you will supply a custom Ingress [Recommended], provide the path to its cert file. If you do not include this, a default of 'none' will be assumed (this is not recommended)."
    echo -e "  -c | --ingress-ca       : If you will supply a custom Ingress [Recommended], provide the path to its certificate authority (CA) file. If you do not include this, a default of 'none' will be assumed (this is not recommended)."
    echo -e "  -e | --non-ocp      : If you are deploying on non-ocp system, set this to true so that it disables certain flows"
    echo -e "  -help | --help          : Prints this help\n"

  example
}

#Basic validation of inputs
function validateInputs() {
   validateInputs=true
   #Validate data nodes
   for node in $(echo $DATA_NODES | sed "s/,/ /g")
   do
      if [[ -z `oc get nodes  ${node} --ignore-not-found` ]] ; then
         echo "Invalid value '${node}' for parameter '-h | --host-datanodes'; please enter a valid OpenShift node"
         validateInputs=false
      fi
   done
   #Validate taint data nodes
   if ! [[ "$TAINT_DATA_NODES" =~ ^(true|false)$ ]]; then
      echo "Invalid value '${TAINT_DATA_NODES}' for parameter '-t | --taint-datanodes'; only 'true' or 'false' is supported"
      validateInputs=false
   fi
   #Validate label data nodes
   if ! [[ "$LABEL_DATA_NODES" =~ ^(true|false)$ ]]; then
      echo "Invalid value '${LABEL_DATA_NODES}' for parameter '-l | --label-datanodes'; only 'true' or 'false' is supported"
      validateInputs=false
   fi
   #validate secret force replace
   if ! [[ "$SECRET_FORCEREPLACE" =~ ^(true|false)$ ]]; then
      echo "Invalid value '${SECRET_FORCEREPLACE}' for parameter '-s | --secret-replace'; only 'true' or 'false' is supported"
      validateInputs=false
   fi
   #Show help when validation fails and exit
   if [ "${validateInputs}" == "false" ] ; then
      echo "ERROR : One or more parameters are invalid"
      exit 1
   fi
}
validate_openssl() {
   KEY=masterTest
   ##Encryp
   ORIG_STRING=apple
   ##source
   EncryptedSecret=$(printf $ORIG_STRING | openssl enc -aes-256-cbc -base64 -salt -pbkdf2 -A -k $KEY)
   DecryptedCredVal=$(printf $EncryptedSecret | openssl enc -aes-256-cbc -d -base64 -salt -pbkdf2 -A -k $KEY)
      if [[ "$ORIG_STRING" == "$DecryptedCredVal" ]]; then
         echo "OpenSSL is working with parameters -pbkdf2"
      else
         echo "openssl does not support the following options: enc -aes-256-cbc -base64 -salt -pbkdf2"
         exit 1
      fi  
}

#------------------------  End of Common functions ------------------------

#------------------------  show help when script executes with no paramter ------------------------
if [ "$#" -lt 1 ] ; then
   showHelp
   exit 1
fi

#------------------------  Set values from parameters passsed  ------------------------
margsPassed=0 #Initialize mandatory parameter counter
oargsPassed=0 #Initialize optional parameter counter

TAINT_DATA_NODES="false" #Set default value
LABEL_DATA_NODES="true" #Set default value
CUSTOM_NB_SCC="false" #Set default value
SECRET_FORCEREPLACE="false" #Set default value
INGRESS_KEYFILE="none" #Set default value
INGRESS_CERTFILE="none" #Set default value
INGRESS_CAFILE="none" #Set default value
NON_OCP="false" #set default value

while [ "${1}" != "" ];
do
   case ${1} in
   -n  | --i-namespace  )
                             shift
                             INSIGHTS_NAMESPACE=${1}
                             #set mandatory argument counter for validation
                             margsPassed=$((${margsPassed} + 1))
                             ;;
   -h | --host-datanodes)
                             shift
                             DATA_NODES=${1}
                             #set mandatory argument counter for validation
                             margsPassed=$((${margsPassed} + 1))
                             ;;
   -l | --label-datanodes )  shift
                             LABEL_DATA_NODES=${1}
                             #set mandatory argument counter for validation
                             margsPassed=$((${margsPassed} + 1))
                             ;;   
   -t | --taint-datanodes )  shift
                             TAINT_DATA_NODES=${1}
                             #set mandatory argument counter for validation
                             oargsPassed=$((${oargsPassed} + 1))
                             ;;
   -e | --non-ocp )
                             shift
                             NON_OCP=${1}
                             #set Optional argument counter for validation
                             oargsPassed=$((${oargsPassed} + 1))
                             ;;
   -z | --custom-nb-scc )      shift
                             CUSTOM_NB_SCC=${1}
                             #set Optional argument counter for validation
                             oargsPassed=$((${oargsPassed} + 1))
                             ;;                              
   -k | --ingress-keystore ) shift
                             INGRESS_KEYFILE=${1}
                             #set Optional argument counter for validation
                             oargsPassed=$((${oargsPassed} + 1))
                             ;;
   -f | --ingress-cert )
                             shift
                             INGRESS_CERTFILE=${1}
                             #set Optional argument counter for validation
                             oargsPassed=$((${oargsPassed} + 1))
                             ;;
   -c | --ingress-ca )
                             shift
                             INGRESS_CAFILE=${1}
                             #set Optional argument counter for validation
                             oargsPassed=$((${oargsPassed} + 1))
                             ;;
   -help   | --help )
                             showHelp
                             exit
                             ;;
   *)
                             echo "ERROR : Unknown option"
                             usage
                             example
						     exit 1 # error
                             ;;
   esac
   shift
done

#------------------------  Validate number of mandatory parameters ------------------------
if [ ${margsPassed} -lt ${TOTAL_MANDATORY_PARAM} ] ; then
   echo "ERROR : One or more mandatory parameters missing"
   showHelp
   exit 1
elif [ ${oargsPassed} -lt ${TOTAL_OPTIONAL_PARAMS} ] ; then
   echo "Warning : One or more optional parameters not passed, default values will be used"
fi

#####################################################################################################
#    Main Execution start here
#####################################################################################################
#Validate inputs
validateInputs
validate_openssl

#------------------------ pre-Install Guardium Insights ------------------------
echo "#####IBM Guardium Insights Pre-installation: Starting Preparation#####"

#------------------------ Node Properties ------------------------
   echo "The system properties of the nodes"
   if [[ $NON_OCP == 'true' ]]; then
      echo "Skipping due to NON_OCP being true"
   else
      # Check if TAINT_DATA_NODES is not false, then fetch all nodes
      if [ "${TAINT_DATA_NODES}" != 'false' ]; then
         ClusterNodeList=$(oc get nodes --no-headers)
      else
         ClusterNodeList=$(oc get nodes --no-headers | awk '/worker*/ {print $1}')
      fi
      for node in $ClusterNodeList
      do
         echo "############# ${node} #############"
         echo "********* Pods running on the nodes *************"

         oc get pods --all-namespaces -o wide --field-selector spec.nodeName="${node}" | awk '!/openshift-*/ && !/ibm-common-*/ && !/rook-ceph/ && !/kube-*/ {print $1 "\t\t" $2}'

            echo -e "********* Node System Details *************\n"
            echo "#### Memory Details ####"
         Allocated_Memory=$(oc get nodes ${node} -o=jsonpath="{range .items[*]}{.metadata.name}{'\n'}{.status.capacity.memory}{'\n'}" | awk 'NR==2 {$1/=1048576;printf "%.2fGB\n",$1}')
         Available_Memory=$(oc get nodes ${node} -o=jsonpath="{range .items[*]}{.metadata.name}{'\n'}{.status.allocatable.memory}{'\n'}" | awk 'NR==2 {$1/=1048576;printf "%.2fGB\n",$1}')

         echo -e "The total memory in ${node} is: $Allocated_Memory"
         echo -e "The available memory for the deployment in ${node} is: $Available_Memory\n"

         echo "#### CPU Details ####"
         Allocated_CPU=$(oc get nodes ${node} -o=jsonpath="{range .items[*]}{.metadata.name}{'\n'}{.status.capacity.cpu}{'\n'}" | awk 'NR==2 {print $1}')
         Available_CPU=$(oc get nodes ${node} -o=jsonpath="{range .items[*]}{.metadata.name}{'\n'}{.status.allocatable.cpu}{'\n'}" |  awk 'NR==2 {$1/=1000;printf "%.2f\n",$1}')

         echo -e "The total CPU in ${node} is: $Allocated_CPU"
         echo -e "The available CPU for the deployment in ${node} is: $Available_CPU\n\n"
      done
   fi
#------------------------ Ensure in the correct namespace ------------------------
echo "The system properties of the nodes"
if [[ $NON_OCP == 'true' ]]; then
   echo "Skipping the system properties due to NON_OCP being true"
else
   if [[ -z `oc get namespace  ${INSIGHTS_NAMESPACE} --ignore-not-found` ]] ; then
      oc create namespace ${INSIGHTS_NAMESPACE}
   fi
   oc project ${INSIGHTS_NAMESPACE}
fi
#------------------------ Label and Taint data node(s) ------------------------
hostpath_datanodes=`echo ${DATA_NODES} | sed -e 's#,# #g'`

# label datanodes if requested (optional arg and true by default)
if [ "X${LABEL_DATA_NODES}" != 'Xfalse' ]; then
   for node in ${hostpath_datanodes}
   do
     label=$(oc get node ${node} --show-labels | grep -i icp4data=database-db2wh | wc -l)
     if [[ $label -eq 1 ]]; then
        echo "Node ${node} already labelled."
     else
        oc label node ${node} icp4data=database-db2wh
     fi
   done
else
   echo "Skipping data node(s) labeling."
fi

# taint datanodes if requested (required arg)
if [ "X${TAINT_DATA_NODES}" != 'Xfalse' ]; then
   set +e
   # remove the taint from all worker nodes before adding the taint to the data nodes;
   # this will resolve cases where the db2 node is moved between deployments
   oc adm taint node $(oc get nodes | grep --color=never worker | cut -f 1 -d ' ' | xargs) icp4data=database-db2wh:NoSchedule-
   set -e

   oc adm taint node ${hostpath_datanodes} icp4data=database-db2wh:NoSchedule
   taintRC=$?
#   kubectl drain ${hostpath_datanodes} --ignore-daemonsets --delete-local-data
#   kubectl uncordon ${hostpath_datanodes}
else
  echo "Skipping data node(s) tainting."
fi
if [[ $taintRC -ne 0 ]]; then
  echo "There was a problem running: oc adm taint node ${hostpath_datanodes}"
  echo "Please ensure that the list of nodes exist on the cluster"
  exit 1
fi

# label datanodes if requested (optional arg and true by default)
if [ "X${LABEL_DATA_NODES}" != 'Xfalse' ]; then
   for node in ${hostpath_datanodes}
   do
     label=$(oc get node ${node} --show-labels | grep -i icp4data=database-db2wh | wc -l)
     if [[ $label -eq 1 ]]; then
        echo "Node ${node} already labelled."
     else
        oc label node ${node} icp4data=database-db2wh
     fi
   done
else
   echo "Skipping data node(s) labeling."
fi

# Create custom scc for ODF storage install (optional arg set as false by default)
echo "##### IBM Guardium Insights Pre-installation: Custom Noobaa SCC creation#####"
pushd $BASEDIR 2>&1 >/dev/null
if [ "X${CUSTOM_NB_SCC}" != 'Xfalse' ]; then
  echo "#####IBM Guardium Insights Pre-installation: Applying Custom Noobaa SCC#####"
  #------------------------  SCC preparation for db2 with ODF ------------------------
  echo "Setting scc as $CUSTOM_NB_SCC"
    # create scc yaml with the intended namespace and then apply
    sed -e 's#REPLACE_NAMESPACE#'$INSIGHTS_NAMESPACE'#g' gi-odf-scc_source.yaml > gi-odf-scc.yaml
    oc apply -f gi-odf-scc.yaml
else
  echo "Skipping custom noobaa scc creation"
fi
popd 2>&1 >/dev/null

#if [[ $? -ne 0 ]]; then
#  echo "There was a problem running: oc label node ${hostpath_datanodes}"
#  echo "Please ensure that the list of nodes exist on the cluster"
#  exit 1
#fi

#echo "#####IBM Guardium Insights Pre-installation: Preparation of SCCs and SAs#####"
#------------------------  SA and preparation for other servuces ------------------------
#oc delete sa insights-sequencersa --ignore-not-found -n ${INSIGHTS_NAMESPACE}
#oc create sa insights-sequencersa -n ${INSIGHTS_NAMESPACE}
#oc adm policy add-role-to-user cert-manager-ibm-cert-manager system:serviceaccount:${INSIGHTS_NAMESPACE}:insights-sequencersa
#oc delete sa insights-sa --ignore-not-found -n ${INSIGHTS_NAMESPACE}
#oc create sa insights-sa -n ${INSIGHTS_NAMESPACE}
#oc adm policy add-scc-to-user nonroot system:serviceaccount:${INSIGHTS_NAMESPACE}:insights-sa
#oc adm policy add-scc-to-user nonroot system:serviceaccount:${INSIGHTS_NAMESPACE}:insights-sequencersa
# To make sure this is removed from existing system if present
#oc adm policy remove-scc-from-user nonroot system:serviceaccount:${INSIGHTS_NAMESPACE}:insights-sa > /dev/null 2>&1 || true
#oc adm policy remove-scc-from-user nonroot system:serviceaccount:${INSIGHTS_NAMESPACE}:insights-sequencersa > /dev/null 2>&1 || true
#------------------------  Create ICP auth secret ------------------------
#AuthAdminSecret="insights-ics-authadmin"
#oc delete secret "${AuthAdminSecret}" --ignore-not-found  -n ${INSIGHTS_NAMESPACE}
#echo "Creating Insights ics auth admin secret in '${INSIGHTS_NAMESPACE}' namespace"
#Hide password when running in bash debug mode (bash -x)
#if [[ $- =~ x ]]; then debug=1; set +x; fi
#oc create secret generic "${AuthAdminSecret}"  -n  "${INSIGHTS_NAMESPACE}" --from-literal=_AUTH_ADMIN_USER="${AUTH_ADMINUSER}" --from-literal=_AUTH_ADMIN_CREDENTIAL="${AUTH_ADMINPWD}"
#if [[ $debug == 1 ]] ; then set -x ; fi

#------------------------  Ingres Certificate Recreation ------------------------
echo "#####IBM Guardium Insights Pre-installation: Ingress Certificate Recreation#####"
pushd $BASEDIR/certCreation 2>&1 >/dev/null
./certCreation.sh ${INSIGHTS_NAMESPACE} ${SECRET_FORCEREPLACE} ${INGRESS_KEYFILE} ${INGRESS_CERTFILE} ${INGRESS_CAFILE}
popd 2>&1 >/dev/null

#------------------------  Guardium Insights Secret Creation ------------------------
#echo "#####IBM Guardium Insights Pre-installation: Secret Creation#####"
#pushd $BASEDIR/ 2>&1 >/dev/null
#./preInstall_secrets.sh -i ./preInstall_secretList.csv -n ${INSIGHTS_NAMESPACE} -o ${SECRET_FORCEREPLACE}
#popd 2>&1 >/dev/null

#------------------------  Guardium Insights Encrypt Secrets ------------------------
#echo "#####IBM Guardium Insights Pre-installation: Secret Encryption#####"
#pushd $BASEDIR/ 2>&1 >/dev/null
#./encryptSecrets.sh -i ./preInstall_secretList.csv -n ${INSIGHTS_NAMESPACE}
#popd 2>&1 >/dev/null
