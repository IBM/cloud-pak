-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************
------------------------------------------------
-- DDL Statements for Table "MY_TENANT_SCHEMA"."DM_FILE_INFO"
------------------------------------------------
CREATE TABLE "MY_TENANT_SCHEMA"."DM_FILE_INFO"  (
    "IngestionID" INTEGER NOT NULL,
    "DataType" VARCHAR(255 OCTETS) NOT NULL,
    "FileName" VARCHAR(255 OCTETS) NOT NULL,
    "Error" CLOB INLINE LENGTH 2500 NOT NULL WITH DEFAULT,
    "RetryCount" INTEGER NOT NULL WITH DEFAULT 0,
    "RetryStartTime" TIMESTAMP NOT NULL,
    "RetryEndTime" TIMESTAMP,
    "FailedState" BOOLEAN WITH DEFAULT true,
    "GlobalID" VARCHAR (255 OCTETS) NOT NULL WITH DEFAULT,
    "IngestRecordCount" INTEGER NOT NULL WITH DEFAULT 0,
    PRIMARY KEY ("IngestionID", "FileName")
)
ORGANIZE BY ROW
IN DMSTAT_<TENANT_SHORT_ID>
INDEX IN IGEN4_<TENANT_SHORT_ID>;

CREATE INDEX "MY_TENANT_SCHEMA"."DM_FILE_INFO_I1" ON "MY_TENANT_SCHEMA"."DM_FILE_INFO"
    ("FileName", "GlobalID")
    ALLOW REVERSE SCANS;
