-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_INSTANCE_v3"(
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH, TNT_ID), '/'), FILENAME));

	-- create an external table for the csv file
    SET CREATE_STMT = 'CREATE EXTERNAL TABLE ' || TNT_ID || '.' || TABLENAME || ' (UTCOffset FLOAT, InstanceId DECIMAL(20), SessionId DECIMAL(20), SuccessfulSqls  DECIMAL(20),
                      FailedSqls DECIMAL(20), ObjectsandVerbs VARCHAR(1000), ConstructId VARCHAR(40), PeriodStart TIMESTAMP, PeriodStartUTC TIMESTAMP, DBUserName VARCHAR(255), OSUser VARCHAR(255),
                      SourceProgram VARCHAR(255), ServerIP VARCHAR(50), AnalyzedClientIP VARCHAR(50), ServiceName VARCHAR(80), ClientHostName VARCHAR(255), ServerType VARCHAR(30),
                      AppUserName VARCHAR(240), DatabaseName VARCHAR(255), ApplicationEventID DECIMAL(20), EventUserName VARCHAR(240), EventType VARCHAR(30), EventValueStr VARCHAR(255),
                      EventValueNum VARCHAR(30), EventDate TIMESTAMP, EventDateUTC TIMESTAMP, ServerPort VARCHAR(10), NetworkProtocol VARCHAR(20), TotalRecordsAffected DECIMAL(11), ServerHostName VARCHAR(255),
                      Timestamp TIMESTAMP, TimestampUTC TIMESTAMP, OriginalSQL VARCHAR(8192), AverageExecutionTime DECIMAL(11), Db2ClientInfo VARCHAR(1024), Db2IZDatabase VARCHAR(240), Db2ICurrentUser VARCHAR(240), Db2IZProgram VARCHAR(240), ProcessID VARCHAR(255), DBProtocol VARCHAR(20), OverflowFlagOriginalSQL DECIMAL(5))
                      USING (DATAOBJECT ''' || FILEPATH || ''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString
                      TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;

    -- Insert the INSTANCE rows from the external table
	SET INSERT_STMT = 'INSERT INTO "' || TNT_ID || '"."INSTANCE" ("MessageType", "ID", "InstanceID", "SessionID", "UTCOffset", "PeriodStart", "PeriodStartUTC", "PeriodEnd", "PeriodEndUTC", "ApplicationEventID", "AppUserName", "ApplicationEventType",
                  "ApplicationEventValueStr", "ApplicationEventValueNum", "ApplicationEventDate", "ApplicationEventDateUTC", "ConstructID", "OriginalSQL", "ObjectsandVerbs", "SuccessfulSqls", "FailedSqls", "DBUserName",
                  "OSUser", "SourceProgram", "ServerIP", "ClientID", "ServiceName", "ClientHostName", "ServerType", "DatabaseName", "EventUserName", "ServerPort", "NetworkProtocol",
                  "TotalRecordsAffected", "ServerHostName", "Timestamp", "TimestampUTC", "AverageExecutionTime", "ConfigID", "GlobalID", "Db2ClientInfo", "Db2IZDatabase", "Db2ICurrentUser", "Db2IZProgram", "ProcessID", "DBProtocol", "OverflowFlagOriginalSQL")
                  SELECT
                  ''INSTANCE'',
                  NULL,
                  InstanceId,
                  SessionId,
                  UTCOffset,
                  PeriodStart,
                  PeriodStartUTC,
                  NULL,
                  NULL,
                  ApplicationEventID,
                  AppUserName,
                  EventType,
                  EventValueStr,
                  EventValueNum,
                  EventDate,
                  EventDateUTC,
                  ConstructId,
                  OriginalSQL,
                  ObjectsandVerbs,
                  SuccessfulSqls,
                  FailedSqls,
                  DBUserName,
                  OSUser,
                  SourceProgram,
                  ServerIP,
                  AnalyzedClientIP,
                  ServiceName,
                  ClientHostName,
                  ServerType,
                  DatabaseName,
                  EventUserName,
                  ServerPort,
                  NetworkProtocol,
                  TotalRecordsAffected,
                  ServerHostName,
                  Timestamp,
                  TimestampUTC,
                  AverageExecutionTime,
                  ''0'',
                  ''' || GLOBALID || ''',
                  Db2ClientInfo,
                  Db2IZDatabase,
                  Db2ICurrentUser,
                  Db2IZProgram,
                  ProcessID,
                  DBProtocol,
                  OverflowFlagOriginalSQL FROM "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;

END S1
