-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_POLICY_VIOLATIONS_v4" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  DECLARE duplicate CONDITION FOR SQLSTATE '23505';
	DECLARE CONDITION_COUNT INT;
  DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  	SET CONDITION_COUNT = 0;

  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset              FLOAT
        ,OSUser                VARCHAR(255)
        ,DBUserName            VARCHAR(255)
        ,AnalyzedClientIP      VARCHAR(50)
        ,ClientHostName        VARCHAR(255)
        ,SourceProgram         VARCHAR(255)
        ,ServerIP              VARCHAR(50)
        ,ServerType            VARCHAR(30)
        ,Timestamp             TIMESTAMP
        ,TimestampUTC          TIMESTAMP
        ,ServiceName           VARCHAR(80)
        ,Severity              DECIMAL(20)
        ,FullSQLString         VARCHAR(8192)
        ,AccessRuleDescription VARCHAR(100)
        ,ViolationLogId        DECIMAL(20)
        ,ObjectsandVerbs       VARCHAR(1000)
        ,ServerHostName        VARCHAR(255)
        ,SessionId             DECIMAL(20)
        ,ConstructId           VARCHAR(40)
        ,ProcessId             VARCHAR(255)
        ,OverflowFlagFullSQL   DECIMAL(5))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
  EXECUTE IMMEDIATE CREATE_STMT;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID","OverflowFlagFullSQL")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      ConstructId,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
      '''||GLOBALID||''',
      ProcessId,
      OverflowFlagFullSQL FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID","OverflowFlagFullSQL")
	  SELECT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      ConstructId,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
      '''||GLOBALID||''',
      ProcessId,
      OverflowFlagFullSQL FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
    Select "ViolationID","ConfigID","GlobalID" from "'||TNT_ID||'"."POLICY_VIOLATION" mt where mt."ViolationID" = Ext.ViolationLogId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
    EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."POLICY_VIOLATION" ("MessageType","ID","ViolationID","SessionID","UTCOffset","OSUser","DBUserName","ClientID","ClientHostName","SourceProgram","ServerIP","ServerType","ServiceName","ConstructID","ObjectsandVerbs","AppUserName","AccessRuleID","AccessRuleDescription","Verdict","FullSQL","SendMessage","CurrentCounter","KeyString","CategoryName","ClassificationName","Severity","PolicyDescription","Timestamp","TimestampUTC","ServerHostName","ConfigID","GlobalID","ProcessID","OverflowFlagFullSQL")
	  SELECT DISTINCT ''POLICY_VIOLATION'',
      NULL,
      ViolationLogId,
      SessionId,
      UTCOffset,
      OSUser,
      DBUserName,
      AnalyzedClientIP,
      ClientHostName,
      SourceProgram,
      ServerIP,
      ServerType,
      ServiceName,
      ConstructId,
      ObjectsandVerbs,
      NULL,
      NULL,
      AccessRuleDescription,
      NULL,
      FullSQLString,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      Severity,
      NULL,
      TIMESTAMP,
      TimestampUTC,
      ServerHostName,
      ''0'',
      '''||GLOBALID||''',
      ProcessId,
      OverflowFlagFullSQL FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
    Select "ViolationID","ConfigID","GlobalID" from "'||TNT_ID||'"."POLICY_VIOLATION" mt where mt."ViolationID" = Ext.ViolationLogId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
  EXECUTE IMMEDIATE INSERT_STMT;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

exit:
  SET ROWCOUNT = AFFECTED_ROWS; 
END S1