-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."INSERT_FULL_SQL_v4" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  DECLARE duplicate CONDITION FOR SQLSTATE '23505';
	DECLARE CONDITION_COUNT INT;
  DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  	SET CONDITION_COUNT = 0;

  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset   FLOAT,
    AccessRuleDescription	VARCHAR(100),
    FullSql     VARCHAR(8192),
    InstanceID	DECIMAL(20),
    RecordsAffected	  DECIMAL(11),
    ResponseTime	DECIMAL(11),
    SessionId	DECIMAL(20),
    Succeeded	DECIMAL(11),
    Timestamp	TIMESTAMP,
    TimestampUTC  TIMESTAMP,
    FullSQLID   VARCHAR(20),
    BindVariablesValues VARCHAR(255),
    OverflowFlagFullStatement DECIMAL(5))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
  EXECUTE IMMEDIATE CREATE_STMT;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues","OverflowFlagFullStatement")
	  SELECT ''FULL_SQL'',
      NULL,
      FullSQLID,
      SessionId,
      Timestamp,
      TimestampUTC,
      UTCOffset,
      InstanceID,
      AccessRuleDescription,
      FullSql,
      RecordsAffected,
      Succeeded,
      NULL,
      ResponseTime,
      NULL,
      ''0'',
      '''||GLOBALID||''',
      BindVariablesValues,
      OverflowFlagFullStatement FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues","OverflowFlagFullStatement")
	  SELECT ''FULL_SQL'',
      NULL,
      FullSQLID,
      SessionId,
      Timestamp,
      TimestampUTC,
      UTCOffset,
      InstanceID,
      AccessRuleDescription,
      FullSql,
      RecordsAffected,
      Succeeded,
      NULL,
      ResponseTime,
      NULL,
      ''0'',
      '''||GLOBALID||''',
      BindVariablesValues,
      OverflowFlagFullStatement FROM "'||TNT_ID||'"."'||TABLENAME||'"  Ext
    WHERE NOT EXISTS (
      Select "FullSQLID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."FULL_SQL" mt where mt."FullSQLID" = Ext.FullSQLID AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
    EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."FULL_SQL" ("MessageType","ID","FullSQLID","SessionID","Timestamp","TimestampUTC","UTCOffset","InstanceID","AccessRuleDescription","FullStatement","TotalRecordsAffected","Succeeded","Status","ResponseTime","ACKResponseTime","ConfigID","GlobalID","BindVariablesValues","OverflowFlagFullStatement")
	  SELECT DISTINCT ''FULL_SQL'',
      NULL,
      FullSQLID,
      SessionId,
      Timestamp,
      TimestampUTC,
      UTCOffset,
      InstanceID,
      AccessRuleDescription,
      FullSql,
      RecordsAffected,
      Succeeded,
      NULL,
      ResponseTime,
      NULL,
      ''0'',
      '''||GLOBALID||''',
      BindVariablesValues,
      OverflowFlagFullStatement FROM "'||TNT_ID||'"."'||TABLENAME||'"  Ext
    WHERE NOT EXISTS (
      Select "FullSQLID","SessionID","ConfigID","GlobalID" from "'||TNT_ID||'"."FULL_SQL" mt where mt."FullSQLID" = Ext.FullSQLID AND mt."SessionID" = Ext.SessionId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
    EXECUTE IMMEDIATE INSERT_STMT;

    GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

exit:
  SET ROWCOUNT = AFFECTED_ROWS;  
END S1
