if ! kubectl get operatorgroup -n $NAMESPACE | grep -q .; then
  operatorgroup=$(cat <<EOF
apiVersion: operators.coreos.com/v1alpha2
kind: OperatorGroup
metadata:
  name: operatorgroup
  namespace: $NAMESPACE
spec:
  targetNamespaces:
    - $NAMESPACE
EOF
  )
  echo "$operatorgroup" | kubectl apply -f -
else
  echo "OperatorGroup already exists in namespace ${NAMESPACE}."
fi

# CPFS Installation
config=$(cat <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: ibm-cpp-config
  namespace: $NAMESPACE
data:
  domain_name: "$HOSTNAME"
  kubernetes_cluster_type: cncf
---
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: opencloud-operators
  namespace: $NAMESPACE
spec:
  displayName: IBMCS Operators
  publisher: IBM
  sourceType: grpc
  image: icr.io/cpopen/ibm-common-service-catalog:4.6.2
  updateStrategy:
    registryPoll:
      interval: 45m
---
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: cloud-native-postgresql-catalog
  namespace: $NAMESPACE
spec:
  displayName: Cloud Native Postgresql Catalog
  publisher: IBM
  sourceType: grpc
  image: icr.io/cpopen/ibm-cpd-cloud-native-postgresql-operator-catalog@sha256:0b46a3ec66622dd4a96d96243602a21d7a29cd854f67a876ad745ec524337a1f
  updateStrategy:
    registryPoll:
      interval: 45m
---
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: ibm-common-service-operator
  namespace: $NAMESPACE
spec:
  channel: v4.6
  installPlanApproval: Automatic
  name: ibm-common-service-operator
  source: opencloud-operators
  sourceNamespace: $NAMESPACE
EOF
)

echo "$config" | kubectl apply -f -

CRD_NAME="commonservices.operator.ibm.com"
attempt_counter=0
max_attempts=5

echo "Validate the installation"

while [ $attempt_counter -lt $max_attempts ]; do
  kubectl get crd | grep "${CRD_NAME}" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    echo "CRD ${CRD_NAME} exists."
    break
  else
    echo "Waiting for CRD ${CRD_NAME} to be created in namespace ${NAMESPACE}... Attempt $((attempt_counter + 1))/$max_attempts"
    attempt_counter=$((attempt_counter + 1))
    sleep 30
  fi
done

if [ $attempt_counter -eq $max_attempts ]; then
  echo "CRD ${CRD_NAME} not found after $max_attempts attempts. Exiting."
  exit 1
fi

operand_request=$(cat <<EOF
apiVersion: operator.ibm.com/v1alpha1
kind: OperandRequest
metadata:
  name: common-service
  namespace: $NAMESPACE
spec:
  requests:
    - operands:
        - name: ibm-im-operator
        - name: ibm-platformui-operator
        - name: cloud-native-postgresql
        - name: ibm-events-operator
      registry: common-service
      registryNamespace: $NAMESPACE
EOF
)

echo "$operand_request" | kubectl apply -f -
