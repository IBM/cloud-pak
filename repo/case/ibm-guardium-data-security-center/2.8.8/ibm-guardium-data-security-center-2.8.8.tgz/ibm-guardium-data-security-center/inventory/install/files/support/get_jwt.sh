#!/bin/bash

# **************************************************************
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2020. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
# **************************************************************
host=$1
user=$2
password=$3
tenantId=$4

if [[ $# -lt 3 ]]; then
    echo "Usage: ./get_jwt.sh <hostname> <admin user id> <admin password> [<tenant ID>]"
    exit 2
fi

basicAuth=$(echo -n ${user}:${password} | base64)

res=$(curl -k -X POST "https://${host}/api/v3/authorization" -H "accept: application/json" -H "authorization: Basic ${basicAuth}" -H "Content-Type: application/json" -d "{ \"tenant_id\": \"${tenantId}\"}")

echo ${res} | jq .jwt | sed -e 's/^"//' -e 's/"$//'