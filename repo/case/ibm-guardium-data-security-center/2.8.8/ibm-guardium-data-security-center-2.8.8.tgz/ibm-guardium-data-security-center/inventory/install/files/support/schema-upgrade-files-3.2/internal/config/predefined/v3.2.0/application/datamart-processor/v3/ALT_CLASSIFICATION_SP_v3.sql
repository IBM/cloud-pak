-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_CLASSIFICATION_v3" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
)
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
    DECLARE duplicate CONDITION FOR SQLSTATE '23505';
    DECLARE CONDITION_COUNT INT;
    DECLARE AFFECTED_ROWS INT;

    DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
        SET CONDITION_COUNT = 0;

    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(255),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    ResultDataRowID DECIMAL(20),
    Comments VARCHAR(32000))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
    EXECUTE IMMEDIATE CREATE_STMT;

    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM "'||TNT_ID||'"."'||TABLENAME||'" ;';
    EXECUTE IMMEDIATE INSERT_STMT;

    GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
    Select "ResultDataRowID","ConfigID","GlobalID" from "'||TNT_ID||'"."CLASSIFICATION" mt where mt."ResultDataRowID" = Ext.ResultDataRowID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
    EXECUTE IMMEDIATE INSERT_STMT;

    GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT DISTINCT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
    Select "ResultDataRowID","ConfigID","GlobalID" from "'||TNT_ID||'"."CLASSIFICATION" mt where mt."ResultDataRowID" = Ext.ResultDataRowID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
    EXECUTE IMMEDIATE INSERT_STMT;

    GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 

exit:
    SET ROWCOUNT = AFFECTED_ROWS; 
END S1
