-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_OBJECT_v3" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE OBJECTMERGE VARCHAR(5000);
    DECLARE duplicate CONDITION FOR SQLSTATE '23505';
  DECLARE CONDITION_COUNT INT;
  DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
    SET CONDITION_COUNT = 0;

  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset               FLOAT
        ,SentenceId             VARCHAR(40)
        ,ConstructId            VARCHAR(40)
        ,ObjectId               VARCHAR(40)
        ,ObjectName             VARCHAR(255)
        ,Timestamp              TIMESTAMP
        ,TimestampUTC           TIMESTAMP)
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000
  )';
  EXECUTE IMMEDIATE CREATE_STMT;

  SET OBJECTMERGE = 'INSERT INTO "' || TNT_ID || '"."OBJECT" ("MessageType", "UTCOffset", "SentenceID", "ConstructID", "ObjectID", "ObjectName", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
	                  SELECT ''OBJECT'',
                        UTCOffset,
                        SentenceId,
                        ConstructId,
                        ObjectId,
                        ObjectName,
                        Timestamp,
                        TimestampUTC,
                      ''0'', ''' || GLOBALID || ''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
                    WHERE NOT EXISTS (
                      Select "ObjectID","ConfigID","GlobalID" from "'||TNT_ID||'"."OBJECT" mt where mt."SentenceID" = Ext.SentenceId AND mt."ConstructID" = Ext.ConstructId AND mt."ObjectID" = Ext.ObjectId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
                    );';
	EXECUTE IMMEDIATE  OBJECTMERGE;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

  SET OBJECTMERGE = 'INSERT INTO "' || TNT_ID || '"."OBJECT" ("MessageType", "UTCOffset", "SentenceID", "ConstructID", "ObjectID", "ObjectName", "Timestamp", "TimestampUTC", "ConfigID", "GlobalID")
	                  SELECT DISTINCT ''OBJECT'',
                        UTCOffset,
                        SentenceId,
                        ConstructId,
                        ObjectId,
                        ObjectName,
                        Timestamp,
                        TimestampUTC,
                      ''0'', ''' || GLOBALID || ''' FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
                    WHERE NOT EXISTS (
                      Select "ObjectID","ConfigID","GlobalID" from "'||TNT_ID||'"."OBJECT" mt where mt."SentenceID" = Ext.SentenceId AND mt."ConstructID" = Ext.ConstructId AND mt."ObjectID" = Ext.ObjectId AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
                    );';
	EXECUTE IMMEDIATE  OBJECTMERGE;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 

exit:
  SET ROWCOUNT = AFFECTED_ROWS;  
END S1
