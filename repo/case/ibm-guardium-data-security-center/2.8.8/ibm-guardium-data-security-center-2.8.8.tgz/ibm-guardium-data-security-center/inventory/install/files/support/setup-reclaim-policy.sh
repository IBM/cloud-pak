#!/bin/bash
namespace="$1"

pvc_list=$(oc get pvc -n "$namespace" --no-headers -o custom-columns=NAME:.metadata.name)
for pvc in $pvc_list; do
    pv=$(oc get pvc "$pvc" -o jsonpath='{.spec.volumeName}')
    if [[ -z "$pv" ]]; then
      echo " PVC $pvc does not have a bound PV. Skipping... "
	    continue
    fi 
    current_policy=$(oc get pv "$pv" -o jsonpath='{.spec.persistentVolumeReclaimPolicy}')
    if [[ "$current_policy" != "Retain" ]]; then
      oc patch pv "$pv" -p '{"spec":{"persistentVolumeReclaimPolicy":"Retain"}}'
      if [[ $? -eq 0 ]]; then 
	      echo " PVC $pvc : Reclaim policy for PV $pv set to retain. "
      else 
        echo " PVC $pvc : Failed to set reclaim policy for PV $pv "
      fi
    else
      echo " PVC $pvc : Reclaim policy for PV $pv is already retain. Skipping..."
    fi
done
