#!/bin/bash

#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

export BASE_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export NAMESPACE=$2
export GI_CR_NAME=$3
export DB2INSTANCE="db2inst1"

. ${BASE_DIR}/common.sh

function haltDataIngestion() {
  info_msgn "Stopping data ingestion ..."

  # Declare empty arrays
  declare -a FETCH_ARR
  declare -a DEPLOY_FETCH_ARR
  declare -a DEPLOY_GUARDIUM_CONNECTOR_ARR
  declare -a configmap_param

  #-----------------------#
  #         FETCH         #
  #-----------------------#
  TENANTS_NAME=`oc get tenantminisnif -oname | sed -e 's#.*/##'`
  IFS=$'\n' read -rd '' -a TENANTS_ARR <<< "$TENANTS_NAME" # The IFS is set to newline so the output gets split into the array
  for t in ${TENANTS_ARR[@]}; do
    fetch_name=$(oc get deploy -lapp.kubernetes.io/instance=$t | grep "\-fetch" | awk '{print $1}')
    FETCH_ARR+=("${fetch_name}")
  done

  fetch_lenght=${#FETCH_ARR[@]}

  for (( f=0; f<fetch_lenght; f++ )); do
    deploy_fetch_name_="deployment.apps/${FETCH_ARR[$f]}"
    Y1=`oc get $deploy_fetch_name_ -ogo-template='{{ .spec.replicas }}'`

    # Identifies whether it is evaluating the latest captured resource so doesn't add a comma at the end of the string
    if [[ $f == $((fetch_lenght - 1)) ]]; then
      DEPLOY_FETCH_ARR+='"'${deploy_fetch_name_:16}'":"'${Y1}'"'
    else
      DEPLOY_FETCH_ARR+='"'${deploy_fetch_name_:16}'":"'${Y1}'",'
    fi

    oc scale $deploy_fetch_name_ --replicas=0
    configmap_param+=" --from-literal=${deploy_fetch_name_:16}=$Y1"
  done

  #-----------------------#
  #  GUARDIUM_CONNECTOR   #
  #-----------------------#
  # Get the name of the deploy fetch deployment in format => deployment.apps\${GI_CR_NAME}*-guardium-connector
  DEPLOY_GUARDIUM_CONNECTOR_NAME=`oc get deployment.apps -oname | grep ${GI_CR_NAME} | grep "\-guardium-connector"`

  IFS=$'\n' read -rd '' -a GUARDIUM_CONNECTOR_ARRAY <<< "$DEPLOY_GUARDIUM_CONNECTOR_NAME" # The IFS is set to newline so the output gets split into the array
  guardium_connector_lenght=${#GUARDIUM_CONNECTOR_ARRAY[@]}

  for (( g=0; g<guardium_connector_lenght; g++ )); do
    deploy_guardium_connector_name_="${GUARDIUM_CONNECTOR_ARRAY[$g]}"
    Y2=`oc get $deploy_guardium_connector_name_ -ogo-template='{{ .spec.replicas }}'`

    # Identifies whether it is evaluating the latest captured resource so doesn't add a comma at the end of the string
    if [[ $g == $((guardium_connector_lenght - 1)) ]]; then
      DEPLOY_GUARDIUM_CONNECTOR_ARR+='"'${deploy_guardium_connector_name_:16}'":"'${Y2}'"'
    else
      DEPLOY_GUARDIUM_CONNECTOR_ARR+='"'${deploy_guardium_connector_name_:16}'":"'${Y2}'",'
    fi

    oc scale $deploy_guardium_connector_name_ --replicas=0
    configmap_param+=" --from-literal=${deploy_guardium_connector_name_:16}=$Y2"
  done  

  ## check if replica map exists; if yes and is not being halted earlier, update with the new value ;
  #if does not exist, create configMap with the new count

  if oc get configmap data-ingestion-replicas >/dev/null 2>&1; then
          if [ $(oc get configmap data-ingestion-replicas -o jsonpath='{.data.halt}') != "1" ];
          then
                oc patch configmap data-ingestion-replicas -p '{"data":{'${DEPLOY_FETCH_ARR}','${DEPLOY_GUARDIUM_CONNECTOR_ARR}'}}'
                oc patch configmap data-ingestion-replicas -p '{"data":{"halt":"1"}}'
          fi
  else
        oc create configmap data-ingestion-replicas ${configmap_param} --from-literal=halt=1
  fi
}

function enableDataIngestion() {
  info_msgn "Enabling data ingestion ..."

  oc project ${NAMESPCE}

  if oc get configmap data-ingestion-replicas >/dev/null 2>&1; then
        info_msgn "Enabling data ingestion ..."
        DATA_INGESTION=$(oc get configmap data-ingestion-replicas -o json | jq -r '.data')
        for key in $(echo "$DATA_INGESTION" | jq -r 'keys[]'); do
                value=$(echo "$DATA_INGESTION" | jq -r ".[\"$key\"]")
                if [ "$key" == "halt" ]; then
                  # put halt=0
                  oc patch configmap data-ingestion-replicas -p '{"data":{"halt":"0"}}'
                else
                  oc scale "deployment.apps/${key}" --replicas=$value
                fi
        done
  else
        info_msg "Data Stream services do not have its original replica count. Please stop first then start ... "
  fi
}

function suspendCronjob() {
  info_msgn "Suspending cron jobs ..."
  oc patch `oc get cronjob  -oname -n=${NAMESPACE}` -p '{"spec" : {"suspend" : true }}' -n=${NAMESPACE}
  info_msgn "All cron jobs suspended"
}

function enableCronjob() {
  info_msgn "Enabling cron jobs ..."
  oc patch `oc get cronjob  -oname -n=${NAMESPACE}` -p '{"spec" : {"suspend" : false }}' -n=${NAMESPACE}
  info_msgn "All cron jobs Enabled"
}

function drainKafka() {
  info_msgn "Draining kafka ..."
  ${BASE_DIR}/kafka_drain_test.sh -n ${GI_CR_NAME}
  info_msgn "Kafka drained"
}

function pauseDB2Pods() {
  info_msgn "Pausing DB2 pods  ..."

  info_msgn "Change db2u label database-db2wh "
  workerNode=`oc get nodes -Licp4data | grep database-db2wh|awk '{print $1}'`
  oc patch node $workerNode -p '{"metadata":{"labels":{"icp4data":"tmpVal"}}}'

  info_msgn "Delete db2u pods "
  Pods=`oc get pods | grep -i '^c.*db2' | awk '{print $1}'`
  for pod in $Pods; do
	oc delete pod $pod
  done
  
  info_msgn "Inspect two db2u pod status "
  oc get pods | grep -e 'etcd-0' -e 'db2u-0'
}

function resumeDB2Pods(){
  info_msgn "Resuming DB2 pods to set label database-db2wh back ..."
  workerNode=`oc get nodes -Licp4data | grep tmpVal |awk '{print $1}'`
  oc patch node $workerNode -p '{"metadata":{"labels":{"icp4data":"database-db2wh"}}}'
  info_msgn "Resumed DB2 pods  ..."
}

function scaleDownEventOperator(){
  info_msgn "Scaling down replicas in the events operator ... "
  oc project ibm-common-services
  eventOperator=`oc get deployment | grep ibm-events-operator |  awk '{print $1}'`
  oc patch deployment $eventOperator -p '{"spec":{"replicas":0}}'
  info_msgn "Scaled down replicas in the events operator. "

  info_msgn "Deleting Kafka and Zookeeper pods... "
  oc project $NAMESPACE
  Pods=`oc get pods | grep -e kafka -e zookeeper | awk '{print $1}'`
  for pod in $Pods; do
	  oc delete pod $pod
  done
  info_msgn "Deleted Kafka and Zookeeper pods... "
}

function scaleUpEventOperator(){
  info_msgn "Scaling up events operator ... "
  oc project ibm-common-services
  eventOperator=`oc get deployment | grep events-operator|awk '{print $1}'`
  oc patch deployment $eventOperator -p '{"spec":{"replicas":1}}'
  info_msgn "Scaled up events operator."

  info_msgn "Checking Kafka and Zookeepr pods status.."
  oc get pods | grep -e kafka -e zookeeper
}

function scaleDownSTS(){
  info_msgn "Scaling down replicas in STS stateful sets "

  oc project $NAMESPACE

  unset maparms
  X=`oc get sts,statefulsets -oname`
  for i in $X; do
        replica=`oc get $i -ogo-template='{{ .spec.replicas }}'`
        statefulset=${i#*/}
        oc scale sts $statefulset --replicas=0
        maparms+=" --from-literal=${statefulset}=$replica"
  done

    if oc get configmap sts-statefulsets-replicas >/dev/null 2>&1; then
          if [ $(oc get configmap sts-statefulsets-replicas -o jsonpath='{.data.stop}') != "1" ];
          then
                oc delete configmap sts-statefulsets-replicas
                oc create configmap sts-statefulsets-replicas $maparms --from-literal=stop=1
          fi
  else
         oc create configmap sts-statefulsets-replicas $maparms --from-literal=stop=1
  fi

  info_msgn "Scaled down replicas in STS stateful sets. "
}

function scaleUpSTS(){
 info_msgn "Scaling up replicas of STS stateful sets."

 oc project $NAMESPACE

 if oc get configmap sts-statefulsets-replicas >/dev/null 2>&1; then
        info_msgn "Scaling up STS stateful sets ... "
        config_sts_data=$(oc get configmap sts-statefulsets-replicas -o json | jq -r '.data')
        for repset in $(echo "$config_sts_data" | jq -r 'keys[]'); do
                repcount=$(echo "$config_sts_data" | jq -r ".[\"$repset\"]")
                if [ $repset != 'stop' ]; then
                        oc scale sts $repset --replicas=$repcount
                fi
        done

        ## put stop=0
        oc patch configmap sts-statefulsets-replicas -p '{"data":{"stop":"0"}}'
  else
        info_msg "STS stateful sets do not have its original replica count. Please stop first then start ... "
  fi

  info_msgn "Scaled up replicas of sts stateful sets."
}

function stopGIServices(){
  info_msgn "Stop Data Security Center microservices ... "

  oc project $NAMESPACE

  unset maparms
  X=$(oc get deployments,statefulsets -l project=insights -o name | awk '!/fetch/ && !/guardium-connector/')
  for i in $X; do
        replica=`oc get $i -ogo-template='{{ .spec.replicas }}'`
        deploy=`echo $i | sed -e 's#/#_#g'`
        maparms+=" --from-literal=${deploy}=$replica"
  done

  if oc get configmap gi-services-replicas >/dev/null 2>&1; then
          if [ $(oc get configmap gi-services-replicas -o jsonpath='{.data.stop}') != "1" ];
          then
                oc delete configmap gi-services-replicas
                oc create configmap gi-services-replicas $maparms --from-literal=stop=1
          fi
  else
         oc create configmap gi-services-replicas $maparms --from-literal=stop=1
  fi

  oc scale `oc get deployments,statefulsets -lproject=insights -oname | awk '!/fetch/ && !/guardium-connector/'` --replicas=0
  info_msgn "Successfully Stopped Guardium Insights microservices"
}

function startGIServices(){
  info_msgn "Start Guardium Data Security Center microservices ... "

  oc project $NAMESPACE

  if oc get configmap gi-services-replicas >/dev/null 2>&1; then
        info_msgn "Scaling up Guardium Data Security Center microservices ... "
        config_gi_data=$(oc get configmap gi-services-replicas -o json | jq -r '.data')
        for repset in $(echo "$config_gi_data" | jq -r 'keys[]'); do
                repcount=$(echo "$config_gi_data" | jq -r ".[\"$repset\"]")
                if [ $repset != 'stop' ]; then
                        deploy=`echo $repset | sed -e 's#_#/#g'`
                        oc scale $deploy --replicas=$repcount
                fi
        done

        oc patch configmap gi-services-replicas -p '{"data":{"stop":"0"}}'
  else
        info_msg "Guardium Data Security Center microservices do not have its original replica count. Please stop first then start ... "
  fi

  info_msgn "Successfully Started Guardium Data Security Center microservices"
}

### main ###

## check 
if [ "$#" -ne 3 ] || [ "$1" != "stop" -a "$1" != "start" ]; then
    echo "Usage: $0 [stop|start] [namespace] [GuardimDataSecurityCenter resource namespace] "
    exit 1
fi

# validate namespace
oc project ${NAMESPACE}
if [ $? -ne 0 ]; then
    echo "Namespace is wrong. Please correct and rerun."
    exit 2
fi

## validate GI resource namespace
oc get guardiuminsights ${GI_CR_NAME}
if [ $? -ne 0 ]; then
    echo "GuardiumDataSecurityCenter resource namespace is wrong. Please correct and rerun."
    exit 3 
fi

## kick off stop or start workflow 

if [ "X$1" == "Xstop" ]; then

info_msg "1. Halt all incoming data streams"
haltDataIngestion
print_line

info_msg "2. Suspend all cron jobs"
suspendCronjob
print_line

info_msg "3. Drain Kafka system"
drainKafka
print_line

info_msg "4. Stop Guardim Data Security Center services"
stopGIServices
print_line

info_msg "5. Stop DB2 instance"
info_msgn "Stopping DB2 instance ..."
db2name=`oc get pods | grep db2u-0 | awk '{print $1}'`
oc exec $db2name -- /bin/bash <<EOF
    sudo wvcli system disable -m "Disable HA before Db2 maintenance"
    su - ${DB2INSTANCE}
    db2stop
    ipclean
    db2stop
EOF
info_msgn "Stopped DB2 Instance ..."
print_line

info_msg "6. Pause db2u pod"
pauseDB2Pods
print_line

info_msg "7. Scale down Event operator,  Kafka,  Zookeeper pods"
scaleDownEventOperator
print_line

info_msg "8. Scale down all replicas except the db2u stateful set "
scaleDownSTS
print_line

elif [ "X$1" == "Xstart" ]; then

info_msg "1. Scale up the Event Operator "
scaleUpEventOperator
print_line

info_msg "2. Scale up all replicas except the db2u stateful set "
scaleUpSTS
print_line

info_msg "3. Resume DB2 pods ..."
resumeDB2Pods
print_line

info_msg "4. Checking DB2 instance status "
db2name=`oc get pods | grep db2u-0 | awk '{print $1}'`
oc exec $db2name -- /bin/bash <<EOF
	sudo wvcli system status
EOF
print_line

info_msg "5. Start Guardium Data Security Center services"
startGIServices
print_line

info_msg "6. Verify Guarding Data Security Center pods running status"
oc get pods -lapp.kubernetes.io/instance=${GI_CR_NAME}
print_line

info_msg "7. Resume all cron jobs"
enableCronjob
print_line

info_msg "8. Resume data streams "
enableDataIngestion
print_line

fi

