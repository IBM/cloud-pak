-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."INSERT_ANALYTIC_OUTLIERS_SUMMARY_v4" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
	DECLARE duplicate CONDITION FOR SQLSTATE '23505';
	DECLARE CONDITION_COUNT INT;
  	DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

	SET FILEPATH = (
	CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
		SET CONDITION_COUNT = 0;

	SET CREATE_STMT = '
		CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
		UTCOffset           FLOAT,
		AnalyticOutlierSummaryID DECIMAL(20),
		SourceID            VARCHAR(200),
		AnomalyScore	    DECIMAL(11),
		TypeVolume          VARCHAR(5),
		TypeVulnerableObjects VARCHAR(5),
		TypeNewMessages	    VARCHAR(5),
		TypeDiffMessages	VARCHAR(5),
		TypeFails	        VARCHAR(5),
		TypeRecentHours	    VARCHAR(5),
		ServerIP	        VARCHAR(50),
		DBName              VARCHAR(255),
		DBUser              VARCHAR(255),
		IsPrivileged        VARCHAR(5),
		PeriodStart         TIMESTAMP,
        PeriodStartUTC      TIMESTAMP,
		ServerType          VARCHAR(30),
		DatetimeCodeID      VARCHAR(10),
		ClientIP            VARCHAR(50),
		DiffMessagesScore   DOUBLE ,
		DiffMessagesSWAve   DOUBLE ,
		FailsScore          DOUBLE ,
		FailsSWAve          DOUBLE ,
		NewMessagesScore    DOUBLE ,
		NewMessagesSWAve    DOUBLE ,
		NumDiffMessages     DECIMAL(11),
		NumFails            DECIMAL(11),
		NumNewMessages      DECIMAL(11),
		OSUser              VARCHAR(255) ,
		RecentHoursActivityScore    DOUBLE ,
		TrainingStart               TIMESTAMP ,
		VolumeScore                 DOUBLE ,
		VulnerableObjectsAve        DOUBLE ,
		VulnerableObjectsScore      DOUBLE)
		USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
	EXECUTE IMMEDIATE CREATE_STMT;

    SET
        INSERT_STMT = 'INSERT
		INTO  "' || TNT_ID || '"."ANALYTIC_OUTLIERS_SUMMARY" ("AnalyticOutlierSummaryID","Timestamp", "PeriodStart","PeriodStartUTC", "ServerIP", "DBUser", "DBName", "AnomalyScore", "SourceID", "RarityAndVolumeScore", "TempObjectScore", "TempObjectAve", "TempObjectSD", "TempSourceProgramsScore", "NumTempSourcePrograms", "TempSourceProgramsAve", "TempSourceProgramsSD", "NewMessagesScore", "NewMessagesAve", "NewMessagesSD", "NumNewMessages", "NumTempObjects", "NumSensitiveObjects", "NumFails", "TypeVolumeRarity", "TypeTempObjects", "TypeTempSourcePrograms", "TypeNewMessages", "OrigHostname", "AlertFeedbackID", "IsPrivileged", "EqIntervals", "VolumeScore", "VolumeScoreOrig", "TypeVolume", "VolumeSumLogs", "VolumeSumLogsAve", "VolumeSumLogsSD", "VolumeSumLogsAveOrig", "VolumeSumLogsSDOrig", "VolumeSumLogsMax", "TempObjectsScoreOrig", "NewMessagesScoreOrig", "NumNewMessagesSW", "NewMessagesSWAve", "NewMessagesSWSD", "DiffMessagesScore", "DiffMessagesScoreOrig", "NumDiffMessages", "NumDiffMessagesSW", "DiffMessagesSWAve", "DiffMessagesSWSD", "TypeDiffMessages", "FailsScore", "FailsScoreOrig", "NumFailsSW", "FailsSWAve", "FailsSWSD", "TypeFails", "TrainingScore", "TrainingStart", "TypeTrainingOutlier", "NumFeedbackEvents", "TypeRecentHoursActivity", "RecentHoursActivityScore", "RecentHoursActivityScoreOrig", "TypeFeedback", "RecentHoursRatioVolume", "RecentHoursRatioTempObjects", "RecentHoursRatioNewMessages", "RecentHoursRatioDiffMessages", "RecentHoursRatioFails" ,"ServerType", "ClientIP", "ClientHostname", "OSUser", "DatetimeCodeID", "SourceLinkID", "VulnerableObjectsScore", "VulnerableObjectsAve", "VulnerableObjectsSD", "NumVulnerableObjects", "TypeVulnerableObjects", "VulnerableObjectsScoreOrig","UTCOffset","GlobalID")
		SELECT
			AnalyticOutlierSummaryID,
			CURRENT TIMESTAMP,
			PeriodStart,
            PeriodStartUTC,
			ServerIP,
			DBUser,
			DBName,
			AnomalyScore,
			SourceID,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			NewMessagesScore,
			0,
			0,
			NumNewMessages,
			NULL,
			NULL,
			NumFails,
			NULL,
			NULL,
			NULL,
			TypeNewMessages,
			NULL,
			0,
			IsPrivileged,
			0,
			VolumeScore,
			0,
			TypeVolume,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			NULL,
			NewMessagesSWAve,
			0,
			DiffMessagesScore,
			0,
			NumDiffMessages,
			NULL,
			DiffMessagesSWAve,
			0,
			TypeDiffMessages,
			FailsScore,
			0,
			NULL,
			FailsSWAve,
			0,
			TypeFails,
			0,
			TrainingStart,
			NULL,
			NULL,
			TypeRecentHours,
			RecentHoursActivityScore,
			0,
			NULL,
			0,
			0,
			0,
			0,
			0,
			ServerType,
			ClientIP,
			NULL,
			OSUser,
			DatetimeCodeID,
			NULL,
			VulnerableObjectsScore,
			VulnerableObjectsAve,
			0,
			NULL,
			TypeVulnerableObjects,
			0,
            UTCOffset,
			''' || GLOBALID || '''
		FROM "' || TNT_ID || '"."' || TABLENAME || '";';
	EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

	SET INSERT_STMT = 'INSERT
		INTO  "' || TNT_ID || '"."ANALYTIC_OUTLIERS_SUMMARY" ("AnalyticOutlierSummaryID","Timestamp", "PeriodStart","PeriodStartUTC", "ServerIP", "DBUser", "DBName", "AnomalyScore", "SourceID", "RarityAndVolumeScore", "TempObjectScore", "TempObjectAve", "TempObjectSD", "TempSourceProgramsScore", "NumTempSourcePrograms", "TempSourceProgramsAve", "TempSourceProgramsSD", "NewMessagesScore", "NewMessagesAve", "NewMessagesSD", "NumNewMessages", "NumTempObjects", "NumSensitiveObjects", "NumFails", "TypeVolumeRarity", "TypeTempObjects", "TypeTempSourcePrograms", "TypeNewMessages", "OrigHostname", "AlertFeedbackID", "IsPrivileged", "EqIntervals", "VolumeScore", "VolumeScoreOrig", "TypeVolume", "VolumeSumLogs", "VolumeSumLogsAve", "VolumeSumLogsSD", "VolumeSumLogsAveOrig", "VolumeSumLogsSDOrig", "VolumeSumLogsMax", "TempObjectsScoreOrig", "NewMessagesScoreOrig", "NumNewMessagesSW", "NewMessagesSWAve", "NewMessagesSWSD", "DiffMessagesScore", "DiffMessagesScoreOrig", "NumDiffMessages", "NumDiffMessagesSW", "DiffMessagesSWAve", "DiffMessagesSWSD", "TypeDiffMessages", "FailsScore", "FailsScoreOrig", "NumFailsSW", "FailsSWAve", "FailsSWSD", "TypeFails", "TrainingScore", "TrainingStart", "TypeTrainingOutlier", "NumFeedbackEvents", "TypeRecentHoursActivity", "RecentHoursActivityScore", "RecentHoursActivityScoreOrig", "TypeFeedback", "RecentHoursRatioVolume", "RecentHoursRatioTempObjects", "RecentHoursRatioNewMessages", "RecentHoursRatioDiffMessages", "RecentHoursRatioFails" ,"ServerType", "ClientIP", "ClientHostname", "OSUser", "DatetimeCodeID", "SourceLinkID", "VulnerableObjectsScore", "VulnerableObjectsAve", "VulnerableObjectsSD", "NumVulnerableObjects", "TypeVulnerableObjects", "VulnerableObjectsScoreOrig","UTCOffset","GlobalID")
		SELECT
			AnalyticOutlierSummaryID,
			CURRENT TIMESTAMP,
			PeriodStart,
            PeriodStartUTC,
			ServerIP,
			DBUser,
			DBName,
			AnomalyScore,
			SourceID,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			NewMessagesScore,
			0,
			0,
			NumNewMessages,
			NULL,
			NULL,
			NumFails,
			NULL,
			NULL,
			NULL,
			TypeNewMessages,
			NULL,
			0,
			IsPrivileged,
			0,
			VolumeScore,
			0,
			TypeVolume,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			NULL,
			0,
			0,
			DiffMessagesScore,
			0,
			NumDiffMessages,
			NULL,
			DiffMessagesSWAve,
			0,
			TypeDiffMessages,
			FailsScore,
			0,
			NULL,
			FailsSWAve,
			0,
			TypeFails,
			0,
			TrainingStart,
			NULL,
			NULL,
			TypeRecentHours,
			RecentHoursActivityScore,
			0,
			NULL,
			0,
			0,
			0,
			0,
			0,
			ServerType,
			ClientIP,
			NULL,
			OSUser,
			DatetimeCodeID,
			NULL,
			VulnerableObjectsScore,
			VulnerableObjectsAve,
			0,
			NULL,
			TypeVulnerableObjects,
			0,
            UTCOffset,
			''' || GLOBALID || '''
		FROM "' || TNT_ID || '"."' || TABLENAME || '" Ext
		WHERE NOT EXISTS ( SELECT "AnalyticOutlierSummaryID","GlobalID" FROM "'||TNT_ID||'"."ANALYTIC_OUTLIERS_SUMMARY" mt WHERE mt."AnalyticOutlierSummaryID" = Ext.AnalyticOutlierSummaryID AND mt."GlobalID" = '''||GLOBALID||'''
		);';
	EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

	SET INSERT_STMT = 'INSERT
		INTO  "' || TNT_ID || '"."ANALYTIC_OUTLIERS_SUMMARY" ("AnalyticOutlierSummaryID","Timestamp", "PeriodStart","PeriodStartUTC", "ServerIP", "DBUser", "DBName", "AnomalyScore", "SourceID", "RarityAndVolumeScore", "TempObjectScore", "TempObjectAve", "TempObjectSD", "TempSourceProgramsScore", "NumTempSourcePrograms", "TempSourceProgramsAve", "TempSourceProgramsSD", "NewMessagesScore", "NewMessagesAve", "NewMessagesSD", "NumNewMessages", "NumTempObjects", "NumSensitiveObjects", "NumFails", "TypeVolumeRarity", "TypeTempObjects", "TypeTempSourcePrograms", "TypeNewMessages", "OrigHostname", "AlertFeedbackID", "IsPrivileged", "EqIntervals", "VolumeScore", "VolumeScoreOrig", "TypeVolume", "VolumeSumLogs", "VolumeSumLogsAve", "VolumeSumLogsSD", "VolumeSumLogsAveOrig", "VolumeSumLogsSDOrig", "VolumeSumLogsMax", "TempObjectsScoreOrig", "NewMessagesScoreOrig", "NumNewMessagesSW", "NewMessagesSWAve", "NewMessagesSWSD", "DiffMessagesScore", "DiffMessagesScoreOrig", "NumDiffMessages", "NumDiffMessagesSW", "DiffMessagesSWAve", "DiffMessagesSWSD", "TypeDiffMessages", "FailsScore", "FailsScoreOrig", "NumFailsSW", "FailsSWAve", "FailsSWSD", "TypeFails", "TrainingScore", "TrainingStart", "TypeTrainingOutlier", "NumFeedbackEvents", "TypeRecentHoursActivity", "RecentHoursActivityScore", "RecentHoursActivityScoreOrig", "TypeFeedback", "RecentHoursRatioVolume", "RecentHoursRatioTempObjects", "RecentHoursRatioNewMessages", "RecentHoursRatioDiffMessages", "RecentHoursRatioFails" ,"ServerType", "ClientIP", "ClientHostname", "OSUser", "DatetimeCodeID", "SourceLinkID", "VulnerableObjectsScore", "VulnerableObjectsAve", "VulnerableObjectsSD", "NumVulnerableObjects", "TypeVulnerableObjects", "VulnerableObjectsScoreOrig","UTCOffset","GlobalID")
		SELECT DISTINCT
			AnalyticOutlierSummaryID,
			CURRENT TIMESTAMP,
			PeriodStart,
            PeriodStartUTC,
			ServerIP,
			DBUser,
			DBName,
			AnomalyScore,
			SourceID,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			NewMessagesScore,
			0,
			0,
			NumNewMessages,
			NULL,
			NULL,
			NumFails,
			NULL,
			NULL,
			NULL,
			TypeNewMessages,
			NULL,
			0,
			IsPrivileged,
			0,
			VolumeScore,
			0,
			TypeVolume,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			NULL,
			0,
			0,
			DiffMessagesScore,
			0,
			NumDiffMessages,
			NULL,
			DiffMessagesSWAve,
			0,
			TypeDiffMessages,
			FailsScore,
			0,
			NULL,
			FailsSWAve,
			0,
			TypeFails,
			0,
			TrainingStart,
			NULL,
			NULL,
			TypeRecentHours,
			RecentHoursActivityScore,
			0,
			NULL,
			0,
			0,
			0,
			0,
			0,
			ServerType,
			ClientIP,
			NULL,
			OSUser,
			DatetimeCodeID,
			NULL,
			VulnerableObjectsScore,
			VulnerableObjectsAve,
			0,
			NULL,
			TypeVulnerableObjects,
			0,
            UTCOffset,
			''' || GLOBALID || '''
		FROM "' || TNT_ID || '"."' || TABLENAME || '" Ext
		WHERE NOT EXISTS ( SELECT "AnalyticOutlierSummaryID","GlobalID" FROM "'||TNT_ID||'"."ANALYTIC_OUTLIERS_SUMMARY" mt WHERE mt."AnalyticOutlierSummaryID" = Ext.AnalyticOutlierSummaryID AND mt."GlobalID" = '''||GLOBALID||'''
		);';
	EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

exit:
  SET ROWCOUNT = AFFECTED_ROWS;
END S1
