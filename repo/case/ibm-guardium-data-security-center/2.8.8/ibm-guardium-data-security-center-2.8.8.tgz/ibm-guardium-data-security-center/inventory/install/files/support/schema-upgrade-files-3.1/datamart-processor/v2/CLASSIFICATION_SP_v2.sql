-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."INSERT_CLASSIFICATION_v2" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
)
LANGUAGE SQL
S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

    SET FILEPATH = (CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));

    -- CREATE AN EXTERNAL TABLE FOR THE CSV
    SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
    UTCOffset FLOAT,
    DataSourceID DECIMAL(20),
    DataSourceName VARCHAR(255),
    DataSourceType VARCHAR(50),
    DataSourceIP VARCHAR(255),
    ServiceName VARCHAR(255),
    DBName VARCHAR(255),
    Port DECIMAL(11),
    ProcessDescription VARCHAR(255),
    Catalog VARCHAR(255),
    Schema VARCHAR(255),
    TableName VARCHAR(255),
    ColumnName VARCHAR(255),
    RuleDescription VARCHAR(255),
    ClassificationName VARCHAR(255),
    Category VARCHAR(255),
    StartDateTime TIMESTAMP,
    StartDateTimeUTC TIMESTAMP,
    Comprehensive VARCHAR(50),
    ResultDataRowID DECIMAL(20),
    Comments VARCHAR(32000))
    USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
    PREPARE STMT_1 FROM CREATE_STMT;
    EXECUTE STMT_1;


    SET INSERT_STMT = '
    INSERT INTO  "'||TNT_ID||'"."CLASSIFICATION" ("MessageType", "UTCOffset", "DataSourceID", "DataSourceName", "DataSourceType", "DataSourceIP", "ServiceName", "DBName", "Port", "ProcessDescription", "Catalog", "Schema", "TableName", "ColumnName", "RuleDescription", "ClassificationName", "Category", "StartDateTime", "StartDateTimeUTC", "Comprehensive", "Comments", "ConfigID", "GlobalID", "ResultDataRowID")

	SELECT
        ''CLASSIFICATION'',
        UTCOffset,
        DataSourceID,
        DataSourceName,
        DataSourceType,
        DataSourceIP,
        ServiceName,
        DBName,
        Port,
        ProcessDescription,
        Catalog,
        Schema,
        TableName,
        ColumnName,
        RuleDescription,
        ClassificationName,
        Category,
        StartDateTime,
        StartDateTimeUTC,
        Comprehensive,
        Comments,
        ''0'',
        '''||GLOBALID||''',
        ResultDataRowID
    FROM
        "'||TNT_ID||'"."'||TABLENAME||'";';
    PREPARE STMT_2 FROM INSERT_STMT;
    EXECUTE STMT_2;
    END S1
