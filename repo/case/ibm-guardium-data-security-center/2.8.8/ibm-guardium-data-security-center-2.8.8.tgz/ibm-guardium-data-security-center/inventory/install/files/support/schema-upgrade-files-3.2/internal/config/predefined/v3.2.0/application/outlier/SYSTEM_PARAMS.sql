-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************


CREATE TABLE "MY_TENANT_SCHEMA"."SYSTEM_PARAMS"  (
        "DELIVERY_DATE" TIMESTAMP ,
        "DELIVERY_VERSION" VARCHAR(50 OCTETS) NOT NULL ,
        "GIT_REVISION" VARCHAR(50 OCTETS) NOT NULL ,
        "GIT_DATE" TIMESTAMP ,
        "TRAINING_START" TIMESTAMP ,
        "TRAINING_DAYS" BIGINT NOT NULL ,
        "MIN_DAYS_FOR_ALERTS" INTEGER NOT NULL WITH DEFAULT 7 )
ORGANIZE BY ROW
IN OUT4_<TENANT_SHORT_ID>
INDEX IN IGEN4_<TENANT_SHORT_ID>;
