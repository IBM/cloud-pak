-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- The source code for this program is not published or otherwise
-- divested of its trade secrets, irrespective of what has been
-- deposited with the U.S. Copyright Office.
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."SEC_INSERT_EXCEPTION_v3" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000)
  )
LANGUAGE SQL
  S1:BEGIN
	-- GLOBAL TABLE NAME PARAMETERS
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(8192)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(255)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100)
        ,Db2IZDatabase                              VARCHAR(240)
        ,Db2ICurrentUser                            VARCHAR(240)
        ,Db2IZProgram                               VARCHAR(240))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1)';
  PREPARE STMT_1 FROM CREATE_STMT;
  EXECUTE STMT_1;


SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
	  SELECT ''EXCEPTION'',
NULL,
ExceptionTypeID,
ExceptionID,
UserName,
SourceAddress,
DestinationAddress,
DatabaseProtocol,
AppUserName,
ExceptionDescription,
SQLstringthatcausedtheException,
DatabaseErrorText,
ErrorCode,
ExceptionTimestamp,
ExceptionTimestampUTC,
CASE WHEN (SessionId IS NULL) THEN 0 ELSE SessionId END,
Linktomoreinformationabouttheexception,
UTCOffset,
NULL,
NULL,
''0'',
'''||GLOBALID||''',
Db2IZDatabase,
Db2ICurrentUser,
Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
WHERE NOT EXISTS (
Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
);';
  PREPARE STMT_2 FROM INSERT_STMT;
  EXECUTE STMT_2;
  END S1
