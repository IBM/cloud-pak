#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################
####################################################################################################################################################################################
#                                                            LOG UTILS
####################################################################################################################################################################################

function info_msg() {
  if [[ -z "${LOG_FILE}" ]]; then
    echo -e "$(date) INFO: $1"
  else
    echo -e "$(date) INFO: $1" 2>&1 | tee -a ${LOG_FILE}
  fi
}

function info_msgn() {
    echo -e "$(date) INFO: $1"
}

function error_msg() {
    echo -e "$(date) ERROR: $1"
}

function warn_msg() {
    echo -e "$(date) WARN: $1"
}

function info_file() {
  if [[ -f $1 ]]; then
    echo -e "$(date) WARN: $1"
    cat $1
  else
    echo -e "$(date) ERROR: file $1 does not exist"
  fi
}


function gi_exit() {
  [[ ! -z "${SYS_DEBUG}" ]] && tail -f /dev/null
  exit $1
}

function print_line(){
  for i in {1..60}; do
        printf "*"
  done
  printf "\n"
}
