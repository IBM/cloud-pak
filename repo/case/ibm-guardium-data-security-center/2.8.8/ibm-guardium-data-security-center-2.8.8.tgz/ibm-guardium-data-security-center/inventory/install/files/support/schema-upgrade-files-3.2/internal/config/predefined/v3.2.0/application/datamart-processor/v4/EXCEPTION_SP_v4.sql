-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."INSERT_EXCEPTION_v4" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
  DECLARE duplicate CONDITION FOR SQLSTATE '23505';
	DECLARE CONDITION_COUNT INT;
  DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

  SET FILEPATH = (
  CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
  	SET CONDITION_COUNT = 0;

  SET CREATE_STMT = '
	CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
        UTCOffset                                   DOUBLE
        ,ExceptionID                                VARCHAR(20)
        ,SessionId									VARCHAR(20)
        ,UserName									VARCHAR(255)
        ,SourceAddress								VARCHAR(255)
        ,DestinationAddress							VARCHAR(255)
        ,DatabaseProtocol							VARCHAR(20)
        ,ExceptionTimestamp							TIMESTAMP
        ,ExceptionTimestampUTC                      TIMESTAMP
        ,ExceptionDescription						VARCHAR(255)
        ,Linktomoreinformationabouttheexception		VARCHAR(255)
        ,SQLstringthatcausedtheException			VARCHAR(8192)
        ,ExceptionTypeID							VARCHAR(64)
        ,DatabaseErrorText							VARCHAR(255)
        ,AppUserName								VARCHAR(240)
        ,ErrorCode									VARCHAR(100)
        ,Db2IZDatabase                              VARCHAR(240)
        ,Db2ICurrentUser                            VARCHAR(240)
        ,Db2IZProgram                               VARCHAR(240))
	USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE LFinString TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
  EXECUTE IMMEDIATE CREATE_STMT;

  SET INSERT_STMT = 'INSERT
      INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
      SELECT ''EXCEPTION'',
          NULL,
          ExceptionTypeID,
          ExceptionID,
          UserName,
          SourceAddress,
          DestinationAddress,
          DatabaseProtocol,
          AppUserName,
          ExceptionDescription,
          SQLstringthatcausedtheException,
          DatabaseErrorText,
          ErrorCode,
          ExceptionTimestamp,
          ExceptionTimestampUTC,
          CASE WHEN (SessionId IS NULL) THEN 0 ELSE SessionId END,
          Linktomoreinformationabouttheexception,
          UTCOffset,
          NULL,
          NULL,
          ''0'',
          '''||GLOBALID||''',
          Db2IZDatabase,
          Db2ICurrentUser,
          Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'";';
  EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
	  SELECT ''EXCEPTION'',
      NULL,
      ExceptionTypeID,
      ExceptionID,
      UserName,
      SourceAddress,
      DestinationAddress,
      DatabaseProtocol,
      AppUserName,
      ExceptionDescription,
      SQLstringthatcausedtheException,
      DatabaseErrorText,
      ErrorCode,
      ExceptionTimestamp,
      ExceptionTimestampUTC,
      CASE WHEN (SessionId IS NULL) THEN 0 ELSE SessionId END,
      Linktomoreinformationabouttheexception,
      UTCOffset,
      NULL,
      NULL,
      ''0'',
      '''||GLOBALID||''',
      Db2IZDatabase,
      Db2ICurrentUser,
      Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
      Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
  EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT; 
	
    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

  SET INSERT_STMT = 'INSERT
	  INTO  "'||TNT_ID||'"."EXCEPTION" ("MessageType","ID","ExceptionTypeID","ExceptionID","UserName","SourceAddress","DestinationAddress","DBProtocol","AppUserName","ExceptionDescription","SQLStatement","ErrorCause","ErrorCode","Timestamp","TimestampUTC","SessionID","InformationLink","UTCOffset","Count","SourceID","ConfigID","GlobalID","Db2IZDatabase","Db2ICurrentUser","Db2IZProgram")
	  SELECT DISTINCT ''EXCEPTION'',
      NULL,
      ExceptionTypeID,
      ExceptionID,
      UserName,
      SourceAddress,
      DestinationAddress,
      DatabaseProtocol,
      AppUserName,
      ExceptionDescription,
      SQLstringthatcausedtheException,
      DatabaseErrorText,
      ErrorCode,
      ExceptionTimestamp,
      ExceptionTimestampUTC,
      CASE WHEN (SessionId IS NULL) THEN 0 ELSE SessionId END,
      Linktomoreinformationabouttheexception,
      UTCOffset,
      NULL,
      NULL,
      ''0'',
      '''||GLOBALID||''',
      Db2IZDatabase,
      Db2ICurrentUser,
      Db2IZProgram FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
    WHERE NOT EXISTS (
      Select "ExceptionID","ConfigID","GlobalID" from "'||TNT_ID||'"."EXCEPTION" mt where mt."ExceptionID" = Ext.ExceptionID AND mt."ConfigID" = ''0'' AND mt."GlobalID" = '''||GLOBALID||'''
    );';
  EXECUTE IMMEDIATE INSERT_STMT;

  GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

exit:
  SET ROWCOUNT = AFFECTED_ROWS; 
END S1
