#!/bin/bash

# **************************************************************
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2020. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
# **************************************************************
host=$1
user=$2
password=$3
tenantId=$4

if [[ $# -ne 4 ]]; then
    echo "Usage: ./delete_tenant.sh <hostname> <admin user id> <admin password> <tenant id>"
    exit 2
fi

jwt=$(./get_jwt.sh ${host} ${user} ${password} ${tenantId})

curl -k -X DELETE "https://${host}/api/v3/tenants/${tenantId}?is_permanent_delete=true" -H "accept: application/json" -H "authorization: ${jwt}" -H "Content-Type: application/json"