INSERT INTO "MY_TENANT_SCHEMA"."NESTED_GROUP_MEMBER_PREDEFINED"("GROUP_ID", "GROUP_MEMBER") 
with predef(group_id, group_member) as (
  VALUES 
  (9, 12), 
  (10, 11),
  (15, 16),
  (17, 18),
  (19, 2),
  (19, 13)
)
SELECT group_id, group_member FROM predef
WHERE NOT EXISTS (
  SELECT 1 FROM "MY_TENANT_SCHEMA"."NESTED_GROUP_MEMBER_PREDEFINED" t
  WHERE (t."GROUP_ID", t."GROUP_MEMBER") = (predef.group_id, predef.group_member)
);
