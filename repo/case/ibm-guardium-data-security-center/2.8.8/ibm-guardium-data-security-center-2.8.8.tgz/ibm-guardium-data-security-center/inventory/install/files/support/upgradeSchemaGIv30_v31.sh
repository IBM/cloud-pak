#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2021, 2023. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeSchemaGIv30_v31.sh
#
# DESCRIPTION:   DB2 Synchronization script for Guardium Insights v3.0 to v3.1
#
# USAGE:         This script takes no arguments and will update the BLUDB DB2
#                databse from GI v3.0 schema to GI version v3.1. It should be
#                run only once on a database that is configured with GI v3.0.x
#
# PREREQUISITES: This script should be run on a BLUDB database at GI v3.0 level.
#                Please ensure there is enough space available **TODO how much and where **
#
#----------------------------------------------------------------------------

# defaults
DBNAME=bludb
WV_DIR=/mnt/blumeta0/wolverine
DFT_ARCH_LOG_LOC=/mnt/bludata0/db2/archive_log/
TMP_TBSP_SUFFIX="V31"
SQL_DIR=$(cd $(dirname $0); pwd;)/schema-upgrade-files-3.1

function log() {
  echo "[$1] $2"
}

function info() {
  log "INFO" "$1"
}

function err() {
  log "ERROR" "$1"
}

function debug() {
  [[ -n "$DEBUG" ]] && log "DEBUG" "$1"
}

function updateInstanceCfg() {
  info "Updating instance configuration"
  db2 -v update dbm cfg using FCM_BUFFER_SIZE 65536
  local RC=$?
  if [[ $RC -gt 2 ]]; then
    err "Failed to update DBM config"
    return $RC
  fi
}

function updateDatabaseCfg() {
  info "Updating database configuration"
  db2 -v update db cfg for $DBNAME using LOGBUFSZ 12000
  local RC=$?
  if [[ $RC -gt 2 ]]; then
    err "Failed to update DB config"
    return $RC
  fi
}

function setArchiveLogging() {
  local CFG
  local RC
  info "Setting up archive logging"
  if db2 get db cfg for $DBNAME | grep LOGARCHMETH1 | grep -q DISK ; then
    info "Already set"
    return
  fi
  # Disable HA automation and TCP/IP connectivity to avoid interference
  # then take an offline backup then re-enable stuff.
  # We are assuming that the backup has been already done prior to the upgrade,
  # so we send the backup to /dev/null to avoid wasting space.
  env WV_DIR=$WV_DIR wvcli system disable && \
  db2 -v update db cfg for $DBNAME using AUTO_DEL_REC_OBJ OFF IMMEDIATE || [[ $? -le 2 ]] && \
  db2 -v update db cfg for $DBNAME using LOGARCHMETH1 DISK:$DFT_ARCH_LOG_LOC || [[ $? -le 2 ]] && \
  db2set -null DB2COMM && \
  db2stop force && db2start && \
  db2 -v backup db $DBNAME on all dbpartitionnums to /dev/null && \
  db2set DB2COMM=TCPIP,SSL && \
  db2stop force && db2start && \
  db2 -v update db cfg for $DBNAME using AUTO_DEL_REC_OBJ ON IMMEDIATE || [[ $? -le 2 ]] && \
  env WV_DIR=$WV_DIR wvcli system enable

  RC=$?

  if [[ $RC -ne 0 ]]; then
    err "Failed to enable archive logging"
    return $RC
  fi

  # validate
  CFG=$(db2 get db cfg for $DBNAME)
  if ! echo "$CFG" | grep -qE 'LOGARCHMETH1[^=]+=\s*DISK' ; then
    err "Failed to set LOGARCHMETH1"
    return 1
  fi
  if ! echo "$CFG" | grep -qE 'Backup pending\s+=\s*NO' ; then
    err "Backup pending; failed to enable archive logging"
    return 1
  fi

  return
}

function createPartnGroup() {
  local DBPG_TIME
  local RC
  info "Creating partition group 'SINGLEPRTNGROUP'"
  DBPG_TIME=$(db2 -x "select CREATE_TIME from syscat.dbpartitiongroups where DBPGNAME = 'SINGLEPRTNGROUP'")
  RC=$?
  debug "Querying partition groups; RC=$RC"
  if [[ $RC -ge 4 ]]; then
    err "Failed to query database catalog"
    return $RC
  fi

  if [[ $RC -eq 0 ]] ; then
    info "'SINGLEPRTNGROUP' already exists, created on $DBPG_TIME"
  else
    db2 -v "CREATE DATABASE PARTITION GROUP SINGLEPRTNGROUP ON DBPARTITIONNUMS (0)"
  fi
  return $?
}

# This function will determine existing tenant IDs, create new tablespaces
# for each tenant, move affected tables, drop old tablespaces, then
# rename the new ones to match current names. This is necessary for the
# tablespaces that move to a different partition group
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateTablespaces() {
  local UPD_TBSP_LIST="IGEN4 IGEN8 GRP4 OUT4 OUT8 OUT32 GEN4 SENT OBJ"
  local TNT_SCHEMA="$1"
  local TNT_SHORT_ID="$2"
  info "Updating tablespaces for tenant ${TNT_SHORT_ID}"

  createNewTablespaces "${TNT_SHORT_ID}" && \
  createTmpTablespaces "${TNT_SHORT_ID}" && \
  moveTables "${TNT_SHORT_ID}" "${UPD_TBSP_LIST}" && \
  dropMovedTablespaces "${TNT_SHORT_ID}" "${UPD_TBSP_LIST}" && \
  renameTmpTablespaces "${TNT_SHORT_ID}" "${UPD_TBSP_LIST}" && \
  db2 -v "alter tablespace LG32_${TNT_SHORT_ID} file system caching"
  local RC=$?
  if [[ $RC -ne 0 ]]; then
    err "Error while updating tablespaces for tenant ${TNT_SHORT_ID}"
    return $RC
  fi
}

# Create target tablespaces to move data from the existing ones
# IGEN4 IGEN8 GRP4 OUT4 OUT8 OUT32 GEN4 SENT OBJ
function createTmpTablespaces() {
  db2 -v "CREATE TABLESPACE IGEN4_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4" && \
  db2 -v "CREATE TABLESPACE IGEN8_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 8K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_8" && \
  db2 -v "CREATE TABLESPACE GRP4_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4" && \
  db2 -v "CREATE TABLESPACE OUT4_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4" && \
  db2 -v "CREATE TABLESPACE OUT8_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 8K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_8" && \
  db2 -v "CREATE TABLESPACE OUT32_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32" && \
  db2 -v "CREATE TABLESPACE GEN4_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 4K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_4" && \
  db2 -v "CREATE TABLESPACE SENT_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32" && \
  db2 -v "CREATE TABLESPACE OBJ_${TMP_TBSP_SUFFIX} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32"
  return $?
}

# Create tablespaces not present in 3.0
# $1 - Tenant short ID
function createNewTablespaces() {
  local TNT_SHORT=$1
  local RC
  createIfNotExists "CREATE TABLESPACE TPEVE_${TNT_SHORT} PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32"  && \
  createIfNotExists "CREATE TABLESPACE LSNG_${TNT_SHORT} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32 FILE SYSTEM CACHING"  && \
  createIfNotExists "CREATE TABLESPACE CUSTOM_${TNT_SHORT} IN DATABASE PARTITION GROUP SINGLEPRTNGROUP PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BP_32 MAXSIZE 4G"  && \
  db2 commit
  RC=$?
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Error while creating new tablespaces for tenant ${TNT_SHORT_ID}"
    return $RC
  fi
}

# Execute the provided statement and ignore errors where the object already exists.
# Autocommit is off
# $1 -- statement to run (assume a connection already exists)
function createIfNotExists() {
  [[ -z "$1" ]] && return
  local RC
  local OUT
  local STMT="$1"
  info "Executing [${STMT}]"
  OUT=$(db2 +c "${STMT}")
  RC=$?
  [[ $RC -lt 2 ]] && return # OK
  [[ "$OUT" =~ SQL0601N ]] && info "Object already exists" && return # OK (The name of the object to be created is identical...)
  [[ "$OUT" =~ SQL0624N ]] && info "Constraint already exists" && return # OK (already has a primary key or unique constraint...)
  return $RC # error
}

# Move to the temp tablespaces the tables for which tablespaces have
# been re-created
# $1 - Tenant short ID
# $2 - List of tablespace prefixes
function moveTables() {
  local TBL_LIST
  local RC
  local TNT_SHORT="$1"
  local PREEFIX_LIST="$2"
  # compile a VALUES statement from the list of prefixes
  local VALS
  for PFX in $PREEFIX_LIST; do VALS="$VALS('$PFX'),"; done;
  VALS=${VALS%,}
  # enumerate modified tablespaces; all tables that depend on them will be moved
  local Q="with tmp (tabschema, tabname, data_tbsp, idx_tbsp, lob_tbsp, size_gb) as (
    select distinct t.tabschema, t.tabname, t.tbspace, t.index_tbspace, t.long_tbspace,
    case when t.fpages>0 then t.fpages else 0 end + case when t.mpages>0 then t.mpages else 0 end * ts.pagesize / 1024 / 1024
    from syscat.tables t inner join syscat.tablespaces ts
      on t.tbspace = ts.tbspace
    inner join (values ${VALS}) as v(pfx)
      on  t.tbspace = v.pfx||'_${TNT_SHORT}' or t.index_tbspace = v.pfx||'_${TNT_SHORT}'  or t.long_tbspace = v.pfx||'_${TNT_SHORT}'
    where t.type = 'T' and t.ownertype = 'U'
    ) select tabschema, tabname, data_tbsp, coalesce(idx_tbsp, data_tbsp), coalesce(lob_tbsp, data_tbsp),
    size_gb, sum(size_gb) over () as size_gb_total from tmp"

  TBL_LIST=$(db2 -x "$Q")
  RC=$?
  if [[ $RC -gt 1 ]]; then
    err "Cannot obtain list of tables to move"
    return $RC
  fi
  if [[ $RC -eq 0 ]]; then
    local DONE_SZ=0
    debug "in tbsp prefix loop, shell level $SHLVL"
    echo "$TBL_LIST" | while read TSCHEMA TNAME DATA_TS IDX_TS LOB_TS TSZ ALLSZ; do
      info "Processing $TNAME ($TSZ Gib)"
      debug "in table loop, shell level $SHLVL"
      # if any of the table's tablespaces is on the affected list, target will be
      # the corresponding temp tablespace, otherwise leave intact
      if [[ "$PREEFIX_LIST" =~ ${DATA_TS%%_*} ]]; then DATA_TS="${DATA_TS%%_*}_${TMP_TBSP_SUFFIX}"; fi
      if [[ "$PREEFIX_LIST" =~ ${IDX_TS%%_*} ]]; then
        IDX_TS="${IDX_TS%%_*}_${TMP_TBSP_SUFFIX}";
      elif [[ ${IDX_TS%%_*} = "IRPT8" ]]; then ## OBJECT and SENTENCE -- special case
        IDX_TS="IGEN8_${TMP_TBSP_SUFFIX}"
      else
        IDX_TS="${DATA_TS}";
      fi
      if [[ "$PREEFIX_LIST" =~ ${LOB_TS%%_*} ]]; then LOB_TS="${LOB_TS%%_*}_${TMP_TBSP_SUFFIX}"; else LOB_TS="LSNG_${TNT_SHORT}"; fi
      db2 connect to $DBNAME && \
      db2 -v "call sysproc.admin_move_table('$TSCHEMA', '$TNAME', '$DATA_TS', '$IDX_TS', '$LOB_TS', '', '', '', '',  'ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE')" && \
      db2 -v "select 1 from systools.admin_move_table where tabschema = '$TSCHEMA' and tabname = '$TNAME' and key = 'STATUS' and value = 'COMPLETE'"
      RC=$?
      debug "after move and select RC =  $RC"
      if [[ $RC -ne 0 ]]; then
        err "Failed to move table '$TSCHEMA'.'$TNAME'"
        return $RC
      fi
      info "Completed  '$TSCHEMA'.'$TNAME' ($DONE_SZ of $ALLSZ Gib)"
    done # one tablespace
    info "Completed processing tenant ${TNT_SHORT}"
  else
    info "No tables to move"
  fi
}

# Drop tablespaces from which tables have been moved
# IGEN4 IGEN8 GRP4 OUT4 OUT8 OUT32 GEN4 SENT OBJ
# $1 - Tenant short ID
# $2 - List of tablespace prefixes
function dropMovedTablespaces() {
  info "Dropping empty tablespaces"
  local TNT_SHORT="$1"
  local PREEFIX_LIST="$2"
  local DEP_COUNT
  local RC
  # enumerate tablespaces
  for PREFIX in $PREEFIX_LIST; do
    info "Processing ${PREFIX}_${TNT_SHORT}"
    local Q="select int(count(1)) from syscat.tables
      where tbspace = '${PREFIX}_${TNT_SHORT}'
      or index_tbspace = '${PREFIX}_${TNT_SHORT}'
      or long_tbspace = '${PREFIX}_${TNT_SHORT}' "
    DEP_COUNT=$(db2 -x "$Q")
    RC=$?

    if [[ $RC -ge 2 ]]; then
      err "Failed to verify tablespace ${PREFIX}_${TNT_SHORT} to be empty"
      return $RC
    fi

    if [[ $DEP_COUNT -ne 0 ]]; then
      err "Tablespace ${PREFIX}_${TNT_SHORT} is not empty, cannot continue"
      return 1
    fi

    db2 -v "drop tablespace ${PREFIX}_${TNT_SHORT}"
    RC=$?
    if [[ $RC -ge 4 ]]; then
      err "Error while dropping tablespace ${PREFIX}_${TNT_SHORT}"
      return $RC
    fi
    info "Dropped tablespace ${PREFIX}_${TNT_SHORT}"
  done
}

# Rename the temp tablespaces once the original ones have been dropped
# $1 - Tenant short ID
# $2 - List of tablespace prefixes
function renameTmpTablespaces() {
  info "Renaming temp tablespaces"
  local TNT_SHORT="$1"
  local PREEFIX_LIST="$2"
  local RC
  # enumerate tablespaces
  for PREFIX in $PREEFIX_LIST; do
    info "Processing ${PREFIX}_${TMP_TBSP_SUFFIX}"
    db2 -v "rename tablespace ${PREFIX}_${TMP_TBSP_SUFFIX} to ${PREFIX}_${TNT_SHORT}"
    RC=$?

    if [[ $RC -ge 4 ]]; then
      err "Failed to rename tablespace ${PREFIX}_${TMP_TBSP_SUFFIX}"
      return $RC
    fi
  done
}

# Move tables that have different existing tablespaces in v3.1: SENTENCE & OBJECT
# $1 - Tenant schema name
# $2 - Tenant short ID
# function moveMoreTables() {
#   local TNT_SCHEMA="$1"
#   local TNT_SHORT="$2"
#   db2 -v "call sysproc.admin_move_table('$TNT_SCHEMA', 'SENTENCE', 'SENT_${TNT_SHORT}', 'IGEN8_${TNT_SHORT}', NULL, '', '', '', '',  'ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE')" && \
#   db2 -v "select 1 from systools.admin_move_table where tabname = 'SENTENCE' and key = 'STATUS' and value = 'COMPLETED'" && \
#   db2 -v "call sysproc.admin_move_table('$TNT_SCHEMA', 'OBJECT', 'OBJ_${TNT_SHORT}', 'IGEN8_${TNT_SHORT}', NULL, '', '', '', '',  'ALLOW_READ_ACCESS,COPY_USE_LOAD','MOVE')" && \
#   db2 -v "select 1 from systools.admin_move_table where tabname = 'OBJECT' and key = 'STATUS' and value = 'COMPLETED'"
#   return $?
# }


# Tables that are new in 3.1
# $1 - Tenant schema name
# $2 - Tenant short ID
function createNewTables() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  createIfNotExists "$(cat <<EOF
    CREATE TABLE "${TNT_SCHEMA}"."CONNECTIONS_EVENTS"  (
          "EventID" DECIMAL(20,0) NOT NULL GENERATED ALWAYS AS IDENTITY (
            START WITH +1
            INCREMENT BY +1
            MINVALUE +1
            MAXVALUE +99999999999999999999
            NO CYCLE
            CACHE 20
            NO ORDER ) ,
          "ID" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' ,
          "HostName" VARCHAR(255 OCTETS) NOT NULL WITH DEFAULT '' ,
          "EventType" VARCHAR(20 OCTETS) NOT NULL WITH DEFAULT '' ,
          "Message" VARCHAR(1000 OCTETS) NOT NULL WITH DEFAULT '' ,
          "EventSource" VARCHAR(300 OCTETS) NOT NULL WITH DEFAULT '' ,
          "TimestampUTC" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP ,
          "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )
        DISTRIBUTE BY HASH("EventID")
          IN "TPEVE_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}"
        ORGANIZE BY COLUMN
EOF
  )" && \
  createIfNotExists "$(cat <<EOF
    ALTER TABLE "${TNT_SCHEMA}"."CONNECTIONS_EVENTS"
      ADD PRIMARY KEY
        ("EventID")
      ENFORCED
EOF
  )" && \
  createIfNotExists "$(cat <<EOF
    CREATE TABLE "${TNT_SCHEMA}"."GROUP_MEMBER_PREDEFINED"  (
            "MEMBER_ID" BIGINT NOT NULL GENERATED ALWAYS AS IDENTITY (
                START WITH +1
            INCREMENT BY +1
            MINVALUE +1
            NO MAXVALUE
            NO CYCLE
            CACHE 20
            NO ORDER ) ,
        "GROUP_ID" INTEGER NOT NULL WITH DEFAULT 0 ,
        "GROUP_MEMBER" VARCHAR(255 CODEUNITS32) NOT NULL WITH DEFAULT '' ,
        "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP,
        PRIMARY KEY ("MEMBER_ID"))
    ORGANIZE BY COLUMN
    IN GRP4_${TNT_SHORT}
    INDEX IN IGEN4_${TNT_SHORT}
EOF
  )" && \
  createIfNotExists "$(cat <<EOF
    CREATE TABLE "${TNT_SCHEMA}"."NESTED_GROUP_MEMBER_PREDEFINED"  (
            "MEMBER_ID" INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (
            START WITH +1
            INCREMENT BY +1
            MINVALUE +1
            NO MAXVALUE
            NO CYCLE
            CACHE 20
            NO ORDER ) ,
          "GROUP_ID" INTEGER NOT NULL WITH DEFAULT 0 ,
          "GROUP_MEMBER" INTEGER NOT NULL WITH DEFAULT 0 ,
          "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP ,
      PRIMARY KEY ("MEMBER_ID"))
    ORGANIZE BY COLUMN
    IN GRP4_${TNT_SHORT}
    INDEX IN IGEN4_${TNT_SHORT}
EOF
  )" && \
  createIfNotExists "$(cat <<EOF
    CREATE TABLE "${TNT_SCHEMA}_CUSTOM"."ANALYTICS_ENRICHMENT"  (
          "IntegrationName" VARCHAR(256 OCTETS) ,
          "EventID" VARCHAR(50 OCTETS) ,
          "EventDate" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
          "Action" VARCHAR(256 OCTETS) ,
          "Email" VARCHAR(1024 OCTETS) ,
          "DisplayName" VARCHAR(1024 OCTETS) ,
          "IPAddress" VARCHAR(256 OCTETS) ,
          "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )
        IN "CUSTOM_${TNT_SHORT}" INDEX IN "IGEN8_${TNT_SHORT}"
        ORGANIZE BY COLUMN
EOF
  )" && \
  db2 commit
  RC=$?

  if [[ $RC -ne 0 ]]; then
    err "Creation of new tables in ${TNT_SCHEMA} failed"
    return $RC
  fi
  info "New tables in ${TNT_SCHEMA} created successfully"
}

# Group builder table and data upgrade per INS-14238
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateGroupBuilderData() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  reloadGroupTable $TNT_SCHEMA $TNT_SHORT GROUP_TYPE insert_group_type.sql GROUP_TYPE_ID 20000 && \
  reloadGroupTable $TNT_SCHEMA $TNT_SHORT GROUP_DESC insert_group_desc.sql GROUP_ID 20000 && \
  reloadGroupTable $TNT_SCHEMA $TNT_SHORT NESTED_GROUP_MEMBER insert_nested_group_member.sql MEMBER_ID 20000 && \
  reloadGroupTable $TNT_SCHEMA $TNT_SHORT GROUP_MEMBER insert_group_member.sql MEMBER_ID 1000000 && \
  reloadGroupTable $TNT_SCHEMA $TNT_SHORT GROUP_TUPLES insert_group_tuples.sql && \
  reloadGroupTable $TNT_SCHEMA $TNT_SHORT GROUP_TYPE_MAPPING insert_group_type_mapping.sql && \
  loadGroupTable $TNT_SCHEMA $TNT_SHORT GROUP_MEMBER_PREDEFINED insert_group_member_predefined.sql && \
  loadGroupTable $TNT_SCHEMA $TNT_SHORT NESTED_GROUP_MEMBER_PREDEFINED insert_nested_group_member_predefined.sql && \
  return
  # if we're here something is wrong
  local RC=$?
  if [[ $RC -ne 0 ]]; then
    err "Migration of group builder data failed"
    return $RC
  fi

}

# We cannot alter the existing table due to CDE limitations, so create a new one,
# move data, then drop and rename.
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterGroupType() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  local TABNAME=GROUP_TYPE
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
              and (colname = 'TUPLE_COUNT')")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -ne 0 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi

  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}"  (
        "GROUP_TYPE_ID" INTEGER NOT NULL GENERATED BY DEFAULT AS IDENTITY (
        START WITH +20000
        INCREMENT BY +1
        MINVALUE +1
        NO MAXVALUE
        NO CYCLE
        CACHE 20
        NO ORDER ) ,
      "NAME" VARCHAR(255 CODEUNITS32) NOT NULL,
      "ALLOW_REGEX" INTEGER NOT NULL WITH DEFAULT 0,
    "TUPLE_COUNT" INTEGER NOT NULL DEFAULT 1,
    "TUPLE_PARAMS" VARCHAR(255 CODEUNITS32),
    "TIMESTAMP" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP,
  PRIMARY KEY ("GROUP_TYPE_ID"))
ORGANIZE BY COLUMN
IN GRP4_${TNT_SHORT}
INDEX IN IGEN4_${TNT_SHORT};
INSERT INTO "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}" (
"GROUP_TYPE_ID", "NAME", "ALLOW_REGEX"
)
SELECT "GROUP_TYPE_ID", "NAME", "ALLOW_REGEX"
FROM "${TNT_SCHEMA}"."${TABNAME}"
WHERE GROUP_TYPE_ID >= 20000;
DROP TABLE "${TNT_SCHEMA}"."${TABNAME}";
RENAME TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}" TO "${TABNAME}";
COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Delete and reload predefined values into the specified table
# $1 - Tenant schema name
# $2 - Tenant short ID
# $3 - Table name
# $4 - Insert script file name
# $5 - PK column name (if not provided, all records will be deleted)
# $6 - PK value threshold to delete
function reloadGroupTable() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local TABNAME="$3"
  local INSERT_SCRIPT="$4"
  local PK_NAME="$5"
  local THRESH="$6"
  local RC
  local WHERE
  info "Reloading ${TNT_SCHEMA}.${TABNAME}"
  # set delete criteria if specified
  if [[ -n "$PK_NAME" ]]; then
    WHERE=" WHERE $PK_NAME < $THRESH"
  fi
  # run while disabling autocommit; loadGroupTable() will commit if successful
  db2 +c "delete from ${TNT_SCHEMA}.${TABNAME} $WHERE"  # this could produce a warning on an empty table
  RC=$?
  if [[ RC -ge 2 ]]; then
    db2 rollback
    err "Failed to delete predefined values from ${TNT_SCHEMA}.${TABNAME}"
    return $RC
  fi
  loadGroupTable $TNT_SCHEMA $TNT_SHORT $TABNAME $INSERT_SCRIPT && \
  info "Reload of table ${TNT_SCHEMA}.${TABNAME} successful"
  return $?
}

# Insert predefined values into the specified table
# $1 - Tenant schema name
# $2 - Tenant short ID
# $3 - Table name
# $4 - Insert script file name
function loadGroupTable() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local TABNAME="$3"
  local INSERT_SCRIPT="$4"
  local RC
  info "Inserting ${TNT_SCHEMA}.${TABNAME}"
  if ! [[ -f $SQL_DIR/$INSERT_SCRIPT ]]; then
    err "Cannot find insert script $SQL_DIR/$INSERT_SCRIPT"
    return 1
  fi
  sed 's/MY_TENANT_SCHEMA/'${TNT_SCHEMA}'/g' $SQL_DIR/$INSERT_SCRIPT | db2 +p +c -t
  RC=$?
  # We can ignore the "not found" warnings that can happen if the script runs more than once
  if [[ $RC -ge 2 ]]; then
    db2 rollback
    err "Failed to insert ${TNT_SCHEMA}.${TABNAME}"
    return $RC
  elif [[ $RC -eq 1 ]]; then
    info "No new rows to insert"
  fi
  db2 commit
  info "Insert of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Redefine tables per INS-12999
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTables() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  alterTablePolicyViolation $TNT_SCHEMA $TNT_SHORT && \
  alterTableException $TNT_SCHEMA $TNT_SHORT && \
  alterTableInstance $TNT_SCHEMA $TNT_SHORT && \
  alterTableFullSQL $TNT_SCHEMA $TNT_SHORT && \
  alterGroupType $TNT_SCHEMA $TNT_SHORT && \
  alterTableClassification $TNT_SCHEMA $TNT_SHORT && \
  alterTableVulnerabilityAssessment $TNT_SCHEMA $TNT_SHORT && \
  alterTableOverflowFields $TNT_SCHEMA $TNT_SHORT && \
  alterTableDbErrorText $TNT_SCHEMA $TNT_SHORT && \
  alterTableAnalyticLog $TNT_SCHEMA $TNT_SHORT && \
  alterTableAnalyticOutlier $TNT_SCHEMA $TNT_SHORT && \
  true
  return $?
}

# Redefine table EXCEPTION and move data (no overflow)
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableException() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.EXCEPTION"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = 'EXCEPTION'
              and ((colname = 'SQLStatement' and length > 8192) or (colname = 'ErrorCause' and length > 255))")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 0 ]]; then info "Table ${TNT_SCHEMA}.EXCEPTION already migrated" ; return; fi
  # there is no overflow for exception data, simply truncate
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."EXCEPTION_${TMP_TBSP_SUFFIX}"  (
      "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'EXCEPTION' ,
      "ID" VARCHAR(100 OCTETS) ,
      "ExceptionTypeID" VARCHAR(64 OCTETS) ,
      "ExceptionID" DECIMAL(20,0) NOT NULL ,
      "UserName" VARCHAR(255 OCTETS) ,
      "SourceAddress" VARCHAR(255 OCTETS) ,
      "DestinationAddress" VARCHAR(255 OCTETS) ,
      "DBProtocol" VARCHAR(20 OCTETS) WITH DEFAULT NULL ,
      "AppUserName" VARCHAR(240 OCTETS) ,
      "ExceptionDescription" VARCHAR(255 OCTETS) ,
      "SQLStatement" VARCHAR(8192 OCTETS) ,
      "ErrorCause" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "ErrorCode" VARCHAR(100 OCTETS) ,
      "Timestamp" TIMESTAMP ,
      "TimestampUTC" TIMESTAMP ,
      "SessionID" DECIMAL(20,0) NOT NULL WITH DEFAULT 0 ,
      "InformationLink" VARCHAR(255 OCTETS) ,
      "UTCOffset" DOUBLE ,
      "Count" DECIMAL(11,0) ,
      "SourceID" VARCHAR(50 OCTETS) WITH DEFAULT NULL ,
      "ConfigID" VARCHAR(50 OCTETS) NOT NULL ,
      "GlobalID" VARCHAR(50 OCTETS) NOT NULL ,
      "TenantID" VARCHAR(50 OCTETS) ,
      "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "Db2IZDatabase" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "Db2ICurrentUser" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "Db2IZProgram" VARCHAR(240 OCTETS) WITH DEFAULT NULL )
     DISTRIBUTE BY HASH("SessionID")
       IN "EXCEP_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."EXCEPTION_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("ExceptionID",
     "ConfigID",
     "GlobalID",
     "SessionID")
  ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."EXCEPTION_${TMP_TBSP_SUFFIX}" (
      "MessageType",
      "ID",
      "ExceptionTypeID",
      "ExceptionID",
      "UserName",
      "SourceAddress",
      "DestinationAddress",
      "DBProtocol",
      "AppUserName",
      "ExceptionDescription",
      "SQLStatement",
      "ErrorCause",
      "ErrorCode",
      "Timestamp",
      "TimestampUTC",
      "SessionID",
      "InformationLink",
      "UTCOffset",
      "Count",
      "SourceID",
      "ConfigID",
      "GlobalID",
      "TenantID",
      "IngestTimestamp",
      "Db2IZDatabase",
      "Db2ICurrentUser",
      "Db2IZProgram"
  )
  SELECT
      "MessageType",
      "ID",
      "ExceptionTypeID",
      "ExceptionID",
      "UserName",
      "SourceAddress",
      "DestinationAddress",
      "DBProtocol",
      "AppUserName",
      "ExceptionDescription",
      SUBSTR("SQLStatement",1,8192),
      SUBSTR("ErrorCause",1,255),
      "ErrorCode",
      "Timestamp",
      "TimestampUTC",
      "SessionID",
      "InformationLink",
      "UTCOffset",
      "Count",
      "SourceID",
      "ConfigID",
      "GlobalID",
      "TenantID",
      "IngestTimestamp",
      "Db2IZDatabase",
      "Db2ICurrentUser",
      "Db2IZProgram"
  FROM "${TNT_SCHEMA}"."EXCEPTION";
  DROP TABLE "${TNT_SCHEMA}"."EXCEPTION";
  RENAME TABLE "${TNT_SCHEMA}"."EXCEPTION_${TMP_TBSP_SUFFIX}" TO EXCEPTION;
  COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.EXCEPTION failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.EXCEPTION successful"
}

# Redefine table FULL_SQL and move data (including overflow)
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableFullSQL() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.FULL_SQL"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = 'FULL_SQL'
              and ((colname = 'FullStatement' and length > 8192) or (colname = 'BindVariablesValues' and length > 255))")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 0 ]]; then info "Table ${TNT_SCHEMA}.FULL_SQL already migrated" ; return; fi
  # First create overflow rows for FullStatement values larger than 8192
  # (if they don't already exist), then copy all rows into the new table
  # (BindVariablesValues is simply truncated)
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."FULL_SQL_${TMP_TBSP_SUFFIX}"  (
      "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'FULL_SQL' ,
      "ID" VARCHAR(100 OCTETS) ,
      "FullSQLID" DECIMAL(20,0) NOT NULL ,
      "SessionID" DECIMAL(20,0) NOT NULL ,
      "Timestamp" TIMESTAMP ,
      "TimestampUTC" TIMESTAMP ,
      "UTCOffset" DOUBLE ,
      "InstanceID" DECIMAL(20,0) WITH DEFAULT 0 ,
      "AccessRuleDescription" VARCHAR(100 OCTETS) ,
      "FullStatement" VARCHAR(8192 OCTETS) WITH DEFAULT NULL ,
      "TotalRecordsAffected" DECIMAL(11,0) ,
      "Succeeded" DECIMAL(11,0) WITH DEFAULT 1 ,
      "Status" DECIMAL(11,0) WITH DEFAULT 2 ,
      "ResponseTime" DECIMAL(11,0) WITH DEFAULT 0 ,
      "ACKResponseTime" DECIMAL(11,0) WITH DEFAULT 0 ,
      "ConfigID" VARCHAR(50 OCTETS) NOT NULL ,
      "GlobalID" VARCHAR(50 OCTETS) NOT NULL ,
      "TenantID" VARCHAR(50 OCTETS) ,
      "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "SQLSequenceInRequest" DECIMAL(11,0) ,
      "BindVariablesValues" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "OverflowFlagFullStatement" DECIMAL(5,0) WITH DEFAULT 0 )
     DISTRIBUTE BY HASH("SessionID")
       IN "FSQL_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."FULL_SQL_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("FullSQLID",
     "SessionID",
     "ConfigID",
     "GlobalID")
  ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."OVERFLOW_FIELDS" (
      "TableName" ,
      "ID"  ,
      "ColumnName"  ,
      "Value" ,
      "ConfigID" ,
      "GlobalID"  ,
      "IngestTimestamp"
  )
  SELECT
      'FULL_SQL',
      fs."FullSQLID",
      'FullStatement'  ,
      CLOB(fs."FullStatement")  ,
      fs."ConfigID" ,
      fs."GlobalID"  ,
      fs."IngestTimestamp"
  FROM "${TNT_SCHEMA}"."FULL_SQL" fs
  WHERE LENGTH(TRIM(fs."FullStatement"))>8192
  AND NOT EXISTS (
    SELECT 1 FROM "${TNT_SCHEMA}"."OVERFLOW_FIELDS" of
    WHERE of."TableName" = 'FULL_SQL' and of."ID" = fs."FullSQLID" and of."ColumnName" = 'FullStatement'
    AND fs."ConfigID" = of."ConfigID" AND fs."GlobalID" = of."GlobalID" AND fs."IngestTimestamp" = of."IngestTimestamp"
  );
INSERT INTO "${TNT_SCHEMA}"."FULL_SQL_${TMP_TBSP_SUFFIX}" (
      "MessageType",
      "ID",
      "FullSQLID",
      "SessionID"  ,
      "Timestamp"  ,
      "TimestampUTC"  ,
      "UTCOffset"  ,
      "InstanceID"  ,
      "AccessRuleDescription"  ,
      "FullStatement"  ,
      "TotalRecordsAffected"  ,
      "Succeeded"  ,
      "Status"  ,
      "ResponseTime"  ,
      "ACKResponseTime"  ,
      "ConfigID"  ,
      "GlobalID"  ,
      "TenantID"  ,
      "IngestTimestamp"  ,
      "SQLSequenceInRequest"  ,
      "BindVariablesValues" ,
      "OverflowFlagFullStatement"
  )
  SELECT
      fs."MessageType",
      fs."ID",
      fs."FullSQLID",
      fs."SessionID"  ,
      fs."Timestamp"  ,
      fs."TimestampUTC"  ,
      fs."UTCOffset"  ,
      fs."InstanceID"  ,
      fs."AccessRuleDescription"  ,
      SUBSTR(fs."FullStatement",1,8192)  ,
      fs."TotalRecordsAffected"  ,
      fs."Succeeded"  ,
      fs."Status"  ,
      fs."ResponseTime"  ,
      fs."ACKResponseTime"  ,
      fs."ConfigID"  ,
      fs."GlobalID"  ,
      fs."TenantID"  ,
      fs."IngestTimestamp"  ,
      fs."SQLSequenceInRequest"  ,
      SUBSTR(fs."BindVariablesValues",1,255)  ,
      CASE WHEN of."ID" IS NOT NULL THEN 1.0 ELSE 0.0 END
  FROM "${TNT_SCHEMA}"."FULL_SQL" fs
  LEFT OUTER JOIN "${TNT_SCHEMA}"."OVERFLOW_FIELDS" of
  ON fs."FullSQLID" = of."ID" AND of."ColumnName" = 'FullStatement' AND of."TableName" = 'FULL_SQL'
  AND fs."ConfigID" = of."ConfigID" AND fs."GlobalID" = of."GlobalID" AND fs."IngestTimestamp" = of."IngestTimestamp";
  DROP TABLE "${TNT_SCHEMA}"."FULL_SQL";
  RENAME TABLE "${TNT_SCHEMA}"."FULL_SQL_${TMP_TBSP_SUFFIX}" TO FULL_SQL;
  COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.FULL_SQL failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.FULL_SQL successful"
}

# Redefine table INSTANCE and move data (including overflow)
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableInstance() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.INSTANCE"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = 'INSTANCE'
              and ((colname = 'OriginalSQL' and length > 8192) or (colname = 'ApplicationEventValueStr' and length > 255)
              or (colname = 'Db2ClientInfo' and length > 1024))")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 0 ]]; then info "Table ${TNT_SCHEMA}.INSTANCE already migrated" ; return; fi
  # First create overflow rows for OriginalSQL values larger than 8192
  # (if they don't already exist), then copy all rows into the new table
  # (ApplicationEventValueStr and Db2ClientInfo are simply truncated)
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."INSTANCE_${TMP_TBSP_SUFFIX}"  (
      "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'INSTANCE' ,
      "ID" VARCHAR(100 OCTETS) ,
      "InstanceID" DECIMAL(20,0) NOT NULL ,
      "SessionID" DECIMAL(20,0) NOT NULL ,
      "UTCOffset" DOUBLE ,
      "PeriodStart" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' ,
      "PeriodStartUTC" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' ,
      "PeriodEnd" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' ,
      "PeriodEndUTC" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' ,
      "ApplicationEventID" DECIMAL(20,0) WITH DEFAULT 0 ,
      "AppUserName" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "ApplicationEventType" VARCHAR(30 OCTETS) ,
      "ApplicationEventValueStr" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "ApplicationEventValueNum" DOUBLE WITH DEFAULT NULL ,
      "ApplicationEventDate" TIMESTAMP WITH DEFAULT NULL ,
      "ApplicationEventDateUTC" TIMESTAMP WITH DEFAULT NULL ,
      "ConstructID" VARCHAR(40 OCTETS) ,
      "OriginalSQL" VARCHAR(8192 OCTETS) WITH DEFAULT NULL ,
      "ObjectsandVerbs" VARCHAR(1000 OCTETS) ,
      "SuccessfulSqls" DECIMAL(20,0) ,
      "FailedSqls" DECIMAL(20,0) WITH DEFAULT NULL ,
      "DBUserName" VARCHAR(255 OCTETS) ,
      "OSUser" VARCHAR(255 OCTETS) ,
      "SourceProgram" VARCHAR(255 OCTETS) ,
      "ServerIP" VARCHAR(50 OCTETS) ,
      "ClientID" VARCHAR(50 OCTETS) ,
      "ServiceName" VARCHAR(80 OCTETS) ,
      "ClientHostName" VARCHAR(255 OCTETS) ,
      "ServerType" VARCHAR(30 OCTETS) ,
      "DatabaseName" VARCHAR(255 OCTETS) ,
      "EventUserName" VARCHAR(240 OCTETS) ,
      "ServerPort" VARCHAR(10 OCTETS) ,
      "NetworkProtocol" VARCHAR(20 OCTETS) ,
      "TotalRecordsAffected" DECIMAL(11,0) WITH DEFAULT -1 ,
      "ServerHostName" VARCHAR(255 OCTETS) ,
      "Timestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "TimestampUTC" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "AverageExecutionTime" DECIMAL(11,0) WITH DEFAULT 1 ,
      "ConfigID" VARCHAR(50 OCTETS) NOT NULL ,
      "GlobalID" VARCHAR(50 OCTETS) NOT NULL ,
      "TenantID" VARCHAR(50 OCTETS) ,
      "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "TotalCount" DECIMAL(20,0) GENERATED ALWAYS AS (ISNULL("SuccessfulSqls", 0) + ISNULL("FailedSqls", 0)) ,
      "Db2ClientInfo" VARCHAR(1024 OCTETS) WITH DEFAULT NULL ,
      "Db2IZDatabase" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "Db2ICurrentUser" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "Db2IZProgram" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "ProcessID" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "DBProtocol" VARCHAR(20 OCTETS) WITH DEFAULT NULL ,
      "OverflowFlagOriginalSQL" DECIMAL(5,0) WITH DEFAULT 0 )
     DISTRIBUTE BY HASH("SessionID")
       IN "INST_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."INSTANCE_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("InstanceID",
     "SessionID",
     "ConfigID",
     "GlobalID")
  ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."OVERFLOW_FIELDS" (
      "TableName" ,
      "ID"  ,
      "ColumnName"  ,
      "Value" ,
      "ConfigID" ,
      "GlobalID"  ,
      "IngestTimestamp"
  )
  SELECT
      'INSTANCE',
      ins."InstanceID",
      'OriginalSQL'  ,
      CLOB(ins."OriginalSQL")  ,
      ins."ConfigID" ,
      ins."GlobalID"  ,
      ins."IngestTimestamp"
  FROM "${TNT_SCHEMA}"."INSTANCE" ins
  WHERE LENGTH(TRIM(ins."OriginalSQL"))>8192
  AND NOT EXISTS (
    SELECT 1 FROM "${TNT_SCHEMA}"."OVERFLOW_FIELDS" of
    WHERE of."TableName" = 'INSTANCE' and of."ID" = ins."InstanceID" and of."ColumnName" = 'OriginalSQL'
    AND ins."ConfigID" = of."ConfigID" AND ins."GlobalID" = of."GlobalID" AND ins."IngestTimestamp" = of."IngestTimestamp"
  );
INSERT INTO "${TNT_SCHEMA}"."INSTANCE_${TMP_TBSP_SUFFIX}" (
      "MessageType",
      "ID",
      "InstanceID",
      "SessionID",
      "UTCOffset",
      "PeriodStart",
      "PeriodStartUTC",
      "PeriodEnd",
      "PeriodEndUTC",
      "ApplicationEventID",
      "AppUserName",
      "ApplicationEventType",
      "ApplicationEventValueStr",
      "ApplicationEventValueNum",
      "ApplicationEventDate",
      "ApplicationEventDateUTC",
      "ConstructID",
      "OriginalSQL",
      "ObjectsandVerbs",
      "SuccessfulSqls",
      "FailedSqls",
      "DBUserName",
      "OSUser",
      "SourceProgram",
      "ServerIP",
      "ClientID",
      "ServiceName",
      "ClientHostName",
      "ServerType",
      "DatabaseName",
      "EventUserName",
      "ServerPort",
      "NetworkProtocol",
      "TotalRecordsAffected",
      "ServerHostName",
      "Timestamp",
      "TimestampUTC",
      "AverageExecutionTime",
      "ConfigID",
      "GlobalID",
      "TenantID",
      "IngestTimestamp",
      "Db2ClientInfo",
      "Db2IZDatabase",
      "Db2ICurrentUser",
      "Db2IZProgram",
      "ProcessID",
      "DBProtocol",
      "OverflowFlagOriginalSQL"
  )
  SELECT
      ins."MessageType",
      ins."ID",
      ins."InstanceID",
      ins."SessionID",
      ins."UTCOffset",
      ins."PeriodStart",
      ins."PeriodStartUTC",
      ins."PeriodEnd",
      ins."PeriodEndUTC",
      ins."ApplicationEventID",
      ins."AppUserName",
      ins."ApplicationEventType",
      SUBSTR(ins."ApplicationEventValueStr",1,255),
      ins."ApplicationEventValueNum",
      ins."ApplicationEventDate",
      ins."ApplicationEventDateUTC",
      ins."ConstructID",
      SUBSTR(ins."OriginalSQL",1,8192),
      ins."ObjectsandVerbs",
      ins."SuccessfulSqls",
      ins."FailedSqls",
      ins."DBUserName",
      ins."OSUser",
      ins."SourceProgram",
      ins."ServerIP",
      ins."ClientID",
      ins."ServiceName",
      ins."ClientHostName",
      ins."ServerType",
      ins."DatabaseName",
      ins."EventUserName",
      ins."ServerPort",
      ins."NetworkProtocol",
      ins."TotalRecordsAffected",
      ins."ServerHostName",
      ins."Timestamp",
      ins."TimestampUTC",
      ins."AverageExecutionTime",
      ins."ConfigID",
      ins."GlobalID",
      ins."TenantID",
      ins."IngestTimestamp",
      SUBSTR(ins."Db2ClientInfo",1,1024),
      ins."Db2IZDatabase",
      ins."Db2ICurrentUser",
      ins."Db2IZProgram",
      ins."ProcessID",
      ins."DBProtocol",
      CASE WHEN of."ID" IS NOT NULL THEN 1.0 ELSE 0.0 END
  FROM "${TNT_SCHEMA}"."INSTANCE" ins
  LEFT OUTER JOIN "${TNT_SCHEMA}"."OVERFLOW_FIELDS" of
  ON ins."InstanceID" = of."ID" AND of."ColumnName" = 'OriginalSQL' AND of."TableName" = 'INSTANCE'
  AND ins."ConfigID" = of."ConfigID" AND ins."GlobalID" = of."GlobalID" AND ins."IngestTimestamp" = of."IngestTimestamp";
  DROP TABLE "${TNT_SCHEMA}"."INSTANCE";
  RENAME TABLE "${TNT_SCHEMA}"."INSTANCE_${TMP_TBSP_SUFFIX}" TO INSTANCE;
  COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.INSTANCE failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.INSTANCE successful"
}

# Redefine table POLICY_VIOLATION and move data (including overflow)
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTablePolicyViolation() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.POLICY_VIOLATION"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = 'POLICY_VIOLATION'
              and ((colname = 'FullSQL' and length > 8192))")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 0 ]]; then info "Table ${TNT_SCHEMA}.POLICY_VIOLATION already migrated" ; return; fi
  # First create overflow rows for FullSQL values larger than 8192
  # (if they don't already exist), then copy all rows into the new table
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."POLICY_VIOLATION_${TMP_TBSP_SUFFIX}"  (
      "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'POLICY_VIOLATION' ,
      "ID" VARCHAR(100 OCTETS) ,
      "ViolationID" DECIMAL(20,0) NOT NULL ,
      "SessionID" DECIMAL(20,0) NOT NULL WITH DEFAULT 0 ,
      "UTCOffset" DOUBLE ,
      "OSUser" VARCHAR(255 OCTETS) ,
      "DBUserName" VARCHAR(255 OCTETS) ,
      "ClientID" VARCHAR(50 OCTETS) ,
      "ClientHostName" VARCHAR(255 OCTETS) ,
      "SourceProgram" VARCHAR(255 OCTETS) ,
      "ServerIP" VARCHAR(50 OCTETS) ,
      "ServerType" VARCHAR(30 OCTETS) ,
      "ServiceName" VARCHAR(80 OCTETS) ,
      "ConstructID" VARCHAR(40 OCTETS) ,
      "ObjectsandVerbs" VARCHAR(1000 OCTETS) ,
      "AppUserName" VARCHAR(240 OCTETS) WITH DEFAULT NULL ,
      "AccessRuleID" DECIMAL(20,0) WITH DEFAULT 0 ,
      "AccessRuleDescription" VARCHAR(100 OCTETS) WITH DEFAULT NULL ,
      "Verdict" DECIMAL(11,0) WITH DEFAULT NULL ,
      "FullSQL" VARCHAR(8192 OCTETS) WITH DEFAULT NULL ,
      "SendMessage" DECIMAL(20,0) ,
      "CurrentCounter" DECIMAL(20,0) ,
      "KeyString" VARCHAR(1000 OCTETS) ,
      "CategoryName" VARCHAR(60 OCTETS) WITH DEFAULT NULL ,
      "ClassificationName" VARCHAR(60 OCTETS) WITH DEFAULT NULL ,
      "Severity" DECIMAL(20,0) WITH DEFAULT 0 ,
      "PolicyDescription" VARCHAR(100 OCTETS) WITH DEFAULT NULL ,
      "Timestamp" TIMESTAMP ,
      "TimestampUTC" TIMESTAMP ,
      "ServerHostName" VARCHAR(255 OCTETS) ,
      "ConfigID" VARCHAR(50 OCTETS) NOT NULL ,
      "GlobalID" VARCHAR(50 OCTETS) NOT NULL ,
      "TenantID" VARCHAR(50 OCTETS) ,
      "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "ProcessID" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "OverflowFlagFullSQL" DECIMAL(5,0) WITH DEFAULT 0 )
     DISTRIBUTE BY HASH("SessionID")
       IN "PVIO_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."POLICY_VIOLATION_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("ViolationID",
     "ConfigID",
     "GlobalID",
     "SessionID")
  ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."OVERFLOW_FIELDS" (
      "TableName" ,
      "ID"  ,
      "ColumnName"  ,
      "Value" ,
      "ConfigID" ,
      "GlobalID"  ,
      "IngestTimestamp"
  )
  SELECT
      'POLICY_VIOLATION',
      pv."ViolationID",
      'FullSQL'  ,
      CLOB(pv."FullSQL")  ,
      pv."ConfigID" ,
      pv."GlobalID"  ,
      pv."IngestTimestamp"
  FROM "${TNT_SCHEMA}"."POLICY_VIOLATION" pv
  WHERE LENGTH(TRIM(pv."FullSQL"))>8192
  AND NOT EXISTS (
    SELECT 1 FROM "${TNT_SCHEMA}"."OVERFLOW_FIELDS" of
    WHERE of."TableName" = 'POLICY_VIOLATION' and of."ID" = pv."ViolationID" and of."ColumnName" = 'FullSQL'
    AND pv."ConfigID" = of."ConfigID" AND pv."GlobalID" = of."GlobalID" AND pv."IngestTimestamp" = of."IngestTimestamp"
  );
INSERT INTO "${TNT_SCHEMA}"."POLICY_VIOLATION_${TMP_TBSP_SUFFIX}" (
      "MessageType",
      "ID",
      "ViolationID",
      "SessionID",
      "UTCOffset",
      "OSUser",
      "DBUserName",
      "ClientID",
      "ClientHostName",
      "SourceProgram",
      "ServerIP",
      "ServerType",
      "ServiceName",
      "ConstructID",
      "ObjectsandVerbs",
      "AppUserName",
      "AccessRuleID",
      "AccessRuleDescription",
      "Verdict",
      "FullSQL",
      "SendMessage",
      "CurrentCounter",
      "KeyString",
      "CategoryName",
      "ClassificationName",
      "Severity",
      "PolicyDescription",
      "Timestamp",
      "TimestampUTC",
      "ServerHostName",
      "ConfigID",
      "GlobalID",
      "TenantID",
      "IngestTimestamp",
      "ProcessID",
      "OverflowFlagFullSQL"
  )
  SELECT
      pv."MessageType",
      pv."ID",
      pv."ViolationID",
      pv."SessionID",
      pv."UTCOffset",
      pv."OSUser",
      pv."DBUserName",
      pv."ClientID",
      pv."ClientHostName",
      pv."SourceProgram",
      pv."ServerIP",
      pv."ServerType",
      pv."ServiceName",
      pv."ConstructID",
      pv."ObjectsandVerbs",
      pv."AppUserName",
      pv."AccessRuleID",
      pv."AccessRuleDescription",
      pv."Verdict",
      SUBSTR(pv."FullSQL",1,8192),
      pv."SendMessage",
      pv."CurrentCounter",
      pv."KeyString",
      pv."CategoryName",
      pv."ClassificationName",
      pv."Severity",
      pv."PolicyDescription",
      pv."Timestamp",
      pv."TimestampUTC",
      pv."ServerHostName",
      pv."ConfigID",
      pv."GlobalID",
      pv."TenantID",
      pv."IngestTimestamp",
      pv."ProcessID",
      CASE WHEN of."ID" IS NOT NULL THEN 1.0 ELSE 0.0 END
  FROM "${TNT_SCHEMA}"."POLICY_VIOLATION" pv
  LEFT OUTER JOIN "${TNT_SCHEMA}"."OVERFLOW_FIELDS" of
  ON pv."ViolationID" = of."ID" AND of."ColumnName" = 'FullSQL' AND of."TableName" = 'POLICY_VIOLATION'
  AND pv."ConfigID" = of."ConfigID" AND pv."GlobalID" = of."GlobalID" AND pv."IngestTimestamp" = of."IngestTimestamp";
  DROP TABLE "${TNT_SCHEMA}"."POLICY_VIOLATION";
  RENAME TABLE "${TNT_SCHEMA}"."POLICY_VIOLATION_${TMP_TBSP_SUFFIX}" TO POLICY_VIOLATION;
  COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.POLICY_VIOLATION failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.POLICY_VIOLATION successful"
}

# Redefine table CLASSIFICATION and move data
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableClassification() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  local TABNAME=CLASSIFICATION
  local COLNAME=DataSourceIP
  local COLLEN=255
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
              and colname = '${COLNAME}' and length = ${COLLEN}")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 1 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."CLASSIFICATION_${TMP_TBSP_SUFFIX}"  (
      "MessageType" VARCHAR(25 OCTETS) WITH DEFAULT 'CLASSIFICATION' ,
      "UTCOffset" DOUBLE ,
      "DataSourceID" DECIMAL(20,0) NOT NULL ,
      "DataSourceName" VARCHAR(255 OCTETS) ,
      "DataSourceType" VARCHAR(50 OCTETS) ,
      "DataSourceIP" VARCHAR(${COLLEN} OCTETS) ,
      "ServiceName" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "DBName" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "Port" DECIMAL(11,0) WITH DEFAULT 0 ,
      "ProcessDescription" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "Catalog" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "Schema" VARCHAR(255 OCTETS) NOT NULL ,
      "TableName" VARCHAR(255 OCTETS) NOT NULL ,
      "ColumnName" VARCHAR(255 OCTETS) NOT NULL ,
      "RuleDescription" VARCHAR(255 OCTETS) ,
      "ClassificationName" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "Category" VARCHAR(255 OCTETS) WITH DEFAULT NULL ,
      "StartDateTime" TIMESTAMP WITH DEFAULT '0001-01-01-00.00.00.000000' ,
      "StartDateTimeUTC" TIMESTAMP NOT NULL WITH DEFAULT '0001-01-01-00.00.00.000000' ,
      "Comprehensive" VARCHAR(50 OCTETS) WITH DEFAULT NULL ,
      "ConfigID" VARCHAR(50 OCTETS) NOT NULL ,
      "GlobalID" VARCHAR(50 OCTETS) NOT NULL ,
      "TenantID" VARCHAR(50 OCTETS) ,
      "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP ,
      "ResultDataRowID" DECIMAL(20,0) NOT NULL ,
      "Comments" VARCHAR(32000 OCTETS) WITH DEFAULT NULL )
     DISTRIBUTE BY HASH("ResultDataRowID")
       IN "CLASS_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."CLASSIFICATION_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("ResultDataRowID",
     "ConfigID",
     "GlobalID")
  ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."CLASSIFICATION_${TMP_TBSP_SUFFIX}" (
      "MessageType",
      "UTCOffset",
      "DataSourceID",
      "DataSourceName",
      "DataSourceType",
      "DataSourceIP",
      "ServiceName",
      "DBName",
      "Port",
      "ProcessDescription",
      "Catalog",
      "Schema",
      "TableName",
      "ColumnName",
      "RuleDescription",
      "ClassificationName",
      "Category",
      "StartDateTime",
      "StartDateTimeUTC",
      "Comprehensive",
      "ConfigID",
      "GlobalID",
      "TenantID",
      "IngestTimestamp",
      "ResultDataRowID",
      "Comments"
  )
  SELECT
      "MessageType",
      "UTCOffset",
      "DataSourceID",
      "DataSourceName",
      "DataSourceType",
      "DataSourceIP",
      "ServiceName",
      "DBName",
      "Port",
      "ProcessDescription",
      "Catalog",
      "Schema",
      "TableName",
      "ColumnName",
      "RuleDescription",
      "ClassificationName",
      "Category",
      "StartDateTime",
      "StartDateTimeUTC",
      "Comprehensive",
      "ConfigID",
      "GlobalID",
      "TenantID",
      "IngestTimestamp",
      "ResultDataRowID",
      "Comments"
  FROM "${TNT_SCHEMA}"."CLASSIFICATION";
  DROP TABLE "${TNT_SCHEMA}"."CLASSIFICATION";
  RENAME TABLE "${TNT_SCHEMA}"."CLASSIFICATION_${TMP_TBSP_SUFFIX}" TO CLASSIFICATION;
  COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Redefine table VULNERABILITY_ASSESSMENT
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableVulnerabilityAssessment() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local CNT
  local RC
  local TABNAME=VULNERABILITY_ASSESSMENT
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
              and colname in ('TestID','ExternalReference','ExternalGroupDescription')")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 3 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi

  db2 +p -t <<EOF
alter table ${TNT_SCHEMA}.${TABNAME}
add column "TestID" DECIMAL(11) DEFAULT -1
add column "ExternalReference" VARCHAR(8192) DEFAULT NULL
add column "ExternalGroupDescription" VARCHAR(150) DEFAULT NULL;
EOF
  RC=$?
  if [[ $RC -gt 1 ]]; then
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Redefine table OVERFLOW_FIELDS and move data
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableOverflowFields() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local TABNAME=OVERFLOW_FIELDS
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
        and colname = 'Value' and inline_length = 3500")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 1 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}"  (
      "TableName" VARCHAR(25 OCTETS) NOT NULL WITH DEFAULT  ,
      "ID" DECIMAL(20,0) NOT NULL ,
      "ColumnName" VARCHAR(25 OCTETS) NOT NULL WITH DEFAULT  ,
      "Value" CLOB(2147483647 OCTETS) INLINE LENGTH 3500 LOGGED NOT COMPACT WITH DEFAULT NULL ,
      "ConfigID" VARCHAR(50 OCTETS) NOT NULL ,
      "GlobalID" VARCHAR(50 OCTETS) NOT NULL ,
      "IngestTimestamp" TIMESTAMP WITH DEFAULT CURRENT TIMESTAMP )
     DISTRIBUTE BY HASH("ID")
       IN "OVFFM_${TNT_SHORT}" INDEX IN "IRPT8_${TNT_SHORT}" LONG IN "LG32_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("TableName",
     "ID",
     "ColumnName",
     "ConfigID",
     "GlobalID")
  ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}" (
      "TableName" ,
      "ID"  ,
      "ColumnName"  ,
      "Value" ,
      "ConfigID" ,
      "GlobalID"  ,
      "IngestTimestamp"
  )
  SELECT
      "TableName" ,
      "ID"  ,
      "ColumnName"  ,
      "Value" ,
      "ConfigID" ,
      "GlobalID"  ,
      "IngestTimestamp"
  FROM "${TNT_SCHEMA}"."${TABNAME}";
  DROP TABLE "${TNT_SCHEMA}"."${TABNAME}";
  RENAME TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}" TO ${TABNAME};
  COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Redefine table DB_ERROR_TEXT and move data
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableDbErrorText() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local TABNAME=DB_ERROR_TEXT
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
        and colname = 'ERROR_TEXT' and inline_length = 3500")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 1 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi
  local STMTS=$(cat <<EOF
CREATE TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}"  (
      "DB_ERROR_ID" INTEGER NOT NULL ,
      "DB_PROTOCOL" VARCHAR(20 OCTETS) NOT NULL WITH DEFAULT '' ,
      "DB_PROTOCOL_VERSION" VARCHAR(30 OCTETS) WITH DEFAULT '*' ,
      "ERROR_CODE" VARCHAR(150 OCTETS) NOT NULL WITH DEFAULT '' ,
      "ERROR_TEXT" CLOB(1048576 OCTETS) INLINE LENGTH 3500 LOGGED COMPACT NOT NULL ,
      "LANGUAGE" VARCHAR(20 OCTETS) WITH DEFAULT NULL )
     IN "GEN4_${TNT_SHORT}" INDEX IN "IGEN4_${TNT_SHORT}"
     ORGANIZE BY COLUMN;
ALTER TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}"
  ADD PRIMARY KEY
    ("DB_ERROR_ID")
  NOT ENFORCED;
INSERT INTO "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}" (
      "DB_ERROR_ID",
      "DB_PROTOCOL",
      "DB_PROTOCOL_VERSION" ,
      "ERROR_CODE" ,
      "ERROR_TEXT"  ,
      "LANGUAGE"
  )
  SELECT
      "DB_ERROR_ID",
      "DB_PROTOCOL",
      "DB_PROTOCOL_VERSION" ,
      "ERROR_CODE" ,
      "ERROR_TEXT"  ,
      "LANGUAGE"
  FROM "${TNT_SCHEMA}"."${TABNAME}";
DROP TABLE "${TNT_SCHEMA}"."${TABNAME}";
RENAME TABLE "${TNT_SCHEMA}"."${TABNAME}_${TMP_TBSP_SUFFIX}" TO ${TABNAME};
COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Redefine table ANALYTIC_LOG (in place, as it is row-organized)
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableAnalyticLog() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local TABNAME=ANALYTIC_LOG
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
        and colname = 'DETAIL' and inline_length = 3000")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 1 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi
  local STMTS=$(cat <<EOF
ALTER TABLE "${TNT_SCHEMA}"."${TABNAME}"
 ALTER COLUMN DETAIL SET INLINE LENGTH 3000
 ALTER COLUMN ADVANCED_DETAIL SET INLINE LENGTH 3000;
COMMIT;
REORG TABLE "${TNT_SCHEMA}"."${TABNAME}";
COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}

# Redefine table ANALYTIC_OUTLIER (in place, as it is row-organized)
# $1 - Tenant schema name
# $2 - Tenant short ID
function alterTableAnalyticOutlier() {
  local TNT_SCHEMA="$1"
  local TNT_SHORT="$2"
  local TABNAME=ANALYTIC_OUTLIER
  local CNT
  local RC
  info "Migrating table ${TNT_SCHEMA}.${TABNAME}"
  # check if already migrated
  CNT=$(db2 -x "select int(count(1)) from syscat.columns where tabschema = '${TNT_SCHEMA}' and tabname = '${TABNAME}'
        and colname = 'OBJECT_VERB_TUPLES' and inline_length = 4000")
  RC=$?
  if [[ $RC -ge 2 ]]; then err "Error querying system catalog"; return $RC; fi
  if [[ $CNT -eq 1 ]]; then info "Table ${TNT_SCHEMA}.${TABNAME} already migrated" ; return; fi
  local STMTS=$(cat <<EOF
ALTER TABLE "${TNT_SCHEMA}"."${TABNAME}"
 ALTER COLUMN OBJECT_VERB_TUPLES SET INLINE LENGTH 4000;
COMMIT;
REORG TABLE "${TNT_SCHEMA}"."${TABNAME}";
COMMIT;
EOF
  )
  <<<"${STMTS}" db2 -v +c +p -st
  RC=$?
  if [[ $RC -gt 1 ]]; then
    db2 rollback
    err "Migration of table ${TNT_SCHEMA}.${TABNAME} failed"
    return $RC
  fi
  info "Migration of table ${TNT_SCHEMA}.${TABNAME} successful"
}



# Create stored procedure from script. Assumes it has CREATE OR REPLACE
# $1 - Tenant schema name
# $2 - SP script file name
function createSP() {
  local TNT_SCHEMA="$1"
  local SP_SCRIPT="$2"
  local RC
  info "Creating SP from ${SP_SCRIPT} in ${TNT_SCHEMA}"
  if ! [[ -f $SP_SCRIPT ]]; then
    err "Cannot find  script $SP_SCRIPT"
    return 1
  fi
  sed 's/MY_TENANT_SCHEMA/'${TNT_SCHEMA}'/g;$a @' $SP_SCRIPT | db2 +p +c -td@ && \
  db2 commit
  RC=$?
  if [[ $RC -ne 0 ]]; then
    db2 rollback
    err "Failed to create ${SP_SCRIPT}"
    return $RC
  fi
  info "Executed ${SP_SCRIPT} successfully"
}

# Update stored procedures that are affected by changing table definitions
# $1 - Tenant schema name
# $2 - Tenant short ID
function updateStoredProcs() {
  local TNT_SCHEMA="$1"
  local RC

  # execute all scripts in ${SQL_DIR}/datamart-processor 
  # v2 - only updated SPs
  # v3 - all
  for F in $(find ${SQL_DIR}/datamart-processor -type f -name "*\.sql"); do
    createSP ${TNT_SCHEMA} "${F}" 
    RC=$?
    if [[ $RC -ne 0 ]]; then
      err "Terminate stored procedure upgrade due to earlier error"
      return $RC
    fi
  done
  info "Updated stored procedures successfully"
}

function restartInstance() {
  info "Restarting instance to apply changes"
  db2stop force && db2start && db2 activate db $DBNAME
  local RC=$?
  if [[ $RC -ge 4 ]]; then
    err "Failed to restart the instance"
    return $RC
  else
    return
  fi
}

#----------------------------------------------------------------------------------------

debug "Top, shell level $SHLVL"


db2="${HOME}/sqllib/bin/db2"

logFile="${HOME}/GIv31_DB_Upgrade.log"

db2 connect to $DBNAME
if [[ $? -ne 0 ]]; then
  err "Failed to connect to $DBNAME database, exiting"
  exit 1
fi

info "Upgrading DB schemas to GI version 3.1. Start time: $(date +'%Y-%m-%d %T')"

# database-wide changes
updateInstanceCfg && \
updateDatabaseCfg && \
setArchiveLogging && \
db2 connect to $DBNAME && \
createPartnGroup

RC=$?
if [[ $RC -gt 2 ]]; then err "Failed to apply database-level changes" ; exit $RC; fi

info "Processing tenant schemas"
TNT_SCHEMATA=$(db2 -x "select schemaname from syscat.schemata 
  where schemaname like 'TNT\\_%' escape '\\' 
  and schemaname not like '%\\_CUSTOM' escape '\\'" 
)
RC=$?
if [[ $RC -eq 1 ]]; then info "No tenant data, nothing to do" ; exit; fi
if [[ $RC -ge 4 ]]; then err "Could not list tenants" ; exit $RC; fi

for TNT_SCHEMA in $TNT_SCHEMATA; do
  TNT_ID="${TNT_SCHEMA#TNT_}"
  TNT_SHORT_ID="${TNT_ID:0:11}"
  info "Processing tenant $TNT_ID"

  updateTablespaces ${TNT_SCHEMA} ${TNT_SHORT_ID} && \
  alterTables "${TNT_SCHEMA}" "${TNT_SHORT_ID}" && \
  createNewTables "${TNT_SCHEMA}" "${TNT_SHORT_ID}" && \
  updateGroupBuilderData "${TNT_SCHEMA}" "${TNT_SHORT_ID}" && \
  updateStoredProcs "${TNT_SCHEMA}"
  RC=$?

  db2 terminate
  if [[ $RC -ne 0 ]]; then
    err "Failed to apply schema-level changes for tenant $TNT_ID"
    exit $RC
  fi
done

info "Database upgrade to GI version 3.1 complete. End time: $(date +'%Y-%m-%d %T')"
