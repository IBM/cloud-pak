-- **************************************************************
--
-- Source Components
--
-- 5737-L66
--
-- (C) Copyright IBM Corp. 2019, 2023
--
-- **************************************************************

CREATE OR REPLACE PROCEDURE "MY_TENANT_SCHEMA"."ALT_INSERT_ANALYTIC_OUTLIERS_DETAILS_v4" (
    IN TNT_ID VARCHAR(1000),
    IN FILENAME VARCHAR(1000),
    IN GLOBALID VARCHAR(1000),
    IN TABLENAME VARCHAR(1000),
    IN DB2MOUNTPOINTPATH VARCHAR(1000),
    OUT ROWCOUNT INT
  )
LANGUAGE SQL
  S1:BEGIN
	DECLARE FILEPATH VARCHAR(1000);
	DECLARE CREATE_STMT VARCHAR(5000);
	DECLARE INSERT_STMT VARCHAR(5000);
	DECLARE duplicate CONDITION FOR SQLSTATE '23505';
	DECLARE CONDITION_COUNT INT;
  	DECLARE AFFECTED_ROWS INT;

  DECLARE CONTINUE HANDLER FOR duplicate SET CONDITION_COUNT = CONDITION_COUNT + 1;

	SET FILEPATH = (
	CONCAT(CONCAT(CONCAT(DB2MOUNTPOINTPATH,TNT_ID),'/'),FILENAME));
		SET CONDITION_COUNT = 0;

	SET CREATE_STMT = '
		CREATE EXTERNAL TABLE '||TNT_ID||'.'||TABLENAME||' (
		UTCOffset           FLOAT,
		AnalyticOutlierID   DECIMAL(20),
		SourceID            VARCHAR(200),
		AnomalyScore	    DECIMAL(11),
		IsVolume            VARCHAR(5),
		IsVulnerableObject  VARCHAR(5),
		IsNewMessage	    VARCHAR(5),
		IsFailure	        VARCHAR(5),
		NumberOfInstances	DECIMAL(11),
		ServerIP	        VARCHAR(50),
		DBName              VARCHAR(255),
		SourceProgram       VARCHAR(255),
		DBUser              VARCHAR(255),
		ObjectName          VARCHAR(255),
		Verb                VARCHAR(40),
		PeriodStart         TIMESTAMP,
        periodStartUTC      TIMESTAMP,
		ServerType          VARCHAR(30),
		RecordsAffected     DECIMAL(11),
		ClientIP	        VARCHAR(50),
		ClientHostname      VARCHAR(255),
		OSUser	            VARCHAR(255),
		DatetimeCodeID	    VARCHAR(10),
		TextualDescription	VARCHAR(8192),
		EffectiveVolume     DECIMAL(11),
		IsSensitive         VARCHAR(5),
		MessageDBUser       VARCHAR(255),
		VolumeAve           DOUBLE )
		USING (DATAOBJECT '''||FILEPATH||''' ENCODING UTF8 QUOTEDVALUE DOUBLE RequireQuotes TRUE DELIMITER ''~'' NULLVALUE ''\N'' escapeChar ''\'' TRUNCSTRING TRUE CtrlChars TRUE CRinString TRUE SKIPROWS 1 MAXERRORS 2000000000)';
    EXECUTE IMMEDIATE CREATE_STMT;

	SET
	INSERT_STMT = 'INSERT
		INTO  "' || TNT_ID || '"."ANALYTIC_OUTLIERS_DETAILS" ("AnalyticOutlierID","Timestamp","PeriodStart","periodStartUTC","ServerIP","DBUser","SourceProgram","DBName","ObjectVerbTuples","OutlierType","NumberOfInstances","AnomalyScore","ObjectName","Verb","IsFailure","IsTempObject","IsTempSourceProgram","IsNewMessage","IsSensitive","IsPrivileged","Rarity","VolumeScore","VolumeAve","VolumeSD","SourceID","OrigHostname","AlertFeedbackID","EqIntervals","ServerType","IsVolume","MessageDBUser","RecordsAffected","EffectiveVolume","ClientIP","ClientHostname","OSUser","TextualDescription","DatetimeCodeID","SourceLinkID","IsVulnerableObject","UTCOffset","GlobalID")
		SELECT
			AnalyticOutlierID,
			CURRENT TIMESTAMP,
			PeriodStart,
            periodStartUTC,
			ServerIP,
			DBUser,
			SourceProgram,
			DBName,
			NULL,
			0,
			NumberOfInstances,
			AnomalyScore,
			ObjectName,
			Verb,
			IsFailure,
			0,
			0,
			IsNewMessage,
			IsSensitive,
			0,
			0,
			0,
			VolumeAve,
			0,
			SourceID,
			NULL,
			0,
			0,
			ServerType,
			IsVolume,
			MessageDBUser,
			RecordsAffected,
			EffectiveVolume,
			ClientIP,
			ClientHostname,
			OSUser,
			TextualDescription,
			DatetimeCodeID,
			NULL,
			IsVulnerableObject,
            UTCOffset,
			''' || GLOBALID || '''
	FROM "'||TNT_ID||'"."'||TABLENAME||'";';

	EXECUTE IMMEDIATE INSERT_STMT;

    GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

    IF CONDITION_COUNT = 0 THEN
        GOTO exit;
    END IF;

	SET INSERT_STMT = 'INSERT
	INTO  "' || TNT_ID || '"."ANALYTIC_OUTLIERS_DETAILS" ("AnalyticOutlierID","Timestamp","PeriodStart","PeriodStartUTC","ServerIP","DBUser","SourceProgram","DBName","ObjectVerbTuples","OutlierType","NumberOfInstances","AnomalyScore","ObjectName","Verb","IsFailure","IsTempObject","IsTempSourceProgram","IsNewMessage","IsSensitive","IsPrivileged","Rarity","VolumeScore","VolumeAve","VolumeSD","SourceID","OrigHostname","AlertFeedbackID","EqIntervals","ServerType","IsVolume","MessageDBUser","RecordsAffected","EffectiveVolume","ClientIP","ClientHostname","OSUser","TextualDescription","DatetimeCodeID","SourceLinkID","IsVulnerableObject","UTCOffset","GlobalID")
	SELECT
        AnalyticOutlierID,
        CURRENT TIMESTAMP,
		PeriodStart,
        PeriodStartUTC,
		ServerIP,
		DBUser,
		SourceProgram,
		DBName,
		NULL,
		0,
		NumberOfInstances,
		AnomalyScore,
		ObjectName,
		Verb,
		IsFailure,
		0,
		0,
		IsNewMessage,
		IsSensitive,
		0,
		0,
		0,
		VolumeAve,
		0,
		SourceID,
		NULL,
		0,
		0,
		ServerType,
		IsVolume,
		MessageDBUser,
		RecordsAffected,
		EffectiveVolume,
		ClientIP,
		ClientHostname,
		OSUser,
		TextualDescription,
		DatetimeCodeID,
		NULL,
		IsVulnerableObject,
        UTCOffset,
		''' || GLOBALID || '''
   	FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
	WHERE NOT EXISTS ( SELECT "AnalyticOutlierID","GlobalID" FROM "'||TNT_ID||'"."ANALYTIC_OUTLIERS_DETAILS" mt WHERE mt."AnalyticOutlierID"=Ext.AnalyticOutlierID AND mt."GlobalID" = '''||GLOBALID||'''
	);';
	EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

    IF CONDITION_COUNT = 1 THEN
        GOTO exit;
    END IF;

	SET INSERT_STMT = 'INSERT
	INTO  "' || TNT_ID || '"."ANALYTIC_OUTLIERS_DETAILS" ("AnalyticOutlierID","Timestamp","PeriodStart","PeriodStartUTC","ServerIP","DBUser","SourceProgram","DBName","ObjectVerbTuples","OutlierType","NumberOfInstances","AnomalyScore","ObjectName","Verb","IsFailure","IsTempObject","IsTempSourceProgram","IsNewMessage","IsSensitive","IsPrivileged","Rarity","VolumeScore","VolumeAve","VolumeSD","SourceID","OrigHostname","AlertFeedbackID","EqIntervals","ServerType","IsVolume","MessageDBUser","RecordsAffected","EffectiveVolume","ClientIP","ClientHostname","OSUser","TextualDescription","DatetimeCodeID","SourceLinkID","IsVulnerableObject","UTCOffset","GlobalID")
	SELECT DISTINCT
        AnalyticOutlierID,
        CURRENT TIMESTAMP,
		PeriodStart,
        PeriodStartUTC,
		ServerIP,
		DBUser,
		SourceProgram,
		DBName,
		NULL,
		0,
		NumberOfInstances,
		AnomalyScore,
		ObjectName,
		Verb,
		IsFailure,
		0,
		0,
		IsNewMessage,
		IsSensitive,
		0,
		0,
		0,
		VolumeAve,
		0,
		SourceID,
		NULL,
		0,
		0,
		ServerType,
		IsVolume,
		MessageDBUser,
		RecordsAffected,
		EffectiveVolume,
		ClientIP,
		ClientHostname,
		OSUser,
		TextualDescription,
		DatetimeCodeID,
		NULL,
		IsVulnerableObject,
        UTCOffset,
		''' || GLOBALID || '''
   	FROM "'||TNT_ID||'"."'||TABLENAME||'" Ext
	WHERE NOT EXISTS ( SELECT "AnalyticOutlierID","GlobalID" FROM "'||TNT_ID||'"."ANALYTIC_OUTLIERS_DETAILS" mt WHERE mt."AnalyticOutlierID"=Ext.AnalyticOutlierID AND mt."GlobalID" = '''||GLOBALID||'''
	);';
	EXECUTE IMMEDIATE INSERT_STMT;

	GET DIAGNOSTICS AFFECTED_ROWS = ROW_COUNT;

exit:
  SET ROWCOUNT = AFFECTED_ROWS;
END S1
