#!/bin/bash

# **************************************************************
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2020. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
# **************************************************************
host=$1
user=$2
password=$3

if [[ $# -ne 3 ]]; then
    echo "Usage: ./get_tenants.sh <hostname> <admin user id> <admin password>"
    exit 2
fi

jwt=$(./get_jwt.sh ${host} ${user} ${password})

curl -k -X GET "https://${host}/api/v3/tenants" -H "accept: application/json" -H "authorization: ${jwt}" -H "Content-Type: application/json" | jq .Tenants