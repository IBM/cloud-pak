#!/bin/bash
#
#################################################################
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2022. All Rights Reserved.
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with
# IBM Corp.
#################################################################

#-----------------------------------------------------------------------------
# NAME:          upgradeConfigGIv31_v32.sh
#
# DESCRIPTION:   Upgrade script to fix permission issue with export directory
#
# USAGE:         This script takes two arguments:
#                   1) namespace
#                   2) master log filename
#
# PREREQUISITES: This script should be run at GI v3.2 level.
#
#----------------------------------------------------------------------------

NAME_SPACE="$1"
MASTER_LOG_FILE="$2"

# Check for required NAME_SPACE and MASTER_LOG_FILE parameters
THIS_SCRIPT=$(basename "$0")
if [ "$#" -ne 2 ]; then
	echo "Usage: $THIS_SCRIPT <namespace> <logfile>"
	exit 1
fi

# Global constants
SOURCE_DIR=$(pwd)
LOG_TIMESTAMP=$(date "+%Y%m%d%H%M%S")
UPGRADE_SCRIPT_LOG="${SOURCE_DIR}/logs/${THIS_SCRIPT%.*}_${LOG_TIMESTAMP}.log"
DEPLOYMENT_NAME="$NAME_SPACE-insights"
oc_output=""

# Write a timestamped message to the log file
function write_log() {
	message=$1
	timestamp=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$timestamp $THIS_SCRIPT: $message" >> $MASTER_LOG_FILE
}

function check_deployment_config {
    write_log "Checking deployment configuration..."

    oc_output=$(oc get deployment -oyaml $DEPLOYMENT_NAME | grep /node_app/src/static/insights_exports)

    if [ -z "$oc_output" ]; then
        write_log "Search string does not exist. No remapping is needed"
        return 0
    else
        write_log "Search string found. Remapping is needed"
        return 1
    fi
}

function remap_deployment_config {
    write_log "Remaping deployment configuration..."

    oc get deployment -oyaml $DEPLOYMENT_NAME | sed 's#/node_app/src/static/insights_exports#/tmp/ignore#g' | oc replace -f -
    status=$?

    if [ $status = 0 ]; then
        write_log "Remapped completed successfully"
        return 0
    else
        write_log "Remap failed"
        return 1
    fi
}

# Copy log file back to source run directory
function copy_log_back() {
	write_log "Copying log file back..."

    echo "$oc_output" > $UPGRADE_SCRIPT_LOG

	write_log "Log file copied to source directory $SOURCE_DIR/logs"
}

# Main function

# Go through the upgrade steps
write_log "Start remap deployment config for namespace '$NAME_SPACE'"

check_deployment_config
status=$?
if [ $status = 1 ]; then
    remap_deployment_config
    status=$?
fi
copy_log_back

write_log "End remap deployment config for namespace '$NAME_SPACE'"

exit $status