# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the redis operator

inventory="noobaaOperator" # default inventory item

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    echo "no dependent catalogs"
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {
    echo "no operator group"
}

# Installs the catalog source and operator group
install_catalog() {
    echo "no catalog"
}
# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing native-------------"

    # Verify expected yaml files for install exist
    local cluster_resource_folder="${casePath}/inventory/${inventory}/files/resources"
    local crds_folder="${cluster_resource_folder}/CustomResourceDefinitions"

    local cluster_template_folder="${casePath}/inventory/${inventory}/files/templates"
    local noobaa_cluster_role="${cluster_template_folder}/ClusterRole/namespace.noobaa.io.yaml"
    local noobaa_cluster_role_binding="${cluster_template_folder}/ClusterRoleBinding/namespace.noobaa.io.yaml"
    local noobaa_sa="${cluster_template_folder}/ServiceAccounts/noobaa.yaml"
    local endpoint_sa="${cluster_template_folder}/ServiceAccounts/noobaa-endpoint.yaml"
    local noobaa_role="${cluster_template_folder}/Role/noobaa.yaml"
    local endpoint_role="${cluster_template_folder}/Role/noobaa-endpoint.yaml"
    local noobaa_role_binding="${cluster_template_folder}/RoleBinding/noobaa.yaml"
    local endpoint_role_binding="${cluster_template_folder}/RoleBinding/noobaa-endpoint.yaml"
    # local operator_deployment="${cluster_template_folder}/Deployment/operator.yaml"

    validate_folder_exists "${crds_folder}"

    validate_file_exists "${noobaa_cluster_role}"
    validate_file_exists "${noobaa_cluster_role_binding}"
    validate_file_exists "${noobaa_sa}"
    validate_file_exists "${endpoint_sa}"
    validate_file_exists "${noobaa_role}"
    validate_file_exists "${endpoint_role}"
    validate_file_exists "${noobaa_role_binding}"
    validate_file_exists "${endpoint_role_binding}"
    # validate_file_exists "${operator_deployment}"

    if $kubernetesCLI get deployment noobaa-operator -n ${namespace} 2>/dev/null ; then
        $kubernetesCLI delete deployment noobaa-operator -n ${namespace}
    fi
    # Create CRDs
    $kubernetesCLI apply ${dryRun} -f "${crds_folder}"

    # Process and apply all template files
    cat ${noobaa_cluster_role} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    cat ${noobaa_cluster_role_binding} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    cat ${noobaa_sa} | sed -e 's#${NAMESPACE}#'${namespace}'#g' -e 's#${PULL_SECRET}#'${secret}'#g' | $kubernetesCLI apply -f -;
    cat ${endpoint_sa} | sed -e 's#${NAMESPACE}#'${namespace}'#g' -e 's#${PULL_SECRET}#'${secret}'#g' | $kubernetesCLI apply -f -;
    cat ${noobaa_role} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    cat ${endpoint_role} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    cat ${noobaa_role_binding} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    cat ${endpoint_role_binding} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    # cat ${operator_deployment} | sed -e 's#${NAMESPACE}#'${namespace}'#g' |  $kubernetesCLI apply -f -;
    # $kubernetesCLI process -f "${noobaa_cluster_role}" -p NAMESPACE="${namespace}" 
    #$kubernetesCLI process -f "${noobaa_cluster_role_binding}" -p NAMESPACE="${namespace}" 
    #$kubernetesCLI process -f "${noobaa_sa}" -p NAMESPACE="${namespace}" -p PULL_SECRET="${secret}" 
    #$kubernetesCLI process -f "${endpoint_sa}" -p NAMESPACE="${namespace}" -p PULL_SECRET="${secret}" 
    #$kubernetesCLI process -f "${noobaa_role}" -p NAMESPACE="${namespace}" 
    #$kubernetesCLI process -f "${endpoint_role}" -p NAMESPACE="${namespace}" 
    #$kubernetesCLI process -f "${noobaa_role_binding}" -p NAMESPACE="${namespace}" 
    #$kubernetesCLI process -f "${endpoint_role_binding}" -p NAMESPACE="${namespace}" 
    #$kubernetesCLI process -f "${operator_deployment}" -p NAMESPACE="${namespace}"

}

# Install utilizing default CLI method

install_operator_native() {
    # Verfiy arguments are valid
    echo "-------------Installing native-------------"
    echo "[INFO] Operator Native installation is similar to Operator installation."
    echo "[INFO] Continuing with operator install."
    install_operator

}

# install operand custom resources
apply_custom_resources() {
    echo "No action required for this CASE."
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "no catalog"
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"

    local cluster_template_folder="${casePath}/inventory/${inventory}/files/templates"
    local noobaa_cluster_role="${cluster_template_folder}/ClusterRole/namespace.noobaa.io.yaml"
    local noobaa_cluster_role_binding="${cluster_template_folder}/ClusterRoleBinding/namespace.noobaa.io.yaml"
    local noobaa_sa="${cluster_template_folder}/ServiceAccounts/noobaa.yaml"
    local endpoint_sa="${cluster_template_folder}/ServiceAccounts/noobaa-endpoint.yaml"
    local noobaa_role="${cluster_template_folder}/Role/noobaa.yaml"
    local endpoint_role="${cluster_template_folder}/Role/noobaa-endpoint.yaml"
    local noobaa_role_binding="${cluster_template_folder}/RoleBinding/noobaa.yaml"
    local endpoint_role_binding="${cluster_template_folder}/RoleBinding/noobaa-endpoint.yaml"
    local operator_deployment="${cluster_template_folder}/Deployment/operator.yaml"

    validate_file_exists "${noobaa_cluster_role}"
    validate_file_exists "${noobaa_cluster_role_binding}"
    validate_file_exists "${noobaa_sa}"
    validate_file_exists "${endpoint_sa}"
    validate_file_exists "${noobaa_role}"
    validate_file_exists "${endpoint_role}"
    validate_file_exists "${noobaa_role_binding}"
    validate_file_exists "${endpoint_role_binding}"
    validate_file_exists "${operator_deployment}"

    # Delete all after processing template files
    $kubernetesCLI process -f "${operator_deployment}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${endpoint_role_binding}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${noobaa_role_binding}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${endpoint_role}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${noobaa_role}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${endpoint_sa}" -p NAMESPACE="${namespace}" -p PULL_SECRET="${secret}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${noobaa_sa}" -p NAMESPACE="${namespace}" -p PULL_SECRET="${secret}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${noobaa_cluster_role_binding}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI process -f "${noobaa_cluster_role}" -p NAMESPACE="${namespace}" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -

}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    uninstall_operator
}

delete_custom_resources() {
    echo "No action required for this CASE."
}
parse_custom_dynamic_args() {
    echo "No action required for this CASE."
}
