# noobaaOperator

`noobaaOperator` inventory item contains the resources required for installing the Operator for Noobaa. A cluster scoped permissions is required while installing this inventory item since it involves installing cluster resources like crds, clusterroles and clusterrolebindings.
