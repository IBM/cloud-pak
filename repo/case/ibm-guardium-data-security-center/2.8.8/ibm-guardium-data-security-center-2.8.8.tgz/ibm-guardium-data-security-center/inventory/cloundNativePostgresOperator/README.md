# Install the Cloud Native PostgreSQL Operator
This document explains steps to install Cloud Native PostgreSQL Operator (non-OLM flow) which is a prerequisite for GDSC installation.

## Prerequisites
- Target kubernetes/openshift cluster with login details.
- KubernetesCLI/OpenshiftCLI i.e. `kubectl/oc` installed.

## Steps for Installation
- Reference document - https://cloudnative-pg.io/documentation/1.26/installation_upgrade/
- Login into the kubernetes/openshift cluster. Example
```
oc login -u kubeadmin -p xxxxx-xxxxx-xxxxx --server=https://api.gdsc-devops01.cp.fyre.ibm.com:6443
```
- Run the command to apply the manifest with required version, in the example below v1.26.0 is being used as reference. 
```
kubectl apply --server-side -f \
  https://raw.githubusercontent.com/cloudnative-pg/cloudnative-pg/release-1.26/releases/cnpg-1.26.0.yaml
```
- The `cnpg-controller-manager` pod will go into CrashLoopBackOff. Update the deployment for the `cnpg-controller-manager` and remove `runAsGroup` and `runAsUser`.
```
oc edit deploy cnpg-controller-manager -n cnpg-system
```

## How to update new version into the GDSC caseBundle and AnsibleConvert:
Refer - [Cloud Native PostgreSQL Operator Update](/README_CNPG.md)

