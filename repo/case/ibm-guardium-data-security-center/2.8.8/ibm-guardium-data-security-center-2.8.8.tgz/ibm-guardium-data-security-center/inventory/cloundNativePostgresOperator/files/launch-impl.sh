#!/bin/bash
# (C) Copyright IBM Corp. 2023  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this cloundNativePostgresOperator Installation.
 
inventory="cloundNativePostgresOperator" # default inventory item

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --ks_flag)
        ks_flag=$val
        echo "Parsed ks_flag: $ks_flag"
        ;;
    *)
        echo "No action required for this CASE."
        ;;
    esac
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
    echo "no dependent catalogs"
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {
    echo "no operator group"
}

# Installs the catalog source and operator group
install_catalog() {
    echo "no catalog"
}
# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # Check if EKS flag is set
    echo "EKS Flag: ${ks_flag}"

    # Proceed with install
    echo "-------------Installing native-------------"

    # Verify expected yaml files for install exist
    local cluster_resource_folder="${casePath}/inventory/${inventory}/files/resources"
    local crds_folder="${cluster_resource_folder}/CustomResourceDefinitions"

    local cluster_template_folder="${casePath}/inventory/${inventory}/files/templates"
    local cnpg_db_editor_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-database-editor-role.yaml"
    local cnpg_db_viewer_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-database-viewer-role.yaml"
    local cnpg_manager_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-manager.yaml"
    local cnpg_pub_editor_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-publication-editor-role.yaml"
    local cnpg_pub_viewer_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-publication-viewer-role.yaml"
    local cnpg_sub_editor_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-subscription-editor-role.yaml"
    local cnpg_sub_viewer_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-subscription-viewer-role.yaml"
    local cnpg_manager_cluster_role_binding="${cluster_template_folder}/ClusterRoleBinding/cnpg-manager-rolebinding.yaml"
    local cnpg_default_monitoring_cm="${cluster_template_folder}/Configmap/cnpg-default-monitoring.yaml"
    local cnpg_mutating_webhook_config="${cluster_template_folder}/MutatingWebhookConfiguration/cnpg-mutating-webhook-configuration.yaml"
    local cnpg_netpol="${cluster_template_folder}/NetworkPolicy/access-to-cnpg-postgres-operator-webhooks.yaml"
    local cnpg_manager_sa="${cluster_template_folder}/ServiceAccount/cnpg-manager.yaml"
    local cnpg_validating_webhook_config="${cluster_template_folder}/ValidatingWebhookConfiguration/cnpg-validating-webhook-configuration.yaml"

    validate_folder_exists "${crds_folder}"

    validate_file_exists "${cnpg_db_editor_cluster_role}"
    validate_file_exists "${cnpg_db_viewer_cluster_role}"
    validate_file_exists "${cnpg_manager_cluster_role}"
    validate_file_exists "${cnpg_pub_editor_cluster_role}"
    validate_file_exists "${cnpg_pub_viewer_cluster_role}"
    validate_file_exists "${cnpg_sub_editor_cluster_role}"
    validate_file_exists "${cnpg_sub_viewer_cluster_role}"
    validate_file_exists "${cnpg_manager_cluster_role_binding}"
    validate_file_exists "${cnpg_default_monitoring_cm}"
    validate_file_exists "${cnpg_mutating_webhook_config}"
    validate_file_exists "${cnpg_netpol}"
    validate_file_exists "${cnpg_manager_sa}"
    validate_file_exists "${cnpg_validating_webhook_config}"
    
    # Apply EKS-specific configurations if needed
    if [[ "$ks_flag" == "true" ]]; then
        echo "Applying EKS-specific configurations for CNPG operator"
        
        # Check if running on EKS environment
        if ! $kubernetesCLI get deployment -n kube-system metrics-server >/dev/null 2>&1; then
            echo "WARNING: metrics-server not found in kube-system namespace. Some monitoring features may not work properly."
        fi
        
        # Define variables for certificate setup
        local NS="${namespace}"
        local ISSUER_NAME="cnpg-selfsigned-issuer"
        local CA_SECRET="cnpg-ca-cert"
        local EKS_RESOURCES_DIR="${casePath}/inventory/${inventory}/files/eks-resources"
        
        # Validate that all required EKS resource files exist
        echo "Validating EKS resource files..."
        validate_file_exists "${EKS_RESOURCES_DIR}/issuer.yaml"
        validate_file_exists "${EKS_RESOURCES_DIR}/ca-certificate.yaml"
        validate_file_exists "${EKS_RESOURCES_DIR}/webhook-certificate.yaml"
        validate_file_exists "${EKS_RESOURCES_DIR}/controller-config.yaml"
        validate_file_exists "${EKS_RESOURCES_DIR}/service-account.yaml"
        validate_file_exists "${EKS_RESOURCES_DIR}/mutating-webhook.yaml"
        validate_file_exists "${EKS_RESOURCES_DIR}/validating-webhook.yaml"
        
        # Create a self-signed issuer if it doesn't exist
        echo "==> [CNPG] Creating self-signed issuer for certificates"
        sed "s|REPLACE_NAMESPACE|${NS}|g" "${EKS_RESOURCES_DIR}/issuer.yaml" | $kubernetesCLI apply -f -
        
        # Create CA certificate secret if it doesn't exist
        echo "==> [CNPG] Creating CA certificate"
        sed "s|REPLACE_NAMESPACE|${NS}|g" "${EKS_RESOURCES_DIR}/ca-certificate.yaml" | $kubernetesCLI apply -f -
        
        # Wait for CA certificate to be ready
        echo "==> [CNPG] Waiting for CA certificate to be ready..."
        local retries=30
        while [ $retries -gt 0 ]; do
            if $kubernetesCLI get secret "${CA_SECRET}" -n "${NS}" -o jsonpath="{.data.tls\\.crt}" >/dev/null 2>&1; then
                echo "CA certificate is ready"
                break
            fi
            echo "Waiting for CA certificate to be generated... ($retries attempts left)"
            sleep 5
            retries=$((retries - 1))
        done
        
        # Get CA bundle from secret
        echo "==> [CNPG] Reading CA bundle from secret: ${CA_SECRET}"
        local CA_BUNDLE=$($kubernetesCLI -n "${NS}" get secret "${CA_SECRET}" -o jsonpath="{.data.tls\\.crt}" 2>/dev/null || true)
        if [ -z "$CA_BUNDLE" ]; then
            echo "ERROR: Could not read .data.tls.crt from secret/${CA_SECRET} in ${NS}"
            exit 1
        fi
        echo "CA bundle length (base64): ${#CA_BUNDLE}"
        
        # Create webhook certificate
        echo "==> [CNPG] Creating webhook certificate"
        sed "s|REPLACE_NAMESPACE|${NS}|g" "${EKS_RESOURCES_DIR}/webhook-certificate.yaml" | $kubernetesCLI apply -f -
        
        # Create ConfigMap for webhook certificate directory
        echo "==> [CNPG] Creating ConfigMap for webhook certificate directory"
        sed "s|REPLACE_NAMESPACE|${NS}|g" "${EKS_RESOURCES_DIR}/controller-config.yaml" | $kubernetesCLI apply -f -
        
        # Create service account with entitlement key
        echo "==> [CNPG] Creating ServiceAccount with entitlement key reference"
        sed "s|REPLACE_NAMESPACE|${NS}|g" "${EKS_RESOURCES_DIR}/service-account.yaml" | $kubernetesCLI apply -f -
        
        # Create temporary directory for webhook configurations with CA bundle
        local eks_temp_dir="/tmp/cnpg-eks-configs"
        mkdir -p "${eks_temp_dir}"
        
        # Create mutating webhook configuration with CA bundle
        echo "==> [CNPG] Creating mutating webhook configuration with CA bundle"
        local temp_mutating_webhook="${eks_temp_dir}/eks-cnpg-mutating-webhook.yaml"
        sed "s|REPLACE_NAMESPACE|${NS}|g; s|REPLACE_CA_BUNDLE|${CA_BUNDLE}|g" "${EKS_RESOURCES_DIR}/mutating-webhook.yaml" > "${temp_mutating_webhook}"
        cnpg_mutating_webhook_config="${temp_mutating_webhook}"
        
        # Create validating webhook configuration with CA bundle
        echo "==> [CNPG] Creating validating webhook configuration with CA bundle"
        local temp_validating_webhook="${eks_temp_dir}/eks-cnpg-validating-webhook.yaml"
        sed "s|REPLACE_NAMESPACE|${NS}|g; s|REPLACE_CA_BUNDLE|${CA_BUNDLE}|g" "${EKS_RESOURCES_DIR}/validating-webhook.yaml" > "${temp_validating_webhook}"
        cnpg_validating_webhook_config="${temp_validating_webhook}"
        
        # Override the service account path
        cnpg_manager_sa="${EKS_RESOURCES_DIR}/service-account.yaml"
    fi

    if $kubernetesCLI get deployment cnpg-controller-manager -n ${namespace} 2>/dev/null ; then
        $kubernetesCLI delete deployment cnpg-controller-manager -n ${namespace}
    fi
    # Create CRDs
    $kubernetesCLI apply --server-side --force-conflicts ${dryRun} -f "${crds_folder}"

    cat ${cnpg_db_editor_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_db_viewer_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_manager_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_pub_editor_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_pub_viewer_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_sub_editor_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_sub_viewer_cluster_role} |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_manager_cluster_role_binding} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    cat ${cnpg_default_monitoring_cm} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    # Apply webhook configurations - if ks_flag is true, the replacements have already been done
    if [[ "$ks_flag" == "true" ]]; then
        cat ${cnpg_mutating_webhook_config} | $kubernetesCLI apply --server-side --force-conflicts -f -;
    else
        cat ${cnpg_mutating_webhook_config} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    fi
    
    cat ${cnpg_netpol} | sed -e 's#NAMESPACE#'${namespace}'#g' | $kubernetesCLI apply --server-side --force-conflicts -f -;
    
    # Apply service account - if ks_flag is true, use REPLACE_NAMESPACE pattern
    if [[ "$ks_flag" == "true" ]]; then
        cat ${cnpg_manager_sa} | sed -e 's#REPLACE_NAMESPACE#'${namespace}'#g' | $kubernetesCLI apply --server-side --force-conflicts -f -;
    else
        cat ${cnpg_manager_sa} | sed -e 's#NAMESPACE#'${namespace}'#g' | $kubernetesCLI apply --server-side --force-conflicts -f -;
    fi
    
    # Apply validating webhook configuration - if ks_flag is true, the replacements have already been done
    if [[ "$ks_flag" == "true" ]]; then
        cat ${cnpg_validating_webhook_config} | $kubernetesCLI apply --server-side --force-conflicts -f -;
    else
        cat ${cnpg_validating_webhook_config} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI apply --server-side --force-conflicts -f -;
    fi
    
    # Clean up temporary directory if it was created
    if [[ "$ks_flag" == "true" && -d "/tmp/cnpg-eks-configs" ]]; then
        rm -rf "/tmp/cnpg-eks-configs"
    fi
}

# Install utilizing default CLI method

install_operator_native() {
    # Verfiy arguments are valid
    echo "-------------Installing native-------------"
    echo "[INFO] Operator Native installation is similar to Operator installation."
    echo "[INFO] Continuing with operator install."
    install_operator

}

# install operand custom resources
apply_custom_resources() {
    echo "No action required for this CASE."
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "no catalog"
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    
    # Clean up EKS-specific resources if needed
    if [[ "$ks_flag" == "true" ]]; then
        echo "Cleaning up EKS-specific resources for CNPG operator"
        
        local NS="${namespace}"
        local ISSUER_NAME="cnpg-selfsigned-issuer"
        local CA_SECRET="cnpg-ca-cert"
        local EKS_RESOURCES_DIR="${casePath}/inventory/${inventory}/files/eks-resources"
        
        # Delete webhook certificates and related resources
        echo "==> [CNPG] Deleting webhook certificates and related resources"
        $kubernetesCLI delete certificate cnpg-webhook-cert -n "${NS}" --ignore-not-found=true
        $kubernetesCLI delete secret cnpg-webhook-cert -n "${NS}" --ignore-not-found=true
        $kubernetesCLI delete configmap cnpg-controller-manager-config -n "${NS}" --ignore-not-found=true
        
        # Delete CA certificate and issuer
        echo "==> [CNPG] Deleting CA certificate and issuer"
        $kubernetesCLI delete certificate "${CA_SECRET}" -n "${NS}" --ignore-not-found=true
        $kubernetesCLI delete secret "${CA_SECRET}" -n "${NS}" --ignore-not-found=true
        $kubernetesCLI delete issuer "${ISSUER_NAME}" -n "${NS}" --ignore-not-found=true
        
        # Delete webhook configurations
        echo "==> [CNPG] Deleting webhook configurations"
        $kubernetesCLI delete mutatingwebhookconfiguration cnpg-mutating-webhook-configuration --ignore-not-found=true
        $kubernetesCLI delete validatingwebhookconfiguration cnpg-validating-webhook-configuration --ignore-not-found=true
        
        # Delete service account
        echo "==> [CNPG] Deleting service account"
        $kubernetesCLI delete serviceaccount cnpg-manager -n "${NS}" --ignore-not-found=true
        
        echo "==> [CNPG] EKS-specific resources cleanup completed"
    fi

    local cluster_template_folder="${casePath}/inventory/${inventory}/files/templates"
    local cnpg_db_editor_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-database-editor-role.yaml"
    local cnpg_db_viewer_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-database-viewer-role.yaml"
    local cnpg_manager_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-manager.yaml"
    local cnpg_pub_editor_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-publication-editor-role.yaml"
    local cnpg_pub_viewer_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-publication-viewer-role.yaml"
    local cnpg_sub_editor_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-subscription-editor-role.yaml"
    local cnpg_sub_viewer_cluster_role="${cluster_template_folder}/ClusterRole/cnpg-subscription-viewer-role.yaml"
    local cnpg_manager_cluster_role_binding="${cluster_template_folder}/ClusterRoleBinding/cnpg-manager-rolebinding.yaml"
    local cnpg_default_monitoring_cm="${cluster_template_folder}/Configmap/cnpg-default-monitoring.yaml"
    local cnpg_mutating_webhook_config="${cluster_template_folder}/MutatingWebhookConfiguration/cnpg-mutating-webhook-configuration.yaml"
    local cnpg_netpol="${cluster_template_folder}/NetworkPolicy/access-to-cnpg-postgres-operator-webhooks.yaml"
    local cnpg_manager_sa="${cluster_template_folder}/ServiceAccount/cnpg-manager.yaml"
    local cnpg_validating_webhook_config="${cluster_template_folder}/ValidatingWebhookConfiguration/cnpg-validating-webhook-configuration.yaml"

    validate_file_exists "${cnpg_db_editor_cluster_role}"
    validate_file_exists "${cnpg_db_viewer_cluster_role}"
    validate_file_exists "${cnpg_manager_cluster_role}"
    validate_file_exists "${cnpg_pub_editor_cluster_role}"
    validate_file_exists "${cnpg_pub_viewer_cluster_role}"
    validate_file_exists "${cnpg_sub_editor_cluster_role}"
    validate_file_exists "${cnpg_sub_viewer_cluster_role}"
    validate_file_exists "${cnpg_manager_cluster_role_binding}"
    validate_file_exists "${cnpg_default_monitoring_cm}"
    validate_file_exists "${cnpg_mutating_webhook_config}"
    validate_file_exists "${cnpg_netpol}"
    validate_file_exists "${cnpg_manager_sa}"
    validate_file_exists "${cnpg_validating_webhook_config}"

    cat ${cnpg_db_editor_cluster_role} |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_db_viewer_cluster_role} |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_manager_cluster_role} | $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_pub_editor_cluster_role} |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_pub_viewer_cluster_role} |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_sub_editor_cluster_role} |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_sub_viewer_cluster_role} |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_manager_cluster_role_binding} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    cat ${cnpg_default_monitoring_cm} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    # Delete webhook configurations - if ks_flag is true, the replacements have already been done
    if [[ "$ks_flag" == "true" ]]; then
        cat ${cnpg_mutating_webhook_config} | $kubernetesCLI delete --server-side --force-conflicts -f -;
    else
        cat ${cnpg_mutating_webhook_config} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    fi
    
    cat ${cnpg_netpol} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    
    # Delete service account - if ks_flag is true, use REPLACE_NAMESPACE pattern
    if [[ "$ks_flag" == "true" ]]; then
        cat ${cnpg_manager_sa} | sed -e 's#REPLACE_NAMESPACE#'${namespace}'#g' | $kubernetesCLI delete --server-side --force-conflicts -f -;
    else
        cat ${cnpg_manager_sa} | sed -e 's#NAMESPACE#'${namespace}'#g' | $kubernetesCLI delete --server-side --force-conflicts -f -;
    fi
    
    # Delete validating webhook configuration - if ks_flag is true, the replacements have already been done
    if [[ "$ks_flag" == "true" ]]; then
        cat ${cnpg_validating_webhook_config} | $kubernetesCLI delete --server-side --force-conflicts -f -;
    else
        cat ${cnpg_validating_webhook_config} | sed -e 's#NAMESPACE#'${namespace}'#g' |  $kubernetesCLI delete --server-side --force-conflicts -f -;
    fi
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    uninstall_operator
}

delete_custom_resources() {
    echo "No action required for this CASE."
}

