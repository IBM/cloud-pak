# Introduction

IBM Cloud Pak for Data Watson Studio provides the environment and tools for you to collaboratively work on data to solve your business problems. You can choose the tools you need to analyze and visualize data, to cleanse and shape data, to ingest streaming data, or to create and train machine learning models.

The architecture of Watson Studio is centered around the analytics project. Data scientists and business analysts use analytics projects to organize resources and analyze data.
You can have these types of resources in a project:
- Collaborators are the people on the team who work with the data.
- Data assets point to your data that is either in uploaded files or accessed through connections to data sources.
- Operational assets are the objects you create, such as scripts and models, to run code on data.
- Tools are the software you use to derive insights from data. RStudio IDE is one of the tools supported in Watson Studio.
R is a popular statistical analysis and machine-learning package that includes tests, models, analyses, and graphics, and enables data management. RStudio IDE provides an IDE for working with R.

# Link To External Documentation
See [RStudio runtimes for Watson Studio](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.5?topic=36-installing-rstudio-server-r)
### SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
See [Custom security context constraints for services](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.5?topic=installing)
### PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```
