# Name

IBM&reg; Data Refinery 

# Introduction

Use Data Refinery to prepare and visualize tabular data.

## Summary

The Data Refinery service reduces the amount of time it takes to prepare data. Use pre-defined operations in data flows to transform large amounts of raw data into consumable, quality data that’s ready for analysis. 

## Features

With Data Refinery you can do the following tasks:
* Interactively discover, cleanse, and transform your data with over 100 built-in operations. No coding is required.
* Understand the quality and distribution of your data using dozens of built-in charts, graphs, and statistics.
* Schedule data flow executions for repeatable outcomes.

# Details

## Prerequisites

IBM Data Refinery requires the following 
- IBM Cloud Pak for Data Common Core Services version 1.0.0 or later
- cloudctl binary

### Resources Required

IBM Data Refinery includes front-end micro-services and runtime. Micro-services are constantly running on the cluster, while a runtime is only spawned when a user refines data. Resources for runtime will be reclaimed after data refining is completed.

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Micro-services | 4      | 1           |           |       |
| Runtime   | 2           | 0.2         |           |       |
| **Total** | 6           | 1.2         |           |       |

## Installing

The Data Refinery service is not separately installable. The Data Refinery service is installed when you install either the Watson Studio service or the Watson Knowledge Catalog service.


IBM Cloud Pak for Data platform installation documentation:
https://www.ibm.com/docs/en/SSQNUZ_4.0/cpd/install/install.html

If you have already completed the Cloud Pak for Data setup and installation, see the following  service documentation:

Watson Knowledge Catalog installation documentation:
https://www.ibm.com/docs/en/SSQNUZ_4.0/wsj/install/install-wkc.html

Watson Studio installation documentation:
https://www.ibm.com/docs/en/SSQNUZ_4.0/wsj/install/install-ws.html

## Configuration

Default scale for Data Refinery is `small`. Update the scaleConfig by changing the `spec.scaleConfig` value in Data Refinery CR.

## Storage

IBM Data Refinery supports dynamic storage provisioning using storage class.  The following storages are supported
- NFS
- Portworx 2.7 
- OCS

## Limitations

Only one instance of IBM Data Refinery operator can be deployed in a cluster. Multiple instances of Data Refinery operands can be deployed in different namespaces in a cluster.

## PodSecurityPolicy Requirements

The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements

The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restrict
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

