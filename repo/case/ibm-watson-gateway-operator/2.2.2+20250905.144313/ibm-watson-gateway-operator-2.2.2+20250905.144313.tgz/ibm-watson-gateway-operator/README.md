# IBM Watson Gateway Operator

![operator-version](https://img.shields.io/badge/operator_version-v1.0.4-green.svg) ![gateway-version](https://img.shields.io/badge/gateway_version-v3.7.8-green.svg)

# Introduction

This case deploys the watson gateway operator to the IBM Cloud Pak for Data environment, allowing users to manage Watson service instances and access the tooling.

## Details

The Docker image includes:

- Watson Add-on: Adds an add-on to the Cloud Pak for Data add-ons page in the AI category
- Ingress and authorization configuration for tooling: `/<release-name>/<service-name>`
- Ingress configuration for API: `/<release-name>/<service-name>/<service-instance>/instances/api`
- IBM Cloud Account and Resource Controller API mocks (to be used by tooling)
- Injects `X-Watson-UserInfo` to the API requests: `/<release-name>/<service-name>/instances/<service-instance>/api`

### Namespace scoping
The gateway operator supports namespace scoped install rather than a complete cluster install.

```
env:
- name: WATCH_NAMESPACE
  valueFrom:
    fieldRef:
      fieldPath: metadata.annotations['olm.targetNamespaces']
- name: POD_NAME
  valueFrom:
    fieldRef:
      fieldPath: metadata.name
- name: OPERATOR_NAME
  value: "gateway-operator"
```

# Prerequisites

- IBM Cloud Pak for Data 4.5.0 or later
- Kubernetes 1.18 or later
- `watson-gateway` docker image

# Resources Required

# Installing
Steps to install via OLM catalog:
1. \$ oc create -f stable/ibm-watson-gateway-operator-case-bundle/case/ibm-watson-gateway-operator/inventory/ibmWatsonGatewayOperatorSetup/files/op-olm/catalog_source.yaml
1. Replace the Channel name as v1.0 and namespace in stable/ibm-watson-gateway-operator-case-bundle/case/ibm-watson-gateway-operator/inventory/ibmWatsonGatewayOperatorSetup/files/op-olm/subscription.yaml
1. \$ oc create -f stable/ibm-watson-gateway-operator-case-bundle/case/ibm-watson-gateway-operator/inventory/ibmWatsonGatewayOperatorSetup/files/op-olm/subscription.yaml
1. If there is no operator group available in the same namespace then create the operator group as well \$ oc create -f stable/ibm-watson-gateway-operator-case-bundle/case/ibm-watson-gateway-operator/inventory/ibmWatsonGatewayOperatorSetup/files/op-olm/operator_group.yaml
1. \$ oc create -f stable/ibm-watson-gateway-operator-case-bundle/case/ibm-watson-gateway-operator/inventory/ibmWatsonGatewayOperatorSetup/files/op-olm/watson-gateway_v1_watsongateway.yaml

## Operator

| Container       | Memory Request | Memory Limit | CPU Request | CPU Limit |
| --------------- | -------------- | ------------ | ----------- | --------- |
| gaeway-operator | 512Mi          | 1024Mi       | 100m        | 800m      |

## Watson Gateway

| Container      | Memory Request | Memory Limit | CPU Request | CPU Limit |
| -------------- | -------------- | ------------ | ----------- | --------- |
| watson-gateway | 128Mi          | 512Mi        | 100m        | 500m      |

## Pre-install steps

The gateway doesn't have pre-requisites.


## Configuration

All the parameters can be seen in the CRD definition.

### NGINX configuration

The following headers will be set by default as part of the nginx configuration, you can use `nginxDirectives` to set other directives

```nginx
proxy_set_header  Host $host;
proxy_set_header  X-Real-IP $remote_addr;
proxy_set_header  X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header  X-Forwarded-Proto $scheme;
```

### WebSockets

Adding support for WebSockets can be done using the `nginxDirectives`.

```yaml
nginxDirectives:
  - "proxy_http_version 1.1;"
  - "proxy_set_header Upgrade $http_upgrade;"
  - 'proxy_set_header Connection "upgrade";'
```

## Network Policy Requirements

Network Policy use will be up to the adopting service, as it must run in the same namespace that the service is running in, which is not necessarily the CPD namespace.  

## PodSecurityPolicy Requirements

NA

## Red Hat OpenShift SecurityContextConstraints Requirements

This chart requires a `SecurityContextConstraints` to be bound to the target namespace prior to installation. To meet this requirement there may be cluster scoped as well as namespace scoped pre and post actions that need to occur.

The predefined `SecurityContextConstraints` name: [`ibm-restricted-scc`](https://ibm.biz/cpkspec-scc) has been verified for this chart, if your target namespace is bound to this `SecurityContextConstraints` resource you can proceed to install the chart.

Custom SecurityContextConstraints definition:

```yml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy is the most restrictive,
      requiring pods to run with a non-root UID, and preventing pods from accessing the host."
    cloudpak.ibm.com/version: "1.0.0"
  name: ibm-restricted-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: false
allowedCapabilities: []
allowedFlexVolumes: []
allowedUnsafeSysctls: []
defaultAddCapabilities: []
defaultPrivilegeEscalation: false
forbiddenSysctls:
  - "*"
fsGroup:
  type: MustRunAs
  ranges:
    - max: 65535
      min: 1
readOnlyRootFilesystem: false
requiredDropCapabilities:
  - ALL
runAsUser:
  type: MustRunAsNonRoot
seccompProfiles:
  - docker/default
seLinuxContext:
  type: RunAsAny
supplementalGroups:
  type: MustRunAs
  ranges:
    - max: 65535
      min: 1
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
priority: 0
```

## Scope of the Operator
This operator by default is namespace scoped. This can be used with ibm namespace scoped operator to support installing in different namespaces.

Supported Install modes:

- Single Namespace
- Same Namespace
- Declared Namespace
- All Namespaces

## Limitations

- Watson Gateway only runs on Intel architecture nodes.
- This chart should only use the default image tags provided with the chart. Different image versions might not be compatible with different versions of this chart.

_Copyright© IBM Corporation 2021. All Rights Reserved._
