# IBM DataStax Enterprise CPE CASE

Cloud Pak Extension (CPE) CASE package for publishing IBM DataStax Enterprise container images to production registry.

## Purpose

This CASE package is used exclusively for image publication through the CPE delivery pipeline. It does **not** include Helm charts or deployment manifests.

## Key Differences from SWH CASE

- **Image-only**: No Helm charts included
- **Production coordinates**: Uses `cp.icr.io/cp/ibm-datastax-enterprise/*` registry

## Images

| Image | Tag |
|-------|-----|
| `cp.icr.io/cp/ibm-datastax-enterprise/dse-server` | `<version>-ubi` |
| `cp.icr.io/cp/ibm-datastax-enterprise/dse-server-core` | `<version>-ubi` |

