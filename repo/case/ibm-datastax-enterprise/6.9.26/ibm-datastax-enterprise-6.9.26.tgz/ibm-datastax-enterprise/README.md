# IBM DataStax Enterprise CPE CASE

Cloud Pak Extension (CPE) CASE package for publishing IBM DataStax Enterprise container images to production registry.

## Purpose

This CASE package is used exclusively for image publication through the CPE delivery pipeline. It does **not** include Helm charts or deployment manifests.

## Images

| Image | Tag |
|-------|-----|
| `cp.icr.io/cp/ibm-datastax-enterprise/dse-server` | `6.9.26-ubi` |
| `cp.icr.io/cp/ibm-datastax-enterprise/dse-server-core` | `6.9.26-ubi` |

## Generating the Bundle

See `../generate-case-resources.sh` to populate `resources.yaml` with live digests, then package with:

```bash
cd dse-case-bundle/case
tar zchf ibm-datastax-enterprise-6.9.26.tgz ibm-datastax-enterprise
```
