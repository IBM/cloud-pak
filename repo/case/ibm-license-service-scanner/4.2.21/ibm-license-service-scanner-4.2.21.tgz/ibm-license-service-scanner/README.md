# Name

IBM License Service Scanner&reg;

# Introduction

https://ibmdocs-test.dcs.ibm.com/docs/en/module_1710150398004

<!-- ## Summary

https://www.ibm.com/docs/en/cpfs?topic=operator-overview -->

<!-- ## Features

https://www.ibm.com/docs/en/cpfs?topic=operator-reported-metrics -->

# Details

<!-- ## Prerequisites -->

<!-- ### Resources Required

https://www.ibm.com/docs/en/cpfs?topic=operator-overview -->

# Installing

https://ibmdocs-test.dcs.ibm.com/docs/en/module_1710150398004?topic=scanner-installing-license-service

## Configuration

https://ibmdocs-test.dcs.ibm.com/docs/en/module_1710150398004?topic=scanner-configuring-license-service

<!-- ## Limitations

https://www.ibm.com/docs/en/cpfs?topic=operator-reported-metrics -->


## Documentation

https://ibmdocs-test.dcs.ibm.com/docs/en/module_1710150398004

<!-- # SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```yaml
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
``` -->