# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh


caseName="/ibm-aiopsedge-bundle"
caseCatalogName="ibm-aiopsedge-case"
catalogNamespace="openshift-marketplace"
inventory="aiopsedge"
caseSubscriptionName="aiopsedge-operator-catalog-subscription"
channelName="v3.6"
recursive_action=1
case_dependencies="ibm-cp-common-services ibm-vault-operator"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-cp-common-services)
        echo "ibmCommonServiceOperatorSetup"
        return 0
        ;;
    ibm-vault-operator)
        echo "ibmVaultOperatorSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    $kubernetesCLI delete catsrc opencloud-operators -n ${catalogNamespace} --ignore-not-found=true
    $kubernetesCLI delete catsrc ibm-vault-operator-catalog -n ${catalogNamespace} --ignore-not-found=true

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        # Figure out what to use for --registry.  Some CASEs require this
        # parm and some don't.
        registryParam="--registry ${registry}"
        if [[ -z $registry ]]; then
          registryParam="--registry icr.io"
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registryParam} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# ----- INSTALL ACTIONS -----

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed "s|REPLACE_NAMESPACE|${namespace}|g" "${opgrp_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source
install_catalog() {

    validate_install_catalog
    $kubernetesCLI delete catsrc ${caseCatalogName} -n ${catalogNamespace} --ignore-not-found=true
    #swag

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed "${catsrc_file}" -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}


# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_files="${casePath}/inventory/${inventory}/files/catalog_source.yaml"

    for catsrc in $catsrc_files; do
        echo "-------------Uninstalling catalog source-------------"
        $kubernetesCLI delete -f "${catsrc}" --ignore-not-found=true ${dryRun}
    done
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/aiopsedge_v1beta1_aiopsedge.yaml

    validate_file_exists "$cr"

    sed -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscriptions.operators.coreos.com "${caseSubscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscriptions.operators.coreos.com "${caseSubscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/aiopsedge_v1beta1_aiopsedge.yaml

    validate_file_exists "$cr"

    sed -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
