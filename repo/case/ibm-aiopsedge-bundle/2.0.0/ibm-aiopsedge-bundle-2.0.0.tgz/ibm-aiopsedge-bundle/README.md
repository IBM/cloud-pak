# Name
IBM&reg; AIOps Edge Operator
# Introduction
## Details
The `aiopsedge-operator` manages the connector related components of the IBM&reg; Cloud Pak for Watson AIOps. This
operator sets up a camel k platform, a vault access point, kafka, and data collectors to pull in data from various
sources.
## Prerequisites
Before you create an `AIOpsEdge` instance, complete the following tasks. For more information about these tasks, see
[Preparing to install IBM Cloud Pak for Watson AIOps](https://ibm.biz/cpwaiops_prereqs).
- Configure a block storage class
- Create a custom namespace
- Create the entitlement key secret
- Apply the network policy for the IBM&reg; Cloud Pak for Watson AIOps routes
- Create the IBM&reg; Cloud Pak for Watson AIOps catalog source(s)
- Assess compatibility with any other IBM&reg; Cloud Pak solutions that are installed on the cluster
### Resources Required:
For resource requirements, visit the [IBM&reg; Documentation](https://ibm.biz/cpwaiops_36x_install)
### SecurityContextConstraints Requirements:
The operator and most of the workloads it deploys run with the `restricted` security context constraint (SCC). The
exception to this rule are the camel based workloads which rely on OpenShift's build functionality and are built with
pods using the `privileged` SCC.

This Operator also defines a custom SecurityContextConstraints object which is used to finely control the permissions
and capabilities needed to deploy this Operator, the definition of this SCC is shown below:
#### Custom SecurityContextConstraints definition:
```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: ibm-aiopsedge-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
 groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
## Cluster Permissions Requested
The operator requests the following elevated permissions when installed for the following reasons:
- storageclasses.storage.k8s.io (view): used to auto detect the storage class and validate that the storage class exists
- clusterversions.config.openshift.io (view): used to retrieve an id that is unique to the cluster
- ingresses.config.openshift.io (view): used to determine the router URL for exposed OpenShift routes
- customresourcedefinitions.apiextensions.k8s.io (view): used to determine and wait for the presence of required operators
- ingresscontrollers.operator.openshift.io named `default` (view): used to detect a networking edge case
- namespaces named `default` (view): used to detect a networking edge case
- configmaps named `console-config` (view): used to retrieve the external openshift api route
- dnses.operator.openshift.io (view): used to determine the internal cluster domain
# Installing
For detailed installation instructions, visit the [IBM&reg; Documentation](https://ibm.biz/cpwaiops_36x_install)
## OLM Operator Scope
The operator only supports being installed using `Own Namespace Mode`.
## Configuration
Set parameters as desired when creating the `AIOpsEdge` resource.
```
apiVersion: connectors.aiops.ibm.com/v1beta1
kind: AIOpsEdge
metadata:
  name: aiopsedge
  namespace: aiopsedge
spec:
  license:
    accept: true
  size: medium
  storageClass: rook-ceph-block
```
## Storage
Block storage is sufficient for the operands this operator deploys. For more details refer to
[Preparing to install IBM Cloud Pak for Watson AIOps](https://ibm.biz/cpwaiops_prereqs).
## Limitations
- Only one `AIOpsEdge` instance can be installed per namespace.
- Openshift 4.6 or later
- Linux x86_64
