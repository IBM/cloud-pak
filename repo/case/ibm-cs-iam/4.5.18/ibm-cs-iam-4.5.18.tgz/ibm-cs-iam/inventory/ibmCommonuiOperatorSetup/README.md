# Introduction
The IBM Common UI operator installs the Common UI as part of IBM Common services.
Only install this operator using the IBM Common Services Operator. For more information about installing this operator and other Common Services operators, see [Installer documentation](http://ibm.biz/cpcs_opinstall).
## Details
### Configuration
## Installing
> **Important:** Do not install this operator directly. Only install this operator using the IBM Common Services Operator. For more information about installing this operator and other Common Services operators, see [Installer documentation](http://ibm.biz/cpcs_opinstall).
> If you are using this operator as part of an IBM Cloud Pak, see the documentation for that IBM Cloud Pak to learn more about how to install and use the operator service. For more information about IBM Cloud Paks, see [IBM Cloud Paks that use Common Services](http://ibm.biz/cpcs_cloudpaks).

You can use the ibm-commonui-operator to install the Common Web UI service for the IBM Cloud Platform Common Services and access the Common Web UI console. You can use the Common Web UI console to access information and features from other IBM Cloud Platform Common Services or IBM Cloud Paks that you install.

For more information about the available IBM Cloud Platform Common Services, see the [IBM Knowledge Center](http://ibm.biz/cpcsdocs).

# Limitations
* Deployment limits - You can only deploy this in the namespace set by the Common service operator
* Although the Common UI can be deployed in multiple namespaces, it should not be deployed outside of the namespace `ibm-common-services`. We communicate with services that live in that namespace.
* List deployment limitations such as : restrictions on deploying more than once or into custom namespaces.

## Prerequisites
The Common Web UI service has dependencies on other IBM Cloud Platform Common Services. Before you install this operator, you need to first install the operator dependencies and prerequisites:

- For the list of operator dependencies, see the IBM Knowledge Center [Common Services dependencies documentation](http://ibm.biz/cpcs_opdependencies).

- For the list of prerequisites for installing the operator, see the IBM Knowledge Center [Preparing to install services documentation](http://ibm.biz/cpcs_opinstprereq).

### Resources Required

* This limit describes the sizing requirements for installing default common services

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |    19.139   |      5.59   |    90     |    4  |
| **Total** |             |             |           |       |

# PodSecurityPolicy Requirements

# SecurityContextConstraints Requirements
The Common UI service supports running with the OpenShift Container Platform 4.3 default restricted Security Context Constraints (SCCs).

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints.](https://docs.openshift.com/container-platform/4.3/authentication/managing-security-context-constraints.html)
