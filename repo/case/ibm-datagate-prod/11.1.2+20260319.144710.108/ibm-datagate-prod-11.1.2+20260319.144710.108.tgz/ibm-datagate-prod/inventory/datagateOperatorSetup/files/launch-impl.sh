#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Script install Couchdb Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI)
# application of kubernetes manifests in both an online and offline airgap environment.  This script can be invoked using
# `cloudctl`, a command line tool to manage Container Application Software for Enterprises (CASEs), or directly on an
# uncompressed CASE archive.  Running the script through `cloudctl case launch` has added benefit of pre-requisite validation
# and verification of integrity of the CASE.  Cloudctl download and usage istructions are available at [github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli).
#
# Pre-requisites:
#   oc or kubectl installed
#   sed installed
#   CASE tgz downloaded & uncompressed
#   authenticated to cluster
#
# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="install-operator-native"
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName="ibm-datagate-prod"
inventory="datagateOperatorSetup"
instance=""

# - optional parameter / argument defaults
dryRun=""
deleteCRDs=0
namespace=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
cr_system_status="betterThanYesterday"

# - variables specific to catalog/operator installation
caseCatalogName="ibm-datagate-operator-catalog"
caseCatalogSubscriptionName="ibm-datagate-operator-subscription"
caseOperatorGroupName="ibm-datagate-operator-group"
catalogNamespace="openshift-marketplace"
csvName="ibm-datagate-operator.v1.0.254"
channelName="v1.0"
catalogDigest=":latest"

# - additional variables
WEBHOOK_ENABLED_CPD="${WEBHOOK_ENABLED_CPD:-true}"
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-datagate-operator}"
OPERATOR_TAG="${OPERATOR_TAG:-v1.0.1-x86_64}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-cp.stg.icr.io/cp}"
entitledSecret="ibm-datagate-operator-secret"
entitledRegistry="cp.stg.icr.io/cp"
storageclass=""
size=""

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    skip_actions="imageInfo mirrorImages configureCredsAirgap initRegistry startRegistry stopRegistry"
    if [[ "$skip_actions" != *$action* ]]; then
        check_kube_connection
        check_kube_namespace
    fi

    # Verify dynamic args are valid (show as any issues on invocation as possible)
    parse_dynamic_args
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"

    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --deleteCRDs)
            deleteCRDs=1
            ;;
        --channelName)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            channelName="${v}"
            ;;
        --catalogDigest)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            catalogDigest="@${v}"
            ;;
        --registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry="${v}"
            ;;
        --pullPrefix)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pullPrefix="${v}"
            ;;
        --from-registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            mirrorSource="${v}"
            ;;
        --entitledRegistry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledRegistry="${v}"
            ;;
        --inputDir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            inputcasedir="${v}"
            ;;
        --user)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            user="${v}"
            ;;
        --entitledUser)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledUser="${v}"
            ;;
        --pass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pass="${v}"
            ;;
        --entitledPass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledPass="${v}"
            ;;
        --secret)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            secret="${v}"
            ;;
        --systemStatus)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            cr_system_status="${v}"
            ;;
        --recursive)
            recursive_action=1
            ;;
        --help)
            print_usage 0
            ;;
        --storageclass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            storageclass=${v}
            ;;
        --scaleConfig)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            size=${v}
            ;;
        --fromRegistry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            src_registry="${v}"
            ;;
         --chunks)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            mirror_image_chunks="${v}"
            ;;
        --groups)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            image_groups="${v}"
            ;;
        --skipDelta)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            skip_delta="${v}"
            ;;
        # flags related to starting/stopping local docker registry
        --subject)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_subject="${v}"
            ;;
        --dir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_dir="${v}"
            ;;
        --image)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_image="${v}"
            ;;
        --engine)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_engine="${v}"
            ;;
        --port)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_port="${v}"
            ;;
        --clean)
            registry_clean=1
            ;;
        *)
            err_exit "Invalid Option ${v}" >&2
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

check_entitled_secret_params() {

    local foundError=0

    [[ -z ${entitledRegistry} ]] && {
        foundError=1
        err "'--entitledRegistry' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledUser} ]] && {
        foundError=1
        err "'--entitledUser' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledPass} ]] && {
        foundError=1
        err "'--entitledPass' is required for creating a entitled registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

# Validates that the required args were specified for install action
validate_install_args() {
    # Verify arguments required per install method were provided
    echo "Checking install arguments"

    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]]; then
        check_secret_params
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    fi

    if [[ -n "${entitledUser}" || -n "${entitledPass}" ]]; then
        check_entitled_secret_params
        if $kubernetesCLI get secrets "${entitledSecret}" -n "${namespace}" >/dev/null 2>&1; then
            echo "Secret ${entitledSecret} already exists, skipping create"
            secret=${entitledSecret}
        else
            set -e
            $kubernetesCLI create secret docker-registry "${entitledSecret}" \
                --docker-server="${entitledRegistry}" \
                --docker-username="${entitledUser}" \
                --docker-password="${entitledPass}" \
                --docker-email="${entitledUser}" \
                --namespace "${namespace}"
            secret=${entitledSecret}
            set +e
        fi
    fi

    if [[ -n "${pullPrefix}" ]];then
        entitledRegistry=${pullPrefix}
    fi
}

validate_configure_cluster_airgap_native_args() {
# Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}


# ***** END ARGUMENT CHECKS *****

# ***** UTILS *****

assert() {
    testname="$1"
    got=$2
    want=$3
    if [ "$got" != "$want" ]; then
        err_exit "got $got, but want $want : ${testname} failed"
    fi
}
# ***** END UTILS *****

# ***** ACTIONS *****

# ----- CONFIGURE ACTIONS -----

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap_native() {

    echo "-------------Configuring cluster for airgap native-------------"

    validate_configure_cluster_airgap_native_args

    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
       echo "Secret ${secret} already exists, skipping create"
    else
       set -e
       $kubernetesCLI create secret generic "${secret}" \
       --from-literal=url="${registry}" \
       --from-literal=user="${user}" \
       --from-literal=key="${pass}" \
       --namespace "${namespace}"
       set +e
    fi

    OPERATOR_IMAGE_FULL_PATH=${registry}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    sed -i -- "s#icr.io/cpopen#${OPERATOR_IMAGE_FULL_PATH}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
}

# ----- INSTALL ACTIONS -----

install_dependent_catalogs() {
    echo "-------------Installing dependent catalogs-------------"

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "No dependent operators now"
}

# Uninstalls the operators (native) of any dependencies
uninstall_dependent_operators() {
    echo "No dependent operators now"
}

install_operator_group() {
    echo "------------- Installing operator group for $namespace -------------"
    local operator_group_file="${casePath}/inventory/${inventory}/files/deploy/install/operator-group.yaml"
    validate_file_exists "${operator_group_file}"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        sed <"${operator_group_file}" "s|ibm-datagate-operator-namespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi

}

# Installs the catalog source and operator group
install_catalog() {
    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "Wait for catalog installation to complete"
    sleep 30
    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    echo "-------------Installing via OLM-------------"

    # Verfiy arguments are valid
    validate_install_args

    # Install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    # Install operator group
    install_operator_group

    # Check if catalog source is installed; Might to be delete after getting into ibm-operator-catalog
    echo "Checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        echo "Can't find the catalog source. Attemp to install catalog source"
        install_catalog
    else
        echo "Found catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    local subscription_file="${casePath}/inventory/${inventory}/files/deploy/install/subscription.yaml"
    validate_file_exists "${subscription_file}"

    sed <"${subscription_file}" "s|ibm-datagate-operator-namespace|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "Wait for subscription to complete"
	sleep 60

}

# Install utilizing default CLI method
install_operator_native() {
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    if $kubernetesCLI get deploy --all-namespaces | grep -w ibm-datagate-operator > /dev/null 2>&1;then
        echo "ibm-datagate-operator already deployed"
        exit 1
    fi

    echo "Install Operator Native..."
    sed -i "s#icr.io/cpopen#${OPERATOR_REGISTRY}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    sed -i "s#WEBHOOK_ENABLED_CPD#false#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    #sed -i -- "s#\"ENTITLED_REGISTRY\"#\"${entitledRegistry}\"#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    # replace registry if provided, default registry for csv deployment
    sed -i "s#image: .*\/#image: ${entitledRegistry}\/#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    sed -i "s#ibm-datagate-operator-namespace#${namespace}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml
    sed -i "s#ibm-datagate-operator-namespace#${namespace}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml

    # remove pullPrefix from case, replace tag with digest
    # if [[ -z "${pullPrefix}" ]];then
    #     image=$(grep "image: " "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml | sed "s/image: .*\/\(.*\)/\1/g")
    #     imageName=$(echo $image | awk -F: '{print $1}')
    #     imageTag=$(echo $image | awk -F: '{print $2}')
    #     change from metainv to "${inventory}" done by Prabhu
    #     imageDigest=$(grep "image: $imageName$" "${casePath}"/inventory/"${inventory}"/resources.yaml -B 1 | grep digest | awk -F": " '{print $2}')
    #     if [[ -z "$imageDigest" ]];then
    #         echo "failed to get image digest"
    #         exit 1
    #     fi
    #     sed -i -- "s#\(image: .*\):.*#\1@${imageDigest}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    # fi

    echo "pre install"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/datagate.cpd.ibm.com_datagateinstanceservices.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/datagate.cpd.ibm.com_datagateservices.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml  -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml  -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml  -n ${namespace}

    if [[ "$secret" != "" ]]; then
       $kubernetesCLI secrets link ibm-datagate-operator-serviceaccount ${secret} --for=pull -n ${namespace}
    fi

    echo "installing operator"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    # todo (fanjing) --- no sample yaml file
    local cr="${casePath}"/inventory/"${inventory}"/files/datagate_v1_datagateservice.yaml

    validate_file_exists "$cr"

    if [[ -z ${storageclass} ]]; then
        echo "storageclass is empty, set to default: managed-nfs-storage"
        storageclass="managed-nfs-storage"
    fi

    if [[ -z ${size} ]]; then
        echo "size is empty, set to default: small"
        size="small"
    fi

    sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" -e "s|^\([ \t].*scaleConfig:\).*|\1 ${size}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

}

run_adm(){
    echo "***run adm in ${namespace}: to be removed after security hardening***"

    $kubernetesCLI apply -n ${namespace} -f "${casePath}"/inventory/"${inventory}"/files/deploy/adm.yaml
    $kubernetesCLI adm policy add-scc-to-user cpd-user-scc system:serviceaccount:${namespace}:cpd-viewer-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-user-scc system:serviceaccount:${namespace}:cpd-editor-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-zensys-scc system:serviceaccount:${namespace}:cpd-admin-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-noperm-scc system:serviceaccount:${namespace}:cpd-norbac-sa
}

remove_adm(){
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/adm.yaml
    $kubernetesCLI adm policy remove-scc-from-user cpd-user-scc system:serviceaccount:${namespace}:cpd-viewer-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-user-scc system:serviceaccount:${namespace}:cpd-editor-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-zensys-scc system:serviceaccount:${namespace}:cpd-admin-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-noperm-scc system:serviceaccount:${namespace}:cpd-norbac-sa
}
# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "-------------Uninstalling dependent catalogs-------------"
    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "-------------Uninstalling catalog-------------"

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}

}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling Operator-------------"

    # Delete instance crds
    delete_custom_instance_resources

    # # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogSubscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n ${namespace} --ignore-not-found=true)
    # # Remove the Cluster Service Version - CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n ${namespace} --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseOperatorGroupName}" -n "${namespace}" --ignore-not-found=true

    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogSubscriptionName}" -n ${namespace} --ignore-not-found=true ${dryRun}

    # Don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseOperatorGroupName}" -n "${namespace}" --ignore-not-found=true

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}

    # Delete crds
    delete_custom_resources

    # Delete other datagate resource
    delete_resources

    # delete installplan
    if [ -n "${csvName}" ]; then
      installplanName=$($kubernetesCLI get installplan -n ${namespace} --no-headers|grep $csvName|cut -d' ' -f1|head -1)
    fi

    if [ -n "${installplanName}" ]; then
      $kubernetesCLI delete installplan "${installplanName}" -n "${namespace}" --ignore-not-found=true ${dryRun};
    fi

}

# Uninstall operator installed via CLI
uninstall_operator_native() {

    echo "-------------Uninstall operator native-------------"
    # Delete instance crds
    delete_custom_instance_resources

    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace} ${dryRun}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml -n ${namespace} ${dryRun}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml -n ${namespace} ${dryRun}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml -n ${namespace} ${dryRun}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml -n ${namespace} ${dryRun}

    delete_custom_resources

    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace} ${dryRun}

    delete_resources

}

delete_resources() {

    echo "-------------Deleting operator resources-------------"
    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
        $kubernetesCLI delete secret "${secret}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    fi
    # $kubernetesCLI delete secret ibm-entitlement-key --ignore-not-found=true #Not sure why we need it here.

    echo "-------------  cleanup datagate runtime pods and sa  ---------------"
    if $kubernetesCLI get deployment -n ${namespace} | grep -i ibm-datagate-operator >/dev/null 2>&1; then
      $kubernetesCLI get deployment -n ${namespace} | grep -i ibm-datagate-operator | awk '{print $1}' | xargs $kubernetesCLI delete deployment -n ${namespace} --ignore-not-found=true ${dryRun}
    fi

    if $kubernetesCLI get sa -n ${namespace} | grep -i ibm-datagate-operator >/dev/null 2>&1; then
      $kubernetesCLI get sa -n ${namespace} | grep -i ibm-datagate-operator | awk '{print $1}' | xargs $kubernetesCLI delete sa -n ${namespace} --ignore-not-found=true ${dryRun}
    fi
    echo "-------------cleanup datagate secrets and pvcs-------------"


}

delete_custom_resources() {
     echo "-------------Uninstall custom resources-------------"
     $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/datagate.cpd.ibm.com_datagateservices.yaml --ignore-not-found=true -n ${namespace} ${dryRun}
}

delete_custom_instance_resources() {
     echo "-------------Uninstall custom instance resources-------------"
     $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/datagate.cpd.ibm.com_datagateinstanceservices.yaml --ignore-not-found=true -n ${namespace} ${dryRun}
}

install_olm() {
    install_operator
}

uninstall_olm() {
    uninstall_operator
}
