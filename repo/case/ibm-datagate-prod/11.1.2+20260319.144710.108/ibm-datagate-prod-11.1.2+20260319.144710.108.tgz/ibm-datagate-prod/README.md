# Name

IBM Db2 for z/OS Data Gate

# Introduction

The IBM Db2 for z/OS Data Gate service extracts, loads, and synchronizes your mission-critical data from Db2 for z/OS to Cloud Pak for Data for quick access by your new, high volume, read-only transactional and analytic applications.

The service propagates your data from a Db2 for z/OS source on IBM Z to a target database on Cloud Pak for Data. You can choose your target database based on your business needs. For example, you might set up Db2 as your target database for your new high-intensity transactional workloads, such as mobile banking applications. Or, you might set up Db2 Warehouse as your target database for your analytic or AI workloads.

for more information, refer to:
https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=services-db2-data-gate

## Features

The Db2 Data Gate service uses an integrated data synchronization protocol to ensure that your data is current, consistent, and secure. The fully zIIP-enabled synchronization protocol is lightweight, high throughput, and low latency protocol. It offers fast access to your data (close to real-time) without degrading the performance of your core transaction engine.

Compared to any custom-built solution, the Db2 Data Gate service reduces the cost and complexity of your application development. By using this service to synchronize and access your enterprise data on Cloud Pak for Data, a cloud-native solution, you can reduce your operational cost while accelerating your journey to the cloud and AI.

Here is the list of features that Db2 Data Gate provided,
* Updating a source definition for Db2 Data Gate. You must connect to a data source to give Db2 Data Gate access to the original data in Db2 for z/OS®. You define a data source when you create (provision) an instance for the first time. This data source can be changed at a later time.
* Adding tables to Db2 Data Gate. From the dashboard, you can always add tables to your configured Db2 Data Gate instances.
* Enabling or disabling synchronization for Db2 Data Gate. You can add or remove tables from the synchronization process using the table list of the Db2 Data Gate instance.
* Loading tables in Db2 Data Gate. You can load the tables of a Db2 Data Gate instance from the dashboard.
* Removing tables from Db2 Data Gate. You can remove tables from a Db2 Data Gate instance using the dashboard.
* Monitoring a Db2 Data Gate instance. The dashboard is displayed after the creation of an instance has finished. You can also access the dashboard from the Cloud Pak for Data main menu. The dashboard gives you various pieces of information about your Db2 Data Gate instance, such as the system availability, the table status, the replication latency, and throughput. The dashboard also allows you to add, load, and remove tables or to enable or disable synchronization. The dashboard is displayed after the creation of an instance.

# Details

## Prerequisites
IBM Cloud Pak for Db2 Data Gate requires the following software.

- IBM Cloud Pak Foundational Services version 3.7 or later
- Zen version 4.0.1 or later
- cloudctl binary

### Resources Required

To deploy Db2 Data Gate  as add-on to IBM Cloud Pak for Data, you must have the following minimum resources available.

- Cores: 5 available cores
- Memory: 13 GB available memory
- Persistent storage: 50 GB

# Installing

Install IBM Db2 Data Gate using the operator:

Set up the cluster. Make sure to meet the prerequisites.
Install the operator in one of the following ways:
- Install the IBM Db2 Data Gate Operator using cloudctl
- Install teh IBM Db2 Data Gate Operator using OLM via Operator Hub
- Install the IBM Db2 Data Gate by applying DatagateService CR

## Prerequisite
- Get the latest version of the cloudctl program for your operating system and add it to your local path ($PATH). You can download the program from https://github.com/IBM/cloud-pak-cli/releases
- Download the latest stable (non-beta) version of ibm-datagate-prod-4.0.1-< buildnumber >.tgz
- Set the ENV environment variable
```
export NAMESPACE_TO_WATCH=<Single value or comma seperated value, ex: zen1,zen2 for IBM Datagate Operator to watch and create DatagateService CR>
export DOCKER_APIKEY=<Docker API Key which has access to cp.icr.io/cp/cpd registry to download datagate-operator and datagate service component>
export DOCKER_USERNAME=<Docker API username which has access to cp.icr.io/cp/cpd registry to download ibm-datagate-operator and datagate service component> like `iamapikey`
```
- Create a configuration map for the IBM Db2 Data Gate operator
```
oc create configmap namespace-scope --from-literal=namespaces=$NAMESPACE_TO_WATCH
```
- Back up your current global pull secret (IMPORTANT)
```
oc get secret pull-secret -n openshift-config -o yaml > global-pull-secret.yaml
```
- Create the new global pull secret
```
pull_secret=$(echo -n "$DOCKER_USERNAME:$DOCKER_APIKEY" | base64 -w0)
oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|"auths":{|"auths":{"cp.icr.io/cp/cpd":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json
```
Reference:
https://docs.openshift.com/container-platform/4.6/openshift_images/managing_images/using-image-pull-secrets.html#images-update-global-pull-secret_using-image-pull-secrets

In case of something goes wrong, revert to your old secret.

If you want to use an air-gapped installation that includes images , mirror the icr.io/cpopen and cp.irc.io/cp registries to the target registry supposed to contain the images and create the pull secret for your private registry.

Note that all the images are hard-coded and use icr.io/cpopen and cp.irc.io/cp as their registries in the build. You cannot use the version tag for this new mechanism since the image digest has to specify it in the resource yaml.

It might take between 10 and 15 min. to update the cluster nodes and set up the mirror. During this time, scheduling will be disabled on the nodes. Check the status of the nodes and wait until the status of all of them is **Ready**.

```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - <your private registry>
    source: cp.icr.io/cp/cpd
  - mirrors:
    - <your private registry>
    source: icr.io/cpopen
EOF
```

## Install IBM Db2 Data Gate Operator using cloudctl
```
export DATAGATE_OPERATOR_NAMESPACE=<operator-namespace>
cloudctl case launch --case ibm-datagate-4.0.1-<buildnumber>.tgz --namespace $DATAGATE_OPERATOR_NAMESPACE --inventory datagateOperatorSetup --action installOperatorNative --tolerance=1
```

Replace `<operator-namespace>` with the namespace that datagate-operator will be running on.


## Install IBM Db2 Data Gate Operator using OLM via Operator Hub

1. Install the IBM Db2 Data Gate operator catalog

```
export DATAGATE_OPERATOR_NAMESPACE=<operator-namespace>
cloudctl case launch --case ibm-datagate-prod-4.0.1-<buildnumber>.tgz --namespace <namespace name>  --inventory datagateOperatorSetup --action installCatalog --tolerance 1
```
Replace `<operator-namespace>` with the namespace that datagate-operator will be running in.

2. Install the IBM Db2 Data Gate operator using any of the following options:

Option 1. - Install the operator by using the cloudctl command
```
export DATAGATE_OPERATOR_NAMESPACE=<operator-namespace>
oc project $DATAGATE_OPERATOR_NAMESPACE
cloudctl case launch --case ibm-datagate-prod-4.0.1-<buildnumber>.tgz --namespace $DATAGATE_OPERATOR_NAMESPACE --inventory datagateOperatorSetup --action install --tolerance=1
```
Option 2. - Install the operator from the OpenShift console UI

```
Example: open the console UI of openshift.
  - Look for `Datagate Operator` in the Operator Hub
  - Hit `Install` button
  - Choose namespaces for the operator to watch.
  - Hit `Install` button again
```

## DatagateService CR
After installing the IBM Db2 Data Gate operator, you can use the DatagateService CR template to install the Db2 Data Gate service.

### DatagateService CR template for network file system (nfs):

```
cat << EOF | oc apply -f -
apiVersion: datagate.cpd.ibm.com/v1
kind: DatagateService
metadata:
  name: datagateservice-cr
  namespace: <LITE_NAMESPACE>
spec:
  scaleConfig: small
  is_35_upgrade: false
  cert_manager_enabled: false
  ignoreForMaintenance: false
  docker_registry_prefix: "cp.icr.io/cp/cpd"
  storageClass: managed-nfs-storage
  storageVendor:
  storageOverride:
  version: "2.0.1"
  license:
    accept: true
    license: Enterprise
EOF
```    
Replace <LITE_NAMESPACE> with the namespace that Cloud Pak for Data instance namespace is installed in and that will be used to run the Db2 Data Gate service.

### DatagateService CR template for OpenShift Container Storage (OCS):

```
cat << EOF | oc apply -f -
apiVersion: datagate.cpd.ibm.com/v1
kind: DatagateService
metadata:
  labels:
    control-plane: ibm-datagate-operator
    app.kubernetes.io/instance: ibm-datagate-operator
    app.kubernetes.io/managed-by: ibm-datagate-operator
    app.kubernetes.io/name: ibm-datagate-operator
  name: datagateservice-cr
  annotations:
    "ansible.sdk.operatorframework.io/verbosity": "4"
  namespace: <LITE_NAMESPACE>
spec:
  scaleConfig: small
  is_35_upgrade: false
  cert_manager_enabled: false
  ignoreForMaintenance: false
  docker_registry_prefix: "cp.icr.io/cp/cpd"
  storageClass: ocs-storagecluster-cephfs
  storageVendor: ocs
  storageOverride:
  version: "2.0.1"
  license:
    accept: true
    license: Enterprise
EOF
```    
Replace `<LITE_NAMESPACE>` with the namespace that Cloud Pak for Data instance namespace is installed in and  that will be used to run the Db2 Data Gate service.

### DatagateService CR Template on portworx.

```
cat << EOF | oc apply -f -
apiVersion: datagate.cpd.ibm.com/v1
kind: DatagateService
metadata:
  name: datagateservice-cr
  annotations:
    "ansible.sdk.operatorframework.io/verbosity": "4"
  namespace: <LITE_NAMESPACE>
spec:
  scaleConfig: small
  is_35_upgrade: false
  cert_manager_enabled: false
  ignoreForMaintenance: false
  docker_registry_prefix: "cp.icr.io/cp/cpd"
  storageClass: portworx-shared-gp3
  storageVendor: portworx
  storageOverride:
  version: "2.0.1"
  license:
    accept: true
    license: Enterprise
EOF
```    
Replace `<LITE_NAMESPACE>` with the namespace that Cloud Pak for Data instance namespace is installed and datagate service will be running on.


## Configuration

Configure the size of Db2 Data Gate by changing the spec.size value in the DatagateService CR template. The following values can be set:

- small
- medium
- large


## Storage

IBM Cloud Pak for Db2 Data Gate supports dynamic storage provisioning by using storage classes. The following storage types are supported.

- NFS
- Portworx 2.7
- OCS

## Limitations

The replica of Db2 Data Gate deployment is 1. If we scale it over 1, the second Db2 Date Gate instances will refer to the same filesystem that consist of the instance, database directory, etc. This will cause Data Gate instance to crash.

## Documentation

IBM Documentation: https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=services-db2-data-gate

## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
See [Custom security context constraints for services](https://ibmdocs-test.mybluemix.net/docs/en/SSQNUZ_4.5_test?topic=cluster-custom-sccs-services)
