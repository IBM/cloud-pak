# IBM Sterling OMS Enterprise Edition

This inventory item `ibmOmsProProd` can be used to install the IBM Sterling Order Management Software Enterprise Edition.

For more infomation, see [README](../../README.md)
