# Licensed Materials - Property of IBM
# IBM Order Management Software (5725-D10)
# (C) Copyright IBM Corp. 2021, 2022 All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# operator specific variables
CASE_CATALOG_NAME="ibm-sterling-oms-catalog"
SUBSCRIPTION_NAME="ibm-oms"

if [[ $($kubernetesCLI api-resources | grep "openshift.io" | wc -l) -gt 0 ]]; then
  export IS_OPENSHIFT=true
  export CATSRC_NS="openshift-marketplace"
else 
  export IS_OPENSHIFT=false
  export CATSRC_NS="olm" 
fi

if [ $(echo "${casePath}" | grep "ibm-oms-pro-case"  | wc -l) == 1 ]; then
    export EDITION_ABBR="pro"
else
    export EDITION_ABBR="ent"
fi

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
  key=$1
  val=$2
  case $key in
  --omenv)
    export omenv=$val 
    ;;
  esac
}

__install_operator_group() {
  # Check if operator group exists
  echo "Check for any existing operator group in ${namespace}"
  if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
    echo "found operator group"
    $kubernetesCLI get og -n "${namespace}" -o yaml
    return
  fi

  # Create operator group
  echo "No existing operator group found. Creating a new operator group"
  echo "Installing operator group for $namespace"
  local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
  validate_file_exists "${opgrp_file}"
  sed <"${opgrp_file}" "s|_NAMESPACE_|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
  echo "done"
}

__remove_operator_group() {
  echo "Remove operator group in ${namespace} namespace"
  local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
  validate_file_exists "${opgrp_file}"
  sed <"${opgrp_file}" "s|_NAMESPACE_|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f -) | cat
  echo "done"
}

__validate_operator_ns() {
  echo "Validate operator namespace"
  if [ "${IS_OPENSHIFT}" == true ] && [ "${namespace}" != "openshift-operators" ]; then 
    echo "ERROR: Install operator to all namespaces on Openshift should use openshift-operators namespace. Passed namespace: ${namespace}"
    exit 1
  elif [ "${IS_OPENSHIFT}" != true ] && [ "${namespace}" != "operators" ]; then
    echo "ERROR: Install operator to all namespaces on Vanilla Kubernetes should use operators namespace. Passed namespace: ${namespace}"
    exit 1
  fi
}

__validate_catalog_ns() {
  echo "Validate catalog namespace"
  if [ "${IS_OPENSHIFT}" == true ] && [ "${namespace}" != "openshift-marketplace" ]; then 
    echo "ERROR: CatalogSource namespace for OpenShift cluster should be openshift-marketplace"
    exit 1
  elif [ "${IS_OPENSHIFT}" != true ] && [ "${namespace}" != "olm" ]; then
    echo "ERROR: CatalogSource namespace for non-Openshift should be olm"
    exit 1
  fi
}

install_operator() {
  echo -e "\n-------------Installing Operator OLM-------------"

  # Validations
  validate_install_args

  # Check if the operator is installed on all namespaces or specific namespace
  if [ "${namespace}" == "openshift-operators" ] || [ "${namespace}" == "operators" ]; then 
    __validate_operator_ns || exit 1
    echo "Install operator to all namespaces on the cluster"
  else
    __install_operator_group || exit 1
    echo "Install operator to ${namespace} namespace"
  fi

  # Check if subscription already exists
  if [[ $($kubernetesCLI get subscription --ignore-not-found=true --namespace=${namespace} |grep $SUBSCRIPTION_NAME | wc -l)  -gt 0 ]]; then
    echo "Subscription $SUBSCRIPTION_NAME already exists"
    exit 0
  fi

  # Validate subscription file exists
  local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
  validate_file_exists "${subscription_file}"

  # Check if catalog source is installed
  echo "Checking if catalog source exists ..."
  if ! $kubernetesCLI get catsrc "${CASE_CATALOG_NAME}" -n "${CATSRC_NS}"; then
    err_exit "expected catalog source '${CASE_CATALOG_NAME}' expected to be installed namespace '${CATSRC_NS}'"
    exit 1
  fi

  # Create subscription
  echo "Create subscription in namespace ${namespace}"
  sed -e "s|_NAMESPACE_|${namespace}|g" -e "s|_SOURCENAMESPACE_|${CATSRC_NS}|g" -e 's/REPLACE_WITH_EDITION_ABBR/'${EDITION_ABBR}'/g' "${subscription_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

uninstall_operator() {    
  echo -e "\n-------------Uninstalling operator-------------"

  if [ "${namespace}" == "openshift-operators" ] || [ "${namespace}" == "operators" ]; then 
    __validate_operator_ns
  else
    __remove_operator_group
  fi

  # Find installed CSV
  csvName=$($kubernetesCLI get subscription ibm-oms-$EDITION_ABBR -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
  echo $csvName

  # Remove the subscription
  local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
  sed -e "s|_NAMESPACE_|${namespace}|g" -e "s|_SOURCENAMESPACE_|${CATSRC_NS}|g" -e 's/REPLACE_WITH_EDITION_ABBR/'${EDITION_ABBR}'/g' "${subscription_file}" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat

  # Remove the CSV which was generated by the subscription but does not get garbage collected
  [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; } || exit 1

  # Delete CRDs
  for crdYaml in "${casePath}"/inventory/"${inventory}"/files/crds/*.yaml; do
    $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
  done
}

install_catalog() {
  echo -e "\n-------------Installing catalog source-------------"

  # Validations 
  validate_install_catalog
  __validate_catalog_ns

  # Validate file exists
  local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
  validate_file_exists "${catsrc_file}"

  # Apply yaml files manipulate variable input as required
  $kubernetesCLI apply -f "${catsrc_file}" -n "${CATSRC_NS}" ${dryRun}

  echo "done"
}

uninstall_catalog() {
  echo -e "\n-------------Uninstalling catalog source-------------"
  
  # Validations
  validate_install_catalog "uninstall"
  __validate_catalog_ns

  # Validate file exists
  local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
  validate_file_exists "${catsrc_file}"

  # Remove catalog source
  $kubernetesCLI delete -f "${catsrc_file}" -n "${CATSRC_NS}" --ignore-not-found=true ${dryRun}
  echo "done"
}

apply_custom_resources() {
  echo -e "\n-------------Applying custom resources-------------"

  # Validate args
  if [ -z "${omenv}" ]; then
    echo "ERROR: No custom resources to apply. Use --args \"--omenv <path/to/custom_resources/file>\" to specify a custom resource file."
    exit 1
  fi

  # Validate to make sure the files exist
  validate_file_exists "$omenv"

  # Apply CRs
  $kubernetesCLI apply -n "${namespace}" -f "${omenv}" ${dryRun}
}

delete_custom_resources() {
  echo -e "\n-------------Deleting custom resources-------------"

  # Validate args
  if [ -z "${omenv}" ]; then
    echo "ERROR: No custom resources to delete. Use --args \"--omenv <path/to/custom_resources/file>\" to specify a custom resource file."
    exit 1
  fi

  # Validate to make sure the files exist
  validate_file_exists "$omenv"
  
  # Remove the custom resources
  $kubernetesCLI delete -n "${namespace}" -f "${omenv}" ${dryRun}
}

install() {
  apply_custom_resources
}

uninstall() {
  delete_custom_resources
}