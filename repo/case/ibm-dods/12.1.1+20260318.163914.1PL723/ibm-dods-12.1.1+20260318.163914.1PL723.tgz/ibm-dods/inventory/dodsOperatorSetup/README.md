# DODS Operator Setup

This inventory item contains resources required to install the DODS Operator