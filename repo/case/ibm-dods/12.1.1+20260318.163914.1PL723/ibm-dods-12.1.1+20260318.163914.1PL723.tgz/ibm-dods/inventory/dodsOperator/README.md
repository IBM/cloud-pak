# DODS Operator

Contains the DODS Operator custom resource
