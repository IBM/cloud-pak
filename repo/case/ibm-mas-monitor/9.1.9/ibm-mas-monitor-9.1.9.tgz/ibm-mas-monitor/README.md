# Name

IBM&reg; Maximo Monitor&reg;

# Introduction
## Summary
IBM&reg; Maximo Monitor&reg; is an application in Maximo Application Suite. It provides a monitoring solution for real-time visibility, root-cause troubleshooting, anomaly detection, and AI-driven alerts at scale.

## Features
With IBM&reg; Maximo Monitor&reg;, business users can:
 - Visualize current and historical trend data for their devices in customizable dashboards
 - Drill down through layers from a system-wide view to individual devices
 - Apply analytic functions to input data, and display the output on value cards, tables, images, line graphs, and alert tables
 - Run anomaly detectors on the input data to detect outliers, gaps, and flat lines in the data

# Details
## Prerequisites

Summary of Prerequisites required for IBM&reg; Maximo Monitor&reg;:
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4.x
- cert-manager 1.1.0 (or higher) installed in the cluster. See cert-manger [documentation](https://cert-manager.io/docs/installation/openshift/#installing-with-regular-manifests) for install details
- MongoDB, either internal to the cluster or external
- Db2Warehouse, internal to the cluster or external
- IBM IoT, internal to the cluster
- An IBM Entitled Registry key

### Resources Required
Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |   15        |  5.0        |  250      |  2    |


## Installing
- Refer to official [Monitor documentation](https://www.ibm.com/docs/en/mas87/8.7.0?topic=applications-maximo-monitor) for the recommended install process
- If you wish to instead manually install from OperatorHub, you will need to choose to install into a namespace that complies with MAS standards, i.e. `mas-INSTANCENAME-monitor`.  Then, create a MonitorApp and MonitorWorkspace custom resource, following the alm-examples.

### Verifying Install
Check status of the MonitorApp custom resource:
```sh
oc get monitorapp {{instanceId}}
```

Check status of the MonitorWorkspace custom resource:
```sh
oc get monitorworkspace {{instanceId}}
```


## Configuration
See the details provided in [IBM docs](https://www.ibm.com/docs/en/mas87/8.7.0?topic=applications-maximo-monitor#deploy_monitor) for more information about how to configure IBM&reg; Maximo Monitor&reg;.

## Storage

IBM&reg; Maximo Monitor&reg; requires no direct persistent storage in the OpenShift cluster. All data is stored in the MonogDB and Db2Warehouse prerequistes.

### Encryption

We recommend the use of storage with passive encryption enabled to protect the data in MongoDB and Db2Warehouse.

## Air Gap Installs
Air gap installs are not supported in IBM&reg; Maximo Monitor&reg; 8.8.

## Limitations
- The operator only supports single namespace deployment
- The operator will only watch for resources in its own namespace
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of the MonitorApp can **not** be deployed in the same namespace
- Each MonitorApp resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-monitor`

## Upgrades
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.6/html/operators/administrator-tasks#olm-upgrading-operators).

## Documentation
The Maximo Application Suite documentation is available [here](https://www.ibm.com/docs/en/mas/continuous-delivery)

## License
Maximo Application Suite 8.8 License is available [here](https://ibm.biz/MAS88-License) 

## Roles and Personas

Installation and configuration of the Maximo Application Suite operator may be divided into two Roles or Personas to limit the access privileges required.
- Cluster Admin - Installs the operator into a namespace
- End User - Creates suite custom resource(s) so that the operator produces required resources to allow the Maximo Application Suite to function.

## Backup
### Backup process
Backups should be made of both the OpenShift Cluster and MongoDb.

OpenShift Cluster backup requires backing up the etcd cluster. Details can be found in the OpenShift Container Platform [documentation](https://docs.openshift.com/container-platform/4.6/backup_and_restore/backing-up-etcd.html)

Backups should be made of the following MongoDB databases created:
- `mas_{{instanceId}}_core`
- `mas_{{instanceId}}_catalog`

There is no need to backup the following MongoDB databases:
- mas_{{instanceId}}_adoptionusage

Each Application deployed via Maximo Application Suite might require additional backup sources, please consult the documentation for each application.

### Restore process
Restoring should be executing as described in the OpenShift Container Platform documentation and MongoDB documentation.

## SecurityContextConstraints Requirements
#### Custom SecurityContextConstraints definition:
The operator uses the Openshift default `restricted` SCC (Security Context Constraints).

## PodSecurityPolicy Requirements
The operator runs in OpenShift so no PodSecurityPolicy configuration is required.

## Install Status Codes

- **CertificateNotReady** - A required certificate is not ready to use
- **TruststoreNotReady** - A required truststore is not ready to use
- **SuiteIsNotInstalled** - The parent suite resource is not installed
- **MissingCredentials** - A referenced secret is missing
- **InvalidCredentials** - A referenced secret does not contain the correct data
- **InvalidConfiguration** - The configuration is invalid
- **ValidationFailed** - The configuration failed validation
- **DatabaseUpdateFailed** - An error occured updating internal database
- **AppPointReservationFailed** - An error occurred reserving app points with catalogmgr
- **CompatibilityCheckFailure** - There is compatibility problem
- **Ready** - Everything is ready
