# Name
IBM&reg; Product Master

# Introduction
IBM&reg; Product Master Provides trusted product information management (PIM) capabilities. Product Master Aggregates information from upstream system,enforces business processes for accuracy and consistency, and synchronises trusted information with downstream systems.

## Summary

Product Master is the middleware that establishes a single, integrated, consistent view of products and services information of an enterprise.

## Features

Product Master provides the following PIM solutions:
-       Creates an accurate and up-to-date repository of product and service information that can be used throughout organizations for strategic business initiatives.
- Aggregates information from any upstream system, enforces business processes to ensure data accuracy and consistency, and synchronizes trusted information with downstream systems.
- Tools for modelling, capturing, creating, and managing information with high user productivity and high information quality.
- The ability to integrate and synchronize information with existing systems, enterprise applications, repositories, and masters.
- Business user workflows for supporting multi-department and multi-enterprise business processes.
- The ability to exchange and synchronize information externally with Business Partners.

# Details
## Prerequisites

IBM Product Master Cartridge for IBM Cloud Pak for Data requires the following
- Bedrock version 3.7 or later
- Zen version 4.0.2 or later
- cloudctl binary
- db2U - If Client wants to go for DB2 from Bedrock
- IBM Cloud Pak for Data Common Core Services.
- Create app-secret.yaml secret file for required credentials. Refer Create app-secret.yaml secret file section from "Installing" below
- Create custom zen route

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|    IBM Product Master Cartridge       |     40        |     12        |  200         |       |
| **Total** |             |             |           |       |


## Configuration

* Provide configuration instructions if any

## Storage
IBM Product Master Cartridge for IBM Cloud Pak for Data supports dynamic storage provisionging using storage class.  The following storages are supported
- NFS
- Portworx 2.7
- OCS

## Limitations

Only one instance of IBM Product Master Cartridge operator can be deployed in one namespace.  Multiple instances of Product Master operands can be deployed in different namespaces in a cluster.

IBM Product Master Cartridge only run on amd64 architecture type

## Documentation

* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: ibm-productmaster-scc
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
## Installing
### Install Zen Operator and Bedrock
Make sure the credential for accessing registry `cp.icr.io/cp/cpd` is added to secret `pull-secret` in project `openshift-config` because the IBM Product Master operator images is pushed to `cp.icr.io/cp/cpd` registry.

See Zen operator and Bedrock installation instructions

NOTE:
- in step 1 of the above procedure, replace with the following
```yaml
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: productmaster-mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - cp.stg.icr.io/cp/cpd
    source: cp.icr.io/cp/cpd
  - mirrors:
    - cp.stg.icr.io/cp
    source: icr.io/cpopen
  - mirrors:
    - hyc-cloud-private-daily-docker-local.artifactory.swg-devops.com/ibmcom
    - hyc-cp4d-team-bootstrap-2-docker-local.artifactory.swg-devops.com
    source: quay.io/opencloudio
  - mirrors:
    - hyc-cp4d-team-bootstrap-docker-local.artifactory.swg-devops.com
    source: docker.io/ibmcom
```
- in step 2 of the above procedure, ADD
```bash
STAGING_USER="iamapikey"
STAGING_APIKEY="<apikey for cp.stg.icr.io/cp>"
pull_secret=$(echo -n "$STAGING_USER:$STAGING_APIKEY" | base64 -w0)
oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|:{|:{"cp.stg.icr.io/cp":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json
```

### Get OLM Utils (run_utils) up and running for deloyment.
Follow official KC link to get olm utils up

### Before starting the deployment, add staging to registry mirror and update global pull secret for registry
[If mirroring already present then do not create it]
The images of IBM Product Master are available in staging registry (cp.stg.icr.io/cp/cpd).  Add staging registry `cp.stg.icr.io/cp/cpd` to source `cp.icr.io/cp/cpd` `cp.stg.icr.io/cp` to `icr.io/cpopen`.

```yaml
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - hyc-cp4d-team-bootstrap-docker-local.artifactory.swg-devops.com
    - cp.stg.icr.io/cp/cpd
    source: cp.icr.io/cp/cpd
  - mirrors:
    - hyc-cp4d-team-bootstrap-docker-local.artifactory.swg-devops.com
    - cp.stg.icr.io/cp
    source: icr.io/cpopen
```

### Install IBM Product Master Operator with OLM using run_utils

#### declare zen namespace where zen service(CP4D) in namespaceScope common-service to watch this namespace as you will be applying your CR in this namespace.

```bash
$oc patch nss common-service -n ibm-common-services --type='json' -p='[{"op": "add", "path":"/spec/namespaceMembers/0","value": "'<zen namespace>'" }]'
```

#### Create IBM Product Master Operator Catalog and Subscription using below command:
```bash
run_utils apply-olm --release=7.0.0 --components=productmaster
```

#### Create IBM Product Master service instance using below command:
```bash
run_utils apply-cr --release=7.0.0 --components=productmaster --license_acceptance=true --cpd_instance_ns=<zen namespace>
```

#### Deploy IBM Product Master

To install Product Master:

1. Log in to Red Hat® OpenShift Container Platform as a user with sufficient permissions to complete the task:

```bash
oc login OpenShift_URL:port
```


2. Get IBM Db2 pod details.

 If you choose the Db2 service within the Cloud Pak for Data as your database, you need to complete following:

    - Collect Db2 pod details which will be required to put in app-secret
    - Creating table spaces in the Db2 pod for Product Master

 Note: DB2 operator and Product Master should be in same namespace.

  - Log in to the IBM Db2 instance pod.
  - Get the password of the db2inst1 user by using the following commands.

```bash
    oc rsh c-<instancename> -db2u-0
    cat /secrets/db2instancepwd/password
```

  - Get the created database name by using the following commands.

```bash
oc rsh c-<instancename> -db2u-0
su db2inst1
db2 list database directory
```

  - Get the SVC name of DB2 that is going to be used as IBM Db2 host name by using the following command. The port number is 50000.

```bash
oc get svc  | grep db2 | grep -v None | grep ClusterIP
```

 - Creating table spaces in the Db2 pod for Product Master

 Proceed as follows to create table spaces in the Db2 pod. This is a one-time activity.

    Log in to the IBM Db2 instance pod.
    Run the following commands.

```bash
$oc rsh c-<instancename>-db2u-0
$ su db2inst1
$ cd
$db2 list database directory
```
Create tablespaces_creation.sh script file by using the following content. Replace <database_name> with the actual database name that you are going to use for the Product Master. 

```bash
db2 connect to <database name>
db2 CREATE BUFFERPOOL USERSBP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL INDXBP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL BLOBBP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL TEMPUSRBP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL TEMPSYSBP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL TEMPUSRBP32 SIZE AUTOMATIC PAGESIZE 32K;
db2 CREATE BUFFERPOOL TEMPSYSBP32 SIZE AUTOMATIC PAGESIZE 32K;
db2 CREATE BUFFERPOOL XML_DATA_BP SIZE AUTOMATIC PAGESIZE 32K;
db2 CREATE BUFFERPOOL XML_LARGE_BP SIZE AUTOMATIC PAGESIZE 32K;
db2 CREATE BUFFERPOOL XML_INDX_BP SIZE AUTOMATIC PAGESIZE 32K;


db2 CREATE BUFFERPOOL ITA_DATA_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ITA_IX_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ITD_DATA_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ITD_IX_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ITM_DATA_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ITM_IX_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ICM_DATA_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL ICM_IX_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL LCK_DATA_BP SIZE AUTOMATIC PAGESIZE 16K;
db2 CREATE BUFFERPOOL LCK_IX_BP SIZE AUTOMATIC PAGESIZE 16K;

db2 CREATE LARGE TABLESPACE USERS PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL USERSBP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE INDX PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL INDXBP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE BLOB_TBL_DATA PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL BLOBBP FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE XML_DATA PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL XML_DATA_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 100M;
db2 CREATE LARGE TABLESPACE XML_LARGE_DATA PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL XML_LARGE_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 100M;
db2 CREATE LARGE TABLESPACE XML_INDEX PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL XML_INDX_BP FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 100M;


db2 CREATE LARGE TABLESPACE ITA_DATA PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ITA_DATA_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ITM_DATA PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ITM_DATA_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ITD_DATA PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ITD_DATA_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ICM_DATA PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ICM_DATA_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE LCK_DATA PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL LCK_DATA_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ITA_IX PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ITA_IX_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ITM_IX PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ITM_IX_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ITD_IX PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ITD_IX_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE ICM_IX PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL ICM_IX_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE LARGE TABLESPACE LCK_IX PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL LCK_IX_BP NO FILE SYSTEM CACHING AUTORESIZE YES INCREASESIZE 1G;
db2 CREATE USER TEMPORARY TABLESPACE TEMP_USER PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL TEMPUSRBP;
db2 CREATE SYSTEM TEMPORARY TABLESPACE TEMP_SYSTEM PAGESIZE 16K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL TEMPSYSBP;
db2 CREATE USER TEMPORARY TABLESPACE TEMP_USER32 PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL TEMPUSRBP32;
db2 CREATE SYSTEM TEMPORARY TABLESPACE TEMP_SYSTEM32 PAGESIZE 32K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL TEMPSYSBP32;
db2 CREATE SCHEMA PIM AUTHORIZATION db2inst1;


db2 update db cfg for <database name> using LOGFILSIZ 7.0.0;
db2 update db cfg for <database name> using LOGPRIMARY 40;
db2 update db cfg for <database name> using LOGSECOND 2;
```
Run the tablespaces_creation.sh script file by using the following commands.

```bash
chmod 755 tablespaces_creation.sh
./tablespaces_creation.sh
```



3.  Change to the project where the IBM Cloud Pak® for Data is installed.
```bash
oc project <zen namespace>
```

4. Create app-secret with the following entries.

```yaml
cat <<EOF |oc apply -f -
apiVersion: v1
kind: Secret
metadata:
  name: app-secret
  labels:
    app.kubernetes.io/instance: ibm-cpd-productmaster-operator
    app.kubernetes.io/managed-by: ibm-cpd-productmaster-operator
    app.kubernetes.io/name: ibm-cpd-productmaster-operator
  namespace: <zen namespace>
type: Opaque
stringData:
#Database details
  db_type: "<db2 / oracle>"
  db_name: "<DB name>"
  db_host: "<IP/DB2 SVC name>"
  db_user: "<DB username>"
  db_pass: "<DB password>"
  db_port: "<DB server port>"

#IBM Watson® Knowledge Catalog details
  cpd_host_url: "<CPD host URL>"
  cpd_user_name: "<CPD User name>"
  wkc_auth_api_key: "<WKC API Key>"
  wkc_catalog_name: "<WKC Catalog name>"
#Simple Mail Transfer Protocol (SMTP) details
  smtp_address: "<SMTP server hostname>"
  from_address: "<From email address>"
  smtp_port: "<SMTP server port>"
  smtp_user: "<SMTP username or API key>"
  smtp_pass: "<SMTP password>"
  smtp_additional_props: "<SMTP Additional Properties>"
#Security Assertion Markup Language (SAML) Single sign-on (SSO) details
  sso_company: "<Company code>"
  sso_config_adminui: "<AdminUI SAML WebSSO configuration for IBM WebSphere® Liberty, in the format <samlWebSso20>..</samlWebSso20>>"
  sso_config_personaui: "<PersonaUI SAML WebSSO configuration for IBM WebSphere® Liberty Liberty, in the format <samlWebSso20>..</samlWebSso20>>"
  sso_idp_metadata: "<Identity provider metadata file content>"
EOF
```

Table 1. app-secret properties

| Property | Description |
| --- | --- |
| namespace | Specifies the namespace where the IBM Cloud Pak for Data is installed |
|db_type, db_name, db_host, db_user, db_pass, db_port  | Specify the database parameters. These parameters depend on your database type (IBM Db2 or Oracle). To get IBM Db2 details, see Step 2. |
| cpd_host_url, cpd_user_name, wkc_auth_api_key, wkc_catalog_name | Optional: Specify the connection details if you are using the IBM Watson® Knowledge Catalog feature.
For more information on generating authentication keys for the wkc_auth_api_key property, see Platform API key. |
| smtp_address, from_address, smtp_port, smtp_user, smtp_pass, and smtp_additional_props | Optional: Specify the configuration details if you are using the SMTP. |
| sso_company, sso_config_adminui, sso_config_personaui, and sso_idp_metadata | Optional: Specify the authentication details if you are using the SAML SSO. |


5. Run below command to apply Product Master CR:


```bash
run_utils apply-cr --release=8.0.0 --components=productmaster_instance --license_acceptance=true --cpd_instance_ns=<zen namespace> --block_storage_class=<block storage> --file_storage_class=<file storage> --extra-vars="productmaster_instance_scale_config=small"
```


6. To get the application URLs run below commands: 

- adminUI URL:

```bash
oc get route | grep productmaster-admin | awk {'print $2'}
productmaster-admin-cpd-instance.productmaster-88d730e9314ff984c930e51ffa50442f-0000.che01.containers.appdomain.cloud
```
So the AdminUI URL is https://productmaster-admin-cpd-instance.productmaster-88d730e9314ff984c930e51ffa50442f-0000.che01.containers.appdomain.cloud

- personaUI URL: 
PersonaUI Domain FQDN is same as Zen UI just suffix '/mdm_ui/' is appended. 

```bash
oc get route  | grep ibm-nginx-https-port | awk {'print $2'}
cpd-cpd-instance.productmaster-88d730e9314ff984c930e51ffa50442f-0000.che01.containers.appdomain.cloud
```
So the URL is https://cpd-cpd-instance.productmaster-88d730e9314ff984c930e51ffa50442f-0000.che01.containers.appdomain.cloud/mdm_ui/

### Deploy IBM Product Master with OLM using oc command

#### Create IBM Product Master Catalog
Create IBM Product Master Catalog Source by creating file `productmaster-catalogsource.yaml` with the content below.  Run `oc apply -f productmaster-catalogsource.yaml -n <operator project>`
```yaml
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: ibm-productmaster-catalog
  namespace: openshift-marketplace
spec:
  displayName: IBM Product Master
  publisher: IBM
  sourceType: grpc
  image: icr.io/cpopen/ibm-cpd-productmaster-operator-catalog@sha256:0e50653878bd322b1a10c5e443cf20c82d102144cfc0c81c6b5a9aaa8c3507a8
```

#### Create IBM Product Master Subsription
Create IBM Product Master Subsription by creating file `productmaster-subscription.yaml` with the content below.  Run `oc apply -f productmaster-subscription.yaml`
```yaml
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: ibm-productmaster-catalog-subscription
  namespace: ibm-common-services
spec:
  channel: v3.3
  name: productmaster-operator
  installPlanApproval: Automatic
  source: ibm-productmaster-catalog
  sourceNamespace: openshift-marketplace
```

### Install IBM Product Master by CR

Go to Zen namespace where this CR (Custome Resource) will be deployed.

Create app-secret before applying CR with same above yaml.

- First create service instance: 
```bash
cat << EOF | oc apply -f-
apiVersion: productmaster.cpd.ibm.com/v1
kind: ProductMasterService
metadata:
  name: productmasterservice-cr
  labels:
    app.kubernetes.io/instance: ibm-cpd-productmaster-operator
    app.kubernetes.io/managed-by: ibm-cpd-productmaster-operator
    app.kubernetes.io/name: ibm-cpd-productmaster-operator
spec:
  version: "8.0.0"
  license:
    accept: true
EOF
```

Run the following command by updating correct storage class:
```bash
cat << EOF | oc apply -f -
apiVersion: productmaster.cpd.ibm.com/v1
kind: ProductMaster
metadata:
  labels:
    app.kubernetes.io/instance: ibm-cpd-productmaster-operator
    app.kubernetes.io/managed-by: ibm-cpd-productmaster-operator
    app.kubernetes.io/name: ibm-cpd-productmaster-operator
  name: productmaster-cr
spec:
  version: "8.0.0"
  scaleConfig: small
  license:
    accept: true
  shutdown: false
  autoScaleConfig: false
  fileStorageClass: <>
  blockStorageClass: <>
EOF
```

Table 3. custom resource file properties

| Property | Description |
| --- | --- |
| name | Default value is productmaster-cr. This is the recommended name, but you can change it. |
| scaleConfig | Specifies the T-Shirt sizing relative estimation. The acceptable values are small, medium, large and xlarge. |
| shutdown | Set to false by default. If you specify the value as true, it sets the replica_count of all the apps to zero |
| autoScaleConfig | by default it is false. If you want to enable Horizontal Pod Autoscaling then you can mark it as true |
| fileStorageClass | enter file storage name |
| blockStorageClass | enter block storage name |


Check the deployment status using below command:

```bash
oc get ProductMaster productmaster-cr -o jsonpath="{.status.productmasterStatus}"
```

#### Install IBM Product Master Operator Native using cloudctl (without OLM)
Run the commnand below to create IBM Product Master operator Native
```bash
cloudctl case launch --case <productmaster case tgz file> --tolerance 1 --namespace "ibm-common-services" --action installOperatorNative --inventory productmasterOperatorSetup
```

Follow above steps of creating app-secret and run below command to Apply CR:

```bash
cloudctl case launch --case <productmaster case tgz file> --namespace "<zen namespace>"  --args "--storageclass <storageclassname> --domainname <SSL domain name>" --inventory "productmasterOperator" --action apply-custom-resources --tolerance 1
```


### Installing in an air-gapped OpenShift Cluster with bastion

#### Prepare the bastion host

* Log on to the bastion host.

* Verify that the bastion host has access to:
  * Public internet (to download CASE and images).
  * A target image registry ( where the images will be mirrored).
  * A target Red Hat OpenShift cluster to install the operator.

* Download and install the required command line tools:
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with Openshift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All of the following steps should be run from the bastion host computer.

#### Setup environment variables
```bash
export SOURCE_REGISTRY=cp.stg.icr.io
export SOURCE_REGISTRY_PASS=<source registry password>
export SOURCE_REGISTRY_USER=iamapikey
export TARGET_REGISTRY=wslinstall1.fyre.ibm.com:37443
export TARGET_REGISTRY_USER=testuser1
export TARGET_REGISTRY_PASS=abc123ABC
```
1. create directory
```bash
mkdir /root/offline
mkdir /root/install
```
2. Download case tgz and extract it into /root/install. Then run below command to Save case
```bash
cloudctl case save --case /root/install/ibm-productmaster --outputdir /root/offline -t 1
```

3. Create credentials for airgap
```bash
cloudctl case launch --case /root/install/ibm-productmaster --inventory productmasterOperatorSetup --action configureCredsAirgap --args "--registry $SOURCE_REGISTRY --user $SOURCE_REGISTRY_USER --pass $SOURCE_REGISTRY_PASS" --tolerance 1
cloudctl case launch --case /root/install/ibm-productmaster --inventory productmasterOperatorSetup --action configureCredsAirgap --args "--registry $TARGET_REGISTRY --user $TARGET_REGISTRY_USER --pass $TARGET_REGISTRY_PASS" --tolerance 1
```

The following two files will be created after running the above 2 commands
```bash
ls -l ~/.airgap/secrets/
total 8
-rw------- 1 root root 128 Mar 28 11:04 cp.stg.icr.io.json
-rw------- 1 root root 101 Mar 28 11:05 wslinstall1.fyre.ibm.com:37443.json
```

4. Setup image pull from developement registry

If you use SKOPEO
Create file `~/.config/containers/registries.conf` with the following content to setup registry mirror
```bash
unqualified-search-registries = ["icr.io","cp.icr.io"]

[[registry]]
prefix = "icr.io/cpopen/"
insecure = false
blocked = false
location = "cp.stg.icr.io/cp"

[[registry]]
prefix = "cp.icr.io/cp/cpd"
insecure = false
blocked = false
location = "cp.stg.icr.io/cp/cpd"
```

If you NOT use SKOPEO
Make a copy of offline/ibm-productmaster-7.0.0-images.csv file.  Update offline/ibm-productmaster-7.0.0-images.csv. Replacing "cp.icr.io" with "cp.stg.icr.io" and replacing "icr.io,cpopen" with "cp.stg.icr.io,cp"

5. Load image to target registry

install skopeo using yum/apt command.

run below commands. Make USE_SKOPEO as true if you are using skopeo, else do not export it.

```bash
export USE_SKOPEO=true

cloudctl case launch --case /root/install/ibm-productmaster --inventory productmasterOperatorSetup --action mirrorImages --args "--registry $TARGET_REGISTRY --inputDir /root/offline" -t 1
```

6. Setup airgap cluster

If file `offline/ibm-productmaster-7.0.0-images.csv` is changed in step 4, rollback the change.
Transfer saved directorY (offline) to airgap cluster
create project which productmaster operator run

7. setup mirror in airgap cluster
```bash
cloudctl case launch --case /root/install/ibm-productmaster --inventory productmasterOperatorSetup --namespace ibm-common-services --action configureClusterAirgap --args "--registry $TARGET_REGISTRY --inputDir /root/offline" -t 1
```
ImageContentSourcePolicy "ibm-productmaster" is created and pull secret for registr $TARGET_REGISTRY is added to secret "pull-secret" in namespace "openshift-config" after running the above command.

For testing
Change the `source` in ImageContentSourcePolicy "ibm-productmaster" as follow by running `oc edit ImageContentSourcePolicy ibm-productmaster`
```yml
spec:
  repositoryDigestMirrors:
  - mirrors:
    - wslinstall1.fyre.ibm.com:37443/cp/cpd
    source: cp.icr.io/cp/cpd
  - mirrors:
    - wslinstall1.fyre.ibm.com:37443/cp
    source: icr.io/cpopen
```

If you are using production registry `cp.icr.io` as source then you don't need to edit ImageContentSourcePolicy ibm-productmaster.

Remove the following from `.spec.repositoryDigestMirrors` from ImageContentSourcePolicy that already setup for IBM Product Master install if it exsit.
```yml
  - mirrors:
    - cp.stg.icr.io/cp/cpd
    source: cp.icr.io/cp/cpd
  - mirrors:
    - cp.stg.icr.io/cp/cpd
    - cp.stg.icr.io/cp
    source: icr.io/cpopen
```
Create ImageContentSourcePolicy will requires all nodes to restart.  Wait until all node are ready before continue.

8. Install catalog
```bash
cloudctl case launch --case /root/install/ibm-productmaster --namespace "openshift-marketplace" --inventory "productmasterOperatorSetup" --action install-catalog -t 1
```

The catalogsource "ibm-productmaster-catalog" is created in project "openshift-marketplace"
```bash
oc get catsrc -n openshift-marketplace
NAME                           DISPLAY                    TYPE   PUBLISHER   AGE
ibm-productmaster-catalog   IBM Product Master             grpc    IBM       150m
```

If the corresponding pod failed with the following error
```bash
oc get po -n openshift-marketplace
NAME                                            READY   STATUS             RESTARTS   AGE
ibm-productmaster-catalog-xkghc              0/1     ImagePullBackOff   0          14m
Describe pod shows
  Warning  Failed          8s (x4 over 100s)  kubelet            Failed to pull image "wslinstall1.fyre.ibm.com:37443/cp/cpd/ibm-cpd-productmaster-operator-catalog@sha256:9509c7659837f3ef421159b490f1e3711517d1caab6c3f86f876047958d434e3": rpc error: code = Unknown desc = error pinging docker registry wslinstall1.fyre.ibm.com:37443: Get "https:xxxxxxx/v2/": x509: certificate signed by unknown authority
```

Add registry cert to cluster by
- get registry cert. If you have setup the registry using airgap.sh script, then you can find the certificate in /tmp/docker-registry/certs.
- follows Add self-signed cert to openshift cluster (https://docs.openshift.com/container-platform/4.6/builds/setting-up-trusted-ca.html)

```bash
[root@jctesti98-inf test]# oc create configmap registry-cas -n openshift-config --from-file=wslinstall1.fyre.ibm.com..37443=/root/test/certs/domain.crt
configmap/registry-cas created
oc patch image.config.openshift.io/cluster --patch '{"spec":{"additionalTrustedCA":{"name":"registry-cas"}}}' --type=merge
image.config.openshift.io/cluster patched
```
A configmap "registry-cas" will be created in project "openshift-config"

9. Install IBM Product Master operator with OLM


```bash
cloudctl case launch --case /root/install/ibm-productmaster --namespace "ibm-common-services" --inventory "productmasterOperatorSetup" --action install-operator -t 1
```
Subscription, installplan, csv will be created after running the above command.
```bash
oc get sub -n ibm-common-services ibm-productmaster-catalog-subscription
NAME                                        PACKAGE                 SOURCE                         CHANNEL
ibm-productmaster-catalog-subscription   ibm-cpd-productmaster   ibm-productmaster-catalog          v1.0

oc get csv -n ibm-common-services ibm-cpd-productmaster.v8.0.0
NAME                           DISPLAY              VERSION   REPLACES    PHASE
ibm-cpd-productmaster.v8.0.0   IBM Product Master   7.1.0                Succeeded

oc get ip -n ibm-common-services|grep pro
install-fcjvs   ibm-cpd-productmaster.v7.0.0   Automatic   true
```

If csv is not created, check the operator image registry mirror is setup.

10. Create IBM Product Master CR

Follow 'Deploy IBM Product Master' from above steps


### Uninstall Product Master
Run the command below to uninstall IBM Product Master
```bash
cloudctl case launch --case <productmaster case tgz file> --tolerance 1 --namespace <cpd project> -action deleteCustomResources --inventory productmasterOperator
```
or
Run
```bash
oc delete productmaster productmaster-cr -n <cpd project>
```
NOTE:
This is for TESTING ONLY
If the CR instanace is not deleted, run `oc edit productmaster productmaster-cr -n <cpd project>` and delete the following two lines (the finalizer) under `metadata` section
```yml
  finalizers:
  - productmaster.cpd.ibm.com/finalizer
```


### Uninstall Product Master
#### Uninstall Product Master Native
Run the command below to uninstall Product Master Native
```bash
cloudctl case launch --case <productmaster case tgz file> --tolerance 1 --namespace ibm-common-services -action uninstallOperatorNative --inventory productmasterOperatorSetup
```

#### Uninstall Product Master Operator OLM
Run the command below to uninstall Product Master Operator OLM
```bash
cloudctl case launch --case <productmaster case tgz file> --tolerance 1 --namespace ibm-common-services -action uninstallOperator --inventory productmasterOperatorSetup
```

#### Uninstall Product Master Catalog
Run the command below to uninstall Product Master catalog
```bash
cloudctl case launch --case <productmaster case tgz file> --tolerance 1 --namespace openshift-marketplace -action uninstall-catalog --inventory productmasterOperatorSetup
```

## IBM Product Master Versions

| CPD Version | Opeator Version | Replaces | Skiprange | Operand Version | Default Channel | Channel | Description | Provider version |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 4.0.1 | 1.0.0 | | | 1.0.0 | | alpha | The first version of ProductMaster operator | 12.0.3 |
| 4.0.2 | 1.0.1 | 1.0.1 | >=1.0.1 <1.0.1 | 1.0.1 | v1.0 | v1.0 | Upgrade | 12.0.4     |
| 4.0.3 | 1.0.2 | 1.0.1 | >=1.0.1 <1.0.2 | 1.0.2 | v1.0 | v1.0 | Upgrade | 12.0.4-1   |
| 4.0.5 | 1.0.3 | 1.0.2 | >=1.0.1 <1.0.3 | 1.0.3 | v1.0 | v1.0 | Upgrade | 12.0.4-2   |
| 4.0.9 | 1.0.4 | 1.0.3 | >=1.0.1 <1.0.3 | 1.0.3 | v1.0 | v1.0 | Upgrade | 12.0.5.1   |
| 4.5.0 | 2.0.0 | 1.0.4 | >=1.0.1 <2.0.0 | 2.0.0 | v2.0 | v2.0 | Upgrade | 12.0.6     |
| 4.5.2 | 2.1.0 | 2.0.0 | >=1.0.1 <2.1.0 | 2.1.0 | v2.1 | v2.1 | Upgrade | 12.0.6     |
| 4.6.0 | 3.0.0 | 2.1.0 | >=1.0.1 <3.0.0 | 3.0.0 | v3.0 | v3.0 | Upgrade | 12.0.6.3   |
| 4.6.1 | 3.1.0 | 3.0.0 | >=1.0.1 <3.1.0 | 3.1.0 | v3.1 | v3.1 | Upgrade | 12.0.6.4   |
| 4.7.0 | 4.0.0 | 3.1.0 | >=1.0.1 <4.0.0 | 4.0.0 | v4.8 | v4.8 | Upgrade | 12.0.8.1   |
| 4.7.1 | 4.1.0 | 4.0.0 | >=1.0.1 <4.1.0 | 4.1.0 | v4.1 | v4.1 | Upgrade | 12.0.8.1-2 |
| 4.8.0 | 5.0.1 | 4.1.0 | >=1.0.1 <5.0.1 | 5.0.1 | v4.8 | v4.8 | Upgrade | 12.0.9.2   |
| 4.8.1 | 5.1.0 | 5.0.1 | >=1.0.1 <5.1.0 | 5.1.0 | v5.1 | v5.1 | Upgrade | 12.0.9.2-1 |
| 4.8.2 | 5.2.0 | 5.1.0 | >=1.0.1 <5.2.0 | 5.2.0 | v5.2 | v5.2 | Upgrade | 12.0.9.2-2 |
| 4.8.3 | 5.3.0 | 5.2.0 | >=1.0.1 <5.3.0 | 5.3.0 | v5.3 | v5.3 | Upgrade | 12.0.9.2-3 |
| 5.0.0 | 6.0.0 | 5.3.0 | >=1.0.1 <6.0.0 | 6.0.0 | v6.0 | v6.0 | Upgrade | 12.0.11    |
| 5.0.1 | 6.1.0 | 6.0.0 | >=1.0.1 <6.1.0 | 6.1.0 | v6.1 | v6.1 | Upgrade | 12.0.11-1  |
| 5.0.2 | 6.1.0 | 6.0.0 | >=1.0.1 <6.1.0 | 6.1.0 | v6.1 | v6.1 | Upgrade | 12.0.11-1  |
| 5.0.3 | 6.2.0 | 6.1.0 | >=1.0.1 <6.2.0 | 7.0.0 | v6.2 | v6.2 | Upgrade | 12.0.11-2  |
| 5.1.0 | 7.0.0 | 6.2.0 | >=1.0.1 <7.0.0 | 7.0.0 | v7.0 | v7.0 | Upgrade | 12.0.12    |
| 5.1.1 | 7.1.0 | 7.0.0 | >=1.0.1 <7.1.0 | 7.1.0 | v7.1 | v7.1 | Upgrade | 12.0.12    |
| 5.1.3 | 7.2.0 | 7.1.0 | >=1.0.1 <7.2.0 | 7.2.0 | v7.2 | v7.2 | Upgrade | 12.0.12    |
| 5.2.0 | 8.0.0 | 7.2.0 | >=1.0.1 <8.0.0 | 8.0.0 | v8.0 | v8.0 | Upgrade | 14.0.0     |
| 5.2.1 | 8.1.0 | 8.0.0 | >=1.0.1 <8.1.0 | 8.1.0 | v8.1 | v8.1 | Upgrade | 14.0.0     |
| 5.2.2 | 8.2.0 | 8.1.0 | >=1.0.1 <8.2.0 | 8.2.0 | v8.2 | v8.2 | Upgrade | 14.0.1     |
| 5.3.0 | 9.0.0 | 8.2.0 | >=1.0.1 <9.0.0 | 9.0.0 | v9.0 | v9.0 | Upgrade | 14.0.2     |
| 5.3.1 | 9.1.0 | 9.0.0 | >=1.0.1 <9.1.0 | 9.1.0 | v9.1 | v9.1 | Upgrade | 14.0.2     |
| 5.4.0 | 10.0.0| 9.1.0 | >=1.0.1 <10.0.0| 10.0.0| v10.0| v10.0| Upgrade | 14.0.2     |
| 5.4.4 | 10.0.4| 10.0.0 | >=1.0.1 <10.0.4| 10.0.4| v10.0| v10.0| Upgrade | 14.0.3-2     |

### Installing in an air-gapped OpenShift cluster without bastion

#### 1. Prepare a portable device

Prepare a portable device, such as laptop, that be used to download the CASE and images and that can be carried into the air-gapped environment.

* Verify that the portable device has access to:
  * Public internet (to download CASE and images).
  * A target image registry ( where the images will be mirrored).
  * A target openshift cluster to install the operator.

* Download and install the required command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with the Red Hat OpenShift cluster.

All of the following steps should be run from the portable device.

#### 2. Download CASE

See instructions from the previous [Downloading CASE](#2-download-case) section.

#### 3. Configure registry authentication

See the instructions from the previous [Configure registry authentication](#3-configure-registry-auth) section.

#### 4. Mirror images

See the instructions from the previous [Mirror images](#4-mirror-images) section.

#### 5. Configure the air-gapped cluster

See the instructions from the previous [Configure the air-gapped cluster](#5-configure-cluster-for-airgap) section.

### 6. Install the catalog source

See the instructions from the previous [Install the catalog source](#6-install-catalog-source) section.

### 7. Install the operator

See the instructions from the [Operator installation section](#Operator installation section) section.

## Configuration

For information about configuring and administering services in IBM Cloud Pak for Data, see [IBM Documentation](https://www.ibm.com/docs/SSQNUZ_4.0/cpd/admin/administer.html)

## Storage

For information about storage in IBM Cloud Pak for Data, see [IBM Documentation](https://www.ibm.com/docs/SSQNUZ_4.0/cpd/plan/storage_considerations.html).

## Limitations

Only one service instance of IBM Match 360 with Watson is supported per namespace.

## Documentation

For more information about installing, configuring, and using IBM Match 360 with Watson, see [IBM Documentation](https://www.ibm.com/docs/SSQNUZ_4.0/svc-welcome/mdc.html).
