# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this product master operator

# operator specific variables
caseName="ibm-productmaster"
inventory="productmasterOperatorSetup"
caseCatalogName="ibm-productmaster-catalog"
catalogNamespace="openshift-marketplace"
channelName="alpha"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-productmaster-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:sha256:c86b16e0d997f19618eace2a680474e4d687426adea99bac182b591c214664a1}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
CATALOG_IMAGE="${CATALOG_IMAGE:-ibm-cpd-productmaster-operator-catalog}"
#CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:e8769f8dc2b97f1efa57a4199c14ffbd601ce00f83b5befd3eb3d36bfac3fd49}"
BUILD_NUMBER="19"
entitledRegistry="icr.io/cpopen"
storageclass=""
#backupstorageclass=""
#scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
#casePath="${scriptDir}/../../../../.."

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
#    ibm-couchdb)
#        echo "couchdbOperatorSetup"
#        return 0
#        ;;
#    ibm-cp-common-services)
#        echo "ibmCommonServiceOperatorSetup"
#        return 0
#        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

#    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    echo "Inside  launch-impl.sh install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi
    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX=""
    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    productmastersetup_defintion_files="${casePath}/inventory/productmasterOperatorSetup/files"
    echo "productmastersetup_defintion_files: ${productmastersetup_defintion_files}"

    productmaster_crd_files="${productmastersetup_defintion_files}/op-cli/productmaster.cpd.ibm.com_productmasters.yaml"
    validate_file_exists ${productmaster_crd_files}
    operator_files="${productmastersetup_defintion_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${productmastersetup_defintion_files}/op-cli/role.yaml"
    validate_file_exists "${productmastersetup_defintion_files}/op-cli/service_account.yaml"
    validate_file_exists "${productmastersetup_defintion_files}/op-cli/role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required
    # create CDR
    $kubernetesCLI apply ${dryRun} -f ${productmaster_crd_files} 
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${productmastersetup_defintion_files}/op-cli/role.yaml
    #$kubernetesCLI apply ${dryRun} -f ${productmastersetup_defintion_files}/op-cli/cluster_role.yaml
    sed <${productmastersetup_defintion_files}/op-cli/service_account.yaml "s| system| ${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    #$kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${productmastersetup_defintion_files}/op-cli/role_binding.yaml
    sed <${productmastersetup_defintion_files}/op-cli/role_binding.yaml "s| system| ${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    cat ${productmastersetup_defintion_files}/op-cli/role_binding.yaml
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
 
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/productmaster_v1_productmaster.yaml

    echo "storageclass: ${storageclass}"

    if [[ -z ${storageclass} ]]; then
        storageclass="\"\""
    fi

    validate_file_exists "$cr"

    sed "${cr}" -e "s/accept: false/accept: true/g" -e "s/domain_name:.*/domain_name: ${domainname}/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/productmaster.cpd.ibm.com_productmasters.yaml; do
        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    done
    # - dependent resources
    #$kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    # Delete catalog source
    #$kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
    # Delete operator group
    #echo "uninstalling uninstall_operator_group"
    #uninstall_operator_group
    #local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    #validate_file_exists "${opgrp_file}"

    #sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI delete ${dryRun} -n "${namespace}" -f -) | cat
    #cat ${opgrp_file}

}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    productmastersetup_defintion_files="${casePath}/inventory/productmasterOperatorSetup/files"
    echo "productmastersetup_defintion_files: ${productmastersetup_defintion_files}"

    productmaster_crd_files="${productmastersetup_defintion_files}/op-cli/productmaster.cpd.ibm.com_productmasters.yaml"
    validate_file_exists ${productmaster_crd_files}
    operator_files="${productmastersetup_defintion_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${productmastersetup_defintion_files}/op-cli/role.yaml"
    validate_file_exists "${productmastersetup_defintion_files}/op-cli/service_account.yaml"
    validate_file_exists "${productmastersetup_defintion_files}/op-cli/role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required

#    sed <"${operator_files}" "s| system| ${namespace}|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    $kubernetesCLI delete ${dryRun} -n "${namespace}" deploy controller-manager
    #sed <"${productmastersetup_defintion_files}/op-cli/cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${productmastersetup_defintion_files}/op-cli/role_binding.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${productmastersetup_defintion_files}/op-cli/service_account.yaml
    #$kubernetesCLI delete ${dryRun} -f ${productmastersetup_defintion_files}/op-cli/cluster_role.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${productmastersetup_defintion_files}/op-cli/role.yaml
    # delete CDR
    $kubernetesCLI delete ${dryRun} -f ${productmaster_crd_files}

}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/productmaster_v1_productmaster.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
