# Introduction
Contains the IBM Product Master Operator custom resource and launch scripts to install/delete the custom resources

## Details
IBM&reg; Product Master Provides trusted product information management (PIM) capabilities. Product Master Aggregates information from upstream system, enforces business processes for accuracy and consistency, and synchronises trusted information with downstream systems.

## Features
Product Master provides the following PIM solutions:
- 	Creates an accurate and up-to-date repository of product and service information that can be used throughout organizations for strategic business initiatives.
- Aggregates information from any upstream system, enforces business processes to ensure data accuracy and consistency, and synchronizes trusted information with downstream systems.
- Tools for modelling, capturing, creating, and managing information with high user productivity and high information quality.
- The ability to integrate and synchronize information with existing systems, enterprise applications, repositories, and masters.
- Business user workflows for supporting multi-department and multi-enterprise business processes.
- The ability to exchange and synchronize information externally with Business Partners.

## Storage
IBM Product Master Cartridge for IBM Cloud Pak for Data supports dynamic storage provisionging using storage class.  The following storages are supported
- NFS
- Portworx 2.7 
- OCS

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.

## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
## Limitations
Only one instance of IBM Product Master Cartridge operator can be deployed in a cluster.  Multiple instances of Product Master operands can be deployed in different namespaces in a cluster.

IBM Product Master Cartridge only run on amd64 architecture type

## Copyright and trademark information
© Copyright IBM Corporation 2020
U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule
Contract with IBM Corp.
IBM®, the IBM logo and ibm.com® are trademarks of International Business Machines Corp., registered in m
any jurisdictions worldwide. Other product and service names might be trademarks of IBM or other compani
es. A current list of IBM trademarks is available on the Web at "Copyright and trademark information" at
 [www.ibm.com/legal/copytrade.shtml](https://www.ibm.com/legal/copytrade.shtml).

