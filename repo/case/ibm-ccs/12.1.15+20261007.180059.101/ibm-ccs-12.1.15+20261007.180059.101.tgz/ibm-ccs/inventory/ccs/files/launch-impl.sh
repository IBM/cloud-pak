# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ccs operator

# ccs operator specific variables
caseName="ibm-ccs"
inventory="ccsSetup"
channelName="v2.0"
cr_system_status="betterThanYesterday"

# - additional variables
entitledRegistry="icr.io/cpopen"
storageclass=""
filestorageclass=""
blockstorageclass=""
storagevendor=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
#    ibm-couchdb)
#        echo "couchdbOperatorSetup"
#        return 0
#        ;;
#    ibm-cp-common-services)
#        echo "ibmCommonServiceOperatorSetup"
#        return 0
#        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/ccs_cr.yaml

    echo "storagevendor: ${storagevendor}, storageclass: ${storageclass}, filestorageclass: ${filestorageclass}, blockstorageclass: ${blockstorageclass}"
    if [[ -z ${filestorageclass} && -z ${storageclass} ]]; then
        err_exit "storageclass and filestorageclass MUST not all empty"
    fi

    validate_file_exists "$cr"
    cp $cr ${casePath}/inventory/${inventory}/files/op-cli/tmp_ccs_cr.yaml
    local tmpcr="${casePath}/inventory/${inventory}/files/op-cli/tmp_ccs_cr.yaml"
    validate_file_exists "$tmpcr"

    if [[ ! -z $storageclass ]]; then
        sed -i "/^\ \ license:.*/i \ \ storageClass: ${storageclass}" ${tmpcr}
    fi
    if [[ ! -z $filestorageclass ]]; then
        sed -i "/^\ \ license:.*/i \ \ fileStorageClass: ${filestorageclass}" ${tmpcr}
    fi
    if [[ ! -z $blockstorageclass ]]; then
        sed -i "/^\ \ license:.*/i \ \ blockStorageClass: ${blockstorageclass}" ${tmpcr}
    fi
    echo "AFTER processing filestorageclass and blockstorageclass"
    cat ${tmpcr}

    echo
    echo
    if [[ -z $storagevendor ]]; then
        sed "${tmpcr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g"  | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
        if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" && ${storagevendor} != "\"\"" ]]; then
            err_exit "storagevendor value must be empty, \"ocs\" or \"portworx\""
        fi
        sed "${tmpcr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "/^\ \ license:.*/i \ \ storageVendor: ${storagevendor}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi
    rm ${tmpcr}
}

# ----- UNINSTALL ACTIONS -----

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/ccs_cr.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}

