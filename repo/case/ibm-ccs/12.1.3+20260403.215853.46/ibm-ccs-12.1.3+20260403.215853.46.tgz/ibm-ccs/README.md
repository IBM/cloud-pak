# Name

IBM&reg; IBM Cloud Pak for Data Common Core Services

# Introduction

## Summary

IBM Cloud Pak for Data Common Core Services is the common components for Cloud Pak for Data services.
See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/overview/overview.html)

## Features

IBM Cloud Pak for Data Common Core Services includes 
- data store
- catalog
- project
- space
- job
- runtimes utility
- environment
- notification
- common ui


# Details

## Prerequisites

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/install/preinstall-overview.html)

### Resources Required

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/cpd/plan/rhos-reqs.html#rhos-reqs__production#rhos-reqs__production)

# Installing

IBM Cloud Pak for Data Common Core Services is not installed by itself.  It is installed with Watson Studio, Watson Knowledge Catalog, Watson Machine Learning.
See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/install/install.html)

## Configuration
You can change the size of CCS by changing the `spec.size` value in CCS cr.

## Storage
See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/cpd/plan/storage_considerations.html)

## Limitations
IBM Cloud Pak for Data Common Core Services is not installed by itself.  It is installed with Watson Studio, Watson Knowledge Catalog, Watson Machine Learning.  See correponding section in respective services.


## Documentation
See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/overview/overview.html)

## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restrict denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restrict
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

