# Name

IBM&reg; Content Assistant Operator

# Introduction

## Summary
IBM Content Assistant Operator is designed to improve operational visibility, decision-making, and automation within organizations. It utilizes sophisticated analytics, artificial intelligence (AI), and machine learning technologies to examine events from diverse sources across business processes. Through this analysis, businesses can better understand their operations, recognize patterns, anticipate outcomes, and refine processes to enhance efficiency and effectiveness.

## Features

Follow [link](https://www.ibm.com/docs/en/bai/24.0.0?topic=discovering-business-automation-insights) for more details.

IBM Business Automation Insights is designed to improve operational visibility, decision-making, and automation within organizations. It utilizes sophisticated analytics, artificial intelligence (AI), and machine learning technologies to examine events from diverse sources across business processes. Through this analysis, businesses can better understand their operations, recognize patterns, anticipate outcomes, and refine processes to enhance efficiency and effectiveness See https://www.ibm.com/docs/en/bai/24.0.0 for more information.

# CASE Details

## Prerequisites

- Redhat Openshift Container Platform version 4.14 and above
- NFS Server or Gluster File System or cloud-specific storage system
- Follow this install instructions to install the product. [link](https://www.ibm.com/docs/en/bai/24.0.0?topic=installing)
- The deployment scripts guide to install the product with required dependencies.

# PodSecurityPolicy Requirements

# SecurityContextConstraints Requirements

### Red Hat OpenShift SecurityContextConstraints Requirements
This Operator requires a SecurityContextConstraints to be bound to the target namespace prior to installation. This Operator is namespace scoped so it can deploy into any target namespace and furthermore you can deploy the Operator multiple times using difference namespaces.

1. For Red Hat OpenShift, add SecurityContextConstraints (SCC) requirements.
If you are installing the chart on Red Hat OpenShift or OKD, the privileged SecurityContextConstraint resource is required for the installation. For more information, see IBM Cloud Pak SecurityContextConstraints Definitions.

2. For RedHat OpenShift, if applicable, add policies to enable the Pod resources to start the containers by using the required UIDs.


### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| CP4A      |  32 GB      |    16       |   500     |  5    |


# Download required container images.
- You can access the container images in the IBM Entitled registry with your IBMid (Option 1), or you can use the downloaded archives from IBM Passport Advantage (PPA) (Option 2).

        * Create a pull secret for the IBM Cloud Entitled Registry
          - Log in to [MyIBM Container Software Library](https://myibm.ibm.com/products-services/containerlibrary) with the IBMid and password that are associated with the entitled software.
          - In the **Container software library** tile, click **View library** and then click **Copy key** to copy the entitlement key to the clipboard.
          - Create a pull secret by running a `kubectl create secret` command.
             ```bash
             $ kubectl create secret docker-registry <my_pull_secret> --docker-server=cp.icr.io --docker-username=iamapikey --docker-password="<API_KEY_GENERATED>" --docker-email=user@foo.com
             ```
             > **Note**: The `cp.icr.io` value for the **docker-server** parameter is the only registry domain name that contains the images.
          - Take a note of the secret and the server values so that you can set them to the **pullSecrets** and **repository** parameters when you run the operator for your containers.


# Installing the CASE

- Follow this link to install using the CASE. [link](https://www.ibm.com/docs/en/bai/24.0.0?topic=deployment-preparing-your-cluster-air-gapped-offline) 


## Configuration

Create a namespace and execute IBM Business Automation Insights deployment.

## Storage

IBM® Business Automation Insights supports a NFS storage system.  A NFS storage system needs to be created as a pre-req before deploying IBM® Business Automation Insights chart. 
Dynamic Provisioning of PersistenceVolumes is not supported by provising Storage Class in Custom Resource file.

## Documentation

## Details
- Documentation link [link](https://ibmdocs-test.dcs.ibm.com/docs/en/bai/24.0.0)

## Limitations
- Known limitations. [link](https://ibmdocs-test.dcs.ibm.com/docs/en/bai/24.0.0?topic=notes-known-limitations)
