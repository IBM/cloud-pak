# IBM Voice Gateway Operator

## Introduction

This Operator will allow you to deploy IBM Voice Gateway.

### Summary

[IBM Voice Gateway](https://www.ibm.com/support/knowledgecenter/SS4U29/welcome_voicegateway.html) provides a way to integrate a set of orchestrated Watson services with a public or private telephone network by using the Session Initiation Protocol (SIP). Voice Gateway enables direct voice interactions over a telephone with a cognitive self-service agent or transcribes a phone call between a caller and agent so that the conversation can be processed with analytics for real-time agent feedback.

### Features

- Check out all the features of IBM Voice Gateway on [About IBM Voice Gateway](https://www.ibm.com/docs/en/voice-gateway?topic=gateway-about-voice) page.

## Details

### Prerequisites

- Download and install the command line tools:
  - [oc](https://docs.openshift.com/container-platform/4.12/cli_reference/openshift_cli/getting-started-cli.html#installing-openshift-cli) - To interact with Openshift Cluster
  - [ibm-pak](https://github.com/IBM/ibm-pak) - To download and install CASE

### Resources Required

System requirements:

```text
RAM         8 gigabytes (GB)
vCPUs       2 vCPU with x86-64 architecture at 2.4 GHz clock speed
                Note: Varies based on expected number of concurrent calls and other factors
Storage     50 gigabytes (GB)
                Note: Call recording and log storage settings significantly affect storage requirements
```

## Installing

For detailed installation instruction including airgap installation refer to [Installing Voice Gateway](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.7.x?topic=gateway-installing) page.

### 1. Configure local env variables

```bash
## Set the following variables

export LOCALDIR="CASE download directory"
export NAMESPACE="Voice gateway installation namespace"
```

### 2. Download CASE to a local directory

- Download the case:

  ```bash
  oc ibm-pak get ibm-voice-gateway
  ```

- Edit the sample voicegateway located inside the case:
  `${LOCALDIR}/ibm-voice-gateway/inventory/voiceGatewayOperator/files/config/samples/voicegateway_v1_voicegateway.yaml`

  Refer to [Administering Voice Gateway](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.7.x?topic=gateway-administering) for advanced options available in the custom resource.

### 3. Install Catalog

```bash
oc ibm-pak launch ibm-voice-gateway     \
  --namespace openshift-marketplace     \
  --inventory voiceGatewayOperatorSetup \
  --action install-catalog              \
  --tolerance 1
```

### 4. Install Operator

```bash
oc ibm-pak launch ibm-voice-gateway     \
  --namespace ibm-common-services       \
  --inventory voiceGatewayOperatorSetup \
  --action install-operator             \
  --tolerance 1
```

### 5. Configure tenant configuration secret

- Create a tenantConfig.json with the tenant credentials and any additional parameters. A sample tenantConfig.json can be found in the [tenantConfig.json](https://github.com/WASdev/sample.voice.gateway/blob/master/kubernetes/multi-tenant/tenantConfig.json) file.

- Visit [Advanced JSON configuration](https://www.ibm.com/support/knowledgecenter/SS4U29/json_config_props.html) for more information on configuring this file.

- Create a secret `vgw-tenantconfig-secret` from the tenantConfig.json file using the following command:

  ```bash
  oc create secret generic vgw-tenantconfig-secret --from-file=tenantConfig=/PATH_TO_FILE/tenantConfig.json -n ${NAMESPACE}
  ```

### 6. Create an Image Pull Secret using the Entitled Key

```bash
## Set the following variables

ENTITLEDKEY="Use your IBM image entitlement key"
EMAIL="Use the email value"
NAMESPACE="Use the targeted namespace value"
```

```bash
oc create secret docker-registry ibm-entitlement-key    \
  --docker-server=cp.icr.io                               \
  --docker-username=cp                                    \
  --docker-password=${ENTITLEDKEY}                        \
  --docker-email=${EMAIL}                                 \
  --namespace=${NAMESPACE}
```

### 7. Create voicegateway custom resource

```bash
oc ibm-pak launch ibm-voice-gateway \
  --namespace ${NAMESPACE}          \
  --inventory voiceGatewayOperator  \
  --action apply-custom-resources   \
  --tolerance 1
```

## Uninstallation

### 1. Delete your custom resource

```bash
oc delete voicegateway YOUR_CUSTOM_RESOURCE_NAME -n ${NAMESPACE}
```

### 2. Delete secret `vgw-tenantconfig-secret`

```bash
oc delete secret vgw-tenantconfig-secret -n ${NAMESPACE}
```

### 3. Uninstall operator

```bash
oc ibm-pak launch ibm-voice-gateway     \
  --namespace ibm-common-services       \
  --inventory voiceGatewayOperatorSetup \
  --action uninstall-operator           \
  --tolerance 1
```

### 4. Uninstall catalog

```bash
oc ibm-pak launch ibm-voice-gateway     \
  --namespace openshift-marketplace     \
  --inventory voiceGatewayOperatorSetup \
  --action uninstall-catalog            \
  --tolerance 1
```

## Configuration

- Refer to [Administering Voice Gateway](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.7.x?topic=gateway-administering) for advanced options available in the custom resource.

## Limitations

- Because IBM Voice Gateway uses `hostNetwork` mode, you can only deploy 1 pod per node.
- Need an external SIP load balancer for load balancing across more than 1 pod.

## Documentation

[WAVI on Cloud Pak for Data](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.7.x?topic=services-watson-assistant-voice-interaction)
[Voice Gateway on Cloud Pak for Data](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.7.x?topic=services-voice-gateway)
