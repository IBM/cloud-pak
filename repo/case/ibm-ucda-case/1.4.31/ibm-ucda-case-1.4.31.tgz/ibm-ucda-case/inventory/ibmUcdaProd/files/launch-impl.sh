# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ibm-ucda-prod helm chart

# ----- INSTALL ACTIONS -----

valuesPath=""
helmReleaseName=""
helmChartPath=""

# Installs the helm chart
install_helm_chart() {
    echo helm install ${helmReleaseName} ${helmChartPath} --namespace ${namespace} --values ${valuesPath} 
    helm install ${helmReleaseName} ${helmChartPath} --namespace ${namespace} --values ${valuesPath}
}

# Uninstalls the helm release
uninstall_helm_chart() {
    echo helm delete ${helmReleaseName}
    helm delete ${helmReleaseName}
}

# Override default parse_custom_dynamic_args function.
# Parses the args (--args) parameter if any are specified
parse_custom_dynamic_args() {
    key=$1
    val=$2

    if [[ "$key" =~ -- ]]; then
        echo "Parsing arg: ${key}=${val}"
    fi

    case $key in
        --helmReleaseName)
            helmReleaseName="$val"
            ;;
        --helmChartPath)
            helmChartPath="$val"
            ;;
        --valuesPath)
            valuesPath="$val"
            ;;
    esac
}
