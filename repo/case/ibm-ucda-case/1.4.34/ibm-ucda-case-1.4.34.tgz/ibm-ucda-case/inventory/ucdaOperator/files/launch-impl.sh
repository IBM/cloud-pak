# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ibm-ucda-prod operator

# ibm-urbancode-deploy operator specific variables
caseName="ibm-ucda-case"
inventory="ucdaOperatorSetup"
caseCatalogName="ucda-operator-catalog"
channelName="v3.0"   # Needs to match value specified in operator Makefile
registry="${TARGET_REGISTRY:-icr.io/cpopen}"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
catalogDigest="@sha256:a9f04aa9e414c81a900bb4fa92281210dd026c3ca2560a2dec070573b0f208f9"

# - optional parameter / argument defaults
crFile=""                   # specify custom resource file path

# ----- INSTALL ACTIONS -----


install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog


    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

    # replace original registry with local registry
    local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^1]*\///")"

    # correct digest and apply catalog source
    sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat

    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing native-------------"

    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local manifest_file="${op_cli_files}/manifestsNativeDeploy.yaml"

    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
    sed -e "s|ucda-operator-system|${namespace}|g" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"

    echo "Installing resource from ${crFile} file "

    local cr="${crFile}"
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    set -e
    cat "${cr}" | $kubernetesCLI apply ${dryRun} -n "$namespace" -f -
    set +e
}

# ----- UNINSTALL ACTIONS -----


# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"


    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete ${dryRun} -f "${catsrc_file}" --ignore-not-found=true
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete ${dryRun} subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete ${dryRun} clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete ${dryRun} OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
        $kubernetesCLI delete ${dryRun} -f "${crdYaml}" --ignore-not-found=true
    done
    # Delete catalog source
    # $kubernetesCLI delete ${dryRun} CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    echo "-------------Uninstalling operator native-------------"

    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local manifest_file="${op_cli_files}/manifestsNativeDeploy.yaml"

    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
    sed -e "s|ucda-operator-system|${namespace}|g" "${manifest_file}" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -

}

# delete operand custom resources
delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"

    echo "Deleting resource from ${crFile} file "

    local cr="${crFile}"
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    set -e
    cat "${cr}" | $kubernetesCLI delete ${dryRun} -n "$namespace" -f -
    set +e
}

# Override default parse_custom_dynamic_args function.
# Parses the args (--args) parameter if any are specified
parse_custom_dynamic_args() {
    key=$1
    val=$2

    if [[ "$key" =~ -- ]]; then
        echo "Parsing arg: ${key}=${val}"
    fi

    case $key in
        --crFile)
            crFile="$val"
            ;;
    esac
}
