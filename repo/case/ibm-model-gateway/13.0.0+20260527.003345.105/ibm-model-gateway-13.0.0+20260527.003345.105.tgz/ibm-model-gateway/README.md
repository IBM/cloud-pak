# Name

IBM&reg; IBM Cloud Pak for Data Model Gateway Services

# Introduction

## Summary

IBM Cloud Pak for Data Model Gateway provides...

See [Details]()

## Features

The Model Gateway service is...

# Details

## Prerequisites

See [Details]()

### Resources Required

See [Details]()


# Installing

See [Details]()

## Configuration

You can change the size of Model Gateway by changing the `spec.size` value in modelgateway cr.

## Storage

See [Details]()

## Limitations
See [Details]()


## Documentation

See [Details]()

## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restrict denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restrict
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```