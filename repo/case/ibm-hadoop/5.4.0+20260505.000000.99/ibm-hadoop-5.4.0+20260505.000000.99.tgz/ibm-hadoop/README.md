# Name

IBM&reg; Execution Engine for Apache Hadoop

# Introduction

Explore data or build models on your Apache Hadoop cluster.

## Summary

Use the Execution Engine for Apache Hadoop service to integrate the Watson Studio service with your remote Apache Hadoop cluster.

## Features

When the Execution Engine for Apache Hadoop service is installed, data scientists can:
- Use familiar tools, such as Data Refinery, Jupyter Notebooks, and RStudio, to build models and then train and deploy models at scale
- Leverage the distributed computing power of a Hadoop cluster
- Analyze data in place
- Use packages and libraries from Watson Studio without installing them on your Hadoop cluster

# Details

## Prerequisites

IBM Execution Engine for Apache Hadoop requires the following:
- WSL version 2.0.0 or later and its dependencies
- Hadoop Execution Engine RPM product installed and configured on a Hadoop Edge node.

### Resources Required

The base IBM Execution Engine for Apache Hadoop requires .5 vCPU / 512 Mi of resources to run.  Depending on how many remote systems registration as well as how many concurrent job sessions planned to be run, the memory / CPU usage will vary.  Please note that Refinery or Notebook jobs leveraging Hadoop remote environments will calculate the resource consumption base on Refinery and Notebook job definitions. 

Minimum scheduling capacity:

| Software  | Memory | CPU (vCPU) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Hadoop addon catalog  |   50Mi  | 10m  | N/A |           |
| Hadoop addon operator | 1024Mi  | 500m | N/A |           |
| Hadoop operand        |  512Mi  | 0.5  | ~2 GB per image pushed | |
|  - per registration   |  .5 GB  | 0.5  | ~5kb per registration | |
|  - per script job     | .25 GB  | 0.3  | N/A |
| **Total**             | 1586Mi  | 1.1  |     |       |



# Installing

1. Ensure that pre-requisite has been installed.

2. Get `cloudctl`

You'll likely to have already completed this step when you install WSL. You can download the latest `cloudctl` binary from the [release page](https://github.com/IBM/cloud-pak-cli/releases). Please note that only the linux version of `cloudctl` has been tested.

3. Setup registry mirror (Optional) 

You will likely to have already completed this step when you install WSL.  The images for IBM Execution Engine for Apache Hadoop are available in registry (cp.icr.io/cp/cpd and icr.io/cpopen).  If cluster cannot access these registries, add registry mirror to re-direct registry to local registry where images are available by create `ImageContentSourcePolicy` like below 
```
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - <registry repository and namespace for operand images>
    source: cp.icr.io/cp/cpd
  - mirrors:
    - <registry repository and namespace for operator images>
    source: icr.io/cpopen
```

4. Download IBM Execution Engine for Apache Hadoop case bundle

5. Install Hadoop Operator 
### Install Hadoop Operator Native using cloudctl
Run the commnand below to create Hadoop operator Native
```
cloudctl case launch --case <hadoop case tgz file> --tolerance 1 --namespace <operator project> --action installOperatorNative --inventory hadoopSetup --args "--registry cp.icr.io/cp"
```

### Install Hadoop Operator OLM using cloudctl
Run the commnand below to create Hadoop operator OLM
```
cloudctl case launch --case <hadoop case tgz file> --tolerance 1 --namespace <operator project> --action installOperator --inventory hadoopSetup --args "--registry cp.icr.io/cp"
```

6. Install Hadoop
### Install Hadoop using `oc apply -f`
This install method supports Hadoop Operator installed by Native or OLM method. Please verify the actual storageclass name by running `oc get sc` for the different storageclass configurations.

Update the command below with values matching your deployment, then run it.
```
cat << EOF | oc apply -f -
apiVersion: hadoop.cpd.ibm.com/v1
kind: Hadoop
metadata:
  name: hadoop-cr
  namespace: <cpd project>
spec:
  version: "5.4.0"
  size: "small"
  storageClass: <storageclass name>
  storageVendor: <"" for NFS, or "ocs" or "portworx">
  license:
    accept: true
    license: Enterprise
EOF
```

### Install Hadoop using cloudctl
This install method supports Hadoop Operator installed by Native or OLM method. Please verify the actual storageclass name by running `oc get sc` for the different storageclass configurations.

Run the command below to install Hadoop with NFS storage
```
cloudctl case launch --case <hadoop case tgz file> --tolerance 1 --namespace <cpd project> --args "--storageclass <storageclass name>" --action applyCustomResources --inventory hadoop
```

Run the command below to install Hadoop with Portworx storage
```
cloudctl case launch --case <hadoop case tgz file> --tolerance 1 --namespace <cpd project> --args "--storageclass <storageclass name> --storagevendor portworx" --action applyCustomResources --inventory hadoop
```

Run the command below to install Hadoop with OCS storage
```
cloudctl case launch --case <hadoop case tgz file> --tolerance 1 --namespace <cpd project> --args "--storageclass <storageclass name> --storagevendor ocs" --action applyCustomResources --inventory hadoop
```

### Install Hadoop from Openshift Console
This install method supports Hadoop Operator installed by OLM method.

In OpenShift console, on left menu select Operators > Installed Operators.  In Project drop down menu at top of the page, select the project which Hadoop operator is installed.  Click on `Execution Engine for Apache Hadoop` row, then click `Create Instance`.

- Fill in the form leveraging some of the drop down values that are already populate.  Make sure you accept license.
- Select `YAML View`, update the following fields:
  - spec.namespace: `<cpd project>`
  - spec.size: only `small` is supported
  - spec.storageVendor (Select `ocs` or `portworx`; set "" if it is NFS storage)

## Configuration
The IBM Execution Engine for Apache Hadoop add-on only supports "small" size deployment and does not require additional configurations other than creating the appropriate CR above. 

## Storage
IBM Execution Engine for Apache Hadoop supports dynamic storage provisionging using storage class.  The following storages are supported
- NFS
- Portworx 2.7 
- OCS

## Limitations

Only one instance of IBM Execution Engine for Apache Hadoop (Hadoop) operator can be deployed in a cluster.  Multiple instances of Hadoop operands can be deployed in different namespaces in a cluster.  These operands requires that CCS and WS operands are also installed in these namespaces.


## Documentation

https://www.ibm.com/docs/en/SSQNUZ_4.0/svc-welcome/hadoopaddon.html

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be r
un with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive
SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

