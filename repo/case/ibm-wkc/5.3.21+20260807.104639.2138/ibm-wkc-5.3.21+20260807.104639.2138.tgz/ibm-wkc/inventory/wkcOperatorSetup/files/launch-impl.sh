# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ccs operator

# wkc operator specific variables
caseName="ibm-wkc"
inventory="wkcOperatorSetup"
caseCatalogName="ibm-cpd-wkc-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="v9.21"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
case_depedencies="ibm-ccs ibm-fdb ibm-analyticsengine ibm-datarefinery ibm-datastage-enterprise mantaflow"

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-wkc-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:9829db7eef7dd5818b73f2c779f333478103e655141166f3ca32df9b5cd70691}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
CATALOG_IMAGE="${CATALOG_IMAGE:-ibm-cpd-wkc-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:af95f5902d0f75c420aaac35b71fe16afcefc47110c7f001f85a89867e1956f3}"
entitledRegistry="icr.io/cpopen"
storageclass=""
service=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageclass)
        storageclass=$val
        ;;
    --service)
        service=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    ibm-fdb)
        echo "fdbOperator"
        return 0
        ;;
    ibm-analyticsengine)
        echo "analyticsengineOperatorSetup"
        return 0
        ;;
    ibm-datastage-enterprise)
        echo "dsOperatorSetup"
        return 0
        ;;
    ibm-datarefinery)
        echo "datarefinerySetup"
        return 0
        ;;    
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        arch=$(uname -m)
        if [[ ${dep} == "ibm-fdb" && ${arch} != "x86_64" ]]; then
          echo "Non x86_64 system detected skipping FDB Catalog install"
          continue
        fi

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    CATALOG_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${CATALOG_IMAGE}@${CATALOG_DIGEST}

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        #tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
        sed <"${catsrc_file}" "s|image: .*|image: ${CATALOG_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -f -
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        #local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
        local catsrc_image_mod="${registry}/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/[^/]*\///")"
        if [[ ${registry} == "cp.stg.icr.io" ]]; then
            local catsrc_image_mod="${registry}/cp/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/.*\///")"
        fi
        # apply catalog source
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group


    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"
    local service_account_file="${casePath}/inventory/${inventory}/files/op-cli/wkc_operator_serviceaccount.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "Checking if catalog source exists ..."
    catsrc_exist=$(oc get catsrc "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true)
    if [[ -z $catsrc_exist ]]; then
        echo "Creating catalog source '${caseCatalogName}' in namespace '${catalogNamespace}'"
        install_catalog
        echo "Wait for catalog installation to complete"
        sleep 30
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    #sed "${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    $kubernetesCLI apply -f "${subscription_file}" -n ${namespace}
    echo "Wait for subscription to complete"
    sleep 60

    $kubernetesCLI apply -f "${service_account_file}" -n ${namespace}

    echo "done"
}

# Install utilizing default CLI method
install_operator_native() {
    echo "Inside  launch-impl.sh install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="wkc"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/wkcOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    wkc_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkc.yaml"
    validate_file_exists ${wkc_crd}
    workflow_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_workflow.yaml"
    validate_file_exists ${workflow_crd}
    profiling_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_profiling.yaml"
    validate_file_exists ${profiling_crd}
    glossary_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_glossary.yaml"
    validate_file_exists ${glossary_crd}
    metadataimports_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_metadataimports.yaml"
    validate_file_exists ${metadataimports_crd}
    enrichment_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_enrichment.yaml"
    validate_file_exists ${enrichment_crd}
    wkcgovui_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkcgovui.yaml"
    validate_file_exists ${wkcgovui_crd}
    finley_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_finley.yaml"
    validate_file_exists ${finley_crd}
    policy_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_policy.yaml"
    validate_file_exists ${policy_crd}
    knowledgegraph_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_knowledgegraph.yaml"
    validate_file_exists ${knowledgegraph_crd}
    dataquality_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_dataquality.yaml"
    validate_file_exists ${dataquality_crd}
    semanticsearch_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_semanticsearch.yaml"
    validate_file_exists ${semanticsearch_crd}
    operator_files="${setup_definition_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required
    # create CRD
    $kubernetesCLI apply ${dryRun} -f ${wkc_crd}
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml

    # Append OPERATOR_PREFIX to all resources under rbac
    sed <"${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

}

# # install operand custom resources
# apply_custom_resources() {
#     echo "-------------Applying custom resources-------------"
#     #local cr="${casePath}"/inventory/"${inventory}"/files/sample_v1beta1_panamax.yaml
#     local wkc_cr="${casePath}"/inventory/"${inventory}"/files/config/samples/cpd_v1beta1_wkc.yaml
#
#     echo "storageclass: ${storageclass}"
#     if [[ -z ${storageclass} ]]; then
#         echo "storageclass is empty, defaulting to managed-nfs-storage"
#         storageclass="managed-nfs-storage"
#     fi
#
#     validate_file_exists "$wkc_cr"
#     validate_file_exists "$ug_cr"
#
#     echo "service: ${service}"
#     if [[ -z ${service} ]]; then
#       echo "No service specified, deploying both WKC and UG custom resources"
#       sed "${wkc_cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
#       sed "${ug_cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
#     elif [[ "${service}" == "wkc" ]]; then
#       echo "Deploying WKC custom resource"
#       sed "${wkc_cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
#     elif [[ "${service}" == "ug" ]]; then
#       echo "Deploying UG custom resource"
#       sed "${ug_cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
#     fi
# }

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        arch=$(uname -m)
        if [[ ${dep} == "ibm-fdb" && ${arch} != "x86_64" ]]; then
          echo "Non x86_64 system detected skipping FDB Catalog uninstall"
          continue
        fi

        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Get subscription name
    caseSubName=$($kubernetesCLI get sub -n "${namespace}" | grep ibm-cpd-wkc-operator | cut -d' ' -f1|head -1)
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseSubName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseSubName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${ namespace}" --ignore-not-found=true

    # delete crds
    $kubernetesCLI delete crd wkc.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd workflow.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd profiling.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd glossary.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd metadataimports.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd enrichment.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd wkcgovui.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd finley.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd policy.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd knowledgegraph.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd dataquality.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd semanticsearch.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    # delete installplan
    installplanName=$($kubernetesCLI get installplan -n ${namespace} --no-headers|grep $csvName|cut -d' ' -f1|head -1)
    [[ -n "${installplanName}" ]] && { $kubernetesCLI delete installplan "${installplanName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    OPERATOR_PREFIX="wkc"

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/wkcOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    wkc_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkc.yaml"
    validate_file_exists ${wkc_crd}
    workflow_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_workflow.yaml"
    validate_file_exists ${workflow_crd}
    profiling_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_profiling.yaml"
    validate_file_exists ${profiling_crd}
    glossary_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_glossary.yaml"
    validate_file_exists ${glossary_crd}
    metadataimports_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_metadataimports.yaml"
    validate_file_exists ${metadataimports_crd}
    enrichment_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_enrichment.yaml"
    validate_file_exists ${enrichment_crd}
    wkcgovui_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkcgovui.yaml"
    validate_file_exists ${wkcgovui_crd}
    finley_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_finley.yaml"
    validate_file_exists ${finley_crd}
    policy_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_policy.yaml"
    validate_file_exists ${policy_crd}
    knowledgegraph_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_knowledgegraph.yaml"
    validate_file_exists ${knowledgegraph_crd}
    dataquality_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_dataquality.yaml"
    validate_file_exists ${dataquality_crd}
    semanticsearch_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_semanticsearch.yaml"
    validate_file_exists ${semanticsearch_crd}
    operator_files="${setup_definition_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required

    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" deploy ibm-cpd-wkc-operator
    sed <"${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role.yaml
    # delete CDR
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${wkc_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${workflow_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${profiling_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${glossary_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${metadataimports_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${enrichment_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${wkcgovui_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${finley_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${policy_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${knowledgegraph_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${dataquality_crd}
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f ${semanticsearch_crd}
}

# delete_custom_resources() {
#     echo "-------------Deleting custom resources-------------"
#     local wkc_cr="${casePath}"/inventory/"${inventory}"/files/config/samples/cpd_v1beta1_wkc.yaml
#
#     echo "service: ${service}"
#     if [[ -z ${service} ]]; then
#       echo "No service specified, undeploying both WKC and UG custom resources"
#       [[ ! -f ${wkc_cr} ]] && { err_exit "Missing required ${wkc_cr}, exiting deployment."; }
#       $kubernetesCLI delete -n "${namespace}" -f "${wkc_cr}" ${dryRun}
#       [[ ! -f ${ug_cr} ]] && { err_exit "Missing required ${ug_cr}, exiting deployment."; }
#       $kubernetesCLI delete -n "${namespace}" -f "${ug_cr}" ${dryRun}
#     elif [[ "${service}" == "wkc" ]]; then
#       echo "Undeploying WKC custom resource"
#       [[ ! -f ${wkc_cr} ]] && { err_exit "Missing required ${wkc_cr}, exiting deployment."; }
#       $kubernetesCLI delete -n "${namespace}" -f "${wkc_cr}" ${dryRun}
#     elif [[ "${service}" == "ug" ]]; then
#       echo "Undeploying UG custom resource"
#       [[ ! -f ${ug_cr} ]] && { err_exit "Missing required ${ug_cr}, exiting deployment."; }
#       $kubernetesCLI delete -n "${namespace}" -f "${ug_cr}" ${dryRun}
#     fi
# }

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
