# Name

IBM&reg; IBM Cloud Pak for Data IBM Knowledge Catalog.

# Introduction

## Summary

IBM Knowledge Catalog provides a secure enterprise catalog management platform that is supported by a data governance framework.

## Features

* IBM Knowledge Catalog powers intelligent, self-service discovery of data, models, and more, activating them for artificial intelligence, machine learning, and deep learning. Access, curate, categorize, and share data, knowledge assets, and their relationships, wherever they reside. Use Knowledge Catalog in the following ways:
* Curate and shape analytic assets, including structured and unstructured data, machine learning models, and notebooks.
* Discover more relevant assets quicker with intelligent recommendations powered by Watson and by peers across the organization.
* Protect data misuse and confidently share assets previously unavailable to AI application development with the automated, dynamic masking of sensitive data elements.
* Automatically profile and classify structured and unstructured data, helping users understand what is in their data.
* Seamlessly integrate with Watson Studio, allowing data scientists and knowledge workers to quickly drive productive use of their data in a suite of powerful data science, AI, ML, and DL tools to build, train, and deploy models.
* Interactively discover, cleanse, and prepare your data. Understand data quality and distribution through data profile visualizations, built-in charts, and statistics.


# Details

## Prerequisites
See [Details](https://ibmdocs-test.mybluemix.net/docs/en/SSQNUZ_4.5_test?topic=installing-pre-installation-tasks)

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:
| Software | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Cloud Pak for Data | 64 | 16 | 100 | 3 |
| **Total** | **64** | **16**  | **100**  | **3** |


# Installing'
1. Get cloudctl
Download latest cloudctl binary from url below
Release page: https://github.com/IBM/cloud-pak-cli/releases

2. Download WKC development case
Download the latest WKC development case

3. Setup registry mirror (Optional)
The images of WKC are available in registry (cp.icr.io/cp/cpd and icr.io/cpopen).  If cluster cannot access these registries, add registry mirror to re-direct registry to local registry where images are available by create `ImageContentSourcePolicy` like below
```
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - <registry repository and namespace for operand images>
    source: cp.icr.io/cp/cpd
  - mirrors:
    - <registry repository and namespace for operator images>
    source: icr.io/cpopen
  - mirrors:
    - <registry repository and namespace for operand images>
    source: docker.io/ibmcom
  - mirrors:
    - <registry repository and namespace for operand images>
    source: quay.io/opencloudio
```

### Install WKC Operator using OLM [Operator LifeCycle Manager + Cloudctl]   
**1. Install WKC Operator**   
```
export NAMESPACE=<Operator Project>

cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <Operator Project> --action installOperator --inventory wkcOperatorSetup

Note: <Operator Project> = ibm-common-services
```
**2. Install WKC Core Custom Resource**

* NFS
```
#Note: <CP4D Project> = wkc
export NAMESPACE=<CP4D Project>   
oc new-project <CP4D Project>  
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service wkc --storageclass managed-nfs-storage"

```
* OCS | Portworx
```
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service wkc --storagevendor <ocs|Portworx>"

```
**3. Install Information Server (IIS)**
**4. Install UG Custom Resource**
* NFS
```
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service ug --storageclass managed-nfs-storage"
```
* OCS | Portworx
```
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service ug --storagevendor <ocs|Portworx>"
```


### Install WKC Operator using OLM [Operator LifeCycle Manager - Manual]   
**1. Install CatalogSource**
```
cat << EOF | oc apply -f -
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: ibm-cpd-wkc-operator-catalog
  namespace: openshift-marketplace
spec:
  sourceType: grpc
  image: cp.stg.icr.io/cp/ibm-cpd-wkc-operator-catalog:latest
  imagePullPolicy: Always
  displayName: CPD WKC
  publisher: IBM
EOF
```
Check the ibm-cpd-wkc-operator-catalog pod under openshift-marketplace namespace. Wait until they are running. If the pod is stuck with image pull errors, check your global pull secret.

**2. Create Operator Group for WKC**

Check WKC operator group exist by running. **Do not create operator group if Operator Group already exists using the below command**
```
oc get operatorgroup -n <operator project>
```

To create operator group, create file `wkc-og.yaml` with the content below.  Run `oc apply -f wkc-og.yaml -n <operator project>`
Replace the place holder `REPLACE_NAMESPACE` with the project name the operator is to be deployed.
```
apiVersion: operators.coreos.com/v1
kind: OperatorGroup
metadata:
  name: ibm-cpd-wkc-operator-group
  labels:
    app.kubernetes.io/instance: ibm-cpd-wkc-operator-cluster-role
    app.kubernetes.io/managed-by: ibm-cpd-wkc-operator
    app.kubernetes.io/name: ibm-cpd-wkc-operator-cluster-role
spec:
  targetNamespaces:
    - REPLACE_NAMESPACE
```
Check for created wkc operator group `oc get operatorgroup -n <operator project>`
For example as shown below:
```
# oc get operatorgroup -n ibm-common-services
NAME                         AGE
ibm-cpd-wkc-operator-group   64m
```

**3. Install Subscription for WKC**   
```
cat << EOF | oc apply -f -
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  labels:
    app.kubernetes.io/instance:  ibm-cpd-wkc-operator-catalog-subscription
    app.kubernetes.io/managed-by: ibm-cpd-wkc-operator
    app.kubernetes.io/name:  ibm-cpd-wkc-operator-catalog-subscription
  generation: 1
  name: ibm-cpd-wkc-operator-catalog-subscription
spec:
    channel: v7.1
    installPlanApproval: Automatic
    name: ibm-cpd-wkc
    source: ibm-cpd-wkc-operator-catalog
    sourceNamespace: openshift-marketplace
    startingCSV: ibm-cpd-wkc.v2.1.1
EOF
```

Check for created subscription in operator namespace `oc get sub -n <operator project>`
```
wkc                   ibm-cpd-wkc-operator-catalog-subscription             ibm-cpd-wkc                      ibm-cpd-wkc-operator-catalog             v4.1
```
Check for wkc operator pod in <operator project> `oc get pods -n <operator project> | grep ibm-cpd`
Wait till wkc operator pod is up and running. For example as below:
```
ibm-cpd-wkc-operator-b485bd7c6-kpg6l                              1/1     Running     0          3h41m
```


**4. Install WKC Core Custom Resource**   
**For OCS use: storageVendor: "ocs"
  For Portworx use:  storageVendor: "portworx"
```
oc new-project <any-namespace>

cat << EOF | oc apply -f -
apiVersion: wkc.cpd.ibm.com/v1beta1
kind: WKC
metadata:
  name: wkc-cr
spec:
  version: "5.4.6"
  storageClass: managed-nfs-storage
  license:
    accept: true
    license: Standard
```

### Install WKC Operator using CASE (Cloudctl) (Native)
**1. Install WKC Operator**   
```
export NAMESPACE=<Operator Project>

cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <Operator Project> --action installOperatorNative --inventory wkcOperatorSetup

Note: <Operator Project> = ibm-common-services
```
**2. Install WKC Core Custom Resource**  

* NFS
```
#Note: <CP4D Project> = wkc
export NAMESPACE=<CP4D Project>   
oc new-project <CP4D Project>  
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service wkc --storageclass managed-nfs-storage"

```
* OCS | Portworx
```
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service wkc --storagevendor <ocs|Portworx>"

```
**3. Install Information Server (IIS)**
**4. Install UG Custom Resource**   
* NFS
```
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service ug --storageclass managed-nfs-storage"
```
* OCS | Portworx
```
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory wkcOperator --args "--service ug --storagevendor <ocs|Portworx>"
```

## Uninstall WKC
```
cloudctl case launch --case <WKC case tgz file> --tolerance 1 --namespace <cpd project> --action deleteCustomResources --inventory wkcOperator --args "--service wkc"
```
## Uninstall UG
```
cloudctl case launch --case <WKC case tgz file> --tolerance 1 --namespace <cpd project> --action deleteCustomResources --inventory wkcOperator --args "--service ug"
```
## Uninstall WKC and UG
```
cloudctl case launch --case <WKC case tgz file> --tolerance 1 --namespace <cpd project> --action deleteCustomResources --inventory wkcOperator
```
## Uninstall WKC-core Operator
```
export NAMESPACE=<operator-namespace>  
oc new-project ${NAMESPACE}  
cloudctl case launch --case <wkc case tgz file> --tolerance 1 --namespace <operator namespace/project> --action uninstallOperatorNative --inventory wkcOperatorSetup
```



## Configuration
Add you the scale config of WKC by changing the `spec.scaleConfig`, `spec.storageClass` value in WKC cr.

## Storage

IBM Cloud Pak for Data WKC supports dynamic storage provisionging using storage class.  The following storages are supported
- NFS
- Portworx 2.7
- OCS

## Limitations
Only one instance of IBM Cloud Pak for Data IBM Knowledge Catalog. (WKC) operator can be deployed in a cluster.  Multiple instances of WKC operands can be deployed in different namespaces in a cluster.

## Documentation
See [Details](https://ibmdocs-test.mybluemix.net/docs/en/SSQNUZ_4.5_test?topic=governance-watson-knowledge-catalog)

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: RESTRICTED
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

### Airgap Install

1. Setup environment variables

```
export SOURCE_REGISTRY=cp.stg.icr.io
export SOURCE_REGISTRY_PASS=<source registry password>
export SOURCE_REGISTRY_USER=iamapikey
export TARGET_REGISTRY=<target registry repository>
export TARGET_REGISTRY_USER=testuser1
export TARGET_REGISTRY_PASS=abc123ABC

```
2. create directory
```
mkdir offline
```
3. Save case
```
cloudctl case save --case /root/install/ibm-wkc --outputdir /root/test/offline -t 1
```
4. Create credentials for airgap
```
cloudctl case launch --case /root/install/ibm-wkc --inventory wkcOperatorSetup --action configureCredsAirgap --args "--registry $SOURCE_REGISTRY --user $SOURCE_REGISTRY_USER --pass $SOURCE_REGISTRY_PASS" --tolerance 1

cloudctl case launch --case /root/install/ibm-wkc --inventory wkcOperatorSetup --action configureCredsAirgap --args "--registry $TARGET_REGISTRY --user $TARGET_REGISTRY_USER --pass $TARGET_REGISTRY_PASS" --tolerance 1
```
The following two files will be created after running the above 2 commands
```
ls -l ~/.airgap/secrets/
total 8
-rw------- 1 root root 128 May 20 05:48 cp.stg.icr.io.json
-rw------- 1 root root 215 May 20 05:48 <target registry repository>.json

```
5.Update image csv update offline/ibm-wkc-4.0.0-####-images.csv. Replacing "cp.icr.io" with "cp.stg.icr.io" and replacing "icr.io,cpopen" with "cp.stg.icr.io,cp"

6.Load image to target registry
```
yum install skopeo
export USE_SKOPEO=true

cloudctl case launch --case /root/install/ibm-wkc --inventory wkcOperatorSetup --action mirrorImages --args "--registry $TARGET_REGISTRY --inputDir /root/test/offline" -t 1
```
7. setup mirror in airgap cluster
```
cloudctl case launch --case /root/install/ibm-wkc --inventory wkcOperatorSetup --namespace ibm-common-services --action configureClusterAirgap --args "--registry $TARGET_REGISTRY --inputDir /root/test/offline" -t 1
```
ImageContentSourcePolicy "ibm-wkc" is created and pull secret for registr $TARGET_REGISTRY is added to secret "pull-secret" in namespace "openshift-config" after running the above command

For testing Change the source in ImageContentSourcePolicy "ibm-wkc" as follow by running oc edit ImageContentSourcePolicy ibm-wkc
```
spec:
  repositoryDigestMirrors:
  - mirrors:
    - <registry repository and namespace for operand images>
    source: cp.stg.icr.io/cp/cpd
  - mirrors:
    - <registry repository and namespace for operand images>
    source: cp.stg.icr.io/cp
```
Remove the following from .spec.repositoryDigestMirrors from ImageContentSourcePolicy that already setup for wkc install if it exsit.
```
 - mirrors:
    - cp.stg.icr.io/cp/cpd
    source: cp.icr.io/cp/cpd
  - mirrors:
    - cp.stg.icr.io/cp/cpd
    - cp.stg.icr.io/cp
    source: icr.io/cpopen
```
Create ImageContentSourcePolicy will requires all nodes to restart. Wait until all node are ready before continue.

8.Install catalog
```
cloudctl case launch --case /root/install/ibm-wkc --inventory wkcOperatorSetup --namespace ibm-common-services --action installCatalog -t 1
```
The catalogsource "ibm-cpd-wkc-operator-catalog" is created in project "openshift-marketplace"
```
oc get catsrc -n openshift-marketplace | grep wkc
ibm-cpd-wkc-operator-catalog   CPD  WKC   grpc   IBM  18h

```
9.  Install WKC-Core CR

10. Install IIS Airgap method

11. Install UG CR
