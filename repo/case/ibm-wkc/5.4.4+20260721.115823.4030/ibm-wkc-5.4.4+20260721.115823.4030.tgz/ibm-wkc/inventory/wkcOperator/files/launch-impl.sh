# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ccs operator

# ccs operator specific variables
#caseName="ibm-sample-panamax"
caseName="ibm-wkc"
#inventory="panamaxOperatorSetup"
inventory="wkcOperatorSetup"
#caseCatalogName="ibm-sample-panamax-catalog"
caseCatalogName="ibm-cpd-wkc-operator-catalog"
catalogNamespace="openshift-marketplace"
#channelName="v3.0"
channelName="v10.4"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-wkc-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:5ea61c4439a238e7fcd13fd52be0bed9b0dbb73156fd9e8a56d390cce9095212}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
entitledRegistry="icr.io/cpopen"
storageclass=""
storagevendor=""
service=""
license_accept=0
license_type=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageclass)
        storageclass=$val
        ;;
    --storagevendor)
        storagevendor=$val
        ;;
    --service)
        service=$val
        ;;
    --license-accept)
        license_accept=1
        ;;
    --license-type)
        license_type=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
#    ibm-couchdb)
#        echo "couchdbOperatorSetup"
#        return 0
#        ;;
#    ibm-cp-common-services)
#        echo "ibmCommonServiceOperatorSetup"
#        return 0
#        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed "${catsrc_file}" -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed "${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    echo "Inside  launch-impl.sh install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="wkc"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/wkcOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    wkc_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkc.yaml"
    validate_file_exists ${wkc_crd}
    workflow_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_workflow.yaml"
    validate_file_exists ${workflow_crd}
    profiling_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_profiling.yaml"
    validate_file_exists ${profiling_crd}
    glossary_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_glossary.yaml"
    validate_file_exists ${glossary_crd}
    metadataimports_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_metadataimports.yaml"
    validate_file_exists ${metadataimports_crd}
    enrichment_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_enrichment.yaml"
    validate_file_exists ${enrichment_crd}
    wkcgovui_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkcgovui.yaml"
    validate_file_exists ${wkcgovui_crd}
    finley_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_finley.yaml"
    validate_file_exists ${finley_crd}
    policy_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_policy.yaml"
    validate_file_exists ${policy_crd}
    knowledgegraph_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_knowledgegraph.yaml"
    validate_file_exists ${knowledgegraph_crd}
    dataquality_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_dataquality.yaml"
    validate_file_exists ${dataquality_crd}
    semanticsearch_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_semanticsearch.yaml"
    validate_file_exists ${semanticsearch_crd}
    operator_files="${setup_definition_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_service.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required
    # create CRD
    $kubernetesCLI apply ${dryRun} -f ${wkc_crd}
    $kubernetesCLI apply ${dryRun} -f ${workflow_crd}
    $kubernetesCLI apply ${dryRun} -f ${profiling_crd}
    $kubernetesCLI apply ${dryRun} -f ${glossary_crd}
    $kubernetesCLI apply ${dryRun} -f ${metadataimports_crd}
    $kubernetesCLI apply ${dryRun} -f ${enrichment_crd}
    $kubernetesCLI apply ${dryRun} -f ${wkcgovui_crd}
    $kubernetesCLI apply ${dryRun} -f ${finley_crd}
    $kubernetesCLI apply ${dryRun} -f ${policy_crd}
    $kubernetesCLI apply ${dryRun} -f ${knowledgegraph_crd}
    $kubernetesCLI apply ${dryRun} -f ${dataquality_crd}
    $kubernetesCLI apply ${dryRun} -f ${semanticsearch_crd}
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml

    # Append OPERATOR_PREFIX to all resources under rbac
    sed <"${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create clusterrole wkc-proxy-role
    # sed <"${setup_definition_files}/rbac/auth_proxy_role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrole wkc-manager-role
    # sed <"${setup_definition_files}/rbac/role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-manager-role|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrole wkc-metrics-reader
    # sed <"${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml" "s|metrics-reader|${OPERATOR_PREFIX}-metrics-reader|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrolebinding wkc-proxy-rolebinding
    # sed <"${setup_definition_files}/rbac/auth_proxy_role_binding.yaml" "s|proxy-rolebinding|${OPERATOR_PREFIX}-proxy-rolebinding|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrolebinding wkc-manager-rolebinding
    # sed <"${setup_definition_files}/rbac/role_binding.yaml" "s|manager-rolebinding|${OPERATOR_PREFIX}-manager-rolebinding|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create service wkc-controller-manager-metrics-service
    # sed <"${setup_definition_files}/rbac/auth_proxy_service.yaml" "s| system| ${namespace}|g" | sed "s|controller-manager-metrics-service|${OPERATOR_PREFIX}-controller-manager-metrics-service|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # # create rolebinding wkc-leader_election_rolebinding
    # sed <"${setup_definition_files}/rbac/leader_election_role_binding.yaml" "s|leader-election-rolebinding|${OPERATOR_PREFIX}-leader-election-rolebinding|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # # create role wkc-leader-election-role
    # sed <"${setup_definition_files}/rbac/leader_election_role.yaml" "s|leader-election-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    #sed <"${manifest_file}" "s|ibm-sample-panamax-operator-system|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    #local cr="${casePath}"/inventory/"${inventory}"/files/sample_v1beta1_panamax.yaml
    local wkc_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_wkc.yaml
    local workflow_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_workflow.yaml
    local profiling_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_profiling.yaml
    local glossary_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_glossary.yaml
    local metadataimports_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_metadataimports.yaml
    local enrichment_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_enrichment.yaml
    local wkcgovui_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_wkcgovui.yaml
    local finley_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_finley.yaml
    local policy_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_policy.yaml
    local knowledgegraph_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_knowledgegraph.yaml
    local dataquality_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_dataquality.yaml
    local semanticsearch_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_semanticsearch.yaml

    echo "storagevendor: ${storagevendor}, storageclass: ${storageclass}"
    if [[ -z ${storageclass} && -z ${storagevendor} ]]; then
        err_exit "storageclass and storagevendor MUST not both empty"
    fi
    if [[ -z ${storageclass} ]]; then
        storageclass="\"\""
    fi

    echo "license-accept: ${license_accept}, license-type: ${license_type}"
    if [[ ${license_accept} -eq 1 ]]; then
        if [[ -z ${license_type} ]]; then
            err_exit "You must set the license type that you purchased by specifying --args \"--license-type Enterprise|Standard\"."
        fi

        if [[ ${license_type} != "Enterprise" && ${license_type} != "Standard" ]]; then
           err_exit "The license type must be either Enterprise or Standard, e.g., --args \"--license-type Enterprise|Standard\"."
        fi
    else
        err_exit "Please accept the license by specifying --args \"--license-accept\""
    fi

    validate_file_exists "$wkc_cr"
    validate_file_exists "$workflow_cr"
    validate_file_exists "$profiling_cr"
    validate_file_exists "$glossary_cr"
    validate_file_exists "$metadataimports_cr"
    validate_file_exists "$enrichment_cr"
    validate_file_exists "$wkcgovui_cr"
    validate_file_exists "$finley_cr"
    validate_file_exists "$policy_cr"
    validate_file_exists "$knowledgegraph_cr"
    validate_file_exists "$dataquality_cr"
    validate_file_exists "$semanticsearch_cr"

    echo "service: ${service}"
    if [[ -z ${service} ]]; then
       # deploying WKC will deploy all other custom resources
       echo "No service specified, deploying WKC custom resource"
       serv_cr="${wkc_cr}"
    elif [[ "${service}" == "wkc" ]]; then
       echo "Deploying WKC custom resource"
       serv_cr="${wkc_cr}"
    elif [[ "${service}" == "workflow" ]]; then
       echo "Deploying workflow custom resource"
       serv_cr="${workflow_cr}"
    elif [[ "${service}" == "profiling" ]]; then
       echo "Deploying Profiling custom resource"
       serv_cr="${profiling_cr}"
    elif [[ "${service}" == "glossary" ]]; then
       echo "Deploying Glossary custom resource"
       serv_cr="${glossary_cr}"
    elif [[ "${service}" == "metadataimports" ]]; then
       echo "Deploying Metadata Imports custom resource"
       serv_cr="${metadataimports_cr}"
    elif [[ "${service}" == "enrichment" ]]; then
       echo "Deploying Enrichment custom resource"
       serv_cr="${enrichment_cr}"
    elif [[ "${service}" == "wkc-gov-ui" ]]; then
       echo "Deploying wkc-gov-ui custom resource"
       serv_cr="${wkcgovui_cr}"
    elif [[ "${service}" == "finley" ]]; then
       echo "Deploying Finley custom resource"
       serv_cr="${finley_cr}"
    elif [[ "${service}" == "policy" ]]; then
       echo "Deploying Policy custom resource"
       serv_cr="${policy_cr}"
    elif [[ "${service}" == "knowledgegraph" ]]; then
       echo "Deploying Knowledgegraph custom resource"
       serv_cr="${knowledgegraph_cr}"
    elif [[ "${service}" == "dataquality" ]]; then
       echo "Deploying dataquality custom resource"
       serv_cr="${dataquality_cr}"
    elif [[ "${service}" == "semanticsearch" ]]; then
       echo "Deploying semanticsearch custom resource"
       serv_cr="${semanticsearch_cr}"
    fi

    for cr in ${serv_cr} ; do
      if [[ -z $storagevendor ]]; then
          sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s/license: Standard/license: ${license_type}/g" -e "s|^\([ \t]*storageClass:\).*|\1 ${storageclass}|g" -e "s|^\([ \t]*fileStorageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
      else
          if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" && ${storagevendor} != "nfs" && ${storagevendor} != "\"\"" ]]; then
              err_exit "storagevendor value must be empty, \"nfs\", \"ocs\", or \"portworx\""
          fi
          sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s/license: Standard/license: ${license_type}/g" -e "s|^\([ \t]*storageClass:\).*|\1 ${storageclass}|g" -e "s|^\([ \t]*fileStorageClass:\).*|\1 ${storageclass}|g" -e "/^\([ \t]*.*[Ss]torageClass:\).*/a \ \ storageVendor: ${storagevendor}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
      fi
    done
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done
    $kubernetesCLI delete crd wkc.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd workflow.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd profiling.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd glossary.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd metadataimports.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd enrichment.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd wkcgovui.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd finley.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd policy.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd knowledgegraph.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd dataquality.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd semanticsearch.wkc.cpd.ibm.com --ignore-not-found=true ${dryRun}
   # - dependent resources
    $kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    OPERATOR_PREFIX="wkc"

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/wkcOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    wkc_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkc.yaml"
    validate_file_exists ${wkc_crd}
    workflow_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_workflow.yaml"
    validate_file_exists ${workflow_crd}
    profiling_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_profiling.yaml"
    validate_file_exists ${profiling_crd}
    glossary_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_glossary.yaml"
    validate_file_exists ${glossary_crd}
    metadataimports_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_metadataimports.yaml"
    validate_file_exists ${metadataimports_crd}
    enrichment_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_enrichment.yaml"
    validate_file_exists ${enrichment_crd}
    wkcgovui_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_wkcgovui.yaml"
    validate_file_exists ${wkcgovui_crd}
    finley_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_finley.yaml"
    validate_file_exists ${finley_crd}
    policy_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_policy.yaml"
    validate_file_exists ${policy_crd}
    knowledgegraph_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_knowledgegraph.yaml"
    validate_file_exists ${knowledgegraph_crd}
    dataquality_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_dataquality.yaml"
    validate_file_exists ${dataquality_crd}
    semanticsearch_crd="${setup_definition_files}/op-cli/wkc.cpd.ibm.com_semanticsearch.yaml"
    validate_file_exists ${semanticsearch_crd}
    operator_files="${setup_definition_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_service.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required

    # delete role wkc-leader-election-role
    # sed <"${setup_definition_files}/rbac/leader_election_role.yaml" "s|leader-election-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    # # delete rolebinding wkc-leader_election_rolebinding
    # sed <"${setup_definition_files}/rbac/leader_election_role_binding.yaml" "s|leader-election-rolebinding|${OPERATOR_PREFIX}-leader-election-rolebinding|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    # # delete service wkc-controller-manager-metrics-service
    # sed <"${setup_definition_files}/rbac/auth_proxy_service.yaml" "s| system| ${namespace}|g" | sed "s|controller-manager-metrics-service|${OPERATOR_PREFIX}-controller-manager-metrics-service|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    # # delete clusterrolebinding wkc-manager-rolebinding
    # sed <"${setup_definition_files}/rbac/role_binding.yaml" "s|manager-rolebinding|${OPERATOR_PREFIX}-manager-rolebinding|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrolebinding wkc-proxy-rolebinding
    # sed <"${setup_definition_files}/rbac/auth_proxy_role_binding.yaml" "s|proxy-rolebinding|${OPERATOR_PREFIX}-proxy-rolebinding|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrole wkc-metrics-reader
    # sed <"${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml" "s|metrics-reader|${OPERATOR_PREFIX}-metrics-reader|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrole wkc-manager-role
    # sed <"${setup_definition_files}/rbac/role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-manager-role|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrole wkc-proxy-role
    # sed <"${setup_definition_files}/rbac/auth_proxy_role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" deploy ibm-cpd-wkc-operator
    sed <"${setup_definition_files}/op-cli/wkc_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role_binding.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_serviceaccount.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_cluster_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/wkc_operator_role.yaml
    # delete CRD
    $kubernetesCLI delete ${dryRun} -f ${wkc_crd}
    $kubernetesCLI delete ${dryRun} -f ${workflow_crd}
    $kubernetesCLI delete ${dryRun} -f ${profiling_crd}
    $kubernetesCLI delete ${dryRun} -f ${glossary_crd}
    $kubernetesCLI delete ${dryRun} -f ${metadataimports_crd}
    $kubernetesCLI delete ${dryRun} -f ${enrichment_crd}
    $kubernetesCLI delete ${dryRun} -f ${wkcgovui_crd}
    $kubernetesCLI delete ${dryRun} -f ${policy_crd}
    $kubernetesCLI delete ${dryRun} -f ${finley_crd}
    $kubernetesCLI delete ${dryRun} -f ${knowledgegraph_crd}
    $kubernetesCLI delete ${dryRun} -f ${dataquality_crd}
    $kubernetesCLI delete ${dryRun} -f ${semanticsearch_crd}
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    #local cr="${casePath}"/inventory/"${inventory}"/files/sample_v1beta1_panamax.yaml
    #setup_definition_files="${casePath}/inventory/iisOperator/files"
    local wkc_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_wkc.yaml
    local workflow_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_workflow.yaml
    local profiling_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_profiling.yaml
    local glossary_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_glossary.yaml
    local metadataimports_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_metadataimports.yaml
    local enrichment_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_enrichment.yaml
    local wkcgovui_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_wkcgovui.yaml
    local finley_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_finley.yaml
    local policy_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_policy.yaml
    local knowledgegraph_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_knowledgegraph.yaml
    local dataquality_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_dataquality.yaml
    local semanticsearch_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_semanticsearch_cr.yaml
    echo "service: ${service}"
    if [[ -z ${service} ]]; then
      echo "No service specified, undeploying all custom resources"
      [[ ! -f ${wkc_cr} ]] && { err_exit "Missing required ${wkc_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${wkc_cr}" ${dryRun}
      [[ ! -f ${workflow_cr} ]] && { err_exit "Missing required ${workflow_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${workflow_cr}" ${dryRun}
      [[ ! -f ${profiling_cr} ]] && { err_exit "Missing required ${profiling_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${profiling_cr}" ${dryRun}
      [[ ! -f ${glossary_cr} ]] && { err_exit "Missing required ${glossary_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${glossary_cr}" ${dryRun}
      [[ ! -f ${metadataimports_cr} ]] && { err_exit "Missing required ${metadataimports_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${metadataimports_cr}" ${dryRun}
      [[ ! -f ${enrichment_cr} ]] && { err_exit "Missing required ${enrichment_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${enrichment_cr}" ${dryRun}
      [[ ! -f ${wkcgovui_cr} ]] && { err_exit "Missing required ${wkcgovui_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${wkcgovui_cr}" ${dryRun}
      [[ ! -f ${policy_cr} ]] && { err_exit "Missing required ${policy_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${policy_cr}" ${dryRun}
      [[ ! -f ${finley_cr} ]] && { err_exit "Missing required ${finley_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${finley_cr}" ${dryRun}
      [[ ! -f ${knowledgegraph_cr} ]] && { err_exit "Missing required ${knowledgegraph_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${knowledgegraph_cr}" ${dryRun}
      [[ ! -f ${dataquality_cr} ]] && { err_exit "Missing required ${dataquality_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${dataquality_cr}" ${dryRun}
      [[ ! -f ${semanticsearch_cr} ]] && { err_exit "Missing required ${semanticsearch_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${semanticsearch_cr}" ${dryRun}
    elif [[ "${service}" == "wkc" ]]; then
      echo "Undeploying WKC custom resource"
      [[ ! -f ${wkc_cr} ]] && { err_exit "Missing required ${wkc_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${wkc_cr}" ${dryRun}
    elif [[ "${service}" == "workflow" ]]; then
      echo "Undeploying workflow custom resource"
      [[ ! -f ${workflow_cr} ]] && { err_exit "Missing required ${workflow_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${workflow_cr}" ${dryRun}
    elif [[ "${service}" == "profiling" ]]; then
      echo "Undeploying Profiling custom resource"
      [[ ! -f ${profiling_cr} ]] && { err_exit "Missing required ${profiling_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${profiling_cr}" ${dryRun}
    elif [[ "${service}" == "glossary" ]]; then
      echo "Undeploying Glossary custom resource"
      [[ ! -f ${glossary_cr} ]] && { err_exit "Missing required ${glossary_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${glossary_cr}" ${dryRun}
    elif [[ "${service}" == "metadataimports" ]]; then
      echo "Undeploying Metadata Imports custom resource"
      [[ ! -f ${metadataimports_cr} ]] && { err_exit "Missing required ${metadataimports_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${metadataimports_cr}" ${dryRun}
    elif [[ "${service}" == "enrichment" ]]; then
      echo "Undeploying Enrichment custom resource"
      [[ ! -f ${enrichment_cr} ]] && { err_exit "Missing required ${enrichment_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${enrichment_cr}" ${dryRun}
    elif [[ "${service}" == "wkc-gov-ui" ]]; then
      echo "Undeploying wkc-gov-ui custom resource"
      [[ ! -f ${wkcgovui_cr} ]] && { err_exit "Missing required ${wkcgovui_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${wkcgovui_cr}" ${dryRun}
    elif [[ "${service}" == "finley" ]]; then
      echo "Undeploying Finley custom resource"
      [[ ! -f ${finley_cr} ]] && { err_exit "Missing required ${finley_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${finley_cr}" ${dryRun}
    elif [[ "${service}" == "policy" ]]; then
      echo "Undeploying Policy custom resource"
      [[ ! -f ${policy_cr} ]] && { err_exit "Missing required ${policy_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${policy_cr}" ${dryRun}
    elif [[ "${service}" == "knowledgegraph" ]]; then
      echo "Undeploying Knowledgegraph custom resource"
      [[ ! -f ${knowledgegraph_cr} ]] && { err_exit "Missing required ${knowledgegraph_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${knowledgegraph_cr}" ${dryRun}
    elif [[ "${service}" == "dataquality" ]]; then
      echo "Undeploying dataquality custom resource"
      [[ ! -f ${dataquality_cr} ]] && { err_exit "Missing required ${dataquality_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${dataquality_cr}" ${dryRun}
    elif [[ "${service}" == "semanticsearch" ]]; then
      echo "Undeploying semanticsearch custom resource"
      [[ ! -f ${semanticsearch_cr} ]] && { err_exit "Missing required ${semanticsearch_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${semanticsearch_cr}" ${dryRun}
    fi
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
