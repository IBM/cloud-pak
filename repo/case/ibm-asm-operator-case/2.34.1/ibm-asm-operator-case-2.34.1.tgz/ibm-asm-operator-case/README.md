# Name

IBM Netcool Agile Service Manager

# Introduction

## Details

* IBM Netcool Agile Service Manager (ASM) provides operations teams with complete up-to-date visibility and control over dynamic infrastructure and services. IBM Netcool Agile Service Manager lets you query a specific networked resource, and then presents a configurable topology view of it within its ecosystem of relationships and states, both in real time and within a definable time window.

## Features

This case will deploy the ASM core services and observers into your Kubernetes environment.
* Cassandra, Elasticsearch, Kafka and Zookeeper are deployed as StatefulSet objects.
* Layout, Merge, Topology and Search make up the core services of ASM, and are deployed as Deployment objects.
* You choose which further observers to deploy based on your infrastructure.

## Prerequisites

The following prerequisites are required for a successful installation.

- A Red Hat OpenShift Kubernetes Container Platform v4.5 or later. For more information on the cluster, see [OpenShift Container Platform 4.5 Documentation](https://docs.openshift.com/container-platform/4.5/welcome/index.html)
- For the airgap action, oc 4.5.0 client version or higher. See [oc downloads](https://mirror.openshift.com/pub/openshift-v4/clients/oc/).
- Cloudctl v3.4 or higher to manage Container Application Software for Enterprise (CASE) [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli)

## Resources Required

The `smallProduction` deployment configuration will start three instances of Cassandra, Elasticsearch, Kafka
and Zookeeper. To ensure maximum resiliency, you will need a minimum of three worker nodes in your
cluster with this configuration.

See [ Sizing requirements](https://www.ibm.com/support/knowledgecenter/SS9LQB_1.1.10/Reference/r_asm_waiops_sizing.html)

# Installing

This operator can be installed in an on-line or air-gapped cluster through either of following install paths :
1. Operator Life Cycle Manager (default)
2. Kubernetes CLI

[To install on-line using OpenShift Operator Catalog](#to-install-on-line-using-openshift-operator-catalog)

[To install on-line using command-line](#to-install-on-line-using-command-line)

[In Air-Gapped OpenShift Cluster With a Bastion](#in-air-gapped-openshift-cluster-with-a-bastion)

[In Air-Gapped OpenShift Cluster Without a Bastion](#in-air-gapped-openshift-cluster-without-a-bastion)


## Download CASE

Create a directory to save the CASE to a local directory

```
$ mkdir /tmp/cases
```

Run

```
$ cloudctl case save --case ibm-netcool-asm-prod --repo https://raw.githubusercontent.com/IBM/cloud-pak/master/repo/case --outputdir /tmp/cases
```

Above should give output like :

```
Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```

Verify the CASE and images csv has been downloaded under the /tmp/cases directory.

```
$ ls /tmp/cases/
total 436
drwxr-xr-x 2 root root      6 Sep 15 03:44 charts
-rw-r--r-- 1 root root 429652 Sep 15 03:45 ibm-netcool-asm-prod-1.1.0.tgz
-rw-r--r-- 1 root root     32 Sep 15 03:45 ibm-netcool-asm-prod-1.1.0-charts.csv
-rw-r--r-- 1 root root  10071 Sep 15 03:45 ibm-netcool-asm-prod-1.1.0-images.csv
```

- Create a custom namespace to deploy into:

```
oc create namespace ${NAMESPACE}
```

Refer [Preparing Your Cluster](https://www.ibm.com/support/knowledgecenter/SS9LQB_1.1.10/Installing/t_asm_waiops_preparingcluster.html) for steps required before installing.

## To install on-line using OpenShift Operator Catalog

1. Set below according to your environment:

```
export NAMESPACE=prod
export RELEASE_NAME=small-prod-asm
export REGISTRY_SECRET=asm-registry-secret
```

2. Install the catalog :

Export the TARGET_REGISTRY based on your desired image registry. By default, this should be docker.io/ibmcom, even when airgap. The catalog can be optionally installed cluster wide by setting
the namespace to `openshift-marketplace`. Otherwise, the catalog
source will be specific to the `prod` namespace only.

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action install-catalog                        \
    --args "--registry $TARGET_REGISTRY"                    
```

3. Install the operator :

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action install-operator                     
```

4.  Create a service account over which ASM services would run:

    Skip this if aleady created.

```
cat <<EOF | oc apply -f -
apiVersion: v1
kind: ServiceAccount
metadata:
  name: "${RELEASE_NAME}-service-account"
imagePullSecrets:
- name: "${REGISTRY_SECRET}"
EOF
```

5. Edit the ASM custom resource with required values and apply [`Operator Properties`](#Configuration):

```
oc apply -f ibm-netcool-asm-prod/inventory/asmOperator/files/asm.ibm.com_asm_cr.yaml
```

Alternatively, can create a new ASM Custom Resource via Operator Hub (OLM UI) within installed ASM Operator


## To uninstall on-line using OpenShift Operator Catalog

1. Delete the ASM custom resource :

```
oc delete -f ibm-netcool-asm-prod/inventory/asmOperator/files/asm.ibm.com_asm_cr.yaml
```

Alternatively, can delete the ASM Custom Resource via Operator Hub (OLM UI) within installed ASM Operator.

3. Uninstall the operator via OLM

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action uninstall-operator
```

Use `--args "--deleteCRDs"` if CRDs need to be deleted as part of uninstall. This will also delete any parallel instances of ASM in other namespaces.

4. Uninstall the catalog via OLM

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action uninstall-catalog
```


## To install on-line using command-line

1. Set below according to your environment:

```
export NAMESPACE=prod
export RELEASE_NAME=small-prod-asm
export REGISTRY_SECRET=asm-registry-secret
export TARGET_REGISTRY=cp.icr.io/cp/noi
```

2. Install the operator via command line specifying image pull secret as argument if installing from authenticated registry

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action install-operator-native
```

Alternatively, the install script can point another image registry when installing via airgap

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action install-operator-native                \
    --args "--registry $TARGET_REGISTRY"
```

3.  Create a service account with over which ASM services would run:

    Skip if alredy done.
```
cat <<EOF | oc apply -f -
apiVersion: v1
kind: ServiceAccount
metadata:
  name: "${RELEASE_NAME}-service-account"
imagePullSecrets:
- name: "${REGISTRY_SECRET}"
EOF
```

4. Edit the ASM custom resource with correct values and apply [`Operator Properties`](#configuration):

```
oc apply -f ibm-netcool-asm-prod/inventory/asmOperator/files/asm.ibm.com_asm_cr.yaml
```

## To uninstall on-line using command-line

1. Delete the ASM custom resource :

```
oc delete -f ibm-netcool-asm-prod/inventory/asmOperator/files/asm.ibm.com_asm_cr.yaml
```

2. Uninstall the operator via command line

```
cloudctl case launch                                \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action uninstall-operator-native
```
Use `--args "--deleteCRDs"` if CRDs need to be deleted as part of uninstall. This will also delete any parallel instances of ASM in other namespaces.

### In Air-Gapped OpenShift Cluster With a Bastion

#### 1. Prepare Bastion Host

* Logon to the bastion machine

* Verify that the bastion machine has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with OpenShift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the bastion machine

#### 2. Download CASE

See instructions from previous [Downloading CASE](#download-case) section


#### 3. Set the target image registry

A production grade Docker V2 compatible registry such as Quay Enterprise, JFrog Artifactory, or Docker Registry is required to store images. The OpenShift Internal Registry is NOT SUPPORTED.

Set the TARGET_REGISTRY environment variable to the registry server address

```
export TARGET_REGISTRY=[REGISTRY_URL]
```

Set the namespace according to your environment:

```
export NAMESPACE=prod
```

#### 4. Configure Registry Authentication

1. Create authentication secret for the the source image registry

Create registry secret for source image registry (if the registry is public which doesn't require credentials, this step can be skipped)

```
$ cloudctl case launch                                   \
    --case ibm-netcool-asm-prod                         \
    --namespace ${NAMESPACE}                             \
    --inventory asmOperatorSetup                         \
    --action configure-creds-airgap                      \
    --args "--registry cp.icr.io --user ${SOURCE_REGISTRY_USER} --pass ${SOURCE_REGISTRY_PASSWORD}"
```

where ${SOURCE_REGISTRY_USER} is the user for `cp.icr.io` and is usually `cp` or `iamapikey`.

2. Create authentication secret for target image registry

```
$ cloudctl case launch                                   \
    --case ibm-netcool-asm-prod                         \
    --namespace ${NAMESPACE}                             \
    --inventory asmOperatorSetup                         \
    --action configure-creds-airgap                      \
    --args "--registry ${TARGET_REGISTRY} --user `${USERNAME}` --pass ${PASSWORD}"
```

The credentials are now saved to `~/.airgap/secrets/<registry-name>.json`

#### 5. Mirror Images

In this step image from saved CASE (images.csv) are copied to target registry in the airgap environment.

```
$ cloudctl case launch                              \
    --case ibm-netcool-asm-prod                    \
    --namespace ${NAMESPACE}                        \
    --inventory asmOperatorSetup                    \
    --action mirror-images                          \
    --args "--registry ${TARGET_REGISTRY} --inputDir /tmp/cases"
```

#### 6. Configure Cluster for Airgap

* This step does the following

  * creates a global image pull secret for the target registry (skipped if target registry is unauthenticated)
  * creates a imagesourcecontentpolicy

  ```
  $ cloudctl case launch                              \
      --case ibm-netcool-asm-prod                    \
      --namespace ${NAMESPACE}                        \
      --inventory asmOperatorSetup                    \
      --action configure-cluster-airgap               \
      --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
  ```

  * (Not Advised) If you are using an insecure registry, you must add the local registry to the cluster insecureRegistries list.

    ```
    oc patch image.config.openshift.io/cluster --type=merge -p '{"spec":{"registrySources":{"insecureRegistries":["'${TARGET_REGISTRY}'"]}}}'
    ```

* WARNING:

  * Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in $HOME/.airgap/secrets and /tmp/airgap* to support this action

  * Applying imagesourcecontentpolicy causes cluster nodes to recycle.


#### 8. Install Operator

See instructions from [Installing](#installing) section

### In Air-Gapped OpenShift Cluster Without a Bastion

#### 1. Prepare a portable device

Prepare a portable device (such as laptop) that be used to download the case and images can be carried into the air gapped environment

* Verify that the portable device has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with OpenShift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the portable device

#### 2. Download CASE

See instructions from previous [Downloading CASE](#download-case) section

#### 3. Configure Registry Authentication

See instructions from previous [Configure Registry Authentication](#4-configure-registry-authentication) section

#### 4. Mirror Images

See instructions from previous [Mirror Images](#6-mirror-images) section

#### 5. Configure Cluster for Airgap

See instructions from previous [Configure Cluster for Airgap](#7-configure-cluster-for-airgap) section

#### 6. Install the operator

See instructions from previous [Installing](#installing) section

## Configuration

[ASM Operator custom resource properties.](https://www.ibm.com/support/knowledgecenter/SS9LQB_1.1.10/Reference/r_asm_aiops_properties.html)


## Storage

- Refer [Storage for IBM Netcool Agile Service Manager](http://ibm.biz/storage-asm-ocp)


## SecurityContextConstraints Requirements

The chart runs with `restricted` SecurityContextConstraints and does not need to be explicitly applied.

Custom SecurityContextConstraints definition:

```
...
```


## Limitations
* The product can be deployed multiple times in the same namespace under different release names.
* For development case bundles, use the --tolerance 1 switch to ignore security checks.
* Should not be installed in parallel to NOI operator on same cluster. If NOI is required , uninstall standalone ASM operator and install the NOI operator.
* IBM Netcool Agile Service Manager has been tested on OpenShift version 4.5 and above .
* Supported on Cloudctl version v3.4 and above .

## Documentation

Full documentation on deploying the IBM Netcool Agile Service Manager can be found in the [IBM Netcool Agile Service Manager](https://www.ibm.com/support/knowledgecenter/SS9LQB_1.1.10/Installing/t_asm_waiops_installing.html).
