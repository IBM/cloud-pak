# Name

IBM&reg; Automation Foundation assets

# Introduction

## Summary

IBM Automation Foundation assets (previously know as IBM Cloud Pak for Integration Asset Repository) allows a user to store, manage, retrieve and search integration and automation assets within CP4I and IBM Automation.

Users of CP4I and IBM Automation are able to utilise Automation assets to share integration assets across the platform capabilities. Storing assets, e.g. JSON schemas, within this repository allows them to be accessed directly within the user interface of certain Integration capabilities. For example, an OpenAPI specification asset stored in the repository can be directly imported within the IBM API Connect user interface.

The installation of is carried out through the CP4I Navigator or by creating a custom resource in the OpenShift console. See the [IBM Cloud Pak for Integration Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSGT7J) for installation information.

## Features

* Share assets between users of CP4I and IBM Automation
* Load assets directly from integration products
* Store assets from within integration products
* Import assets from git repositories

# Details

## Prerequisites

- Red Hat OpenShift version 4.10 and above

### Resources Required

* An instance of the operator will typically use around 1050m CPU and 256Mi memory
* The resources required for an operand depend on options selected during installation and are presented upfront in the UI and are listed in the documentation linked below


## SecurityContextConstraints Requirements

* Automation assets runs under the default `restricted` SecurityContextConstraints.

### Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups:
- system:authenticated
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Installing

This operator supports being installed cluster wide or in a specific namespace. When installed across all namespaces, the dependencies (IBM Common Service Operator) will also be installed across all namespaces.

See [Installing Automation Assets](https://www.ibm.com/docs/en/cloud-paks/cp-integration/2021.1?topic=runtimes-automation-assets-deployment#installing).

## Configuration

* No additional configuration required

## Limitations

* The Automation Assets capability is available only on the `amd64` architecture.

## Documentation

* [IBM Cloud Pak for Integration Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSGT7J)