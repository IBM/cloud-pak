# Business Teams Service

## Introduction
The Business Teams Service (BTS) is a microservice that allows to administer and manage global teams across business applications.

## Details
A team is a collection of users, groups, and other teams that already exist. Unlike users and groups, teams are not stored in LDAP. BTS provides the team management capability, but does not perform authorization on behalf of the apps and components, which apply their own authorization policies. Teams can be associated with resources in components to control authorization to these resources.

## Prerequisites
BTS require IBM Foundational Services as a prerequisite.

## Resources Required
Minimum scheduling capacity:

| Software  | Memory (GB)  | CPU (cores)                         | Disk (GB) | Nodes |
| --------- | ---------------------------------------            | ----------- | --------- | ----- |
|           |  4Gi on each node        | 1 master node with 4 CPUs  5 GB         |             |           |       |
| **Total** |              | 1 infrastructure node with 4 CPUs   |             |           |       |
|           |              | 1 infrastructure node with 4 CPUs   |             |           |       |

## PodSecurityPolicy Requirements
BTS does not require PodSecurityPolicy

## Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition: none

BTS runs with the 'restricted' SCC.

## Installing
BTS is deployed by components that require the BTS functionality. Customers do not need to perform any steps to deploy BTS.

## Configuration
BTS is configured by the parent component. Customers do not need to configure BTS.

## Limitations
BTS is only supported on amd64, ppc64le and s390x architectures.
