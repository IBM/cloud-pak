# Name

IBM&reg; ibm-cpd-edb

# Introduction

This case bundle installs the operator that Cloud Pak for Data uses to deploy Postgresql Standard and Postgresql Enterprise clusters. The case bundle also installs the Cloud Native PostgreSQL operator, which is also installable as a separate case bundle (ibm-cloud-native-postgresql).

## Details

This bundle installs ibm-cpd-edb-operator, a container that is used to create PostgreSQL clusters in Cloud Pak for Data.

### Configuration

No special configuration is necessary

## Installing the Chart

Install the catalog source for this operator by running the "installCatalog" action in the "ibmCPDEDBSetup" inventory:

```
oc ibm-pak launch               \
    --case ./ibm-cpd-edb           \
    --namespace openshift-marketplace \
    --inventory ibmCPDEDBSetup     \
    --action installCatalog        \
    --args "--recursive --inputDir ."
```

Then install the operator by running the "install" action:

```
oc ibm-pak launch               \
    --case ./ibm-cpd-edb           \
    --namespace <target namespace> \
    --inventory ibmCPDEDBSetup     \
    --action installOperator       \
    --args "--recursive --inputDir ."
```

Use "openshift-operators" as your target namespace to install cluster wide. Otherwise, provide the name of the namespace in which to create the operator.

# Limitations

N/A

## Prerequisites

In order to use the IBM EDB operator in Cloud Pak for Data, you will first need to install the Cloud Pak for Data platform.

### Resources Required

Minimum memory - 2 GB
Minimum CPU - 1 vCPU
Minimum storage - 100 GB

# PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:

```

```

This release is only for Openshift, and uses SecurityContextConstraints

# SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```

```

No custom SCC is used. This case bundle uses the "restricted" default SCC:

```
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: []
apiVersion: v1
defaultAddCapabilities: []
fsGroup:
  type: MustRunAs
groups:
- system:authenticated
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
  creationTimestamp: null
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SYS_CHROOT
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

