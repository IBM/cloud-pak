# IBM&reg; App Connect operator setup

This inventory item provides the files needed to install the App Connect operator into an offline cluster,
 using Operator Lifecycle Manager (OLM).  See the top-level README for this CASE for instructions on how to do this.
