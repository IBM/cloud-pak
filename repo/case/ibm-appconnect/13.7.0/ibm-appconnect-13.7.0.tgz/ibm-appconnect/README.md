# Name

IBM&reg; App Connect

# Introduction

## Summary

IBM&reg; App Connect is a market-leading lightweight enterprise integration engine that offers a fast, simple way for systems and applications to communicate with each other. As a result, it can help you achieve business value, reduce IT complexity, and save money. IBM App Connect supports a range of integration choices, skills, and interfaces to optimize the value of existing technology investments.

The IBM App Connect Operator for Red Hat OpenShift Container Platform provides an easy way to manage the lifecycle of IBM App Connect deployments.

IBM App Connect is part of [IBM Integration](https://www.ibm.com/products/integration).

# Details

* Integration Runtime - IBM App Connect Operator provides the ability to create always-on and serverless App Connect integration runtimes. For information about the installation parameters, see https://ibm.biz/aceintrtmrop-sc3.
* Dashboard - IBM App Connect Operator provides the ability to create App Connect dashboards for administering integration runtimes. For information about the installation parameters, see https://ibm.biz/acedashbdop-sc3.
* Designer Authoring - IBM App Connect Operator provides the ability to create an App Connect Designer authoring environment for developing and testing integration flows. For information about the installation parameters, see https://ibm.biz/acedesignerop-sc3.
* Configuration - IBM App Connect Operator provides the ability to create configurations for use with ntegration runtimes. For information about the installation parameters, see https://ibm.biz/aceconfig-sc3.
* Switch Server - IBM App Connect Operator provides the ability to create App Connect switches to enable hybrid integration. For information about the installation parameters, see https://ibm.biz/aceswitchsrvop-sc3.
* Trace - IBM App Connect Operator provides the ability to collect user or service trace for integration runtimes. For information about the installation parameters, see https://ibm.biz/acetraceop-sc3.

## Resources Required

* IBM App Connect Operator requires a typical cluster configuration of 400m CPU & 512Mi memory. The minimum cluster configuration is 100m CPU 128Mi Memory.
* Please refer to the operand readmes above to understand the resources required
* To use the managed Keycloak solution for identity and access management (IAM) you need to install the IBM Integration Operator.

# Installing

This operator supports being installed cluster wide or in a specific namespace.

See [Installing the IBM App Connect Operator on Openshift](https://ibm.biz/aceopinstall-sc3).

## Configuration

See the operand readme topics in the **Details** section.

## Storage

The installation of the operator requires no storage. See the operand readme topics in the **Details** section to understand the requirements for each operand.

## Scaling

See the operand readme topics in the **Details** section to understand how to scale each resource appropriately.

## Documentation

[IBM App Connect documentation](https://ibm.biz/ACEv13ContainerDocs-sc3)
