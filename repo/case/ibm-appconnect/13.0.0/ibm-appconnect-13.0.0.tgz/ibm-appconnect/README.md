# Name

IBM&reg; App Connect

# Introduction

## Summary

IBM&reg; App Connect is a market-leading lightweight enterprise integration engine that offers a fast, simple way for systems and applications to communicate with each other. As a result, it can help you achieve business value, reduce IT complexity, and save money. IBM App Connect supports a range of integration choices, skills, and interfaces to optimize the value of existing technology investments.

The IBM App Connect Operator for Red Hat OpenShift Container Platform provides an easy way to manage the lifecycle of IBM App Connect deployments.

IBM App Connect is part of [IBM Cloud Pak for Integration](https://www.ibm.com/cloud/cloud-pak-for-integration).

## Features

* Creation and management of IBM App Connect operands
* Integration with Cloud Pak for Integration Operations Dashboard
* Single sign-on (SSO) using the IBM Common Services IAM

# Details


* Dashboard - IBM App Connect Operator provides the ability to create App Connect dashboards for administering integration servers. For information about the installation parameters, see https://ibm.biz/acedashbdop-sc3.
* Designer Authoring - IBM App Connect Operator provides the ability to create an App Connect Designer authoring environment for developing and testing integration flows. For information about the installation parameters, see https://ibm.biz/acedesignerop-sc3.
* Configurator - IBM App Connect Operator provides the ability to create configurations for use with integration servers. For information about the installation parameters, see https://ibm.biz/aceconfig-sc3.
* Switch Server - IBM App Connect Operator provides the ability to create App Connect switches to enable hybrid integration. For information about the installation parameters, see https://ibm.biz/aceswitchsrvop-sc3.
* Trace - IBM App Connect Operator provides the ability to collect user or service trace for integration servers. For information about the installation parameters, see https://ibm.biz/acetraceop-sc3.

## Prerequisites

Installing the operator

* v1.0 channel: Red Hat OpenShift version 4.4.4 or later, with 4.4.13 or later preferred.
* v1.2 channel: Red Hat Openshift version 4.5 or later
* v1.3 channel: Red Hat Openshift version 4.6 or later.
* cd channel: Red Hat Openshift version 4.6 or later.
* A user with the cluster administrator role.

See also the operand readme links in the **Details** section for information about specific prerequisites

### Resources Required

* IBM App Connect Operator requires a typical cluster configuration of 200m CPU and 256Mi memory. The minimum cluster configuration is 100m CPU and 128Mi memory.
* See the operand readme topics in the **Details** section to understand the resources required.
* The IBM Common Service Operator and its dependencies are installed automatically when you install the IBM App Connect Operator. In addition, when the operand starts, it will install a number of Common Services operands for Metrics and Licensing. For more information, see [Hardware requirements and recommendations for common services](https://www.ibm.com/support/knowledgecenter/SSHKN6/installer/3.x.x/hardware_sizing_reqs.html) and [Dependencies of the IBM Cloud Platform Common Services](https://www.ibm.com/support/knowledgecenter/SSHKN6/installer/3.x.x/disable_and_enable_services.html). (You can disable the common services by using a CR property, as detailed in the operand readme topics.)
# Installing

This operator supports being installed cluster wide or in a specific namespace. When installed across all namespaces, the dependencies (IBM Common Service Operator) will also be installed across all namespaces.

See [Installing the IBM App Connect Operator on Openshift](https://ibm.biz/aceopinstall-sc3).

## Configuration

See the operand readme topics in the **Details** section.

## Storage

The installation of the operator requires no storage. See the operand readme topics in the **Details** section to understand the requirements for each operand.

## Scaling

See the operand readme topics in the **Details** section to understand how to scale each resource appropriately.

## SecurityContextConstraints Requirements

* IBM App Connect runs under the default `restricted` SecurityContextConstraints.

## Custom SecurityContextConstraints definition:

```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: ibm-ace-restricted
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: false
allowPrivilegedContainer: false
defaultAllowPrivilegeEscalation: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Limitations 

* The App Connect Operator supports only the `amd64` and `s390x` architectures.
* The App Connect Operator is supported on OpenShift Container Platform V4.6
* The Designer Authoring capability is available only on the `amd64` architecture.
* Editing the storage settings of a Designer Authoring instance after initial creation is not supported.
* The following alpha and beta APIs and features are used by the IBM App Connect Operator:
  * `apiextensions.k8s.io/v1beta1` for Operator installation
  * `operators.coreos.com/v1alpha1` for Operator installation
  * `operator.ibm.com/v1alpha1` for installation of additional IBM common operators
  * `service.beta.openshift.io` annotations on Service, to provide a certificate for the webhook

## Documentation

[IBM App Connect documentation](https://ibm.biz/ACEv13ContainerDocs-sc3)
