# Name

IBM&reg; (IBM Connect Direct for Unix v6.4.0)

# Introduction
  
IBM® Connect:Direct® for UNIX links technologies and moves all types of information between networked systems and computers. It manages high-performance transfers by providing such features as automation, reliability, efficient use of resources, application integration, and ease of use. Connect:Direct (C:D) for UNIX offers choices in communications protocols, hardware platforms, and operating systems. It provides the flexibility to move information among mainframe systems, midrange systems, desktop systems, LAN-based workstations and cloud based storage providers (Amazon S3 Object Store for current release). 

To find out more, see the Knowledge Center for [IBM Connect:Direct](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=overview-what-is-connectdirect).

# Details

This CASE is only meant for deployment on OpenShift cluster in Airgap environment. It contains one inventory items:

ibmConnectDirect - required setup for installing IBM Connect Direct for Unix v6.4.0 helm chart

# Prerequisites

## CASE Bundle (Prereq #1)

Please refer to [Offline deployment - For OpenShift](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=container-installing#concept_pjj_bxm_lkb) section in the online Knowledge Center documentation. 
 
## Storage (Prereq #2) 

Please refer to [Creating storage for Data Persistence](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=tasks-creating-storage-data-persistence) section in the online Knowledge Center documentation.

## Secret (Prereq #3)

Please refer to [Creating secret](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=tasks-creating-secret) section in the online Knowledge Center documentation.

## Tools (Prereq #4)

To install chart from the command prompt, tools needed are:

- Refer [Software Requirements](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=software-planning#concept_ylx_4wm_lkb__title__3) section in the online Knowledge Center documentation.
- The environment should be configured to connect to the target cluster
- IBM Pak Plugin for oc from [here](https://www.ibm.com/links?url=https%3A%2F%2Fgithub.com%2FIBM%2Fibm-pak%23overview)

## Pod Security Standard and Security Context Contraints Requirements

Please refer to [PSS and SCC](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=software-installing#concept_t5n_rvx_lkb__title__1) section in the online Knowledge Center documentation.

# Resources Required

This chart uses the following resources by default:

* 100Mi of persistent volume
* 1 GB Disk space
* 500m CPU
* 2000Mi Memory

Please refer [Requirements](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=software-planning#concept_ylx_4wm_lkb__section_kt3_n1m_gxb__title__1) section in the online Knowledge Center documentation.

# Installing the case

## Install Prequisites

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Setup](./inventory/ibmConnectDirect/README.md)

## Install CASE inventory items

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmConnectDirect/README.md)

## Uninstalling the CASE

See the following readme files for details of removing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmConnectDirect/README.md)

## Configuration

- [Chart Readme](./inventory/ibmConnectDirect/README.md)

# Storage

IBM connect Direct for Unix Helm chart supports both dynamic and pre-created persistent storage. 

* Either use storage class for dynamic provisioning or pre-create Persistent Volume
* To retain the data stored on Persistent Volume, the storage class should have reclaim policy as `Retain`
* The default access mode is set to `ReadWriteMany`

# Limitations

Please refer to [Limitations](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=installing-connectdirect-unix-using-sterling-connectdirect-unix-container#concept_rd1_m5m_lkb__title__1)

# Documentation

[IBM Connect Direct for Unix](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=sterling-connectdirect-unix)
