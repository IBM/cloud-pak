# Event Processing

## Introduction

Event Processing is a scalable, low-code, event stream processing platform that helps you transform and act on data in real time.

## Links to External Documentation

For more information about installing Event Processing, see the installation instructions in the [documentation](https://ibm.biz/ep-documentation).
