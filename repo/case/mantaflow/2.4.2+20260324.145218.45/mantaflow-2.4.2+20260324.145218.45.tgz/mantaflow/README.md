# Name

MANTA Automated Data Lineage for IBM Cloud Pak for Data

# Introduction
MANTA can bring in the lineage information IBM Cloud Pak for Data for governance as well as Data Ops.

## Details

* MANTA is a world-class data lineage platform that automatically scans your data environment to build a powerful map of all data flows and deliver it through a native UI and other channels to both technical and non-technical users. With MANTA, everyone gets full visibility and control of their data pipeline.

* Find more details at: https://getmanta.com

## Features

* MANTA brings intelligence to metadata management by providing an automated solution that helps you drive productivity, gain trust in your data, and accelerate digital transformation. Metadata—data about your data—holds necessary information that helps you unlock valuable insights. Insights that will allow you to fully understand your data and get rid of anecdote-driven decisions and processes once and for all.

 - Automate Data Lineage Collection
 - Scan Even the Most Siloed Environment
 - Build Custom Metadata Ingestion Processes
 - Enhance Data Governance in Cloud Pak for Data
 - Achieve Data Pipeline Observability
 - Find and fix Data Incidents 


## Prerequisites
IBM Watson Knowledge Catalog is a prerequisite for deploying MANTA Automated Data Lineage on Cloud Pak for Data.

IBM Cloud Pak for Data Watson Knowledge Catalog requires the following
- Bedrock version 3.7 or later
- Zen version 4.0.0 or later
- cloudctl binary
- db2U
- IBM Cloud Pak for Data Common Core Services.

### PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
This product runs with the 'restricted' SCC

### SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
This product runs with the 'restricted' SCC

### Prereq scripts - How to locate

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| MANTA-adl | 4 GB        | 8 vCPU      | 10 G      |   3   |
| --------- | ----------- | ----------- | --------- | ----- |
| **Total** | 4 GB        | 8 vCPU      | 10 G      |   3   |

# Installing

* Use the `cloudctl` command to download and install the CASE Bundle for MANTA. For more details, see the Watson Knowledge Catalog Information center here: (TODO: link to WKC docs)

Download latest cloudctl binary from url below
Release page: https://github.com/IBM/cloud-pak-cli/releases


## Configuration

* None

## Storage

* The following storage services are supported
 - NFS 
 - Portworx
 - OCS

## Limitations

* Refer to the known issues section within Watson Knowledge Catalog Information center. https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=issues-watson-knowledge-catalog

## Documentation

* Refer to the Watson Knowledge Catalog Information center. https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=services-watson-knowledge-catalog

### Link to External Documentation
https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=services-watson-knowledge-catalog
