# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ccs operator

# ccs operator specific variables
#caseName="ibm-sample-panamax"
caseName="mantaflow"
#inventory="panamaxOperatorSetup"
inventory="mantaflowOperatorSetup"
#caseCatalogName="ibm-sample-panamax-catalog"
caseCatalogName="manta-adl-operator-catalog"
catalogNamespace="openshift-marketplace"
#channelName="v3.0"
channelName="4.5.0"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-manta-adl-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:4bca4d2d0603caa4822566291b65360aa129f968c63bbde0c334eb82ec4234fc}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-cp.icr.io/cpd}"
entitledRegistry="cp.icr.io/cpd"
storageclass=""
storagevendor=""
service=""
license_accept=0
license_type=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageclass)
        storageclass=$val
        ;;
    --storagevendor)
        storagevendor=$val
        ;;
    --service)
        service=$val
        ;;
    --license-accept)
        license_accept=1
        ;;
    --license-type)
        license_type=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
#    ibm-couchdb)
#        echo "couchdbOperatorSetup"
#        return 0
#        ;;
#    ibm-cp-common-services)
#        echo "ibmCommonServiceOperatorSetup"
#        return 0
#        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed "${catsrc_file}" -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed "${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    echo "Inside  launch-impl.sh install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="mantaflow"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/mantaflowOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    manta_flow_crd="${setup_definition_files}/config/samples/manta_v1beta1_mantaflow.yaml"
    validate_file_exists ${manta_flow_crd}
    operator_files="${setup_definition_files}/op-olm/config/manager/manager.yaml"
    validate_file_exists ${operator_files}
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_service.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/leader_election_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaauth_editor_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaauth_viewer_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaflow_editor_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaflow_viewer_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_client_clusterrole.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_service.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/leader_election_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/service_account.yaml"


    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required
    # create CDR
    # $kubernetesCLI apply ${dryRun} -f ${manta_auth_crd}
    $kubernetesCLI apply ${dryRun} -f ${manta_flow_crd}
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/auth_proxy_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/leader_election_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaauth_editor_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaauth_viewer_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaflow_editor_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/rbac/mantaflow_viewer_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/auth_proxy_client_clusterrole.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/rbac/service_account.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/rbac/auth_proxy_role_binding.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/role_binding.yaml


    # Append OPERATOR_PREFIX to all resources under rbac
    sed <"${setup_definition_files}/op-olm/config/role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create clusterrole wkc-proxy-role
    # sed <"${setup_definition_files}/rbac/auth_proxy_role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrole wkc-manager-role
    # sed <"${setup_definition_files}/rbac/role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-manager-role|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrole wkc-metrics-reader
    # sed <"${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml" "s|metrics-reader|${OPERATOR_PREFIX}-metrics-reader|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrolebinding wkc-proxy-rolebinding
    # sed <"${setup_definition_files}/rbac/auth_proxy_role_binding.yaml" "s|proxy-rolebinding|${OPERATOR_PREFIX}-proxy-rolebinding|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create clusterrolebinding wkc-manager-rolebinding
    # sed <"${setup_definition_files}/rbac/role_binding.yaml" "s|manager-rolebinding|${OPERATOR_PREFIX}-manager-rolebinding|g" | $kubernetesCLI apply ${dryRun} -f -
    # # create service wkc-controller-manager-metrics-service
    # sed <"${setup_definition_files}/rbac/auth_proxy_service.yaml" "s| system| ${namespace}|g" | sed "s|controller-manager-metrics-service|${OPERATOR_PREFIX}-controller-manager-metrics-service|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # # create rolebinding wkc-leader_election_rolebinding
    # sed <"${setup_definition_files}/rbac/leader_election_role_binding.yaml" "s|leader-election-rolebinding|${OPERATOR_PREFIX}-leader-election-rolebinding|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # # create role wkc-leader-election-role
    # sed <"${setup_definition_files}/rbac/leader_election_role.yaml" "s|leader-election-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    #sed <"${manifest_file}" "s|ibm-sample-panamax-operator-system|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local manta_flow_cr="${casePath}"/inventory/"${inventory}"/files/config/samples/manta_v1beta1_mantaflow.yaml

    echo "storagevendor: ${storagevendor}, storageclass: ${storageclass}"
    if [[ -z ${storageclass} && -z ${storagevendor} ]]; then
        err_exit "storageclass and storagevendor MUST not both empty"
    fi
    if [[ -z ${storageclass} ]]; then
        storageclass="\"\""
    fi

    echo "license-accept: ${license_accept}, license-type: ${license_type}"
    if [[ ${license_accept} -eq 1 ]]; then
        if [[ -z ${license_type} ]]; then
            err_exit "You must set the license type that you purchased by specifying --args \"--license-type Enterprise|Standard\"."
        fi

        if [[ ${license_type} != "Enterprise" && ${license_type} != "Standard" ]]; then
           err_exit "The license type must be either Enterprise or Standard, e.g., --args \"--license-type Enterprise|Standard\"."
        fi
    else
        err_exit "Please accept the license by specifying --args \"--license-accept\""
    fi

    #validate_file_exists "$manta_auth_cr"
    validate_file_exists "$manta_flow_cr"

    echo "service: ${service}"
    if [[ -z ${service} ]]; then
       echo "No service specified, deploying both Manta Auth and Manta Flow custom resources"
       serv_cr="${manta_auth_cr} ${manta_flow_cr}"
    elif [[ "${service}" == "manta-auth" ]]; then
       echo "Deploying Manta Auth custom resource"
       serv_cr="${manta_auth_cr}"
    elif [[ "${service}" == "manta-flow" ]]; then
       echo "Deploying Manta Flow custom resource"
       serv_cr="${manta_flow_cr}"
    fi

    for cr in ${serv_cr} ; do
      if [[ -z $storagevendor ]]; then
          sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s/license: Standard/license: ${license_type}/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
      else
          if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" && ${storagevendor} != "nfs" && ${storagevendor} != "\"\"" ]]; then
              err_exit "storagevendor value must be empty, \"nfs\", \"ocs\", or \"portworx\""
          fi
          sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s/license: Standard/license: ${license_type}/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" -e "/^\([ \t].*storageClass:\).*/a \ \ storageVendor: ${storagevendor}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
      fi
    done
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-olm/config/*_crd.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done
    $kubernetesCLI delete crd manta.getmanta.com_mantaauths --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete crd manta.getmanta.com_mantaflows --ignore-not-found=true ${dryRun}
    # - dependent resources
    $kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    OPERATOR_PREFIX="mantaflow"

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/mantaflowOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    manta_flow_crd="${setup_definition_files}/op-olm/config/crd/bases/manta_v1beta1_mantaflow.yaml"
    validate_file_exists ${manta_flow_crd}
    operator_files="${setup_definition_files}/op-olm/config/manager/manager.yaml"
    validate_file_exists ${operator_files}
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/leader_election_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/role_binding.yaml"
    # validate_file_exists "${setup_definition_files}/rbac/auth_proxy_service.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/leader_election_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaauth_editor_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaauth_viewer_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaflow_editor_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/mantaflow_viewer_role.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_client_clusterrole.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/auth_proxy_service.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/leader_election_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-olm/config/rbac/service_account.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required

    # delete role wkc-leader-election-role
    # sed <"${setup_definition_files}/rbac/leader_election_role.yaml" "s|leader-election-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    # # delete rolebinding wkc-leader_election_rolebinding
    # sed <"${setup_definition_files}/rbac/leader_election_role_binding.yaml" "s|leader-election-rolebinding|${OPERATOR_PREFIX}-leader-election-rolebinding|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    # # delete service wkc-controller-manager-metrics-service
    # sed <"${setup_definition_files}/rbac/auth_proxy_service.yaml" "s| system| ${namespace}|g" | sed "s|controller-manager-metrics-service|${OPERATOR_PREFIX}-controller-manager-metrics-service|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    # # delete clusterrolebinding wkc-manager-rolebinding
    # sed <"${setup_definition_files}/rbac/role_binding.yaml" "s|manager-rolebinding|${OPERATOR_PREFIX}-manager-rolebinding|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrolebinding wkc-proxy-rolebinding
    # sed <"${setup_definition_files}/rbac/auth_proxy_role_binding.yaml" "s|proxy-rolebinding|${OPERATOR_PREFIX}-proxy-rolebinding|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrole wkc-metrics-reader
    # sed <"${setup_definition_files}/rbac/auth_proxy_client_clusterrole.yaml" "s|metrics-reader|${OPERATOR_PREFIX}-metrics-reader|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrole wkc-manager-role
    # sed <"${setup_definition_files}/rbac/role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-manager-role|g" | $kubernetesCLI delete ${dryRun} -f -
    # # delete clusterrole wkc-proxy-role
    # sed <"${setup_definition_files}/rbac/auth_proxy_role.yaml" "s|proxy-role|${OPERATOR_PREFIX}-leader-election-role|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" deploy manta-adl-operator
    sed <"${setup_definition_files}/op-olm/configrole_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -f -
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/role_binding.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/auth_proxy_role_binding.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/service_account.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/auth_proxy_client_clusterrole.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/auth_proxy_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/leader_election_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaauth_editor_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaauth_viewer_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaflow_editor_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/mantaflow_viewer_role.yaml
    $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-olm/config/rbac/role.yaml

    # delete CDR
    #$kubernetesCLI delete ${dryRun} -f ${manta_auth_crd}
    $kubernetesCLI delete ${dryRun} -f ${manta_flow_crd}

}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    #local cr="${casePath}"/inventory/"${inventory}"/files/sample_v1beta1_panamax.yaml
    #setup_definition_files="${casePath}/inventory/iisOperator/files"
    local manta_flow_cr="${casePath}"/inventory/"${inventory}"/files/config/samples/manta_v1beta1_mantaflow.yaml

    echo "service: ${service}"
    if [[ -z ${service} ]]; then
      echo "No service specified, undeploying both Manta Auth and Manta Flow custom resources"
      [[ ! -f ${manta_auth_cr} ]] && { err_exit "Missing required ${manta_auth_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${manta_auth_cr}" ${dryRun}
      [[ ! -f ${manta_flow_cr} ]] && { err_exit "Missing required ${manta_flow_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${manta_flow_cr}" ${dryRun}
    elif [[ "${service}" == "manta-auth" ]]; then
      echo "Undeploying Manta Auth custom resource"
      [[ ! -f ${manta_auth_cr} ]] && { err_exit "Missing required ${manta_auth_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${manta_auth_cr}" ${dryRun}
    elif [[ "${service}" == "manta-flow" ]]; then
      echo "Undeploying Manta Flow custom resource"
      [[ ! -f ${manta_flow_cr} ]] && { err_exit "Missing required ${manta_flow_cr}, exiting deployment."; }
      $kubernetesCLI delete --ignore-not-found=true -n "${namespace}" -f "${manta_flow_cr}" ${dryRun}
    fi
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
