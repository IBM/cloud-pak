# Name

IBM&reg; (ibm-redis-cp)

# Introduction
This case bundle installs the operator IBM Redis CP . IBM Redis CP is an internal product used by CloudPaks in general. IBM Redis CP operator is primarily used for CloudPak for Data products and follows CP4D release cycle. however we enhance the product with requirements from other cloudpaks as well and provide support.  
## Details

IBM REDIS CP operator is an ansible based operator for deploying and maintaining redis-cluster for CloudPaks


## Features

* It provisions a Redis Sentinel implementation
* Supported redis operand versions: 6.0.27
* Always-on TLS
* Support Single node installation
* Architectures: x86_64,s390x,ppc64le
* Different scalecinfig as small,medium and large for resource optimization
* Supported persistence using filestorage and blockstirage types
* Non-persistent Installation is supported
* Support OCP EUS version 4.12.x
* Shutdown and restart

# Details

## Prerequisites

### Resources Required

*Minimum memory - 2 GB Minimum CPU - 2 vCPU Minimum storage - 100 GB
3 node ocp cluster


# Installing (Guidance)

* catalogsource, which makes the redis package available in embedded openshift catalog Sample catalog as below Apply catalogsource to get IBM Redis CP operator in OperatorHub


```bash
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: ibm-redis-cp-operator-catalog
  namespace: openshift-marketplace
spec:
  displayName: ibm-redis-cp-operator-catalog
  publisher: IBM
  sourceType: grpc
  image: icr.io/cpopen/ibm-redis-cp-operator-catalog@sha256:1b04eebaf1a00fa6b536aed686c301900eda83145f7f50966f6d00d5402408b2
  updateStrategy:
    registryPoll:
      interval: 45m
```
Use olm to create a subscription or install operator from the operator hub

verify the operator deployment by checking the operator pod
```bash
 $ oc get po
NAME                                     READY   STATUS    RESTARTS   AGE
ibm-redis-cp-operator-6d88f7bfb8-sdrvh   1/1     Running   0          21h

```
Sample CR to create a redis deployment wit persistence enabled mode and storage class "nfs-client"
```bash
apiVersion: redis.ibm.com/v1
kind: Rediscp
metadata:
  name: ibm-redis-cp-example-cr
spec:
  version: "1.0.0"
  scale_config: "medium"
  size: 3
  block_storage_class: "nfs-client"
  file_storage_class: "nfs-client"
  shutdown: false
  password: "xxhsjshdjsk"
  license:
    accept: true
```
Note:

To create non persisent redis cluster, comment out block_storage_class and file_storage_class from CR
To shutdown redis cluster, edot rediscp CR and set shutdown value as false in CR. To restart the redis cluster edit rediscp CR and set the value back to false
To set a custom password use the password field. if the filed is not present a system generated password will be used to form redis cluster
# Installing Redis (Example)

This operator can be installed in an on-line or air-gapped cluster through either of following install paths :

1. Operator Life Cycle Manager (default)
2. Kubernetes CLI

## To install on-line using Openshift Operator Catalog

1. (Optional) Create a image pull secret and service account if installing operator from authenticated registry.

```bash
oc create secret docker-registry 'cp.icr.io' --docker-server='cp.icr.io' --docker-username='cp' --docker-password='<token>' --docker-email='<user>' --namespace='<target namespace>'
```

2. Install the operator via OLM

```bash

    oc ibm-pak launch \
    ibm-redis-cp \
    --version 1.3.2 \
    --action install-catalog \
    --inventory ibmRedisCPOperator \
    --namespace my-namespace \
    --args "--registry myregistry.com --recursive --inputDir ~/.ibm-pak/data/cases/ibm-redis-cp/1.3.2"

   oc ibm-pak launch \
   ibm-redis-cp \
   --version 1.3.2 \
   --action install-operator \
   --inventory ibmRedisCPOperator \
    --namespace my-namespace
```
### In Air-Gapped OpenShift Cluster With a Bastion

#### 1. Prepare Bastion Host

* Logon to the bastion machine

* Verify that the bastion machine has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools

All the following steps should be run from the bastion machine

#### 2. Download CASE

Create a directory to save the CASE to a local directory

```bash
mkdir /tmp/cases
```

Run

```bash
$ cloudctl case save --case case/ibm-redis-cp --outputdir /tmp/cases
Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```


#### 3. Configure Registry Auth

1. Create auth secret for the the source image registry

Create registry secret for source image registry (if the registry is public which doesn't require credentials, this step can be skipped)

```bash
$ cloudctl case launch  \
    --case case/ibm-redis-cp \
    --namespace <target namespace> \
    --inventory ibmRedisCPOperator \
    --action configure-creds-airgap \
    --args "--registry cp.icr.io --user iamapikey --pass xyz"
```

2. Create auth secret for target image registry

```bash
$ cloudctl case launch  \
    --case case/ibm-redis-cp       \
    --namespace <target namespace>       \
    --inventory ibmRedisCPOperator  \
    --action configure-creds-airgap      \
    --args "--registry $TARGET_REGISTRY --user abc --pass xyz"
```

The credentials are now saved to `~/.airgap/secrets/<registry-name>.json`

#### 4. Mirror Images

In this step image from saved CASE (images.csv) are copied to target registry in the airgap environment

```bash
$ cloudctl case launch  \
    --case stable/ibm-redis-cp-case-bundle/case/ibm-redis-cp  \
    --namespace <target namespace>  \
    --inventory ibmRedisCPOperator  \
    --action mirror-images  \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

#### 5. Configure Cluster for Airgap

This steps does the following

* creates a global image pull secret for the target registry (skipped if target registry is unauthenticated)
* creates a imagesourcecontentpolicy

WARNING:

* Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in $HOME/.airgap/secrets and /tmp/airgap* to support this action

* Applying imagesourcecontentpolicy causes cluster nodes to recycle.

```bash
$ cloudctl case launch                  \
    --case case/ibm-redis-cp      \
    --namespace <target namespace>      \
    --inventory ibmRedisCPOperator \
    --action configure-cluster-airgap   \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

### 6. Install Catalog Source

This step installs the operator catalogsource in the openshift-marketplace namespace. And also installs catalogs from dependent subcases (couchdb in this case)

```bash
cloudctl case launch \
  --case case/ibm-redis-cp \
  --namespace $NS \
  --inventory ibmRedisCPOperator \
  --action install-catalog              \
  --args "--registry $TARGET_REGISTRY --inputDir $OFFLINEDIR --recursive"
```

### 7. Install Operator

See instructions from [Installing Redis](#installing-redis-example) section

### In Air-Gapped OpenShift Cluster Without a Bastion

#### 1. Prepare a portable device

Prepare a portable device (such as laptop) that be used to download the case and images can be carried into the air gapped environment

* Verify that the portable device has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
All the following steps should be run from the portable device

#### 2. Download CASE

See instructions from previous [Downloading CASE](#2-download-case) section

#### 3. Configure Registry Auth

See instructions from previous [Configure Registry Auth](#3-configure-registry-auth) section

#### 4. Mirror Images

See instructions from previous [Mirror Images](#4-mirror-images) section

#### 5. Configure Cluster for Airgap

See instructions from previous [Configure Cluster for Airgap](#5-configure-cluster-for-airgap) section

### 6. Install Catalog Source

See instructions from previous [Install Catalog Source](#6-install-catalog-source) section

### 7. Install the operator

See instructions from previous [Installing Redis](#installing-redis-example) section

## Configuration

* Provide configuration instructions if any

## Storage

* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## PodSecurityPolicy Requirements

* Describe your PodSecurityPolicy requirements here if applicable. (Required if your CASE supports being installed on Non-Red Hat Openshift)

### Custom PodSecurityPolicy definition

The Custom PodSecurityPolicy definition:

```
```

This is an OpenShift project and uses `SecurityContextConstriants`

## SecurityContextConstraints Requirements


Custom SecurityContextConstraints definition:

```
kind: SecurityContextConstraints
apiVersion: security.openshift.io/v1
metadata:
  name: ibm-rediscp-scc
seLinuxContext:
  type: MustRunAs

```
### Redis Controller

The IBM  Redis CP Operator controller currently runs with the default Red Hat `restricted` SCC.

This Operator also defines a custom SecurityContextConstraints object which is used to finely control the permissions/capabilities needed to deploy this Operator, the definition of this SCC is shown below:

#### Custom SecurityContextConstraints definition

The Custom SecurityContextConstraints definition:

```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: redisSCC
allowHostPorts: false
priority: null
requiredDropCapabilities:
  - MKNOD
allowPrivilegedContainer: false
runAsUser:
  type: MustRunAsRange
users: []
allowHostDirVolumePlugin: false
allowHostIPC: false
seLinuxContext:
  type: MustRunAs
readOnlyRootFilesystem: false
fsGroup:
  type: MustRunAs
groups: []
defaultAddCapabilities: null
supplementalGroups:
  type: RunAsAny
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
allowHostPID: false
allowHostNetwork: false
allowedCapabilities: null
```

If you wish to deploy the Operator controller under the custom SCC enforcement, then the SCC must be bound to the namespace before installing the Operator. Copy the above SCC into a file to apply it to your cluster. It is also available in the CASE under inventory/ibmRedisCPOperator/files/redis-operator-scc.yaml

```
oc login # login as cluster admin 

oc apply -f <path to scc>

oc create clusterrole redis-scc-binding-cluster-role --verb="use" --resource="securityContextConstraints" --resource-name="redisSCC"

oc create rolebinding redis-scc-binding-namespace-role-binding --clusterrole="redis-scc-binding-cluster-role" --group="system:serviceaccounts:<namespace for redis deployment>" 
```

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.3/authentication/managing-security-context-constraints.html).

#### Redis Operand Application

https://redis.io/docs/management/sentinel/
#### Custom SecurityContextConstraints definition

`TODO`
## Limitations
 NA
Detailed documentation in link.

## Documentation

