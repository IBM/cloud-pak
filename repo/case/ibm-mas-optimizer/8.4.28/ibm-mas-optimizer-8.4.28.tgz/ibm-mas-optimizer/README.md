# Name

IBM&reg; Maximo&reg; Optimizer

# Introduction
## Summary
IBM&reg; Maximo&reg; Optimizer includes IBM Maximo Optimization Framework for data and application management of optimization jobs and embeds IBM ILOG® CPLEX® Optimization Studio for solving optimization models.

## Features
Maximo Optimizer includes several IBM Maximo Optimization Framework models.

From the Maximo Optimizer administration user interface, you can configure and deploy optimization models

- Resource leveling
Optimize your schedule to balance resource use, balancing work demands with the available resource pool.

- Capacity planning
Optimize your schedule to complete as much work as possible in the allotted time period. Identify whether additional labor resources are necessary to complete work in a specific timeframe.

- Maintenance scheduling
Optimize large schedules in the Graphical Scheduling - Large Projects application.

- Labor and crew assignment
Optimize your schedule to automatically assign people and crews to work based on their availability and required skills.

- Spatial scheduling

Optimize your schedule to automatically assign work to people and crews based on their geographic location. Work is assigned based on the locations and work zones of labor and crew resources.[Learn more](https://www.ibm.com/products/maximo/asset-management)

# Details
## Prerequisites

IBM&reg; Maximo&reg; Optimizer requires IBM&reg; Maximo&reg; Application Suite to be installed before a successful deployment and activation in a workspace can be performed.

See prerequisites details here https://www.ibm.com/support/knowledgecenter/SSRHPA_8.5.0

- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4

### Resources Required
Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |   4.6       |  0.8        |  0        |  1    |


## Installing

- Navigate to OperatorHub in your OpenShift Dashboard and install the ibm-mas-optimizer operator following the instructions presented there.
- Deploy an instance of the `OptimizerApp` via the installed operator. Provide details of the cert-manager namespace and a Certificate Issuer to use (if configured). You must also accept the license
- Activate the Optimizer Application within a workspace using the Maximo Application Suite administration dashboard.

### Verifying Install
Check status of the OptimizerApp custom resource:
```sh
oc get OptimizerApp {{instanceId}} -n mas-{{instanceId}}-optimizer

NAME      VERSION            STATUS   AGE
mascore   8.10.0              Ready    5h53m
```

For a more detailed view of the status run the following:
```sh
oc get OptimizerApp {{instanceId}} -o yaml
```

The status will show an overall Ready status type:
```yaml
  status:
    conditions:
    - lastTransitionTime: '2021-09-02T18:36:10Z'
      message: Ready to enable workspace
      reason: Ready
      status: 'True'
      type: Ready
```

Check status of the OptimizerWorkspace custom resource:

```sh
oc get OptimizerWorkspace {{instanceId}}-{{workspaceId}} -n mas-{{instanceId}}-optimizer

NAME      VERSION            STATUS   AGE
mascore   8.10.0              Ready    5h53m
```

For a more detailed view of the status run the following:
```sh
oc get OptimizerWorkspace {{instanceId}}-{{workspaceId}} -n mas-{{instanceId}}-optimizer -o yaml
```

The status will show an overall Ready status type:
```yaml
  status:
    conditions:
    - lastTransitionTime: "2021-09-03T17:12:08Z"
      message: Optimizer activated in workspace masdev
      reason: Ready
      status: "True"
      type: Ready
```


## Configuration
See the details provided in [IBM docs](https://www.ibm.com/support/knowledgecenter/SSRHPA_8.5.0) for more information about how to configure Maximo Application Suite.

## Storage

IBM&reg; Maximo&reg; Optimizer requires no direct persistent storage in the OpenShift cluster. All data is stored in the MonogDB prerequiste.

### Encryption
We recommend the use of storage with passive encryption enabled to protect the data in MongoDB.

## Air Gap Installs
Air gap installs are supported in Maximo Application Suite 8.10. For more information, see [Installing Maximo Application Suite in an AirGap environment] (https://www.ibm.com/docs/en/mas-cd/continuous-delivery?topic=installation-in-disconnected-environment).

## Limitations
- The operator only supports single namespace deployment
- The operator will only watch for resources in its own namespace
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of the OptimizerApp can **not** be deployed in the same namespace
- Each OptimizerApp resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-optimizer`

## Upgrades
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.8/html/operators/administrator-tasks#olm-upgrading-operators).

## Documentation
The Maximo Application Suite documentation is available [here](https://www.ibm.com/docs/SSRHPA/latest)

## License
Maximo Application Suite 8.10 License is available [here](https://ibm.biz/MAS810-License)

## Backup
### Backup process
Backups should be made of both the OpenShift Cluster and MongoDb.

OpenShift Cluster backup requires backing up the etcd cluster. Details can be found in the OpenShift Container Platform [documentation](https://docs.openshift.com/container-platform/4.8/backup_and_restore/control_plane_backup_and_restore/backing-up-etcd.html)

Backups should be made of the following MongoDB databases created by Maximo Optimizer:
- `mas_{{instanceId}}_optimizer`

### Restore process
Restoring should be executing as described in the OpenShift Container Platform documentation and MongoDB documentation.

## SecurityContextConstraints Requirements
The operator uses the Openshift default `restricted` SCC (Security Context Constraints).

## Reason Codes

#### OptimizerApp:
- **ApplicationComponentNotReady** : One or more application level components are not ready. The status message will indicate which component is not currently operational.
- **CompatibilityCheckFailure** : Installed MAS Core version  is not compatible with application version.
- **InstallPending**: Installation is currently inprogress.
- **AppPointReservationFailed** : Appoint reservation failed.
- **TruststoreNotReady** : Optimizer truststore is not ready.  Timed out after 2 minutes.
- **InvalidConfiguration** : Invalid configuration. Either applicationId or instanceId labels are invalid.

#### OptimizerWorkspace:
- **WorkspaceComponentNotReady**  : One or more workspace level components are not ready. The status message will indicate which component is not currently operational.
- **InvalidConfiguration** : Invalid configuration. Either applicationId, workspaceId or instanceId labels are invalid.
- **InstallPending**: Installation is currently inprogress.
