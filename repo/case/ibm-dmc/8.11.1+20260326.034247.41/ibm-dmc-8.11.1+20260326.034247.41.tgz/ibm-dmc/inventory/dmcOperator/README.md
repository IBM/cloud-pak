# IBM Db2 Data Management Console Operator

Contains the IBM Db2 Data Management Console Operator custom resource and launch scripts to install/delete the custom resources
