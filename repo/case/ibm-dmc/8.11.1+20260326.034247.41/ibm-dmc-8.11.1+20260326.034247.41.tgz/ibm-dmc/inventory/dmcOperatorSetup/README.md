# IBM Db2 Data Management Console Operator Setup

This inventory item contains resources required to install the IBM Db2 Data Management Console Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI) application of kubernetes manifests in both an online and offline airgap environment.

