IBM Db2 Data Management Console is a browser-based tool that helps you administer, monitor, manage and optimize the performance of IBM Db2 databases.


# Name

IBM&reg; Db2 Data Management Console

# Introduction

This case contains  ibm-dmc and the ibm-dmc-addon which is the module to interagte DMC into Cloud pak for data.

## Summary

IBM&reg; Db2 Data Management Console is an integrated database  management offering, with capabilities and tooling for managing databases provisioned in Cloud pak for data. Key features of the DMC include admin, monitor, runsql, load, and explan. 


## Features
- Real-time and historical monitoring
Track the health and status of your database on the Monitor Summary page. At a high level, your database status is represented by six stories, similar to how every airplane is equipped with six core instruments. Use these to understand the availability, responsiveness, throughput, resource use, user contention and time spent in each database from one screen. These same metrics are also available on the enterprise home page, which lists your databases and allows you to access their metrics.

- Alerts and notifications
The console supports a wide range of alerts to ensure you can catch the problems before they impact the business. You can review alert information plus sort and share all received alerts from the Notification Center. Some of the supported alerts are threshold alerts, smart alerts for query optimization, HADR alerts, email and SNMP notifications. The console is also integrated with an IBM tool that apples machine learning (ML) algorithms to analyze some issues and propose auto-fixes.

Fully integrated SQL editor
Write and edit SQL with the help of an interactive type-ahead SQL parser. Run SQL scripts and view results right away or export them to a CSV or Excel worksheet. With the collaboration feature, share SQL scripts with your team by copying and sending them through a shared link. Improve team productivity by using templates and shared scripts. You can also collect a detailed history of the SQL statements running on your database locate inefficiencies and optimize performance.

- Database object exploration and management
You can manage and explore objects to understand relationships between them. For example, you can view all tables under your schemas, look through table properties and definitions, and create new tables directly in the console. Some other primary object types supported are view, remote tables, aliases, schemas, sequences and MQTs. You can explore application objects, such as stored procedures, user-defined types and functions; manage databases by user, group or role; and run changes immediately or build a script to automate changes.

- Team collaboration with composable user interface
The user interface of the new console is built to allow you to compose your own interface by picking what you want to see. Each time you select a new page, the URL uniquely identifies that part of the interface. If you send that URL to other users of the console, they can go to the same page you are seeing. With a small modification to the URL, that page can be embedded into your Iframe, webpage or Jupyter notebook.

- Support for RESTful services APIs
Access and configure all console capabilities with RESTful APIs and sample scripts in key programming languages for an open and extensible development experience. That includes APIs to run SQL, manage database objects and privileges, monitor performance, and load data and files. Complete and comprehensive documentation on how to use this functionality is built into the user interface. Examples of how to write your own code in Python to access and use these new interfaces are on GIT.

# Details

## Prerequisites

1. OpenShift Version >= 4.6
2. IBM Cloud Pak for Data >= 4.0.0


### Resources Required

To deploy Data Management Console as add-on to IBM Cloud Pak for Data, you must have the following minimum resources available.

* Cores: 4 available cores
* Memory: 10 Gi available memory
* Persistent storage: 43Gi

# Install Modes

The operator can be installed in of the following install modes.

- OwnNamespace
- SingleNamespace
- MultiNamespace
- AllNamespaces

More details about the behaviour of each install mode can be found in this [Redhat documentation](https://docs.openshift.com/container-platform/4.1/applications/operators/olm-understanding-olm.html#olm-operatorgroups-membership_olm-understanding-olm)

# Installing

This case is to be installed via Cloud Pak for Data integrated interface using add-on logic.

This operator can be installed in an on-line or air-gapped cluster through either of following install paths :

1. Operator Life Cycle Manager (default)
2. Kubernetes CLI

It supports being installed cluster wide or in specific namespaces.

## Online using Openshift Operator Catalog

1. Install the operator via OLM

```bash
cloudctl case launch               \
    --case <path/to/case>          \
    --namespace <target namespace> \
    --inventory dmcOperator      \
    --action install-operator      \
```

## Air-Gapped OpenShift Cluster With a Bastion

All the following steps should run from the bastion machine.

### 1. Prepare Bastion Host

- Verify that the bastion machine has access to the following

  - public internet (to download CASE and images)
  - a target image registry (where the images will be mirrored)
  - a target openshift cluster to install the operator

- Download and install dependent command line tools
  - [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with Openshift Cluster
  - [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

### 2. Download CASE

1. Create a directory to save the CASE to a local directory

   ```bash
   $ mkdir /tmp/cases
   ```

2. Save the case bundle using cloudctl

   ```bash
   $ cloudctl case save --case <path/to/case> --outputdir /tmp/cases
   Downloading and extracting the CASE ...
   - Success
   Retrieving CASE version ...
   - Success
   Validating the CASE ...
   - Success
   Creating inventory ...
   - Success
   Finding inventory items
   - Success
   Resolving inventory items ...
   Parsing inventory items
   - Success
   ```

3. Verify the CASE and images csv has been downloaded

   ```bash
   $ ls /tmp/cases/

   ```

### 3. Configure Registry Auth

1. Create auth secret for the the source image registry

   ```bash
   $ cloudctl case launch              \
       --case <path/to/case>           \
       --namespace <target namespace>  \
       --inventory dmcOperator       \
       --action configure-creds-airgap \
       --args "--registry cp.icr.io --user cp --pass <token>"
   ```

2. Create auth secret for target image registry

   ```bash
   $ cloudctl case launch              \
       --case <path/to/case>           \
       --namespace <target namespace>  \
       --inventory dmcOperator       \
       --action configure-creds-airgap \
       --args "--registry $TARGET_REGISTRY --user abc --pass xyz"
   ```

The credentials are now saved to `~/.airgap/secrets/<registry-name>.json`

### 4. Mirror Images

In this step image from saved CASE (`images.csv`) are copied to target registry in the airgap environment

```bash
$ cloudctl case launch             \
    --case <path/to/case>          \
    --namespace <target namespace> \
    --inventory dmcOperator      \
    --action mirror-images         \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

### 5. Configure Cluster for Airgap

This steps does the following

- creates a global image pull secret for the target registry (skipped if target registry is unauthenticated)
- creates a ImageSourceContentPolicy

**WARNING:**

- Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in `$HOME/.airgap/secrets` and `/tmp/airgap*` to support this action

- Applying ImageSourceContentPolicy causes cluster nodes to recycle.

```bash
$ cloudctl case launch                \
    --case <path/to/case>             \
    --namespace <target namespace>    \
    --inventory dmcOperator         \
    --action configure-cluster-airgap \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

### 6. Install Catalog Source

This step installs the operator catalogsource in the openshift-marketplace namespace.

```bash
cloudctl case launch                  \
  --case <path/to/case>               \
  --namespace $NS                     \
  --inventory dmcOperator           \
  --action install-catalog            \
  --args "--registry $TARGET_REGISTRY --inputDir $OFFLINEDIR --recursive"
```

### 7. Install Operator

See instructions from the [Online Install](#online-using-openshift-operator-catalog) section

## In Air-Gapped OpenShift Cluster Without a Bastion

### 1. Prepare a portable device

Prepare a portable device (such as laptop) that be used to download the case and images can be carried into the air gapped environment

- Verify that the portable device has access

  - to public internet (to download CASE and images)
  - a target image registry ( where the images will be mirrored)
  - a target openshift cluster to install the operator

- Download and install dependent command line tools
  - [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with Openshift Cluster
  - [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the portable device

### 2. Download CASE

See instructions from previous [Downloading CASE](#2-download-case) section

### 3. Configure Registry Auth

See instructions from previous [Configure Registry Auth](#3-configure-registry-auth) section

### 4. Mirror Images

See instructions from previous [Mirror Images](#4-mirror-images) section

### 5. Configure Cluster for Airgap

See instructions from previous [Configure Cluster for Airgap](#5-configure-cluster-for-airgap) section

### 6. Install Catalog Source

See instructions from previous [Install Catalog Source](#6-install-catalog-source) section

### 7. Install the operator

See instructions from previous [Online install](#online-using-openshift-operator-catalog) section



## Scaling

The cpu and memory of dmc instance can be scaled if needed.

Change the `scaleConfig` parameter to `small_mincpureq small medium large` in CustomResource to match the requirement.

## Upgrades


## Configuration

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/en/SSQNUZ_3.0.1/svc-welcome/dmc.html) for instructions on installing and configuring this workload.

## Storage

Persistent Volumes are required if persistence is enabled. Currently, only volumes created via dynamic provisioning are supported. The storage class used may support ReadWriteOnce or ReadWriteMany. 

- NFS, Portwokx or Openshift container storage class supported

## Limitations

- A cluster admin role is required to install.

## Documentation

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/en/SSQNUZ_3.0.1/svc-welcome/dmc.html) for further guidance.

## SecurityContextConstraints Requirements

The predefined SecurityContextConstraints name: restricted has been verified for this CASE, if your target namespace is bound to this SecurityContextConstraints resource you can proceed.

Custom SecurityContextConstraints definition: 
```
not required
```

