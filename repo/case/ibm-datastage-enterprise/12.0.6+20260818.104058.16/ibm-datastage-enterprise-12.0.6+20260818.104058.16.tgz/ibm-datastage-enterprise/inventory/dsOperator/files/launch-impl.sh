# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ds operator

# ds operator specific variables
#caseName="ibm-sample-panamax"
caseName="ibm-datastage-enterprise"

caseCatalogName="ibm-cpd-datastage-operator-catalog"
catalogNamespace="openshift-marketplace"
caseSubscriptionName="ibm-cpd-datastage-operator-subscription"
channelName="v10.6"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies="ibm-ccs"

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ds-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:tbd}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-wcp-datastage-team-docker-local.artifactory.swg-devops.com}"
CATALOG_IMAGE="${CATALOG_IMAGE:-ds-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:tbd}"
storageclass=""
backupstorageclass=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."

kubernetesCLI="oc"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageclass)
        storageclass=$val
        ;;
    --service)
        service=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {
    echo "------------- Installing operator group for $namespace -------------"
    
    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        sed <"${casePath}/inventory/${inventory}/files/dsOperatorGroup.yaml"  "s#NAMESPACE#${namespace}#g" | $kubernetesCLI -n ${namespace} apply -f -
    fi
    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/dsCatalogSource.yaml"
    #CATALOG_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${CATALOG_IMAGE}@${CATALOG_DIGEST}
    CATALOG_IMAGE_FULL_PATH=$(cat ${catsrc_file} | grep 'image:' | awk '{print $2}' | sed 's/"//g')

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        $kubernetesCLI apply ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/dsCatalogSource.yaml
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        #local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
        local catsrc_image_mod="${registry}/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/[^/]*\///")"
        if [[ ${registry} == "cp.stg.icr.io" ]]; then
            local catsrc_image_mod="${registry}/cp/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/.*\///")"
        fi
        # apply catalog source
        sed <"${catsrc_file}" "s|image: .*|image: ${catsrc_image_mod}|g" | $kubernetesCLI apply ${dryRun} -f -
    fi

    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    echo "start install_operator()"
    dssetup_defintion_files="${casePath}/inventory/${inventory}/files"
    local subscription_file="${dssetup_defintion_files}/dsSubscription.yaml"
    local catalog_source_file="${dssetup_defintion_files}/dsCatalogSource.yaml"
    setupRolesForDS
    $kubernetesCLI apply -f ${catalog_source_file}
    waitForDSCatalogPod
    install_operator_group
    sleep 10

    sed <"${subscription_file}" "s#NAMESPACE#${namespace}#g" | $kubernetesCLI apply -f -

    #waitForIP
    waitForCSV
    waitForDSOperator
    echo "complete install_operator()"
}

waitForDSCatalogPod()
{
    echo "start waitForDSCatalogPod()"
    waitIteration=120
    waitSeconds=10
    sleep 10
    for ((i=1; i<=${waitIteration}; i++))
    do
        count=`$kubernetesCLI get pods -n openshift-marketplace | grep "1/1" | grep -c ${caseCatalogName}` || true
        if [ $count -eq 1 ]; then
           break
        else
           echo "Pods in progress: iter: $i"
           $kubernetesCLI get pods -n openshift-marketplace | grep ${caseCatalogName} || true
           sleep ${waitSeconds}
        fi
    done
    if [ $count -eq 0 ]; then
        echo "The following pods are still not ready:"
        $kubernetesCLI get pods -n openshift-marketplace | grep ${caseCatalogName} || true
        exit 1
    fi
    echo "complete waitForDSCatalogPod()"
}

waitForIP()
{
    echo "start waitForIP()"
    waitIteration=20
    waitSeconds=10
    sleep 10
    for ((i=1; i<=${waitIteration}; i++))
    do
        $kubernetesCLI get ip -n ${namespace} | grep ibm-cpd-datastage-operator | grep true > /tmp/pods_in_progress.tmp || true
        count=`cat /tmp/pods_in_progress.tmp | wc -l`
        if [ $count -eq 1 ]; then
            break
        else
            echo "ip is not ready yet:"
            $kubernetesCLI get ip -n ${namespace} | grep ibm-cpd-datastage-operator || true
            sleep ${waitSeconds}
        fi
    done
    if [ $count -eq 0 ]; then
        echo "ip is not ready after $i iteration waiting:"
        $kubernetesCLI get ip -n ${namespace} | grep ibm-cpd-datastage-operator || true
        exit 1
    fi
    echo "complete waitForIP()"
}

waitForCSV()
{
    echo "start waitForCSV()"
    waitIteration=120
    waitSeconds=10
    sleep 10
    for ((i=1; i<=${waitIteration}; i++))
    do
        $kubernetesCLI get csv -n ${namespace} | grep ibm-cpd-datastage-operator | grep Succeeded > /tmp/pods_in_progress.tmp || true
        count=`cat /tmp/pods_in_progress.tmp | wc -l`
        if [ $count -eq 1 ]; then
            break
        else
            echo "csv is not ready yet:"
            $kubernetesCLI get csv -n ${namespace} | grep ibm-cpd-datastage-operator || true
            sleep ${waitSeconds}
        fi
    done
    if [ $count -eq 0 ]; then
        echo "csv is not ready after $i iteration waiting:"
        $kubernetesCLI get csv -n ${namespace} | grep ibm-cpd-datastage-operator || true
        exit 1
    fi
    echo "complete waitForCSV()"
}

waitForDSOperator()
{
    echo "start waitForDSOperator()"
    waitIteration=120
    waitSeconds=10
    sleep 10
    for ((i=1; i<=${waitIteration}; i++))
    do
        $kubernetesCLI get pods -n ${namespace} | grep ds-operator-controller-manager | grep -v "1/1" > /tmp/pods_in_progress.tmp || true
        count=`cat /tmp/pods_in_progress.tmp | wc -l`
        if [ $count -eq 0 ]; then
            break
        else
            echo "Pods in progress: $count, iter: $i"
            cat /tmp/pods_in_progress.tmp
            sleep ${waitSeconds}
        fi
    done
    if [ $count -gt 0 ]; then
        echo "The following pods are still not ready or have issues:"
        cat /tmp/pods_in_progress.tmp
        exit
    fi
    echo "complete waitForDSOperator()"
}

# Install utilizing default CLI method
install_operator_native() {
    echo "start install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verify expected yaml files for install exist
    dssetup_defintion_files="${casePath}/inventory/dsOperatorSetup/files"
    echo "dssetup_defintion_files: ${dssetup_defintion_files}"

    setupRolesForDS

    sed <"${dssetup_defintion_files}/deploy/manifestsNativeDeploy.yaml" "s#namespace: NAMESPACE#namespace: ${namespace}#g" | $kubernetesCLI apply -f -

    waitForOperator
    echo "complete install_operator_native()" 
}

setupRolesForDS()
{
    echo "start setupRolesForDS()"
    dssetup_defintion_files="${casePath}/inventory/dsOperatorSetup/files"
    sed -i -e "s/namespace: NAMESPACE/namespace: ${namespace}/g" ${dssetup_defintion_files}/ds-admin-rb.yaml
    oc apply -f ${dssetup_defintion_files}/ds-admin-role.yaml -n ${namespace}
    oc apply -f ${dssetup_defintion_files}/ds-admin-rb.yaml -n ${namespace}
    echo "complete setupRolesForDS()"
}

waitForOperator()
{
    echo "start waitForOperator()"
    waitIteration=120
    waitSeconds=10
    sleep 10
    for ((i=1; i<=${waitIteration}; i++))
    do
        $kubernetesCLI get pods -n ${namespace} | grep ibm-cpd-datastage-operator | grep -v "1/1" > /tmp/pods_in_progress.tmp || true
        count=`cat /tmp/pods_in_progress.tmp | wc -l`
        if [ $count -eq 0 ]; then
            break
        else
            echo "Pods in progress: $count, iter: $i"
            cat /tmp/pods_in_progress.tmp
            sleep ${waitSeconds}
        fi
    done
    if [ $count -gt 0 ]; then
        echo "The following pods are still not ready or have issues:"
        cat /tmp/pods_in_progress.tmp
        exit
    fi
    echo "complete waitForOperator()"
}

# install operand custom resources
apply_custom_resources() {
    echo "apply_custom_resources()"
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete catalogsource ibm-cpd-datastage-operator-catalog -n openshift-marketplace --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "start uninstall_operator()"
    echo "Find installed CSV ..."
    csvName=$($kubernetesCLI get subscription ${caseSubscriptionName} -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    echo "csvName=${csvName}"
    echo "Remove the subscription ..."
    $kubernetesCLI delete subscription ${caseSubscriptionName} -n "${namespace}" --ignore-not-found=true
    echo "Remove the CSV which was generated by the subscription but does not get garbage collected ..."
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true }; }

    echo "Delete catalog source ..."
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true

    echo "Delete operator Group..."
    $kubernetesCLI delete og ibm-cpd-datastage-operator-group -n "${namespace}" --ignore-not-found=true
    echo "complete uninstall_operator()"
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    echo "start uninstall_operator_native()"

    # Verify expected yaml files for install exist
    dssetup_defintion_files="${casePath}/inventory/dsOperatorSetup/files"
    echo "dssetup_defintion_files: ${dssetup_defintion_files}"
    sed <"${dssetup_defintion_files}/deploy/manifestsNativeDeploy.yaml" "s#namespace: NAMESPACE#namespace: ${namespace}#g" | $kubernetesCLI -n ${namespace} delete ${dryRun} -f -
    waitForDSOperatorDeletion
    echo "complete uninstall_operator_native()"
}

waitForDSOperatorDeletion()
{
    echo "start waitForDSOperatorDeletion()"
    waitIteration=120
    waitSeconds=10
    sleep 10
    for ((i=1; i<=${waitIteration}; i++))
    do
        count=`$kubernetesCLI get pods -n ${namespace} | grep -c ds-operator-controller-manager` || true
        if [ $count -eq 0 ]; then
            break
        else
            echo "Pods in progress: $count, iter: $i"
            $kubernetesCLI get pods -n ${namespace} | grep -c ds-operator-controller-manager || true
            sleep ${waitSeconds}
        fi
    done
    if [ $count -gt 0 ]; then
        echo "The following pods are still not deleted:"
        $kubernetesCLI get pods -n ${namespace} | grep ds-operator-controller-manager || true
        exit 1
    fi
    echo "complete waitForDSOperatorDeletion()"
}

delete_custom_resources() {
    echo "delete_custom_resources()"
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
