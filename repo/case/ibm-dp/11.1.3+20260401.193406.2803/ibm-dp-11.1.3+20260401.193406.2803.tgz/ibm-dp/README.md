# Name

IBM&reg; Data Privacy

# Introduction

## Summary

* Paragraph overview of the product
* Include links to external sources for more details

## Features

* Simple bullet list of product features


# Details

## Prerequisites
IBM Cloud Pak for Data Data Privacy requires the following
- Watson Knowledge Catalog 4.0.2 or later
- Analytics Engine powered by Apache Spark 4.0.2 or later 

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Cloud Pak for Data | 64 | 16 | 100 | 3 |
| **Total** | **64** | **16**  | **100**  | **3** |

# Installing

### Get cloudctl
Download latest cloudctl binary from url below and add it to your $PATH

Release page: https://github.com/IBM/cloud-pak-cli/releases

### Get Data Privacy development case 
Build the latest Data Privacy development case tgz file from <ibm-git-hub>/data-privacy/ibm-dp-bundle/blob/master/stable/ibm-dp-bundle/case/ibm-dp/

### Prerequisites
**1. Update the global pull secrets**

- Back up your current global pull secret (IMPORTANT)
```
oc get secret pull-secret -n openshift-config -o yaml > global-pull-secret.yaml
```
- Create/Update the global pull secret
```
REGISTRY_USER=<your user name for image registry>
REGISTRY_APIKEY=<your api key for image registry>
# for Linux
pull_secret=$(echo -n "$REGISTRY_USER:$REGISTRY_APIKEY" | base64 -w0)
# for Mac
pull_secret=$(echo -n "$REGISTRY_USER:$REGISTRY_APIKEY" | base64)
```
Replace the `registry url` with actual value, e.g. `docker-na-public.artifactory.swg-devops.com/hyc-dp-team-docker-local` or `cp.stg.icr.io/cp`

```
oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|:{|:{"<registry url>":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json
```
**2. Add docker registry to mirror registry**   
Add the mirrorings below to facilliate image pulling from the accessible registry.

```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: dp-mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - cp.stg.icr.io/cp
    source: icr.io/cpopen
  - mirrors:
    - cp.stg.icr.io
    source: cp.icr.io
EOF
```
It might take up to 20-25 min to update nodes to setup mirrors during which time a scheduling will be disabled on the nodes. Check your nodes' status and wait until they are all `Ready`

### ONLINE: Install Data Privacy Operator using OLM [Cloudctl]   
**1. Install Data Privacy Operator**   
```
export NAMESPACE=<Operator Project>

cloudctl case launch --case <dp case tgz file> --tolerance 1 --namespace <Operator Project> --action installOperator --inventory dpOperatorSetup

Note: <Operator Project> = ibm-common-services
```

Confirms if operator pod is up before moving to next step.

**2. Install Data Privacy Custom Resource**

```
#Note: <CP4D Project> = zen
export NAMESPACE=<CP4D Project>   
oc new-project <CP4D Project>  
cloudctl case launch --case <dp case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory dpOperator --args "--storageclass <accessible storage class> --license-accept --license-type <Enterprise|Standard>"
```

### AIRGAP: Install Data Privacy Operator using OLM [Cloudctl]

**1. Setup environment variables**

```
export SOURCE_REGISTRY=cp.stg.icr.io
export SOURCE_REGISTRY_PASS=<source registry password>
export SOURCE_REGISTRY_USER=<source registry user>
export TARGET_REGISTRY=docker-na-public.artifactory.swg-devops.com/dataconn-docker-local
export TARGET_REGISTRY_USER=<target registry user>
export TARGET_REGISTRY_PASS=<target registry password>

```
**2. create directory**
```
mkdir offline
```
**3. Save case**
```
cloudctl case save --case /root/install/ibm-dp --outputdir /root/test/offline -t 1
```
**4. Create credentials for airgap**
```
cloudctl case launch --case /root/install/ibm-dp --inventory dpOperatorSetup --action configureCredsAirgap --args "--registry $SOURCE_REGISTRY --user $SOURCE_REGISTRY_USER --pass $SOURCE_REGISTRY_PASS" --tolerance 1

cloudctl case launch --case /root/install/ibm-dp --inventory dpOperatorSetup --action configureCredsAirgap --args "--registry $TARGET_REGISTRY --user $TARGET_REGISTRY_USER --pass $TARGET_REGISTRY_PASS" --tolerance 1
```
The following two files will be created after running the above 2 commands
```
ls -l ~/.airgap/secrets/
total 8
-rw------- 1 root root 128 May 20 05:48 cp.stg.icr.io.json
-rw------- 1 root root 215 May 20 05:48 dataconn-docker-local.artifactory.swg-devops.com.json

```
**5.Update image csv update offline/ibm-dp-`version`-images.csv. Replacing "cp.icr.io" with "cp.stg.icr.io" and replacing "icr.io,cpopen" with "cp.stg.icr.io,cp"**

**6.Load image to target registry**
```
yum install skopeo
export USE_SKOPEO=true

cloudctl case launch --case /root/install/ibm-dp --inventory dpOperatorSetup --action mirrorImages --args "--registry $TARGET_REGISTRY --inputDir /root/test/offline" -t 1
```
**7. setup mirror in airgap cluster**
```
cloudctl case launch --case /root/install/ibm-dp --inventory dpOperatorSetup --namespace ibm-common-services --action configureClusterAirgap --args "--registry $TARGET_REGISTRY --inputDir /root/test/offline" -t 1
```
ImageContentSourcePolicy "ibm-dp" is created and pull secret for registr $TARGET_REGISTRY is added to secret "pull-secret" in namespace "openshift-config" after running the above command

Create ImageContentSourcePolicy will requires all nodes to restart. Wait until all node are ready before continue.

**8. Install catalog**
```
cloudctl case launch --case /root/install/ibm-dp --inventory dpOperatorSetup --namespace ibm-common-services --action installCatalog -t 1
```
The catalogsource "ibm-cpd-dp-operator-catalog" is created in project "openshift-marketplace"
```
oc get catsrc -n openshift-marketplace | grep dp
ibm-cpd-dp-operator-catalog   CPD Data Privacy       grpc   IBM         5d12h 
```

**9. Install Data Privacy Operator**  
```
export NAMESPACE=<Operator Project>

cloudctl case launch --case <dp case tgz file> --tolerance 1 --namespace <Operator Project> --action installOperator --inventory dpOperatorSetup

Note: <Operator Project> = ibm-common-services
```

## Configuration

* Provide configuration instructions if any

## Storage

* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## Limitations

* Deployment limits - can you deploy more than once, can you deploy into different namespace
* List specific limitations such as platforms, security, replica's, scaling, upgrades etc.. - noteworthy limits identified
* List deployment limitations such as : restrictions on deploying more than once or into custom namespaces.
* Not intended to provide chart nuances, but more a state of what is supported and not - key items in simple bullet form.
* Does it work on IBM Kubernetes Services, IBM Private Cloud ?

## Documentation

* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.

## Development
### Build CASE Bundle
Build case tgz file from case directory (in ibm-dp-bundle/stable/ibm-dp-bundle/case for Data Privacy), create case tgz with below command:
```
tar -zcvhf ibm-dp-1.tgz ibm-dp/ 
```
Note the “h” option is needed to archive the actual file instead of symbolic link

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```
## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  Use the OpenShift built in restricted SCC.
Custom SecurityContextConstraints definition:
```
Not Applicable
```
