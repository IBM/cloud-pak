# Introduction
The IBM® Db2 Operator Extension for IBM® Cloud Pak for Data installs a set of extensions to enable IBM® Db2 within Cloud Pak for Data.

# Name

IBM® Db2 Operator Extension for IBM® Cloud Pak for Data

# Introduction

## Summary

IBM® Db2 Database is an AI-infused, cost-effective data management system with proven performance and scalability, available both on premises and on the cloud. The Db2 container and operator have a strong focus on quality & architecture, performance, security, and deployment time.

- Powered by AI–Machine learning algorithms help to provide significantly faster query speed improvements.–Machine learning algorithms are used to score queries and provide confidence-based results for faster insights.
- Built for AI–Support for PYTHON, GO, JSON, and Jupyter Notebooks allows data scientists to use the most innovative tools available.–Data federation lets mission-critical data stay in place while running operations, fueling new insights with less hassle

Refer to the [IBM Db2 Material](https://www.ibm.com/analytics/db2) for more information.

## Documentation

See the [IBM Cloud Pak for Data Db2 Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSEPGG_11.5.0/com.ibm.db2.luw.db2u_openshift.doc/doc/c_db2u_11-5-5.html)

# Details

## Prerequisites

This operator depends on the IBM Db2 Operator. This IBM Db2 Operator will be automatically installed using the Operand Deployment Lifecycle Manager operator.

## Supported platforms

Red Hat OpenShift Container Platform 4.6 or newer installed on one of the following platforms:
- Linux x86_64
- Power ppc64le
- IBM Z s390x

## Link To External Documentation
https://www.ibm.com/analytics/db2

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
This operator runs with the 'restricted' SCC

```
openshift.io/scc: restricted
```