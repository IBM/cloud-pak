#!/bin/bash

# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh

## variables specific to catalog/operator installation
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

NOT_IMPLEMENTED="Not implemented for the Db2u Operator"
CATALOG_IMAGE="operator-catalog"

SUBSCRIPTION="subscription.yaml"
CATALOG_SOURCE="catalog-source.yaml"
OPERATOR_GROUP="operator-group.yaml"
MARKETPLACE="openshift-marketplace"
LATEST=":latest"
REPL_NAMESPACE="REPLACE_NAMESPACE"

CATALOG_KIND="CatalogSource"
SUBSCRIPTION_KIND="Subscription"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
      --storageClass)
        storage_class=$val
        shift 2
        ;;
      --source-namespace)
        sourceNamespace=$val
        shift 2
        ;;
      --channel)
        channel=$val
        shift 2
        ;;
      --csv)
        csv=$val
        shift 2
        ;;
      --registry)
        registry=$val
        shift 2
        ;;
      --operator-image-namespace)
        operator_image_namespace=$val
        shift 2
        ;;
      --operand-image-namespace)
        operand_image_namespace=$val
        shift 2
        ;;
    esac
}

## Not Defined for Db2U Operator
dependent_inventory_item() {
    echo ${NOT_IMPLEMENTED}
}

## Not Defined for Db2U Operator
dependent_case_tgz() {
    echo ${NOT_IMPLEMENTED}
}

# ----- INSTALL ACTIONS -----

## Not Defined for Db2U Operator
install_dependent_catalogs() {
    echo ${NOT_IMPLEMENTED}
}

## Not Defined for Db2U Operator
install_dependent_operators() {
    echo ${NOT_IMPLEMENTED}
}

## Creates the OLM Operator Group
install_operator_group() {

    op=$($kubernetesCLI get operatorgroup -n ${namespace} -o name)

    ## Only create an OP if one does not exist
    if [ -z "$op" ]
    then
        BUNDLE_CSV="${casePath}/inventory/${inventory}/files/deploy/install"
        OP_FILE="${BUNDLE_CSV}/${OPERATOR_GROUP}"
        perl -i -pe "s/namespace:[[:blank:]]${REPL_NAMESPACE}/namespace: ${namespace}/g" ${OP_FILE}
        perl -i -pe "s/-[[:blank:]]${REPL_NAMESPACE}/- ${namespace}/g" ${OP_FILE}

        echo "About to Create:"
        cat ${OP_FILE}
        $kubernetesCLI apply -f ${OP_FILE} -n ${namespace}

        perl -i -pe "s/namespace:[[:blank:]]${namespace}/namespace: ${REPL_NAMESPACE}/g" ${OP_FILE}
        perl -i -pe "s/-[[:blank:]]${namespace}/- ${REPL_NAMESPACE}/g" ${OP_FILE}
    else
        echo "Operator Group is already created! Skipping"
    fi
}

## Creates the OLM Suscription
create_subscription() {
    ## Locate the root of the install DIR
    BUNDLE_CSV="${casePath}/inventory/${inventory}/files/deploy/install"
    
    ## Get the Subscription
    SUBSCRIPTION_FILE=${BUNDLE_CSV}/${SUBSCRIPTION}
    SUBSCRIPTION_TMP_FILE="subscription-temp.yaml"

    ## copy the original subscription.yaml as a temp file so the original file does not get overwritten
    \cp ${SUBSCRIPTION_FILE} ${SUBSCRIPTION_TMP_FILE}
    ## Edit Custom Source Namespace Arg in Subscription
    
    if [[ -z ${sourceNamespace} ]]; then sourceNamespace=${MARKETPLACE}; fi
    perl -i -pe "s/sourceNamespace:[[:blank:]]\S+/sourceNamespace: ${sourceNamespace}/g" ${SUBSCRIPTION_TMP_FILE}

    [[ ! -z ${channel} ]] && perl -i -pe "s/channel:[[:blank:]]\S+/channel: ${channel}/g" ${SUBSCRIPTION_TMP_FILE}
    [[ ! -z ${csv} ]] && perl -i -pe "s/startingCSV:[[:blank:]]db2u-operator.v\S+/startingCSV: db2u-operator.v${csv}/g" ${SUBSCRIPTION_TMP_FILE}

    ## Create the Subscription
    cat ${SUBSCRIPTION_TMP_FILE}
    $kubernetesCLI apply -f ${SUBSCRIPTION_TMP_FILE} -n ${namespace}

    ## Extract properties
    CSV_VERSION=$(cat ${SUBSCRIPTION_TMP_FILE} | grep "startingCSV" | cut -d ":" -f 2 | tr -d [:space:])
    [[ -z ${CSV_VERSION} ]] && { echo "File ${SUBSCRIPTION} does not contain the proper name tag" && exit; }

    ## Delete the temporary subscription
    rm -rf ${SUBSCRIPTION_TMP_FILE}

    LOOP=TRUE
    UPDATE_REGISTRY=FALSE
    if [[ -n "${registry}" ]];
    then
        UPDATE_REGISTRY=TRUE 
    fi
    while [[ $LOOP == "TRUE" ]];
    do
        sleep 40
        RESP="X$($kubernetesCLI get csv ${CSV_VERSION} -n ${namespace} --no-headers 2>/dev/null)"
        RC=$(echo $?)
        STATUS="Installing"
        if [ "$RC" -eq 0 ]
        then
            if  [ "${UPDATE_REGISTRY}" == "TRUE" ];
            then
                echo "Updating image registry prefix to ${registry}"
                update_registry_prefix_in_csv "${CSV_VERSION}" "${namespace}"
                RC=$?
                if [ $RC -eq 0 ];
                then
                    UPDATE_REGISTRY=FALSE
                fi
            else
                STATUS="X$($kubernetesCLI get csv ${CSV_VERSION} -n ${namespace} -o template --template '{{.status.phase}}')"
                RC=$(echo $?)
            fi
        fi
        # Check the CSV state
        if [ "$STATUS" == "XSucceeded" ]
        then
            echo "Operator has been installed"
            LOOP="FALSE"
        else
            echo "Waiting for Successful State"
        fi
    done  
}

update_registry_prefix_in_csv() {
    local csv_version=$1
    local namespace=$2
    DB2U_OPERATOR_IMAGE=$(kubectl get csv ${csv_version} -n ${namespace} \
        -o jsonpath='{.spec.install.spec.deployments[0].spec.template.spec.containers[0].image}')
    DAY2_OPERATOR_IMAGE=$(kubectl get csv ${csv_version} -n ${namespace} \
        -o jsonpath='{.spec.install.spec.deployments[1].spec.template.spec.containers[0].image}')

    if [[ -z "${operator_image_namespace}" ]]; then
        DB2U_OPERATOR_IMAGE_PATH=$(echo "${DB2U_OPERATOR_IMAGE}" | awk -F/ '{OFS="/"; $1=""; sub(/^\/+/,""); print}')
        DAY2_OPERATOR_IMAGE_PATH=$(echo "${DAY2_OPERATOR_IMAGE}" | awk -F/ '{OFS="/"; $1=""; sub(/^\/+/,""); print}')
        registry_prefix=${registry}
    else
        DB2U_OPERATOR_IMAGE_PATH="${DB2U_OPERATOR_IMAGE##*/}"
        DAY2_OPERATOR_IMAGE_PATH="${DAY2_OPERATOR_IMAGE##*/}"
        registry_prefix="${registry}/${operator_image_namespace}"
    fi

    NEW_DB2U_OPERATOR_IMAGE="${registry_prefix}/${DB2U_OPERATOR_IMAGE_PATH}"
    NEW_DAY2_OPERATOR_IMAGE="${registry_prefix}/${DAY2_OPERATOR_IMAGE_PATH}"

    # Extract args array
    ARGS=($(kubectl get csv "${csv_version}" -n "${namespace}" -o jsonpath='{.spec.install.spec.deployments[0].spec.template.spec.containers[0].args[*]}'))
    # Find the indexes of arguments
    local registry_index=-1
    local namespace_index=-1

    for i in "${!ARGS[@]}"; do
        case "${ARGS[$i]}" in
            --operand-image-registry=*)
                registry_index=$i
                ;;
            --operand-image-namespace=*)
                namespace_index=$i
                ;;
        esac
    done

    # Build the JSON patch
    patches=()
    patches+=("{\"op\":\"replace\",\"path\":\"/spec/install/spec/deployments/0/spec/template/spec/containers/0/image\",\"value\":\"${NEW_DB2U_OPERATOR_IMAGE}\"}")
    patches+=("{\"op\":\"replace\",\"path\":\"/spec/install/spec/deployments/1/spec/template/spec/containers/0/image\",\"value\":\"${NEW_DAY2_OPERATOR_IMAGE}\"}")

    if [[ ${registry_index} -ge 0 ]]; then
        patches+=("{\"op\":\"replace\",\"path\":\"/spec/install/spec/deployments/0/spec/template/spec/containers/0/args/${registry_index}\",\"value\":\"--operand-image-registry=${registry}\"}")
    fi

    if [[ ${namespace_index} -ge 0 ]]; then
        patches+=("{\"op\":\"replace\",\"path\":\"/spec/install/spec/deployments/0/spec/template/spec/containers/0/args/${namespace_index}\",\"value\":\"--operand-image-namespace=${operator_image_namespace}\"}")
    fi

    # Join patches
    patch_json="[$(IFS=,; echo "${patches[*]}")]"
    # Apply patch
    kubectl patch csv "${csv_version}" -n "${namespace}" --type='json' -p="${patch_json}"
    return $?
}

## Creates the catalog source
install_catalog() {
    ## Locate the Install dir
    BUNDLE_CSV="${casePath}/inventory/${inventory}/files/deploy/install"
    CS="${BUNDLE_CSV}/${CATALOG_SOURCE}"

    recursive_action=0
    validate_install_catalog "install"

    perl -i -pe "s/namespace:[[:blank:]]${MARKETPLACE}/namespace: ${namespace}/g" ${CS}

    ## Update registry prefix
    if [[ -n "${registry}" ]]; then
        echo "Updating registry prefix to '${registry}'..."
        perl -i -pe "s|(image:[[:blank:]])icr\.io|\${1}${registry}|g" "${CS}"

        ## If operator image namespace is also provided, update it
        if [[ -n "${operator_image_namespace}" ]]; then
            echo "Updating operator image namespace to '${operator_image_namespace}'..."
            perl -i -pe "s|(image:[[:blank:]]${registry}/)(?:[^/]+/)?|\${1}${operator_image_namespace}/|g" "${CS}"
        fi
    fi
    ## Create the Catalog Source
    cat ${CS}
    $kubernetesCLI apply -f ${CS} -n ${namespace}

    ## Revert Namespace
    perl -i -pe "s/namespace:[[:blank:]]${namespace}/namespace: ${MARKETPLACE}/g" ${CS}

    ## Check that the Catalog Source is Up & Running
    condition="READY"

    ## Get Catalog Name
    CATALOG=$(cat ${CS} | grep "name:" | cut -d ":" -f 2 | tr -d [:space:])
    echo ${CATALOG}

    retries=100 # Number of times to retry and wait time period between tries for CR status to be 'Started'
    while [[ "X$($kubernetesCLI get -o jsonpath='{.status.connectionState.lastObservedState}{"\n"}' --namespace="${namespace}" catalogsource ${CATALOG})" != "X${condition}" ]]; do
	$kubernetesCLI get -o jsonpath='{.status}{"\n"}' --namespace="${namespace}" catalogsource ${CATALOG}
  	[[ $retries -eq "0" ]] && { printf "***** CatalogSource %s did not become ready in time *****" ; exit 3 ; }
  	retries=$((retries - 1))
  	sleep 15
    done
}

# Install utilizing default OLM method
install_operator() {

    # Reset Recursive Argument. Operator could be recursively installed
    recursive_action=0

    # Validate the arguments
    validate_install_args "install"

    # Create the Operator Group
    install_operator_group

    # Create the subscription
    create_subscription
}

## Redirect to OLM - the only currently supported method
install_operator_native() {
    install_operator
}

## Test only Artifact
apply_custom_resources() {
    echo ${NOT_IMPLEMENTED}
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo ${NOT_IMPLEMENTED}
}

uninstall_dependent_operators() {
    echo ${NOT_IMPLEMENTED}
}

# deletes the catalog source and operator group
uninstall_catalog() {
    ## Locate the Install dir
    BUNDLE_CSV="${casePath}/inventory/${inventory}/files/deploy/install"
    CS="${BUNDLE_CSV}/${CATALOG_SOURCE}"

    validate_install_catalog "uninstall"

    CS_NAME=$(cat ${CS} | grep "name:.*catalog" | cut -d ":" -f 2 | tr -d [:space:])

    obj=$($kubernetesCLI get ${CATALOG_KIND} -n ${namespace} -o name | grep ${CS_NAME})
    ## Only remove the CatalogSource if one exists already
    if [ -n "$obj" ]
    then
        ## Delete the Catalog Source
        $kubernetesCLI delete ${CATALOG_KIND} ${CS_NAME} -n ${namespace}
    else
        echo "CatalogSource does not exist! Skipping"
    fi
}

## Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    ## Locate the CSV
    BUNDLE_CSV="${casePath}/inventory/${inventory}/files/deploy/install"

    ## Get the Subscription
    SUBSCRIPTION_FILE=${BUNDLE_CSV}/${SUBSCRIPTION}

    SUB=$(cat ${SUBSCRIPTION_FILE} | grep -E "name:.*subscription" | cut -d ":" -f 2 | tr -d [:space:])
    obj=$($kubernetesCLI get ${SUBSCRIPTION_KIND} -n ${namespace} -o name | grep ${SUB})
    ## Delete the Subscription
    ## Only remove the Subscription if one exists already
    if [ -n "$obj" ]
    then
        ## Delete the Catalog Source
        $kubernetesCLI delete ${SUBSCRIPTION_KIND} ${SUB} -n ${namespace}
    else
        echo "Subscription does not exist! Skipping"
    fi

    ## Extract properties
    OP_NAME=$(cat ${SUBSCRIPTION_FILE} | grep "startingCSV" | cut -d ":" -f 2 |  cut -d "." -f 1 | tr -d [:space:])

    CSV_NAME=$($kubernetesCLI get csv -n ${namespace} -o jsonpath='{.items[*].metadata.name}' | tr ' ' '\n' | grep ${OP_NAME} | head -1)
    if [ -n "$CSV_NAME" ]
    then
        ## Delete the CSV
        oc delete csv ${CSV_NAME} -n ${namespace}
    else
        echo "CSV does not exist! Skipping"
    fi
}

## Redirect to OLM - the only currently supported method
uninstall_operator_native() {
    uninstall_operator
}

## Test only Artifact
delete_custom_resources() {
    echo ${NOT_IMPLEMENTED}
}
