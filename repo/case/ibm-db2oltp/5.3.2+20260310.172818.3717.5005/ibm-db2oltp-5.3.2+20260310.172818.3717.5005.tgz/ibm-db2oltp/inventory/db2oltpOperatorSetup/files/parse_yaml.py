#!/usr/bin/env python
import os
import sys
import argparse
import yaml

class YamlWriter:
    def update_yaml_with_value (self, dir_path, filename, tag, old_value, new_value, is_col):
        yaml_file = ''

        try:
            ## Locate the yaml
            for dirpath, dirnames, filenames in os.walk(dir_path, topdown=False):
                for f in filenames:
                    if filename in f:
                        yaml_file = os.path.join(dirpath, f)
                        break
                if yaml_file != '':
                    break

            with open (yaml_file) as file:
                values = yaml.safe_load(file)
            
            if len(tag) == 2:

                if is_col:
                    if not old_value:
                        values[tag[0]][tag[1]] = [ new_value ]
                    else:
                        values[tag[0]][tag[1]] = [ values[tag[0]][tag[1]][0].replace(old_value, new_value) ]
                else:
                    if not old_value:
                        values[tag[0]][tag[1]] = new_value
                    else:
                        values[tag[0]][tag[1]] = values[tag[0]][tag[1]].replace(old_value, new_value)
            else:
                print ('Unsupported number of arguments')
                raise

            with open(yaml_file, "w") as f:
                f.write(yaml.dump(values, indent=1, default_flow_style=False))

            return yaml_file

        except RuntimeError as err:
            print (err)
            print ('Error when processing file', yaml_file)
            print ('Required python libraries: sys, argparse, yaml')
            raise

        print ('file', yaml_file, 'does not contain the image', 'image')
        raise

    def update_subscription(self, dir_path, filename, key, value):

        yaml_file = ''

        try:
            ## Locate the CSV
            for dirpath, dirnames, filenames in os.walk(dir_path, topdown=False):
                for f in filenames:
                    if filename in f:
                        yaml_file = os.path.join(dirpath, f)
                        break
                if yaml_file != '':
                    break

            with open (yaml_file) as file:
                values = yaml.safe_load(file)

            values['spec'][key] = value
            with open(yaml_file, "w") as f:
                f.write(yaml.dump(values, indent=1, default_flow_style=False))

        except RuntimeError as err:
            print (err)
            print ('Error when processing file', yaml_file)
            print ('Required python libraries: sys, argparse, yaml')
            raise
    
    ## Function to clean up resources.yaml
    def cleanResYaml(self, temp_dir, yaml_file):
        values = {}
        yaml_file = temp_dir + yaml_file
        with open (yaml_file) as file:
            values = yaml.load(file, Loader=yaml.FullLoader)
        if "containerImages" in values['resources']['resourceDefs']:
            values['resources']['resourceDefs']['containerImages'] = []
            print ('Deleting old images from: ', yaml_file)
            with open(yaml_file, "w") as f:
                f.write(yaml.dump(values, indent=1, default_flow_style=False))
        else:
            print ('Unexpected Error: missing containerImages from: ', yaml_file)
            raise

class YamlReader:
    def get_digest_fat_manifest(self, yaml_file, image):
        try:
            with open (yaml_file) as file:
                values = yaml.safe_load(file)

            images = values['resources']['resourceDefs']['containerImages']
            for i in images:
                # Substring check - Relies on naming consistency
                if image in i['image']:
                    return i['digest']
        except:
            print ('Error when processing file', yaml_file)
            print ('Required python libraries: sys, argparse, yaml')
            raise

        print ('file', yaml_file, 'does not contain the image', 'image')
        raise

    def get_image_tag(self, yaml_file, image):
        try:
            with open (yaml_file) as file:
                values = yaml.safe_load(file)

            images = values['resources']['resourceDefs']['containerImages']
            for i in images:
                # Substring check - Relies on naming consistency
                if image in i['image']:
                    return i['tag']
        except:
            print ('Error when processing file', yaml_file)
            print ('Required python libraries: sys, argparse, yaml')
            raise

        print ('file', yaml_file, 'does not contain the image', 'image')
        raise

    def get_value_from_value_and_filename(self, yaml_file, tag, value):
        try:
          
            with open (yaml_file) as file:
                values = yaml.safe_load(file)

            for i in range (0, len(tag)-1):
                values = values[tag[i]]

            for i in values:
                if value in i[tag[len(tag)-1]]:
                    l = i[tag[len(tag)-1]].split("/")
                    return l[len(l) - 1]
        except:
            print ('Error when processing file', yaml_file)
            print ('Required python libraries: sys, argparse, yaml')
            raise

        print ('file', yaml_file, 'does not contain the specified tag', tag, 'or the value', value)
        raise

    def find_file_and_get_value(self, dir_path, filename, tag):

        yaml_file = ''

        try:
            ## Locate the CSV
            for dirpath, dirnames, filenames in os.walk(dir_path, topdown=False):
                for f in filenames:
                    if filename in f:
                        yaml_file = os.path.join(dirpath, f)
                        break
                if yaml_file != '':
                    break

            with open (yaml_file) as file:
                values = yaml.safe_load(file)

            for t in tag:
                values = values[t]

            return values

        except RuntimeError as err:
            print (err)
            print ('Error when processing file', yaml_file)
            print ('Required python libraries: sys, argparse, yaml')
            raise

        print ('file', yaml_file, 'does not contain the image', 'image')
        raise

if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    # Commands: update, resources, digest, yaml
    parser.add_argument("-y", "--yaml", nargs='?', const=1, type=int)
    parser.add_argument("-g", "--digest", nargs='?', const=1, type=int)
    parser.add_argument("-e", "--image-tag", nargs='?', const=1, type=int)
    parser.add_argument("-u", "--update", nargs='?', const=1, type=int)
    parser.add_argument("-s", "--update-sub", nargs='?', const=1, type=int)
    parser.add_argument("-x", "--delete-images", nargs='?', const=1, type=int)

    # Options
    parser.add_argument("-c", "--collection", nargs='?', const=1, default=False, type=bool)
    parser.add_argument("-f", "--filename", default=None, help="", type=str)
    parser.add_argument("-i", "--image", default=None, help="", type=str)
    parser.add_argument("-t", "--tag", nargs='+', help="")
    parser.add_argument("-k", "--key", default=None, help="", type=str)
    parser.add_argument("-v", "--value", default=None, help="", type=str)
    parser.add_argument("-d", "--dir", default=None, help="", type=str)
    parser.add_argument("-n", "--new-value", default=None, help="", type=str)
    parser.add_argument("-o", "--old-value", default=None, help="", type=str)

    args = parser.parse_args()

    reader = YamlReader()
    writer = YamlWriter()

    ## Reader
    if args.digest:
        print (reader.get_digest_fat_manifest(args.filename, args.image))
    elif args.image_tag:
        print (reader.get_image_tag(args.filename, args.image))
    elif args.yaml and args.dir != None and args.filename:
        print (reader.find_file_and_get_value(args.dir, args.filename, args.tag))
    elif args.yaml and args.tag and args.value:
        print (reader.get_value_from_value_and_filename(args.filename, args.tag, args.value))
    ## Writer
    elif args.update:
        print(writer.update_yaml_with_value(args.dir, args.filename, args.tag, args.old_value, args.new_value, args.collection))
    elif args.update_sub:
        writer.update_subscription(args.dir, args.filename, args.key, args.value)
    elif args.delete_images:
        writer.cleanResYaml(args.dir, args.filename)
    ##
    ## Unsupported
    else:
        print ('Not a supported use-case')
