# ibm-cdc-access-server

IBM Data Replication 12.0 CDC Access Server CASE bundle.

Deploys the IBM CDC Access Server on Red Hat OpenShift via the `cdc-access-server` Helm chart.
