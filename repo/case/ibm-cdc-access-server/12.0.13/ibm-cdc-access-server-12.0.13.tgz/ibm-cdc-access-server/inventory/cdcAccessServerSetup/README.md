# cdcAccessServerSetup

Inventory item for deploying the IBM CDC Access Server via Helm.
