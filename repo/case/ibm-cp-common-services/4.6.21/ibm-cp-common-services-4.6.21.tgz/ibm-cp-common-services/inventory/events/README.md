# Name

IBM&reg; Events Operator

# Contents (adopters)
- [Introduction](#introduction)
- [Prerequisites](#prerequisites)
- [Resources Required](#resources-required)
- [Installing](#installing)
- [Configuration](#configuration)
- [Security Context Constraints (SCC) Requirements](#securitycontextconstraints-requirements)
- [Pod Security Policy Requirements](#PodSecurityPolicy-Requirements)
- [Details To Use](#details)
- [To uninstall](#to-install)

---

**Note:**
- This early access development driver is currently available for amd64 and s390x only

---

## Introduction

Kafka Service based on the open-source Apache Kafka project. The Events Operator takes advantage of the Open Source Strimzi Operator that is published under the Cloud Native Computing Foundation and extends it to provide increased capabilities and support.

https://strimzi.io/

## Prerequisites
### Install the IBM Cloud Pak foundational services

* See https://github.com/IBM/ibm-common-service-operator/blob/master/docs/install.md#install-ibm-common-services

### Add a global pull secret

This will be used to pull Docker images for the Events Operator pod, and the Kafka and ZooKeeper images.

Inside the `ibm-events-operator-bundle` repository run:

```shell
ARTIFACTORY_USERNAME=userid ARTIFACTORY_PASSWORD=password ./update-pull-secret.sh
```
Replace `userid` with your Artifactory userid (normally your IBM w3 id) and `password` with your Artifactory API key.

**Note:**
* Using a global pull secret is a temporary workaround because the IBM Events Operator isn't yet released.
* This step will not be necessary once the Events Operator is released as part of IBM Cloud Pak foundational services.
* This will cause OpenShift to roll the nodes in your cluster


### Add a mirror to the Artifactory Image repository

This will be used to mirror the IBM Cloud Pak foundational services image repository with the temporary Artifactory image repository.
Once applied wait for all your nodes to roll (`oc get nodes` should report all nodes as ready, if you see `SchedulingDisabled` then your nodes are not ready).

Inside the `ibm-events-operator-bundle` repository run:

```shell
oc apply -f catalog/ibm-events-operator-image-content-source-policy.yaml
```

**Note:**
* Using mirror is a temporary workaround because the IBM Events Operator isn't yet released.
* This step will not be necessary once the Events Operator is released as part of IBM Cloud Pak foundational services.
* This will cause OpenShift to roll the nodes in your cluster

### Update the Common Services registry

This will add the temporary development `CatalogSource` hosting the Events Operator to your OpenShift Operator catalog, and patch your Common Services `OperandRegistry` to add the temporary catalog to it.

Inside the `ibm-events-operator-bundle` repository run:

```shell
./install.sh
```

**Notes:**
* This step is a temporary workaround because the IBM Events Operator isn't yet in the Common Services registry.
* This step will not be necessary once the Events Operator is released as part of IBM Cloud Pak foundational services
* Don't run the install script more than once, as it will add the IBM Events Operator to the list of operators more than once.

---

## Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Kafka (per replica) |  At least 2Gi       |   At least 1000m         |    Usage dependent       |  1     |
| Zookeeper (per replica)  |  1  Gi   |     1000m        |    2 Gi       |     1  |
| Cluster Operator  |  1  Gi      |     1000m        |    N/A     |     1  |
| Entity Operator  |  1  Gi      |     1000m        |    N/A       |     1  |

---

## Limitations

* The operator can be deployed cluster or namespace scoped.  The Kafka operand is namespace scoped
* Supported on AMD64 (s390x coming soon)
* Only the Kafka, KafkaUser and KafkaTopic are supported

* For more information about IBM Cloud Pak foundational services, please see [IBM Common Service Knowledge Center](http://ibm.biz/cpcsdocs)

---

## Installing

* [IBM Common Service Knowledge Center](http://ibm.biz/cpcsdocs)

---

## Configuration

* [IBM Common Service Knowledge Center](http://ibm.biz/cpcsdocs)

---

## SecurityContextConstraints Requirements

By default, the ibm-events-operator uses the `restricted` Security Context Constraints (SCCs) that comes with the OpenShift Container Platform.

For more information about SCCs in OpenShift, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.5/authentication/managing-security-context-constraints.html).

If you want to apply a custom SCC, use the following sample. This sample provides a basic SCC for the operator.

### Sample Custom SCC
```
metadata:
  name: <YOUR_SCC>
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: RunAsAny
kind: SecurityContextConstraints
priority: 2
readOnlyRootFilesystem: false
requiredDropCapabilities:
  - KILL
  - MKNOD
  - SETUID
  - SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
groups:
  # entry to the array
  - system:serviceaccounts:<INSTALLATION_NAMESPACE>
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
```

1. Add the name of the target namespace you created earlier for your installation:
```
groups:
    - system:serviceaccounts:<INSTALLATION_NAMESPACE>
```
2. Provide a unique name for your SCC in the metadata section:
```
metadata:
  name: <YOUR_SCC>
```

---

## PodSecurityPolicy Requirements

* Red Hat OpenShift Container Platform (OCP) supports equivalent functionality using SecurityContextConstraints (SCC).

---

## Details

* For more information about IBM Cloud Pak foundational services, please see [IBM Common Service Knowledge Center](http://ibm.biz/cpcsdocs)

---

## To uninstall
### Delete your OperandRequest

```
oc delete operandrequest your-common-services-request
```

### Remove IBM Events Operator from the Common Services registry

Currently, to uninstall the IBM Events Operator, you have to manually remove it from the Common Services registry.

```shell
oc edit operandregistry common-service -n ibm-common-services
```

Find the IBM Events Operator in `.spec.operators`.

It should look like this:
```yaml
  - channel: stable
    name: ibm-events-operator
    namespace: ibm-common-services
    packageName: ibm-events-operator
    scope: public
    sourceName: opencloud-events-operators
    sourceNamespace: openshift-marketplace
```

Remove it, and then save the OperandRegistry.

### Remove the Catalog Source

Inside the `ibm-events-operator-bundle` repository run:

```
oc delete -f ./catalog/catalog-source.yaml
```

---