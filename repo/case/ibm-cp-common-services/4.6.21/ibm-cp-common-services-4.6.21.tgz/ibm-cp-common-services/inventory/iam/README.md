# IBM® Identity and Access Management (IAM)

# Introduction

## Summary

The `ibm-iam-operator` installs the IBM Cloud Pak foundational services Identity and Access Management (IAM) service.

**Important:** Do not install this operator directly. Install this operator only by using the IBM Cloud Pak foundational services. For more information about installing the IBM Cloud Pak foundational services, see [Installer documentation](http://ibm.biz/cpcs_opinstall) (https://www.ibm.com/support/knowledgecenter/SSHKN6/kc_welcome_cs.html).

If you are using the operator as part of an IBM Cloud Pak, see the documentation for that IBM Cloud Pak to learn more about how to install and use the operator service. For more information about IBM Cloud Paks, see [IBM Cloud Paks that use IBM Cloud Pak foundational services](http://ibm.biz/cpcs_cloudpaks).


## Features

* You can use the `ibm-iam-operator` to install the authentication and authorization services for the IBM Cloud Pak foundational services.

* With these services, you can configure security for IBM Cloud Pak foundational services, IBM Certified Containers (IBM products), or IBM Cloud Paks that are installed.

For more information about the available IBM Cloud Pak foundational services, see the [IBM Knowledge Center](http://ibm.biz/cpcsdocs).


# Details

## Prerequisites

Before you install this operator, you need to first install the operator dependencies and prerequisites:

- For the list of operator dependencies, see the IBM Knowledge Center [Dependencies of the IBM Cloud Pak foundational services](http://ibm.biz/cpcs_opdependencies).

- For the list of prerequisites for installing the operator, see the IBM Knowledge Center [Preparing to install foundational services](http://ibm.biz/cpcs_opinstprereq).


### Resources Required

* This document contains the details for the scheduling capacity (https://www.ibm.com/support/knowledgecenter/SSHKN6/installer/3.2.4/hardware_reqs.html).

Minimum scheduling capacity for a standard installation:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| **Total** |    16     | 32          | 20          |       |


## Installing

* To install the operator by using the IBM Cloud Pak foundational services, follow the installation and configuration instructions that are in the IBM Knowledge Center.

* If you are using the operator as part of an IBM Cloud Pak, see the documentation for that IBM Cloud Pak [IBM Cloud Paks that use IBM Cloud Pak foundational services](http://ibm.biz/cpcs_cloudpaks).

* If you are using the operator with an IBM Containerized Software, see the IBM Cloud Platform Common Services Knowledge Center [Installer documentation](http://ibm.biz/cpcs_opinstall).


## Configuration

* See the link provided in `Installing` section for configuration i.e. [IBM Cloud Pak foundational services documentation](http://ibm.biz/cpcsdocs).

## Storage

* All state is stored in the Kubernetes API server and persisted in MongoDB. This includes roles, policies, LDAP configurations, teams but no users or group.

## Limitations

* The documentation lists all the limitations for the IAM operator.

## SecurityContextConstraints Requirements

The IAM operator service runs under the OpenShift Container Platform security context constraints. IAM pods namely auth-idp, auth-pap and auth-pdp run under the privileged scc. All the other IAM pods run under restricted scc. All IAM pods describe their security contexts in their deployments and run with non root user.

## PodSecurityPolicy Requirements

The IAM operator does not define any specific pod security requirements.