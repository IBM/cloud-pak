# Operand Deployment Lifecycle Manager (ODLM)

# Introduction

Operand Deployment Lifecycle Manager is used to manage the lifecycle of a group of operands. Check the design document [here](./docs/design/operand-deployment-lifecycle-manager.md).

Operand Deployment Lifecycle Manager has three CRDs:

| Resource                 | Short Name | Description                                                                                |
|--------------------------|------------|--------------------------------------------------------------------------------------------|
| OperandRequest | opreq | It defines which operator/operand want to be installed in the cluster |
| OperandRegistry | opreg | It defines the OLM information, like channel and catalog source, for each operator|
| OperandConfig | opcon | It defines the parameters that should be used to install the operator's operand |
| OperandBindInfo | opbi | It identifies secrets and/or configmaps that should be shared with requests |

# Details

## Supported platforms

Red Hat OpenShift Container Platform 4.3 or newer installed on one of the following platforms:

   - Linux x86_64
   - Linux on Power (ppc64le)

## Prerequisites

### Resources Required

#### Minimum scheduling capacity

| Software                   | Memory (MB) | CPU (cores) | Disk (GB) | Nodes  |
| -------------------------- | ----------- | ----------- | --------- | ------ |
| Operand Deployment Lifecycle Manager | 200          | 0.2        | 1          | worker |
| **Total**                  | 200         | 0.2         | 1         |        |


## Storage

* No volume dependency.

## Limitations

* Deployment limits - can only deploy one instance in each cluster.

## Documentation

- [installation](./docs/install/install.md)
- [design](./docs/design/operand-deployment-lifecycle-manager.md)

## SecurityContextConstraints Requirements

The IBM Cloud Pak foundational services supports running with the OpenShift Container Platform 4.3 default restricted Security Context Constraints (SCCs) and IBM Cloud Pak Security Context Constraints (SCCs).

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.3/authentication/managing-security-context-constraints.html).

For more information about the IBM Cloud Pak Security Context Constraints, see [Managing Security Context Constraints](https://ibm.biz/cpkspec-scc).
