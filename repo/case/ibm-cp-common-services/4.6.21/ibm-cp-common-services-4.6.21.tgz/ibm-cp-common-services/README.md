# IBM® Cloud Pak foundational services


# updates

## Try enabling ibm-operator-catalog in 1Q2021
## Remove of metering operator in 1Q2021

# Introduction

## Summary

* IBM Cloud Pak foundational services is used to install the IBM Cloud Pak foundational services.

## Features

- IBM Cloud Pak foundational services is a bridge to connect CloudPaks and ODLM/IBM Cloud Pak foundational services, and it can be also installed in standalone mode.
- Operand Deployment Lifecycle Manager is used to manage the lifecycle of a group of operands.

# Details

## Supported platforms

Red Hat OpenShift Container Platform 4.3 or newer installed on one of the following platforms:

   - Linux x86_64
   - Linux on Power (ppc64le)

## Prerequisites

### Resources Required

#### Minimum scheduling capacity

| Software                   | Memory (MB) | CPU (cores) | Disk (GB) | Nodes  |
| -------------------------- | ----------- | ----------- | --------- | ------ |
| IBM Cloud Pak foundational services | 200          | 0.2        | 1          | worker |
| operand deployment lifecycle manager | 200          | 0.2        | 1          | worker |
| **Total**                  | 400         | 0.4         | 2         |        |

# Installing

For installation, see the [IBM Cloud Pak foundational services documentation](http://ibm.biz/cpcsdocs).

## Configuration

For configuration, see the [IBM Cloud Pak foundational services documentation](http://ibm.biz/cpcsdocs).

## Storage

* No volume dependency.

## Limitations

* Deployment limits - can only deploy one instance in each cluster.

## Documentation

* Refer to [operand-deployment-lifecycle-manager](https://github.com/IBM/operand-deployment-lifecycle-manager) for more information about operator.
* Refer to [IBM Cloud Pak foundational services documentation](http://ibm.biz/cpcsdocs) for installation and configuration.

## SecurityContextConstraints Requirements

[Audit Logging SCC Requirements](inventory/auditlogging/README.md#SecurityContextConstraints-Requirements)
[Catalog UI SCC Requirements](inventory/catalogui/README.md#SecurityContextConstraints-Requirements)
[Cert Manager SCC Requirements](inventory/certmanager/README.md#SecurityContextConstraints-Requirements)
[Common UI SCC Requirements](inventory/commonui/README.md#SecurityContextConstraints-Requirements)
[Health Check SCC Requirements](inventory/healthCheck/README.md#SecurityContextConstraints-Requirements)
[Helm API SCC Requirements](inventory/helmApi/README.md#SecurityContextConstraints-Requirements)
[Helm Repo SCC Requirements](inventory/helmRepo/README.md#SecurityContextConstraints-Requirements)
[IAM SCC Requirements](inventory/iam/README.md#SecurityContextConstraints-Requirements)
[IBM Cloud Pak foundational services SCC Requirements](inventory/ibmCommonServiceOperator/README.md#SecurityContextConstraints-Requirements)
[Licensing SCC Requirements](inventory/licensing/README.md#SecurityContextConstraints-Requirements)
[Management Ingress SCC Requirements](inventory/managementIngress/README.md#SecurityContextConstraints-Requirements)
[Megering SCC Requirements](inventory/metering/README.md#SecurityContextConstraints-Requirements)
[MongoDB SCC Requirements](inventory/mongodb/README.md#SecurityContextConstraints-Requirements)
[Monitoring SCC Requirements](inventory/monitoring/README.md#SecurityContextConstraints-Requirements)
[Operand Deployment Lifecycle Manager SCC Requirements](inventory/operandDeploymentLifecycleManager/README.md#SecurityContextConstraints-Requirements)
[Platfrom API SCC Requirements](inventory/platformApi/README.md#SecurityContextConstraints-Requirements)

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
default Openshift SCCs
```
