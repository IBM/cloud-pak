#!/bin/bash
# Copyright IBM Corp. 2020, 2026

CR_INDEX=0
echo "SZ_DEBUG $SZ_DEBUG"

# These for the operator based cloud deployment
# User can choose the Stepzen Graph Server CR.
# If no Stepzen Graph Server found will throw an error.
# Only one Stepzen Graph Server found will not show the options.
# More than one Stepzen Graph Server found the user will get a choice.
if [ -z "$SZA_PULL_SECRET_NAME" ] || [ -z "$SZA_MDB_SECRET_NAME" ]; then
  SZA_AVAILABLE_CRS=$(kubectl get StepZenGraphServer -o jsonpath='{.items[*].metadata.name}')
  #Hack to get array length. The SZA_AVAILABLE_CRS is space separated string the code will split the string into SZA_AVAILABLE_CRS_ARRAY
  IFS=' ' read -ra SZA_AVAILABLE_CRS_ARRAY <<<"$SZA_AVAILABLE_CRS"
  if [ ${#SZA_AVAILABLE_CRS_ARRAY[@]} -gt 1 ]; then
    echo "These are the Stepzen Graph Servers:"
    for ((i = 0; i < ${#SZA_AVAILABLE_CRS_ARRAY[@]}; i++)); do
      echo "$((i + 1)). ${SZA_AVAILABLE_CRS_ARRAY[i]}"
    done
    read -p "Enter your choice: " choice
    CR_INDEX=$(expr $choice - 1)
  elif [ ${#SZA_AVAILABLE_CRS_ARRAY[@]} -eq 1 ]; then
    CR_INDEX=0
  else
    echo "No Stepzen Graph Server found."
    exit 1
  fi
fi

# Default account
ACCOUNT_NAME=${2:-"graphql"}

# Assume operator-installed StepZenGraphServer by default
EXPRESSION_IPS="{.items[$CR_INDEX].spec.imagePullSecrets[0]}"
EXPRESSION_CDS="{.items[$CR_INDEX].spec.controlDatabaseSecret}"
SZA_PULL_SECRET_NAME=${SZA_PULL_SECRET_NAME:-$(kubectl get StepZenGraphServer -o jsonpath="$EXPRESSION_IPS")}
SZA_MDB_SECRET_NAME=${SZA_MDB_SECRET_NAME:-$(kubectl get StepZenGraphServer -o jsonpath="$EXPRESSION_CDS")}
SZA_ZEN_URL_BASE=${SZA_ZEN_URL_BASE:-"http://stepzen-graph-server.$(kubectl config view --minify -o jsonpath='{..namespace}').svc"}

# TODO: update to version tag on release
SZA_IMAGE=${SZA_IMAGE:-"cp.icr.io/cp/stepzen/stepzen-admin-jobs@sha256:50cd850457ecd2f93793833c8c13d0c885ad831478f64f29211b5b4f745dee08"}

# Generate a random string of 6 alphanumeric characters
RANDOM_FRAGMENT=$((RANDOM % 10000))
APP_NAME="stepzen-admin-jobs-$RANDOM_FRAGMENT"
SPINNER="/|\\-"
DELAY=0.1
ZENCTL_URL=$SZA_ZEN_URL_BASE/api/zenctl/graphql

# Convert a raw string into a JSON string and surround with double quotes.
function to_json_string() {
  JS_S=$1
  JS_S=${JS_S//\\/\\\\}
  JS_S=${JS_S//\"/\\\"}
  JS_S=${JS_S//
/\\\n}
  JS_S=${JS_S//	/\\\t}
  JS_S=${JS_S//^M/\\\r}
  JS_S=${JS_S//^L/\\\f}
  JS_S=${JS_S//^H/\\\b}
  echo "\"$JS_S\""
}

# Converts each argument to a JSON string and returns a list of them
function to_json_string_list() {
  JS_L="["
  for e in "$@"; do
    if [ "$JS_L" != "[" ]; then
      JS_L="$JS_L,"
    fi
    JS_L=$JS_L$(to_json_string "$e")
  done
  JS_L="$JS_L]"
  echo $JS_L
}

function format_and_print_command() {
  screen_width=$(tput cols)
  plus_signs=$(printf '+%.0s' $(seq 1 $screen_width))

  echo "+ $1"
  echo "$plus_signs"
  eval $1
  echo "$plus_signs"

}

# Run the specified commands with the desired format
function printAllLogs() {
  lines="10000" # Change this to the desired number of lines

  format_and_print_command "kubectl get StepZenGraphServer -o yaml"
  format_and_print_command "kubectl get stepzen-introspection -o yaml"

  pod_list=$(kubectl get pods --no-headers -o custom-columns=":metadata.name")

  for pod in $pod_list; do
    format_and_print_command "kubectl logs $pod --tail $lines"
  done

  format_and_print_command "kubectl get CustomResourceDefinition stepzengraphservers.stepzen-graph.ibm.com -o yaml"

  format_and_print_command "kubectl get ingress"
  format_and_print_command "kubectl get route"
}

if [ -z "$SZA_ARGS" ]; then
  if [ "$1" == "add-account" ]; then
    SZA_ARGS=$(to_json_string_list "-add-account=$ACCOUNT_NAME" "-zenctl=$ZENCTL_URL")
  elif [ "$1" == "remove-account" ]; then
    if [ -z "$2" ]; then
      echo "Please provide an <account-name> parameter."
      exit 1
    fi
    SZA_ARGS=$(to_json_string_list "-remove-account=$ACCOUNT_NAME" "-zenctl=$ZENCTL_URL")
  elif [ "$1" == "get-adminkey" ]; then
    SZA_ARGS=$(to_json_string_list "--get-adminkey=$ACCOUNT_NAME")
  elif [ "$1" == "get-apikey" ]; then
    SZA_ARGS=$(to_json_string_list "--get-apikey=$ACCOUNT_NAME")
  elif [ "$1" == "generate-apikey" ]; then
    SZA_ARGS=$(to_json_string_list "--generate-apikey=$ACCOUNT_NAME" "-zenctl=$ZENCTL_URL")
  elif [ "$1" == "generate-adminkey" ]; then
    SZA_ARGS=$(to_json_string_list "--generate-adminkey=$ACCOUNT_NAME" "-zenctl=$ZENCTL_URL")
  elif [ "$1" == "get-logs" ]; then
    printAllLogs
    exit 0
  elif [ "$1" == "remove-key" ]; then
    if [ -z "$2" ]; then
      echo "Please provide an <account-name> parameter."
      exit 1
    fi
    if [ -z "$3" ]; then
      echo "Please provide the key value to be removed."
      exit 1
    fi
    SZA_ARGS=$(to_json_string_list "-remove-key-account=$2" "-remove-key-value=$3" "-zenctl=$ZENCTL_URL")
  elif [ "$1" == "request" ]; then
    if [ -z "$2" ]; then
      echo "Please provide an <account-name> parameter."
      exit 1
    fi
    if [ -z "$3" ]; then
      echo "Please provide a GraphQL request (e.g. 'query { version { version_tag } }') to be executed."
      exit 1
    fi
    SZA_ARGS=$(to_json_string_list "-request-account=$2" "-request-value=$3" "-zenctl=$ZENCTL_URL")
  elif [ "$1" == "deploy" ]; then
    if [ -z "$2" ]; then
      echo "Please provide an <account-name> parameter and <workspace-dir> containing a stepzen workspace."
      exit 1
    fi
    if [ -z "$3" ]; then
      echo "Please provide a local directory containing a stepzen workspace."
      exit 1
    fi
    SZA_ARGS=$(to_json_string_list "-stepzen-cli-login=$2" "-zenctl=$ZENCTL_URL")
  else
    echo "Usage: $0 add-account|remove-account|get-apikey|get-adminkey|generate-apikey|generate-adminkey <account-name>"
    echo "       $0 remove-key <account-name> <key>"
    echo "       $0 get-logs"
    echo "       $0 request <account-name> <graphql>"
    echo "       $0 deploy <account-name> <workspace-dir>"
    exit 1
  fi
fi

if [ -z "$SZA_CONTAINER_ENV" ]; then
  SZA_CONTAINER_ENV="[{
        \"name\": \"STEPZEN_CONTROL_DB_DSN\",
        \"valueFrom\": {
          \"secretKeyRef\": {
            \"name\": \"$SZA_MDB_SECRET_NAME\",
            \"key\": \"DSN\"
          }
        }
      }]"
fi

# Function to display the loading animation
function loading_animation() {
  local i=0
  while true; do
    printf "\r[%c] Waiting for pod to complete... " "${SPINNER:$i:1}"
    sleep "$DELAY"
    i=$(((i + 1) % 4))
  done
}

# Start the loading animation in the background
{ loading_animation & } 2>/dev/null
trap 'kill $!; exit' INT

kubectl get secret "$SZA_PULL_SECRET_NAME" 1>/dev/null || {
  echo "no access to secrets with name $SZA_PULL_SECRET_NAME - did you run kubectl login?" >&2
  # Kill loading animation
  kill %1
  exit 1
}

if [ "$1" != "initialize" ]; then
  kubectl get secret "$SZA_MDB_SECRET_NAME" 1>/dev/null || {
      echo "no access to secrets with name $SZA_MDB_SECRET_NAME - did you run kubectl login?" >&2
      # Kill loading animation
      kill %1
      exit 1
  }
fi

function cleanup_and_exit() {
  # Kill loading animation
  { kill $! && wait; } 2>/dev/null
  echo

  exit_code=$1
  pod_name=$(kubectl get pod -l job-name=$APP_NAME -o jsonpath="{.items[?(@)].metadata.name}" 2>/dev/null)

  if [[ $exit_code -ne 0 ]]; then
    if [[ -z "$SZ_DEBUG" ]]; then
        echo "The job has failed; run with SZ_DEBUG=1 for detailed logs."
    else
        echo "The job has failed; displaying all DEBUG logs."
    fi
  fi

  if [[ "$SZ_DEBUG" == "1" ]]; then
    # Dump all logs
    echo $(kubectl logs "$pod_name")
  else
    # Elide DEBUG: lines
    (kubectl logs "$pod_name" | grep -v "^DEBUG:") || true
  fi

  # Delete existing pod
  kubectl delete job "$APP_NAME" >/dev/null

  exit $exit_code
}

OVERRIDES='{
  "apiVersion": "batch/v1",
  "kind": "Job",
  "metadata": {
    "name": "'"$APP_NAME"'"
  },
  "spec": {
    "completions": 1,
    "template": {
      "metadata": {
        "name": "'"$APP_NAME"'"
      },
      "spec": {
        "containers": [{
          "name": "'"$APP_NAME"'",
          "image": "'"$SZA_IMAGE"'",
          "args": '"$SZA_ARGS"',
          "env": '"$SZA_CONTAINER_ENV"'
        }],
        "imagePullSecrets": [{"name": "'"$SZA_PULL_SECRET_NAME"'"}],
        "restartPolicy": "Never"
      }
    },
    "ttlSecondsAfterFinished": 100
  }
}'

# Create a Pod
echo "$OVERRIDES" | kubectl apply -f - >/dev/null


# For deploy, copy files and run stepzen deploy when pod is up and running
if [[ "$1" == "deploy" ]]; then
  count=1
  while [[ "$phase" != "Running" ]]; do
    if [[ "$count" -gt 10 ]]; then
      echo "Error waiting for pod to start"
      cleanup_and_exit 1
    fi
    sleep 5
    count=$((count + 1))
    pod_name=$(kubectl get pod -l job-name=$APP_NAME -o jsonpath="{.items[?(@)].metadata.name}" 2>/dev/null)
    phase=$(kubectl get pod $pod_name -o jsonpath="{.status.phase}" 2>/dev/null)
  done
  workdir="$3"
  workdir_name=$(basename "$3")
  # basic sanity check
  if [[ ! -f "$workdir/stepzen.config.json" ]]; then
    echo "Expected $workdir to be a StepZen workspace"
    cleanup_and_exit 1
  fi

  # copy workspace and deploy
  if ! kubectl cp "$workdir" "$pod_name:/tmp/workspaces/$workdir_name"; then
    cleanup_and_exit 1
  fi
  if ! kubectl exec "$pod_name" -- stepzen deploy --non-interactive --silent --dir "/tmp/workspaces/$workdir_name"; then
    echo "Error while deploying schema"
    cleanup_and_exit 1
  fi
  # Terminate the pod gracefully
  kubectl exec "$pod_name" -- bash -c 'kill -HUP $(cat /tmp/adminjobs.pid)' >/dev/null 2>&1
fi

# Loop until the container is in "Completed" state or Error
count=1
while true; do
  pod_name=$(kubectl get pod -l job-name=$APP_NAME -o jsonpath="{.items[?(@)].metadata.name}" 2>/dev/null)
  status=$(kubectl get pod $pod_name -o jsonpath="{.status.containerStatuses[?(@.name)].state.terminated.reason}" 2>/dev/null)
  if [[ "$status" == "Completed" ]]; then
    cleanup_and_exit 0
  elif [[ "$status" == "Error" || "$count" -gt 10 ]]; then
    cleanup_and_exit 1
  else
    count=$((count + 1))
    sleep 5
  fi
done
