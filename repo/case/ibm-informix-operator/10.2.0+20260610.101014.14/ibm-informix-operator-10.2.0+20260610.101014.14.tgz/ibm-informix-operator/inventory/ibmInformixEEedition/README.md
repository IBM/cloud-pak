# ibmInformixEEedition
Informix Installer for the Enterprise Edition