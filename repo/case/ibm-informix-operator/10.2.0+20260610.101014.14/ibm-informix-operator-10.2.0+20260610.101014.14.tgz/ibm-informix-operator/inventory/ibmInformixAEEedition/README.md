# ibmInformixAEEedition
Informix Installer for the Advanced Enterprise Edition