# ibmInformixWEedition
Informix Installer for the Workgroup Edition