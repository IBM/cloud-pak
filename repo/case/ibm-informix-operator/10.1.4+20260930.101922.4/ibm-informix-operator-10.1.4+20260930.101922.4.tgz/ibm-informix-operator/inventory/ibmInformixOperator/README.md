# ibmInformixOperator
Informix Operator images