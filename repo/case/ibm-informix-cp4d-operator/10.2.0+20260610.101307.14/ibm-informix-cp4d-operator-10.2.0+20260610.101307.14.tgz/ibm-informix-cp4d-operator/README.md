# Name

IBM® Informix Operator Extension for IBM Cloud Pak for Data.

This operator is used to enable Informix in Cloud Pak for Data instances and create Informix clusters.

This operator requires the presence of Cloud Pak for Data in the same namespace, as well as the install of the Informix operator, also available in the IBM Catalog.

# Introduction

## Summary

IBM® Informix is a secure embeddable database, optimized for OLTP and Internet of Things (IoT) data. Informix has the unique ability to seamlessly integrate SQL, NoSQL/JSON, time series and spatial data. Its versatility and ease of use make Informix a preferred solution for a wide range of environments, from enterprise data warehouses to individual application development

Refer to the [IBM Informix Material](https://www.ibm.com/analytics/informix) for more information.

## Features

The IBM® Informix CP4D Operator allows to install the IBM Informix Cloud Pak for Data service

* [Knowledge Center](https://ibm.biz/BdfY4V)
* [Software-defined certified storage for Informix](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/svc-welcome/ifx.html)
* Includes REST & Mongo cabability
* IBM® Informix version 14.10   

## Documentation

See the [Informix Knowledge Center](https://ibm.biz/BdfY4V)

## License

By installing this product you accept the [license terms](https://ibm.biz/BdfGBZ)

# Details

## Prerequisites

### SecurityContextConstraints Requirements

This operator uses the default "restricted" SCC

Custom SecurityContextConstraints definition:
```
```

### Resources Required

### PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:
```
```

Minimum scheduling capacity:

#### IBM® Informix CP4D Operator

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Operator  | 300Mi     |    300m     |           |   1   |

More information about the different licenses and consideration for deployment have been documented in the [IBM Knowledge Center](https://ibm.biz/BdfnEv)

## Limitations
- Limited console facility: enhanced console facility is expected to be in next release

# Installing the Informix Operator

These instructions are for installing Informix CP4D from the Red Hat Marketplace.

## To install the Informix CP4D operator from the Red Hat Marketplace

- You can find installation guidance in the [Informix install documentation](https://ibm.biz/BdfnEv)

## Configuration

* The Informix CP4D operator does not require any particular configuration

## License

## Storage
    
## Example of a InformixService Custom Resource

```
apiVersion: ifx.ibm.com/v1
kind: InformixService
metadata:
  name: informixcp4d
spec:
  license:
    accept: true
  db_type: informix        
```
