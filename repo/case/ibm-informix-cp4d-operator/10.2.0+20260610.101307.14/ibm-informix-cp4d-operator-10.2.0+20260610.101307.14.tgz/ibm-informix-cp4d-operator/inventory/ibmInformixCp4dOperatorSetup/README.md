# ibmInformixCp4dOperatorSetup

Custom PodSecurityPolicy definition:
```
qwe
```

### Custom SecurityContextConstraints definition:

This operator uses the default "restricted" SCC
```
qwe
```