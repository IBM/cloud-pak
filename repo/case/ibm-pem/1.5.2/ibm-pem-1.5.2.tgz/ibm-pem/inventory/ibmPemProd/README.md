# IBM Partner Engagement Manager
## Introduction

## Chart Details

This chart deploys IBM Parnter Engagement Manager Standard cluster on a container management platform with the following resources.


## Prerequisites

1. Kubernetes version >= 1.31 and <= 1.34

2. Red Hat OpenShift Container Platform version >= 4.18

3. Helm version >= 3.21.x

4. Ensure that one of the supported database server (Oracle/DB2) is installed and the database is accessible from inside the cluster.

5. Ensure that the docker images for IBM Partner Engagement Manager Standard from Entitlement registry are loaded to an appropriate docker registry.

6. When `volumeClaims.resources.enabled` is `true`, create a persistent volume for application resources with access mode as 'Read Only Many' and place the database driver jar , SEAS jars and MQ jars in the mapped volume location.

7. When `volumeClaims.logs.enableAppLogOnConsole` is `false`, create a persistent volume for application logs with access mode as 'Read Write Many'.

8. When `communitymanager.prod.archive.enabled` is `true`, create a persistent volume for archive document storage with access mode as 'Read Write Many'.

9. When `communitymanager.nonprod.archive.enabled` is `true`, create a persistent volume for archive document storage with access mode as 'Read Write Many'.

    Mount the archive persistent volume to b2bi server

9. Create secrets with requisite confidential credentials for passphrase.txt, Keystore.jks dbpasswords and keystore passwords. You can use the supplied configuration files under pak_extensions/pre-install/secret directory.


      Create a secret from the provided syntax file included in helm charts /ibm-cloudpak-extensons/preinstall/secrets.yaml

      oc apply -f secrets.yaml

10. Create a secret to pull the image from a private registry or repository using following command
    ```
    oc create secret docker-registry <name of secret> --docker-server=<your-registry-server> --docker-username=<your-username> --docker-password=<your-password> --docker-email=<your-email>
    ```

11. create secrets with confidential certificates (Keystore files) required by Database, MQ for SSL connectivity using below command
    ```
     oc create secret generic <secret-name> --from-file=/path/to/<Keystore.jks>

	```

12. When installing the chart on a new database which does not have IBM PEM standard Software schema tables and metadata,
* ensure that `dbsetup.type` parameter is set to `newinstall`. This will create the required database tables and metadata in the database before installing the chart.

13. When installing the chart on a database with new image upgrade
* ensure that `dbsetup.type` parameter is set to `upgrade`


## Resources Required

The following table describes the default usage and limits per pod

Pod                                       | Memory Requested  | Memory Limit | CPU Requested | CPU Limit
------------------------------------------| ------------------|--------------| --------------|----------
PEM Portal pod                            |       4 Gi        |     8 Gi     |      1        |    2
PP pod                                    |       2 Gi        |     4 Gi     |      1        |    2
PR pod                                    |       2 Gi        |     4 Gi     |      1        |    2
API Gateway pod                           |       2 Gi        |     4 Gi     |      1        |    2
PCM Prod pod                              |       2 Gi        |     4 Gi     |      1        |    2
PCM Non Prod pod                          |       2 Gi        |     4 Gi     |      1        |    2
Agent pod                                 |       2 Gi        |     4 Gi     |      1        |    2
Purge (API) pod                           |       0.5 Gi      |     1 Gi     |      0.1      |    0.5

## Installing the Chart

Prepare a custom values.yaml file based on the configuration section which will be present in chart_Directory/valus.yaml.

To install the chart with the release name `my-release`:
1. Ensure that the chart is downloaded locally and available.

2. Run the below command
```sh
$ helm install my-release -f values.yaml ./ibm-pem-standard --timeout 3600s  --namespace <namespace>
```

Depending on the capacity of the openshift worker node and database network connectivity, chart deployment can take on average
* 2-3 minutes for 'installation against a pre-loaded database' and
* 10-20 minutes for 'installation against a fresh new or older release upgrade'
## Upgrading the Chart

You would want to upgrade your deployment when you have a new docker image or helm chart verison or a change in configuration, for e.g. new service ports to be exposed.

1. Ensure that the chart is downloaded locally and available.

2. Before upgrading the release for any configurations change, set the `dataSetup.type` as `upgrade`

3. Run the following command to upgrade your deployments.

```sh
helm upgrade my-release -f values.yaml ./ibm-pem-standard --timeout 3600s
```

4. Run the following command to upgrade your deployments

```
helm upgrade my-release -f values.yaml ./ibm-pem-standard --timeout 3600s --recreate-pods
```
For product release version upgrade, please refer product documentation.


## Rollback the Chart
If the upgraded environment is not working as expected or you made an error while upgrading, you can easily rollback the chart to a previous revision.
Procedure
To rollback a chart with release name <my-release> to a previous revision invoke the following command:


```sh
helm rollback my-release <previous revision number>
```

To get the revision number execute the following command:

```sh
helm history my-release
```
Note : If the revision isn't specified then by default rolls back to the last revision.

## Uninstalling the Chart

To uninstall/delete the `my-release` deployment run the command:


```sh
 helm delete my-release  --purge
```
Since there are certain kubernetes resources created using the `pre-install` hook, helm delete command will try to delete them as a post delete activity. In case it fails to do so, you need to manually delete the following resources created by the chart:
* ConfigMap - <release name>-Migrator-Setupfile
* ConfigMap - <release name>-Dbutils-Setupfile
* PersistentVolumeClaim if persistence is enabled - <release name>-resources-pvc  only if resources pv are enabled
* PersistentVolumeClaim if persistence is enabled - <release name>-logs-pvc #enable logs for migrator and dbutils

Note: You may also consider deleting the secrets and peristent volumes created as part of prerequisites, after creating their backups.
