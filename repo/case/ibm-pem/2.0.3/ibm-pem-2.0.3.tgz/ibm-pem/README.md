# Name
IBM Partner Engagement Manager Essential on REDHAT OpenShift Container platform

# Introduction



# Details

This CASE contains two inventory items:

ibmpem - a helm chart for installing IBM Partner Engagement Manager Essential

## Prerequisites

### PodSecurityPolicy Requirements

This chart requires a PodSecurityPolicy to be bound to the target namespace prior to installation.  Choose either a predefined PodSecurityPolicy or have your cluster administrator create a custom PodSecurityPolicy for you:
* Predefined PodSecurityPolicy name: [`ibm-anyuid-psp`](https://ibm.biz/cpkspec-psp)

This chart optionally defines a custom PodSecurityPolicy which is used to finely control the permissions/capabilities needed to deploy this chart. It is based on the predefined PodSecurityPolicy name: [`ibm-restricted-psp`](https://github.com/IBM/cloud-pak/blob/master/spec/security/psp/ibm-anyuid-psp.yaml) with extra required privileges. You can enable this policy by using the Platform User Interface or configuration file available under pak_extensions/pre-install/ directory
- From the user interface, you can copy and paste the following snippets to enable the custom PodSecurityPolicy
Note: For kubernetes version 1.32 or higher apiVersion for the PodSecurityPolicy should be policy/v1
  - Custom PodSecurityPolicy definition:

    ```
    apiVersion: policy/v1beta1
    kind: PodSecurityPolicy
    metadata:
      name: "ibm-pem-psp"
      labels:
        app: "ibm-pem-psp"

    spec:
      privileged: false
      allowPrivilegeEscalation: false
      hostPID: false
      hostIPC: false
      hostNetwork: false
      allowedCapabilities:
      requiredDropCapabilities:
      - MKNOD
      - AUDIT_WRITE
      - KILL
      - NET_BIND_SERVICE
      - NET_RAW
      - FOWNER
      - FSETID
      - SYS_CHROOT
      - SETFCAP
      - SETPCAP
      - CHOWN
      - SETGID
      - SETUID
      - DAC_OVERRIDE
      allowedHostPaths:
      runAsUser:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      runAsGroup:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      seLinux:
        rule: RunAsAny
      supplementalGroups:
        rule: MustRunAs
        ranges:
        - min: 1
          max: 4294967294
      fsGroup:
        rule: MustRunAs  
        ranges:
        - min: 1
          max: 4294967294
      volumes:
      - configMap
      - emptyDir
      - projected
      - secret
      - downwardAPI
      - persistentVolumeClaim
      - nfs
      forbiddenSysctls:
      - '*'
    ```

  - Custom ClusterRole for the custom PodSecurityPolicy:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: ClusterRole
    metadata:
      name: "ibm-pem-psp"
      labels:
        app: "ibm-pem-psp"
    rules:
    - apiGroups:
      - policy
      resourceNames:
      - "ibm-pem-psp"
      resources:
      - podsecuritypolicies
      verbs:
      - use
  - apiGroups:
      - ""
      resources:
      - secrets
      verbs:
      - get
      - list
      - patch
      - update
  - apiGroups:
      - apps
      resources:
      - deployments
      verbs:
      - get
      - list
      - patch
      - update
    ```
- Create a rolebinding for the above role and the service account:
    ```
    kind: RoleBinding
    apiVersion: rbac.authorization.k8s.io/v1
    metadata:
      name: <rolebinding name>
      namespace: <namespace>
    subjects:
      - kind: ServiceAccount
        name: <service account>
        namespace: <namespace>
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: ibm-pem-psp
    ```

### SecurityContextConstraints Requirements

* Predefined SecurityContextConstraints name: [`ibm-anyuid-scc`](https://ibm.biz/cpkspec-scc)

This chart optionally defines a custom SecurityContextConstraints (on Red Hat OpenShift Container Platform) which is used to finely control the permissions/capabilities needed to deploy this chart.  It is based on the predefined SecurityContextConstraint name: [`ibm-restricted-scc`](https://github.com/IBM/cloud-pak/blob/master/spec/security/scc/ibm-restricted-scc.yaml) with extra required privileges.

  - Custom SecurityContextConstraints definition:

    ```
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata:
      name: ibm-pem-scc
      labels:
       app: "ibm-pem-scc"
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    privileged: false
    allowPrivilegeEscalation: false
    allowPrivilegedContainer: false
    allowedCapabilities:
    allowedFlexVolumes: []
    allowedUnsafeSysctls: []
    defaultAddCapabilities: []
    defaultAllowPrivilegeEscalation: false
    forbiddenSysctls:
      - "*"
    fsGroup:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - MKNOD
    - AUDIT_WRITE
    - KILL
    - NET_BIND_SERVICE
    - NET_RAW
    - FOWNER
    - FSETID
    - SYS_CHROOT
    - SETFCAP
    - SETPCAP
    - CHOWN
    - SETGID
    - SETUID
    - DAC_OVERRIDE
    runAsUser:
      type: MustRunAsRange
    # This can be customized for your host machine
    seLinuxContext:
      type: RunAsAny
    # seLinuxOptions:
    #   level:
    #   user:
    #   role:
    #   type:
    supplementalGroups:
      type: MustRunAs
      ranges:
      - min: 1
        max: 4294967294
    # This can be customized for your host machine
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
    - nfs
    priority: 0
    ```
- Custom ClusterRole for the custom SecurityContextConstraints:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
	kind: ClusterRole
	metadata:
     name: "ibm-pem-scc"
     labels:
      app: "ibm-pem-scc"
	rules:
	- apiGroups:
  	  - security.openshift.io
  	  resourceNames:
      - "ibm-pem-scc"
      resources:
      - securitycontextconstraints
      verbs:
      - use
  - apiGroups:
      - ""
      resources:
      - secrets
      verbs:
      - get
      - list
      - patch
      - update
  - apiGroups:
      - apps
      resources:
      - deployments
      verbs:
      - get
      - list
      - patch
      - update
    ```
- Create a rolebinding for the above role and the service account:
    ```
    kind: RoleBinding
    apiVersion: rbac.authorization.k8s.io/v1
    metadata:
      name: <rolebinding name>
      namespace: <namespace>
    subjects:
      - kind: ServiceAccount
        name: <service account>
        namespace: <namespace>
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: Role
      name: ibm-pem-scc
    ```

## Resources Required

## Configuration
### The following table lists the configurable parameters for the chart


Pod                                       | Memory Requested  | Memory Limit | CPU Requested | CPU Limit
------------------------------------------| ------------------|--------------| --------------|----------
PEM Portal pod                            |       4 Gi        |     8 Gi     |      1        |    2
PP pod                                    |       2 Gi        |     4 Gi     |      1        |    2
PR pod                                    |       2 Gi        |     4 Gi     |      1        |    2
API Gateway pod                           |       2 Gi        |     4 Gi     |      1        |    2
Agent pod                                 |       2 Gi        |     4 Gi     |      1        |    2
Purge (API) pod                           |       0.5 Gi      |     1 Gi     |      0.1      |    0.5

# Installing the case

### Install Prequisites

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Setup Readme](./inventory/ibm-pem/README.md)

### Install CASE inventory items

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibm-pem/README.md)

### Uninstalling the CASE

See the following readme files for details of removing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibm-pem/README.md)

## Configuration

- [Chart Readme](./inventory/ibm-pem/README.md)

## Storage

To work with IBM Partner Enagagement Manager Essential Helm Charts 3 out of the box Persistent Volume Claims can be configured or enabled for resources, logs and documents.

* While the resources volume is not dynamic and needs to be pre-setup on shared file storage viz. NFS with the     
required database driver and other resources files, It is recommended to use a dynamic provisioner to  
create the logs and archive persistent volume.
* resources, logs and archive data volume should have the access mode set to ReadOnlyMany, ReadWriteMany and  ReadWriteMany respectively.  
* The Storage Class should have a Reclaim Policy of Retain.
* The persistent volume cannot be hostpath or empty dir.

### Setting the `fsGroup`

Unless overridden by the environment (e.g. OpenShift may set these according to the restricted SCC)), the `PEMCluster` uses a default `securityContext` of:

```
securityContext:
  runAsUser: 1011
  fsGroup: 1011
  supplementalGroups: [5555]
```

For resources volume the group id of the shared file system needs to be assigned as part of the supplementalGroups to configure the correct file permissions for persistent volumes.

## IBM Licensing
 
Automatically installing ibm-licensing-operator with a stand-alone IBM Containerized Software using Operator Lifecycle Manager (OLM). 
Use the automatic script to install License Service on any Kubernetes-orchestrated cloud. The script creates an instance and validates the steps. It has been tested to work on OpenShift Container Platform 4.8+, vanilla Kubernetes clusters, and is available at:
  pre-install/license/ibm_licensing_operator_install.sh
Post-installation steps: https://github.com/IBM/ibm-licensing-operator/blob/master/README.md#post-installation-steps"
 
## Uploading RESOURCE_VALUE_UNIT Metric to the IBM Licensing Service
 
Use the script to register the RESOURCE_VALUE_UNIT Metric in the IBM Licensing Tool. The script creates this Metric so that the IBM Licensing Service can capture the product deployed based on the provided annotations. The script is available at:
  pre-install/license/uploadMetricToLicensingService.sh

## Documentation

[IBM Partner Engagement Manager Essential ](Need to provide documentation link)

## Limitations

* This helm chart can only be deployed into single namespace

## Documentation
