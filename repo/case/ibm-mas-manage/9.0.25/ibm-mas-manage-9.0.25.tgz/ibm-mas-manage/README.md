# Name

IBM&reg; Manage

# Introduction

## Summary
IBM® Manage is an asset management system to manage asset operations and business processes. It provides insight for all your enterprise assets, their conditions and work processes, for better planning and control.

## Features
- Reduce downtime and costs: Optimize asset management and maintenance processes to improve operational performance.
- Leverage embedded industry expertise: Use best-practice data models and workflows to accelerate your industry transformation.
- Unify asset management processes: Use role-based workspaces to help teams across your enterprise focus on critical tasks and data.
- Extend asset lifecycles: Enhance your return on assets with financial and performance analytics.
- Optimize maintenance work processes: Build preventive and prescriptive approaches for your journey to predictive maintenance.

# Details

## Prerequisites
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4

### Resources Required
Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |    11       |      3      |    250    |    1  |

# Installing

Verify no pods are crashing:
```sh
oc get pods -n mas-<instance>-manage
```
### Verify the Manage is running
```sh
curl -ik https://localhost:7000/maximo/api/ping
HTTP/2 200
x-frame-options: SAMEORIGIN
x-content-type-options: nosniff
access-control-allow-credentials: true
x-xss-protection: 1
cache-control: no-cache
content-language: en-US
content-length: 0
set-cookie: JSESSIONIDUI=0000PaYL9h-Hm5Ylf95_BHLC3Bt:21553c37-640d-42bd-98b3-fc295195c1ce; Expires=Fri, 12 Mar 2021 08:54:18 GMT; Path=/; HttpOnly
date: Thu, 11 Mar 2021 20:54:18 GMT
expires: Thu, 01 Dec 1994 16:00:00 GMT
```

### Verify that you can find expected system message
```sh
curl -ik https://localhost:7000/maximo/api/bamessages/system/noclause
HTTP/2 200
x-frame-options: SAMEORIGIN
x-content-type-options: nosniff
access-control-allow-credentials: true
x-xss-protection: 1
content-type: application/json
content-length: 110
content-language: en-US
set-cookie: JSESSIONIDUI=00001TN45L71tKd9b7fHJg5RLHR:21553c37-640d-42bd-98b3-fc295195c1ce; Expires=Fri, 12 Mar 2021 08:31:15 GMT; Path=/; HttpOnly
date: Thu, 11 Mar 2021 20:31:15 GMT
expires: Thu, 01 Dec 1994 16:00:00 GMT
cache-control: private, max-age=172800, no-cache=set-cookie

{"msgtext":"The query could not be saved because it is the default query. Default queries cannot be altered."}
```

### Verify that you can find an expected label for the work order tracking application
```sh
curl -ik https://localhost:7000/maximo/api/bauitext/wotrack/maintabs_calpointavgs_table_tablebody_5
HTTP/2 200
x-frame-options: SAMEORIGIN
x-content-type-options: nosniff
access-control-allow-credentials: true
x-xss-protection: 1
content-type: application/json
vary: apicachekey
content-length: 58
content-language: en-US
set-cookie: JSESSIONIDUI=00002uKFoVJHc4-FjhO6OZqNE8a:21553c37-640d-42bd-98b3-fc295195c1ce; Expires=Fri, 12 Mar 2021 09:11:04 GMT; Path=/; HttpOnly
date: Thu, 11 Mar 2021 21:11:04 GMT
expires: Thu, 01 Dec 1994 16:00:00 GMT
cache-control: private, max-age=172800, no-cache=set-cookie

{"wotrack":{"maintabs_calpointavgs_table_tablebody_5":{}}}
```

## Configuration
See the details provided in OperatorHub for more information about how to configure SLS.

## Storage
When installing the Manage instance you will be prompted for the storage class and capacity for a PVC that will be used by the Manage application.  There are no specific performance requirements for the storage class and it only requires minimal capacity (less than 1Gb), you may choose the cheapest or lowest quality of service storage class available in your cluster, and set the size to the lowest value supported by the storage class.


## Air Gap Installs
Support for the air gap installer is not available in this release.

## Limitations
- The operator only supports single namespace deployment
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of the Suite can **not** be deployed in the same namespace
- Each Suite resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-manage`

## Upgrades
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.6/html/operators/administrator-tasks#olm-upgrading-operators).

## Documentation
Refer to the IBM Knowledgecenter

## Backup
### Backup process
- Backup DB2/Oracle/SQLServer database.

### Restore process
- Restore DB2/Oracle/SQLServer database.


### Red Hat OpenShift SecurityContextConstraints Requirements
The operator uses the Openshift default `restricted` SCC (Security Context Constraints).

## Network isolation

As a best practice, network isolation is to be used to isolate the Red Hat OpenShift project (Kubernetes namespace) where IBM Maximo Application Suite is deployed. Then, you must ensure that only the appropriate services are accessible outside the namespace or outside the cluster. For more information about network isolation, review the following OpenShift documentation.</br></br>
    - [Understand software-defined networking options with Red Hat OpenShift](https://www.ibm.com/docs/en/openshift?source=https%3A%2F%2Fdocs.openshift.com%2Fcontainer-platform%2F3.11%2Farchitecture%2Fnetworking%2Fsdn.html%23architecture-additional-concepts-sdn&referrer=SSQNUZ_4.0%2Fcpd%2Fplan%2Fsecurity.html)</br>
    - [Using NetworkPolicy objects for custom isolation policies](https://www.ibm.com/docs/en/openshift?source=https%3A%2F%2Fdocs.openshift.com%2Fcontainer-platform%2F3.11%2Fadmin_guide%2Fmanaging_networking.html%23admin-guide-networking-networkpolicy&referrer=SSQNUZ_4.0%2Fcpd%2Fplan%2Fsecurity.html)</br>
    - [Isolating applications in OpenShift projects](https://www.ibm.com/docs/en/openshift?source=https%3A%2F%2Fdocs.openshift.com%2Fcontainer-platform%2F3.11%2Fsecurity%2Fnetwork_security.html&referrer=SSQNUZ_4.0%2Fcpd%2Fplan%2Fsecurity.html)
