# Name

IBM DevOps Loop CASE

# Introduction

## Summary

* DevOps Loop is a cloud-based continuous integration platform. DevOps Loop is built on modern, cloud-native technologies that enables product teams to plan, code, test, build and deploy the applications efficiently. DevOps Loop provides a holistic view of the progress in the DevOps cycle, allowing teams to track development, monitor workflows, and manage releases effectively.

## Features

* Connects teams, processes, and applications across planning, coding, testing, releasing, deploying, and measuring to deliver software faster, with greater visibility and governance. 

# Details

## Prerequisites

### Resources Required

# Installing

* See the Administration->Installation section at https://www.ibm.com/docs/en/devops-loop

## Configuration

## Storage

## Limitations

## Documentation

* https://www.ibm.com/docs/en/devops-loop

