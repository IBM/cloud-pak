# Name

IBM&reg; Asset Data Dictionary

# Introduction
## Summary
IBM Asset Data Dictionary creates and manages Data dictionary resources

## Features
This operator is used by Monitor and Manage applications to store key resources (like assets and devices) and their relationships.

# Details
## Prerequisites
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4

### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| **Total** |  0.2        |  200m       |  0.1      |  1    |

## Installing
This operator may be installed in a internet-connected or disconnected (airgap) environment. Normal installation steps are described here, in an airgap environment the *Airgap Pre-Installation* section should be performed first to make container images accessible to the environment.

A Cluster Admin should create the namespace and entitlement and install the operator as follows.

### Configure namespace and entitlement
Create your namespace, e.g. `mas-{instanceId}-add` and create a Docker secret named `ibm-entitlement` containing your entitlement key for the IBM Entitled Registry.

```bash
oc new-project mas-dev-add
oc create secret docker-registry ibm-entitlement \
    --docker-server=<your-registry-server> \
    --docker-username=<your-name> \
    --docker-password=<your-pword> \
```

### Install Operator
Install the operator in your newly created namespace

## Configuration
An End User may create an instance of the Asset Data Dictionary custom resource:

```yaml

apiVersion: asset-data-dictionary.ibm.com/v1
kind: AssetDataDictionary
metadata:
  name: "add-sample"
  labels:
    asset-data-dictionary.ibm.com/configScope: system
    asset-data-dictionary.ibm.com/instanceId: "{{ instance_id }}"
spec:
  bindings:
    jdbc: "system"
  settings:
    registry: "{{ entitlement_server }}"
    version: "{{ image_version }}"
  displayName: Dummy AssetDataDictionary configuration
```
## Airgap Pre-Installation
If your cluster is in a restricted network or not connected to the Internet, the OCP cluster will not be able to pull container images directly from public registries like IBM Entitled Registry. You will need to fetch the images into a Bastion server, load the images into an internal mirror registry, and configure image mirroring in your OCP cluster so that it will pull the container images from the internal mirror registry.

The pre-installation steps are as follows:
- Install the cloudctl command line tool
- Get the CASE for the Data Dictionary
- Create or identify a mirror registry, accessible from the airgapped cluster
- Mirror CASE images to the mirror registry, using the cloudctl tool
- Configure the cluster to pull images from the mirror registry.

Once these steps have been performed, normal installation can be performed.

## Limitations
- The operator supports single namespace deployment.
- Multiple instances of the operator can be deployed in a single cluster.
- Multiple installations of the Asset Data Dictionary Instance can **not** deployed in the same namespace.
- Each Asset Data Dictionary resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-add`

## Roles and Personas
Installation and configuration of the Asset Data Dictionary operator may be divided into two Roles or Personas to limit the access privileges required.
- Cluster Admin - Installs the operator into a namespace
- End User - Creates custom resources so that the operator produces required resources to allow the asset data dictionary to function

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
The operator uses the OpenShift default `restricted` SCC (Security Context Constraints).

## PodSecurityPolicy Requirements
The operator runs in OpenShift so no PodSecurityPolicy configuration is required.

### Ready Condition Reason Codes
The Data Dictionary operator uses the `Ready` condition reason code of the CR to indicate progress in generating the required secret. The following reason codes are used:

#### Asset Data Dictionary Operator
- **Ready** : Asset Data Dictionary is now ready
- **InvalidConfiguration** : Invalid db2 configuration
- **Timed out after 5 minute waiting for truststore to be ready** : Truststore is not ready
- **MissingCredentials** : Internal router cert secret is not available
- **InvalidCredentials** : Internal router cert secret does not contain expected keys

#### Data Dictionary Workspace Operator
- **Ready** : Data Dictionary workspace is now ready
- **MissingCredentials** : Instance admin secret doesn't exist
- **InvalidCredentials** : Instance admin secret does not contain expected keys
