# Introduction
The IBM® Db2 Operator Extension for IBM Cloud Pak for Data installs a set of extensions to enable IBM® Db2 within Cloud Pak for Data.

# Name

IBM® Db2 Warehouse Operator Extension for IBM Cloud Pak for Data

# Introduction

## Summary

IBM® Db2 Warehouse is designed for high-performance, in-database analytics. You can configure SMP (Symmetric Multiprocessing) or MPP (Massively Parallel Processing) by setting the replica count during provisioning.

Refer to the [IBM Db2 Warehouse Material](https://www.ibm.com/products/db2-warehouse) for more information.

## Documentation

See the [IBM Cloud Pak for Data Db2 Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSEPGG_11.5.0/com.ibm.db2.luw.db2u_openshift.doc/doc/c_db2u_11-5-5.html)

# Details

## Prerequisites

This operator depends on the IBM Db2 Operator. This IBM Db2 Operator will be automatically installed using the Operand Deployment Lifecycle Manager operator.

## Supported platforms

Red Hat OpenShift Container Platform 4.6 or newer installed on one of the following platforms:
- Linux x86_64
- Power ppc64le
- IBM Z s390x

## Link To External Documentation
https://www.ibm.com/analytics/db2

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
This operator runs with the 'restricted' SCC

```
openshift.io/scc: restricted
```