IBM® API Connect is a complete, modern, intuitive and scalable API platform that lets you create, securely expose, manage and monetize APIs across clouds so that you and your customers can power digital applications and spur innovation.

Also available as part of the IBM Cloud Pak for Integration.

# Name

IBM&reg; API Connect Operator

# Introduction

## Summary

IBM&reg; API Connect is an integrated API management offering, with capabilities and tooling for all phases of the API lifecycle. Key steps of the API lifecycle include create, secure, manage, socialize, and analyze. 

IBM&reg; API Connect Version 10 delivers enhanced capabilities for the market-leading IBM API management solution. In addition to the ability to deploy in complex, multi-cloud topologies, this version provides enhanced experiences for developers and cloud administrators in your organization.

## Features

- Management subsystem

    The API Manager provides a user interface that facilitates promotion and tracking of APIs that are packaged within Products and Plans. API providers can move the Products through their lifecycle, and manage the availability and visibility of APIs and Plans.

    Catalogs and Spaces are created in the API Manager to act as staging targets through which APIs, Plans, and Products are published to consumer organizations. API providers can stage their Products to Catalogs or Spaces, and then publish them to make the APIs in those Products visible on a Developer Portal for external discovery.

    To control access to the available API management functions, users in the provider organization can be set up in the API Manager UI with assigned roles and permissions. API providers can also use the UI to manage the consumer organizations that sign up to access their APIs and Plans. Developer communities can additionally be created as a way of grouping together a collection of consumer organizations to whom a particular set of Products and Plans can be made available.

    The API Manager UI also includes functions to manage the security of the API environment, and provides access to analytics information about API invocation metrics within customizable dashboard views.

- Developer Portal subsystem

    The Developer Portal provides a customizable self-service web-based portal to application developers to explore, discover, and subscribe to APIs.

    When API providers publish APIs in the API Manager, those APIs are exposed in the Developer Portal for discovery and usage by application developers in consumer organizations. Application developers can access the Developer Portal UI to register their applications, discover APIs, use the required APIs in their applications (with access approval where necessary), and subsequently deploy those applications.

    The Developer Portal provides additional features, such as forums, blogs, comments, and ratings, for socialization and collaboration. API consumers can also view analytics information about the APIs that are used by an application, or used within a consumer organization.

- Analytics subsystem

    API Connect provides the capability to filter, sort, and aggregate your API event data. This data is then presented within correlated charts, tables, and maps, to help you manage service levels, set quotas, establish controls, set up security policies, manage communities, and analyze trends.


- DataPower&reg; Gateway subsystem

    The DataPower&reg; Gateway is an enterprise API Gateway that is built for departments and cross-enterprise usage. This Gateway provides a comprehensive set of API policies for security, traffic management, mediation, acceleration, and non-HTTP protocol support. The DataPower Gateway is deployed on a virtual or physical DataPower appliance and supports multiple Catalogs per instance or cluster. The DataPower Gateway can handle enterprise level complex integration, and supports containers for flexible runtime management.

## Details

## Prerequisites

### Resources Required

Refer to the [IBM® API Connect Version 10 Detailed System Requirements](https://www.ibm.com/support/knowledgecenter/SSMNED_v10/com.ibm.apic.install.doc/overview_apimgmt_requirements.html) report for resource requirements.

# PodSecurityPolicy Requirements
```
There are no explicit PSP required.
```

# SecurityContextConstraints Requirements
```
There are no explicit SCC required, OpenShift restricted SCC is used by the operator.
```

# Custom PodSecurityPolicy definition
```
There are no custom PodSecurityPolicy.
```

## Installing

### Configuration

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSMNED_v10/com.ibm.apic.install.doc/tapic_install_Kubernetes_OpenShift.html) for instructions on installing and configuring this workload.

## Storage

- Block storage is required

# Limitations

- A cluster admin role is required to run this workload.
- OpenShift 4.6.16 or later is required to run this workload.  OCP 4.9 is not supported. 

## Documentation

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSMNED_v10/com.ibm.apic.cmc.doc/con_cmc_overview.html) for further guidance.


