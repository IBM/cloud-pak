# APIConnect Operator Setup

This inventory item contains resources required to install the IBM APIConnect Operator through the Operator Lifecycle Manager in an online environment.
