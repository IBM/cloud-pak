# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

caseName="ibm-apiconnect"
inventory="apiconnectOperatorSetup"

caseCatalogName="ibm-apiconnect-catalog"
channelName="v5.0"

datapowerCase="ibm-datapower-operator"
datapowerInventory="datapowerOperator"
# commonServicesCase="ibm-cp-common-services"
# commonServicesInventory="ibmCommonServiceOperatorSetup"
# wmlTrainingCase="ibm-ai-wmltraining"
# wmlTrainingInventory="wmltrainingOperatorSetup"
# edbCase="ibm-cloud-native-postgresql"
# edbInventory="ibmCloudNativePostgresqlOperator"

# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
catalogDigest=":latest"

# - default variable values for dynamic args.
s390x=0

cases=("$datapowerCase:$datapowerInventory")
# cases=(" ")

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    case $key in
    --s390x)
        s390x=1
        ;;
    esac
}

dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

install_dependent_catalogs() {
    if [[ $s390x -eq 0 ]]; then
        local dep_case="$(dependent_case_tgz "${datapowerCase}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: "${dep_case}"-------------"
        validate_file_exists "${dep_case}"

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory ${datapowerInventory} \
            --action install-catalog \
            -t 1 \
            --args "--registry ${registry}" "${dryRun}" "${debug}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    fi

    if [[ $s390x -eq 1 ]]; then
        local dep_case="$(dependent_case_tgz "${edbCase}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: "${dep_case}"-------------"
        validate_file_exists "${dep_case}"

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory ${edbInventory} \
            --action install-catalog \
            -t 1 \
            --args "--registry ${registry}" "${dryRun}" "${debug}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    fi

    # local dep_case="$(dependent_case_tgz "${commonServicesCase}" "${inputcasedir}")"
    # echo "-------------Installing dependent catalog source: "${dep_case}"-------------"
    # validate_file_exists "${dep_case}"

    # cloudctl case launch \
    #     --case "${dep_case}" \
    #     --namespace "${namespace}" \
    #     --inventory ${commonServicesInventory} \
    #     --action install-catalog \
    #     -t 1 \
    #     --args "--registry ${registry}" "${dryRun}" "${debug}"

    # if [[ $? -ne 0 ]]; then
    #     err_exit "installing dependent catalog for '${dep_case}' failed"
    # fi

    # local dep_case="$(dependent_case_tgz "${wmlTrainingCase}" "${inputcasedir}")"
    # echo "-------------Installing dependent catalog source: "${dep_case}"-------------"
    # validate_file_exists "${dep_case}"

    # cloudctl case launch \
    #     --case "${dep_case}" \
    #     --namespace "${namespace}" \
    #     --inventory ${wmlTrainingInventory} \
    #     --action install-catalog \
    #     -t 1 \
    #     --args "--registry ${registry}" "${dryRun}" "${debug}"

    if [[ $? -ne 0 ]]; then
        err_exit "installing dependent catalog for '${dep_case}' failed"
    fi

}
uninstall_dependent_catalogs() {
    if [[ $s390x -eq 0 ]]; then
        local dep_case="$(dependent_case_tgz "${datapowerCase}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory ${datapowerInventory} \
            -t 1 \
            --action uninstall-catalog

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog for '${dep_case}' failed"
        fi
    fi

    if [[ $s390x -eq 1 ]]; then
        local dep_case="$(dependent_case_tgz "${edbCase}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory ${edbInventory} \
            -t 1 \
            --action uninstall-catalog

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog for '${dep_case}' failed"
        fi
    fi

    # local dep_case="$(dependent_case_tgz "${commonServicesCase}" "${inputcasedir}")"
    # echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"
    # validate_file_exists "${dep_case}"

    # cloudctl case launch \
    #     --case "${dep_case}" \
    #     --namespace "${namespace}" \
    #     --inventory ${commonServicesInventory} \
    #     -t 1 \
    #     --action uninstall-catalog

    if [[ $? -ne 0 ]]; then
        err_exit "Uninstalling dependent catalog for '${dep_case}' failed"
    fi

    # local dep_case="$(dependent_case_tgz "${wmlTrainingCase}" "${inputcasedir}")"
    # echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"
    # validate_file_exists "${dep_case}"

    # cloudctl case launch \
    #     --case "${dep_case}" \
    #     --namespace "${namespace}" \
    #     --inventory ${wmlTrainingInventory} \
    #     -t 1 \
    #     --action uninstall-catalog

    if [[ $? -ne 0 ]]; then
        err_exit "Uninstalling dependent catalog for '${dep_case}' failed"
    fi
}

# Check to see if the namespace is already the target of an OperatorGroup. If not, create one.
 # Need to have a single OG, otherwise OLM doesn't like.
install_operator_group() {
    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}' ) -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi
    echo "------------- installing operator group -------------"
    local og="${casePath}/inventory/${inventory}/files/olm/operator_group.yaml"
    validate_file_exists "${og}"
    sed <"${og}" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply -n "${namespace}" -f -
}

# install_catalog is ONLY used for offline(airgapped) standalone APIC install
install_catalog() {
    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi
    install_operator_group
    local cat="${casePath}/inventory/${inventory}/files/olm/ibm-apiconnect-catalog-source.yaml"
    validate_file_exists "${cat}"
    sed <"${cat}" "s|image: icr.io/|image: ${registry}/|g" | $kubernetesCLI apply -f -
}

uninstall_catalog() {
    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local cat="${casePath}/inventory/${inventory}/files/olm/ibm-apiconnect-catalog-source.yaml"
    local og="${casePath}/inventory/${inventory}/files/olm/operator_group.yaml"

    validate_file_exists "${cat}"
    validate_file_exists "${og}"

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${cat}" --ignore-not-found=true

    # # don't remove operator group, some other may have a dependency ?
    # echo "-------------Uninstalling operator group-------------"
    # $kubernetesCLI delete -f "${og}" --ignore-not-found=true
}

install_operator() {
# Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing via OLM-------------"
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/olm/subscription.yaml ]] && { err_exit "Missing required subscription yaml, exiting deployment."; }

    # check if catalog source is installed
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # - subscription
    sed <"${casePath}"/inventory/"${inventory}"/files/olm/subscription.yaml "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | $kubernetesCLI apply -n "${namespace}" -f -
}

uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    $kubernetesCLI delete -n ${namespace} subs ibm-apiconnect-catalog-subscription --ignore-not-found=true
    $kubernetesCLI delete -n ${namespace} og ibm-apiconnect-catalog-group --ignore-not-found=true
    $kubernetesCLI delete CatalogSource ibm-apiconnect-catalog -n "${catalogNamespace}" --ignore-not-found=true

    # TODO -- could do a better job cleaning up!
}

retag_dependent_catalog_images() {
    echo "-------------retag_dependent_catalog_images noop-------------"
}

retag_catalog_image() {
    echo "-------------retag_catalog_image noop-------------"
}

install_operator_native() {
    echo "Not supported"
    exit 1
}
uninstall_operator_native() {
    echo "Not supported"
    exit 1
}
delete_custom_resources() {
    echo "Not supported"
    exit 1
}
apply_custom_resources() {
    echo "Not supported"
    exit 1
}

configure_cluster_pull_secret() {
    echo "-------------Configuring cluster pullsecret-------------"
    REGISTRY_SECRETS=$(${scriptDir}/airgap.sh registry secret -l)
    # configure global pull secret if an authentication secret exists on disk
    for i in $REGISTRY_SECRETS; do
        if [[ "${registry}" =~ "${i}" ]]; then
            "${scriptDir}"/airgap.sh cluster update-pull-secret --registry "${i}" "${dryRun}"
        else
            echo "Skipping configuring cluster pullsecret: No authentication exists for ${registry}"
        fi
    done
}

