# IBM Network Intelligence Operator Setup

OLM-based installation of IBM Network Intelligence Operator.
