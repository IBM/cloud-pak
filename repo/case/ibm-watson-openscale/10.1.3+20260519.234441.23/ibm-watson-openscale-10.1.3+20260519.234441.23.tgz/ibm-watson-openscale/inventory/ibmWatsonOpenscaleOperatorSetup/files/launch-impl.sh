#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Script install Couchdb Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI)
# application of kubernetes manifests in both an online and offline airgap environment.  This script can be invoked using
# `cloudctl`, a command line tool to manage Container Application Software for Enterprises (CASEs), or directly on an
# uncompressed CASE archive.  Running the script through `cloudctl case launch` has added benefit of pre-requisite validation
# and verification of integrity of the CASE.  Cloudctl download and usage istructions are available at [github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli).
#
# Pre-requisites:
#   oc or kubectl installed
#   sed installed
#   CASE tgz downloaded & uncompressed
#   authenticated to cluster
#
# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="install-operator"
caseJsonFile=""
casePath="${scriptDir}/../../.."

caseName="ibm-openscale"
inventory="ibmWatsonOpenscaleOperatorSetup"
instance=""

# - optional parameter / argument defaults
deleteCRDs=0
namespace=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
cr_system_status="betterThanYesterday"
recursive_catalog_install=0

# - variables specific to catalog/operator installation
caseCatalogName="ibm-openscale-operator-catalog"
caseCatalogSubscriptionName="ibm-watson-openscale-operator-subscription"
caseOperatorGroupName="ibm-watson-openscale-operator-group"
catalogNamespace="openshift-marketplace"
csvName="ibm-cpd-wos.v9.1.3"
channelName="v9.1"
catalogDigest=":latest"

# - additional variables
WEBHOOK_ENABLED_CPD="${WEBHOOK_ENABLED_CPD:-true}"
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-watson-openscale-operator}"
OPERATOR_TAG="${OPERATOR_TAG:-1.0.0}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
entitledSecret=""
entitledRegistry="cp.icr.io/cp/cpd"
storageclass=""
size=""
licenseaccept=""
licensetype=""

# ***** ARGUMENT CHECKS *****

# Parses the args (--args) parameter if any are specified
parse_custom_dynamic_args() {
    dynamic_arg_name=$1
    dynamic_arg_value=$2
    case $dynamic_arg_name in
    --storageclass)
        storageclass=${dynamic_arg_value}
        ;;
    --scaleConfig)
        size=${dynamic_arg_value}
        ;;
    --license-accept)
        licenseaccept=${dynamic_arg_value}
        ;;
    --license-type)
        licensetype=${dynamic_arg_value}
        ;;
    esac
}

# Check if all secret parameters are included
check_secret_params() {

    local foundError=0

    [[ -z ${secret} ]] && {
        foundError=1
        err "'--secret' is required for creating a registry secret"
    }
    [[ -z ${registry} ]] && {
        foundError=1
        err "'--registry' is required for creating a registry secret"
    }
    [[ -z ${user} ]] && {
        foundError=1
        err "'--user' is required for creating a registry secret"
    }
    [[ -z ${pass} ]] && {
        foundError=1
        err "'--pass' is required for creating a registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

check_entitled_secret_params() {

    local foundError=0

    [[ -z ${entitledRegistry} ]] && {
        foundError=1
        err "'--entitledRegistry' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledUser} ]] && {
        foundError=1
        err "'--entitledUser' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledPass} ]] && {
        foundError=1
        err "'--entitledPass' is required for creating a entitled registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

# Validates that the required args were specified for install action
validate_install_args() {
    # Verify arguments required per install method were provided
    echo "Checking install arguments"

    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]]; then
        check_secret_params
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    fi

    if [[ -n "${entitledUser}" || -n "${entitledPass}" ]]; then
        check_entitled_secret_params
        if $kubernetesCLI get secrets "${entitledSecret}" -n "${namespace}" >/dev/null 2>&1; then
            echo "Secret ${entitledSecret} already exists, skipping create"
            secret=${entitledSecret}
        else
            set -e
            $kubernetesCLI create secret docker-registry "${entitledSecret}" \
                --docker-server="${entitledRegistry}" \
                --docker-username="${entitledUser}" \
                --docker-password="${entitledPass}" \
                --docker-email="${entitledUser}" \
                --namespace "${namespace}"
            secret=${entitledSecret}
            set +e
        fi
    fi

    if [[ -n "${pullPrefix}" ]];then
        entitledRegistry=${pullPrefix}
    fi
}

validate_install_catalog() {

    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    echo "Checking arguments for install-catalog action"

    # Remove registry arg requirement for install
    # if [[ ${mode} != "uninstall" && -z "${registry}" ]]; then
    #     err "'--registry' must be specified with the '--args' parameter"
    #     print_usage 1
    # fi

    if [[ ${recursive_catalog_install} -eq 1 && -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
        print_usage 1
    fi
}

validate_configure_cluster_airgap_native_args() {
# Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** END ARGUMENT CHECKS *****

# ***** UTILS *****

assert() {
    testname="$1"
    got=$2
    want=$3
    if [ "$got" != "$want" ]; then
        err_exit "got $got, but want $want : ${testname} failed"
    fi
}
# ***** END UTILS *****

# ***** ACTIONS *****

# ----- CONFIGURE ACTIONS -----

# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)
# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)

# Append secret to Global Cluster Pull Secret (pull-secret in openshif-config)
configure_cluster_pull_secret() {

    echo "-------------Configuring cluster pullsecret-------------"

    # configure global pull secret if an authentication secret exists on disk
    if "${scriptDir}"/airgap.sh registry secret -l | grep "${registry}"; then
        "${scriptDir}"/airgap.sh cluster update-pull-secret --registry "${registry}" "${dryRun}"
    else
        echo "Skipping configuring cluster pullsecret: No authentication exists for ${registry}"
    fi
}

configure_content_image_source_policy() {

    echo "-------------Configuring imagecontentsourcepolicy-------------"

    get_case_name

    echo "name is ${caseName}"
    echo "dir is ${inputcasedir}"

    "${scriptDir}"/airgap.sh cluster apply-image-policy \
        --name "${caseName}" \
        --dir "${inputcasedir}" \
        --registry "${registry}" "${dryRun}"
}

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap_native() {

    echo "-------------Configuring cluster for airgap native-------------"

    validate_configure_cluster_airgap_native_args

    configure_cluster_pull_secret

    configure_content_image_source_policy
}

# ----- INSTALL ACTIONS -----

install_dependent_catalogs() {
    echo "No dependent catalogs for OpenScale"
}

install_operator_group() {
    echo "------------- Installing operator group for $namespace -------------"
    local operator_group_file="${casePath}/inventory/${inventory}/files/deploy/install/operator-group.yaml"
    validate_file_exists "${operator_group_file}"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        sed <"${operator_group_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi

}

# Installs the catalog source and operator group
install_catalog() {
    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi
    
    echo "Wait for catalog installation to complete"
    sleep 30
    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    echo "-------------Installing via OLM-------------"

    validate_install_args
    install_operator_group
    install_catalog

    local subscription_file="${casePath}/inventory/${inventory}/files/deploy/install/subscription.yaml"
    validate_file_exists "${subscription_file}"
    $kubernetesCLI apply -n ${namespace} -f "${subscription_file}"
    echo "Wait for subscription to complete"
    sleep 60
}

# Install utilizing default CLI method
install_operator_native() {
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi
    
    validate_install_args
   
    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    if $kubernetesCLI get deploy --all-namespaces | grep -w ibm-watson-openscale-operator > /dev/null 2>&1;then 
        echo "ibm-watson-openscale-operator already deployed" 
        exit 1
    fi

    echo "Install Operator Native..."
    # rely on image content source policy
    #sed -i "s#icr.io/cpopen.*#${OPERATOR_IMAGE_FULL_PATH}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
    
    echo "Pre install"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/cpd.ibm.com_woservices.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml -n ${namespace}

    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml -n ${namespace}
    sed <"${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply -n ${namespace} -f -
    
    if [[ "$secret" != "" ]]; then
       $kubernetesCLI secrets link ibm-watson-openscale-operator-serviceaccount ${secret} --for=pull -n ${namespace}
    fi
    
    echo "installing operator"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/sample_cpd_v1_woservice.yaml

    validate_file_exists "$cr"

    if [[ -z ${storageclass} ]]; then
        echo "storageclass is empty, set to default: managed-nfs-storage"
        storageclass="managed-nfs-storage"
    fi

    if [[ -z ${size} ]]; then
        echo "size is empty, set to default: small"
        size="small"
    fi  

    if [[ ${licenseaccept} == "false" ]]; then
        err_exit "You must read and accept the license (IBM Cloud Pak for Data: Enterprise Edition https://ibm.biz/BdffBz; Standard Edition https://ibm.biz/BdffBf) by specifying --args '--license-accept true'"
    fi

    if [[ ${licensetype} != "Enterprise" && ${licensetype} != "Standard"  ]]; then
        err_exit "You must set the license type that you purchased by specifying --args '--license-type Enterprise|Standard'"
    fi

    sed "${cr}" -e "s|STORAGE_CLASS|${storageclass}|g" -e "s|SIZE|${size}|g" -e "s|LICENSE_ACCEPT|${licenseaccept}|g" -e "s|LICENSE_TYPE|${licensetype}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

}

run_adm(){
    echo "***run adm in ${namespace}: to be removed after security hardening***"
    
    $kubernetesCLI apply -n ${namespace} -f "${casePath}"/inventory/"${inventory}"/files/deploy/adm.yaml
    $kubernetesCLI adm policy add-scc-to-user cpd-user-scc system:serviceaccount:${namespace}:cpd-viewer-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-user-scc system:serviceaccount:${namespace}:cpd-editor-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-zensys-scc system:serviceaccount:${namespace}:cpd-admin-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-noperm-scc system:serviceaccount:${namespace}:cpd-norbac-sa
}

remove_adm(){
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/adm.yaml
    $kubernetesCLI adm policy remove-scc-from-user cpd-user-scc system:serviceaccount:${namespace}:cpd-viewer-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-user-scc system:serviceaccount:${namespace}:cpd-editor-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-zensys-scc system:serviceaccount:${namespace}:cpd-admin-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-noperm-scc system:serviceaccount:${namespace}:cpd-norbac-sa
}
# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
   echo "No dependent catalogs for OpenScale"
}

correct_dryrun_option() {

    # rectify the deprecated kubectl option

    if [[ ${dryRun} = "--dry-run" ]]; then
        dryRun="--dry-run=client"
    fi
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "-------------Uninstalling catalog-------------"

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}

}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling Operator-------------"

    correct_dryrun_option

    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogSubscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n ${namespace} --ignore-not-found=true)
    # Remove the Cluster Service Version - CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n ${namespace} --ignore-not-found=true ${dryRun}; }

    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogSubscriptionName}" -n ${namespace} --ignore-not-found=true ${dryRun}

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}

    $kubernetesCLI delete OperatorGroup "${caseOperatorGroupName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {

    echo "-------------Uninstall operator native-------------"

    correct_dryrun_option
   
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml -n ${namespace}
    sed <"${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/role.yaml -n ${namespace}
    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/role_binding.yaml -n ${namespace}

    $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}
}

delete_resources() {
   echo "-------------Uninstall custom resource definition-------------"
   $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/cpd.ibm.com_woservices.yaml --ignore-not-found=true -n ${namespace}
}

delete_custom_resources() {
     echo "-------------Uninstall custom resources-------------"
     $kubernetesCLI delete ${dryRun} -f "${casePath}"/inventory/"${inventory}"/files/sample_cpd_v1_woservice.yaml --ignore-not-found=true -n ${namespace}

    echo "Wait for custom resource to be deleted"
    sleep 60

     #delete_resources
}

# ***** END ACTIONS *****

install() {
    install_operator
}

uninstall() {

    correct_dryrun_option
    uninstall_operator
}
