# Name

IBM&reg; Cloud Pak for Data Watson OpenScale

# Introduction

## Summary

Use IBM Watson OpenScale to analyze your AI with trust and transparency and understand how your AI models make decisions. 
Detect and mitigate bias and drift. 
Increase the quality and accuracy of your predictions. 
Explain transactions and perform what-if analysis. 
With Cloud Pak for Data, your users can collaborate from a single, unified interface that supports a large number of services that are designed to work together.


# Details

## Prerequisites
  
### Resources Required

- For resources required to install, see the [system requirements](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=planning-system-requirements).
  
# Installing

- For install instructions, see the [Installing Watson OpenScale section](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=openscale-installing-watson)

## Prerequisite

- For prerequisite information, see the [before you begin section](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=iwo-installing-watson-openscale) 

## Configuration

See [Configuring Watson OpenScale after installation](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=openscale-configuring-watson-after-installation).

## Limitations

- Only `x86-64` platform is supported by this operator.
- See [Known issues and limitations for Watson OpenScale](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=issues-watson-openscale).

## Documentation

- Product documentation for IBM Watson OpenScale can be found [here](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=services-watson-openscale)

## PodSecurityPolicy Requirements

The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements

The **ibm-wos-cpd-custom-scc** SCC is required to deploy this.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: ibm-wos-cpd-custom-scc
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```