# IBM Spectrum Discover

[IBM Spectrum Discover](https://www.ibm.com/products/spectrum-discover) is a modern metadata management software that provides data insight for exabyte-scale heterogeneous file, object, backup, and archive storage on premises and in the cloud.

# Introduction

## Details

Companies need the ability to use unstructured data to meet their business priorities.

IBM Spectrum Discover provides a rich metadata layer that enables storage administrators, data stewards, and data scientists to efficiently manage, classify, and gain insights from massive amounts of data. It improves storage economics, helps mitigate risk, and accelerates large-scale analytics to create competitive advantage and speed critical research.

Many companies face significant challenges to manage their data. Some difficult challenges that companies face include:

* Pinpointing and activating relevant data for large-scale analytics.
* Lacking the fine-grained visibility needed to map data to business priorities.
* Removing redundant, trivial, and obsolete data.
* Identifying and classifying sensitive data.

### Configuration

You can configure Spectrum Discover by using one of several methods.

See more information in [Deploying and configuring](https://www.ibm.com/docs/en/spectrum-discover/2.0.5?topic=205-deploying-configuring)

## Installing the Product

You can install Spectrum Discover by using one of several methods.

To install the product, see [Deploy and configure a single node production IBM Spectrum Discover appliance cluster](https://www.ibm.com/docs/en/spectrum-discover/2.0.5?topic=dc-deploy-configure-single-node-production-spectrum-discover-appliance-cluster)

# Limitations

...

## Prerequisites

### Resources Required

To learn about the IBM Spectrum Discover system requirements, please visit our [requirements doc](https://www.ibm.com/docs/en/spectrum-discover/2.0.5?topic=205-planning)

* Minimum System Resources Required

Minimum scheduling capacity:

| Software    | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| ---------   | ----------- | ----------- | --------- | ----- |
| Master Node | 16          | 4           | 120       | 3     |
| Worker Node | 64          | 16          | 250       | 3     |

## Documentation

- [Product Documentation](https://www.ibm.com/docs/en/spectrum-discover)
- [Spectrum Discover Architecture](https://www.ibm.com/docs/en/spectrum-discover/2.0.5?topic=overview-spectrum-discover-architecture)
- [Upgrading Spectrum Discover](https://www.ibm.com/docs/en/spectrum-discover/2.0.5?topic=205-upgrading)

# PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:

```
...
```

# SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
# This SCC is the least restrictive, and is meant to be a template
# Pass the --validate=false flag when applying
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: ibm-sd-privileged-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: false
allowedCapabilities:
- '*'
allowedFlexVolumes: []
allowedUnsafeSysctls:
- '*'
defaultAddCapabilities: []
defaultAllowPrivilegeEscalation: false
forbiddenSysctls: []
fsGroup:
  type: RunAsAny
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: MustRunAsRange
seccompProfiles:
- '*'
# This can be customized for your host machine
seLinuxContext:
  type: RunAsAny
# seLinuxOptions:
#   level:
#   user:
#   role:
#   type:
supplementalGroups:
  type: RunAsAny
volumes:
- '*'
# If you want a priority on your SCC -- set for a value more than 0
priority: 0
```
