# IBM Spectrum Discover Operator Setup

This inventory item contains resources required to install the IBM Spectrum Discover Operator through the Operator Lifecycle Manager (OLM) an online and offline airgap environment.