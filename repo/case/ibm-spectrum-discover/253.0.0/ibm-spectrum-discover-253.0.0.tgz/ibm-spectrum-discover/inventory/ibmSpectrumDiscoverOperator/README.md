# IBM Spectrum Discover Operator

Contains the IBM Spectrum Discover Operator custom resource and launch scripts to install/delete the custom resources