### ibm-pg-operator

ibm-pg-operator manages Postgres Clusters embedded in IBM Products
