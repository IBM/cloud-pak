# mdmOperator

`mdmOperator` inventory item contains the resources required for installing the IBM Operator for MDM. A cluster scoped permissions is required while installing this inventory item since it involves installing cluster resources like crds, clusterroles and clusterrolebindings.
