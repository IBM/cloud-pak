# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the mdm operator

inventory="mdmOperator" # default inventory item
subscriptionName="ibm-mdm-operator-subscription"
catalogNamespace="openshift-marketplace"
catalogSource="ibm-mdm-operator-catalog"
case_dependencies="ibm-ccs ibm-rabbitmq-operator ibm-elasticsearch-operator ibm-redis-cp ibm-fdb"

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    ibm-fdb)
        echo "fdbOperator"
        return 0
        ;;
    ibm-rabbitmq-operator)
        echo "ibmRabbitmqOperatorSetup"
        return 0
        ;;
    ibm-elasticsearch-operator)
        echo "ibmElasticsearchOperatorSetup"
        return 0
        ;;
    ibm-redis-cp)
        echo "ibmRedisCPOperator"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
  local dep_case=""

  for dep in $case_dependencies; do
      local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

      echo "-------------Installing dependent catalog source: ${dep_case}-------------"

      validate_file_exists "${dep_case}"
      local inventory=""
      inventory=$(dependent_inventory_item "${dep}")

      cloudctl case launch \
          --case "${dep_case}" \
          --namespace "${namespace}" \
          --inventory "${inventory}" \
          --action install-catalog \
          --args "--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun } --registry ${registry}" \
          --tolerance "${tolerance_val}"

      if [[ $? -ne 0 ]]; then
          err_exit "installing dependent catalog for '${dep_case}' failed"
      fi
  done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun } --registry ${registry}" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    if [[ -z $registry ]]; then
        tee >($kubernetesCLI apply ${dryRun} -f -) <"${catsrc_file}" | cat
    else
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
         sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}
# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${catalogSource}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${catalogSource}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace before creating subscription
    sed <"${subscription_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    err_exit "Installing operator natively is not supported."
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"

    local cr="${casePath}"/inventory/"${inventory}"/files/mdm_v1_masterdatamanagement.yaml

    validate_file_exists "$cr"

    sed <"${cr}" -e "s/accept: false/accept: true/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # deleting InstallPlan for ibm-mdm-operator
    MDM_IP_EXISTS=$(oc get installplan -n ${namespace} | grep "ibm-mdm")
    rc=$?
    if [ $rc == 0 ]; then
    oc delete installplan $(oc get installplan -n ${namespace} | grep ibm-mdm |awk '{ print $1 }') -n ${namespace}
    else
    echo "MDM Installplan Not Found...."
    fi

    # delete crds
    if [[ $deleteCRDs -eq 1 ]]; then
        CRD_EXISTS=$(oc get customresourcedefinition.apiextensions.k8s.io/masterdatamanagements.mdm.cpd.ibm.com)
        rc=$?
        if [ $rc == 0 ]; then
          oc delete customresourcedefinition.apiextensions.k8s.io/masterdatamanagements.mdm.cpd.ibm.com
        else
          echo "CRD masterdatamanagements.mdm.cpd.ibm.com Not Found...."
        fi
        ADDON_CRD_EXISTS=$(oc get customresourcedefinition.apiextensions.k8s.io/masterdatamanagementaddons.mdm.cpd.ibm.com)
        rc=$?
        if [ $rc == 0 ]; then
          oc delete customresourcedefinition.apiextensions.k8s.io/masterdatamanagementaddons.mdm.cpd.ibm.com
        else
          echo "CRD masterdatamanagementaddons.mdm.cpd.ibm.com Not Found...."
        fi
    fi
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    err_exit "Uninstalling operator natively is not supported."
}
