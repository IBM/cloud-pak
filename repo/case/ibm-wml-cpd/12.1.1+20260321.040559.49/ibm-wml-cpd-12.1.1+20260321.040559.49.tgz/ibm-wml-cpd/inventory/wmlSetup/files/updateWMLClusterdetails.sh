#!/bin/bash
# echo "*************************************"	
# echo "Enter host, port, default_instance_group and default_instance_group_edt "
# echo "*************************************"

if [ $# -ne 5 ]; then
	echo "Usage : $0  host port default_instance_group  default_instance_group_edt IP-ADDRESS"
	exit 1
	
fi
	
    DEFAULT_INSTANCE_GROUP_EDT=$4
    DEFAULT_INSTANCE_GROUP=$3
    PORT=$2
    HOST=$1
    IP_ADDRESS=$5

NS=$(oc project -q)

##Form EXTERNAL_URL
external_url="https://${IP_ADDRESS}"
echo
echo

cmName=wmlaconfigmap

if [ $(oc get configmap ${cmName} --no-headers -n ${NS} 2>/dev/null | wc -l ) -eq 1 ]; then
    echo "Configmap ${cmName} will be updated"
    host=\"$HOST\"
    port=\"$PORT\"
    default_instance_group=\"$DEFAULT_INSTANCE_GROUP\"
    default_instance_group_edt=\"$DEFAULT_INSTANCE_GROUP_EDT\"
    url=\"${external_url}\"
    patch_res=$(oc patch configmap ${cmName} --type merge -p="{\"data\":{\"host\":${host}, \"port\":${port}, \"default_instance_group\":${default_instance_group},\"default_instance_group_edt\":${default_instance_group_edt}, \"external_url\":${url}}}" -v=1 -n ${NS})
    echo ****PATCH RESULT STATUS****
    echo $patch_res
else
    echo "create configmap ${cmName}"
    create_res=$(oc create configmap ${cmName} --from-literal=host=${HOST} --from-literal=port=${PORT} --from-literal=default_instance_group=${DEFAULT_INSTANCE_GROUP} --from-literal=default_instance_group_edt=${DEFAULT_INSTANCE_GROUP_EDT} --from-literal=external_url=${external_url} -v=1 -n ${NS})
    echo ****CREATE RESULT STATUS****
    echo $create_res
fi

echo 
echo 
echo ***********RESTARTING TRAINING PODS*************
 oc delete pods -n $NS -l app=wmltraining
 oc delete pods -n $NS -l app=wmltrainingorchestrator
echo ***********TRAINING PODS RESTARTED**************
echo
echo
echo
echo ***********RESTARTING PORTAL PODS***************
 oc delete pods -n $NS -l app=portal-main
 oc delete pods -n $NS -l app=portal-ml-dl
 oc delete pods -n $NS -l app=portal-projects
echo ***********PORTAL PODS RESTARTED****************
echo
echo
echo
while : ; do
    portal_pots_status=$(oc get po | grep "portal-main\|portal-ml-dl\|portal-projects\|wmltraining-\|wmltrainingorchestrator" | grep Running | grep 1/1 | wc -l)
    echo "${portal_pots_status} bedrock pods are running"
    if [[ ${portal_pots_status} -eq 5 ]]; then
      break
    fi
    sleep 10
done

# Validate the new configmaps are reflecting in the training pods.
echo ***********VALIDATING CHANGES***************
PODS="$(oc get pods -n $NS | grep training | cut -d\  -f1 )"

   for P in $PODS
   do
      count=$(oc exec -it $P  -n $NS -- env | grep WMLA | wc -l)
      
      if [ "$count" != 4 ];then
     	 echo "Found ${count} WMLA_* variables instead of 4"
      	 exit 0
      fi

      hostValue=$(oc exec -it $P -n $NS -- env | grep WMLA_HOST| cut -d "=" -f 2| tr -d '\r')
      portValue=$(oc exec -it $P -n $NS -- env | grep WMLA_PORT| cut -d "=" -f 2 | tr -d '\r')
      instGroupValue=$(oc exec -it $P -n $NS -- env | grep WMLA_DEFAULT_INSTANCE_GROUP= | cut -d "=" -f 2| tr -d '\r')
      instGroupValueEDT=$(oc exec -it $P -n $NS -- env | grep WMLA_DEFAULT_INSTANCE_GROUP_EDT| cut -d "=" -f 2|tr -d '\r')
      externalUrl=$(oc exec -it $P -n $NS -- env | grep WML_EXTERNAL_URL| cut -d "=" -f 2 | tr -d '\r')
      echo
      echo "Kube Configmaps validation started for pod $P"
      echo

      if [ "$hostValue" != "$HOST" ];then
      	echo "Host values does not match in pod $P"
      	exit 0
      fi
      
      if [ "$portValue" != "$PORT" ];then
      	echo "Port value does not match in pod $P"
      	exit 0
      fi
      
      if [ "$instGroupValue" != "$DEFAULT_INSTANCE_GROUP" ];then
      	echo "Default instance group value does not match in pod $P"
     	exit 0
      fi
      
      if [ "$instGroupValueEDT" != "$DEFAULT_INSTANCE_GROUP_EDT" ];then
      	echo "Default instance group edt  value does not match in pod $P"
      	exit 0
      fi

      if [ "$externalUrl" != "$external_url" ];then
            echo "externalUrl value does not match in pod $P"
            exit 0
      fi

      echo "Validated successfully for $P"
  done

    echo
    echo
    echo
    echo ***********VALIDATING PORTAL-ML_DL POD CHANGES************
    PODS="$(oc get pods -n $NS | grep portal-ml-dl | cut -d\  -f1 )"

    for P in $PODS
       do
          count=$(oc exec -it $P  -n $NS -- env | grep WMLA_HOST | wc -l)

          if [ "$count" != 1 ];then
             echo "WMLA_HOST not present in as env variable for pod $P"
             exit 0
          fi


          hostValue=$(oc exec -it $P -n $NS -- env | grep WMLA_HOST| cut -d "=" -f 2| tr -d '\r')

          if [ "$hostValue" != "$HOST" ];then
            echo "Host values does not match in pod $P"
            exit 0
          fi

          echo
          echo "Validated successfully for $P"
          echo
       done

    echo
    echo
    echo ***********VALIDATING PORTAL-PROJECTS POD CHANGES************
    PODS="$(oc get pods -n $NS | grep portal-projects | cut -d\  -f1 )"

    for P in $PODS
       do
          count=$(oc exec -it $P  -n $NS -- env | grep WMLA_HOST | wc -l)

          if [ "$count" != 1 ];then
             echo "WMLA_HOST not present in as env variable for pod $P"
             exit 0
          fi


          hostValue=$(oc exec -it $P -n $NS -- env | grep WMLA_HOST| cut -d "=" -f 2| tr -d '\r')

          if [ "$hostValue" != "$HOST" ];then
            echo "Host values does not match in pod $P"
            exit 0
          fi

          echo
          echo "Validated successfully for $P"
          echo
       done
   
   echo
   echo
   echo ***********VALIDATING PORTAL-MAIN POD CHANGES*************
    PODS="$(oc get pods -n $NS | grep portal-main | cut -d\  -f1 )"

    for P in $PODS
       do
          count=$(oc exec -it $P  -n $NS -- env | grep WMLA_HOST | wc -l)

          if [ "$count" != 1 ];then
             echo "WMLA_HOST not present in as env variable for pod $P"
             exit 0
          fi


          hostValue=$(oc exec -it $P -n $NS -- env | grep WMLA_HOST| cut -d "=" -f 2| tr -d '\r')

          if [ "$hostValue" != "$HOST" ];then
            echo "Host values does not match in pod $P"
            exit 0
          fi

          echo
          echo "Validated successfully for $P"
          echo
        done

