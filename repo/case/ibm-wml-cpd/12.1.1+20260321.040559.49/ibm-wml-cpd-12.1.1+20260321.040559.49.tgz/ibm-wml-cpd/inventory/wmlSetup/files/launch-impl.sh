#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Script install Couchdb Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI)
# application of kubernetes manifests in both an online and offline airgap environment.  This script can be invoked using
# `cloudctl`, a command line tool to manage Container Application Software for Enterprises (CASEs), or directly on an
# uncompressed CASE archive.  Running the script through `cloudctl case launch` has added benefit of pre-requisite validation
# and verification of integrity of the CASE.  Cloudctl download and usage istructions are available at [github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli).
#
# Pre-requisites:
#   oc or kubectl installed
#   sed installed
#   CASE tgz downloaded & uncompressed
#   authenticated to cluster
#
# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="install-operator-native"
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName="ibm-wml-cpd"
inventory="wmlSetup"
instance=""

# - optional parameter / argument defaults
dryRun=""
deleteCRDs=0
namespace=""
src_registry=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
mirror_image_chunks=""
image_groups=""
skip_delta=""
recursive_action=0
tolerance_val=0
cr_system_status="betterThanYesterday"
recursive_catalog_install=0

# docker registry variables(airgap changes)
registry_clean=
registry_dir=
registry_engine=
registry_image=
registry_subject=
registry_port=

#airgap changes end


# - variables specific to catalog/operator installation
caseCatalogName="ibm-cpd-wml-operator-catalog"
caseCatalogSubscriptionName="ibm-cpd-wml-operator-subscription"
caseOperatorGroupName="ibm-cpd-wml-operator-group"
catalogNamespace="openshift-marketplace"
csvName="ibm-cpd-wml-operator.v1.0.0"
catalogDigest=":latest"

# - variables specific to catalog/operator installation
case_depedencies="ibm-ccs"

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-wml-operator}"
OPERATOR_TAG="${OPERATOR_TAG:-v1.0.1-x86_64}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-cp.stg.icr.io/cp}"
entitledSecret="ibm-cpd-wml-operator-secret"
entitledRegistry="cp.stg.icr.io/cp"
storageclass=""
storagevendor=""
size=""

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    # skip this check for certain actions(airgap changes)
    skip_actions="imageInfo mirrorImages configureCredsAirgap initRegistry startRegistry stopRegistry"
    if [[ "$skip_actions" != *$action* ]]; then
        check_kube_connection
        check_kube_namespace
    fi
    # airgap changes end
    # Verify dynamic args are valid (show as any issues on invocation as possible)
    parse_dynamic_args
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"

    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --deleteCRDs)
            deleteCRDs=1
            ;;
        --channelName)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            channelName="${v}"
            ;;
        --fromRegistry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            src_registry="${v}"
            ;;            
        --catalogDigest)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            catalogDigest="@${v}"
            ;;
        --registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry="${v}"
            ;;
         --chunks)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            mirror_image_chunks="${v}"
            ;;           
        --groups)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            image_groups="${v}"
            ;;            
        --skipDelta)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            skip_delta="${v}"
            ;;            
        --pullPrefix)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pullPrefix="${v}"
            ;;        
        --from-registry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            mirrorSource="${v}"
            ;;
        --entitledRegistry)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledRegistry="${v}"
            ;;
        --inputDir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            inputcasedir="${v}"
            ;;
        --user)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            user="${v}"
            ;;
        --entitledUser)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledUser="${v}"
            ;;
        --pass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            pass="${v}"
            ;;
        --entitledPass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            entitledPass="${v}"
            ;;
        --secret)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            secret="${v}"
            ;;
        --systemStatus)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            cr_system_status="${v}"
            ;;
        --recursive)
            recursive_action=1
            ;;
        # flags related to starting/stopping local docker registry(airgap changes)
        --subject)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_subject="${v}"
            ;;
        --dir)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_dir="${v}"
            ;;
        --image)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_image="${v}"
            ;;
        --engine)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_engine="${v}"
            ;;
        --port)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            registry_port="${v}"
            ;;
        --clean)
            registry_clean=1
            ;;            
       # airgap changes end     
        --help)
            print_usage 0
            ;;
        --storageclass)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            storageclass=${v}
            ;;
        --storagevendor)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            storagevendor=${v}
            ;;            
        --scaleConfig)
            idx=$((idx + 1))
            v="${arr[${idx}]}"
            size=${v}
            ;;
        *)
            err_exit "Invalid Option ${v}" >&2
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

# Check if all secret parameters are included
check_secret_params() {

    local foundError=0

    [[ -z ${secret} ]] && {
        foundError=1
        err "'--secret' is required for creating a registry secret"
    }
    [[ -z ${registry} ]] && {
        foundError=1
        err "'--registry' is required for creating a registry secret"
    }
    [[ -z ${user} ]] && {
        foundError=1
        err "'--user' is required for creating a registry secret"
    }
    [[ -z ${pass} ]] && {
        foundError=1
        err "'--pass' is required for creating a registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

check_entitled_secret_params() {

    local foundError=0

    [[ -z ${entitledRegistry} ]] && {
        foundError=1
        err "'--entitledRegistry' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledUser} ]] && {
        foundError=1
        err "'--entitledUser' is required for creating a entitled registry secret"
    }
    [[ -z ${entitledPass} ]] && {
        foundError=1
        err "'--entitledPass' is required for creating a entitled registry secret"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

# Validates that the required args were specified for install action
validate_install_args() {
    # Verify arguments required per install method were provided
    echo "Checking install arguments"

    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]]; then
        check_secret_params
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    fi

    if [[ -n "${entitledUser}" || -n "${entitledPass}" ]]; then
        check_entitled_secret_params
        if $kubernetesCLI get secrets "${entitledSecret}" -n "${namespace}" >/dev/null 2>&1; then
            echo "Secret ${entitledSecret} already exists, skipping create"
            secret=${entitledSecret}
        else
            set -e
            $kubernetesCLI create secret docker-registry "${entitledSecret}" \
                --docker-server="${entitledRegistry}" \
                --docker-username="${entitledUser}" \
                --docker-password="${entitledPass}" \
                --docker-email="${entitledUser}" \
                --namespace "${namespace}"
            secret=${entitledSecret}
            set +e
        fi
    fi

    if [[ -n "${pullPrefix}" ]];then
        entitledRegistry=${pullPrefix}
    fi
}

validate_install_catalog() {

    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    echo "Checking arguments for install-catalog action"

    # Remove registry arg requirement for install
    # if [[ ${mode} != "uninstall" && -z "${registry}" ]]; then
    #     err "'--registry' must be specified with the '--args' parameter"
    #     print_usage 1
    # fi

    if [[ ${recursive_action} -eq 1 && -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
        print_usage 1
    fi
}

# Validates that the required args were specified for secret creation
validate_configure_creds_airgap_args() {
    # Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }
    [[ -z "${user}" ]] && {
        foundError=1
        err "'--user' must be specified with the '--args' parameter"
    }
    [[ -z "${pass}" ]] && {
        foundError=1
        err "'--pass' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_configure_cluster_airgap_args() {
# Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    [[ -z "${inputcasedir}" ]] && {
        foundError=1
        err "'--inputDir' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_configure_cluster_airgap_native_args() {
# Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${registry}" ]] && {
        foundError=1
        err "'--registry' must be specified with the '--args' parameter"
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** END ARGUMENT CHECKS *****

# ***** UTILS *****

#airgap changes 

get_case_name() {

    validate_file_exists $casePath/case.yaml

    caseName="$(grep '^name: ' $casePath/case.yaml)"        #get name from case.yaml
    caseName=$(echo $caseName | awk -F':' '{print $2}')     #get everything after ':', ex. `name: ibm-ws` becomes ibm-ws
    caseName="$(echo -e "${caseName}" | tr -d '[:space:]')" #trim ALL whitespaces
}

get_case_version() {

    validate_file_exists $casePath/case.yaml

    caseVersion="$(grep '^version: ' $casePath/case.yaml)"        #get name from case.yaml
    caseVersion=$(echo $caseVersion | awk -F':' '{print $2}')     #get everything after ':', ex. `version: 2.0.0` becomes 2.0.0
    caseVersion="$(echo -e "${caseVersion}" | tr -d '[:space:]')" #trim ALL whitespaces
}
# airgap changes end

assert() {
    testname="$1"
    got=$2
    want=$3
    if [ "$got" != "$want" ]; then
        err_exit "got $got, but want $want : ${testname} failed"
    fi
}
# ***** END UTILS *****

# ----- REGISTRY ACTIONS -----
#airgap changes
init_registry() {
    "${scriptDir}"/airgap.sh registry service init \
        ${user:+'--username' "$user"} \
        ${pass:+'--password' "$pass"} \
        ${registry_dir:+'--dir' "$registry_dir"} \
        ${registry_subject:+'--subject' "$registry_subject"} \
        ${registry:+'--registry' "$registry"} \
        ${registry_clean:+'--clean'}
}

start_registry() {
    "${scriptDir}"/airgap.sh registry service start \
        ${registry_dir:+'--dir' "$registry_dir"} \
        ${registry_engine:+'--engine' "$registry_engine"} \
        ${registry_port:+'--port' "$registry_port"} \
        ${registry_image:+'--image' "$registry_image"}
}

stop_registry() {
    "${scriptDir}"/airgap.sh registry service stop \
        ${registry_engine:+'--engine' "$registry_engine"}
}


#airgap changes end

# ***** ACTIONS *****

# ----- CONFIGURE ACTIONS -----

# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)
# Add / update local authentication store with user/password specified (~/.airgap/secrets/<registy>.json)
configure_creds_airgap() {
    echo "-------------Configuring authentication secret-------------"

    validate_configure_creds_airgap_args

    # Create registry secret for user information provided

    "${scriptDir}"/airgap.sh registry secret -c -u "${user}" -p "${pass}" "${registry}"
}

# Append secret to Global Cluster Pull Secret (pull-secret in openshif-config)
configure_cluster_pull_secret() {

    echo "-------------Configuring cluster pullsecret-------------"

    # configure global pull secret if an authentication secret exists on disk
    if "${scriptDir}"/airgap.sh registry secret -l | grep "${registry}"; then
        "${scriptDir}"/airgap.sh cluster update-pull-secret --registry "${registry}" "${dryRun}"
    else
        echo "Skipping configuring cluster pullsecret: No authentication exists for ${registry}"
    fi
}

configure_content_image_source_policy() {

    echo "-------------Configuring imagecontentsourcepolicy-------------"

    get_case_name

    echo "name is ${caseName}"
    echo "dir is ${inputcasedir}"

    "${scriptDir}"/airgap.sh cluster apply-image-policy \
        --name "${caseName}" \
        --dir "${inputcasedir}" \
        --registry "${registry}" "${dryRun}"
}

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap_native() {

    echo "-------------Configuring cluster for airgap native-------------"

    validate_configure_cluster_airgap_native_args

    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
       echo "Secret ${secret} already exists, skipping create"
    else
       set -e
       $kubernetesCLI create secret generic "${secret}" \
       --from-literal=url="${registry}" \
       --from-literal=user="${user}" \
       --from-literal=key="${pass}" \
       --namespace "${namespace}"
       set +e
    fi

    OPERATOR_IMAGE_FULL_PATH=${registry}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    sed -i -- "s#cp.stg.icr.io/cp/cpd#${OPERATOR_IMAGE_FULL_PATH}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml
}

# Apply ImageContentSourcePolicy required for airgap
configure_cluster_airgap() {

    echo "-------------Configuring cluster for airgap-------------"

    validate_configure_cluster_airgap_args

    configure_cluster_pull_secret

    configure_content_image_source_policy

    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
       echo "Secret ${secret} already exists, skipping create"
    else
       set -e
       $kubernetesCLI create secret generic "${secret}" \
       --from-literal=url="${registry}" \
       --from-literal=user="${user}" \
       --from-literal=key="${pass}" \
       --namespace "${namespace}"
       set +e
    fi
}

# ----- MIRROR ACTIONS -----

# Mirror required images
mirror_images() {
    echo "-------------Mirroring images-------------"
#airgap changes
    get_case_name
    get_case_version

    case_archive="${caseName}-${caseVersion}.tgz"

    validate_configure_cluster_airgap_args
    
    "${scriptDir}"/airgap.sh image mirror \
        --dir "${inputcasedir}" \
        ${src_registry:+'--from-registry' "$src_registry"} \
        --to-registry "${registry}" \
        ${mirror_image_chunks:+'--split-size' "$mirror_image_chunks"} \
        ${image_groups:+'--groups' "$image_groups"} \
        ${skip_delta:+'--skip-delta' "$skip_delta"} \
        ${case_archive:+'--archive' "$case_archive"} \
        "${dryRun}"

}

# list image registries
image_info() {
    echo "-------------Listing Image Registries and Namespaces -------------"

    [[ -z "${inputcasedir}" ]] && {
        foundError=1
        err "'--inputDir' must be specified with the '--args' parameter"
    }

    "${scriptDir}"/airgap.sh image mirror --show-registries-namespaces --dir "${inputcasedir}"
}

#airgap changes end       

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}


# ----- INSTALL ACTIONS -----

install_dependent_catalogs() {
    echo "-------------Installing dependent catalogs-------------"

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")
        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi            

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {
    echo "------------- Installing operator group for $namespace -------------"
    local operator_group_file="${casePath}/inventory/${inventory}/files/op-olm/operator-group.yamll"
    validate_file_exists "${operator_group_file}"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        sed <"${operator_group_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi

}

# Installs the catalog source and operator group
install_catalog() {
    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog-source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # specical handle of staging registry for testing.
        # replace cp.stg.icr.io/cp/cpd/<image name>:<tag>
        #if [[ ${registry} == "cp.stg.icr.io" ]]; then
        #    local catsrc_image_mod="${registry}/cp/$(echo "${catsrc_image_orig}" | sed -e "s/.*\///")"
        #fi        

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi
    
    echo "Wait for catalog installation to complete"
    sleep 30
    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    echo "-------------Installing via OLM-------------"

    # Verfiy arguments are valid
    validate_install_args

    # Install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    # Install operator group
    install_operator_group

    # Check if catalog source is installed; Might to be delete after getting into ibm-operator-catalog
    echo "Checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        echo "Can't find the catalog source. Attemp to install catalog source"
        install_catalog
    else
        echo "Found catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"
	$kubernetesCLI apply -f "${subscription_file}" -n ${namespace}
    echo "Wait for subscription to complete"
	sleep 60
	
}

# Install utilizing default CLI method
install_operator_native() {
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi
    
    validate_install_args
   
    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}:${OPERATOR_TAG}

    echo "Install Operator Native..."
    sed -i "s#ibm-cpd-wml-operator-namespace#${namespace}#g" "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml

    echo "pre install"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/wml.cpd.ibm.com_wmlbases.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml  -n ${namespace}
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml  -n ${namespace}

    if [[ "$secret" != "" ]]; then
       $kubernetesCLI secrets link ibm-cpd-wml-operator-serviceaccount ${secret} --for=pull -n ${namespace}
    fi
    
    echo "installing operator"
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/sample_wml.cpd_v1_wmlbase.yaml

    validate_file_exists "$cr"
    echo "storagevendor: ${storagevendor}, storageclass: ${storageclass}"
    if [[ -z ${storageclass} && -z ${storagevendor} ]]; then
        err_exit "storageclass and storagevendor MUST not both empty"
    fi    

    if [[ -z ${size} ]]; then
        echo "size is empty, set to default: small"
        size="small"
    fi  

    if [[ -z $storagevendor ]]; then
        sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" -e "s|^\([ \t].*scaleConfig:\).*|\1 ${size}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    else

        if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" && ${storagevendor} != "\"\"" ]]; then
            err_exit "storagevendor value must either be empty \"\", \"ocs\" or \"portworx\""
        fi
        sed "${cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s|^\([ \t].*storageClass:\).*|\1 ${storageclass}|g" -e "/^\([ \t].*storageClass:\).*/a \ \ storageVendor: ${storagevendor}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    fi    
}

run_adm(){
    echo "***run adm in ${namespace}: to be removed after security hardening***"
    
    $kubernetesCLI apply -n ${namespace} -f "${casePath}"/inventory/"${inventory}"/files/deploy/adm.yaml
    $kubernetesCLI adm policy add-scc-to-user cpd-user-scc system:serviceaccount:${namespace}:cpd-viewer-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-user-scc system:serviceaccount:${namespace}:cpd-editor-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-zensys-scc system:serviceaccount:${namespace}:cpd-admin-sa
    $kubernetesCLI adm policy add-scc-to-user cpd-noperm-scc system:serviceaccount:${namespace}:cpd-norbac-sa
}

remove_adm(){
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/adm.yaml
    $kubernetesCLI adm policy remove-scc-from-user cpd-user-scc system:serviceaccount:${namespace}:cpd-viewer-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-user-scc system:serviceaccount:${namespace}:cpd-editor-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-zensys-scc system:serviceaccount:${namespace}:cpd-admin-sa
    $kubernetesCLI adm policy remove-scc-from-user cpd-noperm-scc system:serviceaccount:${namespace}:cpd-norbac-sa
}
# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "-------------Uninstalling dependent catalogs-------------"
    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "-------------Uninstalling catalog-------------"

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog-source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}

}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling Operator-------------"

    # # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogSubscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n ${namespace} --ignore-not-found=true)

    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogSubscriptionName}" -n ${namespace} --ignore-not-found=true ${dryRun}

    # # Remove the Cluster Service Version - CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n ${namespace} --ignore-not-found=true ${dryRun}; }


    # Don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseOperatorGroupName}" -n "${namespace}" --ignore-not-found=true

    # delete crds
    $kubernetesCLI delete crd wmlbases.wml.cpd.ibm.com --ignore-not-found=true ${dryRun}

    # delete service account
    $kubernetesCLI delete -n "${namespace}" serviceaccount ibm-cpd-wml-operator-serviceaccount --ignore-not-found=true ${dryRun}

    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}

    # Delete crds
    delete_custom_resources

    # Delete other wml resource
    delete_resources
}

# Uninstall operator installed via CLI
uninstall_operator_native() {

    echo "-------------Uninstall operator native-------------"
   
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role.yaml -n ${namespace}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/cluster_role_binding.yaml -n ${namespace}

    delete_custom_resources

    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator.yaml -n ${namespace}

    delete_resources

}

delete_resources() {

    echo "-------------Deleting operator resources-------------"
    if $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
        $kubernetesCLI delete secret "${secret}" -n "${namespace}" --ignore-not-found=true
    fi
    # $kubernetesCLI delete secret ibm-entitlement-key --ignore-not-found=true #Not sure why we need it here. 

    # cleanup operandrequest wml-requests-ccs
    $kubernetesCLI delete operandrequest wml-requests-ccs -n "${namespace}" --ignore-not-found=true

    echo "-------------  cleanup wml runtime pods  ---------------"

    $kubernetesCLI get deployment -n ${namespace} | grep -i wml-dep-od | awk '{print $1}' | xargs $kubernetesCLI delete deployment -n ${namespace} --ignore-not-found=true

    $kubernetesCLI get deployment -n ${namespace} | grep -i wml-dep-sd-r-shiny | awk '{print $1}' | xargs $kubernetesCLI delete deployment -n ${namespace} --ignore-not-found=true

    $kubernetesCLI get deployment -n ${namespace} | grep -i wml-dep-bd | awk '{print $1}' | xargs $kubernetesCLI delete deployment -n ${namespace} --ignore-not-found=true

    $kubernetesCLI get deployment -n ${namespace} | grep -i wml-dep-vd | awk '{print $1}' | xargs $kubernetesCLI delete deployment -n ${namespace} --ignore-not-found=true

 #Not sure why we need it .
 #   $kubernetesCLI get jobs  -n ${namespace} | grep cams-as | awk '{print $1}' | xargs $kubernetesCLI delete job -n ${namespace} --ignore-not-found=true

  #  $kubernetesCLI get jobs -n ${namespace} | grep delete-runtime | awk '{print $1}' | xargs $kubernetesCLI delete job -n ${namespace} --ignore-not-found=true

   $kubernetesCLI get jobs -n ${namespace} | grep -i training-job | awk '{print $1}' | xargs $kubernetesCLI delete job -n ${namespace} --ignore-not-found=true

   $kubernetesCLI get jobs -n ${namespace} | grep -i wml-dep-vdscikit-learn | awk '{print $1}' | xargs $kubernetesCLI delete job -n ${namespace} --ignore-not-found=true

    echo "-------------cleanup wml secrets and pvcs-------------"

     $kubernetesCLI delete secret wml-scoring-svc-secret ssl-secret wmlproxy-icp-certs training-secrets wml-deployments-etcd-secret  -n ${namespace} --ignore-not-found=true

     $kubernetesCLI delete cm watson-machine-learning-configmap wmlssldocertsconfigmap wmlsslcertsconfigmap wmlkafkaconfigmap ibm-cpd-wml-operator  -n ${namespace} --ignore-not-found=true

     $kubernetesCLI delete pvc data-wml-deployments-etcd-0 data-wml-deployments-etcd-1 data-wml-deployments-etcd-2 manager-pvc wml-training-data -n ${namespace} --ignore-not-found=true


}

delete_custom_resources() {
     echo "-------------Uninstall custom resources-------------"
     $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/crds/wml.cpd.ibm.com_wmlbases.yaml --ignore-not-found=true -n ${namespace}
}

# ***** END ACTIONS *****

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exut "No kubernetes cli found - tried oc and kubectl"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
