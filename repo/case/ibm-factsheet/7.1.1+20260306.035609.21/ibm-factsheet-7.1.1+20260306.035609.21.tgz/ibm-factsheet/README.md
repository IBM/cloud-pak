# Name

IBM&reg; Factsheet

# Introduction

## Summary

* Paragraph overview of the product
* Include links to external sources for more details

## Features

* Simple bullet list of product features


# Details

## Prerequisites
IBM Cloud Pak for Data Factsheet requires the following
- Watson Knowledge Catalog 4.0.2 or later

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Cloud Pak for Data | 64 | 16 | 100 | 3 |
| **Total** | **64** | **16**  | **100**  | **3** |

# Installing

### Get cloudctl
Download latest cloudctl binary from url below and add it to your $PATH

Release page: https://github.com/IBM/cloud-pak-cli/releases

### Get Factsheet development case 
Build the latest Factsheet development case tgz file from #To be updated

### Prerequisites
**1. Update the global pull secrets**

- Back up your current global pull secret (IMPORTANT)
```
oc get secret pull-secret -n openshift-config -o yaml > global-pull-secret.yaml
```
- Create/Update the global pull secret
```
REGISTRY_USER=<your user name for image registry>
REGISTRY_APIKEY=<your api key for image registry>
# for Linux
pull_secret=$(echo -n "$REGISTRY_USER:$REGISTRY_APIKEY" | base64 -w0)
# for Mac
pull_secret=$(echo -n "$REGISTRY_USER:$REGISTRY_APIKEY" | base64)
```
Replace the `registry url` with actual value, e.g. `cp.stg.icr.io/cp`

```
oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|:{|:{"<registry url>":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json
```
**2. Add docker registry to mirror registry**   
Add the mirrorings below to facilliate image pulling from the accessible registry.

```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: factsheet-mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - cp.stg.icr.io/cp
    source: icr.io/cpopen
  - mirrors:
    - cp.stg.icr.io
    source: cp.icr.io
EOF
```
It might take up to 20-25 min to update nodes to setup mirrors during which time a scheduling will be disabled on the nodes. Check your nodes' status and wait until they are all `Ready`

### ONLINE: Install Factsheet Operator using OLM [Cloudctl]   
**1. Install Factsheet Operator**   
```
export NAMESPACE=<Operator Project>

cloudctl case launch --case <factsheet case tgz file> --tolerance 1 --namespace <Operator Project> --action installOperator --inventory factsheetOperatorSetup

Note: <Operator Project> = ibm-common-services
```

Confirms if operator pod is up before moving to next step.

**2. Install Factsheet Custom Resource**

```
export NAMESPACE=<CP4D Project>   
oc new-project <CP4D Project>  
cloudctl case launch --case <factsheet case tgz file> --tolerance 1 --namespace <CP4D Project>  --inventory factsheetOperatorSetup --args "--storageclass <accessible storage class> --scaleConfig <small_mincpureq|small|medium|large> --license-accept --license-type <Enterprise|Standard>"
```

### AIRGAP: Install Factsheet Operator using OLM [Cloudctl]

## Configuration

* Provide configuration instructions if any

## Storage

* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## Limitations

* Deployment limits - can you deploy more than once, can you deploy into different namespace
* List specific limitations such as platforms, security, replica's, scaling, upgrades etc.. - noteworthy limits identified
* List deployment limitations such as : restrictions on deploying more than once or into custom namespaces.
* Not intended to provide chart nuances, but more a state of what is supported and not - key items in simple bullet form.
* Does it work on IBM Kubernetes Services, IBM Private Cloud ?

## Documentation

* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.

## Development
### Build CASE Bundle
Build case tgz file from case directory (in ibm-factsheet-bundle/stable/ibm-factsheet-bundle/case for Factsheet), create case tgz with below command:
```
tar -zcvhf ibm-factsheet-1.tgz ibm-factsheet/ 
```
Note the “h” option is needed to archive the actual file instead of symbolic link

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```
## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  Use the OpenShift built in restricted SCC.
Custom SecurityContextConstraints definition:
```
Not Applicable
```
