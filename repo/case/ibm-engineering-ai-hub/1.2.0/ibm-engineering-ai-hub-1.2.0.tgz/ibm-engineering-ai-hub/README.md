# Name

IBM&reg; IBM Engineering AI Hub

# Introduction

## Summary

* IBM Engineering AI Hub provides a set of agents for engineering teams designed to improve clarity, speed, and confidence across engineering programs and projects.
* IBM Engineering AI Hub is an add-on to IBM Engineering Lifecycle Management.
* See the [product documentation](https://www.ibm.com/docs/engineering-ai-hub/1.0.0) for installation and configuration details.

## Features

* Agents help teams using IBM ELM by raising requirement quality, improving access to information, and streamlining collaboration.
* Uses watsonx.ai for inferencing.

## Prerequisites

* IBM Engineeering Lifeycle Management, with Jazz Authorization Server
* Red Hat OpenShift
* IBM Common Licensing License Key Server
* watsonx.ai public service endpoint

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |             |             |           |       |

# Installing

* Include installation instructions or links to documentation
* Include the basic things necessary to install the product
* Include environment setup or any other items required

## Configuration

* Provide configuration instructions if any

## Storage

* Define how storage works with the workload
* Dynamic vs PV pre-created
* Considerations if using hostpath, local volume, empty dir
* Loss of data considerations
* Any special quality of service or security needs for storage

## Limitations

* Deployment limits - can you deploy more than once, can you deploy into different namespace
* List specific limitations such as platforms, security, replica's, scaling, upgrades etc.. - noteworthy limits identified
* List deployment limitations such as : restrictions on deploying more than once or into custom namespaces.
* Not intended to provide chart nuances, but more a state of what is supported and not - key items in simple bullet form.
* Does it work on IBM Kubernetes Services, IBM Private Cloud ?

## Documentation

* Can have as many supporting links as necessary for this specific workload however don't overload the consumer with unnecessary information.
* Can be links to special procedures in the knowledge center.
