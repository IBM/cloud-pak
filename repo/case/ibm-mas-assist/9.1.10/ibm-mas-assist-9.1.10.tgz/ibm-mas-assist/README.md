# Name
IBM MAS Assist

# Introduction
## Summary
Maximo® Assist provides technicians with AI-powered guidance through a knowledge base of equipment maintenance data and gives them remote access to experts for assistance.
## Features
Use an intuitive mobile interface in Maximo® Assist, technicians can diagnose equipment problems, find recommended solutions, and collaborate with experts by using audio, video, and AR to resolve problems.

For every expert collaboration session, a session summary is generated, attached to the work order, and added to the AI knowledge base so that it is searchable the next time a similar incident occurs. Maximo Assist helps to reduce the mean time to repair, reduces troubleshooting times, improves first-time fix rates, improves diagnosis accuracy, and drives higher levels of technician productivity while enabling companies to capture their valuable expert knowledge and scale it across the organization.

# Details
## Prerequisites
See prerequisites details here https://www.ibm.com/docs/en/mas/continuous-delivery?topic=getting-started

Summary of Prerequisites required for IBM&reg; MAS&reg; Assist :
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4.8 or 4.10
- IBM MAS Application Suite installed
- Watson Discovery
- Ceph S3 compatible Object Storage
- An IBM Entitled Registry key

### SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
IBM MAS Assist runs with the default Red Hat `restricted` SCC.

### Resources Required
Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |    23       |  19         |  0        |  3    |

## Installing
- Navigate to OperatorHub in your OpenShift Dashboard and install the ibm-mas-assist operator following the instructions presented there.
- Create the project `mas-<instanceId>-assist`, replace the `instanceId` with the real instanceId used when you install IBM Maximo Application Suite.
- Configure the Object Storage related info with the either way as below:
  - Maximo Application Suite Configuration Page `https://admin.{{suite_instanceId}}.{{suite_domain}}`
  - or From the Maximo Application Suite Installed Operator Page in the Openshift Console
- Configure the Discovery related info with the either way as below:
  - From the Maximo Application Suite Maximo Application Suite Configuration Page `https://admin.{{suite_instanceId}}.{{suite_domain}}`
  - or Create Configmap `assist-watson-discovery-config` and Secret `assist-watson-discovery-credentials` manually in the project `mas-<instanceId>-assist` based on the Discovery pre-installed
- Deploy an instance of the `AssistApp` via the installed operator.
- Once the `AssistApp` is installed you can then create `AssistWorkspace` to complete IBM MAS Assist install.
- Once all resources have reported "Ready" status you can navigate to Admin Dashboard: `https://admin.{{suite_instanceId}}.{{suite_domain}}` and login with the credentials from the secret `{{ suite_instanceId }}-credentials-superuser`

### Verifying Install

Check status of the AssistApp custom resource:
```sh
oc get AssistApp {{instanceId}}
NAME      VERSION         STATUS   AGE
devtest   8.8.0           Ready    49d
```
Check status of the AssistWorkspace custom resource:
```sh
oc get AssistWorkspace {{instanceId}}
NAME      VERSION         STATUS   AGE
masdev-devtest   8.8.0   Ready    49d
```

### Application Status Reason Codes
The Assist operator uses the `Ready` condition reason code of the CR to indicate progress. The following reason codes are used:
- `Ready` ... the Assist app/workspace/backup/restore Operator CR is up to date and ready to use
- `InvalidConfiguration` ... one or more configuration are not available or incorrect, refer to fail msg for details
- `AssistTooOld` ... migration install of the existing assist is not supported.
- `AssistorCouchDBNotReady` ... Assist is not ready or No embedded couchdb for Backup/Restore
- `CertificateNotReady` ... Certificates Secret is not yet available

## Configuration
See the details provided in [IBM docs](https://www.ibm.com/docs/en/mas/continuous-delivery?topic=getting-started) for more information about how to configure IBM MAS Assist.

## Storage
For IBM MAS Assist, it will install the embedded Redis Server and Couchdb Server, pls select the available Storage Class in the Openshift Cluster.

## Air Gap Installs
You have follow the MAS Knowledge Center to install and configure the MAS in the airgap env.

### Pre-condition
1.	Install MAS in airgap env
Refer to https://www.ibm.com/docs/en/mas-cd?topic=installation-in-airgap-environment
- Install OCS
- install the MAS Core (and Manage) First

2.	Install the Discovery in AirGap Env( refer to CP4D Knowledge center )
To  install the CP4D and Discovery in airgap Env, From its Knowledge Center, the key additional thing need to do for airgap env is to Mirror the images to mirror registry. https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=tasks-mirroring-images-your-private-container-registry

### Install IBM MAS Assist
1.	Mirror IBM MAS Assist images.
```bash
export CLOUDCTL_OUTPUTDIR=/root/offline/ibm-mas-assist/
cloudctl case save --repo https://github.com/IBM/cloud-pak/raw/master/repo/case --case ibm-mas-assist --version 8.5.0 --outputdir $CLOUDCTL_OUTPUTDIR

cloudctl case launch --case $CLOUDCTL_OUTPUTDIR/ibm-mas-assist-8.5.0.tgz --inventory ibmMasAssistSetup --action mirror-images --args "--registry $MIRROR_REGISTRY --inputDir $CLOUDCTL_OUTPUTDIR"
```
2.	Configuring the cluster to route image requests to the local mirror registry

Login in OCP Cluster and switch to Assist project 
```Bash
export CLOUDCTL_OUTPUTDIR=/root/offline/ibm-mas-assist

oc create namespace mas-$INSTANCE-assist
oc project mas-$INSTANCE-assist
```

Configuring the cluster to route image requests to the local mirror registry
```Bash
cloudctl case launch --case $CLOUDCTL_OUTPUTDIR/ibm-mas-assist-8.5.0.tgz --inventory ibmMasAssistSetup --action configure-cluster-airgap --namespace mas-$INSTANCE-assist --args "--registry $MIRROR_REGISTRY --inputDir $CLOUDCTL_OUTPUTDIR/"
```


Create Assist image ConfigMap
```Bash
cloudctl case launch --case $CLOUDCTL_OUTPUTDIR/ibm-mas-assist-8.5.0.tgz --inventory ibmMasAssistSetup --action createImageConfigMap --namespace mas-$INSTANCE-assist --args "--registry $MIRROR_REGISTRY --inputDir $CLOUDCTL_OUTPUTDIR/"


oc get configmap ibm-manage-image-map -n mas-instance-manage
```

3.	Create the IBM Maximo Assist catalog:
```Bash
cat <<EOF | oc apply -f -
apiVersion: operators.coreos.com/v1alpha1
kind: CatalogSource
metadata:
  name: ibm-mas-assist-operator-catalog
  namespace: openshift-marketplace
spec:
  displayName: IBM Maximo Assist Catalog
  publisher: IBM
  description: Catalog Source for IBM Maximo Assist
  sourceType: grpc
  image: icr.io/cpopen/ibm-mas-assist-operator-catalog:latest
  updateStrategy:
    registryPoll:
      interval: 45m
EOF
```
4.	Deploy Assist using the channel subscription with  the created customer source ibm-mas-assist-operator-catalog

5.	Activate the Assist Workspace.



## Upgrades
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.6/html/operators/administrator-tasks#olm-upgrading-operators).

## Documentation
The Maximo Application Suite documentation is available [here](https://www.ibm.com/docs/en/mas/continuous-delivery?topic=getting-started)

## Backup
Assist currently don't support the full backup/restore. But Assist have some intial works to use operator backup/restore the Couchdb data only to Object Storage, and the data can be used for the future recovery.
### Backup process
- Create `AssistBackup` instance in the IBM MAS Assist Installed Operator Page in the Openshift Console to backup Assist CouchDB datbases.

Below is the example to create AssistBackup instance to save the currrent CouchDB data.  Note to replace `assist527` with the real {{ instance_Id }} instance.
```yaml
apiVersion: apps.mas.ibm.com/v1
kind: AssistBackup
metadata:
  name: assist527
  namespace: mas-assist527-assist
  labels:
    app.kubernetes.io/instance: assist527
    app.kubernetes.io/managed-by: ibm-mas-assist
    app.kubernetes.io/name: ibm-mas-assist
    mas.ibm.com/instanceId: assist527
    mas.ibm.com/applicationId: assist
spec:
  backupFileName: Cloudant
  backupBucketName: ibm-mas-assist-assist527
```
Check the backup status
```Bash
oc get AssistBackup {{instanceId}}
NAME      VERSION         STATUS   AGE
assist527   8.8.0           Ready    1m
```
Notes: you need to delete the AssistBackup instance after the backup is complete and `Ready`. Otherwise it will repeatly backup your couchDB data.
### Restore process
- Create `AssistRestore` instance in the IBM MAS Assist Installed Operator Page in the Openshift Console to restore the backup Assist CouchDB databases.
```yaml
apiVersion: apps.mas.ibm.com/v1
kind: AssistRestore
metadata:
  name: assist527
  namespace: mas-assist527-assist
  labels:
    app.kubernetes.io/instance: assist527
    app.kubernetes.io/managed-by: ibm-mas-assist
    app.kubernetes.io/name: ibm-mas-assist
    mas.ibm.com/instanceId: assist527
    mas.ibm.com/applicationId: assist
spec:
  backupFileName: Cloudant
  backupBucketName: ibm-mas-assist-assist527
```
Notes: you need to delete the AssistRestore instance after the backup is complete and `Ready`. Otherwise it will repeatly backup your couchDB data. 
```bash
oc get AssistRestore {{instanceId}}
NAME      VERSION         STATUS   AGE
assist527   8.8.0           Ready    1m
```
Notes: you need to delete the AssistStore instance after the restore is complete and `Ready`. Otherwise it will repeatly restore your couchDB data with the data in Object Storage. 

## Workload Scale Customization

Horizontal Pod Autoscale (HPA) is enabled by default during the Assist deployment, and based on the resource (CPU and Memory) utilization for assist pods. Assist automatically scales in or out the internal components.


If you want to manually scale in or out your pods numbers for each deployment, you need to disable HPA by setting the settings.common.podautoscale to `false` in the AssistApp CR Spec.


Below is Assist components and how to do the workload scale manually 
| component(pod)              |Containers |Support workload scale Customization type | description|
| ---------------------------| :--: | :--: | :--: |
| api| ema-api |replica and resources||
| adminconsole| ema-admin-console |replica and resources||
| antivirus| ema-anti-virus |replica and resources||
| assistuseragent| assist-useragent |N/A|user agent sync pod, Always 1 pod as it proves it’s enough in perfomance test|
| crawler| ema-crawler |replica and resources||
| couch| db, mgmt |resources| coucDB size specified during assist deploy, resource scale cusomization only |
| diagnosisengine| ema-diagnosis-engine, ema-diagnosis-engine-bn, ema-diagnosis-engine-dt |replica and resources||
| redis | redis, sentinel  |resources| replica is 3 cannot be changed, resource scale cusomization only,current limitation. |
| haproxy | haproxy |resources| redis haproxy replica is 1, resource scale cusomization only, current limitation.  |
| multitenant| ema-multi-tenant |replica and resources||
| monitor| ema-monitor |N/A|Don’t support multiple replica and it’s dedicated pod to check and updates components health repeatly with specific interval.|
| workspacemgr| manager |N/A|workspace operator pod, Always 1 pod as it proves it’s enough in perfomance test |
| studio| ema-studio |replica and resources||
| technician| ema-technician |replica and resources||
| voicegateway| assist-voice-gateway |replica and resources||
| voicemanagement| assist-voice-management |replica and resources||
| voicesessionmxinspect| assist-voice-session-mxinspect |replica and resources||

From the above table, for each component(pod), based on the corresponding containers and support workload scale customization type the workload scale `containers` blocked under `spec.podTemplates`can be generated manually, for example, for `api` as example
```yaml
spec:
  settings:
    common:
      podautoscale: false
  podTemplates:
    - containers: 
        - name: ema-api -----------------containers list, only ema-api for api, and resource customization supported
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: api ------------component name
      replicas: 3  --------replica scale supported
```

And below is a example cr spec.podTemplates with full supported components for assist, for your reference to do manually workload customization.

```yaml
spec:
  settings:
    common:
      podautoscale: false
  podTemplates:
    - containers:
        - name: ema-anti-virus
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: antivirus
      replicas: 1
    - containers:
        - name: ema-api
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: api
      replicas: 1
    - containers:
        - name: ema-diagnosis-engine
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 500m
              memory: 700Mi
        - name: ema-diagnosis-engine-bn
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 500m
              memory: 700Mi
        - name: ema-diagnosis-engine-dt
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 500m
              memory: 700Mi
      name: diagnosisengine
      replicas: 1
    - containers:
        - name: ema-crawler
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: crawler
      replicas: 1
    - containers:
        - name: ema-multi-tenant
          resources:
            limits:
              cpu: 0.8
              memory: 1024Mi
            requests:
              cpu: 0.5
              memory: 512Mi
      name: multitenant
      replicas: 1
    - containers:
        - name: mgmt
          resources:
            limits:
              cpu: '2'
              memory: 2Gi
            requests:
              cpu: '1'
              memory: 576Mi
        - name: db
          resources:
            limits:
              cpu: '2'
              memory: 2Gi
            requests:
              cpu: '1'
              memory: 576Mi
      name: couch
    - containers:
        - name: redis
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 50m
              memory: 700Mi
        - name: sentinel
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 50m
              memory: 700Mi
      name: redis
    - containers:
        - name: haproxy
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 50m
              memory: 700Mi
      name: haproxy
    - containers:
        - name: assist-voice-session-mxinspect
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: voicesessionmxinspect
      replicas: 1
    - containers:
        - name: assist-voice-management
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: voicemanagement
      replicas: 1
    - containers:
        - name: assist-voice-gateway
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: voicegateway
      replicas: 1
```
And after the workload customization defined in `spec.podTemplates`, and after Assist operator reconcile, it will update the status to include the applied workload customization. e.g.
```yaml
status:
  components:
    assist:
      enabled: true
      version: 8.8.0-pre.predev
  conditions:
    - lastTransitionTime: '2023-04-07T05:44:40Z'
      message: Deployments complete
      reason: Ready
      status: 'True'
      type: Ready
  milestones:
    installed:
      anonymousId: e8019f9f-99f3-4744-9ca8-ff32d1ac8f46
      timestamp: '2023-04-06T08:05:33.476438+00:00'
      transactionId: 01b7d0fc-e1f0-4aeb-b8c4-8428bb98efa6
  podTemplates:
    - containers:
        - name: mgmt
          resources:
            limits:
              cpu: '2'
              memory: 2Gi
            requests:
              cpu: '1'
              memory: 576Mi
        - name: db
          resources:
            limits:
              cpu: '2'
              memory: 2Gi
            requests:
              cpu: '1'
              memory: 576Mi
      name: couch
      replicas: 1
    - containers:
        - name: haproxy
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 50m
              memory: 700Mi
      name: haproxy
      replicas: 1
    - containers:
        - name: redis
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 50m
              memory: 700Mi
        - name: sentinel
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 50m
              memory: 700Mi
      name: redis
      replicas: 1
    - containers:
        - name: ema-crawler
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: crawler
      replicas: 1
    - containers:
        - name: ema-diagnosis-engine
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 500m
              memory: 700Mi
        - name: ema-diagnosis-engine-bn
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 500m
              memory: 700Mi
        - name: ema-diagnosis-engine-dt
          resources:
            limits:
              cpu: 1
              memory: 700Mi
            requests:
              cpu: 500m
              memory: 700Mi
      name: diagnosisengine
```
## Workload Affinity Customization

Assist support to perform workload affinity customization manually, as workload scale customization mentioned above, you can use the podTemplates to cutomize the affinity as required as possible.

Below is the table for assist components to support affinity customization
| component(pod)              |Containers |Support workload affinity Customization type | description|
| ---------------------------| :--: | :--: | :--: |
| api| ema-api |affinity and tolerations||
| adminconsole| ema-admin-console |affinity and tolerations||
| antivirus| ema-anti-virus |affinity and tolerations||
| assistuseragent| assist-useragent |N/A||
| crawler| ema-crawler |affinity and tolerations|no need to do affinity customization|
| couch| db, mgmt |N/A| coucDB operator is not handled by current release, it didn't provide affinity customization itself, template limitation |
| diagnosisengine| ema-diagnosis-engine, ema-diagnosis-engine-bn, ema-diagnosis-engine-dt |affinity and tolerations||
| redis | redis, sentinel  |affinity and tolerations|  |
| haproxy | haproxy |affinity and tolerations|   |
| multitenant| ema-multi-tenant |affinity and tolerations||
| monitor| ema-monitor |N/A|Don’t support and no need to do affinity customization|
| workspacemgr| manager |N/A| No need to do affinity customization |
| studio| ema-studio |affinity and tolerations||
| technician| ema-technician |affinity and tolerations||
| voicegateway| assist-voice-gateway |affinity and tolerations||
| voicemanagement| assist-voice-management |affinity and tolerations||
| voicesessionmxinspect| assist-voice-session-mxinspect |affinity and tolerations||

Below is the common considerations and best practice 
- Use nodeAffinity to place the pods to specific node; 
- Use podAffinity to pack pods within a service to specific node
- Use podAntiAffinity to  tell the scheduler to avoid placing multiple replicas on a single node(for multiple zone support), e.g with below podAntiAffinity multiple redis/couchDB replicas in different node .
- Combined the podAffinity and podAntiAffinity to control and co-locate the multiple service pods.
- Use taints to allows a node to refuse pods to be scheduled unless that pod has a matching toleration.

From the above table, `spec.podTemplates`can be used to customize the workload affinity manually, for `api` service with 3 pods, 
***spread 3 pods on 3 different node with podaffinity/podAntiAffinity***
```yaml
spec:
  podTemplates:
    - affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
              - matchExpressions:
                  - key: kubernetes.io/arch
                    operator: In
                    values:
                      - amd64
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
            - podAffinityTerm:
                labelSelector:
                  matchLabels:
                    app.kubernetes.io/component: api
                topologyKey: kubernetes.io/hostname
              weight: 100
      containers:
        - name: ema-api
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: api
      replicas: 3
```
After the affinty customization is applied in the assistapp instance, it will reflect in the cr status as below:
```yaml
status:
  podTemplates:
    - affinity:
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
              - matchExpressions:
                  - key: kubernetes.io/arch
                    operator: In
                    values:
                      - amd64
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
            - podAffinityTerm:
                labelSelector:
                  matchLabels:
                    app.kubernetes.io/component: api
                topologyKey: kubernetes.io/hostname
              weight: 100
      containers:
        - name: ema-api
          resources:
            limits:
              cpu: 0.9
              memory: 512Mi
            requests:
              cpu: 0.01
              memory: 196Mi
      name: api
      replicas: 3
```
And also if you check the api pods layout in the cluster
```console
# oc get pods -l app.kubernetes.io/component=api -o wide
NAME                                 READY   STATUS    RESTARTS   AGE     IP              NODE                                     NOMINATED NODE   READINESS GATES
assist810-ema-api-6bbc7c74dc-5h59s   1/1     Running   0          2d11h   10.254.28.93    worker4.assist-minimal.cp.fyre.ibm.com   <none>           <none>
assist810-ema-api-6bbc7c74dc-g9f26   1/1     Running   0          2d11h   10.254.24.45    worker0.assist-minimal.cp.fyre.ibm.com   <none>           <none>
assist810-ema-api-6bbc7c74dc-p752k   1/1     Running   0          2d11h   10.254.32.242   worker5.assist-minimal.cp.fyre.ibm.com   <none>           <none>

```

## Limitations
- The operator only supports single namespace deployment
- The operator will only watch for resources in its own namespace
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of the Assist can **not** be deployed in the same namespace
