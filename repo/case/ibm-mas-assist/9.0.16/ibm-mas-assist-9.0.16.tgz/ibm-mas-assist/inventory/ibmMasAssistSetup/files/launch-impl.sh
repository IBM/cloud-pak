# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName="ibm-mas-assist"
inventory="ibmMasAssist"

# Override
# Create a config-map from the image-map with the digest mappings for the operator
create_image_configmap() {

    echo "-------------Creating configMap for image digest mapping-------------"
     # Verfiy arguments are valid
    # validate_install_args   ToDo - do we need this if we're not doing an OLM install? Need to ask Paul when he gets back.

    local image_map_file="${casePath}/inventory/${inventory}/files/image-map.yaml"
    local cm_name="${caseName}-image-map"
    if [[ -f ${image_map_file} ]]; then
      echo "creating image map configmap: ${cm_name}..."
      oc create configmap ${cm_name} --dry-run=client --from-file=${image_map_file} --namespace=${namespace} -o yaml > "${casePath}/inventory/${inventory}/files/image-map-cm.yaml"
      oc apply -f "${casePath}/inventory/${inventory}/files/image-map-cm.yaml"
    else
      echo "not creating image map configmap as no image map file was found at ${image_map_file}"
    fi

    echo "---Creating configMap for image digest mapping is finished---"
}

# Override
#install_operator() {
#    create_imgmap_configmap
#}
