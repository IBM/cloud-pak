# Event Streams

## Introduction

This CASE provides an operator to install [Event Streams](https://ibm.biz/ea-eventstreams), a high-throughput event-streaming platform based on [Apache Kafka®](https://kafka.apache.org/).

---

## Details

This CASE contains three inventory items:

- ibmEventstreamsOperatorInstall - The installation of the IBM Event Streams Operator. Required for installing the ibmEventstreamsExamples inventory item.
- ibmEventstreamsExamples - Several example resources provided, each of which will create an instance of IBM Event Streams if the operator has been installed.
- ibmEventstreamsExtras -  Provides various extras that are available to utilize when running an instance of IBM Event Streams.

---

## Installing

To install Event Streams by using this CASE bundle, follow the instructions in the [Event Streams documentation](https://ibm.github.io/event-automation/es/installing/offline/).

