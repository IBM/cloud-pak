# Event Streams Extras

This README provides information about the various extras that are available to utilize when running an instance of IBM Event Streams.
The IBM Event Streams extra resources in this inventory item and other useful IBM Event Streams operator resources can also be found on github [here.](https://github.com/ibm-messaging/event-streams-operator-resources)

## Prerequisites

These extras require an instance of IBM Event Streams to be available.
For information on installing an instance of IBM Event Streams, see inventory item [ibmEventStreamsExamples](../ibmEventstreamsExamples/README.md).

## Extras

#### Custom SecurityContextConstraint

IBM Event Streams supports the default `restricted` Security Context Constraint (SCC) provided by the OpenShift Container Platform. If this is changed or another SCC is applied to the Event Streams namespace, some features may fail to operate correctly. This inventory item provides a custom SecurityContextConstraint that can be applied to restore permissions necessary for Event Streams to run.

To apply the custom SecurityContextConstraint, run `oc apply -f files/eventstreams-scc.yaml` in the extracted folder for this inventory item.

#### Cluster role

This inventory item provides an example cluster-admin role. This role can be used to manage the instance of IBM Event Streams.

### Dashboards

This inventory item provides example grafana dashboards that can be used to monitor your instance of IBM Event Streams.
`eventstreams-kafka.json` is an example dashboard that will monitor the behaviour of your Kafka cluster.
`eventstreams-operators.json` is an example dashboard that will monitor the behaviour of your IBM Event Streams operator.
