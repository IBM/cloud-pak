# API reference

## IBM EventStreams Status

This is the reference documentation for the OpenAPIv3 schema of the `status` section of the EventStreams custom resource.


| Property | Type              | Required | Description                                      |
|----------|-------------------|----------|--------------------------------------------------|
| `status` | [object](#status) | No       | The status of the Event Streams instance.        |

## status

The status of the Event Streams instance.

| Property             | Type                         | Required | Description                                                                                                         |
|----------------------|------------------------------|----------|---------------------------------------------------------------------------------------------------------------------|
| `adminUiUrl`         | string                       | No       | Web address for the Event Streams administration UI.                                                                |
| `bootstrapRoutes`    | [object](#bootstraproutes)[] | No       | Routes for the new bootstrap connections.                                                                           |
| `conditions`         | [object](#conditions)[]      | No       | Current state of the Event Streams cluster.                                                                         |
| `customImages`       | boolean                      | No       | Identifies whether any of the Docker images have been modified from the defaults for this version of Event Streams. |
| `endpoints`          | [object](#endpoints)[]       | No       | Addresses of the interfaces provided by the Event Streams cluster.                                                  |
| `kafkaListeners`     | [object](#kafkalisteners)[]  | No       | Addresses of the internal and external listeners.                                                                   |
| `observedGeneration` | integer                      | No       | The generation of the resource at the last successful reconciliation.                                               |
| `phase`              | string                       | No       | Identifies the current state of the Event Streams instance. Possible values are: `Ready`, `Pending`, `Blocked`, `Failed`.      |
| `routes`             | [object](#routes)            | No       | OpenShift Routes created as part of the Event Streams cluster.                                                      |
| `versions`           | [object](#versions)          | No       | Information about the version of this instance and it's upgradable versions.                                        |

### bootstrapRoutes

| Property | Type    | Required | Description                                                |
|----------|---------|----------|------------------------------------------------------------|
| `host`   | string  | No       | The DNS name or IP address of the Kafka bootstrap service. |
| `port`   | integer | No       | The port of the Kafka bootstrap service.                   |

### conditions

| Property             | Type   | Required | Description                                                                                                                                |
|----------------------|--------|----------|--------------------------------------------------------------------------------------------------------------------------------------------|
| `lastTransitionTime` | string | No       | Last time the condition of a type changed from one status to another. The required format is 'yyyy-MM-ddTHH:mm:ssZ', in the UTC time zone. |
| `message`            | string | No       | Human-readable message indicating details about the condition's last transition.                                                           |
| `reason`             | string | No       | The reason for the condition's last transition (a single word in CamelCase).                                                               |
| `status`             | string | No       | The status of the condition, either True, False or Unknown.                                                                                |
| `type`               | string | No       | The unique identifier of a condition, used to distinguish between other conditions in the resource.                                        |

### endpoints

| Property | Type   | Required | Description                                                                                                    |
|----------|--------|----------|----------------------------------------------------------------------------------------------------------------|
| `name`   | string | No       |                                                                                                                |
| `type`   | string | No       | The type of the endpoint: 'UI' for a UI endpoint, 'API' for an API endpoint. Possible values are: `API`, `UI`. |
| `uri`    | string | No       |                                                                                                                |

### kafkaListeners

| Property           | Type                   | Required | Description                                                                                                                                                           |
|--------------------|------------------------|----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `addresses`        | [object](#addresses)[] | No       | A list of the addresses for this listener.                                                                                                                            |
| `bootstrapServers` | string                 | No       | A comma-separated list of `host:port` pairs for connecting to the Kafka cluster using this listener.                                                                  |
| `certificates`     | string[]               | No       | A list of TLS certificates which can be used to verify the identity of the server when connecting to the given listener. Set only for `tls` and `external` listeners. |
| `name`             | string                 | No       | The name of the listener.                                                                                                                                             |
| `type`             | string                 | No       | *The `type` property has been deprecated, and should now be configured using `name`.* The name of the listener.                                                       |

### addresses

| Property | Type    | Required | Description                                                |
|----------|---------|----------|------------------------------------------------------------|
| `host`   | string  | No       | The DNS name or IP address of the Kafka bootstrap service. |
| `port`   | integer | No       | The port of the Kafka bootstrap service.                   |

### routes

OpenShift Routes created as part of the Event Streams cluster.

| Property | Type | Required | Description |
|----------|------|----------|-------------|

### versions

Information about the version of this instance and it's upgradable versions.

| Property     | Type                 | Required | Description                                                          |
|--------------|----------------------|----------|----------------------------------------------------------------------|
| `available`  | [object](#available) | No       | The versions that this instance of Event Streams can be upgraded to. |
| `reconciled` | string               | No       | The current running version of this Operator.                        |

### available

The versions that this instance of Event Streams can be upgraded to.

| Property   | Type                  | Required | Description                                                                                |
|------------|-----------------------|----------|--------------------------------------------------------------------------------------------|
| `channels` | [object](#channels)[] | No       | A list of versions that the Operator is able to automatically upgrade from.                |
| `versions` | [object](#versions)[] | No       | A list of versions that the Operator is able to upgrade this instance of Event Streams to. |

### channels

| Property | Type   | Required | Description                                 |
|----------|--------|----------|---------------------------------------------|
| `name`   | string | No       | The name for this version of Event Streams. |

### versions

| Property | Type   | Required | Description                                 |
|----------|--------|----------|---------------------------------------------|
| `name`   | string | No       | The name for this version of Event Streams. |


