# Event Streams Examples

This README provides instructions about installing an instance of IBM Event Streams.
The example resources in this inventory item and other useful IBM Event Streams operator resources can be found on github [here.](https://github.com/ibm-messaging/event-streams-operator-resources)


## Prerequisites

Installing an instance of IBM Event Streams requires a working IBM Event Streams Operator.
See inventory item [ibmEventstreamsOperatorInstall](../ibmEventstreamsOperatorInstall/README.md) to create a working IBM Event Streams Operator.

Installing an instance of IBM Event Streams requires at least namespace administration privileges. 

### Steps

Install an instance of Event Streams by using the web console or CLI.
 - Installing by using the [web console](https://ibm.github.io/event-streams/installing/installing/#installing-an-instance-by-using-the-web-console)
 - Installing by using the [CLI](https://ibm.github.io/event-streams/installing/installing/#installing-an-instance-by-using-the-cli)

 ## Post-installation

 Checking the status of a deployed Event Streams instance is described in [Verifying an installation](https://ibm.github.io/event-streams/installing/post-installation/#verifying-an-installation).

 More information about a deployed instance can be obtained by running the following command:

 ```
 oc get eventstreams <eventstreams-name> -o jsonpath-as-json='{.status}'
 ```

 where `<eventstreams-name>` is the name of your Event Streams instance. This returns detailed status information as a JSON document whose schema is described [here](./files/es-status.md).
