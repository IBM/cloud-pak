# IBM Event Streams Operator

This README provides instructions for making the operator available in the Openshift Operator Lifecycle Manager and subseqently installing the IBM Event Streams Operator.

This inventory item contains:
 - A reference to all the images used by IBM Event Streams.
 - A catalog source to provide the Operator Lifecycle Manager a reference to the IBM Event Streams Operator.
 - A sample subscription for installing the IBM Event Streams Operator.

## Pre-requisites

Refer to the [Prerequisites](https://ibm.github.io/event-streams/installing/prerequisites/) section in our documentation.

## Installation Steps

Complete the following steps to install the IBM Event Streams Operator.

1. Apply the catalog source in the files directory as follows: `oc apply -f files/CatalogSource.yaml`

2. Install the Operator using one of the following methods:

a) Log in to the OpenShift Container Platform web console using your login credentials, and navigate to the OperatorHub to view the IBM Event Streams Operator tile. You can then install by using the UI.

b) Use the command line. Create an OperatorGroup in the target namespace by editing the namespace in sample OperatorGroup provided in the files directory and apply the file `oc apply -f files/OperatorGroup.yaml`. Edit the namespace in the sample subscription provided in the files directory and apply the file `oc apply -f files/Subscription.yaml`.

## Post-installation

Verifying an installation of an IBM Event Streams Operator is described under _"Checking the operator status"_ [here](https://ibm.github.io/event-streams/installing/installing/#installing-by-using-the-web-console).

More detailed information about installation and dependency status can be obtained by running the following command:

```
oc get clusterserviceversion <eventstreams-csv> -o jsonpath-as-json='{.status}'
```

where `<eventstreams-csv>` is the name of the IBM Event Streams ClusterServiceVersion (obtained by running `'oc get clusterserviceversion'`). This returns detailed status information as a JSON document whose schema is described [here](https://docs.openshift.com/container-platform/4.11/rest_api/operatorhub_apis/clusterserviceversion-operators-coreos-com-v1alpha1.html#status).

