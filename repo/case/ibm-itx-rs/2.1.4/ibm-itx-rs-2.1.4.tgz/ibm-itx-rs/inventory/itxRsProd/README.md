# Readme

This is README document for Helm chart for IBM Sterling Transformation Extender for Red Hat OpenShift

## Prerequisites

This distribution is tested on Red Hat OpenShift 4.20. The OCP project must have access to "redis" to run maps in fenced mode or asynchronously. This deployment is tested with redis-operator 7.22.0 which has been provisioned from OpenShift's OperatorHub.

### PodDisruptionBudgets

The configured deployment does not specify a disruption bugdet. Each consumer of this transformation logic should consider how disruption might impact any specific process.

### SecurityContextConstraints Requirements

This chart requires a `SecurityContextConstraints` to be bound to the target namespace prior to installation. To meet this requirement there may be cluster scoped as well as namespace scoped pre and post actions that need to occur.

The predefined `SecurityContextConstraints` name: [`anyuid`] has been verified for this chart, if your target namespace is bound to this `SecurityContextConstraints` resource you can proceed to install the chart.

This chart defines a custom `SecurityContextConstraints` which can be used to finely control the permissions/capabilities needed to deploy this chart. You can enable this custom `SecurityContextConstraints` resource using these instructions:

* From the OpenShift web console, you can copy and paste the following snippets to enable the custom `SecurityContextConstraints`

  * Custom SecurityContextConstraints definition:

    ```yaml
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata:
      annotations:
      name: ibm-itx-rs-scc
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    allowPrivilegedContainer: false
    allowedCapabilities: []
    allowedFlexVolumes: []
    defaultAddCapabilities: []
    defaultPrivilegeEscalation: false
    forbiddenSysctls:
      - "*"
    fsGroup:
      type: MustRunAs
      ranges:
      - max: 65535
        min: 1
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - ALL
    runAsUser:
      type: MustRunAsNonRoot
    seccompProfiles:
    - docker/default
    seLinuxContext:
      type: RunAsAny
    supplementalGroups:
      type: MustRunAs
      ranges:
      - max: 65535
        min: 1
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
    priority: 0
    ```

  * From the command line
    
    Save the content to a file and run the following command to apply the file content to your namespace:

      `oc apply -f <file_name> -n <namespace_name>`
