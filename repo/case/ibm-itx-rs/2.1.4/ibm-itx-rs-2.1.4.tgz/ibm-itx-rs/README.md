# Name

IBM&reg; Sterling Transformation Extender for Red Hat OpenShift

# Introduction

## Summary

IBM Sterling Transformation Extender (ITX) for Red Hat OpenShift is a containerized distribution of the translation engine exposing a set of REST API endpoints that you can invoke to run ITX maps. Another name for IBM Sterling Transformation Extender for Red Hat OpenShift is ITX Runtime Server. Maps are designed using ITX Design Studio and compiled for the Linux 64 platform. ITX Design Studio is a component separate from ITX Runtime Server. It must be installed and run locally on a Windows host. When you obtain access to the ITX Runtime Server component, you will be provided with instructions explaining how to obtain the ITX Design Studio component as well.

For additional high-level overview of the ITX Runtime Server product, please refer to this [support page](https://www.ibm.com/support/pages/node/7068837).

## Features

The following is a list of high-level features provided by the ITX Runtime Server:

- Uploading, listing, downloading and deleting compiled ITX maps and other files
- Listing and downloading generated REST API server and map execution engine log files
- Fenced (REST API server and map execution engine running in the same process) and unfenced (REST API server and map execution engine running in separate processes) run mode.
- Synchronous and asynchronous map executions
- Cataloging support for the maps, with the REST API endpoints automatically generated for the produced map catalog entries
- Direct map execution and execution via cataloged map REST APIs
- Ability to override map inputs and outputs with the REST API request and response data

# Details

## Prerequisites

ITX Runtime Server requires currently supported version of Red Hat OpenShift Container Platform (RHOCP). It is supported on Linux 64 clusters only. When compiling maps in ITX Design Studio, you must choose the option to compile them for Linux 64 platform. Alternatively, or you can use multi-platform composite maps, at the cost of increased map size. 

Redis installation is required only if you plan to run the ITX Runtime Server in fenced mode, or if you plan to invoke REST APIs for asynchronous map invocations. It is also required if you choose to catalog maps and you wish to enable caching of catalog entries to limit access to the volume where map catalog is stored. Please refer to the [`Redis Configuration`](#redis-configuration) section for more details.

Two filesystem-based persistent volumes must be provisioned for the ITX Runtime Server to be operational. If you plan for the ITX Runtime Server pods to be distributed across multiple nodes, the volumes must support ReadWriteMany bind option so that they can be bound by all pods in the installation. Please refer to the [`Storage`](#storage) section for more details.

### Resources Required

The requested and the maximum Memory and CPU size, as well as the storage capacity can be specified when configuring an ITX Runtime Server instance. The following requested values are selected by default:

| Memory (Gi) | CPU (millicores) | Disk (Gi) | Nodes |
| ----------- | ---------------- | --------- | ----- |
| 4           | 1000             | 10        | 1     |

Note that if you choose to run ITX Runtime Server instance in `fenced` mode, the REST service process will run separately from the map execution worker process. Therefore, two Java Virtual Machine (JVM) processes will created, which should be taken into account when planning system resources, especially memory.

The storage class that you choose to use for persistent volumes must be of **filesystem** type.

Following table shows different configuration profiles, the minimum configuration advisable to set up for the ITX Runtime Server: 

| Profile     | Memory (Gi) | CPU (millicores) | Disk (Gi) | Nodes                        |
| ----------- | ----------- | ---------------- | --------- | ---------------------------- |
| Starter     | 4           | 1000             | 10        | 1 (master and worker node)   |
| Development | 4           | 2000             | 25        | 3 (1 master, 2 worker nodes) |
| Production  | 16          | 4000             | 50        | 5 (2 master, 3 worker nodes) |

NOTE: User should adjust the above suggested configuration based on their transformation needs, by updating the 'resources' and 'persistence' sections in values.yaml.

# Installing

## Installing ITX Runtime Server from Command Line

ITX Runtime Server can be installed in an online (connected) or offline (air gapped) cluster using command line tools.

- Download and install `cloudctl`, `oc` and `helm` command line tools. In case of offline installation, the tools need to be downloaded to the bastion server (if using bastion), or to the portable device (if not using bastion). The CASE containing this README needs to be saved to the same machine to which the tools are downloaded.

  - [oc](https://docs.openshift.com/container-platform/4.20/cli_reference/openshift_cli/getting-started-cli.html) - for interacting with the OpenShift Cluster
  - [cloudctl](https://github.com/IBM/cloud-pak-cli) - for interacting with this CASE
  - [helm](https://helm.sh/docs/intro/install/) - for installing and configuring the embedded chart

Open a Linux shell on the machine with the downloaded tools and this CASE and go to the directory containing the `case` directory for the CASE. All `cloudctl` commands shown below must be run from that directory. 

NOTE: `cloudctl case` usage is deprecated. `cloudctl case` usage when discontinued should be replaced with `oc ibm_pak` in the below command lines after `ibm_pak` plugin for `oc` command line tool has been installed.

## Installing in an Online Cluster through CASE<a id="install-through-CASE"></a>

Run the following command to install the catalog source to the `ibm-itx` namespace in your cluster.  You may choose a namespace different from ``ibm-itx``.

```bash
cloudctl case launch         \
    --case case/ibm-itx-rs   \
    --namespace ibm-itx      \
    --inventory itxRsProd    \
    --args "-accept unknown" \
    --action install
```
Use the `--args ""` parameter to pass additional arguments to the helm installer.  For example, `--args "--set persistence.data.capacity=40Gi"` expands the default size of 10Gi specified in `values.yaml`.

Also, the ``-accept`` value must be passed in the ``--args`` string once you have read and agreed to the product licensing.  The product will not operate until this value is set to "true".

## Installing in an Online Cluster through Native ``helm`` CLI Commands<a id="install-through-helm"></a>

Run the following command, after replacing the `<target namespace>` placeholder with the name of the namespace to which you wish to install the helm chart.

```bash
helm install ibm-itx-rs               \
    --namespace <target namespace>    \
    --set license.accept=unknown      \
    ./charts/ibm-itx-rs-prod
```

NOTE: You must read and accept the product licensing terms by changing --set license.accept=true in the above command line. The product will not operate until this value is set to "true".

## Installing in Air-Gapped (Offline) OpenShift Cluster

### 1. Prepare Bastion Host or Portable Device

* Logon to the bastion machine, and verify that it has access to:

  * the public Internet (to download images from the source image registry)
  * the target image registry (where the images will be mirrored)
  * the target OpenShift cluster, to which to install the helm chart

If a bastion machine is not available, you can use a portable device (such as laptop) instead, which you must be able to carry into the air gapped environment to connect to the target cluster.

The remaining steps should be run from the bastion machine (portable device).

Open Linux shell and go to the directory that contains the `case` folder for this CASE. All the remaining `cloudctl` commands must be run from this directory.

#### 2. Prepare CASE

Prepare the CASE files used by the process. Create a temporary directory used during the process:

```bash
$ mkdir /tmp/cases
```
Run the following command:

```bash
$ cloudctl case save --case case/ibm-itx-rs --outputdir /tmp/cases
Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```
A set of .tgz and .csv files will be created in `/tmp/cases` folder.

Note: The following `cloudctl case launch` commands all include `<target namespace>` argument. The `ConfigureClusterAirgap`, `mirror-images` and `mirror-images` actions do not operate on the target cluster and this argument can be omitted. 

### 3. Configure Registry Auth

1. Authenticate with the source image registry (Entitled Registry)

Run the following command after replacing the `<target namespace>` placeholder with the name of the namespace to which you wish the secret to be created, and after replacing `<password>` placeholder with the password (API key) you have received with your entitlement.

```bash
$ cloudctl case launch               \
    --case case/ibm-itx-rs           \
    --namespace <target namespace>   \
    --inventory itxRsProd            \
    --action configureCredsAirgap    \
    --args "--registry cp.icr.io --user <user> --pass <password>"
```

The credentials will be saved to `~/.airgap/secrets/cp.icr.io.json`

2. Authenticate with the target image registry.

Note: This step can be skipped if the target registry does not require authentication.

Run the following command, after replacing the `<target namespace>` placeholder with the name of the namespace to which you wish the secret to be created, and after replacing `<target registry>`, `<user>` and `<password>` placeholders with the registry, user and password for the target image registry.

```bash
$ cloudctl case launch               \
    --case case/ibm-itx-rs           \
    --namespace <target namespace>   \
    --inventory itxRsProd            \
    --action configureCredsAirgap    \
    --args "--registry <target registry> --user <user> --pass <password>"
```

The credentials will be saved to `~/.airgap/secrets/<target registry>.json`

### 4. Mirror Images

In this step, the container image for ITX Runtime Server is copied to the target registry in the airgap environment. This generates calls to the `oc image mirror` command which copies the images over. Run the following command after replacing the `<target namespace>` placeholder with the name of the target namespace for the image, and after replacing the `<target registry>` placeholder with the name of the target image registry.

```bash
$ cloudctl case launch              \
    --case case/ibm-itx-rs          \
    --namespace <target namespace>  \
    --inventory itxRsProd           \
    --action mirror-images          \
    --args "--registry <target registry> --inputDir /tmp/cases"
```
### 5. Configure Cluster for Airgap

If portable device was used instead of the bastion server, carry the device to the air gapped environment with the target OpenShift cluster, and make sure it has connection to the cluster.

This step does the following:

* creates a global image pull **Secret** for the target registry (skipped if target registry is unauthenticated)

* creates a **ImageSourceContentPolicy** object with mirror settings

WARNING:

* Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in `$HOME/.airgap/secrets and /tmp/airgap*` to support this action

* Applying ImageSourceContentPolicy causes cluster nodes to recycle. Run the following command after replacing the `<target namespace>` placeholder with the name of the target namespace for the helm chart, and after replacing the `<target registry>` placeholder with the name of the target image registry.

```bash
cloudctl case launch                    \
    --case case/ibm-itx-rs              \
    --namespace <target namespace>      \
    --inventory itxRsProd               \
    --action ConfigureClusterAirgap     \
    --args "--registry <target registry> --inputDir /tmp/cases"
```

### 6. Install ITX definitions to the cluster

Follow the instructions in [Installing in an Online Cluster through CASE](#install-through-CASE) section,
or the instructions in [Installing in an Online Cluster through Native ``helm`` CLI Commands](#install-through-helm) section.

With either method, provide the "--set image.repository=<target registry>" command argument.

## Verifying Installation

Once you have installed the ITX Runtime Server, and have used it to deploy an ITX Runtime Server instance, you can test accessing the instance by invoking the `version` and `configuration` endpoints on it, after replacing `<location>` with the location of the `Route` resource deployed with the instance:

`<location>/itx-rs/v1/version`

`<location>/itx-rs/v1/configuration`

The `version` endpoint returns JSON document with information about the product name and version. The `configuration` endpoint returns JSON document with the configuration options and values that you specified when you deployed the instance, which you can as additional confirmation that the instance was configured as expected.

## Configuration

The configuration settings for ITX Runtime Server instance can be broken down into following logical groups:

- Resource utilization (memory, CPU, storage, replica count)
- Redis configuration (host, port, password, etc.)
- Map settings (map threads, file extension, etc.)
- Storage settings (storage class, capacity, dynamic vs. static binding, etc.)
- General settings (service account, license, custom environment variables, replica count)
- Probe settings (liveness, readiness)
- Logging (log severity, log name uniqueness, log targets, etc.)
- TLS configuration (certificates, keys, etc.)

The following is the list of available configuration options when creating ITX Runtime Server instances:

| Property | Description |
| -------- | ----------- |
| **Licensing** ||
| license.accept | Switch with true/false values for accepting the terms and conditions of the license agreement |
| **General** ||
| general.serviceAccountName | Name of the ServiceAccount object to use for the installation. If left empty, the default service account is used. |
| general.replicaCount | Number of ITX Runtime Server replica pods to deploy and run |
| general.env | Name of an optional ConfigMap containing keys/value to set as environment variable names/values when creating the pods |
| general.runMode | Selection of mode (fenced/unfenced). In fenced mode the REST service process and the worker map execution process are separate processes, and in unfenced mode they run in the same process. | 
| general.matchNodeLabel.name | Name of the label of the worker nodes to which the pods must be deployed |
| general.matchNodeLabel.value | Value of the label of the worker nodes to which the pods must be deployed |
| **Image Settings** ||
| image.repository | Image registry and repository location |
| image.digest | Image digest value, which takes priority over image tag value |
| image.tag | Image tag value |
| image.pullPolicy | Image pull policy, one of Always, Never and IfNotPresent |
| image.secret | Name of the pull image Secret object with which to configure the ServiceAccount for pulling images |
| **Probes Settings** |
| probes.liveness.enabled | Switch with true/false values to enable/disable liveness probe |
| probes.liveness.initialDelaySeconds | Number of seconds to wait before making the initial liveness probe call |
| probes.liveness.periodSeconds | Number of seconds between liveness probe calls |
| probes.liveness.timeoutSeconds | Number of seconds after which the liveness probe call times out |
| probes.readiness.enabled | Switch with true/false values to enable/disable readiness probe |
| probes.readiness.initialDelaySeconds | Number of seconds to wait before making the initial readiness probe call |
| probes.readiness.periodSeconds | Number of seconds between readiness probe calls |
| probes.readiness.timeoutSeconds | Number of seconds after which the readiness probe call times out |
| **Map Run Settings** ||
| map.fileExtension | File extension for compiled maps. The default is .lnx which matches the default extension ITX Design Studio used for the maps compiled for the Linux 64 platform. |
| map.unloadTimeMinutes | Time in minutes to keep loaded maps in memory |
| map.maxThreads | Maximum number of threads to spawn for running maps concurrently |
| map.syncTimeoutSeconds | Synchronous map execution timeout in seconds |
| map.disableCaching | Switch to disable map caching in the Runtime Server |
| map.allAttachments | Switch to include/exclude all attachments in the multi-part body response | 
| **Logging** ||
| log.accessLog.level | Severity level for REST API access logs (none, all) |
| log.accessLog.days | Number of days to keep access logs |
| log.serverLog.level | Severity level for the REST server logs (none, failures, info, all) |
| log.serverLog.days | Number of days to keep server logs |
| log.serviceLog.level | Severity level for the REST service (application) logs (none, failures, info, all) |
| log.serviceLog.days | Number of days to keep service logs |
| log.serviceLog.stdErr | Switch with true/false values to enable logging service messages to standard error, in addition to logging them to log files. |
| log.execLog.days | Severity level for the map execution worker logs (none, failures, info, all) |
| log.execLog.fileCount | Number of files to keep in the map execution circular log |
| log.execLog.fileSizeKiB | Size limit in kilobytes for map execution log files. After the limit is passed, new file is created in the circular log. |
| log.execLog.stdErr | Switch with true/false values to enable logging map execution messages to standard error, in addition to logging them to log files. |
| log.jniLog.level | Severity level for the Java Native Interface (JNI) component (none, failures, info, all) |
| log.cmgrLog.level | Severity level for the Connection Manager component (none, failures, info, all) |
| **Resource Registry** ||
| resourceRegistry.configFile | Full path, starting with /data, of the optional ITX resource registry file, if it was previously uploaded |
| **Redis Settings** ||
| redis.host | Redis host name. Must be a resolvable name on the current network. |
| redis.port | Redis port number (default is 6379) |
| redis.timeoutSeconds | Redis connection timeout in seconds |
| redis.secret | Name of the Secret object containing the Redis password, when accessing a password-enabled Redis service |
| redis.stem | Key prefix to use for all Redis keys produced and consumed by the server |
| redis.catalogCacheEnabled | Switch with true/false values to enable/disable caching cataloged map entries when registering and running cataloged maps |
| **Resource Constraints** ||
| resources.enabled | Switch with true/false values to enable/disable setting CPU and memory constraints |
| resources.requests.cpu | Requested number of CPU cores or millicores (using m suffix) |
| resources.requests.memory | Requested memory in bytes (with optional base-10 suffix like M or G, or base-2 suffix, like Mi or Gi |
| resources.limits.cpu | Upper limit number of CPU cores or millicores (using m suffix) |
| resources.limits.memory | Upper limit for memory in bytes (with optional base-10 or base-2 suffix, like Gi for gigabytes) |
| **Persistent Volumes** ||
| persistence.fsGroup | Filesystem group id for persistent volume operations, when not managed by the cluster |
| persistence.data.capacity | Capacity to request for data persistent volume. Base-10 suffixes like M and  G, or base-2 suffixes like Mi and Gi can be used.
| persistence.data.accessMode | Access mode to specify for the data persistent volume. It can be set to ReadWriteMany or ReadWriteOnce |
| persistence.data.useDynamicProvisioning | Switch with true/false values to enable/disable dynamic provisioning for the data persistent volume |
| persistence.data.storageClassName | Name of the storage class supported by the cluster to use for provisioning the data persistent volume |
| persistence.data.matchVolumeLabel.name | Name of the label to search for on the pre-defined data persistent volumes when selecting the one to bind when dynamic provisioning is disabled |
| persistence.data.matchVolumeLabel.value | Value of the specified persistent volume label to match for selecting it as the data persistent volume |
| persistence.logs.accessMode | Access mode to specify for the logs persistent volume. It can be set to ReadWriteMany or ReadWriteOnce |
| persistence.logs.useDynamicProvisioning | Switch with true/false values to enable/disable dynamic provisioning for the logs persistent volume |
| persistence.logs.storageClassName | Name of the storage class supported by the cluster to use for provisioning the logs persistent volume |
| persistence.logs.matchVolumeLabel.name | Name of the label to search for on the pre-defined logs persistent volumes when selecting the one to bind when dynamic provisioning is disabled |
| persistence.logs.matchVolumeLabel.value | Value of the specified persistent volume label to match for selecting it as the logs persistent volume |
| **SSL Settings** ||
| ssl.enabled | Switch with true/false values to enable/disable use of HTTPS protocol on the ITX Runtime Server pods |
| ssl.erviceServingCertificates | Switch with true/false values to enable/disable OpenShift service serving certificates for securing service traffic |
| ssl.clientAuth | Switch with true/false values to enable/disable validation of certificate presented by the REST API callers (mutual authentication) |
| ssl.secret | Name of the Secret object containing CA certificate, Server certificate and Server private key, in PEM format |
| **Service Settings** ||
| service.type | Type of the network service to provision, one of ClusterIP, NodePort, LoadBalancer or ExternalName |
| service.port > http | Port to expose for the HTTP traffic, when SSL is not enabled |
| service.port.https | Port to expose for the HTTPS traffic, when SSL is enabled |
| **Route Settings** ||
| route.enabled | Switch with true/false values to enable/disable creation of a Route when the application is installed |
| route.host | Host value to use for the route, or empty string for the host value to be assigned automatically |
| **Auto Scaling Settings** ||
| autoscaling.enabled | Switch with true/false values to enable/disable auto scaling of ITX Runtime Server pods |
| autoscaling.maxreplicas | Maximum number of ITX Runtime Server pods to auto scale |
| autoscaling.minreplicas | Minimum number of ITX Runtime Server pods with which to start |
| autoscaling.targetCPUUtilizationPercentage | Threshold CPU utilization percentage to scale a new ITX Runtime Server pod |
| autoscaling.targetMemoryUtilizationPercentage | Threshold memory utilization percentage to scale a new ITX Runtime Server pod |


### Redis Configuration

If you are planning to run ITX Runtime Server instances in `fenced` mode, run maps asynchronously or cache catalog entries, you must install Redis prior to installing ITX Runtime Server.

Redis installation is not included and must be obtained separately. Ensure that the Redis you install comes from a reputable source that you trust. Redis version 6.0.6 was validated with this version of ITX Runtime Server and this version or later is the recommended version to use. Older Redis versions may not function as expected when combined with this product and may need to be upgraded before they can be used.

The installed Redis service must be accessible to all ITX Runtime Server pods, at the same host URL and port, which means it must be accessible to all worker nodes to which ITX Runtime Server pods are deployed.

If the selected Redis installation requires password for authentication, you must create a Kubernetes Secret object with the Redis password to use for connecting to Redis. You may give the Secret object any name, you only need to make sure to provide that name as the `redis.secret` configuration parameter value when deploying the server. The password value must be base64-encoded and must be set in the ITX_RS_REDIS_PASSWORD key within the Secret object.

Example:
Presuming the Redis password is `mypassword`, start by based64-encoding it by running the base64 command in a Linux shell:

```
echo -n mypassword | base64
```

The above command will return base64-encoded value of the provided password. In this example the returned value will be `bXlwYXNzd29yZA==`.

Create a YAML file to store the Secret definition and store the following content in it:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: itx-rs-redis-secret
type: Opaque
data:
  ITX_RS_REDIS_PASSWORD: "bXlwYXNzd29yZA=="
```

Apply the file to your target namespace in the OpenShift cluster. You can do it from the command line using tools like kubectl or oc, or from the OpenShift web console. If you created and applied a file from the command line, you may want to permanently delete the yaml file after applying it, since it will contain the Redis password.

### SSL/TLS Configuration

Two options are available for enabling SSL/TLS communication with the ITX Runtime Server.

With the first option, a Kubernetes Secret object needs to be provided containing the server certificate, in PEM format, for the ITX Runtime Server to present during SSL handshake, and the server certificate key, also in PEM format, for the server to use for signing messages and encrypting content. If you wish to enable mutual-authentication, then you also need to provide the CA certificate, again in PEM format, that was used to sign the certificate of the clients making REST API calls to ITX Runtime Server pods and presenting their certificates. The keys that you use in the Secret object for certificate authority, server certificate and server key must be named ca.crt, tls.crt and tls.key, respectively.

You can define and manage the Secret object directly and deploy it to the namespace prior to installing ITX Runtime Server, or you can use a cert-manager tool in your cluster to generate the secret automatically and to manage the certificates and keys stored in the secret, including their expiry and rotation. The name of the secret needs to be provided when deploying ITX Runtime Server.

With the second option, the OpenShift's built-in Service Serving Certificates feature is utilized. When ITX Runtime Server is deployed, a ConfigMap with the name `itx-rs-config-ssc` is automatically created with the `service-ca` key containing PEM encoded CA certificate used for signing certificate for the deployed service. The certificate and its corresponding key are also created for the deployed service, and are stored in the automatically generated Secret object, whose `itx-rs-svc` name needs to be provided in the `ssl.secret` key field when deploying ITX Runtime server.

Step by step instructions for both options are explained next.

#### Option 1 - Produce Secret with ca.crt, tls.crt and tls.key PEM values

If you have CA certificate, server certificate and server key values in PEM format, you can create Secret object manually and deploy it to the namespace where you plan to install ITX Runtime Server. Note that if you choose to manually create **Secret** object, you assume responsibility for its lifecycle, including management of the key and certificate values they store, and restarting the pods to pick up any updates made to the Secret content.

The following is an example of a **Secret** object with the name `itx-rs-ssl-secret`. Before applying it, replace the three indicated base64 value placeholders with the base64 encoded PEM certificates and keys:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: itx-rs-ssl-secret
type: Opaque
data:
  ca.crt: "base64_ca_cert"
  tls.crt: "base64_server_cert"
  tls.key: "base64_server_key"
```

To base64 encode a PEM file and display the value in a single line for inclusion in this manifest, you can use the following command:

```
base64 --wrap=0 <file_name>
```

After applying the manifest, if you deployed it from the command line from a yaml file, you may want to delete the file after applying it, since it will contain the server certificate's private key.

In addition to providing a custom **Secret** object, you can also utilize a certificate management tool to automatically create and manage it the secret.
- You can install Jetstack cert-manager operator from the OperatorHub page in the web console for your cluster. More information is available [here](#https://cert-manager.io/docs/installation/openshift/).
- You can install IBM cert-manager operator, which is part of the IBM Common Services, and can be installed by following the following [instructions](#https://docs.redhat.com/en/documentation/openshift_container_platform/4.20/html/security_and_compliance/cert-manager-operator-for-red-hat-openshift#cert-manager-operator-install).


Upon completing the steps provided here, both Jetstack cert-manager or IBM cert-manager will produce Secret object with ca.crt, tls.crt and tls.key PEM values and will continue to manage the Secret. For example, if the secret is deleted, cert-manager will automatically create a new one.

##### Automatic restart of pods

If you use IBM cert-manager tool for certificate management, updating the managed **Secret** which contains key and certificate information bound to ITX Runtime Server pods will result in automatic restart of the pods. The new pods that start will automatically consume the updated key and certificate values from the **Secret**. If you use another tool or if you manage the **Secret** object manually, you will need to remember to restart the pods manually after updating the content of the **Secret** object for the pods to consume the new key and certificates.

To create a **Secret** object with the cert-manager tool, perform the following steps prior to installing ITX Runtime Server instance. The provided `oc` and `kubectl` commands need to be performed on the namespace in which you plan to install ITX Runtime Server instance. Ensure that namespace is specified in the current context, or explicitly include -n _namespace_ argument in the oc and kubectl commands shown below.

##### Step 1 - Create CA certificate and key

Define a certificate authority (CA) to use for signing and issuing certificates, by creating its certificate and key. You can use the openssl utility on Linux to create the key and certificate. In the following example, openssl is used to create CA certificate and key:

```
openssl genrsa -out ca.key 2048
openssl req -x509 -new -nodes -key ca.key -subj "/CN=ITX_RS_ROOT_CA" -days 3650 -out ca.crt
```

##### Step 2 - Define and apply CA Secret

Define the Secret object for the CA to contain its certificate and key:

Save the following definition to a file, for example itx-rs-ca-secret.yaml:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: itx-rs-ca-secret
data:
  tls.key: "base_64_ca_key"
  tls.crt: "base_64_ca_crt"
```

The base_64_ca_key and base_64_ca_crt values need to be replaced with the actual base64 encoded CA key and certificate. The values can be obtained by running:

```
base64 --wrap=0 ca.key
base64 --wrap=0 ca.crt
```

Apply the file:

```
kubectl apply -f itx-rs-ca-secret.yaml
```

##### Step 3 - Define and apply Issuer

###### Creating Issuer using Jetstack cert-manager

Save the following definition to a file, for example itx-rs-ca-issuer.yaml:

```
apiVersion: cert-manager.io/v1alpha2
kind: Issuer
metadata:
  name: itx-rs-ca-issuer
spec:
  ca:
    secretName: itx-rs-ca-secret
```

Apply the file:

```
kubectl apply -f itx-rs-cas-issuer.yaml
```

###### Creating Issuer using IBM cert-manager

Perform the same steps provided in the [Jetstack](#creating-issuer-using-jetstack- cert-manager) section, but perform the following change to the YAML document before applying it to the cluster namespace:

Replace the line:
```
apiVersion: cert-manager.io/v1alpha2
```
with:
```
apiVersion: certmanager.k8s.io/v1alpha1
```

##### Step 4 - Request signed certificate for server

###### Requesting Certificate using Jetstack cert-manager

Save the following definition to a file, for example itx-rs-cert.yaml:

```
apiVersion: cert-manager.io/v1alpha2
kind: Certificate
metadata:
  name: itx-rs-cert
spec:
  secretName: secret_name
  duration: 2160h # 90d
  renewBefore: 360h # 15d
  organization:
  - IBM
  isCA: false
  usages:
    - server auth
    - client auth
  dnsNames:
  - dns1
  - dns2
  issuerRef:
    name: itx-rs-ca-issuer
    kind: Issuer
```
Replace the values **dns1**, **dns2**, etc. with the names you plan to use for making REST API calls to the ITX Runtime Server. For example, for access from outside the cluster, specify the location host of the route that was created when ITX Runtime Server was deployed. Note that you can specify the location host can be automatically assigned or it can be specified via **Route Host** property when ITX Runtime Server instance is created. For accessing ITX Runtime Server inside the cluster directly through the deployed service, specify the internal host or IP address assigned to the service.

Replace the secret_name value with the name of the Secret that will be automatically created after applying the file. You will then need to provide the name of that secret in the **SSL Certificate And Key Secret** property when deploying the ITX Runtime Service.

Apply the file:

```
kubectl apply -f itx-rs-cas-issuer.yaml
```

A new Secret object should be automatically created in the namespace, containing ca.crt, tls.crt and tls.key values.

###### Requesting Certificate using IBM cert-manager

If using IBM cert-manager, perform the same steps provided in the [Jetstack](#requesting-certificate-using-jetstack-cert-manager) section, except make the following two changes to the YAML document before applying it to the cluster namespace:

1. Replace the line:
```
apiVersion: cert-manager.io/v1alpha2
```
with:
```
apiVersion: certmanager.k8s.io/v1alpha1
```
2. You may add "rotationPolicy" configuration lines after the `isCA: false` line to enforce rotation of private key when signing a new certificate the cert manager provides to replace the previous certificate.

#### Option 2 - Utilize OpenShift Service Serving Certificates

To utilize this feature, set the **Enable Service Serving Certificates** property, `ssl.serviceServingCertificates`, to true when deploying the ITX Runtime Service, and set the **SSL Certificate And Key Secret** property, `ssl.secret`, to `itx-rs-svc`, which is the name of the Secret object that is automatically created by this feature. After installing the product, notice that a new ConfigMap object `itx-rs-config-ssc` is automatically created and contains a single key with name `service-ca.crt`. It contains PEM encoded certificate of the CA used for signing certificates. Also, a Secret with the `itx-rs-svc` name is created with generated PEM certificate and key for the service. Note that this certificate is valid only for accessing the service inside the cluster.

For detailed information about the OpenShift Service Serving Certificates feature, please refer to the [OpenShift documentation](#https://docs.openshift.com/container-platform/4.20/security/certificates/service-serving-certificate.html). 

## Storage

ITX Runtime Server requires two file system based persistent volumes for its operation: `data` and `logs`. The volumes may be provisioned dynamically during the product installation, or created and installed prior to installing the product, as supported by your cluster.

If you wish to use static volume binding and you wish to initialize the `data` volume with all the maps you want to make available to the ITX Runtime Server pods immediately upon the installation, please note that you must organize the file directories in the volume as shown here:

```
/data
     /maps                          - directory for compiled maps
     /catalog                       - directory for map catalog
     /extra                         - directory for any additional JARs and shared libraries
     /tmp                           - directory for temporary files used by maps
     /mqdata                        - directory used by the bundled IBM MQ client
```

### Access Modes

Two access modes are supported: `ReadWriteMany` (RWX) and `ReadWriteOnce` (RWO). The default access mode is `ReadWriteOnce`.

Since all ITX Runtime Server pods are considered equal for handling client requests, they need to be able to process requests that reference the same maps, logs and other data artifacts in the shared data persistent volume, the storage class used for the **data** and **logs** persistent volume must support `ReadWriteMany` access mode and this mode must be selected in order for the data persistent volume claim to be satisfied and for the data storage to be successfully bound to all running pods.

In cases when all the pods are always deployed to the same worker node, such as for example development environments which may even a single node with both the worker and master role, the `ReadWriteOnce` access mode may be selected, if a storage class available in the environment supports this mode and no other storage classes are available that support `ReadWriteMany` mode.

ITX Runtime Server has been tested with the following storage providers:
 * Google Persistent Disk (RWO)
 * Rook CephFS (RWO & RWX)
 * NFS (RWO & RWX)

ITX Runtime Server supports the following storage provisioning options:
 * Dynamic provisioning using a storageClass
 * Pre-created PV's (Persistent Volumes)

### Extra Content 

The `extra` folder is used to host any JAR files, Java classes, or shared libraries that are required for running the maps but that are not included with the product and you will be providing separately. An example is JDBC and ODBC drivers to be utilized with JDBC and ODBC adapters. Since these components will be loading and executing in the ITX Runtime Server pods, it is critical that you ensure that they come from reputable sources that you trust, and that you validate them before enabling them for use with the ITX Runtime Server.

### Backup

If you are using **dynamically** provisioned persistent volumes for data and logs, be aware that these volumes will be claimed when the ITX Runtime Server instance is installed, but will be recycled after the product has been uninstalled, since at that time the persistent volume claims created by the product when it was installed will be removed as well. For dynamically provisioned persistent volumes, the assumption is that the maps and artifacts referenced by the maps will continue to be available in your source systems from which you originally uploaded them to the ITX Runtime Server environment.

Namely, ITX Runtime Server operates only on compiled maps (mmc files) which must have all originated from source maps on on-prem systems where they have been produced by compiling the map source definitions (.mms files) with tools like ITX Design Studio. The produced compiled maps are then uploaded to ITX Runtime Server. In order to be able to upload the maps again if that need arises, they need to continue to remain available at their origin. This is especially critical for the map definitions (.mms files) since they are required to be able to make updates in the future, and can always be compiled again to be uploaded to ITX Runtime Server. Backing up the original storage for those maps, especially the map sources (.mms files) is therefore of utmost importance, and is outside of scope of ITX Runtime Server deployment.

When using pre-allocated persistent volumes, you can choose to configure them with `Retain` policy in which case after uninstalling ITX Runtime Server the content of the volume will be preserved and can retrieved again by accessing the underlying storage directly or making the volume available for binding again and installing ITX Runtime Server again and pointing it to the same volume.

If you need to back up any files in the persistent volumes that were produced by the maps running under ITX Runtime Server, you must download those files individually using the provided **data** and **logs** GET APIs. Alternatively, you may choose to backup the persistent volume storage directly, if your cluster environment provides for direct access to the backing storage. Note that the **data** GET APIs work on subfolders as well, in which case the response will contain the names of all subfolders and files in that folder. This can be utilized to implement scripts which will recursively pull all the files in a given directory.

### Encryption

ITX Runtime Server does not itself perform encryption and decryption of the data at rest. To ensure the data in your persistent volumes is encrypted at rest, when defining persistent volume claims for the ITX Runtime Server, you must specify a filesystem-based storage class that is available in your cluster and supports encryption. For some storage classes, the data may be encrypted automatically by their respective storage providers, but in some cases additional manual configuration may be necessary, such as definition and enablement of encryption keys. Consult the documentation for the storage classes available in your environment for more information.

## SecurityContextConstraints Requirements

ITX Runtime Server requires a SecurityContextConstraints resource to be applied to the namespace to which the instance will be deployed. To define and apply it, please follow the instructions provided in this [support page](#https://supportcontent.ibm.com/support/pages/ibm-sterling-transformation-extender-runtime-server).
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy allows a single, non-root user"
  name: ibm-itx-rs-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: false
allowedCapabilities: null
allowedFlexVolumes: null
allowedUnsafeSysctls: null
defaultAddCapabilities: null
defaultAllowPrivilegeEscalation: false
forbiddenSysctls:
  - "*"
fsGroup:
  type: MustRunAs
  ranges:
  - max: 65535
    min: 1
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: MustRunAsRange
  uidRangeMin: 1000
  uidRangeMax: 65535
seccompProfiles:
- docker/default
seLinuxContext:
  type: RunAsAny
supplementalGroups:
  type: MustRunAs
  ranges:
  - max: 65535
    min: 1
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
priority: 0
```
From the command line, save the YAML object to a file and run the following command to apply the file content to your namespace.

```
oc apply -f <file_name> -n <namespace_name>
```

## Limitations

* ITX Runtime Server runs on supported version of Red Hat OpenShift Container Platform (RHOCP), and on Linux 64 only. This means that any maps designed to run on other platforms, such as those using adapters supported on Windows operating system only, will not be able run in ITX Runtime Server.
* Because of the unique characteristics of running workloads in Kubernetes environments compared to running them in on-prem environments, existing ITX maps may require adjustments before they can be run in ITX Runtime Server, especially if they rely on invoking custom tools or applications, or are making assumptions about the underlying host's operating system, network, local storage or other system-level resources.
* Any files referenced by the maps must assume /data/maps path as the map directory. If a maps writes to a file without specifying its path, the file will be created in the /data/maps directory.
* Deploying multiple instances of ITX Runtime Server to the same projects (namespaces) is not supported. Deploying to multiple projects (namespaces), with one instance per project, is supported.

## Scaling

ITX Runtime Server pods run independently of each other and can serve client requests that can be load balanced across them in any pattern. This includes running ITX maps asynchronously, including scenarios when one pod instance processes the REST API POST call request to run the map and another pod subsequently processes the REST API GET call request to return the status of the map execution, even if the two pods are running on different worker nodes. To access the compiled maps, the pods are accessing shared persistent volume where the compiled maps are saved, and to access statuses of the asynchronous map executions the pods are utilizing Redis queues, which is the reason Redis is required when asynchronous map calls are made.

The number of pods running at any time can be controlled through the **replicaCount** property exposed by the product. When sufficient system resources are available and have been provisioned for the newly added pods to the deployment, it will increase the ability of the deployment to handle additional workload as more pods will available to process the incoming REST API calls simultaneously.

In addition to supporting multiple pods in a single deployment (ITX Runtime Server instance), multiple deployments can be installed in the cluster, but they need to be installed in separate projects (namespaces), one instance per project. This provides for example the ability to run separate QA and Dev ITX Runtime Server deployments in the same cluster simultaneously. 

ITX Runtime Server pods can be auto scaled based on threshold target CPU or Memory utilization on the worker nodes of the cluster. Auto scaling of ITX Runtime Server pods is disabled by default in the Helm Chart for IBM Sterling Transformation Extender for Red Hat OpenShift. Enabling autoscaling option disables **replicaCount** specified in the configuration. IBM Sterling Transformation Extender for Red Hat OpenShift supports horizontal pod autoscaling, does not support vertical pod autoscaling at this time.

## Uninstalling

To uninstall ITX Runtime Server, run the following command, after replacing the `<target namespace>` placeholder with the name of the namespace from which you wish to uninstall the ITX Runtime Server deployment.

```
helm uninstall ibm-itx-rs --namespace <target namespace>
```

## Upgrades and Rollbacks

Upgrade or Rollback activity of ITX Runtime Server instances has to be performed by uninstalling the current deployment and reinstalling the ITX Runtime Server Helm Chart. Helm uninstall and install commands to be used to deploy a newer version of ITX Runtime Server Helm Chart.

## REST API Overview

The main interface the ITX Runtime Server provides is its REST APIs that it exposes and makes available to REST clients inside the cluster via its `Service` resource, and to the REST clients outside the cluster via its `Route` resource. Any REST client capable of invoking REST API methods can be used. This can for example be the `curl` command line tool, the `Postman` graphical interface tool, or a custom application that implements REST client functionality.

The REST APIs exposed by the ITX Runtime Server are documented in OpenAPI 3.0 specification format. You can explore the APIs by pointing your web browser to `<location>/itx-rs/api-docs?url=/itx-rs/openapi.json` where `<location>` is the location exposed by the `Route` resource in your ITX Runtime Server instance. The API specification document can also be retrieved in JSON format from: `<location>/itx-rs/openapi.json`. In addition to OpenAPI 3.0 version, the REST APIs are also represented in Swagger 2.0 version. You can explore the API in this format in the web browser by pointing it to `<location>/itx-rs/api-docs?url=/itx-rs/swagger.json` or you can download the corresponding JSON specification document from `<location>/itx-rs/swagger.json`.

The REST API documentation provides details on the methods included in the API. At a high level, the methods included in the API can be categorized as follows:

- API methods for obtaining general information from the `Pod` resources in the Runtime Server instance, such as their version and configuration details
- API methods for deploying (uploading) maps, when they have not been pre-loaded to the persistent data volume bound to the ITX Runtime Server instance
- API methods for optional cataloging of maps and exposing the map entries as their own REST API endpoints
- API methods for invoking deployed maps, in synchronous or asynchronous mode, and directly or indirectly through their catalog entries.

The cataloged maps are exposed as separate REST endpoints. Each of those endpoints define which map to run and the mode in which to run it, which is specified. You can explore the generated REST endpoints for the cataloged maps by pointing your web browser to `<location>/itx-rs/api-docs?url=/itx-rs/v1/docs` where `<location>` is the location exposed by the `Route` resource in your ITX Runtime Server instance. You can also retrieve the corresponding OpenAPI 3.0 specification document in JSON format from `<location>/itx-rs/v1/docs`. In addition to OpenAPI 3.0 version, the cataloged map REST endpoints are also made available in Swagger 2.0 version. You can explore the API in this format in the web browser by pointing it to `<location>/itx-rs/api-docs?url=/itx-rs/v1/docs/2.0` or you can download to corresponding JSON specification document from `<location>/itx-rs/v1/docs/2.0`.

### Synchronous and asynchronous map invocation

A map can be invoked synchronously, in which case the results of the map run are provided in the REST response, or asynchronously, in which case the response is a reference to the map status endpoint, which can be polled to check on the map status. Asynchronous mode requires Redis installation.

### Direct and cataloged map invocation

Maps can be invoked directly, by referencing them using the location and name that was specified when they were uploaded, or as cataloged objects, by calling their respective REST endpoints, if they were previously cataloged.

### Fenced and unfenced run mode

Lastly, maps can be invoked in one of two modes - fenced and unfenced. In fenced mode, the maps run in the same container as the REST server, but in a separate worker process. If a map results in a failure that causes its worker process to terminate, the REST server process continues to run and creates a new worker process instance to which to delegate map execution. In unfenced mode, a single process is used to serve the ITX endpoints and to run maps. Fenced mode requires Redis installation. 

### Bulk Copy 

ITX Runtime Server Data API allows deploying a single file to the data volume. You can deploy a collection of files organized in a directory structure included in a zip file which gets extracted under data volume. Bulk copy requires a special action header, **rs-action: unpack**, to be included while invoking Data API. It is a POST operation to create a single file or multiple files on the data volume. The Data API can be used to transfer a single file or multiple files under any directory level within the data volume.

Transferring a single file or multiple files to the data volume is required before running a map under ITX Runtime Server unless the volume is prepopulated with the required files. There are other ways to copy files to the data volume, for example, **oc cp** command for OpenShift allows copying the file from local using the container identifier and vice-versa. Using Data API provides a consistent and easy-to-use mechanism for copying single or multiple files to a data volume.

The example curl command using route name with HTTP protocol is as following: 
```bash
curl -F "data=@/mydir/myfiles.zip" -H "rs-action: unpack" "http://<route_name>/itx-rs/v1/data/maps"
```
Executing the example command above results in unpacking the myfles.zip file after it is deployed to the ITX Runtime Server. ITX Runtime Server retains the same directory structure as in the zip file under target directory, /data/maps , while unpacking the contents of the zip file.

## Deployment Guidelines

### GDPR

Users of ITX Runtime Server are responsible for ensuring their own compliance with various laws and regulations, including the European Union General Data Protection Regulation (GDPR). Users are solely responsible for obtaining advice of competent legal counsel as to the identification and interpretation of any relevant laws and regulations that may affect the user's business and any actions the user may need to take to comply with such laws and regulations.

The products, services, and other capabilities described herein are not suitable for all user situations and may have restricted availability. HCL and IBM do not provide legal, accounting, or auditing advice or represent or warrant that its services or products will ensure that users are in compliance with any law or regulation.

For more information about GDPR, please refer to:
- [EU GDPR Information Portal](https://ec.europa.eu/info/law/law-topic/data-protection_en)
- [IBM GDPR website](http://ibm.com/GDPR)

ITX Runtime Server enables an organization to integrate industry-based customer, supplier and business partner transactions across the enterprise. It helps automate complex transformation and validation of data between a range of different formats and standards. Securing and managing the personal data passed through the ITX Runtime Server for processing is a sole responsibility of the user. Some of the security guidelines that follow may help in securing the personal data:

- Harden the master and worker nodes in the cluster based on security benchmarks like CIS Benchmarks
- Harden the Red Hat Enterprise Linux OS based on security benchmarks like CIS Benchmarks
- Secure the communication with ITX Runtime Server using HTTPS protocol instead of HTTP
- Secure the credentials of external systems accessed by ITX Runtime Server using AES-256 encryption in Resource Registry
- Use secure options provided by the data source/target adapters where applicable to securely process the data
- Encrypt and decrypt the data, process data through ITX Runtime Server's Cipher and OpenPGP adapters
- Secure the transport of data from/to maps run by ITX Runtime Server with HTTPS, FTPS adapters
- Cataloged maps would allow hiding the details of the map location, overrides of the deployed maps
- Monitor the outputs generated by the ITX Runtime Server, remove input and output files when not required
- Look out for security bulletins from ITX and Red Hat support teams to resolve security vulnerabilities
- Apply the security patches when released and keep the cluster nodes up to date to avoid security threats
- Refer ITX Knowledge Center and Red Hat OpenShift documentation on the security features available in the products
- Scan map and input files for malware/virus before uploading to the data volume through application endpoint
- Scan driver files and user-defined exit modules for malware/virus before uploading through application endpoint

### CIS Benchmarks

CIS Benchmarks are best practices for the secure configuration of a target system. CIS Benchmarks are developed through a unique consensus-based process comprised of cybersecurity professionals and subject matter experts around the world. CIS benchmark guides are developed and accepted by government, business, industry, and academia.

CIS Benchmarks for Kubernetes and Red Hat OpenShift Container platform environments are available for download from the [CIS Benchmarks website](https://learn.cisecurity.org/benchmarks). These benchmark guides provide information on hardening the master and worker nodes in the OpenShift cluster. Guidance on hardening the Red Hat Enterprise Linux OS can be found in the [Red Hat documentation](https://docs.redhat.com/en/documentation/openshift_container_platform/4.20/html/security_and_compliance/container-security-1#security-hardening). 

ITX Runtime Server has been hardened to a level that satisfies the IBM certification requirements for Container Software. Users are responsible for hardening of the nodes in the cluster that meets their security policies and requirements. 

## Auditing

IBM License Service provides license consumption reporting and audit readiness for IBM containerized software. IBM License Service is useful to any customer that wants to view and understand the license consumption of IBM Certified Container Software running on a Red Hat OpenShift cluster. For information about deploying IBM License Service and tracking license usage of standalone IBM Certified Container software, please check the [license tracking](https://www.ibm.com/docs/en/cpfs?topic=platforms-tracking-license-usage-stand-alone-containerized-software) page.

License audit snapshot is a record of license usage in your environment over a period of time. The audit snapshot is a compressed .zip package that includes a complete set of audit documents that certify your cumulative license usage. Audit snapshot is needed for compliance and audit purposes. For core license metrics, user is obliged to use License Service and periodically generate audit snapshots to fulfill container licensing requirements. For more information about core license metrics, see [Reporter metrics](https://www.ibm.com/docs/en/cloud-paks/cp-integration/2021.4?topic=service-reported-metrics).

You do not need to complete any manual actions to prepare the license audit snapshot; you only need to generate it. At this point, the license audit snapshot is required to be generated at least once a quarter, and stored for two years in a location from which it could be retrieved and delivered to auditors. Refer to [retrieving audit page](https://www.ibm.com/docs/en/cpfs?topic=pcfls-apis#auditSnapshot) for more information on capturing license audit snapshot for compliance and audit purposes.

Note: The requirements might change over time. You should always make sure to follow the latest requirements that are posted on Passport Advantage.

## Documentation

For general information about the IBM Sterling Transformation Extender product portfolio, please check the [Overview]( https://www.ibm.com/products/transformation-extender) page.

For more technical details about IBM Sterling Transformation in general, including designing and compiling ITX maps with the ITX Design Studio for use with ITX Runtime Server, please refer to the ITX [Knowledge Center](https://www.ibm.com/docs/en/ste/10.1.2).

For additional information about the IBM Sterling Transformation Extended Runtime Server product, please refer to this [support page](https://www.ibm.com/support/pages/node/7068837).
