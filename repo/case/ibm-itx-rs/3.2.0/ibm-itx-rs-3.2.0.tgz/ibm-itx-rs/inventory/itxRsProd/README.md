# Readme

README document for Helm Chart for IBM&reg; Sterling Transformation Extender for Red Hat OpenShift 11.0.3
<br>&copy; Copyright IBM Corporation 2024, 2026 All rights reserved.
<br>Program Number : 5724-Q23 

## Prerequisites

This distribution is tested on Red Hat OpenShift 4.20. The OCP project must have access to "redis" to run maps in fenced mode or asynchronously. This deployment is tested with redis-operator 7.22.0 which has been provisioned from OpenShift's OperatorHub.

### PodDisruptionBudgets

The configured deployment does not specify a disruption bugdet. Each consumer of this transformation logic should consider how disruption might impact any specific process.

### SecurityContextConstraints Requirement

The Helm chart of this distribution requires a specific type of `SecurityContextConstraints` to be defined and bound to the user or service account of the installation. The predefined `SecurityContextConstraints`, [`nonroot-v2`](https://docs.openshift.com/container-platform/4.20/authentication/managing-security-context-constraints.html), has been verified for this chart.  If your user or service account is bound to this `SecurityContextConstraints` resource, you can proceed to install the chart.

Below is a custom `SecurityContextConstraints` (SCC) which can be used for finer control of the permissions and capabilities needed to install this chart. It is modeled after the predefined `nonroot-v2` SCC but with the added restriction of only permitting user and group ID, 1001, which is required by the IBM&reg; Sterling Transformation Extender Runtime Server (ITX RS).
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy allows a single, non-root user"
  name: ibm-itx-rs-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: false
allowedCapabilities: 
- NET_BIND_SERVICE
allowedFlexVolumes: null
allowedUnsafeSysctls: null
defaultAddCapabilities: null
defaultAllowPrivilegeEscalation: false
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
seccompProfiles:
- runtime/default
runAsUser:
  type: MustRunAs
  uid: 1001
fsGroup:
  type: MustRunAs
  ranges:
  - max: 1001
    min: 1001
supplementalGroups:
  type: RunAsAny
seLinuxContext:
  type: MustRunAs
volumes:
- configMap
- csi
- downwardAPI
- emptyDir
- ephemeral
- nfs
- persistentVolumeClaim
- projected
- secret
priority: 0
```
From the command line, save the YAML object to a file and run the following command.
``` { .shell }
oc apply -f <file_name>
```
For ITX RS installation details, please see this [support page](https://www.ibm.com/support/pages/node/7274354).

---
