# Name

IBM&reg; Sterling Transformation Extender for Red Hat OpenShift 11.0.3
<br>&copy; Copyright IBM Corporation 2024, 2026 All rights reserved.
<br>Program Number : 5724-Q23 


# Introduction

## Summary

IBM&reg; Sterling Transformation Extender (ITX) for Red Hat OpenShift (RHOS) is a containerized distribution of the translation engine exposing a set of REST API endpoints that you can invoke to run ITX maps and flows. Another name for IBM Sterling Transformation Extender for Red Hat OpenShift is ITX Runtime Server. Maps are designed using either ITX Design Studio or Design Server.  The ITX Design Server can also wire together existing maps into flows, which enable greater integrations and new transformation capabilities.  Maps are compiled and flows are packaged together for deployment and execution on a Linux 64 platform. ITX Design Studio and Design Server are separate components from ITX Runtime Server. While ITX Design Studio must be installed and run locally on a Windows host, the ITX Design Server may be run on either a Windows or Linux host. When you obtain access to the ITX Runtime Server component, you will be provided with instructions explaining how to obtain the ITX Design Studio and Design Server components as well.

For additional high-level overview of the ITX Runtime Server product, refer to this [support page](https://www.ibm.com/support/pages/node/7274354).

## Features

The following is a list of high-level features provided by the ITX Runtime Server:

- Uploading, listing, downloading and deleting compiled ITX maps and other files
- Listing and downloading generated REST API server and map execution engine log files
- Fenced (REST API server and map execution engine running in the same process) and unfenced (REST API server and map execution engine running in separate processes) run mode.
- Synchronous and asynchronous map executions
- Cataloging support for the maps, with the REST API endpoints automatically generated for the produced map catalog entries
- Direct map execution and execution via cataloged map REST APIs
- Ability to override map inputs and outputs with the REST API request and response data

In addition to the previous features, which are specific to Version 1 (V1) of the ITX REST API, the following is a list of additional capabilities that are provided by the ITX Runtime Server:
- Integration with Design Server. Using the Design Server graphical interface, both maps and flows can be deployed to a Runtime Server installation and monitored.
- Flow and map executions are supported by using Version 2 of the REST API.
- The watch functionality of flows allows listeners to be deployed to a Runtime Server.
- Automated map and flow deployments are available via Cloud Object Storage (COS).
- Synchronous and asynchronous map and flow executions.
- Horizontal pod autoscaling with support for custom metrics and behavior policies.

# Details

## Prerequisites

ITX Runtime Server requires Red Hat OpenShift cluster version 4.20. It is supported on Linux 64 clusters only. When compiling maps in ITX Design Studio, you must choose the option to compile them for Linux 64 platform. Alternatively, or you can use multi-platform composite maps, at the cost of increased map size. 

Redis installation is required only if you plan to run the ITX Runtime Server in fenced mode, use the V1 REST API for asynchronous map invocations or use the V2 REST API. Refer to the [`Redis Configuration`](#redis-configuration) section for more details.

Two filesystem-based persistent volumes must be provisioned for the ITX Runtime Server to be operational. If you plan for the ITX Runtime Server pods to be distributed across multiple nodes, the volumes must support ReadWriteMany bind option so that they can be bound by all pods in the installation. Refer to the [`Storage`](#storage) section for more details.

### Resources Required

The requested and the maximum Memory and CPU size, as well as the storage capacity can be specified when configuring an ITX Runtime Server instance. The following requested values are selected by default:

| Memory (Gi) | CPU (millicores) | Disk (Gi) | Nodes |
| ----------- | ---------------- | --------- | ----- |
| 4           | 1000             | 10        | 1     |

Note that if you choose to run ITX Runtime Server instance in `fenced` mode, the REST service process will run separately from the map execution worker process. Therefore, two Java Virtual Machine (JVM) processes will created, which should be taken into account when planning system resources, especially memory.

The storage class that you choose to use for persistent volumes must be of **filesystem** type.

Following table shows different configuration profiles, the minimum configuration advisable to set up for the ITX Runtime Server: 

| Profile     | Memory (Gi) | CPU (millicores) | Disk (Gi) | Nodes                        |
| ----------- | ----------- | ---------------- | --------- | ---------------------------- |
| Starter     | 4           | 1000             | 10        | 1 (master and worker node)   |
| Development | 4           | 2000             | 25        | 3 (1 master, 2 worker nodes) |
| Production  | 16          | 4000             | 50        | 5 (2 master, 3 worker nodes) |

NOTE: User should adjust the above suggested configuration based on their transformation needs, by updating the 'resources' and 'persistence' sections in values.yaml.

# Installing

## Installing ITX Runtime Server from Command Line

ITX Runtime Server can be installed in an online (connected) or offline (air gapped) cluster using command line tools.

- Download and install `cloudctl`, `oc` and `helm` command line tools. In case of offline installation, the tools need to be downloaded to the bastion server (if using bastion), or to the portable device (if not using bastion). The CASE containing this README needs to be saved to the same machine to which the tools are downloaded.

  - [oc](https://docs.openshift.com/container-platform/4.20/cli_reference/openshift_cli/getting-started-cli.html) - for interacting with the OpenShift Cluster
  - [cloudctl](https://github.com/IBM/cloud-pak-cli) - for interacting with this CASE
  - [helm](https://helm.sh/docs/intro/install/) - for installing and configuring the embedded chart

Open a Linux shell on the machine with the downloaded tools and this CASE and go to the directory containing the `case` directory for the CASE. All `cloudctl` commands shown below must be run from that directory. 

NOTE: `cloudctl case` usage is deprecated. `cloudctl case` usage when discontinued should be replaced with `oc ibm_pak` in the below command lines after `ibm_pak` plugin for `oc` command line tool has been installed.

## Installing in an Online Cluster through CASE<a id="install-through-CASE"></a>

Run the following command to install the catalog source to the `ibm-itx` namespace in your cluster.  You may choose a namespace different from ``ibm-itx``.

```bash
cloudctl case launch         \
    --case case/ibm-itx-rs   \
    --namespace ibm-itx      \
    --inventory itxRsProd    \
    --args "-accept unknown" \
    --action install
```
Use the `--args ""` parameter to pass additional arguments to the helm installer.  For example, `--args "--set persistence.data.capacity=40Gi"` expands the default size of 10Gi specified in `values.yaml`.

Also, the ``-accept`` value must be passed in the ``--args`` string once you have read and agreed to the product licensing.  The product will not operate until this value is set to "true".

## Installing in an Online Cluster through Native ``helm`` CLI Commands<a id="install-through-helm"></a>

Run the following command, after replacing the `<target_namespace>` placeholder with the name of the namespace to which you wish to install the helm chart.

```bash
helm install ibm-itx-rs               \
    --namespace <target_namespace>    \
    --set license=false               \
    ./charts/ibm-itx-rs-prod
```

NOTE: You must read and accept the product licensing terms by using --set license=true in the above command line. The product will not operate until this value is set to "true".

## Installing in Air-Gapped (Offline) OpenShift Cluster

### 1. Prepare Bastion Host or Portable Device

* Logon to the bastion machine, and verify that it has access to:

  * the public Internet (to download images from the source image registry)
  * the target image registry (where the images will be mirrored)
  * the target OpenShift cluster, to which to install the helm chart

If a bastion machine is not available, you can use a portable device (such as laptop) instead, which you must be able to carry into the air gapped environment to connect to the target cluster.

The remaining steps should be run from the bastion machine (portable device).

Open Linux shell and go to the directory that contains the `case` folder for this CASE. All the remaining `cloudctl` commands must be run from this directory.

#### 2. Prepare CASE

Prepare the CASE files used by the process. Create a temporary directory used during the process:

```bash
$ mkdir /tmp/cases
```
Run the following command:

```bash
$ cloudctl case save --case case/ibm-itx-rs --outputdir /tmp/cases
Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```
A set of .tgz and .csv files will be created in `/tmp/cases` folder.

Note: The following `cloudctl case launch` commands all include `<target_namespace>` argument. The `ConfigureClusterAirgap`, `mirror-images` and `mirror-images` actions do not operate on the target cluster and this argument can be omitted. 

### 3. Configure Registry Auth

1. Authenticate with the source image registry (Entitled Registry)

Run the following command after replacing the `<target_namespace>` placeholder with the name of the namespace to which you wish the secret to be created, and after replacing `<password>` placeholder with the password (API key) you have received with your entitlement.

```bash
$ cloudctl case launch               \
    --case case/ibm-itx-rs           \
    --namespace <target_namespace>   \
    --inventory itxRsProd            \
    --action configureCredsAirgap    \
    --args "--registry cp.icr.io --user <user> --pass <password>"
```

The credentials will be saved to `~/.airgap/secrets/cp.icr.io.json`

2. Authenticate with the target image registry.

Note: This step can be skipped if the target registry does not require authentication.

Run the following command, after replacing the `<target_namespace>` placeholder with the name of the namespace to which you wish the secret to be created, and after replacing `<target_registry>`, `<user>` and `<password>` placeholders with the registry, user and password for the target image registry.

```bash
$ cloudctl case launch               \
    --case case/ibm-itx-rs           \
    --namespace <target_namespace>   \
    --inventory itxRsProd            \
    --action configureCredsAirgap    \
    --args "--registry <target_registry> --user <user> --pass <password>"
```

The credentials will be saved to `~/.airgap/secrets/<target_registry>.json`

### 4. Mirror Images

In this step, the container image for ITX Runtime Server is copied to the target registry in the airgap environment. This generates calls to the `oc image mirror` command which copies the images over. Run the following command after replacing the `<target_namespace>` placeholder with the name of the target namespace for the image, and after replacing the `<target_registry>` placeholder with the name of the target image registry.

```bash
$ cloudctl case launch              \
    --case case/ibm-itx-rs          \
    --namespace <target_namespace>  \
    --inventory itxRsProd           \
    --action mirror-images          \
    --args "--registry <target_registry> --inputDir /tmp/cases"
```
### 5. Configure Cluster for Airgap

If portable device was used instead of the bastion server, carry the device to the air gapped environment with the target OpenShift cluster, and make sure it has connection to the cluster.

This step does the following:

* creates a global image pull **Secret** for the target registry (skipped if target registry is unauthenticated)

* creates a **ImageSourceContentPolicy** object with mirror settings

WARNING:

* Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in `/nfshome/aimbuild/.airgap/secrets and /tmp/airgap*` to support this action

* Applying ImageSourceContentPolicy causes cluster nodes to recycle. Run the following command after replacing the `<target_namespace>` placeholder with the name of the target namespace for the helm chart, and after replacing the `<target_registry>` placeholder with the name of the target image registry.

```bash
cloudctl case launch                    \
    --case case/ibm-itx-rs              \
    --namespace <target_namespace>      \
    --inventory itxRsProd               \
    --action ConfigureClusterAirgap     \
    --args "--registry <target_registry> --inputDir /tmp/cases"
```

### 6. Install ITX definitions to the cluster

Follow the instructions in [Installing in an Online Cluster through CASE](#install-through-CASE) section,
or the instructions in [Installing in an Online Cluster through Native ``helm`` CLI Commands](#install-through-helm) section.

With either method, provide the "--set image.repository=<target_registry>" command argument.

## Verifying Installation

Once you have installed the ITX Runtime Server, and have used it to deploy an ITX Runtime Server instance, you can test accessing the instance by invoking the `version` and `configuration` endpoints on it, after replacing `<location>` with the location of the `Route` resource deployed with the instance:

`<location>/tx-rest/v1/itx/version`

`<location>/tx-rest/v1/itx/configuration`

The `version` endpoint returns JSON document with information about the product name and version. The `configuration` endpoint returns JSON document with the configuration options and values that you specified when you deployed the instance, which you can as additional confirmation that the instance was configured as expected.

## Configuration

The configuration settings of the Helm chart's "values.yaml" file for the Runtime Server can be broken down into the following logical groups:

* REST settings (V1 or V2 API installation, image details, service account, custom environment variables,
replica count)
* Probe settings (liveness, readiness)
* Map and Flow settings (map threads, file extension, etc.)
* Logging (log severity, log name uniqueness, log targets, etc.)
* Resource utilization (memory, CPU, storage, replica count)
* Redis configuration (host, port, password, etc.)
* Storage settings (storage class, capacity, dynamic vs. static binding, etc.)
* TLS configuration (certificates, keys, etc.)
* Cloud Object Storage settings

The Runtime Server supports two installation modes as follows:

* V1 installation mode
* V2 installation mode

The default V1 mode only supports the V1 API, as enabled by the `restV1.deploy` parameter.  The V2 mode, which is disabled by default, supports both the V2 and V1 APIs, as enabled by the `rest.deploy` parameter. The V2 mode requires an external Redis installation, which is needed for coordination between the REST and Executor components. The V1 mode does not require an external Redis installation if the server is run in `unfenced` mode, which is the default. The V1 mode can be used simultaneously with the V2 mode only if the V1 installation is `unfenced`, as per the `restV1.runMode` parameter. 

The V1 mode supports scaling the number of ITX Runtime Servers, as per the `restV1.replicas` parameter. The V2 mode uses an alternate form of scaling where a single ITX Runtime Server provides messages to one or more execution pods, as per the `executor.replicas` parameter. Horizontal pod autoscaling (HPA) is supported for both modes (see `restV1.autoscaling.enabled` and `executor.autoscaling.enabled`.

For further details on all ITX Runtime Server configuration settings, see the Helm installation's values.yaml and README.md files. The parameters in the `config` section of the values.yaml file enables the ITX configuration settings in the config.yaml file to be overridden with values that are specific for each installation. Each config.yaml setting is referenced under the `config` section according to camel case convention, whereby the first letter of a named setting is lowercase while any remaining words in the name start with a capital letter.

Whenever changes are made to the below parameters during a Helm upgrade, the pods that are associated with the existing installation will not automatically restart - unless the change affects the actual deployment manifest. For example, an update to the image name or resource metrics will change the deployment manifest of the installation, which in turn will trigger an automatic restart of the pods. However, a basic change to a parameter that is linked to the ITX config.yaml file, such as the logging level, will not trigger an automatic restart. The restart would need to take place manually, as provided by the Kubernetes scale command.

### License parameter

| Parameter                              | Description                                                     | Default         |
| -------------------------------------- | --------------------------------------------------------------- | --------------- |
| `license`              | License acceptance                                           | `false`  |

### Global parameters

| Parameter                              | Description                                                     | Default         |
| -------------------------------------- | --------------------------------------------------------------- | --------------- |
| `global.itxImageRegistry`              | Container image registry and namespace                          | `"cp.icr.io/cp"`   |
| `global.itxImagePullSecret`            | Container registry pull secret                                  | `"ibm-encryption-key"` |
| `global.persistence.rwxStorageClassV3` | Optional storage class with RWX mode to use for PV provisioning | `""`            |
|                                        |                                                                 |                 |

### Shared parameters

| Parameter             | Description                                                 | Default                                                        |
| --------------------- | ----------------------------------------------------------- | -------------------------------------------------------------- |
| `displayName`         | Display name for ITX RS deployment                          | `"IBM Sterling Transformation Extender for Red Hat OpenShift"` |
| `nameOverride`        | Name override for the install                               | `""`                                                           |
| `fullnameOverride`    | Full name override for the install                          | `""`                                                           |
| `itxImageRegistry`    | Container image registry and namespace                      | `"cp.icr.io/cp"`                                               |
| `itxImagePullSecret`  | Container registry pull secret                              | `"ibm-encryption-key"`                                         |
| `shutdownTimeSeconds` | Grace period for map/flow completion before ITX RS shutdown | `0`                                                            |
|                       |                                                             |                                                                |

### REST V1-based deployment parameters

| Parameter                                 | Description                                              | Default                 |
| ----------------------------------------- | -------------------------------------------------------- | ----------------------- |
| `restV1.deploy`                           | Deploy **restV1** component                              | `true`              |
| `restV1.runMode`                          | Run mode (`"fenced"`, `"unfenced"`)                      | `"unfenced"`              |
| `restV1.redisStem`                        | Redis stem                                               | `"tx-rest-v1"`           |
| `restV1.cacheType`                        | Cache type                                               | `"internal"`              |
| `restV1.replicas`                         | Replicas                                                 | `1`              |
| `restV1.inbound.http.enabled`             | Enable HTTP inbound connection                           | `true`                  |
| `restV1.inbound.https.enabled`            | Enable HTTPS inbound connection                          | `false`                 |
| `restV1.inbound.https.secret`             | TLS secret for the inbound HTTPS connection              | `""`                    |
| `restV1.inbound.https.serviceServingCertificates`| RHOS provisioned certificate              | `false`                    |
| `restV1.inbound.https.clientAuth`                | Enforce caller authentication (mTLS)      | `false`                 |
| `restV1.serviceAccount.create`                 | Create **restV1** service account                                  | `false`                 |
| `restV1.serviceAccount.annotations`            | Annotations to add to the **restV1** service account               | `""`                    |
| `restV1.serviceAccount.existingName`           | Name of pre-existing **restV1** service account                     | `""`                    |
| `restV1.service.type`                          | Service type (`"ClusterIP"`, `"NodePort"`, `"LoadBalancer"`)              | `"ClusterIP"`             |
| `restV1.service.port.http`                     | Service port for HTTP inbound connection                            | `8080`                  |
| `restV1.service.port.https`                    | Service port for HTTPS inbound connection                           | `8443`                  |
| `restV1.synchronousTimeout`                    | Timeout (in seconds) for synchronous REST API v2 calls              | 300                     |
| `restV1.extraEnvConfigMap`                     | ConfigMap with custom environment variables                         | `""`                    |
| `restV1.extraEnvSecret`                        | Secret with custom environment variables                            | `""`                    |
| `restV1.probes.liveness.enabled`               | Enable liveness probe                                               | `true`                  |
| `restV1.probes.liveness.initialDelaySeconds`   | Delay in seconds for initial liveness probe                         | `35`                    |
| `restV1.probes.liveness.periodSeconds`         | Duration in seconds between liveness probes                         | `20`                    |
| `restV1.probes.liveness.successThreshold`      | Liveness probe success threshold                                    | `1`                     |
| `restV1.probes.liveness.failureThreshold`      | Liveness probe failure threshold                                    | `3`                     |
| `restV1.probes.readiness.enabled`              | Enable readiness probe                                              | `true`                  |
| `restV1.probes.readiness.initialDelaySeconds`  | Delay in seconds for initial readiness probe                        | `35`                    |
| `restV1.probes.readiness.periodSeconds`        | Duration in seconds between readiness probes                        | `20`                    |
| `restV1.probes.readiness.successThreshold`     | Readiness probe success threshold                                   | `1`                     |
| `restV1.probes.readiness.failureThreshold`     | Readiness probe failure threshold                                   | `3`                     |
| `restV1.resources.requests.cpu`                | Mimimum CPU resources                                               | `"250m"`                  |
| `restV1.resources.requests.memory`             | Minimum memory resources                                            | `"700Mi"`                 |
| `restV1.resources.limits.cpu`                  | Maximum CPU resources                                               | `"4000m"`                 |
| `restV1.resources.limits.memory`               | Maximum memory resouces                                             | `"8Gi"`                   |
| `restV1.nodeSelector`                          | Node selector map                                                   | `{}`                    |
| `restV1.tolerations`                           | Tolerations array                                                   | `[]`                    |
| `restV1.affinity`                              | Pod and Node affinity map                                           | `{}`                    |
| `restV1.autoscaling.enabled`                   | Horizontal pod autoscaling enabled                                  | `false`                 |
| `restV1.autoscaling.minReplicas`               | Minimum pod count                                                   | `1`                 |
| `restV1.autoscaling.maxReplicas`               | Maximum pod count                                                   | `10`                 |
| `restV1.autoscaling.cpu.enabled`               | CPU utilization monitoring                                          | `true`                 |
| `restV1.autoscaling.cpu.averageUtilization`    | CPU average utilization threshold                                   | `80`                 |
| `restV1.autoscaling.memory.enabled`            | Memory utilization monitoring                                       | `true`                 |
| `restV1.autoscaling.memory.averageUtilization` | Memory average utilization threshold                                | `80`                 |
| `restV1.autoscaling.custom.enabled`            | Custom metric type monitoring                                       | `false`              |
| `restV1.autoscaling.custom.types`              | Custom metric type definitions                                      | `[]`                 |
| `restV1.autoscaling.behavior`                  | Behavior policies for scaling up or down                            | `{}`                 |
|                                                |                                                                     |                      |

### REST V2-based deployment parameters

| Parameter<sup>1</sup>                          | Description                                                           | Default                 |
| ---------------------------------------------- | --------------------------------------------------------------------- | ----------------------- |
| `rest.deploy`                                  | Deploy **rest** component                     | `false`                     |
| `rest.image.repository`                        | Container image registry & repository         | `"cp.icr.io/cp/ibm-itx-rs"` |
| `rest.image.tag`                               | Container image tag                           | `"11.0.3.0.20260625"`      |
| `rest.image.digest`                            | Container image digest                        | `sha256:04de9e2bc047b42ba6c980e0fdf435eca168c0b16eaa4d2dd9cf2fcb2c077f55`    |
| `rest.image.pullPolicy`                        | Container image pull policy                              | `"IfNotPresent"`          |
| `rest.image.pullPolicyOverride`                | Container image pull policy override                     | `false`          |
| `rest.mapFileExtension`                        | Compiled map file extension                              | `"mmc"`                   |
| `rest.redisStem`                               | Redis stem                                               | `"tx-rest"`                   |
| `rest.cacheType`                               | Cache type                                               | `"external"`              |
| `rest.persistence.data.enabled`                | Persistence volume exists for **data** volume            | `true`                |
| `rest.persistence.data.existingClaim`          | Existing PVC for the **data** volume                     | `""`                    |
| `rest.persistence.data.useDynamicProvisioning` | Enables dynamic provisioning for the **data** PVC        | `false`                 |
| `rest.persistence.data.storageClass`           | Storage class name for the **data** PVC                  | `""`                    |
| `rest.persistence.data.accessMode`             | Access mode for the **data** PVC                         | `"ReadWriteOnce"`         |
| `rest.persistence.data.size`                   | Requested storage size for the **data** PVC              | `"20Gi"`                  |
| `rest.persistence.data.annotations`            | Annotations for the **data** PVC                         | `{}`                    |
| `rest.persistence.logs.enabled`                | Persistence volume exists for **logs** volume            | `true`                |
| `rest.persistence.logs.existingClaim`          | Existing PVC for the **logs** volume                     | `""`                    |
| `rest.persistence.logs.useDynamicProvisioning` | Enables dynamic provisioning for the **logs** PVC        | `false`                 |
| `rest.persistence.logs.storageClass`           | Storage class name for the **logs** PVC                  | `""`                    |
| `rest.persistence.logs.accessMode`             | Access mode for the **logs** PVC                         | `"ReadWriteOnce"`         |
| `rest.persistence.logs.size`                   | Requested storage size for the **logs** PVC              | `"100Mi"`                 |
| `rest.persistence.logs.annotations`            | Annotations for the **logs** PVC                         | `{}`                    |
| `rest.inbound.http.enabled`                    | Enable HTTP inbound connection                           | `true`                  |
| `rest.inbound.https.enabled`                   | Enable HTTPS inbound connection                          | `false`                 |
| `rest.inbound.https.secret`                    | TLS secret for the inbound HTTPS connection              | `""`                    |
| `rest.inbound.https.serviceServingCertificates`| RHOS provisioned certificate              | `false`                    |
| `rest.inbound.https.clientAuth`                | Enforce caller authentication (mTLS)      | `false`                 |
| `rest.serviceAccount.create`                   | Create **rest** service account                                     | `false`                 |
| `rest.serviceAccount.annotations`              | Annotations to add to the **rest** service account                  | `""`                    |
| `rest.serviceAccount.existingName`             | Name of pre-existing **rest** service account                       | `""`                    |
| `rest.service.type`                            | Service type (`"ClusterIP"`, `"NodePort"`, `"LoadBalancer"`)              | `"ClusterIP"`             |
| `rest.service.port.http`                       | Service port for HTTP inbound connection                            | `8080`                  |
| `rest.service.port.https`                      | Service port for HTTPS inbound connection                           | `8443`                  |
| `rest.synchronousTimeout`                      | Timeout (in seconds) for synchronous REST API v2 calls              | 300                     |
| `rest.groupId`                                 | Logical id for aggregating dashboard reports of **rest** instances  | `"1"`                   |
| `rest.extraEnvConfigMap`                       | ConfigMap with custom environment variables                         | `""`                    |
| `rest.extraEnvSecret`                          | Secret with custom environment variables                            | `""`                    |
| `rest.probes.liveness.enabled`                 | Enable liveness probe                                               | `true`                  |
| `rest.probes.liveness.initialDelaySeconds`     | Delay in seconds for initial liveness probe                         | `35`                    |
| `rest.probes.liveness.periodSeconds`           | Duration in seconds between liveness probes                         | `20`                    |
| `rest.probes.liveness.successThreshold`        | Liveness probe success threshold                                    | `1`                     |
| `rest.probes.liveness.failureThreshold`        | Liveness probe failure threshold                                    | `3`                     |
| `rest.probes.readiness.enabled`                | Enable readiness probe                                              | `true`                  |
| `rest.probes.readiness.initialDelaySeconds`    | Delay in seconds for initial readiness probe                        | `35`                    |
| `rest.probes.readiness.periodSeconds`          | Duration in seconds between readiness probes                        | `20`                    |
| `rest.probes.readiness.successThreshold`       | Readiness probe success threshold                                   | `1`                     |
| `rest.probes.readiness.failureThreshold`       | Readiness probe failure threshold                                   | `3`                     |
| `rest.resources.requests.cpu`                  | Mimimum CPU resources                                               | `"250m"`                  |
| `rest.resources.requests.memory`               | Minimum memory resources                                            | `"700Mi"`                 |
| `rest.resources.limits.cpu`                    | Maximum CPU resources                                               | `"4000m"`                 |
| `rest.resources.limits.memory`                 | Maximum memory resouces                                             | `"8Gi"`                   |
| `rest.deployPackages.enabled`                  | If Cloud Object Storage is used, deploy packages                    | `true`                   |
| `rest.deployPackages.directory`                | Directory used to search for packages                    | `"/data/maps"`                |
| `rest.deployPackages.archiveDir`               | Directory used to move packages after successful deploy  | `"/data/packages"`                |
| `rest.deployPackages.secret.keyName`           | TLS key from external.secrets.data                       | `""`                |
| `rest.deployPackages.secret.crtName`           | TLS certificate from external.secrets.data               | `""`                |
| `rest.nodeSelector`                            | Node selector map                                                   | `{}`                    |
| `rest.tolerations`                             | Tolerations array                                                   | `[]`                    |
| `rest.affinity`                                | Pod and Node affinity                                               | `{}`                    |
|                                                |                                                                    |                         |

<sup>1</sup> Container image, map extension and data persistence settings also apply to REST V1 deployment.

### Executor deployment parameters

| Parameter                                      | Description                                            | Default                     |
| ---------------------------------------------- | ------------------------------------------------------ | --------------------------- |
| `executor.serviceAccount.create`               | Create **executor** service account                    | `false`                     |
| `executor.serviceAccount.annotations`          | Annotations to add to the **executor** service account | `{}`                        |
| `executor.serviceAccount.existingName`         | Name of pre-existing **executor** service account      | `""`                        |
| `executor.replicas`                                | Number of executor pod replicas                    | `1`                         |
| `executor.probes.liveness.enabled`                 | Enable liveness probe                              | `true`                      |
| `executor.probes.liveness.initialDelaySeconds`     | Delay in seconds for initial liveness probe        | `30`                        |
| `executor.probes.liveness.periodSeconds`           | Duration in seconds between liveness probes        | `20`                        |
| `executor.probes.liveness.successThreshold`        | Liveness probe success threshold                   | `1`                         |
| `executor.probes.liveness.failureThreshold`        | Liveness probe failure threshold                   | `3`                         |
| `executor.probes.readiness.enabled`                | Enable readiness probe                             | `true`                      |
| `executor.probes.readiness.initialDelaySeconds`    | Delay in seconds for initial readiness probe       | `30`                        |
| `executor.probes.readiness.periodSeconds`          | Duration in seconds between readiness probes       | `20`                        |
| `executor.probes.readiness.successThreshold`       | Readiness probe success threshold                  | `1`                         |
| `executor.probes.readiness.failureThreshold`       | Readiness probe failure threshold                  | `3`                         |
| `executor.resources.requests.cpu`                  | Mimimum CPU resources                              | `"250m"`                      |
| `executor.resources.requests.memory`               | Minimum memory resources                           | `"700Mi"`                     |
| `executor.resources.limits.cpu`                    | Maximum CPU resources                              | `"4000m"`                     |
| `executor.resources.limits.memory`                 | Maximum memory resouces                            | `"4Gi"`                       |
| `executor.nodeSelector`                            | Node selector map                                  | `{}`                        |
| `executor.tolerations`                             | Tolerations array                                  | `[]`                        |
| `executor.affinity`                                | Node and pod affinity map                          | `{}`                        |
| `executor.autoscaling.enabled`                     | Horizontal pod autoscaling enabled                 | `false`                        |
| `executor.autoscaling.minReplicas`                 | Minimum pod count                                                   | `1`                 |
| `executor.autoscaling.maxReplicas`                 | Maximum pod count                                                   | `10`                 |
| `executor.autoscaling.cpu.enabled`                 | CPU utilization monitoring                                        | `true`                 |
| `executor.autoscaling.cpu.averageUtilization`      | CPU average utilization threshold                                 | `80`                 |
| `executor.autoscaling.memory.enabled`              | Memory utilization monitoring                                     | `true`                 |
| `executor.autoscaling.memory.averageUtilization`   | Memory average utilization threshold                              | `80`                 |
| `executor.autoscaling.custom.enabled`              | Custom metric type monitoring                                     | `false`              |
| `executor.autoscaling.custom.types`                | Custom metric type definitions array                              | `[]`                 |
| `executor.autoscaling.behavior`                    | Behavior policies for scaling up or down                          | `{}`                 |
|                                                    |                                                                   |                      |

### External integration parameters

| Parameter                                      | Description                                                    | Default                     |
| ---------------------------------------------- | -------------------------------------------------------------- | --------------------------- |
| `external.data.volume.path`       | Path used to mount ConfigMap and secret files                            | `"/xdata"` |
| `external.data.volume.size`       | Size of the volume                                                       | `"50Mi"` |
| `external.data.secret.subpath`    | Subdirectory path of secret files                                        | `"sec"` |
| `external.data.configMap.subpath` | Subdirectory path of configMap files                                     | `"cfg"` |
| `external.data.map.subpath`       | Subdirectory path of map files                                           | `"map"` |
| `external.mq.secret`              | Name of the secret that contains MQ client channel table                 | `""` |
| `external.mq.chlTab`              | Key of the MQ secret                                                     | `""` |
| `external.mq.chlLib`              | Directory path of the MQCHLLIB environment variable                      | `"/xdata/sec"` |
| `external.mq.sslKeyPath`          | Full path file name to the repository of MQ trusted certificates         | `""` |
| `external.mq.dataPath`            | Full path used to set the MQ_OVERRIDE_DATA_PATH environment variable     | `"/tmp"` |
| `external.secrets`                | Array of secret names and keys to get mounted                            | `[]` |
| `external.configMaps`             | Array of ConfigMap names and keys to get mounted                         | `[]` |
| `external.maps`                   | Maps in a ConfigMap that are mounted and ready for REST V1 execution     | `[]` |
| `external.hostAliases`            | Array of host aliases that are needed in a pod                           | `[]` |
| `external.env`                    | Array of environment variables for use during map execution              | `[]` |
| `external.cos.enabled`            | Cloud Object Storage is enabled for map and flow download and setup      | `false` |
| `external.cos.name`               | Name of the zip object to download and unzip from COS                    | `"maps.zip"` |
| `external.cos.bucket`             | Bucket that contains the zip file                                        | `"itx"` |
| `external.cos.targetDir`          | Destination directory where maps are unzipped                            | `"/data/maps"` |
| `external.cos.platform`           | Cloud platform ("s3", "gcp")                                             | `"s3"` |
| `external.cos.gcp.cf`             | If "gcp" platform, points to the name of the mounted credentials file    | `"cf.json"` |
| `external.cos.s3.accessKey`       | If "s3" platform, points to the name of the mounted access key           | `""` |
| `external.cos.s3.region`          | If "s3" platform, name of the region                                     | `"us-east-1"` |
| `external.cos.s3.endpoint`        | If "s3" platform, URL of S3 compatible storage service                   | `""` |
|                                   |                                                                          |         |

### Redis component parameters

| Parameter                          | Description                                                        | Default      |
| ---------------------------------- | ------------------------------------------------------------------ | ------------ |
| `itxRedis.host`                    | Host name of the externally provided Redis                         | `"redis-master"`   |
| `itxRedis.port`                    | Port name of the externally provided Redis                         | `6379`       |
| `itxRedis.database`                | Database number in the externally provided Redis                   | `0`          |
| `itxRedis.password.secret`         | Name of the secret which contains the Redis password               | `""`         |
| `itxRedis.password.key`            | Key in the secret which contains the Redis password                | `""`         |
| `itxRedis.tls.enabled`             | TLS communication with Redis is enabled                            | `false`      |
| `itxRedis.tls.clientSecret`        | If using mTLS, name of the TLS client secret                       | `""`      |
| `itxRedis.tls.certFilename`        | If using mTLS, name of the certificate in the TLS client secret    | `""`      |
| `itxRedis.tls.certKeyFilename`     | If using mTLS, name of the private key in the TLS client secret    | `""`      |
| `itxRedis.tls.clientCaConfigMap`   | Name of the ConfigMap which contains the Redis server's CA         | `""`      |
| `itxRedis.tls.certCAFilename`      | Key in the ConfigMap which contains the Redis server's CA          | `""`      |
| `itxRedis.tls.sni`                 | Server Name Indication host name, if needed by Redis Server        | `""`      |
| `itxRedis.maxStatisticCount`       | Maximum number of flow instances to retain in the statistics       | `100000`  |
| `itxRedis.statusExpiration`        | Number of day when flow status message expires                     | `7`  |
|                                    |                                                                    |              |

### Route V2-based parameter when deploying to RHOS

| Parameter             | Description                               | Default |
| --------------------- | ----------------------------------------- | ------- |
| `route.deploy`        | Define route when `rest.deploy` is true   | `true`  |
| `route.host`          | Use an explicit route hostname.           | `""`    |
| `route.annotations`   | Add route annotation for backend timeout  | `{}`    |

### Route V1-based parameter when deploying to RHOS

| Parameter             | Description                               | Default |
| --------------------- | ----------------------------------------- | ------- |
| `routeV1.deploy`      | Define route when `restV1.deploy` is true | `true`  |
| `routeV1.host`        | Use an explicit route hostname.           | `""`    |
| `routeV1.annotations` | Add route annotation for backend timeout  | `{}`    |

### Ingress V2-based REST parameters

| Parameter             | Description                               | Default |
| --------------------- | ----------------------------------------- | ------- |
| `ingress.deploy`      | Deploy ingress                            | `false` |
| `ingress.annotations` | Annotations for the ingress               | `{}`    |
| `ingress.className`   | Sets the "ingressClassName"               | `"openshift-default"`    |
| `ingress.hosts`       | Array of host definitions for the ingress | `[]`    |
| `ingress.tls`         | Array of TLS definitions for the ingress  | `[]`    |
| `ingress.default.enabled` | REST service is used when no rules or match exists | `true`    |
|                       |                                           |         |

### Ingress V1-based REST parameters

| Parameter             | Description                               | Default |
| --------------------- | ----------------------------------------- | ------- |
| `ingressV1.deploy`      | Deploy ingress                            | `false` |
| `ingressV1.annotations` | Annotations for the ingress               | `{}`    |
| `ingressV1.className`   | Sets the "ingressClassName"               | `"openshift-default"`    |
| `ingressV1.hosts`       | Array of host definitions for the ingress | `[]`    |
| `ingressV1.tls`         | Array of TLS definitions for the ingress  | `[]`    |
| `ingressV1.default.enabled` | REST service is used when no rules or match exists | `true`    |
|                       |                                           |         |

### Configuration parameters used in "config.yaml" for REST and Executor deployments

| Parameter                                | Description                                                   | Default                     |
| ---------------------------------------- | ------------------------------------------------------------- | --------------------------- |
| `config.runtime.connectionsManager.idle` | Time in seconds before an idle connection is closed           | `60` |
| `config.runtime.connectionsManager.sLim` | Number of connections of a given type that can be kept idle   | `4` |
| `config.runtime.externalJarFiles`        | Array of externally loaded jar files before invoking Java     | `[]` |
| `config.runtime.externalJarDirectories`  | Array of directories used to load jar files                   | `[]` |
| `config.runtime.jvmOptions`              | JVM options in array format for Map and Flow executions       | `[]` |
| `config.runtime.trace`                   | Log to Kubernetes or set to "" for file logging               | `"stdout"` |
| `config.runtime.locale`                  | Locale values: de,en,es,fr,it,ja,ko,pt_BR,ru,zh_CN,zh_TW      | `"en"` |
| `config.rest.logging.level`              | Logging levels: ALL,TRACE,INFO,ERROR,NONE                     | `"ERROR"` |
| `config.rest.logging.header`             | Display column header                                         | `true` |
| `config.rest.logging.columns.time`       | Display time column                                           | `1` |
| `config.rest.logging.columns.uuid`       | Display the UUID of each instance                             | `false` |
| `config.rest.logging.columns.rc`         | Display return code                                           | `true` |
| `config.rest.logging.columns.rcText`     | Display text description of return code                       | `false` |
| `config.rest.logging.columns.msgID`      | Display trace message ID                                      | `false` |
| `config.rest.logging.columns.flowName`   | Display flow, node or adapter name of generated message       | `true` |
| `config.rest.logging.columns.msg`        | Display trace message                                         | `true` |
| `config.rest.logging.columns.funcName`   | Display function name (for internal debugging only)           | `false` |
| `config.rest.logging.columns.sourceInfo` | Display source file and line (for internal debugging only)    | `false` |
| `config.rest.logging.trigger`            | Frequency of execution logs: ALWAYS,ON_ERROR,NEVER            | `"ALWAYS"` |
| `config.rest.logging.addWebServerConsoleLogging` | Enable Kubernetes logging from ITX Runtime Server     | `true` |
| `config.rest.logging.disableWebServerAccessLogging` | Disable logging of REST requests                   | `false` |
| `config.rest.logging.rotation.fileCount` | Max number of log files in rotation                           | `5` |
| `config.rest.logging.rotation.fileSize` | Max size in kilobytes of each log file                         | `20000` |
| `config.rest.logging.rotation.fileAge` | Min number of days after which logs are deleted                 | `30` |
| `config.rest.resources.mapThreads`     | Max number of threads for executing maps                        | `10` |
| `config.rest.resources.flowThreads`    | Max number of threads for executing flows                       | `10` |
| `config.rest.listeners.adapter.jvmOptions` | JVM options in string format for java-based listener        | `""` |
| `config.rest.listeners.file.zone` | Unique zone name for File Listener in multi-regional deployment      | `""` |
| `config.rest.listeners.file.cooperativeMode` | Multiple file listeners use the same watch                | `false` |
| `config.patch.directory` | Directory of fixes to patch runtime modules  | `""` |
| `config.patch.manifest` | Manifest that lists 'cksum' values of fixes   | `"/xdata/cfg/patchmanifest.txt"` |
|                                            |                                                                   |                             |

### Tomcat parameters

| Parameter                                | Description                                                   | Default    |
| ---------------------------------------- | ------------------------------------------------------------- | ---------- |
| `tomcat.connector.acceptCount`           | Max number of waiting REST requests           | `100` |
| `tomcat.connector.maxThreads`            | Max number of working REST requests           | `20`  |
| `tomcat.connector.maxConnections`        | Max number of idle REST connections           | `10000`  |
|                                          |                                               |          |

### Metric parameters

| Parameter                                | Description                                                   | Default    |
| ---------------------------------------- | ------------------------------------------------------------- | ---------- |
| `metrics.enabled`                        | Enable metrics gathering and reporting                        | `false`    |
| `metrics.readinessProbeEnabled`          | Enable metrics readiness probe                                | `false`    |
| `metrics.threadSaturationThreshold`      | Saturation threshold                                          | `0.95`     |
| `metrics.cpuUsageThreshold`              | CPU usage threshold                                           | `0.95`     |
| `metrics.sli.latency`                    | REST request latency threshold                                | `0.95` <sup>1</sup>  |
| `metrics.sli.buckets`                    | REST request latency buckets in milliseconds                  | `""`   <sup>2</sup>  |
| `metrics.jvm.memory`                     | JVM memory metrics                                            | `false` <sup>3</sup> |
| `metrics.jvm.gc`                         | JVM GC metrics                                                | `false`    |
| `metrics.jvm.threads`                    | JVM thread metrics                                            | `false`    |
| `metrics.system.cpu`                     | Container wide CPU usage                                      | `false`    |
|                                          |                                                               |            |

<sup>1</sup> See `values.yaml` for further customizations.\
<sup>2</sup> Limit the histogram bucket count to fewer than 25 entries, such as "75,100,150,175,200,225,250,300,500,750,1000,1250,1500,1700,1850,2000,2150,2300,2500,4000,7500,15000,30000". Using a larger number of buckets increases metric cardinality, memory consumption, and processing overhead.\
<sup>3</sup> JVM specific metrics for detailed analysis and troubleshooting.

### Service Mesh parameters

| Parameter                                | Description                                                   | Default    |
| ---------------------------------------- | ------------------------------------------------------------- | ---------- |
| `istioV1.enabled`                        | Enable service mesh for V1 deployments                        | `false` <sup>1</sup> |
| `istio.enabled`                          | Enable service mesh for V2 deployments                        | `false` <sup>1</sup> |
|                                          |                                                               |            |

<sup>1</sup> See `values.yaml` for detailed configuration parameters and customizations.

### Redis Configuration

If you are planning to run ITX Runtime Server instances in `fenced` mode (which V2 mode requires) or run maps asynchronously, you must install Redis prior to installing ITX Runtime Server.

A Redis server installation is not included and must be obtained separately. Ensure that the Redis server which you install comes from a reputable source that you trust. Redis server version 7.0.11 was validated with this version of ITX Runtime Server. This version or later is the recommended version to use. Older Redis server versions may not function as expected when combined with this product and may need to be upgraded before they can be used.

The installed Redis service must be accessible to all ITX Runtime Server pods, at the same host URL and port, which means it must be accessible to all worker nodes to which ITX Runtime Server pods are deployed.

If the selected Redis server installation requires a password for authentication, you must create a Kubernetes **Secret** object with the password to use for connecting to Redis. The name of the secret is given by `itxRedis.password.secret`. The key within the secret which contains the password is given by `itxRedis.password.key`. See the documentation of your Kubernetes platform for information on creating **Secret** objects and configuring secure cluster secret storage.

Communication with a Redis server which uses TLS is supported. Both mutual and non-mutual TLS are supported. TLS is enabled by setting `itxRedis.tls.enabled` to `true`. The configuration of the external Redis server determines if mutual authentication is required.

For non-mutual and mutual TLS, a Kubernetes **ConfigMap** must be used to provide the trust store that is used by the ITX Redis clients to authenticate the Redis server. The name of the **ConfigMap** is given by `itxRedis.tls.clientCaConfigMap`. The key within the **ConfigMap** which provides a PEM trust store is given by `itxRedis.tls.certCAFilename`. See the documentation of your Kubernetes platform for information on creating **ConfigMap** objects.

For mutual TLS, a Kubernetes **Secret** must be used to provide a client certificate and private key. The name of the **Secret** is given by `itxRedis.tls.clientSecret`. The key which provides the client certificate PEM file is given by `itxRedis.tls.certFilename`. The key which provides the client private key PEM file is given by `itxRedis.tls.certKeyFilename`.

### SSL/TLS Configuration

Two options are available for enabling SSL/TLS communication (HTTPS) with the ITX Runtime Server.

With either option, the Runtime Server can be configured to perform client authentication. This is enabled by setting `restV1.inbound.https.clientAuth` or `rest.inbound.https.clientAuth` to `true` for the V1 and V2 deployment modes, respectively. Client authentication is disabled by default.

With the first option, a Kubernetes **Secret** object needs to be provided. This object contains the server certificate and the server certificate key for the Runtime Server. Both are in PEM format. If you wish to enable client authentication, then you also need to provide a CA certificate file, again in PEM format, that can be used to authenticate clients.

See the mappings `restV1.inbound.https` and `rest.inbound.https` for HTTPS TLS configuration. The keys that you use in the **Secret** object for certificate authority, server certificate and server key must be named `ca.crt`, `tls.crt`, and `tls.key`, respectively.

You can define and manage the Secret object directly and deploy it to the namespace prior to installing ITX Runtime Server, or you can use a certificate manager tool in your cluster to generate the secret automatically and to manage the certificates and keys stored in the secret, including their expiry and rotation. The name of the secret needs to be provided when deploying ITX Runtime Server.

With the second option, the built-in Service Serving Certificates feature of OpenShift is utilized to provide a server certificate, server private key, and a CA trust store. Use of the Service Serving Certificates feature is indicated by setting `restV1.inbound.https.serviceServingCertificates` or `rest.inbound.https.serviceServingCertificates` to `true` for the V1 and V2 deployment modes, respectively.

When the Runtime Server is deployed, a **Secret** object is created for a **Service** whose backend uses the Service Serving Certificates feature. For example, if the Service Serving Certificates feature is used for the V2 deployment option, a **Secret** is created for the **Service** which exposes the HTTPS port of the ITX Runtime Server for the V2 deployment option. Naming and use of this **Secret** is handled automatically.

A **ConfigMap** object is automatically created which contains a CA certificate for the Service Serving Certificates CA. The CA certificate of this **ConfigMap** is used when the ITX Runtime Server performs client authentication. In other words, use of the Service Serving Certificates feature together with client authentication implies that only clients who can be authenticated relative to the Service Serving Certificates CA will be able to access the ITX Runtime Server over HTTPS.

For more information about the OpenShift Service Serving Certificates feature, see the [OpenShift documentation](https://docs.openshift.com/container-platform/4.20/security/certificates/service-serving-certificate.html).

#### Example for option 1 - Produce Secret with ca.crt, tls.crt and tls.key PEM values

If you have CA certificate, server certificate and server key values in PEM format, you can create Secret object manually and deploy it to the namespace where you plan to install ITX Runtime Server. Note that if you choose to manually create **Secret** object, you assume responsibility for its lifecycle, including management of the key and certificate values they store, and restarting the pods to pick up any updates made to the Secret content.

The following is an example of a **Secret** object with the name `itx-rs-ssl-secret`. Before applying it, replace the three indicated base64 value placeholders with the base64 encoded PEM certificates and keys:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: itx-rs-ssl-secret
type: Opaque
data:
  ca.crt: "base64_ca_cert"
  tls.crt: "base64_server_cert"
  tls.key: "base64_server_key"
```

To base64 encode a PEM file and display the value in a single line for inclusion in this manifest, you can use the following command:

```
base64 --wrap=0 <file_name>
```

After applying the manifest, if you deployed it from the command line from a yaml file, you may want to delete the file after applying it, since it will contain the server certificate's private key.

In addition to providing a custom Secret object, you can also utilize a certificate management tool to automatically create and manage the **Secret**. For example, IBM Cloud® [Secrets Manager](https://cloud.ibm.com/docs/secrets-manager) could be used.

## Storage

ITX Runtime Server requires two file system based persistent volumes for its operation, namely `data` and `logs`. The volumes may be provisioned dynamically during the product installation, or created and installed prior to installing the product, as supported by your cluster.

If you wish to use static volume binding and you wish to initialize the `data` volume with all the maps you want to make available to the ITX Runtime Server pods immediately upon the installation, note that you must organize the file directories in the volume as shown here:

```
/data
     /maps                          - directory for compiled maps
     /catalog                       - directory for map catalog
     /config                        - directory for configuration files
     /extra                         - directory for any additional JARs and shared libraries
     /tmp                           - directory for temporary files used by maps
```

### Access Modes

Two access modes are supported, namely `ReadWriteMany` (RWX) and `ReadWriteOnce` (RWO). The default access mode is `ReadWriteOnce`.

Since all ITX Runtime Server pods are considered equal for handling client requests, they need to be able to process requests that reference the same maps, logs and other data artifacts in the shared data persistent volume, the storage class used for the **data** and **logs** persistent volume must support `ReadWriteMany` access mode and this mode must be selected in order for the data persistent volume claim to be satisfied and for the data storage to be successfully bound to all running pods.

In cases when all the pods are always deployed to the same worker node, such as the case with development environments, the `ReadWriteOnce` access mode may be selected, if a storage class available in the environment supports this mode and no other storage classes are available that support `ReadWriteMany` mode.

ITX Runtime Server has been tested with the following storage providers:
 * Google Persistent Disk (RWO)
 * Rook CephFS (RWO & RWX)
 * NFS (RWO & RWX)

ITX Runtime Server supports the following storage provisioning options:
 * Dynamic provisioning using a storageClass
 * Pre-created PV's (Persistent Volumes)

### Cloud Object Storage

ITX Runtime Server can download maps and flows from a Cloud Object Storage (COS) location. The Amazon S3 and GCP APIs are supported (see `external.cos.platform` in values.yaml). When deploying a REST V1 or V2-based installation, all the compiled maps and/or packaged flows can be zipped up in a file with a .zip extension and uploaded to COS for subsequent downloading and automatic setup by the REST V1 or REST V2 pods. The automatic download of both maps and flows is done before the REST pod even starts. The REST pod will only become available once all the maps and/or flows are ready to be executed, thereby avoiding any need for manual deployment and streamlining the overall startup process.

In the case of a REST V1-based deployment whereby maps are only invoked in a synchronous and `unfenced` configuration, the persistent volume requirement is optional. The REST V1 deployment must be configured for `unfenced` mode, which is the default. Otherwise, a `fenced` configuration would require incoming REST data to be stored on a shared persistent volume for subsequent processing by one of the executing pods. In the case of `unfenced` mode, however, each and every pod that is spun up for map execution runs independently of the others - since the maps are loaded in the ephemeral storage location of the running pod. As long as log files are sent to the Kubernetes log and map logs to the REST API invocation when needed, persistent volumes are no longer required and the REST V1-based deployment can be run in a cloud-native capacity that has no single point of failure and a higher degree of availability.

### Extra Content 

The `extra` folder is used to host any JAR files, Java classes, or shared libraries that are required for running the maps but that are not included with the product and you will be providing separately. An example is JDBC and ODBC drivers to be utilized with JDBC and ODBC adapters. Since these components will be loading and executing in the ITX Runtime Server pods, it is critical that you ensure that they come from reputable sources that you trust, and that you validate them before enabling them for use with the ITX Runtime Server.

### Backup

If you are using dynamically provisioned persistent volumes for data and logs, be aware that these volumes will be claimed when the ITX Runtime Server instance is installed, but will be recycled after the product has been uninstalled, since at that time the persistent volume claims created by the product when it was installed will be removed as well. For dynamically provisioned persistent volumes, the assumption is that the maps, flows, and associated artifacts will continue to be available in your source systems from which you originally uploaded or deployed them to the ITX Runtime Server environment.

For example, ITX Runtime Server operates on compiled maps (mmc files) which must have all originated from source maps on on-prem systems where they have been produced by compiling the map source definitions (.mms files) with tools like ITX Design Studio. The compiled maps are then uploaded to ITX Runtime Server. In order to be able to upload the maps again if that need arises, they need to continue to remain available at their origin. This is especially critical for the map definitions (.mms files) since they are required to be able to make updates in the future, and can always be compiled again to be uploaded to ITX Runtime Server. Backing up the original storage for those maps, especially the map sources (.mms files) is therefore of utmost importance, and is outside the scope of 
ITX Runtime Server deployment.

When using persistent volumes, you can choose to configure them with the Retain policy. The content of the persistent volume will then be preserved and can be subsequently retrieved - even after uninstalling ITX Runtime Server. The exact Kubernetes steps for accomplishing this task is documented under the Storage section in the README file of the Helm Chart Examples. After configuring the persistent volume with the `Retain` policy, the `existingClaim` setting in the values.yaml file can be used to identify the persistent volumes, thereby ensuring that deployment of maps and flows need not be repeated after re-installation.

If you need to back up any files in the persistent volumes that were produced by the maps or flows running under ITX Runtime Server, you must download those files individually using the provided **data** and **logs** GET APIs. Alternatively, you may choose to backup the persistent volume storage directly, if your cluster environment provides for direct access to the backing storage. Note that the **data** GET APIs work on subfolders as well, in which case the response will contain the names of all subfolders and files in that folder. This can be utilized to implement scripts which will recursively pull all the files in a given directory.

### Encryption

ITX Runtime Server does not itself perform encryption and decryption of the data at rest. To ensure the data in your persistent volumes is encrypted at rest, when defining persistent volume claims for the ITX Runtime Server, you must specify a filesystem-based storage class that is available in your cluster and supports encryption. For some storage classes, the data may be encrypted automatically by their respective storage providers, but in some cases additional manual configuration may be necessary, such as definition and enablement of encryption keys. For more information, see documentation for the storage classes available in your environment.

In those cases where filesystem-based encryption is not available or only needed in select circumstances, the ITX **cipher** adapter may be used in maps, flows and configuration files to encrypt data that is stored to disk and decrypt the same data that is retrieved from disk. This capability is documented in the ITX Design Studio examples and online help. The data is encrypted with a highly secure symmetric AES-256 cipher. The key that is used for encryption and decryption can be stored as a secret in the cluster. By mounting the secret key via the `external.secrets` section of the values.yaml file, the data at rest on disk remains securely encrypted.

## SecurityContextConstraints Requirements

The ITX Runtime Server Helm chart requires a specific type of `SecurityContextConstraints` to be defined and bound to the user or service account of the installation. The predefined `SecurityContextConstraints`, [`nonroot-v2`](https://docs.openshift.com/container-platform/4.20/authentication/managing-security-context-constraints.html), has been verified for this chart.  If your user or service account is bound to this `SecurityContextConstraints` resource, you can proceed to install the chart.

Below is a `SecurityContextConstraints` (SCC) which can be used for finer control of the permissions and capabilities needed to install this chart. It is modeled after the predefined `nonroot-v2` SCC but with the added restriction of only permitting the user and group ID, 1001, which is required by ITX Runtime Server.

Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: "This policy allows a single, non-root user"
  name: ibm-itx-rs-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: false
allowedCapabilities: 
- NET_BIND_SERVICE
allowedFlexVolumes: null
allowedUnsafeSysctls: null
defaultAddCapabilities: null
defaultAllowPrivilegeEscalation: false
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
seccompProfiles:
- runtime/default
runAsUser:
  type: MustRunAs
  uid: 1001
fsGroup:
  type: MustRunAs
  ranges:
  - max: 1001
    min: 1001
supplementalGroups:
  type: RunAsAny
seLinuxContext:
  type: MustRunAs
volumes:
- configMap
- csi
- downwardAPI
- emptyDir
- ephemeral
- nfs
- persistentVolumeClaim
- projected
- secret
priority: 0
```
From the command line, save the YAML object to a file and run the following command:
```
oc apply -f <file_name>
```
For ITX RS installation details, please see this [support page](https://www.ibm.com/support/pages/node/7274354).

## Limitations

* ITX Runtime Server is supported on OpenShift 4.20, and on Linux 64 only. This means that any maps designed to run on other platforms, such as those using adapters supported on Windows operating system only, will not be able run in ITX Runtime Server.
* Because of the unique characteristics of running workloads in Kubernetes environments compared to running them in on-prem environments, existing ITX maps may require adjustments before they can be run in ITX Runtime Server, especially if they rely on invoking custom tools or applications, or are making assumptions about the underlying host's operating system, network, local storage or other system-level resources.
* Any files referenced by the maps must assume /data/maps path as the map directory. If a maps writes to a file without specifying its path, the file will be created in the /data/maps directory.
* The V2 configuration API is not supported in Helm installations.

## Scaling

ITX Runtime Server pods run independently of each other and can serve client requests that can be load balanced across them in any pattern. This includes running ITX maps asynchronously, including scenarios when one pod instance processes the REST API POST call request to run the map and another pod subsequently processes the REST API GET call request to return the status of the map execution, even if the two pods are running on different worker nodes. To access the compiled maps, the pods are accessing shared persistent volume where the compiled maps are saved, and to access statuses of the asynchronous map executions the pods are utilizing Redis queues, which is the reason Redis is required when asynchronous map calls are made.

The number of pods running at any time can be controlled through the **replicaCount** property exposed by the product. When sufficient system resources are available and have been provisioned for the newly added pods to the deployment, it will increase the ability of the deployment to handle additional workload as more pods will available to process the incoming REST API calls simultaneously.

In addition to supporting multiple pods in a single deployment (ITX Runtime Server instance), multiple deployments can be installed in the cluster, but they need to be installed in separate projects (namespaces), one instance per project. This provides for example the ability to run separate QA and Dev ITX Runtime Server deployments in the same cluster simultaneously. 

ITX Runtime Server pods can be auto scaled based on threshold target CPU or Memory utilization on the worker nodes of the cluster. Auto scaling of ITX Runtime Server pods is disabled by default in the Helm Chart for IBM Sterling Transformation Extender for Red Hat OpenShift. Enabling autoscaling option disables **replicaCount** specified in the configuration. IBM Sterling Transformation Extender for Red Hat OpenShift supports horizontal pod autoscaling, does not support vertical pod autoscaling at this time.

## Uninstalling

To uninstall ITX Runtime Server, run the following command, after replacing the `<target_namespace>` placeholder with the name of the namespace from which you wish to uninstall the ITX Runtime Server deployment.

```
helm uninstall ibm-itx-rs --namespace <target_namespace>
```

## Upgrades and Rollbacks

Upgrade or Rollback activity of ITX Runtime Server instances from a Helm Chart version before 3.x has to be performed by uninstalling the original deployment and then installing the ITX Runtime Server Helm Chart version 3..x.   Version 3 charts use the ITX product version 11.  Prior charts use product version 10.  Helm uninstall and install commands are to be used to deploy a new major version of ITX Runtime Server Helm Chart

Whenever a Helm upgrade is made to an existing deployment with a Helm chart version of 3.x, the pods that are associated with the installation will not automatically restart - unless the change affects the actual deployment manifest. For example, an update to the image name or resource metrics will change the deployment manifest of the installation, which in turn will trigger an automatic restart of the pods. However, a basic change to a values.yaml property that is linked to the ITX config.yaml file, such as the logging level, will not trigger an automatic restart. The restart would need to take place manually, as provided by the Kubernetes scale command.

## REST API Overview

The main interface the ITX Runtime Server provides is its REST APIs that it exposes and makes available to REST clients inside the cluster via its `Service` resource, and to the REST clients outside the cluster via its `Route` resource. Any REST client capable of invoking REST API methods can be used. This can for example be the `curl` command line tool, the `Postman` graphical interface tool, or a custom application that implements REST client functionality.

The REST APIs exposed by the ITX Runtime Server are documented in OpenAPI 3.0 specification format. You can explore the APIs by pointing your web browser to `<location>/tx-rest/api-docs?url=/tx-rest/docs` where `<location>` is the location exposed by the `Route` resource in your ITX Runtime Server instance. To view all V1 and V2 Runtime REST APIs supported by the ITX Runtime Server, replace `v2/docs` in the text box with `openapi.json` and then select `Explore` button in the Swagger web UI page.

The REST API documentation provides details on the methods included in the API. At a high level, the methods included in the API can be categorized as follows:

- API methods for obtaining general information from the `Pod` resources in the Runtime Server instance, such as their version and configuration details
- API methods for deploying (uploading) maps, when they have not been pre-loaded to the persistent data volume bound to the ITX Runtime Server instance
- API methods for optional cataloging of maps and exposing the map entries as their own REST API endpoints
- API methods for invoking deployed maps, in synchronous or asynchronous mode, and directly or indirectly through their catalog entries.

The cataloged maps are exposed as separate REST endpoints. Each of those endpoints define which map to run and the mode in which to run it, which is specified. You can explore the generated REST endpoints for the cataloged maps by pointing your web browser to `<location>/tx-rest/api-docs?url=/tx-rest/docs` where `<location>` is the location exposed by the `Route` resource in your ITX Runtime Server instance. By default, Swagger web UI page shows V2 Runtime REST API map and flow endpoints. To see the V1 Runtime REST API cataloged map endpoints, replace `v2/docs` with `v1/itx/docs` in the text box and select `Explore` button.

### Synchronous and asynchronous map invocation

A map can be invoked synchronously, in which case the results of the map run are provided in the REST response, or asynchronously, in which case the response is a reference to the map status endpoint, which can be polled to check on the map status. Asynchronous mode requires Redis installation.

### Direct and cataloged map invocation

Maps can be invoked directly, by referencing them using the location and name that was specified when they were uploaded, or as cataloged objects, by calling their respective REST endpoints, if they were previously cataloged.

### Fenced and unfenced run mode

Lastly, maps can be invoked in one of two modes - fenced and unfenced. In fenced mode, the maps run in the same container as the ITX Runtime Server, but in a separate worker process. If a map results in a failure that causes its worker process to terminate, the ITX Runtime Server process continues to run and creates a new worker process instance to which to delegate map execution. In unfenced mode, a single process is used to serve the ITX endpoints and to run maps. Fenced mode requires Redis installation. 

### Bulk Copy 

ITX Runtime Server Data API allows deploying a single file to the data volume. You can deploy a collection of files organized in a directory structure included in a zip file which gets extracted under data volume. Bulk copy requires a special action header, **rs-action: unpack**, to be included while invoking Data API. It is a POST operation to create a single file or multiple files on the data volume. The Data API can be used to transfer a single file or multiple files under any directory level within the data volume.

Transferring a single file or multiple files to the data volume is required before running a map under ITX Runtime Server unless the volume is prepopulated with the required files. There are other ways to copy files to the data volume, for example, **oc cp** command for OpenShift allows copying the file from local using the container identifier and vice-versa. Using Data API provides a consistent and easy-to-use mechanism for copying single or multiple files to a data volume.

The example curl command using route name with HTTP protocol is as following: 
```bash
curl -F "data=@/mydir/myfiles.zip" -H "rs-action: unpack" "http://<route_name>/tx-rest/v1/itx/data/maps"
```
Executing the example command above results in unpacking the myfles.zip file after it is deployed to the ITX Runtime Server. ITX Runtime Server retains the same directory structure as in the zip file under target directory, /data/maps , while unpacking the contents of the zip file.

## Deployment Guidelines

### GDPR

Users of ITX Runtime Server are responsible for ensuring their own compliance with various laws and regulations, including the European Union General Data Protection Regulation (GDPR). Users are solely responsible for obtaining advice of competent legal counsel as to the identification and interpretation of any relevant laws and regulations that may affect the user's business and any actions the user may need to take to comply with such laws and regulations.

The products, services, and other capabilities described herein are not suitable for all user situations and may have restricted availability. HCL and IBM do not provide legal, accounting, or auditing advice or represent or warrant that its services or products will ensure that users are in compliance with any law or regulation.

For more information about GDPR, refer to:
- [EU GDPR Information Portal](https://ec.europa.eu/info/law/law-topic/data-protection_en)
- [IBM GDPR website](http://ibm.com/GDPR)

ITX Runtime Server enables an organization to integrate industry-based customer, supplier and business partner transactions across the enterprise. It helps automate complex transformation and validation of data between a range of different formats and standards. Securing and managing the personal data passed through the ITX Runtime Server for processing is a sole responsibility of the user. Some of the security guidelines that follow may help in securing the personal data:

- Harden the master and worker nodes in the cluster based on security benchmarks like CIS Benchmarks
- Harden the Red Hat Enterprise Linux OS based on security benchmarks like CIS Benchmarks
- Secure the communication with ITX Runtime Server using HTTPS protocol instead of HTTP
- Secure the credentials of external systems accessed by ITX Runtime Server using AES-256 encryption in Resource Registry
- Use secure options provided by the data source/target adapters where applicable to securely process the data
- Encrypt and decrypt the data, process data through ITX Runtime Server's Cipher and OpenPGP adapters
- Secure the transport of data from/to maps run by ITX Runtime Server with HTTPS, FTPS adapters
- Cataloged maps would allow hiding the details of the map location, overrides of the deployed maps
- Monitor the outputs generated by the ITX Runtime Server, remove input and output files when not required
- Look out for security bulletins from ITX and Red Hat support teams to resolve security vulnerabilities
- Apply the security patches when released and keep the cluster nodes up to date to avoid security threats
- Refer ITX Knowledge Center and Red Hat OpenShift documentation on the security features available in the products
- Scan map and input files for malware/virus before uploading to the data volume through application endpoint
- Scan driver files and user-defined exit modules for malware/virus before uploading through application endpoint

### CIS Benchmarks

CIS Benchmarks are best practices for the secure configuration of a target system. CIS Benchmarks are developed through a unique consensus-based process comprised of cybersecurity professionals and subject matter experts around the world. CIS benchmark guides are developed and accepted by government, business, industry, and academia.

CIS Benchmarks for Kubernetes and Red Hat OpenShift Container platform environments are available for download from the [CIS Benchmarks website](https://learn.cisecurity.org/benchmarks). These benchmark guides provide information on hardening the master and worker nodes in the OpenShift cluster. Guidance on hardening the Red Hat Enterprise Linux OS can be found in the [Red Hat documentation](https://docs.openshift.com/container-platform/4.20/security/container_security/security-hardening.html). 

ITX Runtime Server has been hardened to a level that satisfies the IBM certification requirements for Container Software. Users are responsible for hardening of the nodes in the cluster that meets their security policies and requirements. 

## Auditing

IBM License Service provides license consumption reporting and audit readiness for IBM containerized software. IBM License Service is useful to any customer that wants to view and understand the license consumption of IBM Certified Container Software running on a Red Hat OpenShift cluster. For information about deploying IBM License Service and tracking license usage of standalone IBM Certified Container software, check the [license tracking](https://www.ibm.com/docs/en/cpfs?topic=platforms-tracking-license-usage-stand-alone-containerized-software) page.

License audit snapshot is a record of license usage in your environment over a period of time. The audit snapshot is a compressed .zip package that includes a complete set of audit documents that certify your cumulative license usage. Audit snapshot is needed for compliance and audit purposes. For core license metrics, user is obliged to use License Service and periodically generate audit snapshots to fulfill container licensing requirements. For more information about core license metrics, see [Reporter metrics](https://www.ibm.com/docs/en/cloud-paks/cp-integration/2021.4?topic=service-reported-metrics).

You do not need to complete any manual actions to prepare the license audit snapshot; you only need to generate it. At this point, the license audit snapshot is required to be generated at least once a quarter, and stored for two years in a location from which it could be retrieved and delivered to auditors. Refer to [retrieving audit page](https://www.ibm.com/docs/en/cpfs?topic=pcfls-apis#auditSnapshot) for more information on capturing license audit snapshot for compliance and audit purposes.

`Note`: The requirements might change over time. You should always make sure to follow the latest requirements that are posted on Passport Advantage.

## Documentation

For general information about the IBM Sterling Transformation Extender product portfolio, check the [Overview]( https://www.ibm.com/products/transformation-extender) page.

For more technical details about IBM Sterling Transformation in general, including designing and compiling ITX maps with the ITX Design Studio for use with ITX Runtime Server, refer to the ITX [Knowledge Center](https://www.ibm.com/docs/en/ste/11.0.3).

For additional information about the IBM Sterling Transformation Extended Runtime Server product, refer to this [support page](https://www.ibm.com/support/pages/node/7274354).


## Migration

The migration guidelines given below are applicable for the following releases -
* IBM Sterling Transformation Extender Runtime Server 10.0.3
* IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.1
* IBM Sterling Transformation Extender for Red Hat OpenShift 10.1.2

Both container and non-container variants of the Runtime REST API endpoints have been synchronized. The `/itx-rs/v1` substring in the endpoints has to be replaced with `/tx-rest/v1/itx` when invoking V1 REST API endpoints of the Runtime Server. API synchronization allows consistent invocation of REST API endpoints across environments, eases design and develop, test and deploy, maintain user applications. 

Swagger 2.0 documentation is no longer provided for REST API endpoints, only OpenAPI 3.0 documentation is provided for REST API endpoints. By default, deployed map and flow endpoints of V2 REST API are shown to user in the Swagger web UI page if `rest.defaultSwagger` property is not set to v1.

Environment variables that were supported to configure the container deployment are no longer supported. All configuration settings have to be specified through overridden config.yaml file if the default value is not suitable for your deployed environment. It is mandatory to accept the license for running the product successfully. The environment variable, `ITX_RS_LICENSE_ACCEPT`, is indirectly set during a Helm install based on the `license` parameter, which should only be set to `true` after reading through the license terms and conditions. Also note that no configuration settings are currently available for configuring catalog entry caching or Redis client connection timeouts. 

The default map extension expected by the Runtime Server has been changed from `lnx` to `mmc`. Compiled maps with .lnx extension should be renamed to .mmc extension before deploying them to the Runtime Server. If the .lnx extension is still desired, override the `rest.mapFileExtension` setting from `mmc` to `lnx`. 

`Tip`: Design Server generates platform independent compiled maps. Users may opt to generate platform independent compiled maps in Design Studio, by selecting Windows and Linux platforms under `Window > Preferences > Transformation Extender > Map > Build Options` panel. Platform independent compiled maps get .mmc extension. You may also change the default extension of the compiled map for a specific platform under `Window > Preferences > Transformation Extender > Map > Compiled Map Extensions` panel.


---
