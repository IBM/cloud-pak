# IBM Maximo AI Service Tenant Operator

This operator manages tenants within IBM Maximo AI Service.
