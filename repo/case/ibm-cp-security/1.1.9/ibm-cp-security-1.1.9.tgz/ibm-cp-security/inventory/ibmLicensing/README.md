# IBM Licensing

# Introduction

When you install this operator:

1. `ibm-licensing` namespace will be created
1. `ibm-licensing-operator` operator will be installed

## Summary

* IBM Licensing Operator is used to install the licensing service.

## Features

- IBM  Licensing  Operator manages the lifecycle of the licensing instances.

# Details

## Supported platforms

Red Hat OpenShift Container Platform 4.14 or newer installed on one of the following platforms:

   - Linux x86_64
   - Linux on Power (ppc64le)

## Prerequisites

### Resources Required

#### Minimum scheduling capacity

TODO

# Installing

For installation, see the [IBM License Service documentation](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.6?topic=service-installing-license-offline-using-pak-plugin).

## Configuration

For configuration, see the [IBM License Service documentation](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.6?topic=service-configuration).

## Storage

* No volume dependency.

## Limitations

* Deployment limits - can only deploy one instance in each cluster.

## Documentation

* Refer to [IBM License Service documentation](https://www.ibm.com/docs/en/cloud-paks/foundational-services/4.6?topic=service-installing-license) for installation and configuration.

## SecurityContextConstraints Requirements

The IBM Common Service Operator supports running with the OpenShift Container Platform 4.3 default restricted Security Context Constraints (SCCs) and IBM Cloud Pak Security Context Constraints (SCCs).

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.3/authentication/managing-security-context-constraints.html).

For more information about the IBM Cloud Pak Security Context Constraints, see [Managing Security Context Constraints](https://ibm.biz/cpkspec-scc).
