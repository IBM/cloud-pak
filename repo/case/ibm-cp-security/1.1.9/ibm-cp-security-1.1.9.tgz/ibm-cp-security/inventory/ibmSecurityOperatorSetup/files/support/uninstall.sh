#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2021. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

kubernetesCLI=oc
fs_namespace=""
cp4s_namespace=""
delete_ns="false"
del_crd="false"
uninstall_cp4s="false"
read_cr=""
force="false"
action=""
read_cr=""
read_crd=""
airgap=""
inputcase_dir=""
all_namespaces_ns="openshift-operators"

usage() {
    echo "
Please pass one of the following arguments:
    #### Uninstall CP4S
    --cp4sNamespace <CP4S-NS>         [mandatory option, if no flags are passed along with '--cp4sNamespace <CP4S-NS>' this initiates a complete cleanup of CP4S and terminates the namespace]
    --deleteCrd                       [if this flag is set, this option will delete all the CP4S CRDs]
    --force                           [if this flag is set, this option will force delete all the remaining objects from a previous uninstall and terminate namespace]
    
    #### Uninstall Foundational Services
    --inputcase_dir <inputcase_dir> [ this is the path to downloaded case] 
    --uninstallFoundationalServices <namespace> [This option runs a complete cleanup of Foundational Services and terminates the namespace. <namespace> is optional, it takes a namespace where foundational Services are installed (default: ibm-common-services)]

    "
}
####################################################################
#check if ns was provided in arguments list
function ns_provided() {
    function check_ns_exist() {
        r=$($kubernetesCLI get project $@ 2>/dev/null)
        if [[ -z $r ]]; then
            usage
            exit 77
        else
            $kubernetesCLI project $@
        fi
    }
    ##cp4s_namespace
    message='[ERROR] Namespace not provided'
    if [[ $@ == 'cp4s' ]]; then
        if [[ -z $cp4s_namespace ]]; then
            echo $message
            usage
            exit 77
        else
            check_ns_exist $cp4s_namespace
        fi
    fi

    ##fs_namespace
    if [[ $@ == 'uninstall_foundational_services' ]]; then
        if [[ -z $fs_namespace ]]; then
            echo $message
            usage
            exit 1
        else
            check_ns_exist $fs_namespace
        fi
    fi
}

####################################################################
## function to check if namespace exists
function ns_exists() {
    local namespace=$1
    $kubernetesCLI get namespace "$namespace" 2>/dev/null
}

####################################################################
## function to remove imagecontent source policy required for Airgap
function delete_sourcepolicy() {
    if [[ $airgap == 'true' ]]; then
        echo "-------------Deleting image contentsourcepolicy-------------"
        $kubernetesCLI delete imagecontentsourcepolicy ibm-cp-security --ignore-not-found=true
    fi
}

####################################################################
#cleanup catalog sourcecatalogsource
function cleanup_catalogsource() {
    echo "-------------Uninstalling $@ catalogSources-------------"
    catalog_source_name=$@
    $kubernetesCLI delete catalogsource $catalog_source_name -n openshift-marketplace --ignore-not-found=true 2>/dev/null
    if [[ $force == 'true' ]]; then
        $kubernetesCLI patch catalogsource $catalog_source_name -n openshift-marketplace --ignore-not-found=true --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
}
####################################################################
#terminate_ns
function terminate_ns() {
    ns=$@
    wait=5
    force=true

    delwh() {
        local kind="$1"
        local ns="$2"

        mh=$($kubernetesCLI get $kind -o jsonpath='{ range .items[*]}{.metadata.name}{" "}{.webhooks[0].clientConfig.service.namespace}{"\n"}{ end }' | awk -v ns=$ns '{ if ( $2 == ns) { printf "%s ", $1 }}')
        if [ -n "$mh" ]; then
            $kubernetesCLI delete $mh --wait=0
        fi
    }

    remaining() {
        local ns="$1"

        $kubernetesCLI get ns $ns -o jsonpath="{.status.conditions[?(@.reason=='SomeResourcesRemain')].message}" --ignore-not-found |\
        sed -e 's/Some resources are remaining://' -e 's/,/\n/' |\
        sed -e 's/ has .*$//'
    }

    get_ns() {
        $kubernetesCLI get namespace $ns -o name 2>/dev/null
    }

    function graceful() {
        local ns="$1"
        local wait="$2"

        iter=$(( wait * 6 ))
        $kubernetesCLI delete ns $ns --ignore-not-found --wait=0 >& /dev/null
         for i in $(seq 0 $iter)
            do
                if [ -z "$($kubernetesCLI get ns $ns -o name)" ]; then
                    echo ""
                    return 0
                fi
                sleep 10
        done

        echo "$(remaining $ns)"
    }

    if [[ "X$(get_ns $ns)" != "X" ]]; then
        echo "-------------Deleting namespace $ns-------------"
        result=$(graceful "$ns" "$wait")
        if [ -n "$result" ]; then
            if [ -z "$force" ]; then
                echo "ERROR: failed to remove namespace: $ns"
                echo "Remaining resources: $result"
                return 1
            fi
        fi

        delwh "mutatingwebhookconfiguration" "$ns"
        delwh "validatingwebhookconfiguration" "$ns"

        if [ -z "$result" ]; then
            echo "INFO: Namespace $ns has been removed"
            return 0
        fi

        for i in $(seq 1 30); do
            result=$(remaining $ns)
            if [ -z "$result" ]; then
                echo "INFO: Namespace $ns has been removed"
                return 0
            fi
            for crd in $result; do
                for cr in $($kubernetesCLI get $crd -o name -n $ns); do
                    $kubernetesCLI patch $cr -n $ns --type=merge -p '{"metadata":{"finalizers":null}}'
                done
            done
            sleep 5
        done      

        echo "ERROR: Failed to delete $ns"
        echo "Remaining resources: $result"
        return 1
    fi
}

#####################################################################
#remove finalisers
function remove_finaliser() {
    ns=$1
    obj_type=$2
    get_obj=($($kubernetesCLI get $obj_type -o name -n $ns --ignore-not-found))

    if [[ $obj_type == 'pods' ]]; then
        $kubernetesCLI get pod --no-headers | awk '{print $1}' | xargs $kubernetesCLI delete pod --force --grace-period=0 >/dev/null
    fi

    if [ -z $get_obj ]; then
        echo "* No $obj_type to patch "
    else
        for c in ${get_obj[@]}; do
            $kubernetesCLI delete $c -n $ns --wait=false 2>/dev/null
            $kubernetesCLI patch $c -n $ns --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
        done
    fi
}

####################################################################
#delete pvc, sa, csv, sub etc
function deleteObject() {
    ns=$1
    object_type=$2
    echo "-------------Deleting $object_type from $ns namespace-------------"
    pending_objs=($($kubernetesCLI get $object_type -n $ns -o name 2>/dev/null))
    if [[ ! -z $pending_objs ]]; then
        $kubernetesCLI delete $object_type -n $ns --all --wait=false --ignore-not-found
    else
        echo "[INFO] No $object_type found "
    fi
}

####################################################################
#cert manager
function remove_certmanager() {
    echo "-------------Deleting Certmanagers from $cp4s_namespace namespace-------------"
    #remove certmanagers
    cm_default=($($kubernetesCLI get certmanagers default))
    if [[ -z $cm_default ]]; then
        echo "[INFO] Default certmanager not found"
    else
        $kubernetesCLI delete certmanagers default --wait=false --ignore-not-found
        $kubernetesCLI patch certmanagers default --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
    $kubernetesCLI delete validatingwebhookconfiguration cert-manager-webhook 2>/dev/null
}

####################################################################
#delete operand request - Add patch before
function del_operandreqregistry() {
    echo "-------------Deleting operand requests from $cp4s_namespace namespace-------------"
    #del operand requests
    $kubernetesCLI delete operandrequest $@ --wait=false --ignore-not-found
    $kubernetesCLI patch operandrequest $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null

    echo "-------------Deleting operand registry from $cp4s_namespace namespace-------------"
    $kubernetesCLI delete operandregistry $@ --wait=false --ignore-not-found
    $kubernetesCLI patch operandregistry $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null

}

####################################################################
#delete CRs
function cleanup_status_check() {
    retry=40
    until [[ $retry == 0 ]]; do
        retry=$((retry - 1))
        echo "[INFO] Waiting for cleanup to complete... (Remaining checks - $retry/40)"
        sleep 15
        $kubernetesCLI get pods -n $cp4s_namespace --no-headers | grep 'Terminating' >/dev/null
        if [[ $? == 1 ]]; then
            echo "[SUCCESS] Cleanup finished successfully"
            break
        fi
        if [[ $retry == 0 ]]; then
            echo "[Error] Timed out: waiting for cleanup to finish"
            break
        fi
    done

}
delete_cp4s_crs() {
    set_crd_name1=$1
    cr_name1=$2

    $kubernetesCLI delete $set_crd_name1 $cr_name1 -n $cp4s_namespace --wait=false --ignore-not-found
    if [[ $force == 'true' ]]; then
        $kubernetesCLI patch $set_crd_name1 $cr_name1 -n $cp4s_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi

}
function run_delete_cp4s_crs() {
    ns_provided cp4s
    set_crd_name=''
    if [[ $@ == 'all' ]]; then
        echo "-------------Uninstalling $@ CRs from $cp4s_namespace namespace-------------"
        crd=$($kubernetesCLI get crd --no-headers | awk '{print $1}' | grep isc.ibm.com)

        for crds in ${crd[*]}; do
            cr_name=($($kubernetesCLI get $crds -n $cp4s_namespace --no-headers --ignore-not-found | awk '{print $1}'))
            if [[ ! -z $cr_name ]]; then
                for i in ${cr_name[*]}; do
                    delete_cp4s_crs $crds $i
                done
            else
                echo "[INFO] No CR found belonging to $crds"
            fi
        done
    else
        if [[ $@ == 'threatmgmt' ]]; then
            set_crd_name='cp4sthreatmanagements.isc.ibm.com'
        elif [[ $@ == 'cpserviceability' ]]; then
            set_crd_name="cpserviceabilities.isc.ibm.com"
        else
            set_crd_name=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep isc.ibm.com | awk '{print $1}' | grep $@)
            if [[ -z $set_crd_name ]]; then
                echo "[ERROR] Check CR name"
                exit 1
            fi
        fi

        echo "-------------Uninstalling $@ CR from $cp4s_namespace namespace-------------"
        delete_cp4s_crs $set_crd_name $@
        sleep 90

    fi

}
function clean_knativeResources() {
    this_object=$1
    this_ns=$2
    $kubernetesCLI get project $this_ns &>/dev/null
    if [[ $? -eq 0 ]]; then
        $kubernetesCLI delete $this_object -n $this_ns --ignore-not-found --wait=false 2>/dev/null
        $kubernetesCLI patch $this_object -n $this_ns --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
}
# Uninstall Knative Sandbox Resources
function uninstall_knative_sandbox() {
    echo "-------------Uninstalling cp4s-sandbox resources and terminating the namespace-------------"

    ###cp4s-sandbox
    clean_knativeResources route.serving.knative.dev/isc-cases-python3-scripting-service cp4s-sandbox
    clean_knativeResources route.serving.knative.dev/isc-cases-python3-scripting-service-cp4s cp4s-sandbox
    clean_knativeResources ingresses.networking.internal.knative.dev/isc-cases-python3-scripting-service cp4s-sandbox
    clean_knativeResources ingresses.networking.internal.knative.dev/isc-cases-python3-scripting-service-cp4s cp4s-sandbox
    terminate_ns cp4s-sandbox

}

# Uninstall Keda
function uninstall_keda() {
    echo "-------------Uninstalling Keda Resources-------------"
    # Remove Keda CR
    $kubernetesCLI delete KedaController keda -n openshift-keda --ignore-not-found

    # Remove Keda Subsciptions
    uninstall_resources_in_namespace "openshift-keda"

    terminate_ns openshift-keda

    # Delete Keda CRDs
    local keda_crds
    keda_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'keda' | awk '{print $1}')
    for crd in "${keda_crds[@]}"; do
        delete_crds "${crd}"
    done

}

# Function to terminate serverless namespace
function terminate_serverless_namespaces(){
    echo "Searching for namespaces containing '-serverless'..."

    # Get the list of namespaces containing '-serverless'
    serverless_namespaces=$($kubernetesCLI get namespaces --no-headers -o custom-columns=:metadata.name | grep '-serverless')

    # Check if any namespaces were found
    if [ -z "$serverless_namespaces" ]; then
        echo "No namespaces containing '-serverless' found."
        return
    fi

    # Loop through each found namespace
    for ns in $serverless_namespaces; do
        if [ "$ns" == "openshift-serverless" ]; then
            echo "Skipping namespace: $ns"
            continue
        fi
        echo "Processing namespace: $ns"

        # remove resources
        uninstall_resources_in_namespace "$ns"

        # terminate the namespace
        terminate_ns "$ns"
    done
}

# Function to uninstall resources in each namespace
function uninstall_resources_in_namespace() {
    local namespace="$1"

    echo "------------- Uninstalling Resources in Namespace: $namespace -------------"

    # Remove Subscriptions, CSVs, and Install Plans
    echo "Removing Subs, CSVs, and InstallPlans for $namespace..."
    $kubernetesCLI delete subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some Subscriptions, CSVs, or Install Plans still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" subscriptions.operators.coreos.com
        remove_finaliser "$namespace" clusterserviceversions.operators.coreos.com
    fi

    # Remove Deployments, DaemonSets, StatefulSets
    echo "Removing Deployments, DaemonSets, and StatefulSets in $namespace..."
    $kubernetesCLI delete deployment,daemonset,statefulset --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get deployment,daemonset,statefulset -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some Deployments, DaemonSets, or StatefulSets still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" deployment
        remove_finaliser "$namespace" daemonset
        remove_finaliser "$namespace" statefulset
    fi

    # Remove ConfigMaps and Secrets
    echo "Removing ConfigMaps and Secrets in $namespace..."
    $kubernetesCLI delete configmap,secret --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get configmap,secret -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some ConfigMaps or Secrets still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" configmap
        remove_finaliser "$namespace" secret
    fi

    # Remove remaining resources (Pods, CRs, etc.)
    echo "Removing Pods, and other resources in $namespace..."
    $kubernetesCLI delete all --all -n "$namespace" --wait=false --ignore-not-found

    pending_objs=()
    while IFS= read -r obj; do
        pending_objs+=("$obj")
    done < <($kubernetesCLI get all -n "$namespace" -o name 2>/dev/null)

    if [[ -n "${pending_objs[*]}" ]]; then
        echo "[INFO] Some resources still present, proceeding to remove finalizers..."
        remove_finaliser "$namespace" all
    fi

    # Remove remaining resources CRs
    echo "Removing Custom Resources in $namespace..."
    crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | awk '{print $1}' | grep isc.ibm.com)
    for crd in $crds; do
        pending_objs=()
        while IFS= read -r obj; do
            pending_objs+=("$obj")
        done < <($kubernetesCLI get $crd -n "$namespace" -o name --ignore-not-found)

        if [[ -n "${pending_objs[*]}" ]]; then
            echo "[INFO] Some CRs still present for CRD: $crd, proceeding to remove finalizers..."
            remove_finaliser "$namespace" "$crd"
        fi
    done

    echo "------------- Finished Uninstalling Resources in Namespace: $namespace -------------"
}

# Uninstall Knative
function uninstall_knative() {

    broker_ns=$(oc get brokers.eventing.knative.dev -A | awk '{ if ($2 == "default") print $1}' | head -1)

    echo "-------------Uninstalling Knative Eventing Resources-------------"
    # Remove Keda CRs
    remove_finaliser "knative-eventing" "KnativeKafkas"
    remove_finaliser "knative-eventing" "KnativeEventings"

    # Remove Knative Subsciptions, CSVs & InstallPlans
    uninstall_resources_in_namespace "knative-eventing"

    echo "-------------Uninstalling Knative Serving Resources-------------"
    # Remove Knative Serving CR
    remove_finaliser "knative-serving" "KnativeServings"

    # Remove Knative Serving Resources
    uninstall_resources_in_namespace "knative-serving"

    # Remove Knative Serving Ingress Resources
    uninstall_resources_in_namespace "knative-serving-ingress"

    echo "-------------Uninstalling Kafka Resources-------------"
    # Remove Knative Resources
    remove_finaliser "kafka" "kafkas"
    uninstall_resources_in_namespace "kafka"

    # Delete namespaces
    echo "Terminating namespaces..."
    terminate_ns kafka
    terminate_ns knative-eventing
    terminate_ns knative-serving
    terminate_ns knative-serving-ingress

    # Delete broker_ns if it exists
    if [ -n "$broker_ns" ]; then
        echo "Terminating broker namespace: $broker_ns"
        terminate_ns "$broker_ns"
    fi

    # Uninstall serverless namespace
    terminate_serverless_namespaces

    # Uninstall Knative Sandbox resources
    uninstall_knative_sandbox

    # Delete Knative CRDs except specific ones
    delete_knative_crds() {
        local knative_crds
        local exclude_crds=("knativeeventings.operator.knative.dev"
                            "knativekafkas.operator.serverless.openshift.io"
                            "knativeservings.operator.knative.dev")
        
        IFS=$'\n' read -rd '' -a knative_crds <<<"$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'knative' | awk '{print $1}')"
        
        for crd in "${knative_crds[@]}"; do
            skip=false
            for exclude_crd in "${exclude_crds[@]}"; do
                if [[ "$crd" == "$exclude_crd" ]]; then
                    skip=true
                    echo "Skipping CRD: $crd"
                    break
                fi
            done
            if [ "$skip" = false ]; then
                delete_crds "$crd"
            fi
        done
    }
    delete_knative_crds
}

# Remove Noobaa resources from the cluster
function uninstall_noobaa() {
    local noobaa_namespace=$1
    echo "-------------Uninstalling Noobaa Resources-------------"

    # Patch the noobaa CR to allow deletion of the CR
    $kubernetesCLI patch noobaas.noobaa.io noobaa -n "${noobaa_namespace}" --type merge -p '{"spec":{"cleanupPolicy":{"allowNoobaaDeletion":true}}}'
    # Delete validation webhook to allow deletion of Noobaa resources
    $kubernetesCLI delete ValidatingWebhookConfiguration -lolm.webhook-description-generate-name=admissionwebhook.noobaa.io

    if [[ $force == 'true' ]]; then

        #  configmap default has finalizer objectbucket.io/finalize
        remove_finaliser "${noobaa_namespace}" configmaps
        #  secrets default has finalizer objectbucket.io/finalize
        remove_finaliser "${noobaa_namespace}" secrets
        remove_finaliser "${noobaa_namespace}" bucketclasses.noobaa.io
    else
        deleteObject "${noobaa_namespace}" noobaaaccounts.noobaa.io
        deleteObject "${noobaa_namespace}" objectbucketclaims.objectbucket.io
        deleteObject "${noobaa_namespace}" objectbucket.objectbucket.io
        deleteObject "${noobaa_namespace}" bucketclasses.noobaa.io
        #  configmap -n default has finalizer objectbucket.io/finalizer
        deleteObject "${noobaa_namespace}" configmaps
        #  secrets default has finalizer objectbucket.io/finalize
        deleteObject "${noobaa_namespace}" secrets
        remove_finaliser "${noobaa_namespace}" noobaaaccounts.noobaa.io
        remove_finaliser "${noobaa_namespace}" objectbucketclaims.objectbucket.io
        remove_finaliser "${noobaa_namespace}" objectbucket.objectbucket.io

    fi

    # Remove Noobaa CR
    if ! $kubernetesCLI delete noobaas.noobaa.io noobaa -n "${noobaa_namespace}" --timeout=120s --ignore-not-found=true; then
        echo "[INFO] Patching the finalizers for Noobaa CR"
        $kubernetesCLI patch noobaas.noobaa.io noobaa -n "${noobaa_namespace}" --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi

    $kubernetesCLI delete subscriptions.operators.coreos.com,clusterserviceversions.operators.coreos.com,installplans.operators.coreos.com --all -n "${noobaa_namespace}"

    # BackingStore needs to be patched to force the removal of it - https://bugzilla.redhat.com/show_bug.cgi?id=1876633
    remove_finaliser "${noobaa_namespace}" backingstores.noobaa.io

    terminate_ns "${noobaa_namespace}"

    # Delete Noobaa CRDs
    local noobaa_crds
    noobaa_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'noobaa.io' | awk '{print $1}')
    for crd in "${noobaa_crds[@]}"; do
        delete_crds "${crd}"
    done
}

#Remove mcg from cluster
function uninstall_mcg() {
    mcg_namespace="openshift-storage"

    # Check if openshift-storage is managed by middleware
    if ! [[ $($kubernetesCLI get namespace "${mcg_namespace}" -o json | jq -r '.metadata.labels["app.kubernetes.io/managed-by"]') == "cp4s-middleware-operator" ]]; then
        echo "[INFO] Openshift-storage not managed by cp4s-middleware-operator. Skipping namespace deletion."
        return
    fi

    echo "-------------Uninstalling Multi Cloud Gateway and Noobaa Resources-------------"
    if [[ $force == 'true' ]]; then
        #  configmap default has finalizer objectbucket.io/finalize
        remove_finaliser "${mcg_namespace}" configmaps
        #  secrets default has finalizer objectbucket.io/finalize
        remove_finaliser "${mcg_namespace}" secrets
        remove_finaliser "${mcg_namespace}" bucketclass
        remove_finaliser "${mcg_namespace}" backingstore
    fi

    # Scale down operators
    $kubernetesCLI -n "${mcg_namespace}" scale deploy rook-ceph-operator odf-operator-controller-manager noobaa-operator --replicas=0 2>/dev/null

    # Patch the noobaa CR to allow deletion of the CR
    $kubernetesCLI patch noobaas.noobaa.io noobaa -n "${mcg_namespace}" --type merge -p '{"spec":{"cleanupPolicy":{"allowNoobaaDeletion":true}}}'
    # Delete validation webhook to allow deletion of Noobaa resources
    $kubernetesCLI delete ValidatingWebhookConfiguration -lolm.webhook-description-generate-name=admissionwebhook.noobaa.io

    # Delete noobaa resources
    deleteObject "${mcg_namespace}" bucketclass
    deleteObject "${mcg_namespace}" backingstore
    $kubernetesCLI delete storageclass openshift-storage.noobaa.io --ignore-not-found=true

    # Remove Noobaa CR
    remove_finaliser "${mcg_namespace}" "noobaas.noobaa.io"

    # Delete storagecluster & storagesystem
    remove_finaliser "${mcg_namespace}" "storagecluster"
    remove_finaliser "${mcg_namespace}" "storagesystem"

    # Delete remaining resources
    uninstall_resources_in_namespace "openshift-storage"

    # Delete Noobaa & odf CRDs
    local mcg_crds
    mcg_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'noobaa.io|odf|ocs' | awk '{print $1}')
    for crd in "${mcg_crds[@]}"; do
        delete_crds "${crd}"
    done

    # terminate the namespace
    terminate_ns "${mcg_namespace}"
}

####################################################################
#delete CRDs
function delete_crds() {
    $kubernetesCLI delete crd $@ --ignore-not-found --wait=false
    if [[ $force == 'true' ]]; then
        $kubernetesCLI patch crd $@ --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
    fi
}
function run_delete_crds() {
    ##########################  Deleting CRDS ##########################

    # Uninstall Noobaa before deleting all CRDs
    if ns_exists "noobaa"; then
        uninstall_noobaa "noobaa"
    fi
    if ns_exists "openshift-storage"; then
        uninstall_mcg
    fi

    # Uninstall Keda
    uninstall_keda

    # Uninstall Knative
    uninstall_knative

    # Remove subscriptions and CSVs in openshift-operators
    deleteObject $all_namespaces_ns csv
    deleteObject $all_namespaces_ns subscription
    # Remove ibm-entitlement-key secret from openshift-operators
    $kubernetesCLI delete secret ibm-entitlement-key -n $all_namespaces_ns --ignore-not-found=true

    if [[ $del_crd == 'true' ]]; then
        echo "------------Remove CRD set to $del_crd------------"
        echo "[INFO] Removing CP4S CRD : $@"

        if [[ $@ == 'all' ]]; then
            cp4s_crds=($($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E '.isc.ibm.com|getambassador.io|entitlements' | awk '{print $1}'))
            for crds1 in ${cp4s_crds[@]}; do
                delete_crds $crds1
            done
            if [[ -z $cp4s_crds ]]; then
                echo "No CRDs found"
            fi

        else
            $kubernetesCLI get crd --no-headers | grep $@ >/dev/null
            if [[ $? -ne 0 ]]; then
                echo "[ERROR] CRD $@ not found"
                exit 1
            fi
            delete_crds $@

        fi

    fi

    #delete cp4s catalogsource from -n openshift-marketplace
    if [[ $airgap == 'true' ]]; then
        echo "[INFO] Flag --airgap set to $airgap"
        #delete source policy
        delete_sourcepolicy

        #delete catalogsource
        cleanup_catalogsource cp4s
    fi
    echo "-------------Uninstallation of CRDs Completed-------------"

}

####################################################################
uninstall_cp4s() {
    echo "[INFO] Starting CP4S uninstallation process..."
    # Detect the namespace of the 'common-web-ui-config' ConfigMap
    fs_namespace="$($kubernetesCLI get configmaps --all-namespaces -o json | jq -r '.items[] | select(.metadata.name=="common-web-ui-config") | .metadata.namespace')"
    
    # Remove CP4S namespace reference from the ibm-cpp-config secretshare
    cp4s_namespace_index=$($kubernetesCLI get secretshare ibm-cpp-config -n "${fs_namespace}" -o json --ignore-not-found=true | jq --arg ns "$cp4s_namespace" '.spec.configmapshares[].sharewith | map(.namespace == $ns) | index(true)')
    $kubernetesCLI patch secretshare ibm-cpp-config -n "${fs_namespace}" --type json -p="[{'op': 'remove', 'path': '/spec/configmapshares/0/sharewith/$cp4s_namespace_index'}]"

    #delete CRs
    run_delete_cp4s_crs threatmgmt
    run_delete_cp4s_crs all

    # Delete objects
    deleteObject $cp4s_namespace csv
    deleteObject $cp4s_namespace subscription
    deleteObject $cp4s_namespace installplan
    deleteObject $cp4s_namespace serviceaccount
    deleteObject $cp4s_namespace deployment
    deleteObject $cp4s_namespace replicaset
    deleteObject $cp4s_namespace service
    deleteObject $cp4s_namespace pods
    deleteObject $cp4s_namespace pvc
    ##patch finalisers
    remove_finaliser $cp4s_namespace deployment
    remove_finaliser $cp4s_namespace replicaset
    remove_finaliser $cp4s_namespace pods
    remove_finaliser $cp4s_namespace service
    #remove certmanager
    remove_certmanager

    #del operand registry and requests
    del_operandreqregistry cp4s-threatmgmt
    del_operandreqregistry cp4s-foundations

    #force cleanup
    if [[ $force == 'true' ]]; then
        remove_finaliser $cp4s_namespace sa
        remove_finaliser $cp4s_namespace csv
        remove_finaliser $cp4s_namespace sub
        remove_finaliser $cp4s_namespace installplan
        remove_finaliser $cp4s_namespace pvc
        deleteObject $cp4s_namespace job
    fi

    #remove role bindings
    list_of_rolebindings=(rolebinding.authorization.openshift.io/admin rolebindings.rbac.authorization.k8s.io/admin-dedicated-admins rolebindings.rbac.authorization.k8s.io/admin-system:serviceaccounts:dedicated-admin)
    for role in ${list_of_rolebindings[@]}; do
        $kubernetesCLI patch $role -n $cp4s_namespace --type="json" -p '[{"op": "remove", "path":"/metadata/finalizers"}]' 2>/dev/null
        $kubernetesCLI delete $role -n $cp4s_namespace --ignore-not-found=true
    done

    #remove pending objects
    list_of_objects=(offerings.entitlements.extensions.platform.cp4s pgprocedures.isc appentitlements.entitlements.extensions.platform.cp4s clients.oidc.security operandrequests.operator rolebindings namespacescopes.operator clients.oidc.security)
    for o in ${list_of_objects[@]}; do
        for p in $($kubernetesCLI get $o.ibm.com -o name --ignore-not-found); do
            $kubernetesCLI delete $p -n $cp4s_namespace --wait=false --ignore-not-found 2>/dev/null
            $kubernetesCLI patch $p -n $cp4s_namespace --type json -p='[{"op": "remove", "path": "/metadata/finalizers"}]' 2>/dev/null
        done
    done

    #delete cp4s catalogsource from -n openshift-marketplace
    if [[ $airgap == 'true' ]]; then
        echo "[INFO] Flag --airgap set to $airgap"
        delete_sourcepolicy
        cleanup_catalogsource cp4s
    fi

    # Terminate the CP4S namespace
    if [[ "$fs_namespace" != "$cp4s_namespace" ]]; then
        echo "[INFO] Common Services is in a different namespace ($fs_namespace). Deleting CP4S namespace: $cp4s_namespace..."
        uninstall_resources_in_namespace "$cp4s_namespace"
        terminate_ns "$cp4s_namespace"
    else
        echo "[INFO] Common Services shares the same namespace as CP4S ($cp4s_namespace). Skipping namespace deletion."
    fi

    echo "[SUCCESS] CP4S uninstallation process completed."
}


# Uninstall IBM Licensing
function uninstall_ibm_licensing() {
    echo "-------------Uninstalling Licensing Resources-------------"

    # Remove resources
    echo "Removing any IBMLicensing related CRs..."
    oc delete ibmlicensing --all  --ignore-not-found
    uninstall_resources_in_namespace ibm_licensing

    # Delete any IBM-Licensing Related CRDs
    echo "Removing any IBM-Licensing related CRDs..."
    local ibm_licensing_crds
    ibm_licensing_crds="ibmlicensings.operator.ibm.com ibmlicensingdefinitions.operator.ibm.com ibmlicensingmetadatas.operator.ibm.com ibmlicensingquerysources.operator.ibm.com"

    for crd in $ibm_licensing_crds; do
        echo "Deleting CRD: $crd"
        $kubernetesCLI delete crd "$crd" --ignore-not-found
    done
    
    terminate_ns ibm-licensing 

    # Delete any ibm-licensing-Related CRDs after namespace termination
    echo "Removing ibm-licensing related CRDs..."
    local ibm_licensing_crds
    ibm_licensing_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'ibm-licensing' | awk '{print $1}')
    for crd in $ibm_licensing_crds; do
        echo "Deleting CRD: $crd"
        $kubernetesCLI delete crd "$crd" --ignore-not-found
    done

    echo "-------------Uninstallation of IBM-Licensing Completed-------------"
}


# Uninstall Cert-Manager
function uninstall_cert_manager() {
    echo "-------------Uninstalling Cert-Manager Resources-------------"

    # Remove Subs, CSVs, and Install Plans
    uninstall_resources_in_namespace "cert-manager-operator"
    uninstall_resources_in_namespace "cert-manager"

    # Terminate the Cert-Manager and Cert-Manager-Operator Namespaces
    echo "Terminating cert-manager and cert-manager-operator namespaces..."
    terminate_ns cert-manager-operator
    terminate_ns cert-manager
    
    # Delete any Cert-Manager-Related CRDs after namespace termination
    echo "Removing Cert-Manager related CRDs..."
    local cert_manager_crds
    cert_manager_crds=$($kubernetesCLI get crd --no-headers --ignore-not-found | grep -E 'cert-manager' | awk '{print $1}')
    for crd in $cert_manager_crds; do
        echo "Deleting CRD: $crd"
        $kubernetesCLI delete crd "$crd" --ignore-not-found
    done

    echo "-------------Uninstallation of Cert-Manager Completed-------------"
}

####################################################################
#uninstall Foundational Services
function err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}
function uninstall_foundational_services() {
    if [[ -z $fs_namespace ]]; then 
        echo '[WARNING] No namespace passed to Foundational Services uninstall.'
        echo '[INFO] Finding Foundational Services namespace using common-web-ui-config configmap'
        fs_namespace="$($kubernetesCLI get configmaps --all-namespaces -o json | jq -r '.items[] | select(.metadata.name=="common-web-ui-config") | .metadata.namespace')"
        namespace_count=$(echo "$fs_namespace" | wc -l)
        if [[ "$namespace_count" -gt 1 ]]; then
            err_exit "Common services detected in multiple namespaces, please run command specifying --namespace"
        fi
    fi
    
    if [[ -z "$fs_namespace" ]]; then
        err_exit "Foundational Services namespace not detected. Exiting ..."
    fi
    
    ns_provided uninstall_foundational_services

    if [[ -z ${inputcase_dir} ]]; then
        echo "[ERROR] Case directory not found"
        exit 1
    fi

    echo "[WARNING] uninstalling CloudPak Foundational Services will delete CP4S dependencies. It is ideal to uninstall CP4S first before running this action."
    echo "Starting uninstall in 5 seconds, press CTRL+C if you wish to discontinue."
    sleep 5
    echo "-------------Uninstalling Common Services-------------"
    local caseName="ibm-cp-common-services"
    local caseVersion=""
    caseFound=$(ls "${inputcase_dir}"/${caseName}-*.tgz)
# we may have CS cvs and subscriptions in openshift-operators namespace
    cscsv=$($kubernetesCLI get subscription.operators.coreos.com -n openshift-operators ibm-common-service-operator-v3-ibm-operator-catalog-openshift-marketplace -o jsonpath="{.status.installedCSV}")
    if [ -z "$cscsv" ]; then
      cscsv=$($kubernetesCLI get subscription.operators.coreos.com -n openshift-operators ibm-common-service-operator -o jsonpath="{.status.installedCSV}")
    fi 
    if [ -n "$cscsv" ]; then
       $kubernetesCLI delete csv -n openshift-operators $cscsv --ignore-not-found=true 
    fi   
    $kubernetesCLI delete subscriptions.operators.coreos.com -n openshift-operators --ignore-not-found=true ibm-common-service-operator-v3-ibm-operator-catalog-openshift-marketplace ibm-common-service-operator
    
    # Uninstall IBM Licensing
    uninstall_ibm_licensing

    # Uninstall Cert Manager
    uninstall_cert_manager

    uninstall_resources_in_namespace "$fs_namespace"
    remove_finaliser "${fs_namespace}" authentications.operator.ibm.com
    remove_finaliser "${fs_namespace}" operandbindinfos.operator.ibm.com

    if [[ ${caseFound} == *"no matches found"* ]]; then
        err_exit "CASE named ${caseName} not found."
    else
        echo "[INFO] Found CASE folder for ${caseName}: ${caseFound}"
        caseVersion=$(echo ${caseFound} | grep -o '\-[[:digit:]].*[[:digit:]].tgz' | sed -e "s/^\-//" -e "s/.tgz//")
        echo "[INFO] CASE version: ${caseVersion}"
    fi
    local inventoryOfOperator="ibmCommonServiceOperatorSetup"

    if [[ "$airgap" != "true" ]] || [[ "X$uninstall_method" == "Xcatalog" ]]; then
        url="$repo"
    else
        url="icr.io"
    fi

    if ! oc ibm-pak launch --case "${caseFound}" --version "${caseVersion}" --namespace "${fs_namespace}" --inventory "$inventoryOfOperator" --action uninstall-catalog --args "--registry $url" --tolerance 1; then
        err_exit "Failed to uninstall  CloudPak Foundational Services catalog"
    fi

    if ! oc ibm-pak launch --case "${caseFound}" --version "${caseVersion}" --namespace "${fs_namespace}" --inventory "$inventoryOfOperator" --action uninstall-operator --tolerance 1; then
        err_exit "Failed to uninstall  CloudPak Foundational Services operator"
    fi

    terminate_ns "$fs_namespace"
}

####################################################################
#execute actions as per flags
function execute_actions() {
    if [[ $force == 'true' ]]; then
        echo "[INFO] Force cleanup is enabled"
    fi
    if [[ $del_crd == 'true' ]]; then
        run_delete_crds $read_crd
    elif [[ $uninstall_cp4s == 'true' ]]; then
        uninstall_cp4s
    fi
}

####################################################################
#function to store flags
function read_flags() {
    if [[ $@ == '' ]]; then
        echo "[ERROR] Incorrect way of passing arguments!"
        usage
        exit 77
    elif [[ $@ == 'delete_crd' ]]; then
        del_crd='true'
    elif [[ $@ == 'uninstall_cp4s' ]]; then
        uninstall_cp4s='true'
    fi
}

####################################################################
#read input from user
while true; do
    flag="$1"
    shift
    if [ -z "$flag" ]; then
        break
    fi
    case $flag in
    --cp4sNamespace)
        cp4s_namespace=$1
        read_flags uninstall_cp4s
        shift
        ;;
    --inputcase_dir)
        inputcase_dir=$1
        shift
        ;;
    --uninstallFoundationalServices)
        fs_namespace=$1
        uninstall_foundational_services
        shift
        ;;
    --deleteCrd)
        read_crd=$1
        if [[ -z $read_crd ]] || [[ $read_crd == '--force' ]] || [[ $read_crd == '--airgap' ]]; then
            if [[ $read_crd == '--airgap' ]]; then
                airgap=true
            fi
            if [[ $read_crd == '--force' ]]; then
                force=true
            fi
            read_crd='all'
        fi
        read_flags delete_crd
        shift
        ;;
    --airgap)
        airgap='true'
        shift
        ;;
    --force)
        force='true'
        shift
        ;;
    *)
        echo "Invalid flag $flag"
        usage
        exit 77
        ;;
    esac
done
#call execute actions
execute_actions
