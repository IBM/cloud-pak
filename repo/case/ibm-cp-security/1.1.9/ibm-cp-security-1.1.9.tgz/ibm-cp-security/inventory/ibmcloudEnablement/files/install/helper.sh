#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2023. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

#===  CONSTANTS  ================================================================
caseVersion=""

# Read the CASE version from the case.yaml file
getCaseVersion() {
    # path to case.yaml from where we pull the version of CASE
    local caseYaml="${casepath}/case.yaml"
    # check if the case file is there if not then download the case
    if [ -f "$caseYaml" ]; then
        echo "[INFO] $caseYaml exists."
    else
        echo "[INFO] $caseYaml don't exists. Missing case.yaml file."
    fi
    local localCaseVersion=""
    localCaseVersion=$(grep "version:" "${caseYaml}" | awk '{print $2}')
    if [[ -z "$localCaseVersion" ]]; then
        err_exit "[ERROR] Cannot find CASE version in YAML."
    else
        echo "[INFO] CASE version in YAML: ${localCaseVersion}"
        caseVersion="${localCaseVersion}"
    fi
}

# Pull the CASE using IBM Pak plugin
getCase() {
    if [[ -n "$httpCaseUsername" ]]; then
        echo "[INFO] Pulling from internal CASE repo"

        # Configure IBM Pak plugin to pull CASE from internal repo
        oc ibm-pak config repo 'Internal CP4S CASE repo' --url https://raw.github.ibm.com/security-secops/cp4s-case/main/repo/case --enable

        # Setup environment variables required by IBM Pak plugin
        export HTTP_CASE_USER_NAME=$httpCaseUsername
        export HTTP_CASE_PASSWORD=$httpCasePassword
        export CASECTL_RESOLVERS_LOCATION="${base_dir}/resolvers.yaml"
        export CASECTL_RESOLVERS_AUTH_LOCATION="${base_dir}/resolvers_auth.yaml"
        export CASE_NAME=ibm-cp-security
        export CASE_VERSION=$caseVersion

        # Prepare resolver files
        sed -i -e "s/REPLACE_EMAIL/$HTTP_CASE_USER_NAME/g" "${CASECTL_RESOLVERS_AUTH_LOCATION}"
        sed -i -e "s/REPLACE_GH_TOKEN/$HTTP_CASE_PASSWORD/g" "${CASECTL_RESOLVERS_AUTH_LOCATION}"
        echo "[INFO] Environment variables have been set."
    fi

    if ! oc ibm-pak get ibm-cp-security --version $caseVersion --disable-top-level-images-mode --skip-verify; then
        error_exit "[ERROR] Failed to download QRadar Suite CASE."
    fi
}

extractCase() {
    tar -xf \
        ~/.ibm-pak/data/cases/ibm-cp-security/${caseVersion}/ibm-cp-security-${caseVersion}.tgz \
        -C ~/.ibm-pak/data/cases/ibm-cp-security/${caseVersion}
}

# exposing binaries
export caseVersion=${caseVersion}
