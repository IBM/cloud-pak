#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2023. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

#===  CONSTANTS  ================================================================

# download oc ibm-pak plugin
function install_oc_ibm_pak() {
    if ! wget https://github.com/IBM/ibm-pak-plugin/releases/latest/download/oc-ibm_pak-linux-amd64.tar.gz -O /tmp/oc-ibm_pak.tar.gz; then
        error_exit "Failed to download oc ibm-pak plugin"
    fi
    tar xvfz /tmp/oc-ibm_pak.tar.gz
    chmod +x oc-ibm_pak-*-amd64
    mv oc-ibm_pak-*-amd64 "${base_dir}"/oc-ibm_pak
    oc ibm-pak --version
}

# exposing binaries
export PATH=${base_dir}:$PATH
