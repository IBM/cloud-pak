# ibm-pg-operator Setup for OCP 4.6+

## Install ibm-pg-operator through CP4S Case on OCP

The PG Operator will be deployed as part of the overall CP4S

