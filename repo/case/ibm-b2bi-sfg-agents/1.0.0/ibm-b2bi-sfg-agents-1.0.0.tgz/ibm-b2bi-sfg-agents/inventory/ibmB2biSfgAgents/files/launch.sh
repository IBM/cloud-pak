#!/usr/bin/env bash
#
# Simplified launcher for the ibmB2biSfgAgents inventory item.
#
# SCOPE / LIMITATIONS: this is a lightweight `helm install`/`upgrade`/
# `uninstall` wrapper, NOT a full reimplementation of the generic
# `cloudctl case launch` tooling (no image mirroring / air-gap / catalog
# install support). It has not been validated against a real `cloudctl`
# invocation — no CASE CLI was available while authoring this CASE. Prefer
# calling `helm` directly (see ../../../README.md "Installing without
# cloudctl") unless you have verified this script's flag handling against
# your `cloudctl` version first.
#
# Usage:
#   ./launch.sh --action install --namespace <ns> --instance <release-name> \
#     [--args "--set key=value --set key2=value2"] [--dryRun]
#   ./launch.sh --action uninstall --namespace <ns> --instance <release-name>

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# case/ibm-b2bi-sfg-agents/inventory/ibmB2biSfgAgents/files -> up 5 levels to
# the CASE bundle root, then into the sibling charts/ directory populated by
# ../../../../../../scripts/build-case-bundle.sh.
CHART_DIR="${CHART_DIR:-$SCRIPT_DIR/../../../../../charts/ibm-b2bi-sfg-agents}"

action=""
namespace=""
instance=""
extraArgs=""
dryRun=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --action) action="$2"; shift 2 ;;
    --namespace) namespace="$2"; shift 2 ;;
    --instance) instance="$2"; shift 2 ;;
    --args) extraArgs="$2"; shift 2 ;;
    --dryRun) dryRun=true; shift ;;
    *) echo "launch.sh: unknown option: $1" >&2; exit 1 ;;
  esac
done

if [[ -z "$action" || -z "$namespace" || -z "$instance" ]]; then
  echo "Usage: $0 --action install|uninstall --namespace <ns> --instance <release-name> [--args \"--set ...\"] [--dryRun]" >&2
  exit 1
fi

if [[ ! -d "$CHART_DIR" ]]; then
  echo "launch.sh: chart directory not found at $CHART_DIR — this CASE has not been packaged yet (charts/ is populated at package time, see repo deploy/ tooling)." >&2
  exit 1
fi

case "$action" in
  install)
    helmArgs=(upgrade --install "$instance" "$CHART_DIR" --namespace "$namespace" --create-namespace)
    [[ "$dryRun" == true ]] && helmArgs+=(--dry-run)
    # shellcheck disable=SC2086
    helm "${helmArgs[@]}" $extraArgs
    ;;
  uninstall)
    helmArgs=(uninstall "$instance" --namespace "$namespace")
    [[ "$dryRun" == true ]] && helmArgs+=(--dry-run)
    helm "${helmArgs[@]}"
    ;;
  *)
    echo "launch.sh: unknown action '$action' (expected install|uninstall)" >&2
    exit 1
    ;;
esac
