# ibmB2biSfgAgents inventory item

Deploys the `ibm-b2bi-sfg-agents` Helm chart (agent + co-located MCP server)
into a single target namespace. `k8sScope: namespace` — no cluster-scoped
resources are created.

## Required values at install time

At minimum, override:

- `global.license=true` — license acceptance gate
- `istio.installed=true` — only if `istio.enabled` (default `true`) is kept;
  set `istio.enabled=false` instead on clusters without a service mesh
- `mcpServer.b2bi.baseUrl` — your B2BI/SFG instance URL
- `mcpServer.b2bi.existingSecretName` (or the inline `username`/`password`/
  `apiToken` convenience values — dev/quick-start only)

See `../../../../helm/ibm-b2bi-sfg-agents/README.md` for the full values
reference.

## Files

- `inventory.yaml` — declares this as a namespace-scoped inventory item
- `resources.yaml` — Helm chart + container image references (see file for
  registry placeholder notes)
- `actions.yaml` — `install`/`uninstall` actions, `namespaceAdmin` role only,
  namespace-scoped `k8sPermissions` only (no ClusterRole/CRD creation)
- `files/launch.sh` — simplified `helm`-based launcher script (see its header
  for scope and validation status)
