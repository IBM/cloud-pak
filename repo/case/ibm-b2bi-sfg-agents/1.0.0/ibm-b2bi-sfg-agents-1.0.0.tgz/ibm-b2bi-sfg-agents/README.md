# IBM Sterling B2B Integrator / File Gateway Agentic Service

## Introduction

The Agentic Foundation Service hosts IBM Sterling B2B Integrator (B2BI) and
Sterling File Gateway (SFG) AI agents and self-registers them with an
Agent Hub. It is deployed alongside its co-located MCP tool server
(`b2bi-mcp-server`), which exposes B2BI/SFG REST APIs as agent-callable tools.

This CASE provides a Helm chart (`ibm-b2bi-sfg-agents`) that deploys both
workloads as a single release. See
`../../../helm/ibm-b2bi-sfg-agents/README.md` for the full chart
documentation (values, security model, Istio vs. native mTLS, secrets).

> **Certification status:** this CASE has not yet been submitted for formal
> IBM Cloud Pak certification. No certification claim is made in `case.yaml`.

## Prerequisites

1. Kubernetes >= 1.29, or Red Hat OpenShift Container Platform >= 4.19
2. Helm >= 3.14
3. All pods run under the built-in `restricted-v2` SCC (OpenShift) /
   restricted Pod Security Standard (vanilla Kubernetes) — no custom
   SecurityContextConstraints or PodSecurityPolicy needs to be pre-created.
4. **Optional but recommended on OCP:** OpenShift Service Mesh (Istio) >= 3.3,
   with the target namespace enrolled (`istio-injection=enabled` label). Not
   a hard requirement — see the chart's native mTLS fallback.
5. A reachable B2BI/SFG instance and credentials for the MCP server.
6. Container images for `b2bi-sfg-agents` and `b2bi-mcp-server` pushed to a
   registry reachable from the cluster (see `inventory/ibmB2biSfgAgents/resources.yaml`).
7. Ensure the target namespace has a `ServiceAccount` this CASE can bind its
   Role to (the chart creates its own `ServiceAccount` by default).

## Contents

```
case.yaml            # CASE descriptor — single inventory item, no certification claim yet
prereqs.yaml          # k8sDistros only — no custom SCC/PSP prerequisite
roles.yaml            # namespaceAdmin only — this CASE never requires cluster-admin
LICENSE               # Apache License 2.0 (matches the source repo)
licenses/notices      # third-party notices placeholder — see file for generation instructions
inventory/
  ibmB2biSfgAgents/
    inventory.yaml     # k8sScope: namespace
    resources.yaml      # helm chart + container image references
    actions.yaml         # install/uninstall actions (namespaceAdmin, namespace-scoped k8sPermissions only)
    files/launch.sh       # simplified helm-based launcher (see file header for scope/limitations)
```

## Installing without `cloudctl`

This CASE has not been validated against the `cloudctl case launch` CLI (no
CASE tooling was available while authoring it). The straightforward path is
to install the Helm chart directly:

```console
kubectl create namespace your-namespace
kubectl label namespace your-namespace istio-injection=enabled  # required — istio.enabled=true is the chart default

helm install my-agents ../../../helm/ibm-b2bi-sfg-agents \
  --namespace your-namespace \
  --set global.license=true \
  --set istio.installed=true \
  --set agents.hub.registryUrl=https://agent-hub:8443/v1/registry/agents \
  --set mcpServer.b2bi.baseUrl=https://your-b2bi-host:9080 \
  --set mcpServer.b2bi.existingSecretName=my-b2bi-creds
```

`your-namespace` is just a placeholder — use your own project/namespace name.
See the chart's own [README.md](../../../helm/ibm-b2bi-sfg-agents/README.md)
(Prerequisites / Network policy sections) for the sidecar-injection and
NetworkPolicy details this example depends on.

`inventory/ibmB2biSfgAgents/files/launch.sh` wraps the same `helm` invocation
for use via `cloudctl case launch` — validate it against your `cloudctl`
version before relying on it in production.
