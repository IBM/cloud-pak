# IBM Operator for Apache Flink

## Introduction

You can use this image to install the IBM Operator for Apache Flink, which acts as a control plane to manage the complete deployment lifecycle of your [Flink](https://flink.apache.org) instances. The operator is part of the Event Processing capability within IBM Event Automation.

## Links to external documentation

For more information about installing the IBM Operator for Apache Flink, see the installation instructions in the [documentation](https://ibm.biz/ep-installing-flink).
