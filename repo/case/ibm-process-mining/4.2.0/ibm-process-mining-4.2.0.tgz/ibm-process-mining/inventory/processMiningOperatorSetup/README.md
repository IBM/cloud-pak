# Process Mining Operator Setup

## Overview

This inventory contains the resources and scripts needed to set up the IBM Process Mining Operator on an OpenShift cluster. The operator manages the lifecycle of Process Mining and Task Mining components, including deployment, configuration, and upgrades.

## Contents

### Files

- **`launch.sh`** - Main launch script for operator setup
- **`launch-impl.sh`** - Implementation script with core logic
- **`airgap.sh`** - Air-gapped environment setup script
- **`processmining_v1beta1_processmining.yaml`** - Sample ProcessMining Custom Resource

### OLM Resources (`op-olm/`)

- **`catalog_source.yaml`** - Defines the operator catalog source
- **`operator_group.yaml`** - Configures the operator group for the namespace
- **`subscription.yaml`** - Creates operator subscription for automatic updates

## Usage

### Standard Installation

1. Set required environment variables:
   ```bash
   export PM_PROJECT="process-mining"
   ```

2. Run the setup script:
   ```bash
   ./launch.sh
   ```

The script will:
- Create the target namespace
- Install required catalog sources
- Create operator group and subscription
- Wait for operator installation
- Deploy the ProcessMining custom resource

### Air-Gapped Installation

For air-gapped environments, use the airgap.sh script to mirror images:

```bash
# Mirror images to local registry
./airgap.sh image mirror --dir ./offline --to-registry registry.example.com:5000

# Configure cluster
./airgap.sh cluster apply-image-policy --name process-mining --dir ./offline --registry registry.example.com:5000
```

See the [Air-Gap CLI documentation](../../../../submodules/cloud-pak-airgap-cli/README.md) for complete details.

## Custom Resource Configuration

The `processmining_v1beta1_processmining.yaml` file provides a sample configuration. Key parameters:

### License Acceptance
```yaml
spec:
  license:
    accept: true  # Must be set to true
```

### Storage Configuration
```yaml
spec:
  processMining:
    storage:
      storageClassName: "nfs-storage"  # Must support ReadWriteMany
      size: "20Gi"
```

### Task Mining Configuration
```yaml
spec:
  taskMining:
    enabled: true  # Enable/disable Task Mining component
    storage:
      storageClassName: "nfs-storage"
      size: "50Gi"
```

### Database Configuration
```yaml
spec:
  processMining:
    database:
      type: "postgresql"  # or "embedded"
      # For external database:
      host: "postgres.example.com"
      port: 5432
      name: "processmining"
```

## Prerequisites

### Cluster Requirements
- **OpenShift**: 4.11 or higher
- **Access**: Cluster admin privileges
- **Storage**: Storage class with ReadWriteMany support (NFS, GlusterFS, or cloud-specific)

### Resource Requirements

| Component | Memory (GB) | CPU (cores) | Disk (GB) |
|-----------|-------------|-------------|-----------|
| Process Mining | 64 | 8 | 100 |
| Task Mining | 32 | 8 | 100 |
| **Total** | 96 | 16 | 200 |

### Required Credentials
- **IBM Entitlement Key**: For pulling images from IBM Container Registry
- **Registry Credentials**: For staging/production registries (if applicable)

## Installation Steps

### 1. Prepare Environment

```bash
# Login to OpenShift cluster
oc login --token=<token> --server=https://api.cluster.example.com:6443

# Set target namespace
export PM_PROJECT="process-mining"

# Set IBM Entitlement Key (if needed)
export IBM_ENTITLEMENT_KEY="your-key-here"
```

### 2. Create Namespace

```bash
oc new-project $PM_PROJECT
```

### 3. Create Image Pull Secret

```bash
oc create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=$IBM_ENTITLEMENT_KEY \
  --namespace=$PM_PROJECT
```

### 4. Install Operator

```bash
# Apply catalog sources
oc apply -f op-olm/catalog_source.yaml

# Create operator group
oc apply -f op-olm/operator_group.yaml

# Create subscription
oc apply -f op-olm/subscription.yaml
```

### 5. Wait for Operator Installation

```bash
# Check operator status
oc get csv -n $PM_PROJECT

# Wait for operator to be ready
oc wait --for=condition=Succeeded csv/ibm-automation-processmining.v4.1.0 -n $PM_PROJECT --timeout=600s
```

### 6. Deploy ProcessMining Instance

```bash
# Edit the sample CR as needed
vi processmining_v1beta1_processmining.yaml

# Apply the custom resource
oc apply -f processmining_v1beta1_processmining.yaml -n $PM_PROJECT
```

### 7. Verify Installation

```bash
# Check ProcessMining resource status
oc get processmining -n $PM_PROJECT

# Check all pods are running
oc get pods -n $PM_PROJECT

# Check routes
oc get routes -n $PM_PROJECT
```

## Troubleshooting

### Operator Not Installing

**Symptom**: Subscription created but operator not appearing

**Check subscription status**:
```bash
oc get subscription -n $PM_PROJECT
oc describe subscription processmining-operator -n $PM_PROJECT
```

**Check catalog source**:
```bash
oc get catalogsource -n openshift-marketplace
oc describe catalogsource processmining-catalog -n openshift-marketplace
```

**Common causes**:
- Catalog source image not accessible
- Invalid registry credentials
- Network connectivity issues

### Pods Not Starting

**Symptom**: Pods in Pending, CrashLoopBackOff, or ImagePullBackOff state

**Check pod status**:
```bash
oc get pods -n $PM_PROJECT
oc describe pod <pod-name> -n $PM_PROJECT
```

**Check operator logs**:
```bash
oc logs -n $PM_PROJECT deployment/processmining-operator-controller-manager
```

**Common causes**:
- Insufficient resources (CPU/Memory)
- Storage class not available or not ReadWriteMany
- Image pull secrets missing or invalid
- PVC not binding

### Storage Issues

**Symptom**: PVCs in Pending state

**Check PVC status**:
```bash
oc get pvc -n $PM_PROJECT
oc describe pvc <pvc-name> -n $PM_PROJECT
```

**Verify storage class**:
```bash
oc get storageclass
oc describe storageclass <storage-class-name>
```

**Requirements**:
- Storage class must support ReadWriteMany access mode
- Sufficient storage capacity available
- Storage provisioner is functioning

### Database Connection Issues

**Symptom**: Application pods failing with database connection errors

**Check database connectivity**:
```bash
# For embedded database
oc get pods -n $PM_PROJECT | grep postgres

# For external database
oc run -it --rm debug --image=postgres:13 --restart=Never -- psql -h <db-host> -U <db-user> -d <db-name>
```

**Verify credentials**:
```bash
oc get secret processmining-db-secret -n $PM_PROJECT -o yaml
```

### Image Pull Errors

**Symptom**: ImagePullBackOff or ErrImagePull

**Check image pull secret**:
```bash
oc get secret ibm-entitlement-key -n $PM_PROJECT
```

**Verify image exists**:
```bash
skopeo inspect docker://cp.icr.io/cp/processmining-app:2.1.1
```

**Test registry access**:
```bash
podman login cp.icr.io --username cp --password $IBM_ENTITLEMENT_KEY
```

## Validation

### Health Checks

```bash
# Check all pods are running
oc get pods -n $PM_PROJECT --field-selector=status.phase=Running

# Check ProcessMining CR status
oc get processmining -n $PM_PROJECT -o jsonpath='{.items[0].status.conditions}'

# Check service endpoints
oc get endpoints -n $PM_PROJECT
```

### Access Application

```bash
# Get application route
ROUTE=$(oc get route processmining -n $PM_PROJECT -o jsonpath='{.spec.host}')
echo "Access Process Mining at: https://$ROUTE"

# Test connectivity
curl -k https://$ROUTE/health
```

## Upgrade Procedure

### Operator Upgrade

The operator automatically upgrades when a new version is available in the catalog source (if automatic approval is enabled).

**Manual upgrade**:
```bash
# Check available versions
oc get packagemanifest processmining-operator -o jsonpath='{.status.channels[*].currentCSV}'

# Update subscription to new version
oc patch subscription processmining-operator -n $PM_PROJECT --type merge -p '{"spec":{"channel":"v4.1"}}'
```

### Application Upgrade

Update the ProcessMining CR with new version:
```bash
oc edit processmining processmining-instance -n $PM_PROJECT
```

Change the version field:
```yaml
spec:
  version: "2.1.1"  # Update to new version
```

## Uninstallation

### Remove ProcessMining Instance

```bash
oc delete processmining processmining-instance -n $PM_PROJECT
```

### Remove Operator

```bash
# Delete subscription
oc delete subscription processmining-operator -n $PM_PROJECT

# Delete CSV
oc delete csv ibm-automation-processmining.v4.1.0 -n $PM_PROJECT

# Delete operator group
oc delete operatorgroup processmining-operator-group -n $PM_PROJECT
```

### Clean Up Resources

```bash
# Delete PVCs (WARNING: This deletes all data)
oc delete pvc --all -n $PM_PROJECT

# Delete namespace
oc delete project $PM_PROJECT
```

## Related Documentation

- [Main README](../../../../README.md) - Repository overview
- [Scripts Documentation](../../../../scripts/README.md) - Automation scripts guide
- [Product Documentation](https://ibm.biz/ibm-process-mining) - Official product documentation
- [Installation Guide](https://ibm.biz/pm-install) - Detailed installation instructions
- [Air-Gap CLI](../../../../submodules/cloud-pak-airgap-cli/README.md) - Air-gapped deployment tools

## Support

For issues and questions:
- **Product Issues**: Contact IBM Support
- **Installation Issues**: Check troubleshooting section above
- **Documentation**: https://ibm.biz/ibm-process-mining

---

**Last Updated**: 2026-04-29  
**Version**: 4.1.0  
**Product Version**: 2.1.1
