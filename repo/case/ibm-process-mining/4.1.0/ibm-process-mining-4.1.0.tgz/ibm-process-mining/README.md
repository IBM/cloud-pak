# Name

IBM&reg; Process Mining

# Introduction

## Summary

IBM Process and Task Mining is a process mining and Digital Twin of an Organization solution that offers a low-cost, fail-fast approach to analyze, constantly monitor, improve business processes, and drive digital transformation. 
IBM Process Mining discovers the end-to-end process streamline and identifies process behavior, compliance, performance, resources involved and their roles. 
It's advanced analytics monitor process deviation, KPI alignment, and bottlenecks.

## Features

IBM Process Mining is a process mining solution that automatically discovers, constantly monitors, and optimizes business processes. Process mining uses business system data to create and visualize an end-to-end process that includes all the process activities involved along with the various process paths. Businesses can easily analyze the discovered process to gain actionable insights for process improvement.

Simulation is a feature of IBM Process Mining that businesses can use to test unlimited process changes. SImulation combines historical data with contextual data, like decision rules, to create what-if scenarios that are then analyzed for incredibly fast and simple results. Simulation shows how process changes affect future process behavior along with new benefits and reliable ROI. Businesses can also create simulations from scratch without the need for historical data so that processes can be tested and successfully introduced to business operations with immediate benefits.

IBM Process Mining facilitates process automation by finding the best process candidates for automation, calculating expected ROI, and showing the impact of automation initiatives on the entire process before implementation. IBM Task Mining integrates with IBM Process Mining for a better understanding of how manual processes impact the business process. IBM Task Mining captures and sends real user interaction data to IBM Process Mining to create an augmented process model. The result is deeper insights for automation projects than what process mining alone can provide.

## Details
The operator supports instances of type `ProcessMining` .

The ProcessMining is the custom resource used to install and upgrade the Process Mining capabilities in a Cloud Pak.

## Prerequisites

- Redhat Openshift Container Platform version 4.11 and above
- NFS Server or Gluster File System or cloud-specific storage system. ReadWriteMany option must be supported by the storage class. 
- Mongo Db v3.6 or above and MySQL 5.7 or above for production environment.

### Resources Required

Minimum cluster capacity:

| Software               | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| -------------------- | ----------- | ----------- | --------- | ----- |
|  Process Mining   | 64          | 8           | 100       | 1     |
|  Task Mining      | 32          | 8           | 100       | 1     |
| **Total**         | 96          | 16          | 200       | 2     |

## Installing

### Download required container images.

To get access to the Process Mining container images from the IBM Entitled Registry, you must have an IBM entitlement registry key to pull the images. 
For additional details regarding container images check: https://ibm.biz/pm-images

### Installing the operator

To install process mining in a Cloud Pak, first install the Cloud Pak.

The Process Mining operator defines a ProcessMining Custom Resource Definition (CRD) in Kubernetes that you use to install the process mining capabilities in the Cloud Pak user interface.

The Process Mining CRD must be deployed in the same kubernetes namespace so that Process Mining augments the Cloud Pak user interface with new menu entries and user roles.

If you do not want to install the Cloud Pak, you can still deploy the Process Mining CRD in a namespace that does not have any Cloud Pak installed. 

The product is installed through the Operator Lifecycle Manager, following the instructions in the OpenShift documentation for [custom catalogs](https://docs.openshift.com/container-platform/latest/operators/admin/olm-managing-custom-catalogs.html).

Create a new `ProcessMining` CRD in the target namespace, then create a new `Subscription` .

Details regarding installation can be found [here](https://ibm.biz/pm-install). 


### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition: 


```yaml
    kind: SecurityContextConstraints
    metadata:
    annotations:
        kubernetes.io/description: restricted denies access to all host features and requires
        pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
        is the most restrictive SCC and it is used by default for authenticated users.
        release.openshift.io/create-only: "true"
    name: processmining-scc-restricted
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - KILL
    - MKNOD
    - SETUID
    - SETGID
    runAsUser:
    type: MustRunAsRange
    seLinuxContext:
    type: MustRunAs
    supplementalGroups:
    type: RunAsAny
    users: []
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    allowPrivilegeEscalation: true
    allowPrivilegedContainer: false
    allowedCapabilities: null
    apiVersion: security.openshift.io/v1
    defaultAddCapabilities: null
    fsGroup:
    type: MustRunAs
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
```

## PodSecurityPolicy Requirements

* The Pods do not require any special permission and watch only their namespace.

## Configuration

*  No additional configuration is required for creating an instance of this operator.

## Storage

* The installation requires two mandatory persistent volumes and two optional. The storage for Mysql and MongoDb are only required when databases are embedded into the installation.
* The installation will create Persistent volume claims for the volumes, but it is possible to provide in the CRD Persistent Volume Claim already created. The storage class that is used must access the ReadWriteMany mode.
* By default when the Process Mining CRD is removed the PVC are removed and the data is loss.
* The data inside the persistent volumes must be backed up.

 | Used by | Default name | Dynamically created  | Default size (Gb) | Default class | Mandatory | Access Modes |
 | ------- |------- |------- | ------- |------- |------- | --- |
 | Process Mining  | processmining-repository  | Yes  | 20 | n/a | yes | ReadWriteMany |  
 | Mongo DB  | processmining-mongo | Yes  | 20 |  n/a | no | ReadWriteMany | 
 | Task Mining  | taskmining-data  | Yes  | 50 | n/a | yes (when task mining is installed)| ReadWriteMany | 
 | IBM DB2  | N/A | Yes  | 20 | n/a | no | ReadWriteMany | 
 
 Details on storage can be found in [here](https://ibm.biz/pm-storage) .

## Limitations

* It is possible to deploy more than one instance in different namespaces
* Hardware resource should be adapted in order to support  the number of events (for ProcessMining) and the number of Agent (Taskmining) planned.
* MongoDb and MySQL Pods do not support replica and they must be used for non production environment
* The application must be deployed on OCP 4.11 and further releases.
* Only supported on Linux x86_64 platform
* Not available on Power or Z architectures

## Scaling

* Manual scaling is supported by changing the number of replica of each Pod into the CRD. 
* Auto-scaling is not supported.
* It is possible to install more that one instance in same cluster into different namespace. Each instance must be used for a specific purpose (i.e. test env, prod env). This means that they must have a dedicated storage and database.

Details on scaling can be found in [here](https://ibm.biz/pm-scaling) .


## User and access management

* The authentication and access management is provided by the Cloud Pak Platform UI.
* The Process Mining components adds two permissions to the Cloud Pak role management: "Automation Analyst" and "Automation Administrator".
A user with the role "Automation Admnistrator" is profiled as Administrator inside Process Mining and can manage the fine grain permissions inside IBM Process Mining UI.

## Certificate management

* For non-production environment self-signed certificates are automatically generated by the operator. It is also possible to obtain the root CA and import on end-user PC in order to have secure communications.
* In a production environment it is possible, inside the CRD, to specify a secret that contain valid TLS certificates.
* The Operator does not use the IBM certificate management service provided as part of the common services.

## Documentation

For additional details regarding install parameters check: https://ibm.biz/ibm-process-mining
