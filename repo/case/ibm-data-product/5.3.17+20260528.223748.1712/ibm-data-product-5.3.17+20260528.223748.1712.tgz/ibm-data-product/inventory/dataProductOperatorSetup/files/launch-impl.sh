# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this Data Product operator

# Data Product operator specific variables
caseName="ibm-data-product"
inventory="dataProductOperatorSetup"
caseCatalogName="ibm-cpd-data-product-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="v8.17"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
#dependency
#removed 'ibm-analyticsengine' as part of non-olm update, since we don't need to install this anymore
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-data-product-operator-bundle}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:83da52b2e7e7ba6805938edff34780fc55aa4d2ab5aecc8a0ad5d62b1b5bdb95}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
CATALOG_IMAGE="${CATALOG_IMAGE:-ibm-cpd-data-product-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:899d5ea740ecad096b77b72148a4ef71148a6b6203eb5a18f4065fa0dba0d490}"
entitledRegistry="icr.io/cpopen"
storageclass=""
storagevendor=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageclass)
        storageclass=$val
        ;;
    --storagevendor)
        storagevendor=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-analyticsengine)
        echo "analyticsengineOperatorSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    CATALOG_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${CATALOG_IMAGE}@${CATALOG_DIGEST}

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        #tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
        sed <"${catsrc_file}" "s|image: .*|image: ${CATALOG_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -f -
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        #local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
        local catsrc_image_mod="${registry}/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/[^/]*\///")"
        if [[ ${registry} == "cp.stg.icr.io" ]]; then
            local catsrc_image_mod="${registry}/cp/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/.*\///")"
        fi
        # apply catalog source
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group


    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"
    local service_account_file="${casePath}/inventory/${inventory}/files/op-cli/data-product_operator_serviceaccount.yaml"
    validate_file_exists "${service_account_file}"

    # check if catalog source is installed
    echo "Checking if catalog source exists ..."
    catsrc_exist=$(oc get catsrc "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true)
    if [[ -z $catsrc_exist ]]; then
        echo "Creating catalog source '${caseCatalogName}' in namespace '${catalogNamespace}'"
        install_catalog
        echo "Wait for catalog installation to complete"
        sleep 30
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    #sed "${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    $kubernetesCLI apply -f "${subscription_file}" -n ${namespace}
    echo "Wait for subscription to complete"
    sleep 60

    $kubernetesCLI apply -f "${service_account_file}" -n ${namespace}

    echo "done"
}

# Install utilizing default CLI method
install_operator_native() {
    echo "Inside  launch-impl.sh install_operator_native()"
    echo "casePath: ${casePath}"
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="data-product"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/dataProductOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    data-product_crd="${setup_definition_files}/op-cli/data-product.cpd.ibm.com_data-product.yaml"
    validate_file_exists ${data-product_crd}
    operator_files="${setup_definition_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_serviceaccount.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_cluster_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required
    # create CDR
    $kubernetesCLI apply ${dryRun} -f ${data-product_crd}
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_cluster_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_serviceaccount.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_role_binding.yaml

    # Append OPERATOR_PREFIX to all resources under rbac
    sed <"${setup_definition_files}/op-cli/data-product_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    #local cr="${casePath}"/inventory/"${inventory}"/files/sample_v1beta1_panamax.yaml
    local dataproduct_cr="${casePath}"/inventory/"${inventory}"/files/op-cli/dataproduct_v1beta1_dataproduct.yaml

    echo "storagevendor: ${storagevendor}, storageclass: ${storageclass}"
    if [[ -z ${storageclass} && -z ${storagevendor} ]]; then
        err_exit "storageclass and storagevendor MUST not both empty"
    fi
    if [[ -z ${storageclass} ]]; then
        storageclass="\"\""
    fi

    validate_file_exists "$dataproduct_cr"
    echo "Deploying Data Product custom resource"
    if [[ -z $storagevendor ]]; then
          sed "${dataproduct_cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s/license: Standard/license: ${license_type}/g" -e "s|^\([ \t]*storageClass:\).*|\1 ${storageclass}|g" -e "s|^\([ \t]*fileStorageClass:\).*|\1 ${storageclass}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
          if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" && ${storagevendor} != "nfs" && ${storagevendor} != "\"\"" ]]; then
              err_exit "storagevendor value must be empty, \"nfs\", \"ocs\", or \"portworx\""
          fi
          sed "${dataproduct_cr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "s/license: Standard/license: ${license_type}/g" -e "s|^\([ \t]*storageClass:\).*|\1 ${storageclass}|g" -e "s|^\([ \t]*fileStorageClass:\).*|\1 ${storageclass}|g" -e "/^\([ \t]*.*[Ss]torageClass:\).*/a \ \ storageVendor: ${storagevendor}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Get subscription name
    caseSubName=$($kubernetesCLI get sub -n "${namespace}" | grep data-product-operator | cut -d' ' -f1|head -1)
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseSubName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseSubName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/config/crd/bases/*_crd.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done
    $kubernetesCLI delete crd dataproduct.data-product.cpd.ibm.com --ignore-not-found=true ${dryRun}
    # delete installplan
    installplanName=$($kubernetesCLI get installplan -n ${namespace} --no-headers|grep $csvName|cut -d' ' -f1|head -1)
    [[ -n "${installplanName}" ]] && { $kubernetesCLI delete installplan "${installplanName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    OPERATOR_PREFIX="data-product"

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    setup_definition_files="${casePath}/inventory/dataProductOperatorSetup/files"
    echo "setup_definition_files: ${setup_definition_files}"

    data-product_crd="${setup_definition_files}/op-cli/data-product.cpd.ibm.com_data-product.yaml"
    validate_file_exists ${data-product_crd}
    operator_files="${setup_definition_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_serviceaccount.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_role_binding.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_cluster_role.yaml"
    validate_file_exists "${setup_definition_files}/op-cli/data-product_operator_cluster_role_binding.yaml"

    echo "Inside  launch-impl.sh complete file exist checks"
    # Apply yaml files manipulate variable input as required

    $kubernetesCLI delete ${dryRun} -n "${namespace}" deploy ibm-cpd-data-product-operator
    sed <"${setup_definition_files}/op-cli/data-product_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_role_binding.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_serviceaccount.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_cluster_role.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${setup_definition_files}/op-cli/data-product_operator_role.yaml
    # delete CRD
    $kubernetesCLI delete ${dryRun} -f ${data-product_crd}

}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    #local cr="${casePath}"/inventory/"${inventory}"/files/sample_v1beta1_panamax.yaml
    local dataproduct_cr="${casePath}"/inventory/"${inventory}"/files/config/samples/dataproduct_v1beta1_dataproduct.yaml
    
    echo "Undeploying Data Product custom resource"
      [[ ! -f ${dataproduct_cr} ]] && { err_exit "Missing required ${dataproduct_cr}, exiting deployment."; }
      $kubernetesCLI delete -n "${namespace}" -f "${dataproduct_cr}" ${dryRun}
      $kubernetesCLI delete -n "${namespace}" -f "${dataproduct_cr}" ${dryRun}
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
