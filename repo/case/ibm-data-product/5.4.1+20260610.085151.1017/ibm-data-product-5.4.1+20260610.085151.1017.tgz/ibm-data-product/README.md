# Name

IBM&reg; Data Product

# Introduction

## Summary

Data Product Hub is ideal for data-driven organizations that need fast, reliable, and secure access to data.

## Features

* **Easy access for data consumers** Data Product Hub provides self-service access to data consumers so that they can easily find, understand, and use business-ready data products.
* **Control for data producers** Data Product Hub gives data producers control over the data product lifecycle, making it easy to create, share, and manage their data products, which are comprised of data sets, reports, notebooks, machine learning models, and other data derivatives that support specific use cases.
* **Peace of mind for CDOs** Data Product Hub offers comprehensive governance, making it simple for chief data officers to prevent compliance and security issues."


# Details

## Prerequisites
IBM Cloud Pak for Data Data Product requires the following
- CPD 5.0.x installed

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Cloud Pak for Data | 64 | 16 | 100 | 3 |
| **Total** | **64** | **16**  | **100**  | **3** |

# Installing

## Install IBM Data Product Bundle using CPD-CLI

Follow the steps below to install Data Product Hub using `cpd-cli` commands

### Prerequisites: 
1. Create a folder. For example `cpd50X` X should be the release version,for 5.0.1 release - cpd501 and `cd` into it
2. Update the global pull secrets
**Back up your current global pull secret (IMPORTANT)**
```
oc get secret pull-secret -n openshift-config -o yaml > global-pull-secret.yaml
```
Create/Update the global pull secret
```
REGISTRY_USER=<your user name for image registry>
REGISTRY_APIKEY=<your api key for image registry>
# for Linux
pull_secret=$(echo -n "$REGISTRY_USER:$REGISTRY_APIKEY" | base64 -w0)
# for Mac
pull_secret=$(echo -n "$REGISTRY_USER:$REGISTRY_APIKEY" | base64)
```
Replace the registry url with actual value, e.g. <Entitled registry URL>/cp
```
oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|:{|:{"<registry url>":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json
```

3. Create `mirror.sh` 
Add the mirrorings below to facilitate image pulling from the accessible registry and do execute `sh ./mirror.sh`
```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: dataproduct-mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - <Entitled registry URL>/cp
    source: icr.io/cpopen
  - mirrors:
    - <Entitled registry URL>
    source: cp.icr.io
EOF
```

4. Download the latest `olm-utils` by executing `wget <HTTP PATH>`. The latest packages can be found here - https://github.com/IBM/cpd-cli/releases/ 
5. Extract and `cd` into the extracted folder (tar -xzvf )
6. Export the commonly used variables 
```
export OLM_UTILS_IMAGE=<Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
export CPD_CLI_MANAGE_WORKSPACE=
export release=5.4.0
export cpd_operator_ns=wkc-operators
export cpd_instance_ns=wkc
```
7. Login to OCP cluster 
```
./cpd-cli manage login-to-ocp --server=HOSTNAME -u USER -p PASSWORD
```
This will create a **olm-play-v3** container if not available already

8. Apply cluster components for the targeted release 
```
./cpd-cli manage apply-cluster-components --license_acceptance=true --release=$release
```

### Install DPH 
1. Download the case bundle 
```
./cpd-cli manage apply-olm --release=$release --components=cpd_platform,wkc,dataproduct --cpd_operator_ns=$cpd_operator_ns --catsrc=false --sub=false -vvv
```
This will download the case bundles of `cpd_platform, wkc and dataproduct`. You can verify the downloaded bundle here `/usr/local/CX/work/offline/5.4.0/.ibm-pak/data/cases/`
2. Install Operator pod
```
./cpd-cli manage apply-olm --release=$release --components=cpd_platform,wkc,dataproduct --case_download=false --cpd_operator_ns=$cpd_operator_ns -vvv
```
This will install the **ibm-cpd-data-product-operator** pod along with other dependent operator pods in _-n wkc-operators_ namespace
3. Verify the operator pod is up and running before proceeding to the next steps.
```
oc get pods -n wkc-operators | grep data-product
```
4. Run the Preview mode and check your configs for data-product is present in `cat /usr/local/CX/work/preview.sh`
```
./cpd-cli manage apply-cr --release=$release --components=cpd_platform,dataproduct --license_acceptance=true --cpd_operator_ns=$cpd_operator_ns --cpd_instance_ns=$cpd_instance_ns --file_storage_class=managed-nfs-storage --block_storage_class=managed-nfs-storage --preview=true -vvv
```
The above command will create a preview.sh file with the install configs.
5. Install DPH operand pods in `managed-nfs-storage` storage
```
./cpd-cli manage apply-cr --release=$release --components=cpd_platform,dataproduct --license_acceptance=true --cpd_operator_ns=$cpd_operator_ns --cpd_instance_ns=$cpd_instance_ns --file_storage_class=managed-nfs-storage --block_storage_class=managed-nfs-storage -vvv
``` 
Once done, monitor the operator pod logs. It will take several minutes to install the 'dataproduct-ui' and 'dataproduct-api' operand pods in namespace wkc. 
You can also use **ocs-storagecluster-cephfs** or **portworx** instead of **managed-nfs-storage** based on your cluster storage class. 
6. Once you see the operand pods are installed and running, execute the command to check the cr status
```
oc get dataproduct
```

### Uninstall DPH
These set of commands will uninstall the operand pods, operator pod and dataproduct-cr. If the operator has installed any other dependent pods or cr's, that too will be uninstalled. 
```
./cpd-cli manage delete-cr --components=dataproduct --cpd_instance_ns=wkc

./cpd-cli manage delete-olm-artifacts --components=dataproduct --preview=true --cpd_instance_ns=wkc --cpd_operator_ns=wkc-operators

./cpd-cli manage delete-olm-artifacts --components=dataproduct -vvv --cpd_operator_ns=wkc-operators
```

## AIRGAP: Install Data Product Operator using cpd-cli 

### Configure the cluster
```
#SSH to the cluster node 
ssh <Cluster url> -l root
 
mkdir AirgapFreshinstalldph
cd AirgapFreshinstalldph/

# Install cpd-cli
wget <Internal file server URL>5.0.0/dev/cpd-cli/latest/cpd-cli-linux-EE-14.0.0.tgz
tar -xvf cpd-cli-linux-EE-14.0.0.tgz
cd cpd-cli-linux-EE-14.0.0-269/
export OLM_UTILS_IMAGE=<Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x

# Log in to a remote registry. RegistryURL is <Entitled registry URL>
podman login <Entitled registry URL> -u iamapikey -p <PASSWORD>

# List all images in this registry
REPOSITORY                                              TAG         IMAGE ID      CREATED       SIZE
<Entitled registry URL>/cp/cpd/olm-utils-v3                       5.0.x       c09eb9bd0ec9  10 days ago   869 MB
<Entitled registry URL>/cp/ibm-cpd-data-product-operator          v5.0.439    42227e78547d  11 days ago   303 MB
registry.access.redhat.com/ubi9/ubi                     latest      1cce461347f6  4 weeks ago   220 MB
<Entitled registry URL>/cp/ibm-cpd-data-product-operator-catalog  v5.0.142    ff9970a5ca00  7 weeks ago   207 MB
<Entitled registry URL>/cp/ibm-cpd-data-product-operator-bundle   v5.0.229    1c573fcd94e1  8 weeks ago   55.6 kB
<Entitled registry URL>/cp/ibm-cpd-data-product-operator          v5.0.229    94d5bb2ad6bf  8 weeks ago   414 MB
<Entitled registry URL>/cp/cpd/data-product-api                   1.0.628     ba6474f8accf  2 months ago  826 MB
<Entitled registry URL>/cp/cpd/data-product-ui                    1.0.843     0f973b1f644b  2 months ago  1.65 GB

# Login to the cluster
./cpd-cli manage login-to-ocp --server=<SERVER> -u kubeadmin -p <PASSWORD>
```

**vi airgap-mirror.sh**

```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: cloud-pak-for-data-mirror
spec:
  repositoryDigestMirrors:
  - mirrors:
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/cp
    source: cp.icr.io/cp
  - mirrors:
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/cp/cpd
    - <Entitled registry URL>/cp/cpd
    - docker-<Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote/cp
    source: cp.icr.io/cp/cpd
  - mirrors:
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/ibmcom
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/cp
    source: icr.io/cpopen
  - mirrors:
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/ibmcom
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/cp
    source: icr.io/db2u
  - mirrors:
    - <Internal Artifactory URL>/hyc-ug-staging-docker-local/ibmcom
    - <Entitled registry URL>/cp/cpd
    - docker-<Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote/cp
    source: icr.io/cpopen/cpfs
EOF

```

**vi mirror.sh**

```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: staging-mirror
spec:
  repositoryDigestMirrors:
  - source: quay.io/opencloudio
    mirrors:
    - <Entitled registry URL>/cp
    - <Internal Artifactory URL>
    - <Internal Artifactory URL>/ibmcom
    - docker-na-public.artifactory.swg-devops.com/hyc-cloud-private-daily-docker-local/ibmcom
  - source: icr.io/cpopen
    mirrors:
    - <Entitled registry URL>/cp
    - <Internal Artifactory URL>
    - <Internal Artifactory URL>/ibmcom
    - docker-na-public.artifactory.swg-devops.com/hyc-cloud-private-daily-docker-local/ibmcom
    - <Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote/cp
  - source: icr.io/cpopen/cpfs
    mirrors:
    - docker-na-public.artifactory.swg-devops.com/hyc-cloud-private-daily-docker-local/ibmcom
  - source: icr.io/db2u
    mirrors:
    - <Entitled registry URL>/cp
    - <Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote/cp
  - source: cp.icr.io
    mirrors:
    - <Entitled registry URL>
    - <Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote
  - source: cp.icr.io/cp
    mirrors:
    - <Entitled registry URL>/cp
    - <Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote
  - mirrors:
    - <Entitled registry URL>/cp
    - <Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote/cp
    source: repo.getmanta.com/manta-ubi8-ibm
  - mirrors:
    - docker-na-public.artifactory.swg-devops.com/hyc-cloud-private-daily-docker-local/ibmcom
    source: <Internal Artifactory URL>/ibmcom
EOF

```

**vi ModifiedAirgapDocker.Config.JSON**

```
{
  "auths": {
    "quay.io": {
      "auth": "TOKEN",
      "email": "fyre@us.ibm.com"
    },
    "registry.connect.redhat.com": {
      "auth": "TOKEN",
      "email": "fyre@us.ibm.com"
    },
    "registry.redhat.io": {
      "auth": "TOKEN",
      "email": "fyre@us.ibm.com"
    },
    "cp.icr.io": {
      "auth": "TOKEN",
      "email": "cp"
    },
    "docker-na-public.artifactory.swg-devops.com": {
      "auth": "TOKEN"
    },
    "<Internal Artifactory URL>/hyc-ug-staging-docker-local": {
      "auth": "TOKEN"
    },
    "<Internal Artifactory URL>/hyc-cloudpak-team-cp-cpstgicr-docker-remote": {
      "auth": "TOKEN",
      "email": "C-K2C8897@nomail.relay.ibm.com"
    },
    "<Entitled registry URL>": {
      "auth": "TOKEN",
      "email": "iamapikey"
    }
  }
}

```

**vi override.yaml**
```
override_components_meta:
  wkc:
    case_repo_path: "{{ lookup('env', 'WKC_CASE_REPO_PATH') if lookup('env', 'WKC_CASE_REPO_PATH') | length > 0 else default_case_repo_path }}"
  dataproduct:
    case_repo_path: "{{ lookup('env', 'DPH_CASE_REPO_PATH') if lookup('env', 'DPH_CASE_REPO_PATH') | length > 0 else default_case_repo_path }}"

```
**vi play_env.sh**

```
export CASECTL_RESOLVERS_LOCATION=/tmp/work/resolvers.yaml
export CASECTL_RESOLVERS_AUTH_LOCATION=/tmp/work/resolvers_auth.yaml
export CASE_TOLERATION='--skip-verify'
export GITHUB_TOKEN=TOKEN

export CASE_REPO_PATH="https://<internal_repo_url>/case-repo-dev"
export CPFS_CASE_REPO_PATH="https://<internal_repo_url>/repo/case"
export OPENCONTENT_CASE_REPO_PATH="https://<internal_repo_url>/repo/case"
export WKC_CASE_REPO_PATH="https://<internal_repo_url>/case-repo-local"
```


**vi resolvers_auth.yaml**

```
resolversAuth:
  metadata:
    description:  This is the INTERNAL authorization file for downloading CASE packages from an internal repo
  resources:
    cases:
      repositories:
        DevGitHub:
          credentials:
            basic:
              username: bff@us.ibm.com
              password: PASSWORD
        LocalGitHub:
          credentials:
            basic:
              username: bff@us.ibm.com
              password: PASSWORD
        cloudPakCertRepo:
          credentials:
            basic:
              username: bff@us.ibm.com
              password: PASSWORD
    containerImages:
      registries:
        entitledStage:
          credentials:
            basic:
              username: iamapikey
              password: PASSWORD
```

**vi resolvers.yaml**

```
resolvers:
  metadata:
    description:  resolver file to map cases and registries. Used to get dependency cases
  resources:
    cases:
      repositories:
        LocalGitHub:
          repositoryInfo:
            url: "<Private case repository URL>/5.0.0/local/case-repo-local"
        DevGitHub:
          repositoryInfo:
            url: "<Private case repository URL>/5.0.0/dev/case-repo-dev"
        cloudPakCertRepo:
          repositoryInfo:
            url: "<Private case repository URL>/master/repo/case"
      caseRepositoryMap:
      - cases:
        - case: "ibm-wkc"
          version: "*"
        repositories:
        - LocalGitHub
      - cases:
        - case: "*"
          version: "*"
        repositories:
        - DevGitHub
      - cases:
        - case: "*"
          version: "*"
        repositories:
        - cloudPakCertRepo
```

```
chmod 777 play_env.sh
./play_env.sh
cd ../../../
./cpd-cli manage login-entitled-registry <TOKEN>

# Login to the remote registry
./cpd-cli manage login-private-registry <Entitled registry URL> iamapikey <KEY>
./cpd-cli manage login-private-registry <Entitled registry URL> iamapikey <KEY>

# Login to the local registry
./cpd-cli manage login-private-registry <Internal Artifactory URL>/hyc-cloud-private-daily-docker-local C-K2C8897@nomail.relay.ibm.com <KEY>
./cpd-cli manage login-private-registry <Internal Artifactory URL>/hyc-ug-staging-docker-local C-K2C8897@nomail.relay.ibm.com <KEY>

# ibm-licensing mirroring
./cpd-cli manage mirror-images --release=5.0.0 --components=ibm-licensing  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=true --retry_count=2 --retry_delay=5 -v

# ibm-cert-manager
./cpd-cli manage mirror-images --release=5.0.0 --components=ibm-cert-manager  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=true --retry_count=2 --retry_delay=5 -v
```

### Cpfs mirroring
```
 ./cpd-cli manage mirror-images --release=5.0.0 --components=cpfs  --extra-vars="skip_do_mirror=true" --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=true --retry_count=2 --retry_delay=5 -v

 ./cpd-cli manage mirror-images --release=5.0.0 --components=cpfs --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false --retry_count=2 --retry_delay=5 -v
```

#### list images

```
./cpd-cli manage list-images --release=5.0.0 --components=cpfs --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v

[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# ./cpd-cli manage list-images --release=5.0.0 --components=cpfs --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
[INFO] 2024-05-21T06:15:28.013216Z Checking architecture: amd64
[INFO] 2024-05-21T06:15:28.013271Z Checking podman or docker
[INFO] 2024-05-21T06:15:28.055517Z Dockerexe: podman
[INFO] 2024-05-21T06:15:28.055567Z Checking container image: OLM_UTILS_IMAGE = <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T06:15:28.055607Z User-specified workspace: /usr/local/CX
[INFO] 2024-05-21T06:15:28.106113Z Container olm-utils-play-v3 is running already. Image: <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T06:15:28.147778Z Processing subcommand list-images
[INFO] 2024-05-21T06:15:28.147839Z Run command: podman exec -it olm-utils-play-v3 list-images --release=5.0.0 --components=cpfs --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
========logging to : /tmp/work/offline/5.0.0/list_images.csv ==== 


========manifest info logged to : /tmp/work/offline/5.0.0/list_images.csv ==== 
[SUCCESS] 2024-05-21T06:18:18.127644Z You may find output and logs in the /usr/local/CX/work directory.
[SUCCESS] 2024-05-21T06:18:18.127804Z The list-images command ran successfully.

[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# cd /usr/local/CX/work/offline/5.0.0/
[root@<Cluster url> 5.0.0]# ls -ltr
total 64
-rw-r--r-- 1 1001 root 64016 May 21 06:18 list_images.csv


[root@<Cluster url> 5.0.0]# cp list_images.csv cpfslistimages
[root@<Cluster url> 5.0.0]# ls -ltr
total 128
-rw-r--r-- 1 1001 root 64016 May 21 06:18 list_images.csv
-rw-r--r-- 1 root root 64016 May 21 06:36 cpfslistimages
[root@<Cluster url> 5.0.0]# grep "level=fatal" list_images.csv
[root@<Cluster url> 5.0.0]# grep "level=fatal" cpfslistimages
[root@<Cluster url> 5.0.0]# vi list_images.csv

```

### cpd-platform mirroring

```

./cpd-cli manage mirror-images --release=5.0.0 --components=cpd_platform --extra-vars="skip_do_mirror=true" --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=true --retry_count=2 --retry_delay=5 -v

```

#### sed commands

```
cd /usr/local/CX/work/offline/5.0.0/.ibm-pak/data/cases/ibm-cp-datacore/5.0.0/

datacore-*-images
sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-cp-datacore-*-images.csv
zen-*-images
sed -i 's|icr.io,cpopen/cpfs|<Entitled registry URL>,cp|g' ./ibm-zen-*-images.csv
sed -i 's|icr.io,cpopen/edb|<Entitled registry URL>,cp/edb|g' ./ibm-zen-*-images.csv
sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-zen-*-images.csv
```

#### mirror cmd

```
./cpd-cli manage mirror-images --release=5.0.0 --components=cpd_platform  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false --retry_count=2 --retry_delay=5 -v

```

#### list images

```
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# ./cpd-cli manage list-images --release=5.0.0 --components=cpd_platform --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
[INFO] 2024-05-21T07:00:15.210336Z Checking architecture: amd64
[INFO] 2024-05-21T07:00:15.210379Z Checking podman or docker
[INFO] 2024-05-21T07:00:15.268470Z Dockerexe: podman
[INFO] 2024-05-21T07:00:15.268569Z Checking container image: OLM_UTILS_IMAGE = <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T07:00:15.268702Z User-specified workspace: /usr/local/CX
[INFO] 2024-05-21T07:00:15.321771Z Container olm-utils-play-v3 is running already. Image: <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T07:00:15.366504Z Processing subcommand list-images
[INFO] 2024-05-21T07:00:15.366584Z Run command: podman exec -it olm-utils-play-v3 list-images --release=5.0.0 --components=cpd_platform --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
========logging to : /tmp/work/offline/5.0.0/list_images.csv ==== 


========manifest info logged to : /tmp/work/offline/5.0.0/list_images.csv ==== 
[SUCCESS] 2024-05-21T07:00:49.743039Z You may find output and logs in the /usr/local/CX/work directory.
[SUCCESS] 2024-05-21T07:00:49.743132Z The list-images command ran successfully.

[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# grep "level=fatal" /usr/local/CX/work/offline/5.0.0/list_images.csv 
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# 

```

### wkc mirroring

```
./cpd-cli manage mirror-images --release=5.0.0 --components=wkc  --extra-vars="skip_do_mirror=true" --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=true --retry_count=2 --retry_delay=5 --param-file=/tmp/work/override.yaml -v


[root@<Cluster url> cases]# ls -ltr ./ibm-*/*/ibm-*.tgz
-rw-r--r-- 1 1001 root  211712 May 21 06:00 ./ibm-cert-manager/4.2.4/ibm-cert-manager-4.2.4.tgz
-rw-r--r-- 1 1001 root  224971 May 21 06:04 ./ibm-licensing/4.2.4/ibm-licensing-4.2.4.tgz
-rw-r--r-- 1 1001 root  135932 May 21 06:09 ./ibm-cp-common-services/4.7.99/ibm-events-operator-5.0.1.tgz
-rw-r--r-- 1 1001 root  238165 May 21 06:09 ./ibm-cp-common-services/4.7.99/ibm-cs-install-4.7.20240516.tgz
-rw-r--r-- 1 1001 root   50160 May 21 06:09 ./ibm-cp-common-services/4.7.99/ibm-cs-iam-4.6.20240516.tgz
-rw-r--r-- 1 1001 root  256494 May 21 06:09 ./ibm-cp-common-services/4.7.99/ibm-cp-common-services-4.7.99.tgz
-rw-r--r-- 1 1001 root 3742333 May 21 06:43 ./ibm-cp-datacore/5.0.0/ibm-cp-datacore-5.0.0+20240517.182455.199.600-35.tgz
-rw-r--r-- 1 1001 root   53076 May 21 06:43 ./ibm-zen/6.0.0/ibm-cloud-native-postgresql-4.25.1.tgz
-rw-r--r-- 1 1001 root   70254 May 21 06:43 ./ibm-zen/6.0.0/ibm-zen-6.0.0+20240517.185420.324.tgz
-rw-r--r-- 1 1001 root   57354 May 21 07:18 ./ibm-elasticsearch-operator/1.1.2131/ibm-elasticsearch-operator-1.1.2131.tgz
-rw-r--r-- 1 1001 root  136916 May 21 07:18 ./ibm-ccs/9.0.0/ibm-ccs-9.0.0+20240520.200557.451.tgz
-rw-r--r-- 1 1001 root  257061 May 21 07:18 ./ibm-db2uoperator/6.0.0/ibm-db2uoperator-6.0.0+20240515.200303.9490.tgz
-rw-r--r-- 1 1001 root  126907 May 21 07:18 ./ibm-datarefinery/9.0.0/ibm-datarefinery-9.0.0+20240517.202103.146.tgz
-rw-r--r-- 1 1001 root  118762 May 21 07:18 ./ibm-analyticsengine/9.0.0/ibm-analyticsengine-9.0.0+20240515.051008.962.tgz
-rw-r--r-- 1 1001 root  173559 May 21 07:18 ./ibm-db2aaservice/5.0.0/ibm-db2aaservice-5.0.0+20240517.110903.2491.3349.tgz
-rw-r--r-- 1 1001 root  291690 May 21 07:18 ./ibm-fdb/5.0.0/ibm-fdb-5.0.0+20240517.151826.2.tgz
-rw-r--r-- 1 1001 root  101201 May 21 07:18 ./ibm-datastage-enterprise/8.0.0/ibm-datastage-enterprise-8.0.0+20240520.201454.2489.tgz
-rw-r--r-- 1 1001 root  142911 May 21 07:19 ./ibm-wkc/5.0.0/ibm-wkc-5.0.0+20240521.114224.444.tgz

```

#### sed cmds

```
  sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-ccs/9.0.0/ibm-ccs-*-images.csv
     sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-ccs/9.0.0/ibm-ccs-*-images.csv
     sed -i 's|icr.io,db2u|<Entitled registry URL>,cp|g' ./ibm-db2uoperator/6.0.0/ibm-db2uoperator-*-images.csv
     sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-db2uoperator/6.0.0/ibm-db2uoperator-*-images.csv
     sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-db2aaservice/5.0.0/ibm-db2aaservice-*-images.csv
     sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-db2aaservice/5.0.0/ibm-db2aaservice-*-images.csv
     sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-analyticsengine/9.0.0/ibm-analyticsengine-*-images.csv
     sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-analyticsengine/9.0.0/ibm-analyticsengine-*-images.csv
    sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-fdb/5.0.0/ibm-fdb-*-images.csv
    sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-fdb/5.0.0/ibm-fdb-*-images.csv
   sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-datastage-enterprise/8.0.0/ibm-datastage-enterprise-*-images.csv
     sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-datastage-enterprise/8.0.0/ibm-datastage-enterprise-*-images.csv
     sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-wkc/5.0.0/ibm-wkc-*-images.csv
     sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-wkc/5.0.0/ibm-wkc-*-images.csv
     sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-datarefinery/9.0.0/ibm-datarefinery-*-images.csv
     sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-datarefinery/9.0.0/ibm-datarefinery-*-images.csv

```
#### mirror cmd

```
./cpd-cli manage mirror-images --release=5.0.0 --components=wkc  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false --retry_count=3 --retry_delay=5 -v

```

#### list images

```
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# ./cpd-cli manage list-images --release=5.0.0 --components=wkc  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
[INFO] 2024-05-21T07:38:34.309200Z Checking architecture: amd64
[INFO] 2024-05-21T07:38:34.309249Z Checking podman or docker
[INFO] 2024-05-21T07:38:34.356664Z Dockerexe: podman
[INFO] 2024-05-21T07:38:34.356841Z Checking container image: OLM_UTILS_IMAGE = <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T07:38:34.356906Z User-specified workspace: /usr/local/CX
[INFO] 2024-05-21T07:38:34.407368Z Container olm-utils-play-v3 is running already. Image: <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T07:38:34.455974Z Processing subcommand list-images
[INFO] 2024-05-21T07:38:34.456046Z Run command: podman exec -it olm-utils-play-v3 list-images --release=5.0.0 --components=wkc --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
========logging to : /tmp/work/offline/5.0.0/list_images.csv ==== 


========manifest info logged to : /tmp/work/offline/5.0.0/list_images.csv ==== 
[SUCCESS] 2024-05-21T07:42:49.814075Z You may find output and logs in the /usr/local/CX/work directory.
[SUCCESS] 2024-05-21T07:42:49.814292Z The list-images command ran successfully.

[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# grep "level=fatal" /usr/local/CX/work/offline/5.0.0/list_images.csv 
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# 

```

### dataproduct mirroring

```
./cpd-cli manage mirror-images --release=5.0.0 --components=dataproduct  --extra-vars="skip_do_mirror=true" --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=true --retry_count=2 --retry_delay=5 --param-file=/tmp/work/override.yaml -v

```

#### sed commands

```
sed -i 's|cp.icr.io|<Entitled registry URL>|g' ./ibm-data-product/5.0.0/ibm-data-product-*-images.csv
sed -i 's|icr.io,cpopen|<Entitled registry URL>,cp|g' ./ibm-data-product/5.0.0/ibm-data-product-*-images.csv

```
#### mirror cmd

```
./cpd-cli manage mirror-images --release=5.0.0 --components=dataproduct  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false --retry_count=3 --retry_delay=5 -v

```

#### list images

```
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# ./cpd-cli manage list-images --release=5.0.0 --components=dataproduct  --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
[INFO] 2024-05-21T08:06:36.345893Z Checking architecture: amd64
[INFO] 2024-05-21T08:06:36.345959Z Checking podman or docker
[INFO] 2024-05-21T08:06:36.402242Z Dockerexe: podman
[INFO] 2024-05-21T08:06:36.402296Z Checking container image: OLM_UTILS_IMAGE = <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T08:06:36.402334Z User-specified workspace: /usr/local/CX
[INFO] 2024-05-21T08:06:36.448481Z Container olm-utils-play-v3 is running already. Image: <Entitled registry URL>/cp/cpd/olm-utils-v3:5.0.x
[INFO] 2024-05-21T08:06:36.496406Z Processing subcommand list-images
[INFO] 2024-05-21T08:06:36.496510Z Run command: podman exec -it olm-utils-play-v3 list-images --release=5.0.0 --components=dataproduct --target_registry=<Internal Artifactory URL>/hyc-ug-staging-docker-local --case_download=false -v
========logging to : /tmp/work/offline/5.0.0/list_images.csv ==== 


========manifest info logged to : /tmp/work/offline/5.0.0/list_images.csv ==== 
[SUCCESS] 2024-05-21T08:10:36.027427Z You may find output and logs in the /usr/local/CX/work directory.
[SUCCESS] 2024-05-21T08:10:36.027574Z The list-images command ran successfully.

[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# grep "level=fatal" /usr/local/CX/work/offline/5.0.0/list_images.csv 
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]#

```

### Configure airgap-mirroring and Docker config to install

```
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=./ModifiedAirgapDocker.Config.JSON
I0521 21:10:33.370344  727436 request.go:621] Throttling request took 1.124400157s, request: GET:https://<Cluster url>:6443/apis/whereabouts.cni.cncf.io/v1alpha1?timeout=32s
secret/pull-secret data updated
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# chmod 777 airgap-mirror.sh
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# ./airgap-mirror.sh
imagecontentsourcepolicy.operator.openshift.io/cloud-pak-for-data-mirror created
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get mcp
NAME     CONFIG                                             UPDATED   UPDATING   DEGRADED   MACHINECOUNT   READYMACHINECOUNT   UPDATEDMACHINECOUNT   DEGRADEDMACHINECOUNT   AGE
master   rendered-master-50de3b57c2dbd28fd263734e021870ce   False     True       False      3              0                   0                     0                      104d
worker   rendered-worker-4b4aa9415a1047bd7608d65627319644   False     True       False      7              0                   0                     0                      104d
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get mcp
NAME     CONFIG                                             UPDATED   UPDATING   DEGRADED   MACHINECOUNT   READYMACHINECOUNT   UPDATEDMACHINECOUNT   DEGRADEDMACHINECOUNT   AGE
master   rendered-master-13c8d9333b10f3a3d751c3d00eaafd20   True      False      False      3              3                   3                     0                      104d
worker   rendered-worker-567bc3b30b670e83b6e04bf953f5c487   True      False      False      7              7                   7                     0                      104d
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# 


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get imagecontentsourcepolicy
NAME                        AGE
cloud-pak-for-data-mirror   6m53s


```


### Installation

```
./cpd-cli manage apply-cluster-components --release=5.0.0 --license_acceptance=true


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get po -n ibm-cert-manager
I0521 21:29:35.139518  729491 request.go:621] Throttling request took 1.134983032s, request: GET:https://<Cluster url>:6443/apis/db2u.databases.ibm.com/v1?timeout=32s
NAME                                                              READY   STATUS      RESTARTS   AGE
4fb72fb19f187e74f231228d92bd2793deba1e5b8a4beb1343239327abpn6tj   0/1     Completed   0          3m39s
cert-manager-cainjector-6fdc8d6949-4l9j8                          1/1     Running     0          3m18s
cert-manager-controller-bb584fcbd-7vns9                           1/1     Running     0          3m19s
cert-manager-webhook-6488d69c8b-9gv54                             1/1     Running     0          3m18s
ibm-cert-manager-catalog-m5vsr                                    1/1     Running     0          6m25s
ibm-cert-manager-operator-76c5975765-ln6mc                        1/1     Running     0          3m25s
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get po -n ibm-licensing 
NAME                                                              READY   STATUS      RESTARTS   AGE
f3268163dfece62acfe24169b11923c516ac44c33b0c55f15623a1cc60rprl9   0/1     Completed   0          3m9s
ibm-licensing-catalog-5fgjj                                       1/1     Running     0          5m15s
ibm-licensing-operator-8dfc7ff6-c2dv5                             1/1     Running     0          2m54s



./cpd-cli manage authorize-instance-topology --cpd_operator_ns=cpd-operator --cpd_instance_ns=cpd-instance

./cpd-cli manage authorize-instance-topology --cpd_operator_ns=cpd-operator --cpd_instance_ns=cpd-instance

./cpd-cli manage setup-instance-topology --release=5.0.0 --cpd_operator_ns=cpd-operator --cpd_instance_ns=cpd-instance --license_acceptance=true --block_storage_class=managed-nfs-storage

[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get po -n cpd-operator
I0521 22:17:08.286754  731696 request.go:621] Throttling request took 1.118397848s, request: GET:https://<Cluster url>:6443/apis/runtimes.ibm.com/v1alpha1?timeout=32s
NAME                                                              READY   STATUS      RESTARTS   AGE
2504c0fcf559ebe4c063c46caf0695efb3977f7110e02efe54d16dfcf86jpzk   0/1     Completed   0          9m47s
2712dc9492bb47e41305393f2666bf8e88b3af6fd1b7fda3e61a470f95sngm8   0/1     Completed   0          7m44s
db3a6ea56bd59e4e6e1ecf580973a43145074971cdcb68a8319299fda06sf8g   0/1     Completed   0          9m13s
ibm-common-service-operator-569d8d66d5-4ltlm                      1/1     Running     0          8m28s
ibm-cs-iam-catalog-4bdmr                                          1/1     Running     0          11m
ibm-cs-install-catalog-dwh4q                                      1/1     Running     0          11m
ibm-events-operator-catalog-ct2nn                                 1/1     Running     0          11m
ibm-namespace-scope-operator-76fcbfbfd7-ksgfp                     1/1     Running     0          9m36s
opencloud-operators-npb7x                                         1/1     Running     0          11m
operand-deployment-lifecycle-manager-66f695c4b-vmq2b              1/1     Running     0          5m29s



./cpd-cli manage apply-olm --release=5.0.0 --components=cpd_platform,wkc,dataproduct --case_download=false --cpd_operator_ns=cpd-operator -vv


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get catsrc -n cpd-operator
I0521 22:34:09.735966  735946 request.go:621] Throttling request took 1.112931583s, request: GET:https://<Cluster url>:6443/apis/console.openshift.io/v1alpha1?timeout=32s
NAME                                     DISPLAY                                                           TYPE   PUBLISHER   AGE
cloud-native-postgresql-catalog          ibm-cloud-native-postgresql-4.25.1                                grpc   IBM         13m
cpd-platform                             ibm-cp-datacore-5.0.0+20240517.182455.199.600-35                  grpc   IBM         13m
ibm-cpd-ae-operator-catalog              ibm-analyticsengine-9.0.0+20240515.051008.962                     grpc   IBM         13m
ibm-cpd-ccs-operator-catalog             ibm-ccs-9.0.0+20240520.200557.451                                 grpc   IBM         13m
ibm-cpd-data-product-operator-catalog    CPD Data Product Exchange                                         grpc   IBM         13m
ibm-cpd-datarefinery-operator-catalog    ibm-datarefinery-9.0.0+20240517.202103.146                        grpc   IBM         13m
ibm-cpd-datastage-operator-catalog       ibm-datastage-enterprise-8.0.0+20240520.201454.2489-linux-amd64   grpc   IBM         13m
ibm-cpd-wkc-operator-catalog             ibm-wkc-5.0.0+20240521.114224.444-linux-amd64                     grpc   IBM         13m
ibm-cs-iam-catalog                       ibm-cs-iam-4.6.20240516                                           grpc   IBM         28m
ibm-cs-install-catalog                   ibm-cs-install-4.7.20240516                                       grpc   IBM         28m
ibm-db2aaservice-cp4d-operator-catalog   ibm-db2aaservice-5.0.0+20240517.110903.2491.3349                  grpc   IBM         13m
ibm-db2uoperator-catalog                 IBM Db2U Catalog                                                  grpc   IBM         13m
ibm-elasticsearch-catalog                ibm-elasticsearch-operator-1.1.2131                               grpc   IBM         13m
ibm-events-operator-catalog              ibm-events-operator-5.0.1                                         grpc   IBM         28m
ibm-fdb-operator-catalog                 ibm-fdb-5.0.0+20240517.151826.2-linux-amd64                       grpc   IBM         13m
ibm-zen-operator-catalog                 ibm-zen-6.0.0+20240517.185420.324                                 grpc   IBM         13m
opencloud-operators                      ibm-cp-common-services-4.7.99                                     grpc   IBM         28m


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get csv -n cpd-operator
NAME                                          DISPLAY                                                                VERSION    REPLACES   PHASE
cpd-platform-operator.v6.0.0                  Cloud Pak for Data Platform Operator                                   6.0.0                 Succeeded
db2u-operator.v6.0.0                          IBM Db2                                                                6.0.0                 Succeeded
fdb-kubernetes-operator.v5.0.0                FoundationDB Kubernetes                                                5.0.0                 Succeeded
ibm-cert-manager-operator.v4.2.4              IBM Cert Manager                                                       4.2.4                 Succeeded
ibm-common-service-operator.v4.7.0            IBM Cloud Pak foundational services                                    4.7.0                 Succeeded
ibm-cpd-ae.v6.0.0                             IBM Analytics Engine Powered by Apache Spark Service                   6.0.0                 Succeeded
ibm-cpd-ccs.v9.0.0                            Common Core Services                                                   9.0.0                 Succeeded
ibm-cpd-data-product.v1.0.0                   Data Product Services                                                  1.0.0                 Succeeded
ibm-cpd-datarefinery.v9.0.0                   IBM Data Refinery                                                      9.0.0                 Succeeded
ibm-cpd-datastage-operator.v6.0.0             IBM DataStage                                                          6.0.0                 Succeeded
ibm-cpd-wkc.v2.0.0                            WKC Services                                                           2.0.0                 Succeeded
ibm-db2aaservice-cp4d-operator.v6.0.0         IBM® Db2 as a Service Operator Extension for IBM® Cloud Pak for Data   6.0.0                 Succeeded
ibm-elasticsearch-operator.v1.1.2131          IBM OpenContent Elasticsearch                                          1.1.2131              Succeeded
ibm-namespace-scope-operator.v4.2.3           IBM NamespaceScope Operator                                            4.2.3                 Succeeded
ibm-opencontent-foundationdb.v5.0.0           IBM Opencontent FoundationDB                                           5.0.0                 Succeeded
operand-deployment-lifecycle-manager.v4.3.0   Operand Deployment Lifecycle Manager                                   4.3.0                 Succeeded



[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get sub -n cpd-operator
NAME                                                                     PACKAGE                          SOURCE                                   CHANNEL
cpd-operator                                                             cpd-platform-operator            cpd-platform                             v6.2
fdb-kubernetes-operator-v5.0-ibm-fdb-operator-catalog-cpd-operator       fdb-kubernetes-operator          ibm-fdb-operator-catalog                 v5.0
ibm-common-service-operator                                              ibm-common-service-operator      opencloud-operators                      v4.7
ibm-cpd-ae-operator                                                      analyticsengine-operator         ibm-cpd-ae-operator-catalog              v6.2
ibm-cpd-ccs-operator                                                     ibm-cpd-ccs                      ibm-cpd-ccs-operator-catalog             v9.0
ibm-cpd-data-product-operator-catalog-subscription                       ibm-cpd-data-product             ibm-cpd-data-product-operator-catalog    v5.0
ibm-cpd-datarefinery-operator                                            ibm-cpd-datarefinery             ibm-cpd-datarefinery-operator-catalog    v9.0
ibm-cpd-datastage-operator                                               ibm-cpd-datastage-operator       ibm-cpd-datastage-operator-catalog       v6.2
ibm-cpd-wkc-operator-catalog-subscription                                ibm-cpd-wkc                      ibm-cpd-wkc-operator-catalog             v6.2
ibm-db2aaservice-cp4d-operator                                           ibm-db2aaservice-cp4d-operator   ibm-db2aaservice-cp4d-operator-catalog   v6.2
ibm-db2u-operator                                                        db2u-operator                    ibm-db2uoperator-catalog                 v6.2
ibm-elasticsearch-operator-v1.1-ibm-elasticsearch-catalog-cpd-operator   ibm-elasticsearch-operator       ibm-elasticsearch-catalog                v1.1
ibm-fdb-operator                                                         ibm-opencontent-foundationdb     ibm-fdb-operator-catalog                 v5.0
ibm-namespace-scope-operator                                             ibm-namespace-scope-operator     opencloud-operators                      v4.2
operand-deployment-lifecycle-manager-app                                 ibm-odlm                         opencloud-operators                      v4.3


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get ip -A
NAMESPACE          NAME            CSV                                     APPROVAL    APPROVED
cpd-operator       install-cb4m4   ibm-cpd-datastage-operator.v6.0.0       Automatic   true
cpd-operator       install-gc8nn   ibm-cpd-wkc.v2.0.0                      Automatic   true
cpd-operator       install-k9cws   fdb-kubernetes-operator.v5.0.0          Automatic   true
cpd-operator       install-pn5w4   ibm-cpd-data-product.v1.0.0             Automatic   true
cpd-operator       install-v6rpz   ibm-db2aaservice-cp4d-operator.v6.0.0   Automatic   true
ibm-cert-manager   install-6dr5h   ibm-cert-manager-operator.v4.2.4        Automatic   true
ibm-licensing      install-7jjgt   ibm-licensing-operator.v4.2.4           Automatic   true


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get operandregistry -A
I0521 22:46:50.335040  736006 request.go:621] Throttling request took 1.123456051s, request: GET:https://<Cluster url>:6443/apis/ccs.cpd.ibm.com/v1beta1?timeout=32s
NAMESPACE      NAME                                 AGE   PHASE                  CREATED AT
cpd-instance   common-service                       37m   Ready for Deployment   2024-05-22T05:09:24Z
cpd-instance   ibm-cpd-ae-registry                  22m   Ready for Deployment   2024-05-22T05:24:41Z
cpd-instance   ibm-cpd-ccs-registry                 22m   Ready for Deployment   2024-05-22T05:24:38Z
cpd-instance   ibm-cpd-datarefinery-registry        21m   Ready for Deployment   2024-05-22T05:24:51Z
cpd-instance   ibm-datastage-registry               22m   Ready for Deployment   2024-05-22T05:24:48Z
cpd-instance   ibm-db2aaservice-registry            22m   Ready for Deployment   2024-05-22T05:24:43Z
cpd-instance   opencontent-elasticsearch-registry   22m   Ready for Deployment   2024-05-22T05:24:36Z
cpd-instance   opencontent-foundationdb-registry    22m   Ready for Deployment   2024-05-22T05:24:46Z


[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get po -n cpd-operator
NAME                                                              READY   STATUS      RESTARTS   AGE
1c7246776ea4cd60d8cec97157cfde9e2813d477528c3d906d8da71d26x7r76   0/1     Completed   0          20m
2504c0fcf559ebe4c063c46caf0695efb3977f7110e02efe54d16dfcf86jpzk   0/1     Completed   0          39m
2712dc9492bb47e41305393f2666bf8e88b3af6fd1b7fda3e61a470f95sngm8   0/1     Completed   0          37m
28934e9fc19ac4085c758e83478fefa21b6fefc9263ff1fec406312df69z7lc   0/1     Completed   0          21m
29cb9e8695ae0ff8bd316a0af810c887f8264380dace2728e4d177ee73v6dgk   0/1     Completed   0          20m
2e25075096c541baabb6d413215bf9694cfbfe6ae6a7ee57cd0f37b575pzbn7   0/1     Completed   0          18m
417890f798f7c1e64b68d3f4d68113e9696475849740350a415fdc9c55gkrf8   0/1     Completed   0          18m
4c0d3115157e353ed573d7af8a5f74dfb80f32f8e8fda53fc3461f26f9vh6q7   0/1     Completed   0          22m
6044f0b97a0a84d51059d07aa867822cf90c4b7280a36cd96b3154653842j6x   0/1     Completed   0          17m
7ea89244dbcd304a120d420212ed7f5dc3309de4b1640efcda399996fas986s   0/1     Completed   0          19m
92ac5f6c6142a8dd829e0918152a67ffa493cf46178d55bb14be3410b6q6vmn   0/1     Completed   0          21m
9aff662549b3657350a3101443ee0a7255e55c2b40942b764d12027b64sfhp6   0/1     Completed   0          17m
9ceccd75be67f947a7b5a358e86fabbc014502d41087b0430d5f994616n2gbk   0/1     Completed   0          18m
apple-fdb-controller-manager-fb6f696d4-rbmj8                      1/1     Running     0          18m
cloud-native-postgresql-catalog-6qfp6                             1/1     Running     0          26m
cpd-platform-jq2jj                                                1/1     Running     0          26m
cpd-platform-operator-manager-54985cc4f6-xc8hn                    1/1     Running     0          22m
db2u-day2-ops-controller-manager-f58c4659b-rclm5                  1/1     Running     0          20m
db2u-operator-manager-5c4cd4f465-xx2t8                            1/1     Running     0          20m
db3a6ea56bd59e4e6e1ecf580973a43145074971cdcb68a8319299fda06sf8g   0/1     Completed   0          39m
e167a57546473e049aca78f95bd228c626dbfb14fda1a077828ea178fa7jtg4   0/1     Completed   0          21m
ibm-common-service-operator-569d8d66d5-4ltlm                      1/1     Running     0          38m
ibm-cpd-ae-operator-5f54669c55-lv4vw                              1/1     Running     0          19m
ibm-cpd-ae-operator-catalog-pv2sc                                 1/1     Running     0          26m
ibm-cpd-ccs-operator-5ccccd9f65-nrkz4                             1/1     Running     0          21m
ibm-cpd-ccs-operator-catalog-vx77l                                1/1     Running     0          26m
ibm-cpd-data-product-operator-6448df68fd-jdrc6                    1/1     Running     0          16m
ibm-cpd-data-product-operator-catalog-gk2mb                       1/1     Running     0          26m
ibm-cpd-datarefinery-operator-6ffb896488-4thrd                    1/1     Running     0          20m
ibm-cpd-datarefinery-operator-catalog-wx6tj                       1/1     Running     0          26m
ibm-cpd-datastage-operator-c5dcb6d9-tvfz8                         1/1     Running     0          18m
ibm-cpd-datastage-operator-catalog-4rqtv                          1/1     Running     0          26m
ibm-cpd-wkc-operator-b8dd8c648-6xd8c                              1/1     Running     0          17m
ibm-cpd-wkc-operator-catalog-jqjj4                                1/1     Running     0          26m
ibm-cs-iam-catalog-4bdmr                                          1/1     Running     0          41m
ibm-cs-install-catalog-dwh4q                                      1/1     Running     0          41m
ibm-db2aaservice-cp4d-operator-catalog-4jwzh                      1/1     Running     0          26m
ibm-db2aaservice-cp4d-operator-controller-manager-5887d496vljhs   1/1     Running     0          19m
ibm-db2uoperator-catalog-2tst5                                    1/1     Running     0          26m
ibm-elasticsearch-catalog-bkm2v                                   1/1     Running     0          26m
ibm-elasticsearch-operator-ibm-es-controller-manager-6b85cmbbmx   1/1     Running     0          20m
ibm-events-operator-catalog-ct2nn                                 1/1     Running     0          41m
ibm-fdb-controller-manager-6c7d799766-7v5hj                       1/1     Running     0          18m
ibm-fdb-operator-catalog-x4z4p                                    1/1     Running     0          26m
ibm-namespace-scope-operator-76fcbfbfd7-ksgfp                     1/1     Running     0          39m
ibm-zen-operator-catalog-x2rjj                                    1/1     Running     0          26m
opencloud-operators-npb7x                                         1/1     Running     0          41m
operand-deployment-lifecycle-manager-66f695c4b-vmq2b              1/1     Running     0          35m



./cpd-cli manage apply-cr --release=5.0.0 --components=cpd_platform,dataproduct --license_acceptance=true --cpd_operator_ns=cpd-operator --cpd_instance_ns=cpd-instance --file_storage_class=managed-nfs-storage --block_storage_class=managed-nfs-storage -vv



```

### Verify installs

```
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# export Namespace=cpd-instance
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get Ibmcpd ibmcpd-cr --namespace $Namespace -o jsonpath="{.status.controlPlaneStatus}" ; echo
I0522 02:56:57.826861  741964 request.go:621] Throttling request took 1.161750098s, request: GET:https://<Cluster url>:6443/apis/cpd.ibm.com/v1?timeout=32s
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get cm zen-lite-operation-configmap --namespace $Namespace -o jsonpath='{.data.operation}{"\n"}'
install
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get ZenService lite-cr --namespace $Namespace -o jsonpath='{.status.zenStatus}' ; echo
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get ccs ccs-cr --namespace $Namespace -o jsonpath='{.status.ccsStatus}{"\n"}'
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get Db2aaserviceService db2aaservice-cr --namespace $Namespace -o jsonpath='{.status.db2aaserviceStatus}{"\n"}'
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get datarefinery datarefinery-cr --namespace $Namespace -o jsonpath='{.status.datarefineryStatus}{"\n"}'
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get dataproduct dataproduct-cr --namespace $Namespace -o jsonpath='{.status.dataProductStatus}{"\n"}'
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get workflow workflow-cr --namespace $Namespace -o jsonpath='{.status.workflowStatus}{"\n"}'
Completed
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get enrichment enrichment-cr --namespace $Namespace -o jsonpath='{.status.enrichmentStatus}{"\n"}'
Completed




[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get ccs
NAME     VERSION   RECONCILED   STATUS      AGE
ccs-cr   9.0.0     9.0.0        Completed   129m
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get enrichment
NAME            VERSION   RECONCILED   STATUS      AGE
enrichment-cr   5.0.0     5.0.0        Completed   79m
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get datarefinery
NAME              VERSION   RECONCILED   STATUS      AGE
datarefinery-cr   9.0.0     9.0.0        Completed   95m
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get wkcgovui
NAME            VERSION   RECONCILED   STATUS      AGE
wkc-gov-ui-cr   5.0.0     5.0.0        Completed   87m
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get workflow
NAME          VERSION   RECONCILED   STATUS      AGE
workflow-cr   5.0.0     5.0.0        Completed   25m
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get dataproduct
NAME             VERSION   RECONCILED   STATUS      AGE
dataproduct-cr   5.0.0     5.0.0        Completed   130m





[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get pods -n cpd-operator | grep data-pro
ibm-cpd-data-product-operator-6448df68fd-jdrc6                    1/1     Running     0          4h34m
ibm-cpd-data-product-operator-catalog-gk2mb                       1/1     Running     0          4h43m
[root@<Cluster url> cpd-cli-linux-EE-14.0.0-269]# oc get pods -n cpd-instance | grep datapro
dataproduct-api-7b65b87c54-b9x5l                          1/1     Running     0              15m
dataproduct-ui-ff46fcdd-dwgr8                             1/1     Running     0              18m


```

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```
## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  Use the OpenShift built in restricted SCC.
Custom SecurityContextConstraints definition:
```
Not Applicable
```

