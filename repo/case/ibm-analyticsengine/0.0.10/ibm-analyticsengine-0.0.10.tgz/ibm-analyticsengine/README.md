# IBM Confidential
# OCO Source Materials
# 5737-H76, 5900-A16, 5900-A1J
# ©Copyright IBM Corp. 2020, 2024  All Rights Reserved.
# The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
# Name

IBM&reg; Analytics Engine Powered By Apache Spark

# Introduction

## Summary
Analytics Engine powered by Apache Spark is used as a compute engine to run analytical and machine learning jobs. It can be used to run a variety of workloads on your IBM Cloud Pak for Data cluster:

- Watson Studio notebooks that call Apache Spark APIs
- Spark applications that run Spark SQL
- Data transformation jobs
- Data science jobs
- Machine learning jobs

## Features

- Each time you submit a job, a dedicated Spark cluster is created for the job. You can specify the size of the Spark driver, the size of the executor, and the number of executors for the job. This enables you to achieve predictable and consistent performance.
- When a job completes, the cluster is automatically cleaned up so that the resources are available for other jobs.
- The service also includes interfaces that enable you to analyze the performance of your Spark applications and debug problems.

# Details

## Prerequisites
Analytics Engine powered by Apache Spark requires the following
- Bedrock version 3.7 or later
- Zen version 4.0.0 or later
- IBM Cloud Pak for Data Common Core Service version 4.0.0 or later

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |             |             |           |       |

# Installing

Step to install Analytics Engine using operator
1. [Setup the cluster with prerequisite](#prerequisite)
2. Install the operator in 2 ways:
- [Install with cloudctl](#install-analytics-engine-operator-using-cloudctl)
- [Install with custom OLM from UI](#install-analytics-engine-operator-using-olm-via-operator-hub)
3. [Create the analyticsengine custom resource](#deploy-analytics-engine-operator-cr-using-cloudctl)

#### Prerequisite
- Get the cloudctl binary to your $PATH. You can download from url https://github.com/IBM/cloud-pak-cli/releases
- Download the latest ibm-analyticsengine-4.0.0-<buildnumber>.tgz bundle from the 	`PrivateCloud-analytics/cpd-case-repo/tree/4.0.0/dev/case-repo-dev`.

- Setup ENV variable

```
export NAMESPACE_TO_WATCH=<Single value or comma seperated value, ex: ae1,ae2 for Analytics Engine Operator to watch and create Analytics Engine CR>
export DOCKER_APIKEY=<Docker API Key which has access to preprod.icr.io/cp/cpd registry to download analyticsengine-operator and analyticsengine service component>
export DOCKER_USERNAME=<Docker API username which has access to preprod.icr.io/cp/cpd registry to download analyticsengine-operator and analyticsengine service component>  like `iamapikey`
```

- Create configmap for analyticsengine-operator

```
oc create configmap namespace-scope --from-literal=namespaces=$NAMESPACE_TO_WATCH
```

- Back up your current global pull secret (IMPORTANT)

```
oc get secret pull-secret -n openshift-config -o yaml > global-pull-secret.yaml
```

- Create the global pull secret

```
pull_secret=$(echo -n "$DOCKER_USERNAME:$DOCKER_APIKEY" | base64 -w0)
oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|"auths":{|"auths":{"preprod.icr.io/cp/cpd":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json
```

**Reference:** https://docs.openshift.com/container-platform/4.6/openshift_images/managing_images/using-image-pull-secrets.html#images-update-global-pull-secret_using-image-pull-secrets
In case of something goes wrong, revert to your old secret.
You have to mirror the icr.io/cpopen and cp.irc.io/cp registry to your target registry where the images reside. Note that all the images are hardcoded with registry url icr.io/cpopen and cp.irc.io/cp. Please note that you cannot use the version tag for this new mechanism. The image digest has to specify in the resource yaml.

It might take up to 10-15 min to update nodes to setup mirrors during which time a scheduling will be desabled on the nodes. Check your nodes' status and wait until they are all Ready

To get analyticsengine-operator working. Assuming you have the pull secret setup for the staging repo

```
cat << EOF | oc apply -f -
apiVersion: operator.openshift.io/v1alpha1
kind: ImageContentSourcePolicy
metadata:
  name: mirror-config
spec:
  repositoryDigestMirrors:
  - mirrors:
    - preprod.icr.io/cp/cpd
    source: cp.icr.io/cp/cpd
  - mirrors:
    - preprod.icr.io/cp/cpd
    source: icr.io/cpopen
EOF
```

#### Install Analytics Engine Operator using cloudctl

```
export AE_OPERATOR_NAMESPACE=<operator-namespace>
cloudctl case launch --case ibm-analyticsengine-4.0.0-<buildnumber>.tgz --namespace $AE_OPERATOR_NAMESPACE --inventory analyticsengineOperatorSetup --action installOperatorNative --tolerance=1
```

Replace `<operator-namespace>` with the namespace that analyticsengine-operator will be running on.

#### Deploy Analytics Engine Operator CR using cloudctl

```
cloudctl case launch --case ibm-analyticsengine-4.0.0-<buildnumber>.tgz --tolerance 1 --namespace <namespace>
```

#### Analytics Engine CR Template.
**NOTE :** End users will use the below Analytics Engine CR template to Install Analytics Engine Module.

```
cat << EOF | oc apply -f -
apiVersion: ae.cpd.ibm.com/v1
kind: AnalyticsEngine
metadata:
  name: analyticsengine-sample
  labels:
    app.kubernetes.io/instance: ibm-cpd-ae-operator
    app.kubernetes.io/managed-by: ibm-cpd-ae-operator
    app.kubernetes.io/name: ibm-cpd-ae-operator
    build: BUILD_NUMBER
spec:
#  version: "4.0.0"
  license:
    accept: true
#-------------------------------------------------------#
# Following specs are optional and
# we have added default values as example in this CR.
#-------------------------------------------------------#
  scaleConfig: "small"
#-------------------------------------------------------#
# Following specs are optional and
# can be altered to change service level configurations
#-------------------------------------------------------#
#  serviceConfig:
#    sparkAdvEnabled: "true"                       # This flag will enable or disable job UI capabilities of AnalyticsEngine service
#    jobAutoDeleteEnabled: "true"                  # Set it to false if you do not want to removed spark jobs once they have reached terminal states e.g FINISHED/FAILED
#    fipsEnabled: "false"                          # Set it to true if your system is FIPS enabled
#    kernelCullTime: "30"                          # Change value in minutes, if want to remove idle kernel after X minutes.
#    imagePullCompletions: "20"                    # If you have very large Openshift cluster in that case you can update imagePullCompletions & imagePullParallelism accordingly
#    imagePullParallelism: "40"                    # e.g. if you have 100 nodes cluster set imagePullCompletions: "100" & imagePullParallelism: "150"
#    kernelCleanupSchedule: "*/30 * * * *"         # By default kernel & job cleanup cronjobs look for idle spark kernels/jobs and based on kernelCullTime parameter
#    jobCleanupSchedule: "*/30 * * * *"            # and removes them, if you want cleanup to less/more aggressive change accordingly. e.g for 1 hour "* */1 * * *" k8s format
#-------------------------------------------------------#
# Following specs are optional and can be altered
# to change spark runtime level configurations
#-------------------------------------------------------#
#  sparkRuntimeConfig:                             # If you want to create spark jobs with
#    maxDriverCpuCores: "5"                        # Drive CPUs more than 5 than set accordingly
#    maxExecutorCpuCores: "5"                      # or more than 5 CPU per Executor than set accordingly
#    maxDriverMemory: "50g"                        # or Drive Memory more than 50g than set accordingly
#    maxExecutorMemory: "50g"                      # or more than 50g Memory per Executor than set accordingly
#    maxNumWorkers: "50"                           # or more than 50 workers/executors than set accordingly
#    localDirScaleFactor: 10                          # or more than 10 emptyDir scale factor than set accordingly
#-------------------------------------------------------#
# Following specs are optional and can be altered
# to change service instance level configurations.
# Each AE service service instance have resource quota
# (cpu/memory) set by default as following. It can be changed
# via API for an instance but to change default values
# for any new instance creation update following
#-------------------------------------------------------#
#  serviceInstanceConfig:
#    defaultCpuQuota: "20"                         # defaultCpuQuota means accumulative cpu consumption of spark jobs create under an instance can be no more than 20
#    defaultMemoryQuota: 80                        # defaultMemoryQuota means accumulative memory consumption of spark jobs create under an instance can be no more than 80 in GB
EOF
```


#### Install Analytics Engine Operator using OLM via Operator Hub
1. Install operator catalog

```
export AE_OPERATOR_NAMESPACE=<operator-namespace>
cloudctl case launch --case ibm-analyticsengine-4.0.0-<buildnumber>.tgz --namespace <namespace name>  --inventory analyticsengineOperatorSetup --action installCatalog --tolerance 1

```
Replace `<operator-namespace>` with the namespace that analyticsengine-operator will be running on.


2. Install Analytics Engine operator using any of the below two options :

 Option 1. - Install the operator from cloudctl command
```
export AE_OPERATOR_NAMESPACE=<operator-namespace>
oc project $AE_OPERATOR_NAMESPACE
cloudctl case launch --case ibm-analyticsengine-4.0.0-<buildnumber>.tgz --namespace $AE_OPERATOR_NAMESPACE --inventory analyticsengineOperatorSetup --action install --tolerance=1
```
 Option 2. - Install the operator from the openshift console UI

 ```
  Example: https://console-openshift-console.apps.mocha6-qb.cp.fyre.ibm.com/operatorhub/ns/openshift-operators
    - Look for `IBM Analytics Engine Powered by Apache Spark Service` in the Operator Hub
    - Hit `Install` button
    - Choose namespaces for the operator to watch. Keep as default (watch all namespace) for now.
    - Hit `Install` button again
```

## Configuration
Following specs are optional and we have added default values as example in this CR.
```
	scaleConfig: "small"
```
Following specs are optional and can be altered to change service level configurations
```
	serviceConfig:
	  sparkAdvEnabled: "true"                       # This flag will enable or disable job UI capabilities of AnalyticsEngine service
	  jobAutoDeleteEnabled: "true"                  # Set it to false if you do not want to removed spark jobs once they have reached terminal states e.g FINISHED/FAILED
	  fipsEnabled: "false"                          # Set it to true if your system is FIPS enabled
	  kernelCullTime: "30"                          # Change value in minutes, if want to remove idle kernel after X minutes.
	  imagePullCompletions: "20"                    # If you have very large Openshift cluster in that case you can update imagePullCompletions & imagePullParallelism accordingly
	  imagePullParallelism: "40"                    # e.g. if you have 100 nodes cluster set imagePullCompletions: "100" & imagePullParallelism: "150"
	  kernelCleanupSchedule: "*/30 * * * *"         # By default kernel & job cleanup cronjobs look for idle spark kernels/jobs and based on kernelCullTime parameter
	  jobCleanupSchedule: "*/30 * * * *"            # and removes them, if you want cleanup to less/more aggressive change accordingly. e.g for 1 hour "* */1 * * *" k8s format
```
Following specs are optional and can be altered o change spark runtime level configurations
```
	sparkRuntimeConfig:                             # If you want to create spark jobs with
	  maxDriverCpuCores: "5"                        # Drive CPUs more than 5 than set accordingly
	  maxExecutorCpuCores: "5"                      # or more than 5 CPU per Executor than set accordingly
	  maxDriverMemory: "50g"                        # or Drive Memory more than 50g than set accordingly
	  maxExecutorMemory: "50g"                      # or more than 50g Memory per Executor than set accordingly
	  maxNumWorkers: "50"                           # or more than 50 workers/executors than set accordingly
```
Following specs are optional and can be altered to change service instance level configurations.Each AE service service instance have resource quota (cpu/memory) set by default as following. It can be changed via API for an instance but to change default values for any new instance creation update following
```
	serviceInstanceConfig:
	  defaultCpuQuota: "20"                         # defaultCpuQuota means accumulative cpu consumption of spark jobs create under an instance can be no more than 20
	  defaultMemoryQuota: 80                        # defaultMemoryQuota means accumulative memory consumption of spark jobs create under an instance can be no more than 80 in GB
```

## Storage

Analytics Engine powered by Apache Spark supports dynamic storage provisioning using storage class. The following storages are supported

* NFS
* Portworx 2.7
* OCS

## Limitations

- You must install IBM Cloud Pak for Data before installing Analytics Engine powered by Apache Spark.

## Documentation

TBD

## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```
## SecurityContextConstraints Requirements
 Custom SecurityContextConstraints definition:
 ```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/ibm-cloud-managed: "true"
    include.release.openshift.io/self-managed-high-availability: "true"
    include.release.openshift.io/single-node-developer: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: ibm-cpd-analyticsengine-scc
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret

 ```
