# Name

IBM&reg; IBM Cloud Pak for Data watsonx.ai

# Introduction

## Summary

IBM Cloud Pak for Data watsonx.ai provides the environment and tools for you to collaborately work on data to solve your business problems. You can choose the tools you need to analyze and visualize data, to cleanse and shape data, to ingest streaming data, or to create and train machine learning models.
See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/overview/overview.html)

## Features

The architecture of watsonx.ai is centered around the analytics project. Data scientists and business analysts use analytics projects to organize resources and analyze data.
You can have these types of resources in a project:
- Collaborators are the people on the team who work with the data.
- Data assets point to your data that is either in uploaded files or accessed through connections to data sources.
- Operational assets are the objects you create, such as scripts and models, to run code on data.
- Tools are the software you use to derive insights from data. These tools are included with the Watson Studio service:
Data Refinery: Prepare and visualize data.
Jupyter notebook editor: Code Jupyter notebooks.
JupyterLab IDE: Code Jupyter notebooks and Python scripts with Git integration. Other project tools require additional services. See the lists of supplemental and related services.

# Details

## Prerequisites

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/install/preinstall-overview.html)

### Resources Required

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/cpd/plan/rhos-reqs.html#rhos-reqs__production#rhos-reqs__production)


# Installing

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/install/install.html)

## Configuration

You can change the size of watsonx.ai by changing the `spec.size` value in watsonxaiifm cr.

## Storage

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_latest/cpd/plan/storage_considerations.html)

## Limitations
See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/wsj/getting-started/known-issues-local.html)


## Documentation

See [Details](https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/overview/overview.html)

## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restrict denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restrict
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```


