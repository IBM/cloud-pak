# aiopsLifecycleOperator

Contains the IBM Cloud Pak for AIOps Lifecycle Operator custom resource and launch scripts to install/delete the custom resources
