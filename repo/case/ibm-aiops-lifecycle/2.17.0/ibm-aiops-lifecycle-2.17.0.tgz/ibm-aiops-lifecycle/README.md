# Name

IBM&reg; Cloud Pak for AIOps Lifecycle

# Introduction

## Summary

IBM&reg; Cloud Pak for AIOps Lifecycle provides incident management function
to the IBM&reg; Clout Pak For Watsion AIOps
TODO: fill in...

## Features

* TODO: List features

# Details

## Prerequisites

### Resources Required

The sizing instructions for IBM&reg; Cloud Pak for AIOps should be
used to determine the cluster size required for this component.  The
component runs withing the Cloud Pak and is not meant to be installed
separately.

# Installing

AIOps Lifecycle installed as a part of IBM&reg; Cloud Pak for
AIOps.  Please refer to the Cloud Pak documentation when installing
this product:  https://ibm.biz/cpwaiops_welcome

## Configuration

AIOps Lifecycle is installed as a part of IBM&reg; Cloud Pak for
AIOps.  Please refer to the Cloud Pak documentation when configuring
this product.

## Storage

TODO: Describe storage obtained and its purpose

## Limitations

* TODO: List limitations here...

## Documentation

* Please refer to the IBM&reg; Cloud Pak for AIOps documentation:
  https://ibm.biz/cpwaiops_welcome

### PodSecurityPolicy Requirements
There are no explicit PSP required.

### SecurityContextConstraints Requirements
All pods run with the OpenShift Restricted SCC, which is included here for
reference.
Custom SecurityContextConstraints definition:
```yaml
kind: SecurityContextConstraints
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restricted
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: false
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
