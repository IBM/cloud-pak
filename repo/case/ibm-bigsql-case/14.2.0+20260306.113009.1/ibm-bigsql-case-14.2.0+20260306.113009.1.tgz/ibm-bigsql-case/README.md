# Name

IBM&reg; Db2 Big SQL

# Introduction

## Summary

Db2 Big SQL is a cloud-native, elastic, scalable SQL engine for open data formats on decoupled storage.

Db2 Big SQL (Big SQL in short) running on Cloud Pak for Data can query large amounts of data residing on legacy Hadoop clusters as well as on Private or Public Cloud Object Storage. Big SQL is highly optimized for multiple open source data formats, including Parquet, ORC, Avro and CSV.

When querying data stored on legacy Hadoop clusters, Big SQL leverages the configurations of open source components like HDFS, Hive metastore and Ranger.

Learn more at https://www.ibm.com/products/db2-big-sql

## Features

* Scale the Big SQL add-on as needed
* Process data set residing on a remote Hadoop data lake, a private or public Object Store service or both
* Access data stored in most common ope source formats: Parquet, ORC, Avro, CSV,  ...

# Details

## Prerequisites

### Red Hat OpenShift SecurityContextConstraints Requirements

* Custom SecurityContextConstraints definition:
```
allowHostDirVolumePlugin: true
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: true
allowedCapabilities:
- SYS_RESOURCE
- IPC_OWNER
- SYS_NICE
- CHOWN
- DAC_OVERRIDE
- FSETID
- FOWNER
- SETGID
- SETUID
- SETFCAP
- SETPCAP
- SYS_CHROOT
- KILL
- AUDIT_WRITE
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: RunAsAny
groups: []
kind: SecurityContextConstraints
metadata:
priority: 0
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: RunAsAny
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
volumes:
- '*'
```

### Resources Required

The minimum resource to install Big SQL are

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Big SQL   | 68          | 10.5        | 500       | 2     |
| **Total** |             |             |           |       |

# Installing

Instructions to prepare the cluster, plan & perform the service installation are available at https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=sql-installing-db2-big

## Configuration

Instructions to configure and administer the service are available at https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=sql-administering-db2-big

## Storage

Description of how the service leverages storage and in particular the difference between work storage and data storage is available at https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=sql-preparing-install-db2-big

## Limitations

* Upgrade from Big SQL on CP4D 4.0 is not supported
* As of CP4D 4.0, Big SQL only supports Cloudera Data platform 7.2 as a Hadoop distribution

## Documentation

* For more information, check the IBM Db2 Big SQL for Cloud Pak for Data 4.0 documentation at https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=services-db2-big-sql
