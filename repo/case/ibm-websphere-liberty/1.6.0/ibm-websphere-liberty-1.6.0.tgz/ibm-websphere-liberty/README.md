# Name

IBM&reg; WebSphere&reg; Liberty

# Introduction

## Details

IBM WebSphere Liberty is a modern Java EE, Jakarta EE, MicroProfile runtime, ideal for building new cloud-native applications and modernizing existing applications. Liberty is highly efficient and optimized for modern cloud technologies and practices, making it an ideal choice for container and Kubernetes-based deployments.

The WebSphere Liberty Operator allows you to deploy and manage containerized Liberty applications securely and easily on Red Hat OpenShift as well as other Kubernetes-based platforms in a consistent way. You can also perform Day-2 operations such as gathering traces and memory dumps easily using the operator.

## Prerequisites

Review the [system requirements](https://ibm.biz/wlo-sys-req) for details. 

### Resources Required

Review the [resource requirements](https://ibm.biz/wlo-reqs) before you plan to install IBM WebSphere Liberty operator.

# Installing

Install the IBM WebSphere Liberty operator to the desired namespace and create an instance of the [WebSphereLibertyApplication custom resource](https://ibm.biz/wlo-crs).

## Configuration

The WebSphere Liberty operator provides various customization options to configure the application deployments. Please see [custom resource](https://ibm.biz/wlo-crs) for details.

## Storage

Please see the [storage requirements](https://ibm.biz/wlo-reqs) for details.

## Limitations

* IBM WebSphere Liberty is not available on IBM Power&reg; Systems or IBM z Systems&reg; architectures.

## Documentation

See [IBM WebSphere Liberty documentation] (https://ibm.biz/wlo-docs).

## SecurityContextConstraints Requirements

The IBM WebSphere Liberty operator runs in the `restricted` security context constraints.
    
Custom SecurityContextConstraints definition:

```yaml
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata:
        name: websphere-liberty
    allowHostDirVolumePlugin: false
    allowHostIPC: false
    allowHostNetwork: false
    allowHostPID: false
    allowHostPorts: false
    allowPrivilegeEscalation: true
    allowPrivilegedContainer: false
    allowedCapabilities: null
    defaultAddCapabilities: null 
    fsGroup:
      type: MustRunAs
    users: []  
    groups: []
    priority: null
    readOnlyRootFilesystem: false
    requiredDropCapabilities:
    - ALL
    runAsUser:
      type: MustRunAsRange
    seLinuxContext:
      type: MustRunAs
    supplementalGroups:
      type: RunAsAny
    users: []
    volumes:
    - configMap
    - downwardAPI
    - emptyDir
    - persistentVolumeClaim
    - projected
    - secret
```        

