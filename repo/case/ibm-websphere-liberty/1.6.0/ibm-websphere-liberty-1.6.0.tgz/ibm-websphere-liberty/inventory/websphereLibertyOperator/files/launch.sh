#!/usr/bin/env bash
# (C) Copyright IBM Corp. 2022  All Rights Reserved.
#

# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action=""
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName=""
instance=""

# - optional parameter / argument defaults
dryRun=""
namespace=""
tolerance_val=0

# script version
version=0.0.1

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="
  --tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}

OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}

 ARGS per Action:
    apply-custom-resources     : creates the sample custom resource
      --viewLicense            : view the list of licenses
      --acceptLicense          : required to proceed with the install
      --licenseType            : must be set to a valid license type to proceed with the install.  
      --licenseMetric          : VPC (default) or PVU where VPC is Virtual Processor Core and PVU is Processor Value Unit
      --customResource         : custom resource name (webspherelibertyapplication (default), webspherelibertydump, webspherelibertytrace)  

    delete-custom-resources    : deletes the sample custom resource
      --customResource         : custom resource name (webspherelibertyapplication (default), webspherelibertydump, webspherelibertytrace)  
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ----- Actions -----
# Run the action specified
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# Parses the args (--args) parameter if any are specified
parse_dynamic_args() {
    _IFS=$IFS
    IFS=" "
    read -ra arr <<<"${1}"
    IFS="$_IFS"
    arr+=("")
    idx=0
    v="${arr[${idx}]}"
    while [ "$v" != "" ]; do
        case $v in
        # Enable debug from cloudctl invocation
        --debug)
            idx=$((idx + 1))
            set -x
            ;;
        --dryRun)
            dryRun="--dry-run"
            ;;
        --help)
            print_usage 0
            ;;
        *)
            # pass arr[i], arr[i+1] to the override function
            argVal=${arr[$((idx + 1))]}
            if [[ "$argVal" = --* ]]
            then
                echo "parse_custom_dynamic_args ${arr[${idx}]} "
                parse_custom_dynamic_args "${arr[${idx}]}" ""
            else
                echo "parse_custom_dynamic_args ${arr[${idx}]} ${arr[$((idx + 1))]}"
                parse_custom_dynamic_args "${arr[${idx}]}" "${arr[$((idx + 1))]}"
                idx=$((idx + 1))
            fi
            ;;
        esac
        idx=$((idx + 1))
        v="${arr[${idx}]}"
    done
}

print_client_tool_versions() {
    cluster_access=$1

    if [[ $cluster_access -eq 1 ]]; then
        command -v oc &> /dev/null && echo "oc: $(oc version)" || echo "oc client not installed"
    else
        command -v oc &> /dev/null && echo "oc: $(oc version --client)" || echo "oc client not installed"
    fi

    if [ ! -z "${USE_SKOPEO}" ]; then
        command -v skopeo &> /dev/null && skopeo -v || echo "skopeo not installed"
    fi
}


# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    # skip this check for certain actions
    skip_actions="imageInfo mirrorImages configureCredsAirgap initRegistry startRegistry stopRegistry postInstall validateInstall"
    if [[ "$skip_actions" != *$action* && -z "${dryRun}" ]]; then
        print_client_tool_versions "1"
        check_kube_connection
        check_kube_namespace
    else
        print_client_tool_versions
    fi
}

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exit "No oc or kubectl found in path"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

check_kube_namespace() {
    [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
    if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
        err_exit "Unable to retrieve namespace specified ${namespace}"
    fi
}

validate_file_exists() {
    local file=$1
    [[ ! -f ${file} ]] && { err_exit "${file} is missing, exiting deployment."; }
}

# ***** UTILS *****

# Print version
print_version() {
    echo "[INFO] Version ${version}"
    exit 0
}

# Warning reporting functions
warn() {
    echo >&2 "[WARNING] $1"
}

# Error reporting functions
err() {
    echo >&2 "[ERROR] $1"
}
err_exit() {
    echo >&2 "[ERROR] $1"
    exit 1
}

# ----- ABSTRACT FUNCTIONS -----
# the below functions can be overridden in launch implementation script

parse_custom_dynamic_args() {
    err_exit "Invalid Option ${v}"
}

# ----- INSTALL ACTIONS -----

# products can choose to implement the install/uninstall mechanism they support in launch_impl.sh
delete_custom_resources() {
    echo "Action not supported"
}


apply_custom_resources() {
    echo "Action not supported"
}

# ----- END ACTIONS -----

##
# Main
##
source "$scriptDir"/launch-impl.sh

# Parse CLI parameters
while [ "${1-}" != "" ]; do
    case $1 in
    # Supported parameters for cloudctl & direct script invocation
    --casePath | -c)
        shift
        casePath="${1}"
        ;;
    --caseJsonFile)
        shift
        caseJsonFile="${1}"
        ;;
    --inventory | -e)
        shift
        inventory="${1}"
        ;;
    --action | -a)
        shift
        action="${1}"
        ;;
    --namespace | -n)
        shift
        namespace="${1}"
        ;;
    --tolerance | -t)
        shift
        tolerance_val="${1}"
        ;;
    --instance | -i)
        shift
        instance="${1}"
        ;;
    --args | -r | --)
        shift
        parse_dynamic_args "${1}"
        ;;
    # Additional supported parameters for direct script invocation ONLY
    --help)
        print_usage 0
        ;;
    --debug)
        set -x
        ;;
    --version)
        print_version
        ;;
    *)
        echo "Invalid Option ${1}" >&2
        exit 1
        ;;
    esac
    shift
done

# Execution order
check_cli_args
run_action
