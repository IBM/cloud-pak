#
# (C) Copyright IBM Corp. 2022  All Rights Reserved.
#
view_license() {
    local _license_list_file=${casePath}/inventory/${inventory}/files/license_list

    echo ""
    echo "IBM WebSphere Liberty is offered under the following licences:"
    echo ""
    cat ${_license_list_file}
    echo ""
    echo "For details on each license, please see https://ibm.biz/was-license"
    echo ""
    echo "Use the --licenseType option when installing to specify the ID of the license you are accepting."
    echo ""
}

get_full_license_from_id() {
    local _license_list_file=${casePath}/inventory/${inventory}/files/license_list
    local _full_license_descr="INVALID"

    while IFS= read -r line || [ -n "$line" ]; do
        local _id=$(echo ${line} | sed "s/.* - //")

        if [[ "${line}" == "${license_type}" ]] || [[ "${_id}" == "${license_type}" ]]; then
            _full_license_descr=$(echo ${line} | sed -e 's/[0-9].*$//')
            break
        fi

    done < "${_license_list_file}"

    echo ${_full_license_descr}
}

check_license_type() {
    local _license_list_file=${casePath}/inventory/${inventory}/files/license_list

    _full_license_descr=$(get_full_license_from_id ${license_type})
    if [[ ${_full_license_descr} == "INVALID" ]]; then
        err_exit "License type \"${license_type}\" is not valid. You must provide a valid license type using the --licenseType option. Use --viewLicense to see the valid options."
    fi
}

check_license_accept() {

    if [ -z "${license_accept}" ]; then
        err_exit "You must accept the license before installing IBM WebSphere Liberty. Use '--viewLicense' to view the license and '--acceptLicense' to accept the license."
    fi
}

check_license() {
    if [ -n "${view_license}" ]; then
        view_license
        exit 0;
    fi

    check_license_type

    check_license_accept
}
