#!/bin/bash -x
# (C) Copyright IBM Corp. 2022  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this WebSphere Traditional operator

# websphere liberty operator specific variables
caseName="ibm-websphere-liberty"
inventory="websphereLibertyOperatorSetup"
caseCatalogName="ibm-websphere-liberty-catalog"
catalogNamespace="openshift-marketplace"
channelName="v1.6"
#cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
#case_dependencies="ibm-cp-common-services"
crd="webspherelibertyapplication"
license_metric="VPC"

# parse additional dynamic args
parse_custom_dynamic_args() {
    local _key=$1
    local _val=$2
    
    case $_key in	    
    --viewLicense)
        view_license=true
        ;;	
    --acceptLicense)
        license_accept=true
        ;;
    --licenseType)
        license_type="${_val}"
        ;;	
    --licenseMetric)
        license_metric="${_val}"    
        ;;
    --customResource)
        crd="${_val}"   
	    ;;
    --help)
        #print_usage 0
        ;;           
    *)
        err_exit "Invalid Option ${_key}"
        ;;	  
    esac    
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
#dependent_inventory_item() {
#    local case_name=$1
#    case $case_name in
#    ibm-cp-common-services)
#        echo "ibmCommonServiceOperatorSetup"
#        return 0
#        ;;
#    *)
#        echo "unknown case: $case_name"
#        return 1
#        ;;
#    esac
#}


source "${casePath}"/inventory/"${inventory}"/files/license_check.sh	

# ----- INSTALL ACTIONS -----

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
#install_operator_native() {
    # Verfiy arguments are valid
#    validate_install_args

    # install all operators of subcases first
#    if [[ ${recursive_action} -eq 1 ]]; then
#        install_dependent_operators
#    fi
    # Proceed with install

#    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
#    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
#    local manifest_file="${op_cli_files}/manifests.yaml"

#    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
#    sed -e "s|ibm-sample-panamax-operator-system|${namespace}|g" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

#}

# install operand custom resources
apply_custom_resources() {
    #if [ -z "$license" ]; then
    #    err_exit "To apply the custom resources, the license must be accepted by adding '--args \"--licenseAccept\"'."
    #fi

    check_license
    
    local license_desc=$(get_full_license_from_id ${license_type})

    	
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/liberty.websphere.ibm.com_v1_${crd}s.yaml

    validate_file_exists "$cr"

    standalone="IBM WebSphere Application Server"
    if [[ "$license_desc" =~ ^$standalone ]] && [[ "$license_desc" != *"Family"* ]]; then
      edition=$license_desc
      entitlement="Standalone"
    else
      entitlement=$license_desc
      edition=$standalone
    fi  

    if [ "$license_metric" == "VPC" ]; then
      metric="Virtual Processor Core (VPC)"
    elif [ "$license_metric" == "PVU" ]; then
      metric="Processor Value Unit (PVU)"
    else
      err_exit "Invalid Metric ${license_metric}"
    fi  

    sed -e "s/accept: false/accept: ${license_accept}/g" \
        -e "s/edition: .*/edition: ${edition}/g" \
        -e "s/productEntitlementSource: .*/productEntitlementSource: ${entitlement}/g" \
        -e "s/metric: .*/metric: ${metric}/g" \
        "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    #    $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    #done
    # - dependent resources
    #$kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
#uninstall_operator_native() {
   # Verfiy arguments are valid
#    validate_install_args

    # Proceed with install
#    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
#    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
#    local manifest_file="${op_cli_files}/manifests.yaml"

#    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
#    sed <"${manifest_file}" "s|ibm-sample-panamax-operator-system|${namespace}|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
#}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/config/samples/liberty.websphere.ibm.com_v1_${crd}s.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
