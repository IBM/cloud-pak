# Introduction
Data scientists can use Jupyter Notebook runtimes for Watson Studio to run notebooks and experiments that train compute-intensive machine learning models in Watson Studio analytics projects.
# Link To External Documentation
See [Jupyter Notebook runtimes for Watson Studio](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=services-jupyter-notebook-runtimes-watson-studio)
### SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
See [Custom security context constraints for services](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=tasks-custom-sccs-services)
