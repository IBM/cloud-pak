# Name

IBM&reg; Maximo&reg; Application Suite

# Introduction
## Summary
IBM&reg; Maximo&reg; Application Suite is a program that offers a single point of access to the full suite of Maximo asset lifecycle management capabilities. This robust offering is built to accelerate digital transformation and provide AI-driven maintenance.

## Features
Use the IBM&reg; Maximo&reg; Application Suite collection of applications, add-ons, tools and industry solutions to build an asset management solution for your enterprise needs.

From the Maximo Application Suite dashboard, you can configure and deploy applications, add-ons, tools and industry solutions, administer your users, and more. Use the Suite navigator and the app switcher in the menu bar to navigate between applications or to get back to the Maximo Application Suite Suite navigator.

# Details
## Prerequisites

See Maximo Application Suite prerequisites details [here](http://www.ibm.com/docs/SSRHPA_cd/appsuite/install/dependencies/index.html).

Summary of Prerequisites required for IBM&reg; Maximo&reg; Application Suite:
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4.12/4.13/4.14/4.15
- IBM Certificate Manager installed in the cluster. For more information, see [IBM Certificate Manager install guide](https://www.ibm.com/docs/en/mas-cd/continuous-delivery?topic=services-certificate-manager).
- MongoDB, either internal to the cluster or external.
- User Data Services to assist with collecting and processing license and usage information. For more information on how to install UDS, see [User Data Services install guide](https://www.ibm.com/docs/en/mas-cd/continuous-delivery?topic=services-user-data).
- IBM Suite License Service (SLS) to be available to provide the licensing system that Maximo Application Suite uses. For mode information, see [Suite License Service install guide](https://www.ibm.com/docs/en/mas-cd/continuous-delivery?topic=services-suite-license-service).
- An IBM Entitled Registry key

### Resources Required
Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |   4.6       |  0.8        |  0        |  1    |


## Installing
- Navigate to OperatorHub in your OpenShift Dashboard and install the ibm-mas  operator following the instructions presented there.
- Deploy an instance of the `Suite` via the installed operator. Provide details of the IBM Certificate Manager namespace and a Certificate Issuer to use (if configured). You must also accept the license.
- Once the suite is installed you can then create the following via the OpenShift Installed Operator page to complete the Maximo Application Suite initial install:
  - Configure User Data Services integration: Provide the host details and contact details of the User Data Services prerequisite. Including any TLS certificates required to contact this service.
  - Configure MongoDb: Provide the host details and credentials of the MongoDB prerequisite. Including any TLS certificates required to contact this service.
  - Configure Suite License Service: Configure details of the IBM Suite License Service prerequisite. Including any TLS certificates required to contact this service.
  - Create Workspace: Create the workspace to be used. Details on Addons don't need to be provided at this point.
- Once all resources have reported "Ready" status you can navigate to Admin Dashboard: `https://admin.{{suite_instanceId}}.{{suite_domain}}` and login with the credentials from the secret `{{ suite_instanceId }}-credentials-superuser` which will be found under `mas-{{ suite_instanceId }}-core` namespace.
- Further custom resources can be created depending on the applications/tools to be installed. These custom resources can also be configured using the Maximo Application Suite UI.

### Verifying Install
Check status of the Suite custom resource:
```sh
oc get suite {{instanceId}}
NAME      VERSION            STATUS   SYSTEMDATABASEREADY   BASINTEGRATIONREADY   SLSINTEGRATIONREADY   AGE
mascore   8.11.0              Ready    Ready                 Ready                 Ready                 5h53m
```

For a more detailed view of the status run the following:
```sh
oc get suite {{instanceId}} -o yaml
```

The status will show four key conditions (SLSIntegrationReady, BASIntegrationReady, RoutesReady and SystemDatabaseReady) and an overall Ready status type:
```yaml
  status:
    conditions:
    - lastTransitionTime: '2023-07-12T07:33:57Z'
      message: MAS is ready to use
      reason: Ready
      status: 'True'
      type: Ready
    - lastTransitionTime: '2023-06-10T15:12:36Z'
      message: MongoDB configuration was successfully verified
      reason: Ready
      status: 'True'
      type: SystemDatabaseReady
    - lastTransitionTime: '2023-07-09T07:30:33Z'
      message: BAS configuration was successfully verified
      reason: Ready
      status: 'True'
      type: BASIntegrationReady
    - lastTransitionTime: '2023-06-10T15:24:53Z'
      message: MAS Licensing API endpoint check succeeded
      reason: Ready
      status: 'True'
      type: SLSIntegrationReady
    - lastTransitionTime: '2023-12-08T09:58:08Z'
      message: MAS Routes ready
      reason: Ready
      status: 'True'
      type: RoutesReady
```


## Configuration
See the details provided in [IBM docs](https://www.ibm.com/docs/SSRHPA/latest) for more information about how to configure Maximo Application Suite.

## Storage

IBM&reg; Maximo&reg; Application Suite requires no direct persistent storage in the OpenShift cluster. All data is stored in the MongoDB prerequisite. Applications/Tools that can be installed within the Maximo Application Suite might require storage within the OpenShift cluster.

### Encryption

We recommend the use of storage with passive encryption enabled to protect the data in MongoDB.

## AirGap Installs
Air gap installs are supported in Maximo Application Suite 8.11. For more information, see [Installing Maximo Application Suite in an AirGap environment](https://www.ibm.com/docs/mas/continuous-delivery/appsuite/install/install_airgap.html).

## Limitations
- The operator only supports single namespace deployment
- The operator will only watch for resources in its own namespace
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of the Suite can **not** be deployed in the same namespace
- Each Suite resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-core`

## Upgrades
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.8/html/operators/administrator-tasks#olm-upgrading-operators).

Note that during operator upgrade there may be a small delay applying configuration changes to the MAS installation while the operator pods are restarted.

## Documentation
The Maximo Application Suite documentation is available [here](https://www.ibm.com/docs/SSRHPA/latest)

## License
Maximo Application Suite 8.11 License is available [here](https://ibm.biz/MAS811-License) 

## Roles and Personas

Installation and configuration of the Maximo Application Suite operator may be divided into two Roles or Personas to limit the access privileges required.
- Cluster Admin - Installs the operator into a namespace
- End User - Creates suite custom resource(s) so that the operator produces required resources to allow the Maximo Application Suite to function.

## Backup
### Backup process
Backups should be made of both the OpenShift Cluster and MongoDb.

OpenShift Cluster backup requires backing up the etcd cluster. Details can be found in the OpenShift Container Platform [documentation](https://docs.openshift.com/container-platform/4.8/backup_and_restore/control_plane_backup_and_restore/backing-up-etcd.html)

Backups should be made of the following MongoDB databases created:
- `mas_{{instanceId}}_core`
- `mas_{{instanceId}}_catalog`

There is no need to backup the following MongoDB databases:
- mas_{{instanceId}}_adoptionusage

Each Application deployed via Maximo Application Suite might require additional backup sources, please consult the documentation for each application.

### Restore process
Restoring should be executing as described in the OpenShift Container Platform documentation and MongoDB documentation.

## SecurityContextConstraints Requirements
The operator uses the Openshift default `restricted` SCC (Security Context Constraints).


## Reason Codes

#### Suite-upgrade:
- **UpgradeCheckFailed** : Fail if non supported app is deployed / Current Version is not previous minor Release
- **UpgradeCheckSuccess** : No issues found during upgrade check

#### Suite:
- **PodTemplatesValid** : Validation of podTemplates keys
- **CertificateNotReady** : Secret is not available
- **TruststoreNotReady** : Suite truststore is not ready

#### Addons:
- **AppPointReservationFailed** : AppPoint Reservation failed
- **Ready** : Legacy configuration has changed
- **InvalidConfiguration** : Creation of configmap failed
- **Removed** :  config has been removed
- **CertificateNotReady** : Timed out waiting for client authentication certificate to be created
- **Ready** : get secret or create configmap failed

#### BasCfg:
- **PodTemplatesValid** : Validation of podTemplates keys
- **ValidationFailed** : BAS configuration was unable to be verified
- **SuiteIsNotInstalled** : Suite does not exist in the namespace
- **MissingCredentials** : Resource / Secret missing in the namespace
- **InvalidCredentials** : Secret does not contain the expected key 'api_key'
- **Ready** : BAS configuration was successfully verified
- **ValidationFailed** : BAS configuration validation failed

#### IdpCfg:
- **InvalidConfiguration** : SAML configuration is incomplete
- **Ready** : IDP configuration was successfully verified
- **ValidationFailed** : IDP configuration validation failed
- **Secret does not exist in the coreNamespace namespace, you must create the secret** :  LDAP Credentials are not available
- **Resource does not contain the expected keys 'username' and 'password’** : LDAP Credentials are not available (secret is missing bindDN and/or bindPassword fields)

#### JdbcCfg:
- **SuiteIsNotInstalled** : Suite does not exist in the namespace
- **MissingCredentials** : Resource / Secret missing in the namespace
- **InvalidCredentials** : Secret does not contain the username and password
- **InvalidConfiguration** : “Provided JDBC config is invalid”
- **Ready** : JDBC configuration was successfully verified
- **ValidationFailed** : JDBC configuration validation failed

#### KafkaCfg:
- **Ready** : Kafka configuration was successfully verified
- **ValidationFailed** : Kafka configuration was unable to be verified

#### MongoCfg:
- **Ready** : MongoDB configuration was successfully verified
- **ValidationFailed** : MongoDB configuration was unable to be verified
- **DeprecatedTlsInsecureValue**: The MongoDB connection requires the tlsInsecure flag to be set. In Maximo Application Suite 8.10, for security reasons, the default setting for this flag is false. To use this flag, update the MongoDB CR with spec.config.tlsInsecure:false and the upgrade will automatically proceed

#### ObjectStorageCfg:
- **Ready** : Ready
- **ValidationFailed** : MongoDB configuration was unable to be verified

#### PushNotificationsCfg:
- **PodTemplatesValid** : Validation of podTemplates keys
- **SuiteIsNotInstalled** : Suite does not exist in the namespace
- **MissingCredentials** : Resource / Secret missing in the namespace
- **InvalidCredentials** : Secret does not contain the  expected keys
- **Ready** : Configuration is ready to use

#### scimCfg:
- **PodTemplatesValid** : Validation of podTemplates keys
- **SuiteIsNotInstalled** :  Suite does not exist in the namespace
- **SCIM server and agent configured** : Cronjob ready to run

#### SlsCfg:
- **PodTemplatesValid** : Validation of podTemplates keys
- **MissingCredentials** : Resource / Secret missing in the namespace
- **InvalidCredentials** : Secret does not contain the  expected key
- **RegistrationFailed** : SLS client registration was unsuccessful
- **Ready** : MAS Licensing API endpoint check succeeded
- **APICheckFailed** : MAS Licensing API endpoint check failed
- **FatalError** : SlsCfg resource can not be reconciled.  Registered is set to 'True', but no configuration is recorded in the status sub-resource
- **Success** : SLS registration was successful
- **Valid** : License key is valid for MAS
- **MissingRequiredFeatures** : License key file is missing required MAS product features
- **MissingAccountMetadata** : License key file is missing required MAS account metadata
- **ExpiredFeatures** : License key file has expired features
- **SLSAPIError** : SLS error thrown while validating license key file
- **UnhandledError** : Unknown error thrown while validating license key file

#### SmtpCfg:
- **PodTemplatesValid** : Validation of podTemplates keys
- **SuiteIsNotInstalled** :  Suite does not exist in the namespace
- **MissingCredentials** : Resource / Secret missing in the namespace
- **InvalidCredentials** : Secret does not contain the expected username and/or password key(s)
- **ValidationFailed** : SMTP configuration was unable to be verified
- **Ready** : SMTP configuration is ready to use

#### WatsonStudioCfg:
- **Ready** : Ready

#### Coreidp:
- **PodTemplatesValid** : Validation of podTemplates keys
- **CertificateNotReady** : Internal certificate is not available
- **TruststoreNotReady** : CoreIDP truststore is not ready.  Timed out after 1 minute.
- **TruststoreReady** : Trustsore is now ready
- **Ready** : CoreIDP configured

####  Workspace:
- **SuiteIsNotInstalled** : Unable to find resource Suite
- **Removed** : Workspace database record has been deleted
- **CrNameInvalid** :  Fail if the CR name does not match expected name
- **CertificateNotReady** : Timed out waiting for client authentication certificate to be created
- **CertificateNotReady** : Unable to find resource Secret
- **DatabaseUpdateFailed** : database update failed
