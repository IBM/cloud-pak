# Name

IBM&reg; Storage Fusion Management Operator

## Introduction

### Summary

IBM Storage Fusion HCI delivers a container-native hybrid cloud data platform for Red Hat OpenShift Container Platform. A comprehensive infrastructure with compute, network, and storage resources, including a data platform and global data services for Red Hat OpenShift. It is built with a storage platform that includes the essential elements necessary for mission-critical containers and the hybrid cloud.       Management user interface for configuration and monitoring that includes compute, storage, and networking:
  - Integrated Call home support and troubleshooting
  - Support for deploying virtual machines with Red Hat OpenShift Virtualization
  - Application backup and restore

### Features

* Simple bullet list of product features
* [See an example](<git repo>IBMCloudPak4Apps/icpa-case/blob/e7894e4ae1fdf312325c5ece0905bafb27116554/stable/ibm-cp-applications-bundle/case/ibm-cp-applications/README.md)

## Details

### Supported platforms

Red Hat OpenShift Container Platform 4.10 or higher installed on one of the following platforms:

- Linux x86_64

## Prerequisites

IBM Storage Fusion HCI can be deployed on an HCI appliance.

## Resources Required

To learn about the IBM Storage Fusion HCI system requirements, visit our [requirements doc](https://ibm.com/docs/en/sfhs/2.8.x?topic=prerequisites-hardware-overview-single-rack)

## Installing IBM Storage Fusion HCI
###Planning your installation
Visit our [planning doc](https://ibm.com/docs/en/sfhs/2.8.x?topic=system-planning-prerequisites)

## How to Install

Follow [installation doc](https://ibm.com/docs/en/sfhs/2.8.x?topic=system-installing-storage-fusion-hci)

## Configuration

To confirm the configuration is correct and the success of the installation, refer [install verification doc](https://ibm.com/docs/en/sfhs/2.8.x?topic=system-validating-storage-fusion-hci-installation)

## Storage

IBM Storage Scale

## Limitations

Refer to our [troubleshooting doc](https://ibm.com/docs/en/sfhs/2.8.x?topic=installation-upgrade-issues)

## Documentation

  - [Global Data Platform](https://ibm.com/docs/en/sfhs/2.8.x?topic=configuring-storage)
  - [Fusion Data Foundation](https://ibmdocs-test.dcs.ibm.com/docs/en/sfhs/2.8.x?topic=storage-fusion-data-foundation-414)
  - [Data Cataloging](https://ibmdocs-test.dcs.ibm.com/docs/en/sfhs/2.8.x?topic=data-cataloging)
  - [Data Protection](https://ibmdocs-test.dcs.ibm.com/docs/en/sfhs/2.8.x?topic=data-protection)
  - [Data Recovery](https://ibmdocs-test.dcs.ibm.com/docs/en/sfhs/2.8.x?topic=disaster-recovery)
  - [Workload](https://ibmdocs-test.dcs.ibm.com/docs/en/sfhs/2.8.x?topic=workloads)

## Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
allowHostPorts: false
priority: null
requiredDropCapabilities:
  - ALL
allowPrivilegedContainer: false
runAsUser:
  type: MustRunAsRange
users: []
allowHostDirVolumePlugin: false
allowHostIPC: false
seLinuxContext:
  type: MustRunAs
readOnlyRootFilesystem: false
metadata:
  annotations:
    include.release.openshift.io/ibm-cloud-managed: 'true'
    include.release.openshift.io/self-managed-high-availability: 'true'
    include.release.openshift.io/single-node-developer: 'true'
    kubernetes.io/description: >-
      restricted denies access to all host features and requires pods to be run
      with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated
      users.
    release.openshift.io/create-only: 'true'
  creationTimestamp: '2021-07-16T09:49:07Z'
  generation: 1
  managedFields:
    - apiVersion: security.openshift.io/v1
      fieldsType: FieldsV1
      fieldsV1:
        'f:seLinuxContext':
          .: {}
          'f:type': {}
        'f:readOnlyRootFilesystem': {}
        'f:metadata':
          'f:annotations':
            .: {}
            'f:include.release.openshift.io/ibm-cloud-managed': {}
            'f:include.release.openshift.io/self-managed-high-availability': {}
            'f:include.release.openshift.io/single-node-developer': {}
            'f:kubernetes.io/description': {}
            'f:release.openshift.io/create-only': {}
        'f:volumes': {}
        'f:groups': {}
        'f:defaultAddCapabilities': {}
        'f:allowedCapabilities': {}
        'f:supplementalGroups':
          .: {}
          'f:type': {}
        'f:allowHostPID': {}
        'f:allowHostNetwork': {}
        'f:allowPrivilegeEscalation': {}
        'f:users': {}
        'f:runAsUser':
          .: {}
          'f:type': {}
        'f:allowHostPorts': {}
        'f:priority': {}
        'f:requiredDropCapabilities': {}
        'f:allowPrivilegedContainer': {}
        'f:allowHostDirVolumePlugin': {}
        'f:fsGroup':
          .: {}
          'f:type': {}
        'f:allowHostIPC': {}
      manager: cluster-version-operator
      operation: Update
      time: '2021-07-16T09:49:07Z'
  name: restrictedscc
  resourceVersion: '1735'
  selfLink: /apis/security.openshift.io/v1/securitycontextconstraints/restricted
  uid: c4dd3535-8b06-4306-bafd-08007076f840
fsGroup:
  type: MustRunAs
groups: []
kind: SecurityContextConstraints
defaultAddCapabilities: null
supplementalGroups:
  type: RunAsAny
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
allowHostPID: false
allowHostNetwork: false
allowPrivilegeEscalation: false
apiVersion: security.openshift.io/v1
allowedCapabilities: null
```

## PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition: No requirement

