# isfOperator
