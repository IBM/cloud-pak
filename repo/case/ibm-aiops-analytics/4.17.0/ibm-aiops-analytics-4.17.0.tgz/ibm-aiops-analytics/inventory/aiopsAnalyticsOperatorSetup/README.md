# aiopsAnalyticsOperatorSetup

This inventory item contains resources required to install the IBM Cloud Pak for AIOps Analytics Operator through the Operator Lifecycle Manager (OLM) in an online environment.
