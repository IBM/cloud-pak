# aiopsAnalyticsOperator

Contains the IBM Cloud Pak for AIOps Analytics Operator custom resource and launch scripts to install/delete the custom resources
