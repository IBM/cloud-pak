# Name

IBM&reg; Cloud Pak for AIOps Issue Resolution Analytics

# Introduction

## Summary

The IBM&reg; Issue Resolution Analytics operator is designed to reduce the time to action for operators and SRE's, by providing scalable data mining, domain specific natural language processing and real time graph analysis that enrich insights to alerts and stories within the IBM&reg; Cloud Pak for AIOps.

## Features

* Scalable temporal grouping implementation for historical alert data, with human interactable outputs to allow for simple and effective user interactions with the AI system
* Domain specific training and inference framework for alert classification
* Runtime and file server used for composing horizontally scalable and optimised data analysis pipelines on the Apache Spark 3.1.2 platform
* Probable root cause analysis and story topology graph generation, utilising data feeds from Alerts, Stories and System Topology

# Details

## Prerequisites

### Resources Required

The sizing instructions for IBM® Cloud Pak for AIOps should be used to determine the cluster size required for this component. The component runs within the Cloud Pak and is not meant to be installed separately.

# Installing

The Issue Resolution Analytics capabilities are installed as a part of IBM&reg; Cloud Pak for
AIOps. Please refer to the Cloud Pak documentation when installing
this product: https://ibm.biz/cpwaiops_welcome

## Configuration

AIOps Analytics is installed as a part of IBM&reg; Cloud Pak for
AIOps. Please refer to the Cloud Pak documentation when configuring
this product.

## Storage

The Issue Resolution Analytics components do not allocate or use any persistent storage directly.
The IBM&reg; Cloud Pak for AIOps provisions an Apache Kafka, Apache Cassandra and Cloudant instance, which use persistent storage, and analytics services
will interact with these stateful components by reading and writing data that should be persisted. Please refer to the Cloud Pak documentation when configuring storage.

## Limitations

* The AIOpsAnalyticsOrchestrator CRD can only be provisioned within same namespace as the controller manager  
* It is advisable not to configure multiple instances against the same stateful integrations. Despite the components being multi-tenanted, there are no assurances that the same tenantId of multiple components will not interact with eachothers stateful data within Apache Cassandra, Apache Kafka and Cloudant Couch. The recommended mechanism to use multiple instances of this CRD are to deploy multiple instances of the IBM&reg; Cloud Pak for AIOps to ensure there are dedicated stateful components.
* Currently, only the amd64 architecture is supported

## Documentation

* Please refer to the IBM&reg; Cloud Pak for AIOps documentation:
  https://ibm.biz/cpwaiops_welcome

### PodSecurityPolicy Requirements
There are no explicit PSP required.

### SecurityContextConstraints Requirements
All pods run with the OpenShift Restricted SCC, which is included here for
reference.
Custom SecurityContextConstraints definition:
```yaml
kind: SecurityContextConstraints
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restricted
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: false
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
