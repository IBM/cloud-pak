# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the issue resolution analytics operator and was
# derived from the IBM panamax sample operator.

# AIOps analytics operator specific variables
caseName="ibm-aiops-analytics"
inventory="aiopsAnalyticsOperatorSetup"
caseCatalogName="aiops-analytics-operator-catalog"
catalogNamespace="openshift-marketplace"
caseSubscriptionName="aiops-analytics-operator-catalog-subscription"
caseGroupName="aiops-analytics-operator-catalog-group"
channelName=v5.1
skip_redis_uninstall=0

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --skipRedisUninstall)
        skip_redis_uninstall=$val
        ;;
    esac
}

# ----- INSTALL ACTIONS -----

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed "s|REPLACE_NAMESPACE|${namespace}|g" "${opgrp_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    # TODO: file name
    local cr="${casePath}"/inventory/"${inventory}"/files/aiopsanalyticsorchestrator_v1beta1_aiopsanalyticsorchestrator.yaml

    validate_file_exists "$cr"

    sed -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscriptions.operators.coreos.com "${caseSubscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscriptions.operators.coreos.com "${caseSubscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseGroupName}" -n "${namespace}" --ignore-not-found=true

    # delete crds - skip because CRD yamls are not included in the CASE
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done

    # - dependent resources - none 
    # $kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    
    # Delete catalog source
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/aiopsanalyticsorchestrator_v1beta1_aiopsanalyticsorchestrator.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
