# db2uOperatorStandalone

Contains the standalone Db2U Operator custom resource and launch scripts to install/delete the custom resources
