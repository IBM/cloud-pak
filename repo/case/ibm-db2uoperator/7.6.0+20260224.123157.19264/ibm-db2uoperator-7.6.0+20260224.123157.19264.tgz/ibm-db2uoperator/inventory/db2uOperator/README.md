# db2uOperator

Contains the Db2U Operator custom resource and launch scripts to install/delete the custom resources
