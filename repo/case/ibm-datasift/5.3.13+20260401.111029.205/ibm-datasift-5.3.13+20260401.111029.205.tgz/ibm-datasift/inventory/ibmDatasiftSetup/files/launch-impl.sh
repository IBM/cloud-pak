# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName=ibm-datasift
inventory=ibmdatasiftSetup
caseCatalogName=ibm-cpd-datasift-operator-catalog
channelName="v1"
catalogTag="latest"

# variables specific to catalog installation
catalogNamespace="openshift-marketplace"
case_dependencies="ibm-wkc"

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in

    ibm-wkc)
        echo "IBM WKC"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# Installs the catalog source and operator group
install_catalog() {

	validate_install_catalog


        # install all catalogs of subcases first
        if [[ ${recursive_action} -eq 1 ]]; then
	        install_dependent_catalogs
        fi

        # Verify expected yaml files for install exit
        [[ ! -f "${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml ]] && { err_exit "Missing required catalog source yaml, exiting deployment."; }

	echo "-------------Create catalog source-------------"

	local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

	validate_file_exists "${catsrc_file}"

	# Apply yaml files manipulate variable input as required

	local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

	# replace original registry with local registry
	local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
	if echo "${registry}" | grep -qE "quay.io|docker.io"; then
		catsrc_image_mod="${catsrc_image_orig}"
	fi

	# apply catalog source
	sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat

	echo "check for any existing operator group in ${namespace} ..."
	if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}' ) -gt 0 ]]; then
              echo "found operator group"
	      $kubernetesCLI get og -n "$namespace" -o yaml
	      return
	fi      

	echo "no existing operator group found"

}


# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs()  {

    local dep_case=""

       for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
               --case "${dep_case}" \
               --namespace "${namespace}" \
               --inventory "${inventory}" \
               --action install-catalog \
               --args "${registry:+--registry $registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
               --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
           err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
      done

      # Remove operator groups - these will be created via UI
        for og in $og_dependencies; do
            oc -n "${namespace}" delete operatorgroup $og --ignore-not-found=true
        done
}
