# ![Logos](https://github.com/IBMSpectrumComputing/lsf-hybrid-cloud/blob/master/Spectrum_icon-small.png?raw=true) IBM Cloud Pak for Data Scheduling

# Introduction

IBM CloudPak for Scheduling provides several enhancements over the default Kubernetes scheduler.

# Details

## Quota enforcement

Refresh 2 or later This feature enables you to programmatically enforce the quotas that you set for Cloud Pak for Data or for various Cloud Pak for Data services. For details on quota enforcement, see Managing the platform in the Cloud Pak for data Documentation.

## Co-scheduling of pods

This feature is provided for the Watson Machine Learning Accelerator service.

Parallel and AI workloads can co-schedule pods to
- Guarantee that all pods can start
- Remove resource deadlock
- Enable workloads to grow and shrink
- Support reclaiming pods in the event of resource contention

## GPU sharing

This feature is provided for the Watson Machine Learning Accelerator service.

The scheduling service allows competing groups to share GPUs, which improves GPU utilization. Sharing policies govern how to resolve resource contention.

# Prerequisites

- Openshift Container Platform 4.6 or higher
- 10 GB of PV storage. NFS, Portworx and OCS are supported.
- About 8GB or memory and about 2.5 CPUs.

## SecurityContextConstraints Requirements

All pods run with the restricted SCC.

## Resources Required

Minimum Resource Requirements for CloudPak for Data Scheduling

| Pod       | Memory (GB) | CPU (cores) | Image Size (MB) |
| --------- | ----------- | ----------- | --------------- |
| Scheduler |  4          |  1          | 500             |
| Agent     |  0.75       |  200m       | 250             |
| Validating Webhook |  1 |  200m       | 300             |
| Mutating Webhook |  1   |  200m       | 300             |
| Operator  |  1          |  500m       | 700             |

### Supported Platforms

IBM Cloud Pak for Data Scheduling is an optional component of IBM Cloud Pak for Data.  It supports the same architectures and storage classes as IBM Cloud Pak for Data.  It supports POWER and x86_64 architectures.  It supports running on OpenShift 4.6 and above.

# Installing

This section provides brief instructions for online installation using the IBM `cloudctl` CLI. For detailed instructions refer to the IBM Knowledge Centre.

- The product images are available from IBM's entitled registry.  Configure registry authenrication prior to installation.
- For offline (air-gapped) installation, refer to the IBM Knowledge Centre.

To install the scheduling service, complete the following tasks in order:
1. Plan your installation
2. Install the scheduling service

## Plan your installation
- Determine which namespace will be used for the installation.  The scheduling service should be installed in to either the IBM Foundational Services (bedrock) namespace, or the CloudPak for Data Operators namespace.  Since the scheduling service is a cluster-wide service, it cannot be installed into a CloudPak for data Control Plan Namespace.  In this README, the namespace `ibm-common-services` will be used as an example.
- Determine the storage class that will be used for the PVC.  NFS, Portworx and OCS are supported.  The storage class `managed-nfs-storage` will be used as an example.
- Download the case tarball.

## Install the scheduling service

1. Log in to your Red Hat OpenShift cluster an an administrator.
2. Set, or create, the namespace that the service will be installed into.  Note that the scheduling service should be installed into either the IBM Fondational Services (bedrock) namespace or the CloudPak for Data Operators namespace.  Since the scheduling service is a cluster-wide service, it cannot be installed into a CloudPak for data Control Plan Namespace.

```
oc project ibm-common-services
```

3. Extract the case into an installation directory fo your choice.

```
mkdir scheduler-install
cd scheduler-install
tar zxf <path to case>/ibm-cpd-scheduling-1.2.*.tgz
```

4. Install the scheduling service operator
```
oc project ibm-common-services
cloudctl case launch --case ibm-cpd-scheduling \
                     --namespace ibm-common-services \
                     --action installOperatorNative \
                     --inventory schedulerSetup
```

5. Create an instance of the scheduling service.

**Note**: Remember that there can only be once instance of the scheduling service in the entire cluster.

```
oc project ibm-common-services
cloudctl case launch --case ibm-cpd-scheduling \
                     --namespace ibm-common-services \
                     --inventory schedulerSetup \
                     --action applyCustomResources \
                     --args "--storageClass managed-nfs-storage"
```

6. Monitor the CR status

The CR status indicated when the installation has completed.  During installation the operator status will look like this

```
$ oc get -ojson scheduling  | jq '.items[0].status'
{
  "conditions": [
    {
      "lastTransitionTime": "2021-05-27T01:49:08Z",
      "message": "Running reconciliation",
      "reason": "Running",
      "status": "True",
      "type": "Running"
    }
  ]
}
```

when the install has finished, the operator status will look like this.

```
$ oc get -ojson scheduling  | jq '.items[0].status'
{
  "conditions": [
    {
      "ansibleResult": {
        "changed": 10,
        "completion": "2021-05-27T01:55:25.126707",
        "failures": 0,
        "ok": 81,
        "skipped": 15
      },
      "lastTransitionTime": "2021-05-27T01:49:08Z",
      "message": "Awaiting next reconciliation",
      "reason": "Successful",
      "status": "True",
      "type": "Running"
    }
  ],
  "cpd-schedulingStatus": "Completed",
  "type": "Ready"
}
```

## Configuration

Configurable parameters are exposed through the following config maps.

- ibm-cpd-scheduler-conf
- ibm-cpd-scheduler-mwebhook-cm
- ibm-cpd-scheduler-paralleljobs
- ibm-cpd-scheduler-params
- ibm-cpd-scheduler-queues

Refer to the IBM Knowledge Centre for full documentation.

## Storage

The Scheduling service requires a PV to store recovery information.  NFS, Portworx and OCS are supported.  10GB of space is recommended.

## Limitations

Since the scheduling service is a cluster-wide service, it cannot be installed into a CloudPak for data Control Plan Namespace.

## Documentation

Full documentation can be found in the IBM Knowledge Centre.

## PodSecurityPolicy Requirements
The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run
 with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC
and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```


## Copyright and trademark information
© Copyright IBM Corporation 2020
U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. IBM®, the IBM logo and ibm.com® are trademarks of International Business Machines Corp., registered in many jurisdictions worldwide. Other product and service names might be trademarks of IBM or other companies. A current list of IBM trademarks is available on the Web at "Copyright and trademark information" at [www.ibm.com/legal/copytrade.shtml](https://www.ibm.com/legal/copytrade.shtml).


