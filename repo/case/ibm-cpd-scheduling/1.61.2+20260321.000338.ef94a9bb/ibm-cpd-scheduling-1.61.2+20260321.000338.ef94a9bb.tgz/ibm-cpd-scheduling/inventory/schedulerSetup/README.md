# IBM Cloud Pak for Data Scheduling Operator Setup
This README provides instruction on how to install the Scheduling Operator through Operator Lifecycle Manager (OLM) of via command line (CLI) application of kubernetes manifests in both an online and offline airgap environment.

## Prerequisites
Cluster Administrator rights

## OLM Configuration
Search for "IBM Scheduling" in the Operator Catalog.  Install the Scheduling operator.
Once the operator is ready install the Scheduling cluster in the same namespace.


## Manuel Configuration
The following steps need to be performed manually:
1. Create a namespace
2. Create the CRD:
```
kubectl create -f crds/scheduling.spectrumcomputing.ibm.com_scheduler_crd.yaml
```
4. Create a service account with the needed RBAC policies
```
kubectl create -f service_account.yaml
kubectl create -f role.yaml
kubectl create -f role_binding.yaml
```
5. Modify the clusterrolebinding and set the namespace to the correct value in the **clusterrolebinding1.yaml** files.
6. Create the clusterrole and clusterrolebindings:
```
kubectl create -f clusterrole.yaml
kubectl create -f clusterrolebinding1.yaml
```
7. Deploy the operator
```
kubectl create -f operator.yaml
```


## Removal
To remove this configuration run:
```
kubectl delete -f clusterrolebinding1.yaml
kubectl delete -f clusterrole.yaml
kubectl delete -f role_binding.yaml
kubectl delete -f role.yaml
kubectl delete -f service_account.yaml
kubectl delete -f crds/scheduling.spectrumcomputing.ibm.com_scheduler_crd.yaml
```
