# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName="ibm-cpd-scheduling"
inventory="schedulerSetup"
caseCatalogName="ibm-cpd-scheduling-catalog"
channelName="v1.3"
cr_storage_class="managed-nfs-storage"

# Operator image
IMGOPER=ibm-cpd-scheduling-operator

# implement functions to install or uninstall products
# example

# Is this a new install or an upgrade
IS_UPGRADE=false

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --storageClass)
        cr_storage_class="$val"
        ;;
    --bar)
        echo "do something"
        ;;
    esac
}

# ---------------------  Functions for the Operator ------------

initial_sanity_check() {
	INSTNS="`oc get scheduling --all-namespaces 2> /dev/null | grep -v NAMESPACE | awk '{ print $1 }'`"
	if [ "`oc get scheduling --all-namespaces 2> /dev/null | grep -v NAMESPACE | wc -l`" -eq 0 ]; then
		echo "+ Scheduler not detected, proceeding with a new install"
		IS_UPGRADE=false
		return
	elif [ "${INSTNS}" != "${namespace}" ]; then
		echo "+ The scheduler is already installed in namespace ${INSTNS}. The scheduler is a cluster wide service and should only be installed once."
		exit 99
	elif [ "`oc get scheduling --all-namespaces 2> /dev/null | grep -v NAMESPACE | wc -l`" -eq 1 ]; then
		MAJOR=`oc get -ojson scheduling | jq '.items[0].spec.version' | tr -d '"' | awk -F\. '{print $1}'`
		MINOR=`oc get -ojson scheduling | jq '.items[0].spec.version' | tr -d '"' | awk -F\. '{print $2}'`
		if [ "$MAJOR" -eq 1 -a "$MINOR" -eq 1 ]; then
			echo "+ Detected install of scheduler 1.1"
			IS_UPGRADE=true
		else
			echo "+ Detected install of scheduler ${MAJOR}.${MINOR}.  Upgrade from this version is not supported."
			exit 99
		fi
	else
		echo "+ Multiple schedulers CRs are running. There should be only one instance of the Scheduler CR. Contact Support."
		exit 99
	fi
}

remove_old_resources() {
    # Detect and remove old scc
    OBJ=scc
    RV=$(oc get ${OBJ} -o name |grep 'ibm-cpd-scheduler' |awk -F'/' '{ print $2 }')
    for i in ${RV} ; do
        echo "* Deleting object ${OBJ}  named: $i"
        oc delete ${OBJ} $i 2> /dev/null || true
    done
    oc get clusterrolebinding 2> /dev/null | grep 'scc:ibm-cpd-scheduler' | awk '{print $1}' | while read a; do oc delete clusterrolebinding $a; done
    oc get clusterroles 2> /dev/null | grep 'scc:ibm-cpd-scheduler' | awk '{print $1}' | while read a; do oc delete clusterroles $a; done
    oc get imagestream 2> /dev/null | grep ibm-cpd-scheduler | awk '{print $1}' | while read a; do oc delete imagestream $a; done
}

create_scheduler_crb() {
    # create system:kube-scheduler rolebindings 
    echo "add cluster role system:kube-scheduler to the operator service account"
    oc get clusterrolebindings ibm-cpd-scheduling-operator-kube-sched-crb-${namespace} >/dev/null 2>&1 
    if [ $? -ne 0 ]; then 
        echo "Running: oc adm policy add-cluster-role-to-user system:kube-scheduler system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator --rolebinding-name=ibm-cpd-scheduling-operator-kube-sched-crb-${namespace}" 
        oc adm policy add-cluster-role-to-user system:kube-scheduler system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator --rolebinding-name=ibm-cpd-scheduling-operator-kube-sched-crb-${namespace}
        oc label clusterrolebinding ibm-cpd-scheduling-operator-kube-sched-crb-${namespace} velero.io/exclude-from-backup=true --overwrite
    fi
}

remove_scheduler_crb(){
    echo "remove cluster role system:kube-scheduler from the operator service account"
    oc get clusterrolebindings ibm-cpd-scheduling-operator-kube-sched-crb-${namespace} >/dev/null 2>&1 
    if [ $? -eq 0 ]; then 
        echo "Running: oc adm policy remove-cluster-role-from-user system:kube-scheduler system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator --rolebinding-name=ibm-cpd-scheduling-operator-kube-sched-crb-${namespace}" 
        oc adm policy remove-cluster-role-from-user system:kube-scheduler system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator --rolebinding-name=ibm-cpd-scheduling-operator-kube-sched-crb-${namespace} 
    fi
}

# ----- INSTALL ACTIONS -----
install() {
	initial_sanity_check
    install_operator
}

install_operator_native() {

    echo "Applying scheduling.scheduler.spectrumcomputing.ibm.com CRD"
    oc apply -f ${scriptDir}/op-cli/crds/scheduling.spectrumcomputing.ibm.com_scheduler_crd.yaml
    echo "Applying Service Account: ibm-cpd-scheduling-operator"
    oc apply -f ${scriptDir}/op-cli/service_account.yaml  --namespace=${namespace}
    echo "Applying role for Service Account: ibm-cpd-scheduling-operator"
    oc apply -f ${scriptDir}/op-cli/role.yaml --namespace=${namespace}
    echo "Applying rolebinding for Service Account: ibm-cpd-scheduling-operator"
    oc apply -f ${scriptDir}/op-cli/role_binding.yaml --namespace=${namespace}
    echo "Applying clusterrole for Service Account: ibm-cpd-scheduling-operator"
    oc apply -f ${scriptDir}/op-cli/clusterrole.yaml

    echo "Applying clusterrolebinding for ibm-cpd-scheduling-operator"
    oc adm policy add-cluster-role-to-user ibm-cpd-scheduling-operator system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator --rolebinding-name=ibm-cpd-scheduling-operator-ibm-sched-crb
    oc label clusterrolebinding ibm-cpd-scheduling-operator-ibm-sched-crb velero.io/exclude-from-backup=true --overwrite
    create_scheduler_crb

    #oc label rolebinding <RoleBindingName> velero.io/exclude-from-backup=true --overwrite

    echo "Applying Operator"
    oc apply -f ${scriptDir}/op-cli/operator.yaml  --namespace=${namespace}
    echo "Remove old resources"
    remove_old_resources
}


install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    err_exit "There is no operator group in the target namespace '${namespace}'."
    # echo "no existing operator group found"

    # echo "------------- Installing operator group for $namespace -------------"

    # local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    # validate_file_exists "${opgrp_file}"

    # sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    # echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    sed -i "s|REPLACE_NAMESPACE|${namespace}|g" "${catsrc_file}"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply     
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${namespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${namespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    
    #create_scheduler_crb
}


# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/scheduling.spectrumcomputing.ibm.com_v1_scheduler_cr.yaml

    validate_file_exists "$cr"

    sed -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}


# ----- UNINSTALL ACTIONS -----

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}-subscription" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    echo "Deleting the subscription ${caseCatalogName}-subscription"
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    echo "Deleting the clusterserviceversion ${csvName}"
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/crds/*_crd.yaml; do
        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    done
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Uninstalling native -------------"
    
    local haveSched=$(oc get scheduling --all-namespaces 2>/dev/null |grep -v NAMESPACE |wc -l )
    if [ $haveSched -ge 1 ]; then
        echo ""
        echo "---------------------------------------------------------"
        echo "Notice:  An instance of the Scheduler has been detected.  "
        echo "Please remove the instance before uninstalling."
        echo "---------------------------------------------------------"
        exit 99
    fi
    echo "Removing the clusterrolebindings."
    remove_scheduler_crb
    echo "Running: oc adm policy remove-cluster-role-from-user ibm-cpd-scheduling-operator system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator"
    oc adm policy remove-cluster-role-from-user ibm-cpd-scheduling-operator system:serviceaccount:${namespace}:ibm-cpd-scheduling-operator --rolebinding-name=ibm-cpd-scheduling-operator-ibm-sched-crb 2> /dev/null || true
    echo "Deleting clusterrole for Service Account: ibm-cpd-scheduling-operator"
    oc delete -f ${scriptDir}/op-cli/clusterrole.yaml 2> /dev/null || true
    echo "Deleting Operator"
    oc delete -f ${scriptDir}/op-cli/operator.yaml --namespace=${namespace} 2> /dev/null || true
    echo "Deleting rolebinding for Service Account: ibm-cpd-scheduling-operator"
    oc delete -f ${scriptDir}/op-cli/role_binding.yaml --namespace=${namespace} 2> /dev/null || true
    echo "Deleting role for Service Account: ibm-cpd-scheduling-operator"
    oc delete -f ${scriptDir}/op-cli/role.yaml --namespace=${namespace} 2> /dev/null || true
    echo "Deleting Service Account: ibm-cpd-scheduling-operator"
    oc delete -f ${scriptDir}/op-cli/service_account.yaml --namespace=${namespace} 2> /dev/null || true
    echo "Create/Update scheduling.scheduler.spectrumcomputing.ibm.com CRD"
    oc delete -f ${scriptDir}/op-cli/crds/scheduling.spectrumcomputing.ibm.com_scheduler_crd.yaml 2> /dev/null || true
    echo "Remove old resources"
    remove_old_resources
}



delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/scheduling.spectrumcomputing.ibm.com_v1_scheduler_cr.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
    oc delete clusterrolebindings ibm-cpd-scheduler-crb
    oc delete clusterrolebindings ibm-cpd-scheduler-kube-sched-crb
    oc delete clusterrolebindings ibm-cpd-scheduler-mutate-webhook-crb
    oc delete clusterrolebindings ibm-cpd-scheduler-webhook-crb
    oc delete clusterrole ibm-cpd-scheduler-cr
    oc delete clusterrole ibm-cpd-scheduler-mutate-webhook-cr
    oc delete clusterrole ibm-cpd-scheduler-webhook-cr
    oc delete crds paralleljobs.ibm.com 
    oc delete crds resourceplans.ibm.com
    oc delete crds resourcematches.ibm.com
}


uninstall() {
    uninstall_operator
}
