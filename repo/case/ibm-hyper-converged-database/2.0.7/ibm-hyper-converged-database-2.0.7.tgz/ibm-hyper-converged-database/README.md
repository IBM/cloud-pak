# IBM DataStax Hyper-Converged Database CPE CASE

Cloud Pak Extension (CPE) CASE package for publishing IBM DataStax Hyper-Converged Database container images to production registry.

## Purpose

This CASE package is used exclusively for image publication through the CPE delivery pipeline. It does **not** include Helm charts or deployment manifests.

## Key Differences from SWH CASE

- **Image-only**: No Helm charts included
- **Production coordinates**: Uses `cp.icr.io/cp/ibm-hyper-converged-database/*` registry

## Images

| Image | Tag |
|-------|-----|
| `cp.icr.io/cp/ibm-hyper-converged-database/hcd` | `<version>-ubi` |
| `cp.icr.io/cp/ibm-hyper-converged-database/hcd` | `<version>-jdk17-ubi` (HCD 2.0.x only) |
