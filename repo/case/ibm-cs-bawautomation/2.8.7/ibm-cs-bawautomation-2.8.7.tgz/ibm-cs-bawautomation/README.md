# Name

IBM&reg; Cloud Pak for Automation

# Introduction

## Summary
Cloud Pak for Automation delivers a robust, end-to-end solution for business automation needs within the clients' enterprise. In the current competitive marketplace, digital companies use software automation to achieve higher revenue per employee than their traditional counterparts. Automation can maximize revenue per employee by reinventing the client experience while reducing costs.
Cloud Pak for Automation platform delivers an integrated and managed collection of containerized or virtualized Automation Platform for Digital Business services thatenable rapid deployment and reduce operational costs. Cloud Pak for Automation also digitizes all aspects of business operations and can extend the workforce with digital labor to enable businesses to scale.

## Features

* IBM&reg; FileNet Content Manager

  IBM FileNet Content Manager provides enterprise content management to enable secure access, collaboration support, content synchronization and sharing, and mobile  support to engage users over all channels and devices. IBM® FileNet® Content Manager consists of Content Process Engine (CPE), Content Search Service (CSS), Content  Management Interoperability Services (CMIS), Content Navigator Task Manager  and Content Services GraphQL (CGQL).

* IBM&reg; Business Automation Navigator
  
  IBM Business Automation Navigator provides a console to enable teams to view their documents, folders, and searches in ways that help them to complete their tasks.

* IBM&reg; Operational Decision Manager
 
  IBM® Operational Decision Manager automates policies and decisions by managing thousands of business rules and enabling rapid business change.

* IBM&reg; Business Automation Insights
 
  IBM Business Automation Insights a platform-level component, provides visualization and insights to knowledge workers and business owners. Business Automation Insig  hts provides dashboarding and data science capabilities from the events and business data collected from Cloud Pak for Automation services.

* IBM&reg; Business Automation Content Analyzer

  IBM Business Automation Content Analyzer offers the power of intelligent capture with the flexibility of an API that enables you to extend the value of your core en  terprise content management (ECM) technology stack and helps you rapidly accelerate extraction and classification of data in your documents

* IBM&reg; Business Automation Studio

  IBM Business Automation Studio environment for providing a single place where people go to author business services, applications and digital workers.

* IBM&reg; Business Automation Application Engine

  IBM Business Automation Application Engine (App Engine), a user interface service tier to run applications that are built by IBM Business Automation Application Designer (App Designer).
  
* IBM&reg; Automation Workstream Services

  IBM Automation Workstream Services operator deploys the workflow server, a server engine that runs process applications which are built by Rapid Workflow Designer.

* IBM&reg; Automation Digital Worker

  IBM Automation Digital Worker provides a solution to build, manage, and control the automation that supports your digital workforce. With Digital Worker, you infuse artificial intelligence in your operations and leverage third-party capabilities through predefined intelligent skills, in a transparent and governed environment.

* IBM&reg; User Management Service

  User Management Service provides users of multiple IBM Cloud Pak for Automation components with a single sign-on experience.

IBM Cloud Pak for Automation provides the means to acquire and apply key software from across the Digital Business Automation portfolio to digitize and automate all aspects of your business operations. IBM Cloud Paks deliver a hybrid cloud platform that enables businesses to use a mix of on-premises, public, and privately-operated cloud environments for your data and applications. See https://www.ibm.com/support/knowledgecenter/en/SSYHZ8_20.0.x/welcome/kc_welcome_dba_distrib.html for more information.

# CASE Details

## Prerequisites

- Redhat Openshift Container Platform version 3.11 (or) 4.2
- NFS Server for static Persistent Volumes.
- Download scc-fncm.yaml, service_account.yaml, role.yaml, role_binding.yaml, operator.yaml from certified kubernetes github
- Download required custom resource definition (CRD) and custom resource (CR) files icp4a_v1_icp4a_crd.yaml, icp4a_v1_icp4a_cr_template.yaml
- Modify custom resource definition file in case you want to change default ICP4A custom resource.
- Modify custom resource file to enable which component you want to deploy.
- Create Docker registry secret and provide the secret name in Custom Resource file.
- Create a secret with LDAP password , database user password and provide the secret name in corresponding section of Custom Resource file.
- Cloud Pak for Automation Operator requires 1 persistent volume before deployment.
- The following table describes the storage required for Cloud Pak for Automation.
  - Cloud Pak for Automation Operator
    - Follow [link]( https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/topics/tsk_preparing_bacc.html) for installation instructions.

      | Persistent Volumes            | Persistent Volume Claims        | Description                     |
      | ---------------------------   | ------------------------------- |  ---------------------------------------------     |
      | `operator-shared-pv`         | `operator-shared-pvc`          | `Database drivers required to deploy Cloud Pak for Automation deployment` |

    * Use the below resource to create necessary PersistentVolume and PersistentVolumeClaim or it can be created by using the IBM® Cloud Private console:

      ```
      apiVersion: v1
      kind: PersistentVolume
      metadata:
        name: operator-shared-pv
      spec:
        accessModes:
        - ReadWriteMany
        capacity:
          storage: 1Gi
      nfs:
        path: /operator/
        server: <NFS Server>
      persistentVolumeReclaimPolicy: Retain
      storageClassName: operator-shared-pv
      ---
      apiVersion: v1
      kind: PersistentVolumeClaim
      metadata:
        name: operator-shared-pvc
        namespace: <NAMESPACE>
      spec:
        accessModes:
        - ReadWriteMany
        resources:
          requests:
            storage: 1Gi
        storageClassName: operator-shared-pv
        volumeName: operator-shared-pv
      status:
        accessModes:
        - ReadWriteMany
        capacity:
          storage: 1Gi
      ```
   * On the NFS server create the corresponding folders for the persistentvolumes.
        `
        mkdir -p /operator
        `
   * Copy the jdbc driver to remote persistent voluem
  - IBM® FileNet® Content Manager
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/topics/tsk_prepare_ecm.html) for details about this product.

    * IBM® Content Platform Engine

      | Persistent Volumes            | Persistent Volume Claims        | Description                                        |
      | ---------------------------   | ------------------------------- |  ---------------------------------------------     |
      | `cpe-cfgstore-pv`         | `cpe-cfgstore-pvc`          | `Configuration files for Liberty`                  |
      | `cpe-logstore-pv`         | `cpe-logstore-pvc`          | `Content Platform Engine & Liberty logs`           |
      | `cpe-filestore-pv`        | `cpe-filestore-pvc`         | `Content storage volume for advanced storage area` |
      | `cpe-icmrulesstore-pv`    | `cpe-icmrulesstore-pvc`     | `Rules for IBM Case Manager`                                    |
      | `cpe-textextstore-pv`     | `cpe-textextstore-pvc`      | `Text extraction volume used by CSS`               |
      | `cpe-bootstrapstore-pv`   | `cpe-bootstrapstore-pvc`    | `Content Platform Engine bootstrap file location`  |
      | `cpe-fnlogstore-pv`       | `cpe-fnlogstore-pvc`        | `FileNet Log directory`                            |

    * IBM® Content Search Services

      | Persistent Volume             | Persistent Volume Claims      | Description                                          |
      | ---------------------------   | ----------------------------- | ---------------------------------------------        |
      | `css-cfgstore-pv`         | `css-cfgstore-pvc`        | `Configuration files for CSS`                        |
      | `css-logstore-pv`         | `css-logstore-pvc`        | `Data persistence for CSS log files`                 |
      | `css-tempstore-pv`        | `css-tempstore-pvc`       | `Data persistence for CSS temp files`                |
      | `css-indexstore-pv`       | `css-indexstore-pvc`      | `Data persistence for content index data`            |
      | `css-customstore-pv`       | `css-customstore`        | `Configuration for custom data`                      |
    * IBM® Content Management Interoperability Services

      | Persistent Volumes            | Persistent Volume Claim       | Description                                                 |
      | ---------------------------   | ----------------------------- | ------------------------------------                        |
      | `cmis-cfgstore-pv`        | `cmis-cfgstore-pvc`       | `Configuration files for Liberty`                           |
      | `cmis-logstore-pv`        | `cmis-logstore-pvc`       | `Content Management Interoperability Services Liberty logs` |

    * IBM® Content Rest Services GraphQL

      | Persistent Volumes            | Persistent Volume Claim       | Description                                                 |
      | ---------------------------   | ----------------------------- | ------------------------------------                        |
      | `cql-cfgstore-pv`        | `cql-cfgstore-pvc`       | `Configuration files for Liberty`                           |
      | `cql-logstore-pv`        | `cql-logstore-pvc`       | `Content Rest Services Liberty logs` |

    * IBM® Content Navigator Task Manager

      | Persistent Volumes            | Persistent Volume Claim       | Description                                                 |
      | ---------------------------   | ----------------------------- | ------------------------------------                        |
      | `tm-cfgstore-pv`        | `tm-cfgstore-pvc`       | `Configuration files for Liberty`                           |
      | `tm-logstore-pv`        | `tm-logstore-pvc`       | `Task Manager Liberty logs` |
      | `tm-pluginstore-pv`     | `tm-pluginstore-pvc`    | `Task Manager Plugin Store` |

  - IBM® Business Automation Navigator
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/topics/tsk_prepare_ban.html) for details about this product.

      | Persistent Volume             | Persistent Volume Claim       | Description                                                      |
      | ---------------------------   | ----------------------------- | ---------------------------------------------                    |
      | `icn-cfgstore-pv`         | `icn-cfgstore-pvc`        | `Configuration files for Liberty`                                |
      | `icn-logstore-pv`         | `icn-logstore-pvc`        | `Navigator and Liberty logs`                                     |
      | `icn-pluginstore-pv`      | `icn-pluginstore-pvc`     | `Custom plugins for Navigator`                                   |
      | `icn-vw-cachestore-pv`    | `icn-vw-cachestore-pvc`   | `Daeja VieweONE logs`                                            |
      | `icn-vw-logstore-pv`      | `icn-vw-logstore-pvc`     | `Daeja VieweONE cache`                                           |
      | `icn-asperastore-pv`      | `icn-asperastore-pvc`     | `Aspera upload (It's optional for user who wants to use Aspera)` |

  - IBM® Operational Decision Manager
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/topics/tsk_preparing_odm.html) for details about this product.

  - IBM® Business Automation Insights
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/topics/tsk_preparing_bai.html) for details about this product.

      | Persistent Volume    | Persistent Volume Claim     | Description                 |
      | -------------------- | --------------------------- | --------------              |
      | `ibm-bai-pv`         | `ibm-bai-pvc`               | `BAI Flink Storage`         |
      | `ibm-bai-ek-pv-1e`   | `ibm-bai-ek-pvc-1`          | `BAI Elasticsearch Storage` |

  - IBM® Business Automation Studio
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/k8s_topics/tsk_prepare_bas.html) for details about this product.
    
  - IBM® Business Automation Application Engine
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/k8s_topics/tsk_prepare_ae.html) for details about this product.

  - IBM® Business Automation Content Analyzer
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/tsk_prepare_bacak8s.html) for details about this product.
    
      | Persistent Volume    | Persistent Volume Claim     | Description                 |
      | -------------------- | --------------------------- | --------------                      |
      | `ibm-ca-config-pv`             | `ibm-ca-config-pvc`              | `Configuration PVC for Content Analyzer.The recommended minimum size is 50GB`                                                                                       |
      | `ibm-ca-data-pv`               | `ibm-ca-data-pvc`                | `Data PVC for Content Analyzer.  The recommended minimum size is 60GB.  300GB if shared with Mongo data`                                                            |
      | `ibm-ca-log-pv`                | `ibm-ca-log-pvc`                 | `Log PVC for Content Analyzer. The recommended minimum size is 35GB`                                                                                                |
      | `ibm-ca-mongo-configdb-pv`     | `ibm-ca-mongo-configdb-pvc`      | `Optionaly, you can create the Mongo ConfigDB pv to store its data.  Otherwise, you can share with the ibm-ca-data-pvc. The recommended minimum size is 60GB`       |
      | `ibm-ca-mongo-shard-pv`        | `ibm-ca-mongo-shard-pvc`         | `Optionaly, you can create the Mongo ShardDB pv to store its data.  Otherwise, you can share with the ibm-ca-data-pvc.  The recommended minimum size is 60GB`       |
      | `ibm-ca-mongoadmin-configdb-pv`| `ibm-ca-mongoadmin-configdb-pvc` | `Optionaly, you can create the Mongo Admin ConfigDB pv to store its data.  Otherwise, you can share with the ibm-ca-data-pvc.  The recommended minimum size is 60GB`|
      | `ibm-ca-mongoadmin-shard-pv`   | `ibm-ca-mongoadmin-shard-pvc`    | `Optionaly, you can create the Mongo Admin shardDB pv to store its data.  Otherwise, you can share with the ibm-ca-data-pvc. The recommended minimum size is 60GB`  |
       
  - IBM® Automation Workstream Services
    * Follow [link](https://github.com/bpm/nitro-server-document/blob/master/v20.0.1/IAWS-on-OpenShift-Operator-v20.0.1.md) for details about this product.

# PodSecurityPolicy Requirements

# SecurityContextConstraints Requirements

### Red Hat OpenShift SecurityContextConstraints Requirements
This Operator requires a SecurityContextConstraints to be bound to the target namespace prior to installation. This Operator is namespace scoped so it can deploy into any target namespace and furthermore you can deploy the Operator multiple times using difference namespaces.

  - IBM® FileNet® Content Manager
```
    * Apply the SecurityContextConstraints for the namespace by using the downloaded file.

       oc apply -f scc-fncm.yaml
```
  - IBM® Business Automation Insights
```
    * Requires a custom PodSecurityPolicy definition that sets up the proper PodSecurityPolicy, Role, ServiceAccount, and RoleBinding Kubernetes resources. Such custom definition is requiredto meet the mandatory settings for production mode.

1. Adapt the following YAML to reference your Kubernetes namespace and IBM Business Automation Insights custom resource name, and save it to a file named bai-psp.yml.
This file sets up the custom PodSecurityPolicy definition.
```
```
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  annotations:
    kubernetes.io/description: "This policy is required to allow ibm-dba-ek pods running Elasticsearch to use privileged containers."
  name: <cr_name>-bai-psp
spec:
  privileged: true
  runAsUser:
    rule: RunAsAny
  seLinux:
    rule: RunAsAny
  supplementalGroups:
    rule: RunAsAny
  fsGroup:
    rule: RunAsAny
  volumes:
  - '*'
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: <cr_name>-bai-role
  namespace: <bai-namespace>
rules:
- apiGroups:
  - extensions
  resourceNames:
  - <cr_name>-bai-psp
  resources:
  - podsecuritypolicies
  verbs:
  - use
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: <cr_name>-bai-psp-sa  
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: <cr_name>-bai-rolebinding
  namespace: <NAMESPACE>
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: <cr_name>-bai-role
subjects:
- kind: ServiceAccount
  name: <cr_name>-bai-psp-sa
  namespace: <bai-namespace>
```
2. Run the create command
```
kubectl create -f bai-psp.yaml -n <bai-namespace>
```

This command allows the pods to run the sysctl commands that are needed at initialization, more specifically to adjust the virtual memory and swappiness settings for embedded Elasticsearch. For more information, see https://www.elastic.co/guide/en/elasticsearch/reference/6.7/vm-max-map-count.html and https://www.elastic.co/guide/en/elasticsearch/reference/6.7/setup-configuration-memory.html#swappiness

  - IBM® Automation Workstream Services
  
```
Create a SecurityContextConstraint for Automation Workstream Services that looks like the following content and save it to the ibm-dba-iaws-scc.yaml file. Then add this ibm-dba-iaws-scc SCC  to all service accounts in a namespace:
```
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: ibm-dba-iaws-scc
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: []
defaultAddCapabilities: []
fsGroup:
  type: RunAsAny
groups:
- system:authenticated
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
priority: 1
```

Run the following commands:

```
$ oc apply -f ibm-dba-iaws-scc.yaml
$ oc adm policy add-scc-to-group ibm-dba-iaws-scc system:serviceaccounts:<NAMESPACE_NAME>
```

  - Creating a SecurityContextConstraint for Process Federation Server
  * If pfs_configuration.elasticsearch.privileged is set to true, you must create a SecurityContextConstraint for Process Federation Server that looks like the following content and save it to the ibm-pfs-privileged-scc.yaml file. Then add this ibm-pfs-privileged-scc SCC to the ibm-pfs-es-service-account Process Federation Server Elasticsearch default service account in the current namespace:

```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: ibm-pfs-privileged-scc
allowHostDirVolumePlugin: true
allowHostIPC: true
allowHostNetwork: true
allowHostPID: true
allowHostPorts: true
allowPrivilegedContainer: true
allowPrivilegeEscalation: true
allowedCapabilities:
- '*'
allowedFlexVolumes: []
allowedUnsafeSysctls:
- '*'
defaultAddCapabilities: []
defaultAllowPrivilegeEscalation: true
forbiddenSysctls: []
fsGroup:
  type: RunAsAny
readOnlyRootFilesystem: false
requiredDropCapabilities: []
runAsUser:
  type: RunAsAny
seccompProfiles:
- '*'
seLinuxContext:
  type: RunAsAny
supplementalGroups:
  type: RunAsAny
volumes:
- '*'
priority: 2
```

3. For Red Hat OpenShift, add SecurityContextConstraints (SCC) requirements.
If you are installing the chart on Red Hat OpenShift or OKD, the privileged SecurityContextConstraint resource is required for the installation. For more information, see IBM Cloud Pak SecurityContextConstraints Definitions.

4. For RedHat OpenShift, if applicable, add policies to enable the Pod resources to start the containers by using the required UIDs.
To ensure that these containers can start use the oc command to add the service accounts to the required privileged SCC, add these policies.

```
oc adm policy add-scc-to-user privileged -z <cr_name>-bai-psp-sa
oc adm policy add-scc-to-user privileged -z default
```

### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| CP4A      |  32 GB      |    8        |   500     |  5    |


# Download required container images.
- You can access the container images in the IBM Entitled registry with your IBMid (Option 1), or you can use the downloaded archives from IBM Passport Advantage (PPA) (Option 2).

        * Option 1: Create a pull secret for the IBM Cloud Entitled Registry
          - Log in to [MyIBM Container Software Library](https://myibm.ibm.com/products-services/containerlibrary) with the IBMid and password that are associated with the entitled software.
          - In the **Container software library** tile, click **View library** and then click **Copy key** to copy the entitlement key to the clipboard.
          - Create a pull secret by running a `kubectl create secret` command.
             ```bash
             $ kubectl create secret docker-registry <my_pull_secret> --docker-server=cp.icr.io --docker-username=iamapikey --docker-password="<API_KEY_GENERATED>" --docker-email=user@foo.com
             ```
             > **Note**: The `cp.icr.io` value for the **docker-server** parameter is the only registry domain name that contains the images.
          - Take a note of the secret and the server values so that you can set them to the **pullSecrets** and **repository** parameters when you run the operator for your containers.

        * Option 2: Download the packages from PPA and load the images
          [IBM Passport Advantage (PPA)](https://www-01.ibm.com/software/passportadvantage/pao_customer.html) provides archives (.tgz) for the software. To view the list of Passport Advantage eAssembly installation images, refer to the [20.0.1 download document](https://www.ibm.com/support/pages/ibm-cloud-pak-automation-v2001-download-document)
          - Download one or more PPA packages to a server that is connected to your container registry.
          - Download the [`loadimages.sh`](../../scripts/loadimages.sh) script from GitHub.
          - Run the `loadimages.sh` script to load the images into your Docker registry. Specify the two mandatory parameters in the command line.
          ```
          -p  PPA archive files location or archive filename
          -r  Target Docker registry and namespace
          -l  Optional: Target a local registry
          ```

          The following example shows the input values in the command line.

          ```
          # scripts/loadimages.sh -p <PPA-ARCHIVE>.tgz -r docker-registry.default.svc:5000/my-project
          ```

          > **Note**: The project must have pull request privileges to the registry where the images are loaded. The project must also have pull request privileges to push the images into another namespace/project.
          - Check that the images are pushed correctly to the registry.
          ```bash
          $ oc get is --all-namespaces
          ```
          or
          ```bash
          $ oc get is -n my-project

# Installing the CASE

- Apply Custom Resource Definition file -> oc apply -f icp4a_v1_icp4a_crd.yaml
- Create a service account -> oc apply -f service_account.yaml
- Create a required role -> oc apply -f role.yaml
- Apply required role binding -> oc apply -f role_binding.yaml
- Deploy CP4A Operator ->  oc apply  -f operator.yaml
- Apply modified Custom Resource for the component which you want to deploy -> oc apply -f icp4a_v1_icp4a_cr.yaml

For installation instructions, see https://www.ibm.com/support/knowledgecenter/en/SSYHZ8_20.0.x/com.ibm.dba.install/k8s_topics/tsk_install_kubernetes.html

## Configuration

Create a namespace and execute Cloud Pak for Automation Operator deployment.

## Storage

Currently, IBM® Cloud Pak for Automation only supports a NFS storage system.  A NFS storage system needs to be created as a pre-req before deploying IBM® Cloud Pak for Automation chart. Once the required PV and PVCs are created, you will need to modify the ownership of them.

## Limitations

* IBM FileNet Content Manager , Business Automation Navigator products does not support dynamic storage creation.
* IBM FileNet Content Manager , Business Automation Navigator requires `fsGroup` and `supplementalGroups` is `RunAsAny` and  `runAsUser` is `MustRunAsRange`

## Documentation

