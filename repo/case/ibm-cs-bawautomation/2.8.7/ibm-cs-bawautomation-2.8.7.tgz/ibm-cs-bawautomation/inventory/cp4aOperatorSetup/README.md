# Name

IBM&reg; Business Automation Workflow on Containers

# Introduction

## Summary
Business Automation Workflow in Containers a robust, end-to-end solution for business automation needs within the clients' enterprise. In the current competitive marketplace, digital companies use software automation to achieve higher revenue per employee than their traditional counterparts. Business Automation can maximize revenue per employee by reinventing the client experience while reducing costs.
Cloud Pak for Business Automation platform delivers an integrated and managed collection of containerized or virtualized Automation Platform for Digital Business services thatenable rapid deployment and reduce operational costs. Cloud Pak for Business Automation also digitizes all aspects of business operations and can extend the workforce with digital labor to enable businesses to scale.

## Features

Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/con_capab_ent.html) for more details.

* IBM&reg; FileNet Content Manager

  IBM FileNet Content Manager provides enterprise content management to enable secure access, collaboration support, content synchronization and sharing, and mobile  support to engage users over all channels and devices. IBM® FileNet® Content Manager consists of Content Process Engine (CPE), Content Search Service (CSS), Content  Management Interoperability Services (CMIS), Content Navigator Task Manager  and Content Services GraphQL (CGQL).

* IBM&reg; Business Automation Navigator
  
  IBM Business Automation Navigator provides a console to enable teams to view their documents, folders, and searches in ways that help them to complete their tasks.

* IBM&reg; Business Automation Insights
 
  IBM Business Automation Insights a platform-level component, provides visualization and insights to knowledge workers and business owners. Business Automation Insig  hts provides dashboarding and data science capabilities from the events and business data collected from Cloud Pak for Automation services.

* IBM&reg; Business Automation Content Analyzer

  IBM Business Automation Content Analyzer offers the power of intelligent capture with the flexibility of an API that enables you to extend the value of your core en  terprise content management (ECM) technology stack and helps you rapidly accelerate extraction and classification of data in your documents
  
* IBM&reg; Business Automation Workflow

  IBM Business Automation Workflow simplifies workflows and helps you easily and collaboratively discover new ways to automate and scale work by combining business process and case management capabilities.

* IBM&reg; User Management Service

  User Management Service provides users of multiple IBM Cloud Pak for Automation components with a single sign-on experience.

IBM Business Automation Workflow in containers provides the means to acquire and apply key software from across the Digital Business Automation portfolio to digitize and automate all aspects of your business operations. IBM Cloud Paks deliver a hybrid cloud platform that enables businesses to use a mix of on-premises, public, and privately-operated cloud environments for your data and applications. See https://www.ibm.com/support/knowledgecenter/en/SSYHZ8_20.0.x/welcome/kc_welcome_dba_distrib.html for more information.

# CASE Details

## Prerequisites

- Redhat Openshift Container Platform version 4.4 and above
- NFS Server or Gluster File System or cloud-specific storage system
- Download  service_account.yaml, role.yaml, role_binding.yaml, operator.yaml.[link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/con_cp4a_operator.html)
- Download required custom resource definition (CRD) and custom resource (CR) files icp4a_v1_icp4a_crd.yaml, icp4a_v1_icp4a_cr_template.yaml
- Modify custom resource definition file in case you want to change default ICP4A custom resource. [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/con_install_templates.html)
- Modify custom resource file to enable which component you want to deploy.
- Create Docker registry secret and provide the secret name in Custom Resource file.
- Create a secret with LDAP password , database user password and provide the secret name in corresponding section of Custom Resource file.
- Cloud Pak for Business Automation Operator requires 2  persistent volume before deployment.
- The following table describes the storage required for Cloud Pak for Automation.
  - Cloud Pak for Business Automation Operator
    - Follow [link]( http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/tsk_operators.html) for installation instructions.

      | Persistent Volumes            | Persistent Volume Claims        | Description                     |
      | ---------------------------   | ------------------------------- |  ---------------------------------------------     |
      | `operator-shared-pv`         | `operator-shared-pvc`          | `Database drivers required to deploy Cloud Pak for Business Automation deployment` |
      | `operator-log-pv`            | `operator-log-pvc`             | `Operator ansible logs for Cloud Pak for Business Automation deployment`           |

    * Use the below instructions to create  necessary PersistentVolume and PersistentVolumeClaim or specify storage class name for the storage parameters to dynamically provision required PersistentVolumeClaims.

  - IBM® FileNet Content Manager
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/tsk_create_vol_folders_manually.html)
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/tsk_plan_storage.html)

  - IBM® Business Automation Studio
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/k8s_topics/tsk_prepare_bas.html) for details about this product.

  - IBM® Operation Decision Manager
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.offerings/topics/con_odm_prod.html) for details about this product.

  - IBM® Business Automation Application Engine
    * Follow [link](https://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/k8s_topics/tsk_prepare_ae.html) for details about this product.

  - IBM® Business Automation Workflow
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.offerings/topics/con_baw.html) for details about this product.

  - IBM® Automation Decision Services
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.aid/topics/con_ov_intro.html) for details about this product.

  - IBM® Automation Document Processing
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.aid/topics/con_ov_intro.html) for details about this product.

  - IBM® Enterprise Records
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.offerings/topics/con_ier.html) for details about this product.

  - IBM® Content Collector for SAP
    * Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.offerings/topics/con_ier.html) for details about this product.

# PodSecurityPolicy Requirements

# SecurityContextConstraints Requirements

### Red Hat OpenShift SecurityContextConstraints Requirements
This Operator requires a SecurityContextConstraints to be bound to the target namespace prior to installation. This Operator is namespace scoped so it can deploy into any target namespace and furthermore you can deploy the Operator multiple times using difference namespaces.

  - IBM® Business Automation Workflow
```
Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/tsk_bawprep_scc.html)
```
  - IBM® Business Automation Insights
```
Follow [link](http://www.ibm.com/support/knowledgecenter/SSYHZ8_20.0.x/com.ibm.dba.install/op_topics/tsk_preparing_baik8s_security_policy.html)
```
1. For Red Hat OpenShift, add SecurityContextConstraints (SCC) requirements.
If you are installing the chart on Red Hat OpenShift or OKD, the privileged SecurityContextConstraint resource is required for the installation. For more information, see IBM Cloud Pak SecurityContextConstraints Definitions.

2. For RedHat OpenShift, if applicable, add policies to enable the Pod resources to start the containers by using the required UIDs.
To ensure that these containers can start use the oc command to add the service accounts to the required privileged SCC, add these policies.

```
oc adm policy add-scc-to-user privileged -z <cr_name>-bai-psp-sa
oc adm policy add-scc-to-user privileged -z default
```
  - IBM® FileNet Content Manager
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® Business Automation Navigator
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® Business Automation Studio
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® Business Automation Application Engine
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® Operational Decison Manager
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® Enterprise Records
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® User Management Service
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| CP4A      |  32 GB      |    16       |   500     |  5    |


# Accessing Container Images.
- You can access the container images in the IBM Entitled registry with your IBMid

# Installing

- Create ROKS 4.6 cluster
- Use an existing project or provide a name to create one.
- Click on Run Script which prepares the namespace to install.
- Click on Set Deployment Values to choose a capability to install.
- Choose the Capability or Capabilities from the list
- Accept License Agreement 
- Click Install which will launch the Schematics Workspace to monitor installation log.

# Access the deployed applications.

- The deployment will take about 1 - 3 hours to finish depending on your selection. Once you see configmap icp4adeploy-cp4ba-access-info created in the selected project, you can visit your deployment with the URLs in it.

