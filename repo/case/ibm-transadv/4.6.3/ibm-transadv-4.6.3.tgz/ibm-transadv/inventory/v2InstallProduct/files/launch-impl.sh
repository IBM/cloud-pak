#@IgnoreInspection BashAddShebang
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

case_name="ibm-transadv"
inventory="v2InstallProduct"
case_catalog_name="ibm-transadv-catalog"
catalog_namespace="openshift-marketplace"
channel_name="v4.6"
subscription="ibm-transformation-advisor"
ta_operator="ibm-transformation-advisor-manager"
current_version="4.6.3"
namespace_scoped="false"
cluster_sc_op_inst_ns="openshift-operators"

# Custom args from operator install/uninstall
install_ibm_catalog="false"
uninstall_ibm_catalog="false"

# Custom args from Operand install/uninstall
license_accept="false"
cloudpak_name=
host_name=
cloudpak_id=
cloudpak_version=
host_name=
auth_issuer_endpoint=
api_endpoint=
public_url_server=
public_url_ui=
persistence=
access_mode=
dynamic_provisioning=
persistence_claim_couchdb=
persistence_claim_neo4j=
persistence_storage_class=
supplemental_groups=
secret=
registry=
license_type=
user=
pass=
view_license="false"
install_ta_catalog="false"
uninstall_ta_catalog="false"
custom_ca_cert=
auth_config_file=

## overriding dynamic args, passed with --args
parse_custom_dynamic_args() {
    local _key=$1
    local _val=$2

    case $_key in
    --tolerance | -t)
        tolerance_val=${_val}
        ;;
    --installIbmCatalog)
        install_ibm_catalog="true"
        ;;
    --uninstallIbmCatalog)
        uninstall_ibm_catalog="true"
        ;;
    --installTaCatalog)
        install_ta_catalog="true"
        ;;
    --uninstallTaCatalog)
        uninstall_ta_catalog="true"
        ;;
    --acceptLicense)
        license_accept=${_val}
        ;;
    --licenseType)
        license_type=${_val}
        ;;
    --viewLicense)
        view_license="true"
        ;;
    --cloudPakName)
        cloudpak_name=${_val}
        ;;
    --hostname)
        host_name=${_val}
        ;;
    --apiEndpoint)
        api_endpoint=${_val}
        ;;
    --authIssuerEndpoint)
        auth_issuer_endpoint=${_val}
        ;;
    --publicUrlServer)
        public_url_server=$_val
        ;;
    --publicUrlUI)
        public_url_ui=$_val
        ;;
    --cloudPakId)
        cloudpak_id=${_val}
        ;;
    --cloudPakVersion)
        cloudpak_version=${_val}
        ;;
    --persistence)
        persistence=${_val}
        ;;
    --accessMode)
        access_mode=${_val}
        ;;
    --dynamicProvision)
        dynamic_provisioning=${_val}
        ;;
    --persistenceClaimCouchDB)
        persistence_claim_couchdb=${_val}
        ;;
    --persistenceClaimNeo4j)
        persistence_claim_neo4j=${_val}
        ;;
    --storageClass)
        persistence_storage_class=${_val}
        ;;
    --supplementalGroups)
        supplemental_groups=${_val}
        ;;
    --secret)
        secret=${_val}
        ;;
    --registry)
        registry=${_val}
        ;;
    --user)
        user=${_val}
        ;;
    --pass)
        pass=${_val}
        ;;
    --customCACert)
        custom_ca_cert=${_val}
        ;;
    --authConfigFile)
        auth_config_file=${_val}
        ;;
    --tryAndBuy)
        echo "[WARNING] --tryAndBuy option is no longer valid and will be ignored. Use the --licenseType parameter instead"
        ;;
    --namespaceScoped)
        namespace_scoped=${_val}
        ;;
    --taHelp)
        usage
        exit 0
        ;;
    esac
}

source "$scriptDir"/license_check.sh

usage() {

    echo "--args for install action:"
    echo "    --licenseType <true|false>          : REQUIRED: Must be used and set to a valid license type."
    echo "    --acceptLicense <true|false>        : REQUIRED: Must be used and set to true to proceed with install."
    echo "    --installIbmCatalog <true|false>    : OPTIONAL: If set to true, the IBM operator catalog will be installed if it is not already. Default is false."
    echo "    --secret <secret>                   : OPTIONAL: Specify a secret to use to pull the Tranformation Advisor images from entitle registry."
    echo "    --registry <registry>               : OPTIONAL: Specified entitled registry, e.g. cp.icr.io."
    echo "    --user <user>                       : OPTIONAL: Specify user to access the entitled registry."
    echo "    --pass <password>                   : OPTIONAL: Specify password for user to access entitled registry."
    echo "    --persistence <true|false>          : OPTIONAL: If persistence is required for Transformation Advisor (Default is true)."
    echo "    --accessMode <accessMode>           : OPTIONAL: storage accessMode. Default is ReadWriteOnce."
    echo "    --persistenceClaimCouchDB <claim>   : OPTIONAL: Use an existing persistence claim for CouchDB."
    echo "    --persistenceClaimNeo4j <claim>     : OPTIONAL: Use an existing persistence claim for Neo4j."
    echo "    --storageClass <storage class>      : OPTIONAL: Recommended way use persistence with Transformation Advisor. Specify a valid storage class to use."
    echo "    --supplementalGroups [gid,...]      : OPTIONAL: May be used if using file system based storage to ensure database container has read/write permission for the storage."
    echo "    --hostName <hostname>               : OPTIONAL: hostname to access cluster. Transformation Advisor will discover and set this value. It should not need to be changed for most environments."
    echo "    --apiEndpoint <apiEndpoint>         : OPTIONAL: API url for the cluster. Transformation Advisor will discover and set this value. It should not need to be changed for most environments."
    echo "    --authIssuerEndpoint <aiEndpoint>   : OPTIONAL: Auth issuer endpoint for the cluster. Transformation Advisor will discover and set this value. It should not need to be changed for most environments."
    echo "    --publicUrlServer                   : OPTIONAL: See docs for more information. Transformation Advisor will discover and set this value. It should not need to be changed for most environments."
    echo "    --publicUrlUI                       : OPTIONAL: See docs for more information. Transformation Advisor will discover and set this value. It should not need to be changed for most environments."
    echo "    --customCACert <file path>          : OPTIONAL: Specify file to use as custom CA cert."
    echo "    --authConfigFile <file path>        : OPTIONAL: Specify file to use to configure third party authentication."
    echo "    --namespaceScoped <true|false>      : OPTIONAL: If ommitted, defaults to false. This will make the operator to be insalled into openshift-operators namespace and manage all the namespaces, operand will go into namespace specified by --namespace attribute. If set to true, operator and operand are installed into namespace specified by --namespace attribute."
    echo "    --taHelp                            : OPTIONAL: Display options available"
    echo ""
    echo ""
    echo "--args for uninstall action:"
    echo "    --uninstallIbmCatalog <true|false>  : OPTIONAL: If set to true, the IBM operator catalog will be uninstalled. Default is false."
    echo "    --namespaceScoped <true|false>      : OPTIONAL: If ommitted, defaults to false. This will make the operator to be insalled into openshift-operators namespace and manage all the namespaces, operand will go into namespace specified by --namespace attribute. If set to true, operator and operand are installed into namespace specified by --namespace attribute."
    echo ""
}

install() {
    check_license

    echo "Installing full Transformation Advisor product."

    echo "Check the namespace ${namespace} is empty..."
    $kubernetesCLI project ${namespace}

    local _namespace_exists=$?
    if [[ ${_namespace_exists} -eq 0 ]]; then
       # Namespace exists - make sure its empty.
       local _num_resources=$($kubernetesCLI get all -n "${namespace}" | awk 'END{print NR}')
       if [[ ${_num_resources} -ne 0 ]]; then
            err_exit "Attempting to install into a project that is not empty."
       fi
    fi

    # Check for operator group - uninstall from UI does not remove the operatorgroup
    local _opertor_group=$(oc get operatorgroup -n ${namespace} --no-headers | awk '{print $1}')
    if [[ -n ${opertor_group} ]]; then
        $kubernetesCLI delete operatorgroup ${opertor_group} -n ${namespace} ${dryRun} >/dev/null 2>&1
        sleep 5
    fi


    #
    # STEP 1: INSTALLING THE OPERATOR
    #
    echo "*** Install Step 1: Installing operator. ***"

    local _custom_args=""

    if [[ "${install_ibm_catalog}" == "true" ]]; then
        # install the ibm catalog if its not already installed
        _custom_args="${_custom_args} --installIbmCatalog"
    fi
    if [[ "${install_ta_catalog}" == "true" ]]; then
        # install the ta catalog if its not already installed
        _custom_args="${_custom_args} --installTaCatalog"
    fi
    if [[ "${namespace_scoped}" == "true" ]]; then
        _custom_args="${_custom_args} --namespaceScoped true"
    fi

    oc ibm-pak launch ibm-transadv \
        --version ${current_version} \
        --inventory v2TransAdvOperator \
        --action install-operator \
        --namespace ${namespace} \
        --args "${_custom_args} --acceptLicense true ${dryRun:+--dryRun }"

    if [[  $? -ne 0 ]]; then
        err_exit "Install of the operator was not successful. See previous console log for more details. Exiting."
    fi

    echo "Waiting for operator to get ready..."

    if [[ ${dryRun} != "--dry-run" ]]; then
        sleep 10
        local _retries=80
        local _attempt=0

        local _operator_ns="${cluster_sc_op_inst_ns}"
        if [[ ${namespace_scoped} == "true" ]]; then
            _operator_ns="${namespace}"
        fi

        # Operator is ready when it has logged this "Substitute current operator image into pre-install-job.yaml"
        (check_ta_pod_ready_status 1 "ibm-transformation-advisor-manager" "${_operator_ns}") \
            && (kubectl -n ${_operator_ns} logs $(kubectl -n ${_operator_ns} get pods --sort-by=.status.startTime -o=name | grep ibm-transformation-advisor-manager | sed "s/^.\{4\}//" | tail -1) | grep "Substitute current operator image into pre-install-job.yaml" >/dev/null 2>&1 ) \
            && ( kubectl -n ${_operator_ns} get pods | grep ibm-transformation-advisor-manager | wc -l | grep 1 >/dev/null 2>&1 )
        until [[ $? -eq 0 ]] || [[ "$_attempt" -ge "$_retries" ]]; do
            echo "Waiting for operator setup to complete. Retrying ($((_attempt+1)))..."
            _attempt=$((_attempt+1))
            sleep 5
            _pod=$(kubectl -n ${_operator_ns} get pods --sort-by=.status.startTime -o=name | grep ibm-transformation-advisor-manager | sed "s/^.\{4\}//" | tail -1)
            if [[ -z ${_pod} ]]; then
              _pod="<operator pod not found>"
            fi
            echo "Checking logs for pod: ${_pod}"
            (check_ta_pod_ready_status 1 "ibm-transformation-advisor-manager" "${_operator_ns}") \
                && (kubectl -n ${_operator_ns} logs $(kubectl -n ${_operator_ns} get pods --sort-by=.status.startTime -o=name | grep ibm-transformation-advisor-manager | sed "s/^.\{4\}//" | tail -1) | grep "Substitute current operator image into pre-install-job.yaml" >/dev/null 2>&1 ) \
                && ( kubectl -n ${_operator_ns} get pods | grep ibm-transformation-advisor-manager | wc -l | grep 1 >/dev/null 2>&1 )
        done

        sleep 5

        if [[ "$_attempt" -eq "$_retries" ]]; then
            err_exit "Install of the operator was not successful. See previous console log for more details. Exiting."
        fi
    fi
    # Update the CSV with cloud pak annotations if we have them
    if [[ ! -z ${cloudpak_name} ]] && [[ ! -z ${cloudpak_version} ]] && [[ ! -z ${cloudpak_id} ]]; then
        kubectl patch csv ${_csv} --type='json' \
            -p='[{"op": "replace", "path": "spec/install/spec/deployments/0/spec/template/metadata/annotations", "value":{"cloudpakName":'"$cloudpak_name"',"cloudpakVersion":'"$cloudpak_version"',"cloudpak_id":'"$cloudpak_id"'}}]' \
            "${dryRun}"
    fi
    echo "Transformation Advisor operator ready."

    #
    # STEP 2: INSTALLING THE OPERANDS
    #
    echo "*** Install Step 2: Installing Transformation Advisor operands. ***"

    _custom_args=""
    # license type and accept are already validated at this point
    _custom_args="${_custom_args} --acceptLicense true --licenseType ${license_type}"

    if [[ -n "${cloudpak_name}" ]]; then
        _custom_args="${_custom_args} --cloudPakName ${cloudpak_name}"
    fi
    if [[ -n "${host_name}" ]]; then
        _custom_args="${_custom_args} --hostname ${host_name}"
    fi
    if [[ -n "${api_endpoint}" ]]; then
        _custom_args="${_custom_args} --apiEndpoint ${api_endpoint}"
    fi
    if [[ -n "${auth_issuer_endpoint}" ]]; then
        _custom_args="${_custom_args} --authIssuerEndpoint ${auth_issuer_endpoint}"
    fi
    if [[ -n "${public_url_ui}" ]]; then
        _custom_args="${_custom_args} --publicUrlUI ${public_url_ui}"
    fi
    if [[ -n "${public_url_server}" ]]; then
        _custom_args="${_custom_args} --publicUrlServer ${public_url_server}"
    fi
    if [[ -n "${cloudpak_id}" ]]; then
        _custom_args="${_custom_args} --cloudPakId ${cloudpak_id}"
    fi
    if [[ -n "${cloudpak_version}" ]]; then
        _custom_args="${_custom_args} --cloudPakVersion ${cloudpak_version}"
    fi
    if [[ -n "${persistence}" ]]; then
        _custom_args="${_custom_args} --persistence ${persistence}"
    fi
    if [[ -n "${access_mode}" ]]; then
        _custom_args="${_custom_args} --accessMode ${access_mode}"
    fi
    if [[ -n "${dynamic_provisioning}" ]]; then
        _custom_args="${_custom_args} --dynamicProvision ${dynamic_provisioning}"
    fi
    if [[ -n "${persistence_claim_couchdb}" ]]; then
        _custom_args="${_custom_args} --persistenceClaimCouchDB  ${persistence_claim_couchdb}"
    fi
    if [[ -n "${persistence_claim_neo4j}" ]]; then
        _custom_args="${_custom_args} --persistenceClaimNeo4j  ${persistence_claim_neo4j}"
    fi
    if [[ -n "${persistence_storage_class}" ]]; then
        _custom_args="${_custom_args} --storageClass ${persistence_storage_class}"
    fi
    if [[ -n "${supplemental_groups}" ]]; then
        _custom_args="${_custom_args} --supplementalGroups ${supplemental_groups}"
    fi
    if [[ -n "${registry}" ]]; then
        _custom_args="${_custom_args} --registry ${registry}"
    fi
    if [[ -n "${user}" ]]; then
        _custom_args="${_custom_args} --user ${user}"
    fi
    if [[ -n "${pass}" ]]; then
        _custom_args="${_custom_args} --pass ${pass}"
    fi
    if [[ -n "${secret}" ]]; then
        _custom_args="${_custom_args} --secret ${secret}"
    fi
    if [[ -n "${custom_ca_cert}" ]]; then
        _custom_args="${_custom_args} --customCACert ${custom_ca_cert}"
    fi
    if [[ -n "${auth_config_file}" ]]; then
        _custom_args="${_custom_args} --authConfigFile ${auth_config_file}"
    fi
    if [[ -n "${namespace_scoped}" ]]; then
        _custom_args="${_custom_args} --namespaceScoped ${namespace_scoped}"
    fi

    oc ibm-pak launch ibm-transadv \
        --version ${current_version} \
        --inventory v2TransAdv \
        --action apply-custom-resources \
        --namespace ${namespace} \
        --args "${_custom_args} ${dryRun:+--dryRun }"

    if [[ ${dryRun} != "--dry-run" ]]; then
        if [[  $? -ne 0 ]]; then
            err_exit "Install of Transformation Advisor instance was not successful. See previous console log for more details. Exiting."
        fi
    fi

    echo "Waiting for Transformation Advisor pods to become ready..."

    if [[ ${dryRun} != "--dry-run" ]]; then
        sleep 10
        local _retries=60
        local _attempt=0
        local _nr_ready_pods=4

        # If namespace scoped we have 4 operand pods and 1 operator pod
        if [[ ${namespace_scoped} == "true" ]]; then
            _nr_ready_pods=4
        fi

        check_ta_pod_ready_status ${_nr_ready_pods} "ta-" "${namespace}"
        until [[ $? -eq 0 ]] || [[ "$_attempt" -ge "$_retries" ]]; do
            echo "Waiting for Transformation Advisor pods to become ready. Retrying ($((_attempt+1)))..."
            _attempt=$((_attempt+1))
            sleep 10
            check_ta_pod_ready_status ${_nr_ready_pods} "ta-" "${namespace}"
        done

        if [[ "$_attempt" -eq "$_retries" ]]; then
            err_exit "Install of Transformation Advisor was not successful. The pods are not in a ready state. Exiting."
        fi
    fi

    local _ui_host=$($kubernetesCLI get routes -n ${namespace} | grep ui\-route | awk '{print$2}')
    local _ui_route_url="https://${_ui_host}"

    if [[ ${dryRun} == "--dry-run" ]]; then
        echo ""
        echo "Transformation Advisor dry run installation is complete."
        echo ""
    else
        echo ""
        echo "Transformation Advisor is installed. The UI can be accessed at the following URL:"
        echo ${_ui_route_url}
        echo ""
    fi
}

uninstall() {
    echo "Uninstalling full Transformation Advisor product."

    #
    # STEP 1: UNINSTALLING THE OPERANDS
    #
    echo "*** Uninstall Step 1: Uninstalling Transformation Advisor operands. ***"
    oc ibm-pak launch ibm-transadv \
        --version ${current_version} \
        --inventory v2TransAdv \
        --action delete-custom-resources \
        --namespace ${namespace} \
        --args "${dryRun:+--dryRun }"

    if [[ ${dryRun} == "--dry-run" ]]; then
        echo "Dry run uninstall, Transformation Advisor operand pods will not be terminated"
    else
        echo "Waiting for Transformation Advisor operand pods to terminate..."
        sleep 10
        local _retries=120
        local _attempt=0

        check_ta_pod_exists 1 "ta-" "${namespace}"
        until [[ $? -eq 0 ]] || [[ "$_attempt" -ge "$_retries" ]]; do
            echo "namespace: ${namespace}"
            echo "Waiting for Transformation Advisor operand pods to terminate. Retrying ($((_attempt+1)))..."
            _attempt=$((_attempt+1))
            sleep 10
            check_ta_pod_exists 1 "ta-" "${namespace}"
        done

        if [[ "$_attempt" -eq "$_retries" ]]; then
            err_exit "Uninstall of the Transformation Advisor operands was not successful. Exiting."
        fi
        echo "All Transformation Advisor operand pods have terminated."
    fi

    #
    # STEP 2: UNINSTALLING THE OPERATOR
    #

    echo "*** Uninstall Step 2: Uninstalling operator. ***"
    # For operator uninstall we need to know if it's a cluster or namespace scoped install
    local _uninstall_custom_args
    if [[ -n "${namespace_scoped}" ]]; then
        _uninstall_custom_args="--namespaceScoped ${namespace_scoped}"
    fi

    oc ibm-pak launch ibm-transadv \
        --version ${current_version} \
        --inventory v2TransAdvOperator \
        --action uninstall-operator \
        --namespace ${namespace} \
        --args "${_uninstall_custom_args} ${dryRun:+--dryRun }"

    if [[ ${dryRun} == "--dry-run" ]]; then
        echo "Dry run uninstall, Transformation Advisor operator will not be terminated"
    else
        echo "Waiting for operator to terminate..."
        sleep 10
        local _retries=60
        local _attempt=0

        local _operator_ns="${cluster_sc_op_inst_ns}"
        if [[ ${namespace_scoped} == "true" ]]; then
            _operator_ns="${namespace}"
        fi

        check_ta_pod_exists 0 "ibm-transformation-advisor-manager" "$_operator_ns"
        until [[ $? -eq 0 ]] || [[ "$_attempt" -ge "$_retries" ]]; do
            echo "Waiting for operator to terminate. Retrying ($((_attempt+1)))..."
            _attempt=$((_attempt+1))
            sleep 5
            check_ta_pod_exists 0 "ibm-transformation-advisor-manager" "$_operator_ns"
        done

        if [[ "$_attempt" -eq "$_retries" ]]; then
            err_exit "Uninstall of the operator was not successful. Exiting."
        fi

        echo "Transformation Advisor operator has been uninstalled."
    fi

    if [[ "${uninstall_ibm_catalog}" == "true" ]]; then
        echo "*** Uninstall Step 3: Uninstalling ibm catalog. ***"

        oc ibm-pak launch ibm-transadv \
            --version ${current_version} \
            --inventory v2TransAdvOperator \
            --action uninstall-catalog \
            --namespace ${namespace} \
            --args "--uninstallIbmCatalog ${_uninstall_custom_args} ${dryRun:+--dryRun }"

        if [[ ${dryRun} == "--dry-run" ]]; then
            echo "Dry run uninstall, IBM operator catalog will not be uninstalled."
        else
            echo "IBM operator catalog has been uninstalled."
        fi

    elif [[ "${uninstall_ta_catalog}" == "true" ]]; then
        echo "*** Uninstall Step 3: Uninstalling Transformation Advisor catalog. ***"

        oc ibm-pak launch ibm-transadv \
            --version ${current_version} \
            --inventory v2TransAdvOperator \
            --action uninstall-catalog \
            --namespace ${namespace} \
            --args "--uninstallTaCatalog ${_uninstall_custom_args} ${dryRun:+--dryRun }"

        if [[ ${dryRun} == "--dry-run" ]]; then
            echo "Dry run uninstall, Transformation Advisor operator catalog will not be uninstalled."
        else
            echo "Transformation Advisor operator catalog has been uninstalled."
        fi
    fi

    if [[ ${dryRun} == "--dry-run" ]]; then
        echo ""
        echo "Transformation Advisor dry run uninstall complete"
        echo ""
    else
        echo ""
        echo "Transformation Advisor has been uninstalled."
        echo ""
    fi
}


#
# Check the pods whose names match the pattern given, to see if they are in ready state
# param $1 - number of pods we expect to see in a ready state
# param $2 - the pattern to match against the pod name (begins with...)
#
check_ta_pod_ready_status() {
    local _num_expected=$1
    local _pod_pattern=$2
    local _ns=$3
    local _num_ready_pods=$($kubernetesCLI -n ${_ns} get pods -o custom-columns=NAME:.metadata.name,READY:status.containerStatuses[*].ready | grep "^${_pod_pattern}" | grep true | awk 'END{print NR}')
    if [[ _num_ready_pods -eq $_num_expected ]]; then
        return 0
    else
        return 1
    fi
}

#
# Check the pods whose names match the pattern given, to see if they exist
# param $1 - number of pods we expect to see matching the pattern
# param $2 - the pattern to match against the pod name (begins with...)
#
check_ta_pod_exists() {
    local _num_expected=$1
    local _pod_patttern=$2
    local _ns=$3
    local _num_ready_pods=$($kubernetesCLI -n ${_ns} get pods -o custom-columns=NAME:.metadata.name,READY:status.containerStatuses[*].ready | grep "^${_pod_patttern}" | awk 'END{print NR}')

    if [[ _num_ready_pods -le $_num_expected ]]; then
        return 0
    else
        return 1
    fi
}

get_ta_version() {
    local _version=$($kubernetesCLI -n ${namespace} get pods --no-headers -o custom-columns=NAME:.metadata.name,CHARTLABEL:.metadata.labels.chart -n ${namespace} | awk '$1 ~ /ta-.*ui/' | awk '{print$2}' | sed "s/.*dev-//g")

    if [[ ${_version} =~ ^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$ ]]; then
        echo ${_version}
        return 0
    else
        echo "ERROR"
        return 1
    fi
}

#
# Check the currently installed TA version
# Returns the number of pods at the given version
#
check_ta_version() {
    local _version=$1

    local _num_ta_pods=$($kubernetesCLI -n ${namespace} get pods --show-labels -n ${namespace} | grep ibm-transadv-dev-${_version} | awk 'END{print NR}')

    echo ${_num_ta_pods}

    return 0
}

get_num_ta_pods() {
    local _num_pods=$($kubernetesCLI -n ${namespace} get pods -n ${namespace} -o custom-columns=NAME:.metadata.name -n ${namespace} | awk '$1 ~ /ta-.*couchdb/ || $1 ~ /ta-.*server/ || $1 ~ /ta-.*ui/ { print }' | awk 'END{print NR}')
echo "current namespace: $(oc config view --minify -o 'jsonpath={..namespace}')"
echo "namespace: ${namespace}"
echo "_num_pods: ${_num_pods}"
    return ${_num_pods}
}

update_catalog_source() {
    local _custom_args="--installTaCatalog --acceptLicense true"

    if [[ "${namespace_scoped}" == "true" ]]; then
        _custom_args="${_custom_args} --namespaceScoped true"
    fi

    oc ibm-pak launch ibm-transadv \
        --version ${current_version} \
        --inventory v2TransAdvOperator \
        --action install-catalog \
        --namespace "${catalog_namespace}" \
        --args "${_custom_args} ${dryRun:+--dryRun }"
}

