#@IgnoreInspection BashAddShebang
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

case_name="ibm-transadv"
inventory="v2TransAdvOperator"
case_catalog_name="ibm-transadv-catalog"
catalog_namespace="openshift-marketplace"
channel_name="v5.0"
current_version="5.0.1"
subscription="ibm-transformation-advisor"
ta_content_source_policy="ibm-transadv"
cluster_sc_op_inst_ns="openshift-operators"

# variables for custom dynamic arg variables
initialize_cr="false"
install_custom_cr="false"
cr_file="./ta_custom_cr.yaml"
registry=
user=
pass=
view_license="false"
auth_config_file=""

# Values calculated by operator in preinstall script
calc_hostname=
calc_api_endpoint=
calc_auth_issuer_endpoint=
calc_egress_settings_json=
calc_cluster_id=

#
# CR substitutions
#
#__TA_PLACEHOLDER_LICENSE_TYPE__
license_type=""
#__TA_PLACEHOLDER_LICENSE_ACCEPT__
license_accept="false"
#__TA_PLACEHOLDER_CLOUDPAK_NAME__
cloudpak_name="__TA_PLACEHOLDER_CLOUDPAK_NAME__"
#__TA_PLACEHOLDER_CLOUDPAK_ID__
cloudpak_id="__TA_PLACEHOLDER_CLOUDPAK_ID__"
#__TA_PLACEHOLDER_CLOUDPAK_VERSION__
cloudpak_version="__TA_PLACEHOLDER_CLOUDPAK_VERSION__"
#__TA_PLACEHOLDER_HOST_NAME__
host_name="sample.host.name"
#__TA_PLACEHOLDER_AUTH_ISSUER_ENDPOINT__
auth_issuer_endpoint="__TA_PLACEHOLDER_AUTH_ISSUER_ENDPOINT__"
#__TA_PLACEHOLDER_API_ENDPOINT__
api_endpoint="__TA_PLACEHOLDER_API_ENDPOINT__"
public_url_server="__TA_PLACEHOLDER_SERVER_PUBLIC_URL__"
public_url_ui="#__TA_PLACEHOLDER_UI_PUBLIC_URL__"
#__TA_PLACEHOLDER_PERSISTENCE_ENABLED__
persistence="true"
#__TA_PLACEHOLDER_PERSISTENCE_ACCESS_MODE__
access_mode="ReadWriteOnce"
#__TA_PLACEHOLDER_PERSISTENCE_DYNAMIC__
dynamic_provisioning="true"
#__TA_PLACEHOLDER_PERSISTENCE_CLAIM_COUCHDB__
persistence_claim_couchdb=""
#__TA_PLACEHOLDER_PERSISTENCE_CLAIM_NEO4J__
persistence_claim_neo4j=""
#__TA_PLACEHOLDER_PERSISTENCE_STORAGE_CLASS__
persistence_storage_class=""
#__TA_PLACEHOLDER_PERSISTENCE_SUPPLEMENTAL_GROUPS__ []
supplemental_groups="[]"
#__TA_PLACEHOLDER_NETWORK_POLICY_ENABLED__ []
network_policy_enabled="true"
#__TA_PLACEHOLDER_IMAGE_PULL_SECRET__
secret=""
#__TA_PLACEHOLDER_IMAGE_PULL_SECRET__
secret=""
#__TA_PLACEHOLDER_ROUTER_DESTINATION_CA_CERT__
custom_ca_cert=""
#__TA_PLACEHOLDER_AUTH_ENABLED__
auth_enabled="true"
namespace_scoped="false"

get_subscription_name() {
    # For 2.4.2, subscription is changing name to ibm-transformation-advisor to align with OCP ui sub name
    # This method checks if current subscription is called ta-operator - this convenience will allow the
    # 2.4.2 case to uninstall the 2.4.0, 2.4.1 version.
    ta_subscription="ibm-transformation-advisor"
    if $kubernetesCLI get subscription ta-operator -n ${namespace} >/dev/null 2>&1; then
        subscription="ta-operator"
    fi
    echo "Current subscription is named: ${subscription}"
}

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    local _key=$1
    local _val=$2
    case $_key in
    --initializeCr)
        initialize_cr="true"
        ;;
    --customCrPath)
        cr_file=$_val
        ;;
    --installCustomCr)
        install_custom_cr="true"
        ;;
    --licenseType)
        license_type=$_val
        ;;
    --acceptLicense)
        license_accept=$_val
        ;;
    --viewLicense)
        view_license="true"
        ;;
    --cloudPakName)
        cloudpak_name=$_val
        ;;
    --cloudPakId)
        cloudpak_id=$_val
        ;;
    --cloudPakVersion)
        cloudpak_version=$_val
        ;;
    --hostName)
        host_name=$_val
        ;;
    --apiEndpoint)
        api_endpoint=$_val
        ;;
    --authIssuerEndpoint)
        auth_issuer_endpoint=$_val
        ;;
    --publicUrlServer)
        public_url_server=$_val
        ;;
    --publicUrlUI)
        public_url_ui=$_val
        ;;
    --dbSecret)
        db_secret=$_val
        ;;
    --clientId)
        echo "[WARNING] --clientId option is no longer valid and will be ignored. Add clientId and client Secret to the transformation-advisor-secret instead"
        ;;
    --clientSecret)
        echo "[WARNING] --clientSecret option is no longer valid and will be ignored. Add clientId and clientSecret to the transformation-advisor-secret instead"
        ;;
    --persistence)
        persistence=$_val
        ;;
    --accessMode)
        access_mode=$_val
        ;;
    --dynamicProvision)
        dynamic_provisioning=$_val
        ;;
    --persistenceClaimCouchDB)
        persistence_claim_couchdb=$_val
        ;;
    --persistenceClaimNeo4j)
        persistence_claim_neo4j=$_val
        ;;
    --storageClass)
        persistence_storage_class=$_val
        ;;
    --supplementalGroups)
        supplemental_groups=$_val
        ;;
    --networkPolicy)
        network_policy_enabled=$_val
        ;;
    --tryAndBuy)
        echo "[WARNING] --tryAndBuy option is no longer valid and will be ignored. Use the --licenseType parameter instead"
        ;;
    --secret)
        secret=$_val
        ;;
    --registry)
        registry=$_val
        ;;
    --user)
        user=$_val
        ;;
    --pass)
        pass=$_val
        ;;
    --customCACert)
        custom_ca_cert=$_val
        ;;
    --authConfigFile)
        auth_config_file=${_val}
        ;;
    --namespaceScoped)
        namespace_scoped=${_val}
        ;;
    esac
}

source "$scriptDir"/license_check.sh

install() {
    echo "install not supported for operands"
}

process_auth_config() {
    local _cr_file=$1
    local _updated_cr_file=${_cr_file}.upd

    local _auth_enabled=$(grep "APPMOD_AUTH_ENABLED=" ${auth_config_file} | sed "s^.*APPMOD_AUTH_ENABLED=^^g")
    local _id_request_endpoint=$(grep "TA_AUTH_IDENTITY_REQUEST_ENDPOINT=" ${auth_config_file} | sed "s^.*TA_AUTH_IDENTITY_REQUEST_ENDPOINT=^^g")
    local _id_request_endpoint_path=$(grep "TA_AUTH_IDENTITY_REQUEST_ENDPOINT_PATH=" ${auth_config_file} | sed "s^.*TA_AUTH_IDENTITY_REQUEST_ENDPOINT_PATH=^^g")
    local _id_request_endpoint_scope=$(grep "TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE=" ${auth_config_file} | sed "s^.*TA_AUTH_IDENTITY_REQUEST_ENDPOINT_SCOPE=^^g")
    local _id_request_endpoint_state_prefix=$(grep "TA_AUTH_CALLBACK_STATE_PREFIX_PADDING=" ${auth_config_file} | sed "s^.*TA_AUTH_CALLBACK_STATE_PREFIX_PADDING=^^g")
    local _token_request_endpoint=$(grep "TA_AUTH_TOKEN_REQUEST_ENDPOINT=" ${auth_config_file} | sed "s^.*TA_AUTH_TOKEN_REQUEST_ENDPOINT=^^g")
    local _token_request_endpoint_path=$(grep "TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH=" ${auth_config_file} | sed "s^.*TA_AUTH_TOKEN_REQUEST_ENDPOINT_PATH=^^g")
    local _token_verification_endpoint=$(grep "TA_AUTH_TOKEN_VERIFICATION_ENDPOINT=" ${auth_config_file} | sed "s^.*TA_AUTH_TOKEN_VERIFICATION_ENDPOINT=^^g")
    local _token_verification_endpoint_path=$(grep "TA_AUTH_TOKEN_VERIFICATION_ENDPOINT_PATH=" ${auth_config_file} | sed "s^.*TA_AUTH_TOKEN_VERIFICATION_ENDPOINT_PATH=^^g")

#    echo ${_auth_enabled}
#    echo ${_id_request_endpoint}
#    echo ${_id_request_endpoint_path}
#    echo ${_id_request_endpoint_scope}
#    echo ${_auth_callback_state_prefix_padding}
#    echo ${_token_request_endpoint}
#    echo ${_token_request_endpoint_path}
#    echo ${_token_verification_endpoint}
#    echo ${_token_verification_endpoint_path}

    cat ${_cr_file} | sed -e "s/__TA_PLACEHOLDER_AUTH_ENABLED__/${_auth_enabled}/g" \
        -e "s^.*identityRequestEndpoint: \"\".*^      identityRequestEndpoint: \"${_id_request_endpoint}\"^" \
        -e "s^.*identityRequestEndpointPath: \"\".*^      identityRequestEndpointPath: \"${_id_request_endpoint_path}\"^" \
        -e "s^.*identityRequestEndpointScope: \"\".*^      identityRequestEndpointScope: \"${_id_request_endpoint_scope}\"^" \
        -e "s^.*identityRequestEndpointStatePrefix: \"\".*^      identityRequestEndpointStatePrefix: \"${_id_request_endpoint_state_prefix}\"^" \
        -e "s^.*tokenRequestEndpoint: \"\".*^      tokenRequestEndpoint: \"${_token_request_endpoint}\"^" \
        -e "s^.*tokenRequestEndpointPath: \"\".*^      tokenRequestEndpointPath: \"${_token_request_endpoint_path}\"^" \
        -e "s^.*tokenVerificationEndpoint: \"\".*^      tokenVerificationEndpoint: \"${_token_verification_endpoint}\"^" \
        -e "s^.*tokenVerificationEndpointPath: \"\".*^      tokenVerificationEndpointPath: \"${_token_verification_endpoint_path}\"^" \
        |tee > ${_updated_cr_file}

    mv ${_updated_cr_file} ${_cr_file}
}

cert_insert() {
    local _input=$1
    local _cert_file=$2
    local _indentation='      '
    while IFS= read -r line || [ -n "$line" ]; do
        if [[ $line == *"__TA_PLACEHOLDER_ROUTER_DESTINATION_CA_CERT__"* ]]; then
            while IFS= read -r cline || [ -n "$cline" ]; do
                unset IFS
                local _new_line="${_indentation}${cline}"
                IFS=
                echo ${_new_line}
            done < ${_cert_file}
        else
            IFS=
            echo $line
        fi
    done < $_input
}

#
# Get the CR values that the operator preinstall script has already calculated
#
get_calculated_cr_values() {
    get_subscription_name
    local _csvName
    local _csvNS
    if [[ ${namespace_scoped} == "false" ]]; then
        echo "This is a cluster scoped installation."
        echo "For namespace scoped install use: --args \"--namespaceScoped true\"."
        _csvName=$($kubernetesCLI get subscription "${subscription}" -o go-template --template '{{.status.installedCSV}}' -n "${cluster_sc_op_inst_ns}" --ignore-not-found=true)
        _csvNS=${cluster_sc_op_inst_ns}
    else
        _csvName=$($kubernetesCLI get subscription "${subscription}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
        _csvNS=${namespace}
    fi
    echo "CSV namespace is" ${_csvNS}
    local _tmp_json="./cr.json"

    # Wait for csv to  get updated with values from preinstall.sh
    local _attempt=0
    # jq parses the first element of the alm-examples JSON array
    $kubernetesCLI get csv ${_csvName} -n "${_csvNS}" -o template --template '{{ index .metadata.annotations "alm-examples" }}' | jq '.[0]' > $_tmp_json
    jq -e '.spec.route.hostname | test("__TA_PLACEHOLDER_HOST_NAME__")' $_tmp_json > /dev/null
    echo "Wait for CSV to be patched with cluster config..."
    until [[ $? -eq 1 ]] || [[ "$_attempt" -ge 10 ]]; do
        _attempt=$((_attempt+1))
        echo "CSV not yet patched with cluster config, try again."
        $kubernetesCLI get pods -n "${_csvNS}"
        sleep 10
        $kubernetesCLI get csv ${_csvName} -n "${_csvNS}" -o template --template '{{ index .metadata.annotations "alm-examples" }}' | jq '.[0]' > $_tmp_json
        jq -e '.spec.route.hostname | test("__TA_PLACEHOLDER_HOST_NAME__")' $_tmp_json > /dev/null
    done
    if [[ "$_attempt" -eq 10 ]]; then
        err_exit "Unable to get values from csv. Try rerunning installer with hostname, apiEndpoint and authIssuerEndpoint arguments. Exiting."
    fi

    calc_hostname=$(jq -r '.spec.route.hostname' $_tmp_json)
    calc_api_endpoint=$(jq -r '.spec.authentication.ocp.apiEndpoint' $_tmp_json)
    calc_auth_issuer_endpoint=$(jq -r '.spec.authentication.ocp.authIssuerEndpoint' $_tmp_json)
    calc_cluster_id=$(jq -r '.spec.cluster.id' $_tmp_json)

    calc_egress_settings_json=$(jq -c '.spec.networkPolicy.egress' $_tmp_json)

    # debug
    #echo "egress setting:"
    #echo "${calc_egress_settings_json}"

    rm -f $_tmp_json
}

#
# Update the ${cr_file} with the egress settings already set by the operator in alm-examples
#
update_egress_settings() {

  echo "Applying egress settings..."
  echo "[DEBUG] ${calc_egress_settings_json}"

  $kubernetesCLI patch -f ${cr_file} -n ${namespace} --dry-run=client --type='json' -p='[{"op": "replace", "path": "/spec/networkPolicy/egress", "value": '"${calc_egress_settings_json}"'}]' -o yaml > ${cr_file}.new
  mv ${cr_file}.new ${cr_file}

  # debug
  #echo "cr file with patched egress:"
  #cat ${cr_file}

  echo "Finished applying egress settings..."
}

# install operand custom resources
apply_custom_resources() {
    check_license

    local _full_license_descr=$(get_full_license_from_id ${license_type})
    local _evaluation_license="false"
    if [[ ${_full_license_descr} == *"(Evaluation)"* ]] || [[ ${_full_license_descr} == *"z/OS"* ]]; then
        _evaluation_license="true"
    fi

    $kubernetesCLI get imagecontentsourcepolicy | grep ${ta_content_source_policy}
    local _ics_policy_exists=$?

    if [[ "${initialize_cr}" == "true" ]] || [[ "${install_custom_cr}" == "false" ]]; then

        if [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]] && [[ -z "${secret}" ]]; then
            # If a secret or secret name is not provided create one called transadv-pull-secret
            secret="transadv-pull-secret"
        fi

        validate_install_args "apply_custom_resources"

        if [[ -z "${registry}" || -z "${user}" || -z "${pass}" || -z "${secret}" ]]; then
            if [[ "${_evaluation_license}" == "false" ]] && [[ ${_ics_policy_exists} -eq 1 ]]; then
                # if the imagecontentsource policy exists, assume we are pulling from a mirrored registry in airgap, and so the above info is not needed.
                echo
                echo "You have not supplied the required parameters to access the entitled registry."
                echo "Use the --registry, --user, --pass and --secret params to create a pull secret for the entitled registry."
                echo "You may also specify an existing secret with just the --secret parameter."
                echo
                err_exit "Insufficient information to proceed with install"
            fi
        fi

        local _orig_cr_file="${casePath}/inventory/${inventory}/files/deploy/ta_transadv_prod.yaml"

        validate_file_exists "${_orig_cr_file}"

        ###
        ###
        ### Begin get hostname from existing config, as set up by operator
        get_calculated_cr_values

        local _hostname=${calc_hostname}
        local _api_endpoint=${calc_api_endpoint}
        local _auth_issuer_endpoint=${calc_auth_issuer_endpoint}

        # Substitute the values into the CR file.
        if [[ ${host_name} != "sample.host.name" ]]; then
            _hostname=$host_name
        fi
        if [[ ${api_endpoint} != "__TA_PLACEHOLDER_API_ENDPOINT__" ]]; then
            _api_endpoint=${api_endpoint}
        fi
        if [[ ${auth_issuer_endpoint} != "__TA_PLACEHOLDER_AUTH_ISSUER_ENDPOINT__" ]]; then
            _auth_issuer_endpoint=${auth_issuer_endpoint}
        fi

        local _public_url_server="https://${_hostname}"
        local _public_url_ui="#__TA_PLACEHOLDER_UI_PUBLIC_URL__"

        if [[ ${public_url_server} != "__TA_PLACEHOLDER_SERVER_PUBLIC_URL__" ]]; then
            _public_url_server=${public_url_server}
        fi
        if [[ ${public_url_ui} != "#__TA_PLACEHOLDER_UI_PUBLIC_URL__" ]]; then
            _public_url_ui="publicUrl: \"${public_url_ui}\""
        fi

        ### End get client id, secret and hostname from existing config, as set up by operator
        ###
        ###

        local _secret_sub=""
        if [[ -n "${secret}" ]]; then
            # If we have a pull secret, then add the pull secret
            _secret_sub="s/#__TA_PLACEHOLDER_IMAGE_PULL_SECRET__/imagePullSecret: ${secret}/g"
        fi

        rm -f "${cr_file}"

        cat "${_orig_cr_file}" |sed -e "s/__TA_PLACEHOLDER_LICENSE_ACCEPT__/${license_accept}/g" \
            -e "s^__TA_PLACEHOLDER_LICENSE_TYPE__^${_full_license_descr}^g" \
            -e "s/__TA_PLACEHOLDER_CLOUDPAK_NAME__/${cloudpak_name}/g" \
            -e "s/__TA_PLACEHOLDER_CLOUDPAK_ID__/${cloudpak_id}/g" \
            -e "s/__TA_PLACEHOLDER_CLOUDPAK_VERSION__/${cloudpak_version}/g" \
            -e "s/__TA_PLACEHOLDER_HOST_NAME__/${_hostname}/g" \
            -e "s;__TA_PLACEHOLDER_AUTH_ISSUER_ENDPOINT__;${_auth_issuer_endpoint};g" \
            -e "s;__TA_PLACEHOLDER_API_ENDPOINT__;${_api_endpoint};g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_ENABLED__/${persistence}/g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_ACCESS_MODE__/${access_mode}/g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_DYNAMIC__/${dynamic_provisioning}/g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_CLAIM_COUCHDB__/${persistence_claim_couchdb}/g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_CLAIM_NEO4J__/${persistence_claim_neo4j}/g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_STORAGE_CLASS__/${persistence_storage_class}/g" \
            -e "s/__TA_PLACEHOLDER_PERSISTENCE_SUPPLEMENTAL_GROUPS__/${supplemental_groups}/g" \
            -e "s/__TA_PLACEHOLDER_NETWORK_POLICY_ENABLED__/${network_policy_enabled}/g" \
            -e "s;__TA_PLACEHOLDER_SERVER_PUBLIC_URL__;${_public_url_server};g" \
            -e "s;#__TA_PLACEHOLDER_UI_PUBLIC_URL__;${_public_url_ui};g" \
            -e "s;__TA_PLACEHOLDER_CLUSTER_ID__;${calc_cluster_id};g" \
            -e "${_secret_sub}" \
            | tee > ${cr_file}

        # Update the ${cr_file} with the egress settings already set by the operator in alm-examples
        update_egress_settings

        if [[ ! -z "${custom_ca_cert}" ]]; then
            echo "Adding custom CA cert"
            validate_file_exists "${custom_ca_cert}"

            local _temp_cr=$(mktemp)
            cert_insert ${cr_file} ${custom_ca_cert} > ${_temp_cr}
            cp ${_temp_cr} ${cr_file}
        fi
        if [[ ! -z "${auth_config_file}" ]]; then
            echo "Configuring 3rd party authentication"
            validate_file_exists "${auth_config_file}"
            process_auth_config ${cr_file}
        else
            local _temp_cr2=$(mktemp)
            # If no auth file, set the ocp defaults
            cat ${cr_file} | sed -e "s/__TA_PLACEHOLDER_AUTH_ENABLED__/${auth_enabled}/g" \
                |tee > ${_temp_cr2}

            mv -f ${_temp_cr2} ${cr_file}
        fi
    fi

    if [[ ${_ics_policy_exists} -eq 0 ]]; then
        # If we have a image content policy - assume airgap - set the property
        echo "  airgap: true" >> ${cr_file}
    fi

    if [[ "${initialize_cr}" == "true" ]]; then
        # If only init the cr file - we are done.
        return 0;
    fi

    validate_file_exists "${cr_file}"

    # debug
    # cat ${cr_file}

    $kubernetesCLI apply -f ${cr_file} -n ${namespace} ${dryRun}

    return 0;
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"

    local _orig_cr_file="${casePath}/inventory/${inventory}/files/deploy/ta_transadv_prod.yaml"

    if [[ "${dryRun}" != "--dry-run" ]]; then
        "$scriptDir"/safe_ta_delete.sh openshift-operators ${namespace} instance
    fi

    local _ta_secret="transadv-pull-secret"

    if $kubernetesCLI get secret ${_ta_secret} -n ${namespace} >/dev/null 2>&1 ; then
        $kubernetesCLI delete secret ${_ta_secret} -n ${namespace} ${dryRun}
    fi

    rm -f ${cr_file}
}
