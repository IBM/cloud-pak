# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
case_name="ibm-transadv"
inventory="v2TransAdvOperator"
case_catalog_name="ibm-transadv-catalog"
ibm_catalog_name="ibm-operator-catalog"
channel_name="v5.0"
ta_subscription="ibm-transformation-advisor"
current_version="5.0.1"

# variables specific to catalog installation
catalog_namespace="openshift-marketplace"

# variables for custom dynamic arg variables
install_ibm_catalog="false"
uninstall_ibm_catalog="false"
install_ta_catalog="false"
uninstall_ta_catalog="false"
namespace_scoped="false"
cluster_sc_op_inst_ns="openshift-operators"

# overriding dynamic args, passed with --args
parse_custom_dynamic_args() {
    local _key=$1
    local _val=$2
    case $_key in
    --installIbmCatalog)
        install_ibm_catalog="true"
        ;;
    --uninstallIbmCatalog)
        uninstall_ibm_catalog="true"
        ;;
    --installTaCatalog)
        install_ta_catalog="true"
        ;;
    --uninstallTaCatalog)
        uninstall_ta_catalog="true"
        ;;
    --namespaceScoped)
        namespace_scoped=$_val
        ;;
    esac
}

install() {
    echo "install not supported for operator"
}

get_subscription_name() {
    # For 2.4.2, subscription is changing name to ibm-transformation-advisor to align with operator
    # This method checks if current subscription is called ta-operator - this convenience will allow the
    # 2.4.2 case to uninstall the 2.4.0, 2.4.1 version.
    ta_subscription="ibm-transformation-advisor"
    if $kubernetesCLI get subscription ta-operator -n ${namespace} >/dev/null 2>&1; then
        ta_subscription="ta-operator"
    fi
}

install_operator() {

    echo "-------------Installing Transformation Advisor operator-------------"

    # Set namespace=oepnshift-operators if namespace_scoped=false
    if [[ ${namespace_scoped} == "false" ]]; then
        echo "This is a cluster scoped installation."
        echo "Operator will be installed into ${cluster_sc_op_inst_ns} namespace."
        echo "All namespaces in the cluster will be managed by the operator."
        echo "For namespace scoped install use: --args \"--namespaceScoped true\"."
        namespace="${cluster_sc_op_inst_ns}"
    fi

    local catalog_source=${ibm_catalog_name}

    # Check if TA catalog is installed - if yes then install from there. (For airgap - lets have a step in there to install-catalog.)
    # If not, check if IBM catalog is installed, if yes install from there, if not bomb out with message.

    check_catalog_installed ${case_catalog_name}

    local _ta_catalog_installed=$?
    if [[ ${_ta_catalog_installed} -eq 1 ]] && [[ "${install_ta_catalog}" != "true" ]]; then
        echo "Installing from Transformation Advisor catalog."
        catalog_source=${case_catalog_name}
    elif [[ ${install_ta_catalog} == "true" ]]; then

        local _cat_arg=""

        echo "Installing the Transformation Advisor catalog."
        catalog_source=${case_catalog_name}

        oc ibm-pak launch ibm-transadv \
            --version ${current_version} \
            --inventory "${inventory}" \
            --action install-catalog \
            --namespace "${catalog_namespace}" \
            --args "${_cat_arg} ${dryRun:+--dryRun }"
    else
        check_catalog_installed "ibm-operator-catalog"

        local _ibm_catalog_installed=$?
        if [[ ${_ibm_catalog_installed} -eq 1 ]]; then
            echo "Installing from the IBM operator catalog."
            catalog_source=${ibm_catalog_name}
        else
            if [[ "${install_ibm_catalog}" == "true" ]]; then
                catalog_source=${ibm_catalog_name}
                # If command expressly asks to install IBM catalog, do it.
                oc ibm-pak launch ibm-transadv \
                    --version ${current_version} \
                    --inventory "${inventory}" \
                    --action install-catalog \
                    --namespace "${catalog_namespace}" \
                    --args "--installIbmCatalog ${dryRun:+--dryRun }"
            else
                # Not automatically installing the catalog - as this could result in installing the IBM catalog in airgap mode.
                err_exit "Transformation advisor is not available in any installed catalog. Check documentation for install instructions."
            fi
        fi
    fi

    if [[ "${namespace}" != "${cluster_sc_op_inst_ns}" ]]; then
        echo "Ensure the namespace ${namespace} is empty..."
        $kubernetesCLI project ${namespace}

        local _namespace_exists=$?
        if [[ ${_namespace_exists} -eq 0 ]]; then
           # Namespace exists - make sure its empty.
           local _num_resources=$($kubernetesCLI get all -n "${namespace}" | awk 'END{print NR}')
           if [[ ${_num_resources} -ne 0 ]]; then
                err_exit "Attempting to install into a project that is not empty."
           fi
# From 3.0.0, expecting operatorgroup to be created in advance
#           local _num_op_groups=$($kubernetesCLI get operatorgroup -n "${namespace}" | awk 'END{print NR}')
#           if [[ ${_num_op_groups} -ne 0 ]]; then
#                err_exit "Attempting to install into a project that is not empty. OperatorGroup resource exists in namespace."
#           fi
        fi
    fi
    echo "-------------Installing via OLM-------------"

    # Leave OperatorGroup creation as manual step now for the cluster admin.

    #local _og_file="${casePath}/inventory/${inventory}/files/operator_group.yaml"
    #validate_file_exists "${_og_file}"

    # Create operator group
    # if [[ "${namespace}" != "${cluster_sc_op_inst_ns}" ]]; then
    #    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${_og_file}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    # fi

    local subscription_file="${casePath}/inventory/${inventory}/files/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|ibm-transadv-catalog|$catalog_source|g" | sed "s|REPLACE_CHANNEL_NAME|$channel_name|g" | sed "s|REPLACE_CSV_VERSION|${current_version}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

}


# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Set namespace=oepnshift-operators if namespace_scoped=false
    if [[ ${namespace_scoped} == "false" ]]; then
        echo "This is a cluster scoped installation."
        echo "Operator was installed in ${cluster_sc_op_inst_ns} namespace."
        namespace="${cluster_sc_op_inst_ns}"
    fi

    # Find installed CSV
    get_subscription_name
    local _csv_name=$($kubernetesCLI get subscription "${ta_subscription}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)

    # Remove the subscription
    $kubernetesCLI delete subscription "${ta_subscription}" -n "${namespace}" --ignore-not-found=true ${dryRun}

    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${_csv_name}" ]] && { $kubernetesCLI delete clusterserviceversion "${_csv_name}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # delete crds
    if [[ "${dryRun}" != "--dry-run" ]]; then
        "$scriptDir"/safe_ta_delete.sh openshift-operators ${namespace} operator
    fi

    # Delete ConsoleYAMLSample's
    if $kubernetesCLI get consoleyamlsample >/dev/null 2>&1 ; then
        $kubernetesCLI delete consoleyamlsample ta-prod ${dryRun}
        $kubernetesCLI delete consoleyamlsample ta-sample ${dryRun}
    fi

    # No auto delete of operator group now. If cluster wide install, then, using the global OG. If own namespace install, creating and removing the OG is a manual task.

    # Delete secrets
    $kubernetesCLI delete secret transformation-advisor-secret ${dryRun} >/dev/null 2>&1 || echo "Failed to delete transformation-advisor-secret, or it did not exist."
    $kubernetesCLI delete secret db-internal-cert ${dryRun} >/dev/null 2>&1 || echo "Failed to delete db-internal-cert, or it did not exist."
    $kubernetesCLI delete secret liberty-internal-cert ${dryRun} >/dev/null 2>&1 || echo "Failed to delete liberty-internal-cert, or it did not exist."
    $kubernetesCLI delete secret ui-internal-cert ${dryRun} >/dev/null 2>&1 || echo "Failed to delete ui-internal-cert, or it did not exist."

}


check_catalog_installed() {
    local _catalog=$1
    echo "Check if catalog ${_catalog} is installed..."

    $kubernetesCLI get CatalogSource -n ${catalog_namespace} | grep $_catalog

    local _ret_val=$?
    if [[ ${_ret_val} -eq 1 ]]; then
        echo "NO"
        return 0
    else
        echo "YES"
        return 1
    fi
}

# Installs the catalog source
install_catalog() {

    validate_install_catalog

    echo "-------------Installing catalog source-------------"

    local _catsrc_file="${casePath}/inventory/${inventory}/files/ibm_catalog_source.yaml"

    if [[ "${install_ibm_catalog}" == "false" ]]; then
        _catsrc_file="${casePath}/inventory/${inventory}/files/catalog_source.yaml"
    fi

    # Verfy expected yaml files for install exit
    validate_file_exists "${_catsrc_file}"

    if [[ -n "${registry}" ]] && [[ "${install_ibm_catalog}" == "false" ]]; then
      local _catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

      # replace original registry with local registry
      local _catsrc_image_mod="${registry}/$(echo "${_catsrc_image_orig}" | sed -e "s/[^1]*\///")"
      sed <"${_catsrc_file}" -e "s|${_catsrc_image_orig}|${_catsrc_image_mod}|g" | tee >($kubernetesCLI apply $dryRun -f -) | cat

    else
      $kubernetesCLI apply $dryRun -f "${_catsrc_file}"

    fi

    echo "done"
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    local _catsrc_file="${casePath}/inventory/${inventory}/files/ibm_catalog_source.yaml"

    if [[ "${uninstall_ibm_catalog}" == "false" ]]; then
        _catsrc_file="${casePath}/inventory/${inventory}/files/catalog_source.yaml"
    fi

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${_catsrc_file}" --ignore-not-found=true ${dryRun}
}
