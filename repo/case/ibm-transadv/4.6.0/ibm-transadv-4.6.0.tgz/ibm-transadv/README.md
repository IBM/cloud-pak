# IBM CLOUD TRANSFORMATION ADVISOR


# Introduction

[IBM Cloud Transformation Advisor](http://ibm.biz/transadvisor-kc) helps you plan, prioritize, and package your on-premise workloads for modernization on OpenShift Container Platform. Documentation for the product can be found [here](http://ibm.biz/transadvisor-kc).

# Details

The Transformation Advisor is delivered as an interconnected set of pods and kubernetes services. It consists of four pods: server, ui, database and graph database, managed by an operator.

This CASE bundle contains three inventory items: 
- v2InstallProduct - Provides the CASE actions to install/uninstall the Transformation Advisor product.  It will first install the operator - optionally installing catalogs as required - and then install the instance. See [README](inventory/v2InstallProduct/README.md).
- v2TransAdvOperator - Provides the CASE actions to install/uninstall the Transformation Advisor operator.See [README](inventory/v2TransAdvOperator/README.md).
- v2TransAdv - Provides the CASE actions to install/uninstall the Transformation Advisor instance.See [README](inventory/v2TransAdv/README.md).

## Prerequisites

### IBM Operator Catalog

Transformation Advisor is available in the IBM Operator Catalog. See [IBM Operator Catalog documentation](https://github.com/IBM/cloud-pak/blob/<DEFAULT_BRANCH>/reference/operator-catalog-enablement.md) for more details.

When installing Transformation Advisor using the CASE actions, there is an option `--installIbmCatalog` which will automatically install the IBM operator catalog if it is not already installed on your cluster.

### Namespace/Project

Create a project for Transformation Advisor installation.

This can be done from the OpenShift UI as follows:
- Click the hamburger icon in the top left of the Red Hat OpenShift Container Platform dashboard. 
- Expand "Home" menu and select "Projects". 
- Click "Create Project" button.
- Name the project and click "Create".

Alternatively, you can use the `oc new-project <project name>` command from the command line.

For convenience, set an environment variable that can be used during the install.

```
export TA_PROJECT=ta
```

### Access Transformation Advisor images from the entitled registry

Transformation Advisor can be installed with a time limited evaluation license (fully featured), or as an entitled product. Please read the [license](https://ibm.biz/transadv-license-2-5-0) for more details:

- If installing as an evaluation, you can ignore the following instructions that describe how to get access to the entitled registry. In this case, the required images will be pulled from a public registry and no access details are required.

- If installing Transformation as an entitled product, you will need to have an entitled registry key.

Follow the [Cloud Pak instructions](https://www.ibm.com/support/knowledgecenter/SSCSJL_4.2.x/install-icpa-cli.html) to get your entitled registry key.

You can set the entitled registry details as environment details for use during the install.

```
export ENTITLED_REGISTRY=cp.icr.io
export ENTITLED_REGISTRY_USER=cp
export ENTITLED_REGISTRY_KEY=<entitled registry key>
```

During the install, these values will be used to create an image pull secret so that you can access the images from the entitled registry.

### Persistence

Transformation Advisor requires persistence to be configured in order to persist the database data. There are a number of different configuration options depending on the type of persistence that is available on your cluster.

Please refer to the [documentation](http://ibm.biz/transadvisor-kc) for full details on how to configure persistence.

**NOTE:** Transformation Advisor officially supports `ReadWriteOnce` accessMode.

Although it is NOT recommended for a production install, you can also turn the persistence off. If you turn persistence off - Transformation Advisor will function as normal, however, you will lose all of your Transformation Advisor data when the database container restarts. Persistence can be turned on or off using the `--persistence <true|false>` argument when installing. See "Installing the CASE" section for more details.

The persistence enabled and other persistence options can be set at install time by passing arguments to the CASE installer. (see "Installing the CASE" section below).

## Resources Required

### Minimum Default Configuration

| Subsystem  | CPU Minimum | Memory Minimum (GB) | Disk Space Minimum (GB) |
| ---------- | ----------- | ------------------- | ----------------------- |
| CouchDB    | 0.5         | 1                   | 20                       |
| GraphDB    | 0.5         | 1                   | 5                       |
| Server     | 0.5         | 1                   | N/A                     |
| UI         | 0.5         | 1                   | N/A                     |
| Operator   | 0.4         | 0.5                 | N/A                     |

These values can be changed in the custom resource yaml prior to install (see "Configure and Install Transformation Advisor Instance" section below).


## Installing the CASE

The CASE installer provides the commands needed to install/uninstall Transformation Advisor.
Please see the [installProduct README](inventory/v2InstallProduct/README.md) for details on running the CASE installer. 

## Configuration

Using the CASE installer, you can supply arguments at install time to configure the install. All available options are described in the [installProduct README](inventory/v2InstallProduct/README.md).


## Open Transformation Advisor UI

After a successful install using the CASE install action, a URL will be printed to the console that will take you directly to the Transformation Advisor UI. You will need to have a valid cluster login in order to access the UI.

Alternatively, you can navigate to the RedHat OpenShift web console. Click on the Routes item in the left navigation and select the project that you installed into. From there you should see the UI route which wil take you to the Transformation Advisor UI.


# PodSecurityPolicy Requirements
No PodSecurityPolicy Requirements. A custom SecurityContextConstraint is used. See below.

Custom PodSecurityPolicy definition:
```
N/A
```

# SecurityContextConstraints Requirements
Transformation Advisor Operator runs as restricted SCC.

### Custom SecurityContextConstraints definition:
N/A

## Backup and restore data

Please follow instruction in [documentation](http://ibm.biz/transadvisor-kc) to backup/restore your data.

## Limitations

You may only install one instance of Transformation Advisor per cluster.

## FAQ

For more help, or if you are experiencing issues please refer to the FAQ [here](https://www.ibm.com/support/knowledgecenter/SS5Q6W/troubleshooting/FAQ.html).

## Copyright

© Copyright IBM Corp. 2020. All Rights Reserved.
