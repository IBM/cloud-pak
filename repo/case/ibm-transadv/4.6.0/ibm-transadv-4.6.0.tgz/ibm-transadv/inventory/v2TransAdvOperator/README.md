# IBM CLOUD TRANSFORMATION ADVISOR OPERATOR

## Introduction
This inventory item contains the resources and launch scripts to create the Transformation Advisor subscription and deploy the operator.

## Prerequisites
Create a project/namespace where Transformation Advisor will be installed. The project can be created in the OpenShift UI, or with the following command:
```
oc new-project <project name>
```

The IBM operator catalog must be installed. It may be installed as part of the operator install by providing the `--installIbmCatalog true` argument.

## CASE launch actions
The following case launch actions are supported in this inventory:
- `install-operator`
- `uninstall-operator`
- `install-catalog`
- `uninstall-catalog`
- `configure-creds-airgap`
- `configure-cluster-airgap`
- `mirror-images`

### ACTION: install-operator

#### Description

  This action will create a subscription to Transformation Advisor and deploy the operator to the given namespace. 
  Parameters may be supplied to the `install-operator` action to control aspects of the operator creation.
 
#### Usage

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action install-operator \
    --namespace <namespace/project> \
    --args "[EXTRA ARGS]"

EXTRA ARGS:
    --acceptLicense <true|false>        : REQUIRED: Must be used and set to true to proceed with install.
    --viewLicense                       : OPTIONAL: View the Transformation Advisor license.
    --installIbmCatalog <true|false>    : OPTIONAL: If set to true, the IBM operator catalog will be installed if it is not already. Default is false.
    --namespaceScoped <true|false>      : OPTIONAL: If ommitted, defaults to false. This will make the operator to be insalled into openshift-operators namespace and manage all the namespaces. If set to true, operator and operand are installed into namespace specified by --namespace attribute.
```

#### Examples

##### Example 1

Install Transformation Advisor operator into a namespace called `ta`, installing the IBM operator catalog if it does not already exist.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action install-operator \
    --namespace ta \
    --args "--installIbmCatalog true"    
```

### ACTION: uninstall-operator

#### Description

  This action will uninstall the Transformation Advisor operator and associated subscription.
  Parameters may be supplied to the `uninstall-operator` action to control aspects of the operator creation.
 
#### Usage

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action uninstall-operator \
    --namespace <namespace/project> \
    --args "[EXTRA ARGS]"

EXTRA ARGS:
    --uninstallIbmCatalog <true|false>    : OPTIONAL: If set to true, the IBM operator catalog will be uninstalled. Default is false.
```

#### Examples

##### Example 1

Uninstall Transformation Advisor operator from a namespace called `ta`, uninstalling the IBM operator catalog also.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action uninstall-operator \
    --namespace ta \
    --args "--uninstallIbmCatalog true"    
```

### ACTION: install-catalog

#### Description

  This action will install the Transformation Advisor operator catalog which contains the Transformation Advisor operator.
  This is useful when you don't need or want the IBM operator catalog - for example in an air gapped install scenario.
#### Usage

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action install-catalog \
    --namespace <namespace/project> \
    --args "[EXTRA ARGS]"

EXTRA ARGS:
    --acceptLicense <true|false>        : REQUIRED: Must be used and set to true to proceed with install.
    --viewLicense                       : OPTIONAL: View the Transformation Advisor license.
```

#### Examples

##### Example 1

Install Transformation Advisor operator catalog.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action install-catalog \
    --namespace ta \
    --args "--acceptLicense true"
```

### ACTION: uninstall-catalog

#### Description

  This action will uninstall the Transformation Advisor operator catalog which contains the Transformation Advisor operator.
#### Usage

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action uninstall-catalog \
    --namespace <namespace/project> \
    --args "--acceptLicense true"

```

#### Examples

##### Example 1

Uninstall Transformation Advisor operator catalog.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdvOperator \
    --action uninstall-catalog \
    --namespace ta
```
