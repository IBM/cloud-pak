# IBM CLOUD TRANSFORMATION ADVISOR INSTANCE

## Introduction
This inventory item contains the custom resource definition and launch scripts to install an instance of Transformation Advisor.

## Prerequisites
The Transformation Advisor operator is already installed and watching the same namespace that is being targeted here.

## CASE launch actions
The following case launch actions are supported in this inventory:
- `apply-custom-resources`
- `delete-custom-resources`

### ACTION: apply-custom-resources

#### Description

  This action will stand up an instance of Transformation Advisor by applying a custom resource.
  Parameters may be supplied to the `apply-custom-resources` action to control aspects of the instance creation.
  For more complete control, `apply-custom-resources` may be run in two stages. 
  - The first stage will generate a custom resource yaml file (by default `./ta_custom_cr.yaml`)
  - You may make edits to this yaml to customize the install.
  - Run the second stage of `apply-custom-resources` to create the Transformation Advisor instance with the custom settings.

#### Usage

```
oc ibm-pak launch ibm-transadv \
    --version <VERISON> \
    --inventory v2TransAdv \
    --action apply-custom-resources \
    --namespace <namespace/project> \
    --args "[EXTRA ARGS]"

EXTRA ARGS:
    --acceptLicense <true|false>        : REQUIRED: Must be used and set to true to proceed with install.
    --viewLicense                       : OPTIONAL: View the Transformation Advisor license.
    --secret <secret>                   : OPTIONAL: Specify a secret to use to pull the Tranformation Advisor images from entitle registry.
    --registry <registry>               : OPTIONAL: Specified entitled registry, e.g. cp.icr.io.
    --user <user>                       : OPTIONAL: Specify user to access the entitled registry.
    --pass <password>                   : OPTIONAL: Specify password for user to access entitled registry.
    --tryAndBuy                         : OPTIONAL: If you do not have an entitlement key for the entitled registry, use this option to install Transformation Advisor in try and buy mode
    --persistence <true|false>          : OPTIONAL: If persistence is required for Transformation Advisor (Default is true)
    --accessMode <accessMode>           : OPTIONAL: storage accessMode. Default is ReadWriteOnce
    --persistenceClaimCouchDB <claim>   : OPTIONAL: Use an existing persistence claim CouchDB
    --persistenceClaimNeo4j <claim>     : OPTIONAL: Use an existing persistence claim Neo4j
    --storageClass <storage class>      : OPTIONAL: Recommended way use persistence with Transformation Advisor. Specify a valid storage class to use.
    --supplementalGroups [gid,...]      : OPTIONAL: May be used if using file system based storage to ensure database container has read/write permission for the storage.
    --initializeCr                      : OPTIONAL: For a two stage install. This will create an initialized custom resource yaml file which may be customized befre installing. May be used with --customCrPath to write to a specific file.
    --customCrPath <file path and name> : OPTIONAL: For a two stage install, see --initializeCr
    --installCustomCr                   : OPTIONAL: For a two stage install. Will stand up instance with custom settings. May be used with --customCrPath     
    --apiEndpoint <apiEndpoint>         : OPTIONAL: API url for the cluster. Transformation Advisor will discover and set this value. It should not need to be changed for most environments.
    --authIssuerEndpoint <aiEndpoint>   : OPTIONAL: Auth issuer endpoint for the cluster. Transformation Advisor will discover and set this value. It should not need to be changed for most environments.
    --customCACert <file path>          : OPTIONAL: Specify file to use as custom CA cert.
    --publicUrlServer                   : OPTIONAL: See docs for more information. Transformation Advisor will discover and set this value. It should not need to be changed for most environments.
    --publicUrlUI                       : OPTIONAL: See docs for more information. Transformation Advisor will discover and set this value. It should not need to be changed for most environments.
    --authConfigFile <file path>        : OPTIONAL: Specify file to use to configure third party authentication

```

#### Examples

##### Example 1

Install Transformation Advisor instance into a namespace called `ta`, pulling the images from entitled registry. 

Secret will be created from the given user and pass.

Persistence will use the `rook-ceph-cephfs-internal` storage class specified.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdv \
    --action apply-custom-resources \
    --namespace ta \
    --args "--acceptLicense true --registry cp.stg.icr.io --user ekey --pass w9KpPj7MIN2coc_jMHYDK5iS --secret transadv-pull-secret --storageClass rook-ceph-cephfs-internal"
```

##### Example 2

Install Transformation Advisor instance without access to entitlement registry as a try and buy experience.
Persistence will use the `rook-ceph-cephfs-internal` storage class specified.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdv \
    --action apply-custom-resources \
    --namespace ta \
    --args "--acceptLicense true --tryAndBuy --storageClass rook-ceph-cephfs-internal"
```

##### Example 3

Two stage install of Transformation Advisor instance:

1. 
```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdv \
    --action apply-custom-resources \
    --namespace ta \
    --args "--acceptLicense true --initializeCr"
```
This creates a file called `./ta_custom_cr.yaml`

2. Review and edit if necessary the file that was created (`./ta_custom_cr.yaml`)

3. Apply the custom resource file:
```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdv \
    --action apply-custom-resources \
    --namespace ta \
    --args "--installCustomCr"
```


### ACTION: delete-custom-resources

#### Description

This action will delete an instance of Transformation Advisor in the given namespace.
 
#### Usage

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdv \
    --action delete-custom-resources \
    --namespace <namespace/project> 
```

#### Examples

##### Example 1

Delete Transformation Advisor instance.

```
oc ibm-pak launch ibm-transadv \
    --version $TA_VERISON \
    --inventory v2TransAdv \
    --action delete-custom-resources \
    --namespace ta
```
