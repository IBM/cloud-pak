#!/bin/bash
# (C) Copyright IBM Corp. 2022

# Safe delete of the TA CR and CRD.
# Will delete in background and patch finalizers if necessary to remove deadlock situation.
# Usage:
# safe_ta_delete <operator namespace> <namespace> <mode>
#   mode: <instance|crd> instance just deletes the TA instance. crd deletes the instance and operator.
# Example:
#   safe_ta_delete.sh ta-ns instance # Deletes the instance in the ta-ns
#   safe_ta_delete.sh ta-ns operator # Deletes the instance in the ta-ns and the operator
#
# WARNING: If the delete mode "operator" is chosen, and the operator is installed cluster wide, then all instances of TA
# installed on the cluster will be deleted before deleting the operator.
#

#
# Input Parameters
#
operator_namespace=$1
instance_namespace=$2
delete_mode=$3

#
# Get the number of TA pods currently running
#
function get_num_ta_pods() {
    local _num_pods=$(oc get pods -n ${instance_namespace} -o custom-columns=NAME:.metadata.name | awk '$1 ~ /.*-.*couchdb/ || $1 ~ /.*-.*neo4j/ || $1 ~ /.*-.*server/ || $1 ~ /.*-.*ui/ { print }' | awk 'END{print NR}')
    return ${_num_pods}
}

#
# Find the name of a ta instance in a namespace and delete it
# Delete in the background and also remove finalizer to avoid a hanging state
#
function delete_instance() {
  target_namespace=$1
  echo "[INFO] Entering delete TA instance in namespace $target_namespace"
  echo "[INFO] Get instance name..."

  if ! oc get project $target_namespace >/dev/null 2>&1 ; then
    echo "[WARNING] Attempting to delete instance in a project that doesn't exist: $target_namespace"
    echo "[WARNING] Project may have been deleted before instance was deleted."
    echo "[WARNING] Try to manually rescue this situation by recreated the deleted namespace, and re-running the delete script."
    return
  fi

  if oc get transadvs.ta.ibm.com >/dev/null 2>&1 ; then
    instance_name=$(oc get transadvs.ta.ibm.com -n $target_namespace  -o custom-columns=NAME:.metadata.name --no-headers)

    if [[ -n $instance_name ]]; then
      echo "-> About to delete instance \"$instance_name\" in background..."
      oc delete transadvs.ta.ibm.com/$instance_name -n ${target_namespace} > /dev/null 2>&1 &
      echo "-> Delete of ta instance started..."

      _retries=60
      _attempt=0

      get_num_ta_pods
      until [[ $? -eq 0 ]] || [[ "$_attempt" -ge "$_retries" ]]; do
        echo "-> Waiting for Transformation Advisor operand pods to terminate. Retrying ($((_attempt+1)))..."
        _attempt=$((_attempt+1))
        sleep 10
        get_num_ta_pods
      done

      echo "-> TA operand pods have been deleted. Patching the CR to remove finalizer..."
      oc patch transadvs.ta.ibm.com/$instance_name -p '{"metadata":{"finalizers":[]}}' --type=merge -n ${target_namespace} > /dev/null 2>&1

      echo "-> TA CR patched, checking CR is deleted..."

      if oc get transadvs.ta.ibm.com/$instance_name  -n ${target_namespace} > /dev/null 2>&1; then
        echo "-> TA CR still exists. Try deleting again..."
        oc delete transadvs.ta.ibm.com/$instance_name -n ${target_namespace}
      else
        echo "-> TA CR has been successfully deleted."
      fi

    else
      echo "[INFO] No instance of TA in namespace ${target_namespace}"
    fi

  else
    echo "[INFO] No TransAdv CRD on the cluster. Nothing to do."
  fi
  echo "[INFO] Leaving delete instance."
}

#
# Delete the TA operator
# First check that all TA instances have been deleted, and delete any instances that are not yet deleted.
#
function delete_operator() {

  echo "[INFO] Entering delete operator..."

  if oc get transadvs.ta.ibm.com >/dev/null 2>&1 ; then

    if [[ "${operator_namespace}" == "openshift-operators" ]]; then
      echo "[INFO] Cluster wide install of TA detected."
      echo "[INFO] Check and delete all instances are deleted"

      oc get transadvs.ta.ibm.com --all-namespaces -o custom-columns=NAMESPACE:.metadata.namespace --no-headers | while read -r ns ; do delete_instance $ns ; done
    else
      echo "[INFO] Single namespace install of TA detected."
      echo "[INFO] TA instance already deleted"
    fi

    echo "-> Delete subscription and CSV if exist"
    if oc get subscription ibm-transformation-advisor -n ${operator_namespace} > /dev/null 2>&1; then
        CSV=$(oc get subscription ibm-transformation-advisor -n ${operator_namespace} -o json | jq '.status.installedCSV' | tr -d '"')
        echo "-> Found CSV: " $CSV
        oc delete subscription ibm-transformation-advisor -n ${operator_namespace} || echo "failed to delete subscription or it didnt exist"
        oc delete csv ${CSV} -n ${operator_namespace} || echo "failed to delete CSV or it didnt exist"
    fi

    echo "-> Attempt to delete CRD"
    oc delete crd/transadvs.ta.ibm.com > /dev/null 2>&1 &
    sleep 20
    echo "-> Attempt to patch CRD to remove finalizer..."
    oc patch crd/transadvs.ta.ibm.com -p '{"metadata":{"finalizers":[]}}' --type=merge > /dev/null 2>&1
    sleep 10

    if oc get crd/transadvs.ta.ibm.com  > /dev/null 2>&1; then
        echo "-> TA CRD still exists. Try deleting again..."
        oc delete crd/transadvs.ta.ibm.com/ta
    else
        echo "-> TA CRD has been successfully deleted."
    fi
  else
    echo "[INFO] No TransAdv CRD on the cluster. Nothing to do."
  fi

  echo "[INFO] Leaving delete operator."
}

#
# Main Entry
#
echo "[INFO] Executing safe delete of TA"

delete_instance "${instance_namespace}"

if [[ "${delete_mode}" == "operator" ]]; then

  delete_operator

fi

echo "[INFO] Done executing safe delete of TA"

exit 0