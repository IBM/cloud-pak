# Name

AI Manager - IBM Cloud Pak for AIOps

# Introduction

## Details

AI Manager - IBM Cloud Pak for AIOps provides holistic insights that help prioritize issues and resolution efforts that take place in ever-evolving hybrid cloud and traditional IT environments. It identifies and gathers signals across a variety of structured and unstructured data channels, including alerts, logs, and tickets.

AI Manager - IBM Cloud Pak for AIOps extends the capability to provide transformative, AI-driven insight from structured and unstructured data across IT data sources with the integration of near real-time, cross-domain dynamic event, topology, and metric analytics features of IBM® Netcool® Ops Manager, forming a more powerful AIOps solution.

The new features in AI Manager - IBM Cloud Pak for AIOps enable organizations to:

- Detect, observe, and ingest event, topology, and metric data from their cloud, hybrid, or local environments into a single consolidated AIOps solution
- Gain near real-time dynamic insights for faster probable cause identification
- Take action, potentially reduce cost, and eliminate manual effort and manual steps by automating actions and running automated diagnostics
- Automatically surface advice in ChatOps to help transform the way your team works and to help improve employee productivity and satisfaction
- Use advanced analytics, machine learning, and AI for incident detection and response to help teams quickly:
- Identify a problem as well as identifying emerging problems so that they can better understand the cause of that problem
- Apply automations to resolve problems, when possible
- Escalate and collaborate to restore the service as quickly as possible when a problem is not easily resolved
## Features

IBM AIOps for IBM Cloud Pak for Data 2.0 consists of the following core components.

### AI Manager

AI Manager analyzes structured and unstructured data channels that pertain to an application, including  AIOps Alert Manager for events and topology data, Humio, LogDNA, and PagerDuty. To resolve an incident, it identifies a potential problem, analyzes the evidence, and provides a synthesized report in near real time. When the AI detects a potential problem, it begins to form a story about the incident, surfaces a report in the user's ChatOps environment, such as Slack, and updates the story as evidence is collected.

AI Manager integrates with the following IBM Netcool offerings: Netcool Operations InsightÂ®, IBM Netcool Agile Service Manager, and IBM Tivoli Netcool/Omnibus.

### Metric Manager

Metric Manager analyzes performance and monitoring data (metric data) across silos, domains, vendors, and systems such as New Relic, AppDynamics, and SolarWinds. It automatically learns the normal operational behavior of the metrics in an organization's environment in order to automatically detect anomalies and it offers a wide range of proactive outage avoidance capabilities, including:

- Proactive detection of emerging problems and issues to help avoid service disruptions and outages that can affect your business
- Improved DevOps efficiency during continuous integration and continuous delivery (CI/CD) by detecting performance issues immediately after a new application is released
- Correlation metrics across services, nodes, and metrics to promote faster probable cause identification

### Event Manager

Event Manager uses correlation and analysis processes to deliver a robust analytics-driven alert and incident management solution that helps organizations collect, consolidate, and correlate events and topology data from virtually any source.

Event Manager is a natural evolution and successor to all previous version of Netcool's event management solutions. It delivers advanced, cross-domain event-based and topology-based analytics, enabling ITOps and DevOps teams to improve operational efficiency and potentially reduce operational cost by applying machine learning to diminish event noise for more effective event management and incident response. Capabilities include:

- AI to determine which alert is the most likely to be nearest to the cause of the incident outage or service degradation
- In-context visualization of an alert group or event by using event history and topology to help with quick repair; and self-service topology-based dashboards for health at glance
- Initiation of Runbooks for automated response

###  AIOps -- Extensions

For organizations that are responsible for application and network infrastructure management, the  AIOps for IBM Cloud Pak for Data solution provides the following optional, value-add extensions, not for separate deployment:

- Advanced Agile Discovery Extension. Provides ready-to-use direct application and network discovery of your environment. The solution includes agentless discovery capabilities for cloud-native, lean, and fast discovery of your environment. The discovery function is seamlessly integrated into the dynamic topology service of the  AIOps solution.
- Network Manager Extension. Provides organizations that use earlier versions of IBM Netcool Network Management and IBM Netcool Operations Insight -- Network Management with a path to  AIOps while continuing to manage discovery and manage their physical and virtual network infrastructure.
- Performance Manager Extension. Provides organizations that use earlier versions of programs (such as IBM Netcool Operations Insight, Performance Management) with a path to  AIOps while continuing to manage the performance and health of their physical and virtual enterprise network infrastructure.

# Details

## Prerequisites

- [Basic prerequisites](#basic-prerequisites)
- [Store passwords in secrets](#store-passwords-in-secrets)
- [Role Based Access](#role-based-access)
- [Red Hat OpenShift SecurityContextConstraints Requirements](#red-hat-openshift-securitycontextconstraints-requirements)
### Basic prerequisites

The following prerequisites are required for a successful installation.

- A Kubernetes cluster. For more information on the cluster, see  [Netcool Operations Insight documentation: Products and Components on a Container Platform](https://www.ibm.com/support/knowledgecenter/SSTPTP_1.6.0/com.ibm.netcool_ops.doc/soc/integration/concept/soc_int_noicontphysicaldeplexample.html).
- Kubernetes v1.11.0 or later, and Tiller v2.9.1 or later.
- PersistentVolume support on the cluster.
- Kubernetes command line interface (`kubectl`) installed and able to communicate with the cluster. For more information, including the required version of `kubectl`, see [Accessing your cluster using kubectl](https://www.ibm.com/support/knowledgecenter/en/SSBS6K_3.2.0/manage_cluster/cfc_cli.html).
- For offline (airgap) type of deployments, install the skopeo CLI version 1.0.0 or higher. For more information, see [Installing skopeo from packages](https://github.com/containers/skopeo/blob/master/install.md).


For more information on prerequisites, see [ AIOps Documentation: Preparing for installation](https://www.ibm.com/support/knowledgecenter/SSQNUZ_3.0.1/svc-aiops/aiops-prereqs.html).
### Store passwords in secrets.
Following our security requirements, we do not install with default passwords. There are two options for password generation.
- The install will generate random passwords and store these passwords in secrets, which you can extract after the install.
- You can create the passwords in secrets prior to install, where you choose the password [following these guidelines](https://www.ibm.com/support/knowledgecenter/SSTPTP_1.6.0/com.ibm.netcool_ops.doc/soc/integration/task/int-creating_passwords_and_secrets-rhocp.html).

### Role Based Access
  Our pods require access to information on kubernetes  resources(services, configmaps, pods, routes). This access is granted using [Role Based Access (RBAC)](https://www.ibm.com/support/knowledgecenter/SSTPTP_1.6.0/com.ibm.netcool_ops.doc/soc/integration/task/int-configuring_pod_access_control-rhocp.html).

### Resources Required

#### System resources, based on various install size parameters.

The ibm-netcool-prod Helm chart and its dependent sub-charts have the following minimum resource requirements.

**Note**: This bare minimum setup will not provide production-like
performance; however, it will be sufficient for demonstration purposes.

- 6 virtual machines in your Kubernetes cluster, assigned as follows:
    - 1 infrustructure node: 4 CPU, 8 GB Memory 300GB Disk.
    - 1 master node: 8 CPU, 16 GB Memory 300GB Disk
    - 1 IBM foundation service Node: 4 CPU, 16 GB Memory 500GB Disk
    - 3 Worker nodes: 8 CPU, 16 GB Memory 300GB Disk

- Local Storage, vSphere Storage and Ceph are currently the storage types supported.

See [ Sizing requirements]( https://www.ibm.com/support/knowledgecenter/SSTPTP_1.6.0/com.ibm.netcool_ops.doc/soc/integration/reference/soc_sizing_full.html)

#### Persistence:
* Cassandra will need 108GB of disk space
* Other components will need an additional 4GB

# Installing (Guidance)
https://www.ibm.com/support/knowledgecenter/SSTPTP_1.6.0/com.ibm.netcool_ops.doc/soc/collaterals/soc_netops_kc_welcome.html

# Installing ibm-watson-ai-manager

This operator can be installed in an on-line or air-gapped cluster through either of following install paths :
1. Operator Lifecycle Manager (default)
2. Kubernetes CLI

## Download the case and case dependencies

Create a directory to save the CASEs to a local directory

```
mkdir /tmp/cases
```

Run

```
cloudctl case save                       \
    --case ibm-watson-ai-manager          \
    --repo https://raw.githubusercontent.com/IBM/cloud-pak/master/repo/case \
    --outputdir /tmp/cases
```

Verify the case, dependency cases and images csv has been downloaded under the
`/tmp/cases` directory.


## To install on-line using OpenShift Operator Catalog

1. (Optional) Create a image pull secret and service account (using template under op-cli directory) if installing operator from authenticated registry.

```
kubectl create secret docker-registry 'cp.icr.io'  \
    --docker-server='cp.icr.io'                    \
    --docker-username='cp'                         \
    --docker-password='<token>'                    \
    --docker-email='<user>'                        \
    --namespace='<target namespace>'
```

2. Install the catalog(s) via OLM

Export the TARGET_REGISTRY based on your desired image registry. By default, this
should be `docker.io/ibmcom`. The `<target namespace>` can either be set at a
cluster-wide scope by specifying `openshift-marketplace` or can be targeted directly to a particular namespace.

```
export TARGET_REGISTRY=docker.io/ibmcom

cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action install-catalog                           \
    --args "--registry $TARGET_REGISTRY --recursive --inputDir /tmp/cases"
```

3. Install the operator via OLM

```
cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action install-operator
```

## To uninstall on-line using OpenShift Operator Catalog

1. Uninstall the operator via OLM

```
cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action uninstall-operator
```

2. Uninstall the catalog via OLM

```
cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action uninstall-catalog                         \
    --args "--recursive --inputDir /tmp/cases"
```

3. Find and manually remove NOI dependency CSV and Subscriptions from cluster:
```
oc get ClusterServiceVersion
oc get Subscription
oc delete ClusterServiceVersion <CSV-Name>
oc delete Subscription <Subscription-Name>
```

## To install on-line using command-line

1. (Optional) Create image pull secret if installing operator from authenticated registry

```
kubectl create secret docker-registry 'cp.icr.io'  \
    --docker-server='cp.icr.io'                    \
    --docker-username='cp'                         \
    --docker-password='<token>'                    \
    --docker-email='<user>'                        \
    --namespace='<target namespace>'
```

2. Install the operator via command line specifying image pull secret as argument
if installing from authenticated registry

Export the TARGET_REGISTRY based on your desired image registry. By default, this
should be `docker.io/ibmcom`

```
export TARGET_REGISTRY=docker.io/ibmcom

cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action install-operator-native                   \
    --args "--registry $TARGET_REGISTRY --recursive --inputDir /tmp/cases"
```

## To uninstall on-line using command-line

```
cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action uninstall-operator-native                 \
    --args "--recursive --inputDir /tmp/cases"
```

### In Air-Gapped OpenShift Cluster With a Bastion

#### 1. Prepare Bastion Host

* Logon to the bastion machine

* Verify that the bastion machine has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with OpenShift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the bastion machine

#### 2. Set the TARGET_REGISTRY variable

The OpenShift image registry isn't recommended due to limitations such as lack of
support for fat manifest. Quay.io enterprise is an opensource alternative. To use
the image registry anyways:

1. Expose the OpenShift image registry externally

```
oc patch configs.imageregistry.operator.openshift.io/cluster --patch '{"spec":{"defaultRoute":true}}' --type=merge
```

2. Set the environment variable of the target registry.

```
export TARGET_REGISTRY=$(oc get route default-route -n openshift-image-registry -o jsonpath='{.spec.host}')
```

Otherwise, export the TARGET_REGISTRY environment variable with the location of
the registry.

#### 3. Configure Registry Auth

1. Create auth secret for the the source image registry

Create registry secret for source image registry (if the registry is public which doesn't require credentials, this step can be skipped)

```
cloudctl case launch                                     \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz     \
    --namespace <target namespace>                       \
    --inventory aiManagerSetup                           \
    --action configure-creds-airgap                      \
    --args "--registry cp.icr.io --user iamapikey --pass xyz"
```

2. Create auth secret for target image registry

```
cloudctl case launch                                     \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz     \
    --namespace <target namespace>                       \
    --inventory aiManagerSetup                           \
    --action configure-creds-airgap                      \
    --args "--registry $TARGET_REGISTRY --user `USERNAME` --pass PASSWORD"
```

The credentials are now saved to `~/.airgap/secrets/<registry-name>.json`

#### 4. Mirror Images

In this step image from saved CASE (images.csv) are copied to target registry in the airgap environment.

```
export USE_SKOPEO=1

cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action mirror-images                             \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

#### 5. Configure Cluster for Airgap

This steps does the following

* creates a global image pull secret for the target registry (skipped if target registry is unauthenticated)
* creates a imagesourcecontentpolicy

WARNING:

* Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in $HOME/.airgap/secrets and /tmp/airgap* to support this action

* Applying imagesourcecontentpolicy causes cluster nodes to recycle.

```
cloudctl case launch                                   \
    --case /tmp/cases/ibm-watson-ai-manager-1.1.0.tgz   \
    --namespace <target namespace>                     \
    --inventory aiManagerSetup                         \
    --action configure-cluster-airgap                  \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

(Optional) If you are using an insecure registry, you must add the local registry to the cluster insecureRegistries list.

```
oc patch image.config.openshift.io/cluster --type=merge -p '{"spec":{"registrySources":{"insecureRegistries":["'${TARGET_REGISTRY}'"]}}}'
```

#### 6. Install Operator

See instructions from [Installing ibm-watson-ai-manager](#installing-ibm-watson-ai-manager) section

### In Air-Gapped OpenShift Cluster Without a Bastion

#### 1. Prepare a portable device

Prepare a portable device (such as laptop) that be used to download the case and images can be carried into the air gapped environment

* Verify that the portable device has access
  * to public internet (to download CASE and images)
  * a target image registry ( where the images will be mirrored)
  * a target openshift cluster to install the operator

* Download and install dependent command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with OpenShift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All the following steps should be run from the portable device

#### 2. Configure Registry Auth

See instructions from previous [Configure Registry Auth](#3-configure-registry-auth) section

#### 3. Mirror Images

See instructions from previous [Mirror Images](#4-mirror-images) section

#### 4. Configure Cluster for Airgap

See instructions from previous [Configure Cluster for Airgap](#5-configure-cluster-for-airgap) section

#### 5. Install the operator

See instructions from [Installing ibm-watson-ai-manager](#installing-ibm-watson-ai-manager) section

## Configuration

### Ingress Controller Config

Your OpenShift environment may need to be updated to allow network policies to function correctly. To determine if your OpenShift environment is affected, view the default ingresscontroller and locate the property `endpointPublishingStrategy.type`. If it is set to `HostNetwork`, the network policy will not work against routes unless the default namespace contains the selector label.

```
kubectl get ingresscontroller default -n openshift-ingress-operator -o yaml

  endpointPublishingStrategy:
    type: HostNetwork
```
To set the label via a patch of the default namespace run:

```
kubectl patch namespace default --type=json -p '[{"op":"add","path":"/metadata/labels","value":{"network.openshift.io/policy-group":"ingress"}}]'
```

## Storage

You must create storage prior to your installation of Operations Management on OpenShift.

Due to the high I/O bandwidth and low network latency that is required by Operations Management on OpenShift services, network-based storage options such as Network File System (NFS) and GlusterFS are not supported. vSphere or local storage are the currently supported storage classes.

For more information on storage requirements and the steps required to set up your storage, see [ AI Manager Documentation: Preparing for installation](https://www.ibm.com/support/knowledgecenter/SSQNUZ_3.0.1/svc-aiops/aiops-prereqs.html#aiops-prereqs__pre).

## PodSecurityPolicy Requirements

(Non OpenShift install). Skip if installing on OpenShift

This chart requires a pod security policy to be bound to the target namespace prior to installation. Choose either a predefined PodSecurityPolicy or have your cluster administrator set up a custom pod security policy for you:

  - Using predefined PodSecurityPolicy name: [`ibm-privileged-psp`](https://ibm.biz/cpkspec-psp).
  - [Configure PodSecurityPolicy](https://www.ibm.com/support/knowledgecenter/SSTPTP_1.6.0/com.ibm.netcool_ops.doc/soc/integration/task/int-configuring_pod_access_control.html).
  - Custom PodSecurityPolicy definition:

```
    apiVersion: extensions/v1beta1
    kind: PodSecurityPolicy
    metadata:
      name: ibm-privileged-psp
    spec:
      allowPrivilegeEscalation: true
      allowedCapabilities:
      - '*'
      allowedUnsafeSysctls:
      - '*'
      fsGroup:
        rule: RunAsAny
      hostIPC: true
      hostNetwork: true
      hostPID: true
      hostPorts:
      - max: 65535
        min: 0
      privileged: true
      runAsUser:
        rule: RunAsAny
      seLinux:
        rule: RunAsAny
      supplementalGroups:
        rule: RunAsAny
      volumes:
      - '*'
   ```
## SecurityContextConstraints Requirements
This chart requires a SecurityContextConstraints(SCC) to be bound to the target service account prior to installation. All pods will use this SCC. A SCC constrains the actions a pod can perform. Actions such as Host IPC access. Host IPC access is required by our DB2 pod.
  - Predefined SecurityContextConstraints [`ibm-privileged-scc`](https://ibm.biz/cpkspec-scc)
  - Custom SCC

 #### Custom SecurityContextConstraints definition

   ```
  apiVersion: security.openshift.io/v1
  kind: SecurityContextConstraints
  metadata:
    name: ibm-noi-scc
  allowHostDirVolumePlugin: false
  allowHostIPC: true
  allowHostNetwork: false
  allowHostPID: false
  allowHostPorts: false
  allowPrivilegeEscalation: true
  allowPrivilegedContainer: false
  defaultAddCapabilities: []
  allowedCapabilities:
  - SETPCAP
  - AUDIT_WRITE
  - CHOWN
  - NET_RAW
  - DAC_OVERRIDE
  - FOWNER
  - FSETID
  - KILL
  - SETUID
  - SETGID
  - NET_BIND_SERVICE
  - SYS_CHROOT
  - SETFCAP
  - IPC_OWNER
  - IPC_LOCK
  - SYS_NICE
  - DAC_OVERRIDE
  priority: 11
  fsGroup:
    type: RunAsAny
  readOnlyRootFilesystem: false
  requiredDropCapabilities:
  - MKNOD
  runAsUser:
    type: RunAsAny
  seLinuxContext:
    type: RunAsAny
  supplementalGroups:
    type: RunAsAny
  volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
   ```


  To add SCC to the serviceaccount

  ```
   oc adm policy add-scc-to-user ibm-noi-scc system:serviceaccount:namespace:noi-service-account
  ```
## Limitations

* Platform limited, only supports `amd64` worker nodes.
* StatefulSet are not currently scalable.
* IBM Netcool Operations Insight has been tested on version 4.4/4.5 of OpenShift.

## Documentation

Full documentation on the  AI Manager Case Bundle can be found in the  [ AI Manager Case Bundle Documentation](https://ibm.biz/WatsonAIOps2).
