# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ibm-cem operator

# ibm-cem operator specific variables
caseName="ibm-watson-ai-manager"
inventory="aiManagerSetup"
caseCatalogName="$caseName-catalog"
catalogNamespace="openshift-marketplace"
channelName="v4.7"
# - variables specific to catalog/operator installation
catalogNamespace="openshift-marketplace"
catalogDigest="@INDEX-DIGEST"
case_depedencies=""
# To be removed when either issue fixed or AIManager is in production
# IBMPrivateCloud/container-content-roadmap/issues/7335
tolerance_val=1

# Wrap the catalog/operator install
install() {
    install_catalog
    install_operator
}

# Wrap the catalog/operator uninstall
uninstall() {
    uninstall_operator
    uninstall_catalog
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-netcool-prod)
        echo "noiOperatorSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -n "${registry}" ]]; then
      local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
      local oldRegistry=$(echo $catsrc_image_orig | cut -d'/' -f 1)
      local imageWithoutRegistry=$(echo $catsrc_image_orig | cut -c $((${#oldRegistry}+2))-${#catsrc_image_orig})
      # replace original registry with local registry
      local catsrc_image_mod="${registry}/${imageWithoutRegistry}"
      sed <"${catsrc_file}" -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply -n "${namespace}" -f -) | cat
    else
      # correct digest and apply catalog source
      sed <"${catsrc_file}" "s|:latest|$catalogDigest|g" | ($kubernetesCLI apply -n "${namespace}" -f -) | cat
    fi

    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    userCatalogNamespace="${catalogNamespace}"
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        userCatalogNamespace="${namespace}"
        if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${namespace}"; then
            err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}' or '${namespace}'"
        fi
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" -e "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | sed "s|REPLACE_CATALOG_NAMESPACE|$userCatalogNamespace|g" | tee >($kubernetesCLI apply -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    # Proceed with install
    echo "-------------Installing native-------------"

    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local sa_file="${op_cli_files}/service_account.yaml"
    local role_file="${op_cli_files}/role.yaml"
    local role_binding_file="${op_cli_files}/role_binding.yaml"
    local clusterrole_file="${op_cli_files}/clusterrole.yaml"
    local clusterrole_binding_file="${op_cli_files}/clusterrolebinding.yaml"
    local operator_file="${op_cli_files}/operator.yaml"

    validate_file_exists "${sa_file}"
    validate_file_exists "${role_file}"
    validate_file_exists "${role_binding_file}"
    validate_file_exists "${clusterrole_file}"
    validate_file_exists "${clusterrole_binding_file}"
    validate_file_exists "${operator_file}"

    # Apply yaml files manipulate variable input as required
    # - service account
    sed <"${sa_file}" "s|REPLACE_SECRET|$secret|g" | sed  "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI apply -n "${namespace}" -f -
    # create crds
    for crdYaml in "${op_cli_files}"/*_crd.yaml; do
        $kubernetesCLI apply -n "${namespace}" -f "${crdYaml}"
    done
    # create role
    sed < "${role_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI apply -n "${namespace}" -f -
    sed < "${role_binding_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI apply -n "${namespace}" -f -
    sed < "${clusterrole_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI apply -n "${namespace}" -f -
    sed < "${clusterrole_binding_file}" "s|name: operator|name: aimanager-operator\n  namespace: ${namespace}|g" | $kubernetesCLI apply -n "${namespace}" -f -
    
    # create operator deployment
    sed < "${operator_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI apply -n "${namespace}" -f -
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {
    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -n "${namespace}" -f "${catsrc_file}" --ignore-not-found=true
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseName}-subscription" -n "${namespace}" --ignore-not-found=true
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true
    done

    # Delete catalog source
    # $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    validate_install_args "uninstall"

    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_operators
    fi

    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local sa_file="${op_cli_files}/service_account.yaml"
    local role_file="${op_cli_files}/role.yaml"
    local role_binding_file="${op_cli_files}/role_binding.yaml"
    local clusterrole_file="${op_cli_files}/clusterrole.yaml"
    local clusterrole_binding_file="${op_cli_files}/clusterrolebinding.yaml"
    local operator_file="${op_cli_files}/operator.yaml"

    echo "-------------Uninstalling operator-------------"
    # Verify expected yaml files for uninstall and delete resources for each
    [[ -f "${sa_file}" ]] && { sed <"${sa_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI delete -n "${namespace}" --ignore-not-found=true -f -; }
    [[ -f "${role_file}" ]] && { sed <"${role_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI delete -n "${namespace}" --ignore-not-found=true -f -; }
    [[ -f "${role_binding_file}" ]] && { sed <"${role_binding_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI delete -n "${namespace}" --ignore-not-found=true -f -; }
    [[ -f "${clusterrole_file}" ]] && { sed <"${clusterrole_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI delete --ignore-not-found=true -f -; }
    [[ -f "${clusterrole_binding_file}" ]] && { sed <"${clusterrole_binding_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI delete --ignore-not-found=true -f -; }
    [[ -f "${operator_file}" ]] && { sed <"${operator_file}" "s|name: operator|name: aimanager-operator|g" | $kubernetesCLI delete -n "${namespace}" --ignore-not-found=true -f -; }

    # - crds
    if [[ $deleteCRDs -eq 1 ]]; then
        echo "deleting crds"
        for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
            $kubernetesCLI delete -n "${namespace}" -f "${crdYaml}" --ignore-not-found=true
        done
    fi

}
