# Name

IBM&reg; Cloud Pak for AIOps Issue Resolution Core

# Introduction

## Summary

The IBM&reg; Cloud Pak for AIOps Issue Resolution Core operator is used by the
IBM AIOps lead operator to install the event and incident store.

## Features

* Event and incident datastore consisting of a failover Netcool/OMNIbus
  ObjectServer pair.
* Kafka and HTTP interfaces to the datastore.
* Authorization and authentication service interface to Zen.

# Details

## Prerequisites

### Resources Required

The sizing instructions for IBM&reg; Cloud Pak for AIOps should be
used to determine the cluster size required for this component.  The
component runs withing the Cloud Pak and is not meant to be installed
separately.

# Installing

The Issue Resolution Core is installed as a part of IBM&reg; Cloud Pak for
AIOps.  Please refer to the Cloud Pak documentation when installing
this product:  https://ibm.biz/cpwaiops_welcome

## Configuration

The Issue Resolution Core is installed as a part of IBM&reg; Cloud Pak for
AIOps.  Please refer to the Cloud Pak documentation when configuring
this product.

## Storage

Each of the two ObjectServers create a persistent volume using the storage
class of IBM&reg; Cloud Pak for AIOps.

## Limitations

* Only one instance of the Issue Resolution Core is supported per namespace
* Multiple instances can be configured provided they are all in their own
  namespace
* Only the amd64 architecture is supported

## Documentation

* Please refer to the IBM&reg; Cloud Pak for AIOps documentation:
  https://ibm.biz/cpwaiops_welcome

### PodSecurityPolicy Requirements
There are no explicit PSP required.

### SecurityContextConstraints Requirements
All pods run with the OpenShift Restricted SCC, which is included here for
reference.
Custom SecurityContextConstraints definition:
```yaml
kind: SecurityContextConstraints
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restricted
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: false
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- ALL
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
