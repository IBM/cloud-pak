# issueResolutionCoreOperatorSetup

This inventory item contains resources required to install the IBM Cloud Pak for AIOps Issue Resolution Core Operator through the Operator Lifecycle Manager (OLM) in an online environment.
