# issueResolutionCoreOperator

Contains the IBM Cloud Pak for AIOps Issue Resolution Core Operator custom resource and launch scripts to install/delete the custom resources
