# paw-licenses
License files for PAW Local
