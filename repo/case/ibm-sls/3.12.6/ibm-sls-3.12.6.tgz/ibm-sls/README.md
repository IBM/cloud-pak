
# IBM Suite License Service

# Introduction

IBM Suite License Service (SLS) is a token-based licensing system that uses MongoDB as the data store.

SLS includes the following capabilities:

- License Management APIs that provide license management capabilities.
- Token Pool API that provide basic reporting stats on token usage.
- Entitlement APIs to configure and upload entitlements to the licensing system.
- Reportings APIs that provide historical reports on token usage, license usage, and auditing events.
- Configuration APIs that dynamically enforce or ignore compliance.
- Registration APIs that provide client registration capabilities.
- Client Management APIs that provide client management capabilities.

# Details

IBM Suite License Service standard deployment includes the following resources:
- Pods: controller-manager, truststore-mgr-controller-manager, api-licensing, trustore-worker
- Services: sls

The `controller-manager` operator pod deploys `truststore-mgr-controller-manager`, `api-licensing`, `trustore-worker` pods. After deployment completes, a client can call the `api-licensing` over the `sls` service to manage licenses.

# Prerequisites

- [IBM Suite License Service (SLS) - Supported Compatibility Matrix document](https://supportcontent.ibm.com/support/pages/ibm-suite-license-service-sls-supported-configuration-matrix).

## Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
The operator uses the Red Hat Openshift default `restricted` Security Context Constraints (SCC).

## Install cert-manager

IBM Certificate Manager is recommended to be used as cert-manager for IBM Suite License Service (SLS).

To install IBM Certificate Manager see [Installing IBM Cert Manager for IBM Suite Licensing Service](https://www.ibm.com/support/pages/node/6827535).

**Note:** Skip this step if you installed IBM Certificate Manager as part of another IBM solution.

# Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| **Total** |     4.2     |      4      |     1     |   1   |

# Installing

Before installing IBM Suite License Service, check the supported [installation modes](https://www.ibm.com/support/pages/node/6827911).

## Configure MongoDB credentials

Create a secret in the namespace where you plan to deploy SLS that contains the MongoDB credentials:

```bash
cat <<EOF |oc apply -f -
apiVersion: v1
kind: Secret
type: Opaque
metadata:
  name: sls-mongo-credentials
  namespace: ibm-sls
stringData:
  username: mongouser
  password: mongopwd
EOF
```

## AirGap

  **Note:** Skip the airgap instructions if you are completing a normal installation.

  Airgap Pre-Installation

  If your cluster is in a restricted network or not connected to the internet, the Red Hat OpenShift Container Platform cluster cannot pull container images directly from public registries like IBM Entitled Registry.
  You will need to fetch the images into a Bastion server, load the images into an internal mirror registry, and configure image mirroring in your Red Hat OpenShift Container
  Platform cluster so that it will pull the container images from the internal mirror registry.

  The pre-installation steps are as follows:

  - Install the cloudctl command line tool.
  - Get the CASE for the IBM-SLS.
  - Create or identify a mirror registry, accessible from the air gapped cluster.
  - Mirror CASE images to the mirror registry, by using the cloudctl tool.
  - Configure the cluster to pull images from the mirror registry.
  - After you have completed these steps, you can install SLS.

## Normal Install steps

1. From Operators > OperatorHub, type Suite License Service as a keyword into the filter text box.
2. Click the IBM Suite License Service tile.
3. From the IBM Suite License Service tile page, click Install.
4. Accept the default values for Update Channel and Installation Mode. Enable the Select a Namespace radio button and enter ibm-sls as the target namespace to install SLS.

    **Note:** For system stability, consider setting the Installation Mode to manual so that SLS updates are not automatically applied as they become available. In addition, you can also set the starting CSV to a specific value to ensure that the version you install is the intended version.

5. Click Install.
6. Verify that the SLS operator pod ibm-sls-controller-manager in the ibm-sls namespace is in Ready state.
7. From Operators > Installed Operators, switch to the ibm-sls namespace and select the IBM Suite License Service operator.
8. From the Operator Details page, click Create instance.
9. Select configure by using the YAML view and enter one of the following YAML LicenseService CR templates:

**Note:** Mongo CA certificate is required. Make sure you add it under `spec.mongo.certificates`.

Bare Minimum:

```yaml
apiVersion: sls.ibm.com/v1
kind: LicenseService
metadata:
  name: sls
  namespace: ibm-sls
spec:
  license:
    accept: true
  mongo:
    configDb: admin
    nodes:
    - host: host1.domain.com
      port: 27017
    secretName: sls-mongo-credentials
    certificates:
    - alias: mongoca
      crt: |-
        -----BEGIN CERTIFICATE-----
        ...
        -----END CERTIFICATE-----
```

All Filled:

```yaml
apiVersion: sls.ibm.com/v1
kind: LicenseService
metadata:
  name: sls
  namespace: ibm-sls
spec:
  license:
    accept: true
  domain: domain.com
  ca:
    secretName: ca-keypair
  mongo:
    configDb: admin
    nodes:
    - host: host1.domain.com
      port: 27017
    secretName: sls-mongo-credentials
    authMechanism: DEFAULT
    retryWrites: true
    certificates:
    - alias: mongoca
      crt: |-
        -----BEGIN CERTIFICATE-----
        ...
        -----END CERTIFICATE-----
```

10. Click Create to deploy the LicenseService CR.

The SLS deployment can take up to 10 minutes. The SLS deployment is finished when it reports that it is `Ready` under `STATUS` column. Use the following command to check the instance state:

```sh
oc get -n ibm-sls licenseservice sls

NAME   VERSION   STATUS   INITIALIZED   LICENSEID      REGISTRATIONKEY                        AGE
sls    3.9.1     Ready    Initialized   0242ac110002   0121e6f8-a9ac-5d84-825f-ac455803d3c4   28d
```

# Configuration

## License

SLS requires acceptance of the license terms. If the license isn’t accepted, SLS is not deployed. Set the license accept flag in the LicenseService CR.

```yaml
spec:
  license:
    accept: true
```

## MongoDB

SLS requires MongoDB as a data store. Set the MongoDB hosts, MongoDB CA, credentials secret name, and authentication database in the LicenseService CR.
MongoDB certificates are required and need to be added as a list of aliases and PEM-formatted certificates representing a complete chain of trust.

```yaml
spec:
  mongo:
    configDb: admin
    nodes:
    - host: host1.domain.com
      port: 27017
    secretName: sls-mongo-credentials
    - alias: mongoca
      crt: |-
        -----BEGIN CERTIFICATE-----
        ...
        -----END CERTIFICATE-----
```

**Optionally:** You can override the default values for the MongoDB authentication mechanism (defaults to DEFAULT), retryable writes options (defaults to True), and database prefix (defaults to `<slsNamespace>_<instanceId>_`).

```yaml
spec:
  mongo:
    ...
    authMechanism: DEFAULT
    retryWrites: true
    dbPrefix: domain_sls
    certificates:
    - alias: mongoca
      crt: |-
        -----BEGIN CERTIFICATE-----
        ...
        -----END CERTIFICATE-----
```

## Domain

SLS can be configured to be externally accessible through a route by setting the domain property in the LicenseService CR. Set the domain if SLS is used by application suites that are installed in separate Red Hat OpenShift clusters.

```yaml
spec:
  domain: domain.com
```

## CA

SLS can be configured to use a provided CA keypair for generating certificates by adding the CA keypair to a secret in the SLS namespace and setting the CA keypair secret name in the LicenseService CR. SLS generates its own root CA if a CA keypair is not provided.

```yaml
spec:
  ca:
    secretName: ca-keypair
```

## Application Suite Configuration

Application suites such as IBM Maximo Application Suite, configure the SLS integration by completing a registration process with SLS.
The registration process adds the application suite to the SLS client registry and provisions an X.509 certificate for the application suite to use SLS APIs (SLS requires mutualTLS).

The registration process requires an SLS API URL, an SLS registration key, and an SLS CA certificate. All properties can be found in the SLS status and in the Suite Registration CM:

```sh
oc get -n ibm-sls cm sls-suite-registration -o yaml

kind: ConfigMap
apiVersion: v1
metadata:
  name: sls-suite-registration
  namespace: ibm-sls
data:
  url: <your-sls-api-url>
  registrationKey: <your-registration-key>
  ca: <your-sls-ca>
```

## Upgrades

SLS supports in-place upgrades for fixes and minor upgrades. Complete the backup procedure before you upgrade SLS.
Refer to the official Red Hat [documentation for upgrading operators installed using Operator Lifecycle Manager](https://access.redhat.com/documentation/en-us/openshift_container_platform/4.8/html/operators/administrator-tasks#olm-upgrading-operators).

## Rollback

SLS does not support downgrades as it is not supported by the Operator Lifecycle Manager. To rollback, reinstall SLS using the backup and restore procedure or contact IBM support for a potential hotfix.

## Backup

### Backup process:

1. Back up a snapshot of the mongo database (all collections)
2. Save the SLS CA keypair secret
3. Make a note of the `licenseId` and `registrationKey`:

```sh
oc get -n ibm-sls licenseservice/sls

NAME   VERSION   STATUS   INITIALIZED   LICENSEID      REGISTRATIONKEY                        AGE
sls    3.9.1     Ready    Initialized   0242ac110002   0121e6f8-a9ac-5d84-825f-ac455803d3c4   28d
```
### Restore process:

1. Restore the mongo database snapshot (all collections)
2. Restore the SLS CA keypair secret, set the `ca.secretName` value in the LicenseService CR
3. Create a secret that is called `sls-bootstrap` with the `licenseId` and `registrationKey` set:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: sls-bootstrap
stringData:
  licensingId: 0242ac110002
  registrationKey: 0121e6f8-a9ac-5d84-825f-ac455803d3c4
```
4. Reapply the LicenseService CR
5. Reupload the license file via the UI or create the `ibm-sls-{{ instanceId }}-entitlement` secret with the base64 encoded content of your SLS license/entitlement file under the `entitlement` key like the following:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: ibm-sls-sls-entitlement
data:
  entitlement: U0VSVkVSIHNscy1ybGtzL...
```
6. Re-register application suites

# Limitations

- The operator supports only single namespace deployment but multiple instances of the operator can be deployed in a single Red Hat OpenShift cluster.
- Multiple installations of the LicenseServer Instance cannot be deployed in the same namespace.

## Reason Codes

- **Ready** : Entitlement/config API status check succeeded
- **NotReady** :  Entitlement/config API status check failed
- **Initialized** : Installation has a valid entitlement file
- **MissingConfiguration** : Invalid entitlement file
- **TruststoreNotReady** : SLS Truststore is not ready
- **PodTemplatesValid** : Validation of podTemplates keys
