# Name

IBM Cloud Pak&reg; for AIOps Infrastruture Automation v4.4.0

# Introduction

## Details

Infrastructure automation is a standalone module within IBM Cloud Pak&reg; for AIOps. When you have a license for IBM Cloud Pak for AIOps, you are entitled to install and use Infrastructure Automation. Infrastructure Automation consists of these components (formerly part of IBM Cloud Pak&reg; for Multicloud Management):

Managed services and service catalog, previously called Terraform & Service Automation or IBM Cloud Automation Manager
Infrastructure management, previously called IBM Red Hat&reg; CloudForms.
Managed services provide the capability to automate provisioning of infrastructure and virtual machine applications using Terraform and Ansible. It includes supported versions of Terraform that works across multiple cloud environments with comprehensive IT workflow orchestration. Using out-of-box integration with Ansible Tower, workflows can interconnect Terraform provisioning templates with Ansible playbooks for configuration management, fully supporting infrastructure-as-code (IaC) and GitOps best practices.The service catalog allows authors administrators to publish services and end users to self-service provision infrastructure and applications.

## Features
Infrastructure management delivers the insight, control, compliance and automation enterprises need to address the challenges of managing hybrid cloud environments, which are far more complex than physical ones. This technology enables enterprises with existing virtual, baremetal and cloud infrastructures to improve visibility, control and compliance, and those just starting hybrid cloud deployments to build and operate a well-managed hybrid cloud infrastructure.

Infrastructure Automation enables IT Operations and Site Reliability Engineer (SRE) teams to use infrastructure as code practices to drive IT velocity and shift to the left of operations. With modernize infrastructure management, you can perform the following tasks:

Shorten the time to provision infrastructure (VMs, Cloud Services, Kubernetes) across on-premises, private, and public clouds
Create repeatable templates for common infrastructure requests
Enable self-service catalogs to avoid manual responses to tickets
Scale infrastructure automatically based on demand
Support day-2 operations including automated compliance
You can provision, run, and manage workloads on the infrastructure of your choice. IBM Cloud Pak for AIOps Infrastructure Automation is installed on Red Hat OpenShift&reg; Container Platform. For more information about the supported versions of Red Hat OpenShift Container Platform, see [Supported Red Hat OpenShift Container Platform versions](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/planning/supported_os.html).

# Details

## Prerequisites

The following prerequisites are required for a successful installation.

- A Red Hat OpenShift Container Platform cluster with persistent storage support. For more information on the cluster requirements, see [IBM Documentation: Planning System Requirements](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/planning/requirements_system.html).
- Openshift command line interface (`oc`) installed and able to communicate with the cluster. Cluster administrator access is required.

For more information on prerequisites, see IBM Documentation for [online](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/installing/prerequisites.html) and [airgap](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/installing/prerequisites_airgap.html) deployments.

### Resources Required
See [IBM Documentation: Hardware requirements](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/planning/requirements_hware_both.html) for detailed information.

> - You cannot change your selected size after deployment.
> - Multi-region and multi-zone clusters are not supported.

The minimum cluster requirements for a trial deployment are:
- Worker node count: 3
- vCPU: 48
- Memory (GB): 132
- CoreOS root disk (GB): 360
- Persistent storage (Gi): 671

# Installing (Guidance)

Ensure that you understand and have met the requirements explained under the [Prerequisites](#Prerequisites) topic.

Refer to the IBM Documentation for guidance on [IBM Documentation: Installing IBM Cloud Pak for AIOps](https://www.ibm.com/docs/en/cloud-paks/cloud-pak-watson-aiops/3.3.0?topic=installing-infrastructure-automation).

## Configuration

### Ingress Controller Config

Your OpenShift environment may need to be updated to allow network policies to function correctly. To determine if your OpenShift environment is affected, view the default ingresscontroller and locate the property `endpointPublishingStrategy.type`. If it is set to `HostNetwork`, the network policy will not work against routes unless the default namespace contains the selector label.

```
kubectl get ingresscontroller default -n openshift-ingress-operator -o yaml

  endpointPublishingStrategy:
    type: HostNetwork
```
To set the label via a patch of the default namespace run:

```
kubectl patch namespace default --type=json -p '[{"op":"add","path":"/metadata/labels","value":{"network.openshift.io/policy-group":"ingress"}}]'
```

### Network Policy for traffic between the Operator Lifecycle Manager and the CatalogSource service

To install IBM Cloud Pak for AIOps, the OpenShift Operator Lifecycle Manager (OLM) must be able to communicate with the IBM Cloud Pak for AIOps CatalogSource service. If your OpenShift cluster has network policies that restrict communication, you must create a network policy to allow communication between the OLM and the IBM Cloud Pak for AIOps CatalogSource service.

The following network policy when applied will allows traffic between the IBM Cloud Pak for AIOps installation namespace and all other namespaces.
Replace <namespace> with the IBM Cloud Pak for AIOps installation namespace.

```
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-all-egress-and-ingress
  namespace: <namespace>
spec:
  egress:
  - {}
  ingress:
  - {}
  podSelector: {}
  policyTypes:
  - Egress
  - Ingress
```

If you require a more restrictive network policy, then you can create a network policy that only allows traffic between the OLM namespace and the IBM Cloud Pak for AIOps installation namespace. For more information see [Red Hat OpenShift Documentation: About Network Policy](https://docs.openshift.com/container-platform/4.8/networking/network_policy/about-network-policy.html).

## Storage

You must create persistent storage prior to your installation of IBM Cloud Pak for AIOps on OpenShift.

For more information on storage requirements and the steps required to set up your storage, see [IBM Documentation: Storage considerations](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/planning/considerations_storage_ia.html).


## SecurityContextConstraints Requirements

This chart requires a SecurityContextConstraints(SCC) to be bound to the target service account groups prior to installation. All associated pods will have access to use this SCC. A SCC constrains the actions a pod can perform.

The IBM Cloud Pak for AIOps will utilize the Openshift Restricted SCC available out of the box. In addition, the following Custom SCCs are used.

#### Custom SecurityContextConstraints definition:

```
kind: SecurityContextConstraints
metadata:
  name: iaanyuid
readOnlyRootFilesystem: false
requiredDropCapabilities:
- MKNOD
runAsUser:
  type: RunAsAny
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret

```
  
## PodSecurityPolicy Requirements

#### Custom PodSecurityPolicy definition:  
```
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: cam-services-psp
spec:
  allowPrivilegeEscalation: false
  allowedCapabilities:
  - SETPCAP
  - AUDIT_WRITE
  - CHOWN
  - NET_RAW
  - DAC_OVERRIDE
  - FOWNER
  - FSETID
  - KILL
  - SETGID
  - SETUID
  - NET_BIND_SERVICE
  - SYS_CHROOT
  - SETFCAP
  fsGroup:
    ranges:
    - max: 11111
      min: 10001
    rule: MustRunAs
  readOnlyRootFilesystem: true
  requiredDropCapabilities:
  - MKNOD
  runAsUser:
    ranges:
    - max: 11111
      min: 10001
    rule: MustRunAsNonRoot
  seLinux:
    rule: RunAsAny
  supplementalGroups:
    ranges:
    - max: 11111
      min: 10001
    rule: MustRunAs
  volumes:
  - configMap
  - emptyDir
  - secret
  - persistentVolumeClaim
  - nfs
  - downwardAPI
  - projected
```  

## Limitations

* Platform limited, only supports `amd64` and `ppc64le` worker nodes.
* For an overview of known issues see the IBM Documentation topic for [IBM Documentation: Known issues and limitations](https://www.ibm.com/docs/en/SSJGDOB_3.3.0/about/known_issues.html).

## Documentation

* [IBM Documentation: IBM Cloud Pak for AIOps v3.3.0](https://www.ibm.com/docs/en/SSJGDOB_3.3.0).

