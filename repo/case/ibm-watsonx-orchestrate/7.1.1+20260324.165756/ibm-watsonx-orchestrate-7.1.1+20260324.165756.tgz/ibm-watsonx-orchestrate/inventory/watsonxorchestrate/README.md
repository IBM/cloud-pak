# IBM watsonx Orchestrate

This inventory item contains resources required to install the watsonx Orchestrate Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI) application of Kubernetes manifests in both an online and offline air-gapped environment.