# IBM watsonx Orchestrate

IBM&reg; watsonx Orchestrate

## Introduction

Use your time wisely. Streamline repetitive work so that you can focus on the work that matters.

IBM watsonx Orchestrate includes prebuilt connectors for common applications, such as Gmail and Microsoft Outlook. The software also includes a prebuilt catalog of skills. For example, users can use the chat interface to start skills that automate simple tasks, such as emailing coworkers, or complex tasks, such as creating cases in CRM platforms or managing talent acquisition processes.

## Link to external documentation

https://www.ibm.com/docs/SSQNUZ_4.8.x/svc-welcome/orchestrate.html
