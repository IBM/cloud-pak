# Name

IBM&reg; Integration Monitoring

# Introduction

IBM Cloud Pak for Integration end-to-end monitoring operator provides a way to deploy and manage end-to-end monitoring instances in a simple and consistent manner.
Setting up end-to-end transaction tracing for business transactions involving multiple capabilities like API Connect, App Connect, and IBM MQ. It helps users identify the root cause of delays and errors more quickly.

# What You Can Monitor

You can monitor cross-product transactions that involve the following products:
 - API Gateway instance for managed APIs
 - Event Gateway instance for integration workflows
 - Event Gateway Designer instance for no-code integration flows
 - Queue manager instance for secure and reliable message delivery
 - Integration runtime instance

For example, you can trace a transaction that flows from an API call through an integration flow to a message queue.


## Prerequisites

**Installing the operator**
- **Operator v12 channel:** Red Hat OpenShift version 4.14.0 or later, with 4.19.0 or later preferred.
- A user with the cluster administrator role.

**Creating an instance of the Platform UI with the operator**
- A user with the edit role or above for the namespace where the instance will be created.
- For online clusters, create a secret called `ibm-entitlement-key` in the namespace where the instance will be created. The secret must contain `cp` as the username, `cp.icr.io` as the docker server, and an entitlement key as the password. Get an entitlement key from the [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).
- For restricted environments, [configure the cluster for image mirroring](https://www.ibm.com/docs/en/cloud-paks/cp-integration/latest?topic=installing-in-air-gapped-environment).

## Resources Required
- The operator requests 1.7 CPU cores and 0.7 Gi memory.
- Each Platform UI requests 2.2 CPU cores and 4.6 Gi memory, but can be run with fewer resources with lower performance.
- CertManager is required for the IBM Opensearch Operator
- A RWO(ReadWriteOnce) storage class is required for the IBM Opensearch Operator.

## Installing
See the [Integration Monitoring IBM Documentation](https://ibm.biz/integration-documentation) for installation instructions.

# Configuration
See the [Integration Monitoring IBM Documentation](https://ibm.biz/integration-documentation) for configuration options.

### Limitations
- Only runs on amd64 architecture
- Only runs on Linux operating systems

### Red Hat OpenShift SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
- Both the operator and the instances of the Integration Monitoring run under Red Hat restricted SCC.

### Supported Versions
The following outlines which Platform UI versions are supported by each operator channel:
- **Operator v12 channel:** Supports versions 12.4.7. Supported architectures: amd64.

*Copyright IBM Corporation 2020-2022. All Rights Reserved.*
