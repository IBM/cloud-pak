#!/bin/bash

# Licensed Materials - Property of IBM
# Copyright IBM Corporation 2020. All Rights Reserved
# US Government Users Restricted Rights -
# Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# This is an internal component, bundled with an official IBM product.
# Please refer to that particular license for additional information.

# ---------- Command arguments ----------

# the CASE archive directory
CASE_ARCHIVE_DIR=

# the CASE archive name
CASE_ARCHIVE=

# dry-run mode
DRY_RUN="f"

# oc command
OC_CLI="oc"

# directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# k8s target namespace
NAMESPACE=

# ---------- Command variables ----------

# script version
VERSION=0.0.1

# --- licensekey command variables ---

# action for licensekey command
LICENSEKEY_ACTION=

# --- operator command variables ---

# Path to EDB CASE Archive
CASE_PATH=

# action for operator command
OPERATOR_ACTION=

# tolerance for CASE
TOLERANCE="0"

# ---------- Utility functions ----------

_log() {
  local dry_run_prefix
  if [[ "${DRY_RUN}" == "t" ]]; then
    dry_run_prefix="[dry-run] "
  fi
  echo "${dry_run_prefix}$*"
}

info() {
  _log "[INFO] $*"
}

die() {
  _log "[ERROR] $*"
  exit 1
}

retry() {
  local retries=$1
  shift

  if [[ "${DRY_RUN}" == "t" ]]; then
    info "Succeeded $*"
    return 0
  fi

  local count=0
  until "$@"; do
    exit=$?
    wait=10
    count=$(($count + 1))
    if [ $count -lt $retries ]; then
      info "Retry $count/$retries exited $exit, retrying in $wait seconds..."
      sleep $wait
    else
      info "Retry $count/$retries exited $exit, no more retries left."
      return $exit
    fi
  done
  return 0
}

_oc_apply() {
  local -a args=(
    "-n"
    "${NAMESPACE}"
  )
  if [[ "${DRY_RUN}" == "t" ]]; then
    args+=( "--dry-run=server" )
  fi
  $OC_CLI apply "${args[@]}" "$@"
}

_oc_delete() {
  local -a args=(
    "-n"
    "${NAMESPACE}"
    "--ignore-not-found"
  )
  if [[ "${DRY_RUN}" == "t" ]]; then
    args+=( "--dry-run=server" )
  fi
  $OC_CLI delete "${args[@]}" "$@"
}

_oc_get() {
  local -a args=(
    "-n"
    "${NAMESPACE}"
  )
  $OC_CLI get "${args[@]}" "$@"
}

# ---------- Command functions ----------

#
# Main function
#
main() {
    # run script
    run "$@"
}

#
# Parses the CLI arguments and run specified command
#
run() {
    if [[ "$#" == 0 ]]; then
        print_usage
        exit 1
    fi

    # process options
    while [[ "$1" != "" ]]; do
        case "$1" in
        licensekey)
            shift
            run_licensekey_command "$@"
            break
            ;;
        operator)
            shift
            run_operator_command "$@"
            break
            ;;
        -v | --version)
            print_version
            exit 1
            ;;
        -h | --help)
            print_usage
            exit 1
            ;;
        *)
            print_usage
            exit 1
            ;;
        esac
        shift
    done
}

#
# Prints usage menu
#
print_usage() {
    script_name=`basename ${0}`
    echo "Usage: ${script_name} [licensekey|operator]"
    echo ""
    echo "This tool helps installing EDB Cloud Native PostgreSQL Operator with proper license key set"
    echo ""
    echo "Options:"
    echo "   licensekey        Configure EDB license key"
    echo "   operator          Manage EDB Cloud Native PostgreSQL Operator"
    echo "   -v, --version     Print version information"
    echo "   -h, --help        Print usage information"
    echo ""
}

#
# Prints version
#
print_version() {
    echo "[INFO] Version ${VERSION}"
}

# ---------- License Key functions ----------

#
# Parses argument and run 'licensekey' command
#
run_licensekey_command() {
    if [[ "$#" == 0 ]]; then
        print_licensekey_usage
        exit 1
    fi

     # process options
    while [ "$1" != "" ]; do
        case "$1" in
        create)
            if [[ -n "$LICENSEKEY_ACTION" ]]; then
              print_licensekey_usage
              die "action [${LICENSEKEY_ACTION}] is already specified"
            fi
            LICENSEKEY_ACTION="create"
            ;;
        delete)
            if [[ -n "$LICENSEKEY_ACTION" ]]; then
              print_licensekey_usage
              die "action [${LICENSEKEY_ACTION}] is already specified"
            fi
            LICENSEKEY_ACTION="delete"
            ;;
        -n | --namespace)
            shift
            NAMESPACE="$1"
            ;;
        -d | --dry-run)
            DRY_RUN="t"
            ;;
        -h | --help)
            print_licensekey_usage
            exit 1
            ;;
        *)
            print_licensekey_usage
            exit 1
            ;;
        esac
        shift
    done

    if [[ -z "$LICENSEKEY_ACTION" ]]; then
        print_licensekey_usage
        die "Action is not specified"
    fi

    if [[ -z "$NAMESPACE" ]]; then
        print_licensekey_usage
        die "--namespace is not specified"
    fi

    if [[ "$LICENSEKEY_ACTION" == "create" ]]; then
        create_licensekey
    elif [[ "$LICENSEKEY_ACTION" == "delete" ]]; then
        delete_licensekey
    else
        die "Unknown action ${LICENSEKEY_ACTION}"
    fi
}

# Prints usage menu for 'licensekey' action
#
print_licensekey_usage() {
    script_name=`basename ${0}`
    echo "Usage: ${script_name} licensekey [create|delete] [OPTIONS]..."
    echo ""
    echo "Create/Delete EDB Cloud Native PostgreSQL license key"
    echo ""
    echo "Options:"
    echo "  -n, --namespace   NS    Namespace to [create|delete] license key secret"
    echo "  -d, --dry-run           Dry-run does not perform any actions to cluster"
    echo "  -h, --help              Print usage information"
    echo ""
}

# Create License key secret
# This function creates a k8s job that pulls the image containing license key
#   and create a k8s Job that creates a EDB Postgres config secret.
# The created secret becomes the default license key of Postgres Operator
create_licensekey() {
    echo "-------------Creating PostgreSQL Operator license key secret-------------"

    _oc_apply -f "${SCRIPT_DIR}/postgres/create-license-secret-job.yaml"

    if ! retry 30 _oc_get secret postgresql-operator-controller-manager-config; then
        die "Timeout waiting for Secret/postgresql-operator-controller-manager-config created. Check the status of Job/create-postgres-license-config"
    fi

    info "Done"
}

# Delete license key secret and the job that created the secret
delete_licensekey() {
    echo "-------------Deleting PostgreSQL Operator license key secret-------------"

    _oc_delete secret postgresql-operator-controller-manager-config
    _oc_delete -f "${SCRIPT_DIR}/postgres/create-license-secret-job.yaml"

    info "Done"
}

# ---------- Operator functions ----------

#
# Parses argument and run 'operator' command
#
run_operator_command() {
    if [[ "$#" == 0 ]]; then
        print_operator_usage
        exit 1
    fi

     # process options
    while [ "$1" != "" ]; do
        case "$1" in
        install)
            if [[ -n "$OPERATOR_ACTION" ]]; then
              print_operator_usage
              die "action [${OPERATOR_ACTION}] is already specified"
            fi
            OPERATOR_ACTION="install"
            ;;
        uninstall)
            if [[ -n "$OPERATOR_ACTION" ]]; then
              print_operator_usage
              die "action [${OPERATOR_ACTION}] is already specified"
            fi
            OPERATOR_ACTION="uninstall"
            ;;
        -c | --case-path)
            shift
            CASE_PATH="$1"
            ;;
        -n | --namespace)
            shift
            NAMESPACE="$1"
            ;;
        -t | --tolerance)
            shift
            TOLERANCE="$1"
            ;;
        -d | --dry-run)
            DRY_RUN="t"
            ;;
        -h | --help)
            print_operator_usage
            exit 1
            ;;
        *)
            print_operator_usage
            exit 1
            ;;
        esac
        shift
    done

    if [[ -z "$OPERATOR_ACTION" ]]; then
        print_operator_usage
        die "Action is not specified"
    fi

    if [[ -z "$NAMESPACE" ]]; then
        print_operator_usage
        die "--namespace is not specified"
    fi

    if [[ "$OPERATOR_ACTION" == "install" ]]; then
        install_operator
    elif [[ "$OPERATOR_ACTION" == "uninstall" ]]; then
        uninstall_operator
    else
        die "Unknown action ${OPERATOR_ACTION}"
    fi
}

# Prints usage menu for 'operator' action
#
print_operator_usage() {
    script_name=`basename ${0}`
    echo "Usage: ${script_name} operator [install|uninstall] [OPTIONS]..."
    echo ""
    echo "Install/Uninstall EDB Cloud Native PostgreSQL Operator"
    echo ""
    echo "Options:"
    echo "  -n, --namespace   NS    Namespace to [create|delete] license key secret"
    echo "  -d, --dry-run           Dry-run does not perform any actions to cluster"
    echo "  -c, --case-path   PATH  Path to EDB Cloud Native PostgreSQL CASE"
    echo "  -t, --tolerance   [0|1] Tolerance value for running CASE"
    echo "  -h, --help              Print usage information"
    echo ""
}

# Install PostgreSQL operator using specified CASE launcher script
install_operator() {
    echo "-------------Installing PostgreSQL Operator-------------"
    local -a args=()
    if [[ "$DRY_RUN" == "t" ]]; then
      args+=(
          "--args"
          "--dryRun"
      )
    fi

    cloudctl case launch \
       --case "${CASE_PATH}" \
       --tolerance "${TOLERANCE}" \
       --inventory ibmCloudNativePostgresqlOperator \
       --action install-catalog \
       --namespace "$NAMESPACE" \
       "${args[@]}"

    cloudctl case launch \
       --case "${CASE_PATH}" \
       --tolerance "${TOLERANCE}" \
       --inventory ibmCloudNativePostgresqlOperator \
       --action install \
       --namespace "$NAMESPACE" \
       "${args[@]}"

    info "Done"
}

# Uninstall PostgreSQL operator using specified CASE launcher script
uninstall_operator() {
    echo "-------------Uninstalling PostgreSQL Operator-------------"
    local -a args=()
    if [[ "$DRY_RUN" == "t" ]]; then
      args+=(
          "--args"
          "--dryRun"
      )
    fi
    cloudctl case launch \
       --case "${CASE_PATH}" \
       --tolerance "${TOLERANCE}" \
       --inventory ibmCloudNativePostgresqlOperator \
       --action uninstall \
       --namespace "$NAMESPACE" \
       "${args[@]}"

    info "Done"
}

# --- Run ---

main $*
