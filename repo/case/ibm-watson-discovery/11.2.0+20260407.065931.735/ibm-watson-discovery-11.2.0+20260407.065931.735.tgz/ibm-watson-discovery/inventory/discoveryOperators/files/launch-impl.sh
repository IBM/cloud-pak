#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#
# Script install Watson Discovery Operator through the Operator Lifecycle Manager (OLM)
# application of kubernetes manifests in both an online and offline airgap environment.  This script can be invoked using
# `cloudctl`, a command line tool to manage Container Application Software for Enterprises (CASEs), or directly on an
# uncompressed CASE archive.  Running the script through `cloudctl case launch` has added benefit of pre-requisite validation
# and verification of integrity of the CASE.  Cloudctl download and usage istructions are available at [github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli).
#
# Pre-requisites:
#   oc installed
#   CASE tgz downloaded & uncompressed
#   authenticated to cluster
#
# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
helmCLI="helm"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="install-operator-native"
caseJsonFile=""
casePath="${scriptDir}/../../.."
caseName="ibm-zen-operator-case"
inventory="zenOperatorSetup"
instance="wd"

# - optional parameter / argument defaults
dryRun=""
kubeDryRun=""
deleteCRDs=0
namespace=""
operator_namespace=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
cr_system_status="betterThanYesterday"
recursive_action=0

# - variables specific to catalog/operator installation
caseCatalogName="ibm-zen-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="v1.0"
catalogDigest=":latest"
declare -a case_dependencies=(
    "ibm-model-train-operator"
    "ibm-cloud-native-postgresql"
    "ibm-elasticsearch-operator"
    "ibm-rabbitmq-operator"
    "ibm-watson-gateway-operator"
    "ibm-minio-operator"
    "ibm-etcd-operator"
)

# - variables specific to operator native installation
operatorHelmRelease="wd"

# - additional variables
storageclass=""
cr_patch=()
purge="false"
acceptLicense="false"
wait_completion="false"
deploymentType=""
valuesOverrideFile=""

# - PVC labels
common_label="app.kubernetes.io/name in (discovery, ${instance})"
declare -a pvc_labels=(
    "${common_label},tenant=${instance}"
    "etcd_cluster=${instance}-discovery-etcd" # for label change on Etcd 4.0.4. Should be removed if it was fixed before release.
    "${common_label},release=${instance}-rabbitmq" # RabbitMQ
    "${common_label},release=${instance}-minio" # MinIO
    "${common_label},app.kubernetes.io/managed-by=ibm-elasticsearch" # for ElasticSearch 4.0.5 or later
    "${common_label},k8s.enterprisedb.io/cluster=${instance}-discovery-cn-postgres" # Delete postgres pvc for oadp restore
)

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="
  --tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}

OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}
   --dryRun                    : print the actions that would be taken and exit without writing to the destinations

 ARGS per Action:
    configure-creds-airgap
      --registry               : source/target container image registry (required)
      --user                   : login user name for the container image registry (required)
      --pass                   : login password for the container image registry (required)

    configure-cluster-airgap
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory
      --registry               : target container image registry (required)

    configure-cluster
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry (required)

    image-info                 : list image registries and namespaces used in mirroring
      --inputDir               : path to saved CASE directory (required)

    mirror-images
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)
      --fromRegistry           : override the source image registry in the CASE
      --registry               : target container image registry (required)
      --chunks                 : mirror the images in batches with a given size. Default is 100
      --groups                 : list of image groups to mirror
      --skipDelta              : copy all of the images and not just the delta

    install
      --registry               : source/target container image registry
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --secret                 : name of existing image pull secret for the container image registry
      --groups                 : list of image groups to install
      --operatorNamespace      : namespace where operators are deployed (optional, default: ${namespace})

    install-catalog:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
      --groups                 : list of image groups to filter catalog

    install-operator:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --channelName            : name of channel for subscription (packagemanifest default used if not specified)
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)
      --operatorNamespace      : namespace where operators are deployed (optional, default: ${namespace})

    install-operator-native:
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if pass specified) (not supported)
      --pass                   : login password for the container image registry (required if user specified) (not supported)
      --recursive              : recursively install dependent catalogs (not supported)
      --inputDir               : path to saved CASE directory ( required if --recursive is set) (not supported)
      --groups                 : list of image groups to install (not supported)
      --values                 : override values for operator Helm chart
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --wait                   : if set, wait for operator deployment to be ready

    uninstall                  : uninstall the product

    uninstall-catalog          : uninstalls the catalog source and operator group
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)

    uninstall-operator         : delete the operator deployment via OLM
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --recursive              : recursively uninstall dependent operator CSVs
      --operatorNamespace      : namespace where operators are deployed (optional, default: ${namespace})

    uninstall-operator-native  : deletes the operator deployment via native way
      --deleteCRDs             : deletes CRD's associated with this operator (if not set, crds won't get deleted)
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)

    apply-custom-resources     : creates the sample custom resource
      --registry               : container image registry pulled from
      --secret                 : name of existing image pull secret for the container image registry
      --storageclass           : storage class to use
      --deploymentType         : size of application to be deployed. [Development|Production]
      --cr-patch               : patch YAML file path to override default spec
      --acceptLicense          : indicates have read and agree to license agreements.
      --wait                   : wait for CR status gets ready

    delete-custom-resources    : deletes the same custom resource
      --purge                  : delete all resources related to the custom resource e.g., pvc

    init-registry              : configure a local docker registry with self-sign certificate
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --subject                : self-sign TLS certificate subject
      --registry               : IP or FQDN for the docker registry ( default: $(hostname -f))
      --clean                  : clean up all existing repositories data


    start-registry             : start a local docker registry container
      --port                   : registry service port (default: 5000 )
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --engine                 : container engine to run the container (docker or podman)
      --image                  : docker registry image (default: docker.io/library/registry:2.6)

    stop-registry              : stop a local docker registry container
      --engine                 : container engine to run the container (docker or podman)

    create-postgres-licensekey : creates the license key secret for PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations

    delete-postgres-licensekey : deletes the license key secret for PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations

    install-postgres-operator  : installs PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)

    uninstall-postgres-operator: Uninstalls PostgreSQL Operator
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ----- Actions -----
# Override default implementation to support custom actions
# custom actions:
# - create-postgres-licensekey
# - delete-postgres-licensekey
# - install-postgres-operator
# - uninstall-postgres-operator
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    configureCluster)
        configure_cluster
        ;;
    configureClusterAirgap)
        configure_cluster_airgap
        ;;
    configureCredsAirgap)
        configure_creds_airgap
        ;;
    install)
        install
        ;;
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    installOperatorNative)
        install_operator_native
        ;;
    imageInfo)
        image_info
        ;;
    mirrorImages)
        mirror_images
        ;;
    uninstall)
        uninstall
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    uninstallOperatorNative)
        uninstall_operator_native
        ;;
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    initRegistry)
        init_registry
        ;;
    startRegistry)
        start_registry
        ;;
    stopRegistry)
        stop_registry
        ;;
    createPostgresLicensekey)
        create_postgres_licensekey
        ;;
    deletePostgresLicensekey)
        delete_postgres_licensekey
        ;;
    installPostgresOperator)
        install_postgres_operator
        ;;
    uninstallPostgresOperator)
        uninstall_postgres_operator
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --storageclass)
        idx=$((idx + 1))
        v="${arr[${idx}]}"
        storageclass=${v}
        ;;
    --cr-patch)
        idx=$((idx + 1))
        v="${arr[${idx}]}"
        cr_patch+=("${v}")
        ;;
    --operatorNamespace)
        idx=$((idx + 1))
        v="${arr[${idx}]}"
        operator_namespace=${v}
        ;;
    --deploymentType)
        idx=$((idx + 1))
        v="${arr[${idx}]}"
        deploymentType=${v}
        ;;
    --values)
        idx=$((idx + 1))
        v="${arr[${idx}]}"
        valuesOverrideFile=${v}
        ;;
    --acceptLicense)
        acceptLicense="true"
        ;;
    --purge)
        purge="true"
        ;;
    --wait)
        wait_completion="true"
        ;;
    esac
}

# ***** ARGUMENT CHECKS *****

# Validates that the required parameters were specified for script invocation
check_cli_args() {
    # Verify required parameters were specifed and are valid (including environment setup)
    # - case path
    [[ -z "${casePath}" ]] && { err_exit "The case path parameter was not specified."; }
    [[ ! -f "${casePath}/case.yaml" ]] && { err_exit "No case.yaml in the root of the specified case path parameter."; }

    # Verify kubernetes connection and namespace
    # skip this check for certain actions
    skip_actions="imageInfo mirrorImages configureCredsAirgap initRegistry startRegistry stopRegistry"
    if [[ "$skip_actions" != *$action* ]]; then
        check_kube_connection
        check_kube_namespace
    fi

    # Set another dryrun param
    if [[ -n "$dryRun" ]]; then
        kubeDryRun="--dry-run=server"
    fi

    # Defaults operator namespace to namespace
    if [[ -z "$operator_namespace" ]]; then
        operator_namespace="$namespace"
    fi
}

# TODO: stop overriding the function once dependency operators catalog can be installed using dependency CASEs action
# Validates that the required args were specified for install action
validate_install_args() {
    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    # Verify arguments required per install method were provided
    echo "Checking install arguments for ${mode:-install}"

    # if [[ ${recursive_action} -eq 1 && -z "${inputcasedir}" ]]; then
    #     err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
    #     print_usage 1
    # fi

    # Validate secret arguments provided are valid combination and
    #   either create or check for existence of secret in cluster.
    if [[ -n "${registry}" && -z "${user}" && -z "${pass}" && -z "${secret}" ]]; then
        # registry is provided, but not a user/pass/secret, continue
        :
    elif [[ -n "${registry}" || -n "${user}" || -n "${pass}" ]]; then
        check_secret_params
        set -e
        $kubernetesCLI create secret docker-registry "${secret}" \
            --docker-server="${registry}" \
            --docker-username="${user}" \
            --docker-password="${pass}" \
            --docker-email="${user}" \
            --namespace "${namespace}"
        set +e
    elif [[ -n ${secret} ]]; then
        if ! $kubernetesCLI get secrets "${secret}" -n "${namespace}" >/dev/null 2>&1; then
            err "Secret $secret does not exist, either create one or supply additional registry parameters to create one"
            print_usage 1
        fi
    fi
}

validate_install_catalog() {

    # using a mode flag to share the validation code between install and uninstall
    local mode="$1"

    _log "Checking arguments for install-catalog action"

    if [[ ${recursive_action} -eq 1 && -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter when '--recursive' is set"
        print_usage 1
    fi
}

validate_apply_custom_resources_args() {
    # Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${storageclass}" ]] && {
        foundError=1
        err "'--storageclass' must be specified with the '--args' parameter"
    }
    [[ "${acceptLicense}" == "false" ]] && {
        foundError=1
        err "'--acceptLicense' must be specified to indicate have read and agree to license agreements."
    }

    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}
# ***** END ARGUMENT CHECKS *****

# ***** UTILS *****

assert() {
    testname="$1"
    got=$2
    want=$3
    if [ "$got" != "$want" ]; then
        err_exit "got $got, but want $want : ${testname} failed"
    fi
}

use_kubectl() {
  kubernetesCLI="kubectl"
}

_oc_apply() {
  $kubernetesCLI apply ${kubeDryRun} "$@"
}

_oc_delete() {
  $kubernetesCLI delete ${kubeDryRun} --ignore-not-found "$@"
}

_helm() {
  local -a args=(
    "--namespace"
    "${namespace}"
  )
  if [[ -n "${dryRun}" ]]; then
    args+=( "--dry-run" )
  fi
  $helmCLI "$@" "${args[@]}"
}

_log() {
  local dry_run_prefix
  if [[ -n "${dryRun}" ]]; then
    dry_run_prefix="[dry-run]"
  fi
  echo "${dry_run_prefix} $*"
}

## Got this from: https://gist.github.com/sj26/88e1c6584397bb7c13bd11108a579746
# Retry a command up to a specific numer of times until it exits successfully,
# with exponential back off.
#
#  $ retry 5 echo Hello
#  Hello
#
#  $ retry 5 false
#  Retry 1/5 exited 1, retrying in 1 seconds...
#  Retry 2/5 exited 1, retrying in 2 seconds...
#  Retry 3/5 exited 1, retrying in 4 seconds...
#  Retry 4/5 exited 1, retrying in 8 seconds...
#  Retry 5/5 exited 1, no more retries left.
#
function retry {
  local retries=$1
  shift

  if [[ -n "${dryRun}" ]]; then
    _log "Succeeded $*"
    return 0
  fi

  local count=0
  until "$@"; do
    exit=$?
    wait=10
    count=$(($count + 1))
    if [ $count -lt $retries ]; then
      _log "Retry $count/$retries exited $exit, retrying in $wait seconds..."
      sleep $wait
    else
      _log "Retry $count/$retries exited $exit, no more retries left."
      return $exit
    fi
  done
  return 0
}

## Substitute the template variables with specified values
# args:
#   $1: path to template source file
#       template variable must be the form of {{ variable }}
#   ...: "key=value" form of template values
# example:
#    render_resource /path/to/resource.yaml registry=my-registry
#
render_resource() {
    local file="$1"
    shift
    local args=( "$@" )

    if [ -z "$file" ]; then
      err_exit "render source file is not specified in render_resource function"
    fi

    local -a default_args=(
      "namespace=${namespace}"
      "instance=${instance}"
    )

    local command=""
    for arg in "${default_args[@]}" "${args[@]}"; do
        local key value
        IFS="=" read -r key value <<< "$arg"
        command="${command}s|{{ ${key} }}|${value}|g;"
    done
    command="${command::-1}"

    sed -e "$command" "$file"
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-cloud-native-postgresql)
        echo "ibmCloudNativePostgresqlOperator"
        return 0
        ;;
    ibm-elasticsearch-operator)
        echo "ibmElasticsearchOperatorSetup"
        return 0
        ;;
    ibm-rabbitmq-operator)
        echo "ibmRabbitmqOperatorSetup"
        return 0
        ;;
    ibm-watson-gateway-operator)
        echo "ibmWatsonGatewayOperatorSetup"
        return 0
        ;;
    ibm-minio-operator)
        echo "ibmMinioOperatorSetup"
        return 0
        ;;
    ibm-etcd-operator)
        echo "ibmEtcdOperatorSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}
# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

get_op_cli_resources_dir() {
  echo -n "${casePath}"/inventory/"${inventory}"/files/op-cli
}

get_op_cli_operator_chart_path() {
  mapfile -t chart_paths < <(find "$(get_op_cli_resources_dir)/chart" -maxdepth 1 -name "*.tgz")
  if [[ "${#chart_paths[@]}" != "1" ]]; then
    err_exit "Unexpected number of Helm chart files found: ${chart_paths[*]}"
  fi
  local chart_path="${chart_paths[0]}"
  echo -n "${chart_path}"
}

# ***** END UTILS *****

# ***** ACTIONS *****

# ----- INSTALL ACTIONS -----

install_dependent_catalogs() {
    echo "-------------Installing dependent catalogs-------------"
    for dep in "${case_dependencies[@]}"; do
	      local dep_case
        dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        local install_catalog_args="--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }"
        if [[ -n ${registry} ]]; then
            install_catalog_args="${install_catalog_args} --registry ${registry}"
        fi
        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${install_catalog_args}" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the catalog source and operator group
install_catalog() {
    echo "-------------Installing catalog source-------------"
    validate_install_catalog "install"

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # setup pull secret for the default service account in openshift-marketplace
    if [[ "$secret" != "" ]]; then
       $kubernetesCLI get secret "${secret}" -n "${namespace}" --export -o yaml | _oc_apply -n openshift-marketplace -f -
       if [[ -z "${dryRun}" ]]; then
          $kubernetesCLI secrets link serviceaccount/default "${secret}" --for=pull -n openshift-marketplace
       fi
    fi

    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    # Apply yaml files manipulate variable input as required
    if [[ -z "${registry}" ]]; then
        _oc_apply -f "${catsrc_file}"
    else
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
        _log "orig - ${catsrc_image_orig}"
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
        _log "mod - ${catsrc_image_mod}"
        # apply catalog source
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | _oc_apply -f -
    fi

    _log "Wait for package manifests available"
    if ! retry 30 $kubernetesCLI get packagemanifests ibm-watson-discovery-operator; then
      err_exit "Timeout: Could not find packagemanifests/ibm-watson-discovery-operator"
    fi
}

_exists_current_csv() {
    if [ -z "$(_get_current_csv "$@")" ]; then
        return 1
    fi
}

_get_current_csv() {
  $kubernetesCLI get -n "${operator_namespace}" "$@" -o jsonpath='{.status.currentCSV}'
}

_is_csv_phase_succeeded() {
    if [ "$($kubernetesCLI get -n "${operator_namespace}" ClusterServiceVersion "$@" -o jsonpath='{.status.phase}')" != "Succeeded" ]; then
        return 1
    fi
}

# Install utilizing default OLM method
install_operator() {

    validate_install_args

    echo "-------------Installing operators via OLM-------------"

    install_catalog

    _oc_apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n "${operator_namespace}"
    if [[ "$secret" != "" ]]; then
        if [[ -z "${dryRun}" ]]; then
            $kubernetesCLI secrets link serviceaccount/discovery-operator-sa "${secret}" --for=pull -n "${operator_namespace}"
        fi
    fi

    _log "Installing Watson Discovery Operator"
    _oc_apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/subscription.yaml -n "${operator_namespace}"

    _log "Wait for subscription to complete"
    if ! retry 30 _exists_current_csv -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/subscription.yaml; then
      _debug_olm_status
      err_exit "Timeout: Could not find ClusterServiceVersion for ibm-watson-discovery-operator"
    fi

    local csv
    csv=$(_get_current_csv -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/subscription.yaml)
    if ! retry 30 _is_csv_phase_succeeded "$csv"; then
      _log "Retry max count exceeded. Dump debug info..."
      _debug_olm_status
      err_exit "Timeout: Could not verify ClusterServiceVersion for ibm-watson-discovery-operator is in 'Succeeded' phase"
    fi

    _log "Completed installing Watson Discovery Operator"

    # restart pod to refresh secret
    # oc delete pod -l 'app.kubernetes.io/component=operator,app.kubernetes.io/name=discovery'
}

_debug_olm_status() {
    _log "OLM resources status in ${operator_namespace}:"
    $kubernetesCLI get -n "${operator_namespace}" subscription,installplan,csv,operatorgroup,pod
    _log "OLM resources status in openshift-marketplace:"
    $kubernetesCLI get -n "openshift-marketplace" subscription,installplan,csv,operatorgroup,pod

    _log "Dump OLM resource manifests in /tmp/watson-discovery-install-diagnose"
    if [[ -d /tmp/watson-discovery-install-diagnose ]]; then
      rm -r /tmp/watson-discovery-install-diagnose
    fi
    mkdir -p /tmp/watson-discovery-install-diagnose
    $kubernetesCLI get -n "${operator_namespace}" subscription,installplan,csv,operatorgroup,pod -o yaml > /tmp/watson-discovery-install-diagnose/olm-status.yaml
    $kubernetesCLI get -n "openshift-marketplace" pods -o yaml > /tmp/watson-discovery-install-diagnose/openshift-marketplace-pod-status.yaml
}

_exists_discovery_instance() {
    if $kubernetesCLI get -n "$namespace" WatsonDiscovery ${instance}; then
        return 0
    fi
    return 1
}

_is_discovery_pvcs_removed() {
    for pvc_label in "${pvc_labels[@]}" ; do
        if [[ $($kubernetesCLI get -n "$namespace" pvc -l "${pvc_label}" | wc -l) -gt 1 ]]; then
            return 1
        fi
    done
    return 0
}

_is_discovery_ready() {
    ready_status=$($kubernetesCLI -n "${namespace}" get WatsonDiscovery "$instance" -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}')
    updating_status=$($kubernetesCLI -n "${namespace}" get WatsonDiscovery "$instance" -o jsonpath='{.status.conditions[?(@.type=="Updating")].status}')
    if [[ "$ready_status" == "True" && "$updating_status" == "False" ]]; then
        return 0
    fi
    return 1
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"

    if ! _exists_discovery_instance; then
        _log "Verifying Discovery PVCs are not present in namespace"
        if ! _is_discovery_pvcs_removed; then
            err_exit "Found existing PVCs belonging to Discovery, please verify and remove prior to creating new WatsonDiscovery CR"
        fi
    fi

    validate_apply_custom_resources_args

    local -a render_args=(
        "storageclass=${storageclass}"
        "accept_license=${acceptLicense}"
    )
    local tmp_cr_path="/tmp/watson-discovery.yaml"

    cp "${casePath}"/inventory/"${inventory}"/files/deploy/install/watson-discovery.yaml "${tmp_cr_path}"

    if [ -z "$registry" ]; then
        sed -i -e "/dockerRegistryPrefix/d" "${tmp_cr_path}"
    else
        render_args+=( "registry=${registry}" )
    fi
    if [ -z "$secret" ]; then
        sed -i -e "/imagePullSecret/d" "${tmp_cr_path}"
    else
        render_args+=( "image_pull_secret=${secret}" )
    fi
    if [ -z "$deploymentType" ]; then
        sed -i -e "/deploymentType/d" "${tmp_cr_path}"
    else
        render_args+=( "deployment_type=${deploymentType}" )
    fi

    render_resource \
        "${tmp_cr_path}" "${render_args[@]}" \
        | _oc_apply -n "${namespace}" -f -

    for patch in "${cr_patch[@]}"; do
      $kubernetesCLI patch ${kubeDryRun} -n "${namespace}" WatsonDiscovery "${instance}" --type=merge --patch "$(cat "${patch}")"
    done

    if [[ "$wait_completion" == "true" ]]; then
        _log "Wait for WatsonDiscovery CR status to be ready"
        sleep 30
        if ! retry 720 _is_discovery_ready; then
          err_exit "Timeout: Could not verify the readiness of WatsonDiscovery CR"
        fi

        _log "WatsonDiscovery instance ${instance} is now ready"
        if [[ -z "${dryRun}" ]]; then
          $kubernetesCLI get -n "$namespace" WatsonDiscovery "${instance}"
        fi
    fi
}

_is_discovery_pods_removed() {
    if [[ $($kubernetesCLI get -n "$namespace" pods -l "icpdsupport/addOnId=discovery,tenant=${instance}" | wc -l) -eq 0 ]]; then
        return 0
    fi
    return 1
}

_force_delete_resources_restored_by_oadp() {
    local resources="deployment,pod,role,rolebinding,secret,service,serviceaccount,statefulset,watsongateway,miniocluster,rabbitmqclusters.rabbitmq.opencontent.ibm.com,elasticsearchcluster,cluster,etcdcluster"
    local label="velero.io/restore-name,app.kubernetes.io/instance=${instance}"
    # Check if there is any resources restored by oadp
    if [ -n "$(oc get -n "${namespace}" "${resources}" -l "${label}")" ] ; then
        # Force delete discovery component because some of them are not deleted by GC
        local discovery_components=$(oc get crd -l "app.kubernetes.io/name=discovery" -o jsonpath='{.items[*].metadata.name}')
        for comp in ${discovery_components}
        do
            _oc_delete "${comp}" ${instance} -n "${namespace}"
        done
        # Delete resources restored by oadp
        _oc_delete "${resources}" -l "${label}" -n "${namespace}"
        # Some of secret don't have any label, so we have to delete them directly...
        local secrets=(
            "${instance}-discovery-cert-manager-tls"
            "${instance}-discovery-cn-postgres-ca"
            "${instance}-discovery-cn-postgres-replication"
            "${instance}-discovery-watson-gateway-gw-instance"
        )
        _oc_delete secret "${secrets[@]}" -n "${namespace}"
    fi
}

delete-custom-resources() {
    echo "-------------Deleting custom resources-------------"

    _oc_delete WatsonDiscovery "${instance}" -n "${namespace}"

    _log "Wait for managed resources to be removed"
    retry 30 _is_discovery_pods_removed

    # OADP restore removes owner references from restored resources.
    # Delete restored resources since they are not deleted by GC.
    _force_delete_resources_restored_by_oadp

    # TLS secret created by Cert Manager is not removed by GC
    _oc_delete secret "${instance}-discovery-cert-manager-tls" -n "${namespace}"

    if [[ "$purge" == "true" ]]; then
        _log "--purge option is specified. Deleting PVC resources"
        for pvc_label in "${pvc_labels[@]}" ; do
            _oc_delete -n "$namespace" pvc -l "${pvc_label}"
        done
    fi
}

# do everything needed for deploying a Watson Discover instance
install() {
    echo "-------------Installing Watson Discovery-------------"
    install_operator
    apply_custom_resources
}

# Operator will be left as other instances could be remaining
uninstall() {
    echo "-------------Uninstalling Watson Discovery-------------"
    delete-custom-resources
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "-------------Uninstalling dependent catalogs-------------"
    local dep_case=""
    for dep in "${case_dependencies[@]}"; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        local uninstall_catalog_args="--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }"
        if [[ -n ${registry} ]]; then
            uninstall_catalog_args="${uninstall_catalog_args} --registry ${registry}"
        fi
        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "${uninstall_catalog_args}" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "-------------Uninstalling catalog-------------"
    _oc_delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml

    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi
}

_uninstall_dependent_operators() {
    local -a names_grep_arg=(
        "-e" "cloud-native-postgresql"
        "-e" "watson-gateway" # Watson Gateway Operator
        "-e" "ibm-elasticsearch-operator"
        "-e" "ibm-etcd-operator"
        "-e" "ibm-minio-operator"
        "-e" "ibm-rabbitmq-operator"
        "-e" "model-train-operator"
    )
    dependency_subscriptions=$($kubernetesCLI get -n "${operator_namespace}" subscription -o name | grep "${names_grep_arg[@]}")
    if [[ -n "${dependency_subscriptions}" ]]; then
      _oc_delete -n "${operator_namespace}" ${dependency_subscriptions}
    fi

    dependency_csvs=$($kubernetesCLI get -n "${operator_namespace}" clusterserviceversion -o name | grep "${names_grep_arg[@]}")
    if [[ -n "${dependency_csvs}" ]]; then
      _oc_delete -n "${operator_namespace}" ${dependency_csvs}
    fi
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling Operators-------------"

    _oc_delete -n "${operator_namespace}" -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/subscription.yaml
    # cluster service version is not garbage collected. Need to delete manually
    local discovery_csv
    if [[ -z "${dryRun}" ]]; then
        discovery_csv="$(oc get csv -n "${operator_namespace}" -o name | grep ibm-watson-discovery-operator)"
    else
        discovery_csv="clusterserviceversion.operators.coreos.com/ibm-watson-discovery-operator.v0.0.0"
    fi
    if [[ -n "${discovery_csv}" ]]; then
        _oc_delete -n "${operator_namespace}" "$discovery_csv"
    fi

    if [[ ${recursive_action} -eq 1 ]]; then
        _log "Uninstalling dependent operators"
        _uninstall_dependent_operators
    fi

}

delete_custom_resources() {
     echo "-------------Uninstall custom resources-------------"
     _oc_delete -n "${namespace}" WatsonDiscovery/wd
}

# ----- Install Operator Native Actions (Installation without OLM) -----

install_operator_native() {
    echo "-------------Installing Watson Discovery Operator -------------"
    # use kubectl instead of oc to make it work with vanilla Kubernetes
    use_kubectl

    # rbac - Grant cluster role to service account (namespace-scope) to watch all namespaces
    _oc_apply -f "$(get_op_cli_resources_dir)/rbac/cluster_role.yaml"
    _oc_apply -n "${namespace}" -f "$(get_op_cli_resources_dir)/rbac/service_account.yaml"
    render_resource "$(get_op_cli_resources_dir)/rbac/cluster_role_binding.yaml" | _oc_apply -f -

    # crd - Need to disable validation as custom tags for Discovery makes validation fail
    _oc_apply -f "$(get_op_cli_resources_dir)/crd" --validate=false

    local chart
    chart="$(get_op_cli_operator_chart_path)"
    _log "Installing Watson Discovery Operator Helm chart: ${chart}"

    local -a flags=(
        "--install"
        "--history-max"
        "3"
    )
    if [[ "$wait_completion" == "true" ]]; then
        flags+=( "--wait" )
    fi
    if [[ -n "${valuesOverrideFile}" ]]; then
        flags+=( "--values" "${valuesOverrideFile}" )
    fi
    if [[ -n "${secret}" ]]; then
        flags+=( "--set" "operator.image.pullSecret=${secret}" )
    fi
    if [[ -n "${registry}" ]]; then
        flags+=( "--set" "global.dockerRegistryPrefix=${registry}" )
    fi

    _helm upgrade \
        "${operatorHelmRelease}" \
        "${chart}" \
        "${flags[@]}"
}

uninstall_operator_native() {
    echo "-------------Uninstalling Watson Discovery Operator -------------"
    # use kubectl instead of oc to make it work with vanilla Kubernetes
    use_kubectl

    local chart
    chart="$(get_op_cli_operator_chart_path)"
    _log "Uninstalling Watson Discovery Operator Helm chart: ${chart}"

    local -a flags=()
    _helm uninstall \
        "${operatorHelmRelease}" \
        "${flags[@]}"

    # rbac - Grant cluster role to service account (namespace-scope) to watch all namespaces
    _oc_delete -f "$(get_op_cli_resources_dir)/rbac/cluster_role.yaml"
    _oc_delete -n "${namespace}" -f "$(get_op_cli_resources_dir)/rbac/service_account.yaml"
    render_resource "$(get_op_cli_resources_dir)/rbac/cluster_role_binding.yaml" | _oc_delete -f -

    _oc_delete -f "$(get_op_cli_resources_dir)/crd"
}

# ----- Custom Postgres Actions -----
create_postgres_licensekey() {
  local -a args=(
      "--namespace"
      "$namespace"
  )
  if [[ -n "${dryRun}" ]]; then
      args+=(
          "--dry-run"
      )
  fi
  "${scriptDir}/postgres.sh" licensekey create "${args[@]}"
}

delete_postgres_licensekey() {
  local -a args=(
      "--namespace"
      "$namespace"
  )
  if [[ -n "${dryRun}" ]]; then
      args+=(
          "--dry-run"
      )
  fi
  "${scriptDir}/postgres.sh" licensekey delete "${args[@]}"
}

validate_postgres_operator_command_arg() {
    if [[ -z "${inputcasedir}" ]]; then
        err "'--inputDir' must be specified with the '--args' parameter"
        print_usage 1
    fi
}

run_postgres_sh_operator() {
    local action="$1"

    validate_postgres_operator_command_arg

  	local postgres_case
    postgres_case="$(dependent_case_tgz "ibm-cloud-native-postgresql" "${inputcasedir}")"
    local -a args=(
        "--namespace"
        "$namespace"
        "--tolerance"
        "${tolerance_val}"
        "--case-path"
        "${postgres_case}"
    )
    if [[ -n "${dryRun}" ]]; then
        args+=(
            "--dry-run"
        )
    fi
    "${scriptDir}/postgres.sh" operator "$action" "${args[@]}"
}

install_postgres_operator() {
    run_postgres_sh_operator install
}

uninstall_postgres_operator() {
    run_postgres_sh_operator uninstall
}

# ***** END ACTIONS *****
