![](https://raw.githubusercontent.com/ibm-cloud-docs/images/master/discovery-icp4d-new-banner.png)

# Name

IBM Watson™ Discovery Cartridge for IBM® Cloud Pak for Data

# Introduction

## Summary

IBM Watson™ Discovery Cartridge for IBM® Cloud Pak for Data is an AI-powered search and content analytics engine that finds answers and insights from complex business content with speed and accuracy. Answers can be surfaced to users through a conversational dialog driven by Watson Assistant or embedded in your own user-interface. With its Smart Document Understanding training interface, Watson Discovery can learn where answers live in complex business content based on a visual understanding of documents. Further enhance Watson Discovery's ability to understand domain specific language by teaching it with Watson Knowledge Studio.

Watson Discovery brings together a functionally rich set of integrated and automated Watson APIs to:

- Convert, enrich, and normalize data.
- Securely explore your proprietary content as well as free and licensed public content.
- Apply additional enrichments such as keywords through Natural Language Understanding (NLU).
- Simplify development while still providing direct access to APIs.

# Features

## Pinpoints answers

Comb through content in your connected data sources, pinpoint the most relevant passage and obtain the source documents or webpage with Watson Discovery.

## Finds Trends

Dig through your data in real time to reveal hidden patterns, trends and relationships between different pieces of content. Use text analytics to gain insights into customer and user behavior, analyze trends in social media and e-commerce, find the root causes of problems to inform decision making, and more.

## Better chatbots

Improve customer experience with Watson Assistant’s Search Skill so your virtual assistant can provide answers from your documents and data in a conversational search experience.

## Integration with other IBM Watson services

Watson Discovery is one of many IBM Watson services. Additional Watson services on IBM Cloud Pak for Data and the IBM Public Cloud allow you to bring Watson's AI platform to your business application, and to store, train, and manage your data in the most secure cloud.

For the full list of available Watson services, see:

- [IBM Cloud Pak for Data](https://www.ibm.com/products/cloud-pak-for-data)
- [IBM Watson Public Cloud catalog](https://cloud.ibm.com/catalog?category=ai)

Watson services are currently organized into the following categories for different requirements and use cases:

- **Assistant**: Integrate diverse conversation technology into your application
- **Empathy**: Understand tone, personality, and emotional state
- **Knowledge**: Get insights through accelerated data optimization capabilities
- **Language**: Analyze text and extract metadata from unstructured content
- **Speech**: Convert text and speech with the ability to customize models
- **Vision**: Identify and tag content, then analyze and extract detailed information found in images

# Details

## Prerequisites

### Resources Required

Minimum scheduling capacity:

| Software | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --- | --- | --- | --- | --- |
| Watson Discovery Catalog | 0.01 | 0.05 | - | 1 |
| Watson Discovery Operator | 0.05 | 0.1 | - | 1 |
| Watson Discovery Operand | 15 | 93 | 508 | 3 |
| **Total** | **15.06** | **93.15**  | **508**  | **3** |

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
IBM Watson™ Discovery Cartridge for IBM® Cloud Pak for Data runs with the 'restricted' SCC

## Limitations

- The installation process will not make any verification for available resources (CPU, Memory) on the cluster. Please make sure to have enough resources available to deploy Watson Discovery if you are running other applications on your cluster.
- CPUs must support the AVX2 instruction set.

## Installing

**By installing this product you accept the license terms: https://ibm.biz/BdfMaf (Search for "IBM Watson Discovery Cartridge for IBM Cloud Pak for Data 4.5").**

For the most up to date information on installing Watson Discovery, please visit [the IBM Knowledge Center page](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=discovery-installing-watson).

## Configuration

For the most up to date information on configuring Watson Discovery, please visit [the IBM Knowledge Center page](https://www.ibm.com/docs/en/cloud-paks/cp-data/latest?topic=discovery-installing-watson).

## Storage

Supported storage classes:

- OpenShift Container Storage: `ocs-storagecluster-ceph-rbd`
- Portworx: `portworx-db-gp2-sc`
- IBM Cloud Storage: `ibmc-block-gold`
- Spectrum Scale: `ibm-spectrum-scale-sc`

## Documentation

Please reference the provided documentation during installation and operation:

- [Watson Discovery Documentation](https://cloud.ibm.com/docs/services/discovery-data)
- [API reference](https://cloud.ibm.com/apidocs/discovery/discovery-data)
- [Cloud Pak for Data Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data)

_Copyright©  IBM Corporation 2022. All Rights Reserved._
