# Name

IBM Watson™ Assistant Cartridge for IBM® Cloud Pak for Data

# Introduction
With IBM Watson™ Assistant Cartridge for IBM® Cloud Pak for Data, you can use AI to build and deploy a branded assistant into any device, application, or channel. Connect your assistant to the customer support resources that you already use to deliver an engaging, unified problem-solving experience to your customers.

# Details

## Prerequisites

Before you install Watson Assistant, ensure that:

* The Cloud Pak for Data control plane is already installed on your Red Hat® OpenShift® cluster. For details, see Installing IBM Cloud Pak for Data.
* A cluster administrator has completed the steps in Setting up the cluster for Watson Assistant.
* The cluster meets the minimum requirements for installing Watson Assistant. For details, see System requirements for services.
* You completed the steps in Preparing to install and upgrade services.
* You completed the steps in Creating an override file for Watson Assistant.
* If you want to use a storage solution other than Portworx, take steps to configure it. For more information, see documentation for using an alternative storage solution.

### Resources Required
The following table provides system requirements for the various supported deployment sizes:
| Resource | Large   | Medium | Small  |
| -------- | ------- | ------ | ------ |
| vCPU     |      43 |     33 |     21 |
| Memory   |  350 GB | 250 GB | 150 GB |
| Storage  |  250 Gi | 250 Gi | 250 Gi |

The following table shows details for a typical medium deployment:
| Nodes | VPCs per node | Memory per node |
| ----- | ------------- | --------------- |
|     4 |            16 |             128 |


## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
The IBM Watson Assistant Operator currently requires the `restricted` SCC
```yaml
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  name: restricted
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups:
- system:authenticated
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

# Installing
Installation documentation for Watson Assistant can be found in [IBM Documentation](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=assistant-installing-watson-service).

## Configuration

### watsonAssistant.size
Specifies the deployment size. Options are small, medium, and large. The default size is medium.
### watsonAssistant.languages
English is enabled by default. To add support for a language other than English, you must add the language code to the languages list.
### watsonAssistant.cluster.imagePullSecrets
You need to add an image pull secret only if you don't use in-cluster registries (image-registry.openshift-image-registry.svc). Add the Docker secret that you got from the installation procedure.
### watsonAssistant.analytics.crossInstanceQueryScope.enabled
If you want to enable your user conversation logs to be shared across instances, add this entry in the override file, and set it to true. The Analytics feature must be enabled before you can share logs.

## Storage
305 GB
### Supported storage types:
* Amazon Elastic Block Store (EBS)
    * Required storage class: `gp2`
* Microsoft Azure disk volumes
* OpenShift Container Storage
    * Required storage class: `ocs-storagecluster-cephfs`
* Portworx
    * Required storage class: `portworx-watson-assistant-sc`

## Limitations
* Watson Assistant can be deployed only in the same namespace as Cloud Pak for Data and Watson Discovery.
* The installation process does not verify for available resources, including CPU and memory, on the cluster. Make sure that you have enough resources available to deploy Watson Discovery if you are running other applications on your cluster.
* CPUs must support the AVX2 instruction set.
* Nodes must be Intel architecture.
* CPUs must have a clock speed of 2.4 GHz or higher.
* CPUs must support Linux SSE 4.2.