#!/usr/bin/env bash

################################################################################
#################### COPIED FROM REDIS CASE, EDIT TO FIT WA ####################
################################################################################


# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the watson assistant operator

# inventory="assistantOperator" # default inventory item
subscriptionName="ibm-watson-assistant-operator-subscription"
channelName="v$( echo 5.14.0 | sed 's!\([0-9]*\.[0-9]*\)\..*!\1!')"
catalogNamespace="${NAMESPACE_CATALOG:-cpd-operator}"
catalogSource="ibm-watson-assistant-operator-catalog"
override_yaml=""
cpd_namespace=""
pull_secret=""
accept_license="false"
cr_patch=""
HELM_INSTALL_DIR=""

declare -a case_dependencies=(
    "ibm-redis-cp"
    "ibm-data-governor"
    "ibm-watson-gateway-operator"
    "ibm-opensearch-operator"
)

# Display usage information with return code (if specified)
print_usage() {
    # Determine context of call (via cloudctl or script directly) based on presence of cananical json parameter
    if [ -z "$caseJsonFile" ]; then
        usage="${scriptName} --casePath <CASE-PATH>"
        caseParmDesc="--casePath value, -c value  : root director to extracted CASE file to parse"
        toleranceParm=""
        toleranceParmDesc=""
    else
        usage="cloudctl case launch --case <CASE-PATH>"
        caseParmDesc="--case value, -c value      : local path or URL containing the CASE file to parse"
        toleranceParm="--tolerance tolerance"
        toleranceParmDesc="
  --tolerance value, -t value : tolerance level for validating the CASE
                                 0 - maximum validation (default)
                                 1 - reduced valiation"
    fi
    echo "
USAGE: ${usage} --inventory inventoryItemOfLauncher --action launchAction --instance instance
                  --args \"args\" --namespace namespace ${toleranceParm}
OPTIONS:
   --action value, -a value    : the name of the action item launched
   --args value, -r value      : arguments specific to action (see 'Action Parameters' below).
   ${caseParmDesc}
   --instance value,  -i value : name of instance of target application (release)
   --inventory value, -e value : name of the inventory item launched
   --namespace value, -n value : name of the target namespace
   ${toleranceParmDesc}
 ARGS per Action:
    configure-creds-airgap
      --registry               : source/target container image registry (required)
      --user                   : login user name for the container image registry (required)
      --pass                   : login password for the container image registry (required)
    configure-cluster-airgap
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory
      --registry               : target container image registry (required)
    mirror-images
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --inputDir               : path to saved CASE directory (required)
      --fromRegistry           : override the source image registry in the CASE
      --registry               : target container image registry (required)
      --chunks                 : mirror the images in batches with a given size. Default is 100
      --groups                 : list of image groups to mirror
      --skipDelta              : copy all of the images and not just the delta
    install-catalog:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --registry               : target container image registry
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
      --groups                 : list of image groups to filter catalog
    install-operator:
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --channelName            : name of channel for subscription (packagemanifest default used if not specified)
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if registry|pass specified)
      --pass                   : login password for the container image registry (required if registry|user specified)
    install-operator-native:
      --secret                 : name of existing image pull secret for the container image registry
      --registry               : container image registry (required if pass|user specified)
      --user                   : login user name for the container image registry (required if pass specified)
      --pass                   : login password for the container image registry (required if user specified)
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
      --groups                 : list of image groups to install
    uninstall-catalog          : uninstalls the catalog source and operator group
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
    uninstall-operator         : delete the operator deployment via OLM
      --dryRun                 : print the actions that would be taken and exit without writing to the destinations
    uninstall-operator-native  : deletes the operator deployment via native way
      --deleteCRDs             : deletes CRD's associated with this operator (if not set, crds won't get deleted)
      --recursive              : recursively install dependent catalogs
      --inputDir               : path to saved CASE directory ( required if --recurse is set)
    apply-custom-resources     : creates the sample custom resource
      --cpd-namespace          : name of the target namespace (required)
      --pull-secret            : name of existing image pull secret for the container image registry (required)
      --accept-license         : indicate having read and agreed to license agreements (required)
      --cr-patch               : specify patch to be applied
    delete-custom-resources    : deletes the same custom resource
    init-registry              : configure a local docker registry with self-sign certificate
      --user                   : login user name for the container image registry
      --pass                   : login password for the container image registry
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --subject                : self-sign TLS certificate subject
      --registry               : IP or FQDN for the docker registry ( default: $(hostname -f))
      --clean                  : clean up all existing repositories data
    start-registry             : start a local docker registry container
      --port                   : registry service port (default: 5000 )
      --dir                    : local directory for the docker registry (default: /tmp/docker-registry)
      --engine                 : container engine to run the container (docker or podman)
      --image                  : docker registry image (default: docker.io/library/registry:2.6)
    stop-registry              : stop a local docker registry container
      --engine                 : container engine to run the container (docker or podman)
"

    if [ -z "$1" ]; then
        exit 1
    else
        exit "$1"
    fi
}

# ----- Actions -----
# Override run_action in launch.sh to support custom actions
run_action() {
    echo "Executing inventory item ${inventory}, action ${action} : ${scriptName}"
    case $action in
    configureCluster)
        configure_cluster
        ;;
    configureClusterAirgap)
        configure_cluster_airgap
        ;;
    configureCredsAirgap)
        configure_creds_airgap
        ;;
    install)
        install
        ;;
    installCatalog)
        install_catalog
        ;;
    installOperator)
        install_operator
        ;;
    installOperatorNative)
        install_operator_native
        ;;
    imageInfo)
        image_info
        ;;
    mirrorImages)
        mirror_images
        ;;
    uninstall)
        uninstall
        ;;
    uninstallCatalog)
        uninstall_catalog
        ;;
    uninstallOperator)
        uninstall_operator
        ;;
    uninstallOperatorNative)
        uninstall_operator_native
        ;;
    applyCustomResources)
        apply_custom_resources
        ;;
    deleteCustomResources)
        delete_custom_resources
        ;;
    initRegistry)
        init_registry
        ;;
    startRegistry)
        start_registry
        ;;
    stopRegistry)
        stop_registry
        ;;
    *)
        err "Invalid Action ${action}"
        print_usage 1
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-redis-cp)
        echo "ibmRedisCPOperator"
        return 0
        ;;
    ibm-cloud-native-postgresql)
        echo "ibmCloudNativePostgresqlOperator"
        return 0
        ;;
    ibm-data-governor)
        echo "ibmDataGovernorOperatorSetup"
        return 0
        ;;
    ibm-elasticsearch-operator)
        echo "ibmElasticsearchOperatorSetup"
        return 0
        ;;
    ibm-etcd-operator)
        echo "ibmEtcdOperatorSetup"
        return 0
        ;;
    ibm-watson-gateway-operator)
        echo "ibmWatsonGatewayOperatorSetup"
        return 0
        ;;
    ibm-opensearch-operator)
        echo "ibmOpensearchOperatorSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- VALIDATE ARGS -----

validate_apply_custom_resources_args() {
    # Verify arguments required to create secret were provided
    local foundError=0
    [[ -z "${cpd_namespace}" ]] && {
        foundError=1
        err "'--cpd-namespace' must be specified with the '--args' parameter"
    }
    [[ -z "${pull_secret}" ]] && {
        foundError=1
        err "'--pull-secret' must be specified with the '--args' parameter"
    }
    [[ "${accept_license}" == "false" ]] && {
        foundError=1
        err "'--accept-license' must be specified to indicate have read and agree to license agreements."
    }

    [[ -n "${cr_patch}" ]] && {
        # Optinal parameter  --cr-patch specified, checking if it points to a foile
        [[ -f "${cr_patch}" ]] || {
          foundError=1
          err "'--cr-patch' must point to an existing yaml file with the (strategic merge) patch for a sample custom resource."
        }
    }
    # Print usgae if missing parameter
    [[ $foundError -eq 1 ]] && { print_usage 1; }
}

# ----- INSTALL ACTIONS -----

# # Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
  echo "-------------Installing dependent catalogs-------------"

  local dep_case=""

  for dep in "${case_dependencies[@]}"; do
      local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

      echo "-------------Installing dependent catalog source: ${dep_case}-------------"

      validate_file_exists "${dep_case}"
      local inventory=""
      inventory=$(dependent_inventory_item "${dep}")

      local install_catalog_args="--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }"
      if [[ -n ${registry} ]]; then
          install_catalog_args="${install_catalog_args} --registry ${registry}"
      fi
      echo "      cloudctl case launch \
                --case "${dep_case}" \
                --namespace "${namespace}" \
                --inventory "${inventory}" \
                --action install-catalog \
                --args "${install_catalog_args}" \
                --tolerance "${tolerance_val}""
      cloudctl case launch \
          --case "${dep_case}" \
          --namespace "${namespace}" \
          --inventory "${inventory}" \
          --action install-catalog \
          --args "${install_catalog_args}" \
          --tolerance "${tolerance_val}"

      if [[ $? -ne 0 ]]; then
          err_exit "installing dependent catalog for '${dep_case}' failed"
      fi
  done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {
    echo "no dependent operators"
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    if [[ -z $registry ]]; then
        tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) <"${catsrc_file}" | cat
    else
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
         sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    install_operator_group

    echo "-------------Installing via OLM-------------"
    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${catalogSource}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${catalogSource}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" "s|REPLACE_NAMESPACE|${catalogNamespace}|g; s|REPLACE_CHANNEL_NAME|$channelName|g; s|REPLACE_CATALOG_SOURCE|${catalogSource}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

install() {
    install_operator
}

# install operand custom resources
apply_custom_resources() {
    validate_apply_custom_resources_args

    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/cr.yaml

    validate_file_exists "${cr}"

    cr_content="$(cat "${cr}" )"
    # Patching the instance name
    patch_instance_name="
metadata:
  name: '${instance}'
"
    cr_content="$( echo "${cr_content}" | $kubernetesCLI patch --dry-run=client -f - --type=merge --patch="$(echo "${patch_instance_name}" )" --output yaml)"

    # Apply user provided patch (if specified)
    if [[ -n "${cr_patch}" ]] ; then
      echo "applying patch ${cr_patch}"
      cr_content="$( echo "${cr_content}" | $kubernetesCLI patch --dry-run=client -f - --type=merge --patch="$(cat "${cr_patch}" )" --output yaml)"
    fi

    # $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${cr}"
    echo "${cr_content}" | sed "s|REPLACE_CPD_NAMESPACE|${cpd_namespace}|g; s|REPLACE_PULL_SECRET|$pull_secret|g; s|accept: false|accept: true|g" \
      | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {
    echo "no dependent catalogs"
}

uninstall_dependent_operators() {
    echo "no dependent operators"
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {

    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }


    # don't remove operator group, some other may have a dependency

    # # delete crds
    # for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
    #     $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
    # done

    exit 0
}

uninstall() {
    uninstall_operator
}

delete_custom_resources() {
    local cr="${casePath}"/inventory/"${inventory}"/files/cr.yaml

    validate_file_exists "${cr}"

    echo "-------------Deleting custom resources-------------"
    $kubernetesCLI delete -n "${namespace}" wa ${instance} ${dryRun}
}

parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --cpd-namespace)
        cpd_namespace="$val"
        ;;
    --pull-secret)
        pull_secret="$val"
        ;;
    --accept-license)
        accept_license="$val"
        ;;
    --cr-patch)
        cr_patch="${val}"
        ;;
    esac
}

# ***** END ACTIONS *****