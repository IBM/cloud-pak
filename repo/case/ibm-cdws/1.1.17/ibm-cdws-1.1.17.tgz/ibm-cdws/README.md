# Name

IBM&reg; (IBM Connect:Direct Web Services v6.4.0)

# Introduction

IBM Connect:Direct Web Services targets transforming the Managed File Transfer market with a modern user experience and help your business by:
- Reducing the operating cost
- Deploying solutions rapidly
- Opening new opportunities by enabling easy integration with other Web service-based applications
IBM Connect:Direct Web Services extends a Web-based User Interface (Web Console) and a RESTful API-based interface to Connect:Direct users. To find out more, see the Knowledge Center for [ IBM Connect:Direct Web Services ](  https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=sterling-connectdirect-web-services-v64 ).

# Details

This CASE is only meant for deployment on OpenShift cluster in Airgap environment. It contains one inventory items:

ibmCdws - required setup for installing IBM Connect Direct Web Services v6.4.0 helm chart

# Prerequisites

## CASE Bundle (Prereq #1)

Please refer to [Offline deployment - For OpenShift](https://ibm.com/docs/en/connect-direct/6.4.0?topic=icwsuccs-installing#concept_pjj_bxm_lkb) section in the online Knowledge Center documentation. 
 
## Storage (Prereq #2) 

Please refer to [Creating storage for Data Persistence](https://ibm.com/docs/en/connect-direct/6.4.0?topic=icwsuccs-installing#concept_swd_dcn_lkb) section in the online Knowledge Center documentation.

## Secret (Prereq #3)

Please refer to [Creating secret](https://ibm.com/docs/en/connect-direct/6.4.0?topic=icwsuccs-installing#concept_g2v_nym_lkb) section in the online Knowledge Center documentation.

## Tools (Prereq #4)

To install chart from the command prompt, tools needed are:

- Kubernetes version `>=1.27.0`
- OpenShift version `>=4.14 <=4.19`
- helm version `>=3.2.x`
- The `kubectl` and `helm` commands available
- The environment should be configured to connect to the target cluster
- IBM Pak Plugin for oc from [here](https://www.ibm.com/links?url=https%3A%2F%2Fgithub.com%2FIBM%2Fibm-pak%23overview)

## SecurityContextConstraints Requirements

This chart supports restricted scc. For more details, refer: https://docs.openshift.com/container-platform/4.19/authentication/managing-security-context-constraints.html

### Resources Required

* 500Mi of persistent volume
* 2 GB Disk space
* 1500m CPU
* 1Gi Memory
* 1 master node and at least 1 worker node

## Install Prequisites

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Setup](./inventory/ibmCdws/README.md)

## Install CASE inventory items

See the following readme file for details of installing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmCdws/README.md)

## Uninstalling the CASE

See the following readme files for details of removing the inventory items found in this CASE:

- [Chart Readme](./inventory/ibmCdws/README.md)

## Configuration

- [Chart Readme](./inventory/ibmCdws/README.md)

## Storage

IBM Connect:Direct Web Services Helm chart supports both dynamic and pre-created persistent storage.

* Either use storage class for dynamic provisioning or pre-create Persistent Volume
* To retain the data stored on Persistent Volume, the storage class should have reclaim policy as `Retain`
* The default access mode is set to `ReadWriteOnce`

## Limitations

- High availability and scalability are supported in traditional way of Web Services deployment using Kubernetes load balancer service.
- IBM Connect:Direct Web Services chart supports only amd64 architecture.

# Documentation

[IBM Connect:Direct Web Services](https://www.ibm.com/docs/en/connect-direct/6.4.0?topic=sterling-connectdirect-web-services-v64)
