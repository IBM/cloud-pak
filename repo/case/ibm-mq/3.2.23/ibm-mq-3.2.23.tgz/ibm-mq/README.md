# Name

IBM&reg; MQ

# Introduction

## Summary

[IBM MQ](https://www.ibm.com/products/mq) is messaging middleware that simplifies and accelerates
the integration of diverse applications and business data across multiple platforms.
It uses message queues to facilitate the exchanges of information and offers
a single messaging solution for cloud, mobile, Internet of Things (IoT) and on-premises
environments.

The IBM MQ Operator for Red Hat OpenShift Container Platform provides
an easy way to manage the life cycle of IBM MQ queue managers.

IBM MQ is part of the [IBM Cloud Pak for Integration](https://www.ibm.com/cloud/cloud-pak-for-integration).

## Features

* Creation and management of IBM MQ queue managers
  * Use of single-instance, multi-instance or 'Native HA' queue managers.  Includes a rolling update feature to help minimize fail-over times.
  * Integration with Instana tracing
  * Single Sign-On (SSO) with the Cloud Pak for Integration, using Keycloak
  * [Version support for the IBM MQ Operator](https://www.ibm.com/docs/en/ibm-mq/9.3?topic=operator-version-support-mq)

# Details

## Prerequisites

* Red Hat OpenShift Container Platform V4.12 onwards.
* If persistence is enabled you need to ensure a Storage Class is defined in your OpenShift cluster.

### Resources Required

* The IBM MQ Operator requires 1 CPU core and 1 GB memory
* Each IBM MQ Queue Manager defaults to 1 CPU core and 1 GB memory, but can be run with fewer resources with lower performance
* The IBM Licensing Operator needs to be [installed separately](https://www.ibm.com/docs/en/cloud-paks/cp-integration/latest?topic=administration-deploying-license-service)

# Installing

See [Installing and uninstalling the IBM MQ Operator on OpenShift](https://www.ibm.com/docs/en/ibm-mq/9.3?topic=openshift-installing-uninstalling-mq-operator-red-hat).  Operators need to be installed by a cluster administrator.

## Configuration

See [Deploying and configuring queue managers using the IBM MQ Operator](https://www.ibm.com/docs/en/ibm-mq/9.3?topic=openshift-deploying-configuring-queue-managers-using-mq-operator).  Queue managers can be installed by a project (namespace) administrator.

## SecurityContextConstraints Requirements

* IBM MQ runs under the default `restricted` SecurityContextConstraints.

## Storage

MQ is configured to use dynamic provisioning of ReadWriteOnce (RWO) Persistent Volumes (typically block storage) when using MQ Native HA or single instances.

MQ can optionally be configured to use dynamic provisioning of ReadWriteMany (RWX) Persistent Volumes, which use a shared filesystem, when using multi-instance queue managers.  In this case, MQ is affected by other limits applied to the file system (such as limiting the number of file locks in AWS EFS). See [testing statement](https://www.ibm.com/support/pages/testing-statement-ibm-mq-multi-instance-queue-manager-file-systems).

## Limitations

* Supports only the `amd64`, `s390x` & `ppc64le` CPU architectures
* Supports OpenShift Container Platform V4.12 onwards only.  **Note**: Only the Extended Update Support (EUS) releases are supported, which are the even-numbered minor releases, such as 4.12 and 4.14.
* Do not edit the availability type of a QueueManager after initial creation
* Do not edit the storage settings of a QueueManager after initial creation
* The following alpha and beta APIs and features are used by the MQ operator:
  * `operators.coreos.com/v1alpha1` and `operators.coreos.com/v1alpha2` for Operator installation
  * `operator.ibm.com/v1alpha1` for installation of additional IBM common operators

## Documentation

* [IBM MQ Knowledge Center Documentation](https://ibm.biz/BdPZqj)
* [License reference for mq.ibm.com/v1beta1](https://ibm.biz/Bdm9be)

