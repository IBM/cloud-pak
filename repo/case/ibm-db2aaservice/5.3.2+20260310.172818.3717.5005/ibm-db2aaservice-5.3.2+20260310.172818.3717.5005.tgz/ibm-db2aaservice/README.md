# Introduction
IBM® Db2 is a relational database that delivers advanced data management and analytics capabilities for transactional workloads.

## Link To External Documentation
https://www.ibm.com/analytics/db2

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:
This operator runs with the 'restricted' SCC

```
openshift.io/scc: restricted
```