# Name

IBM&reg; SPSS Modeler 

# Introduction

You can use SPSS Modeler flows to build machine learning pipelines that you can use to iterate rapidly during the model building process. 

## Summary

With SPSS Modeler flows, you can quickly develop predictive models using business expertise to improve decision making. The flows interface is based on the long-established SPSS Modeler client software and uses industry-standard CRISP-DM methodology. The SPSS Modeler service supports the entire data mining process, from data exploration all the way to better business results.

## Features

You can use SPSS Modeler flows to build machine learning pipelines that you can use to iterate rapidly during the model building process. 

# Details

## Prerequisites

IBM SPSS Modeler requires the following 
- IBM Cloud Pak for Data Common Core Services version 1.0.0 or later
- cloudctl binary

### Resources Required

IBM SPSS Modeler includes flow-ui, flow-api and modeler-flow-api micro-services and spss-modeler runtime. Micro-services are constantly running on the cluster, while a runtime is only spawned when a user refines data. Resources for runtime will be reclaimed after data refining is completed.

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Micro-services | .85       | 1           |           |       |
| Runtime   | 8           | 4         |           |       |
| **Total** | 8.85           | 5        |           |       |

## Installing


IBM Cloud Pak for Data platform installation documentation:
https://www.ibm.com/docs/en/SSQNUZ_4.0/cpd/install/install.html

If you have already completed the Cloud Pak for Data setup and installation, see the following  service documentation:

Watson Knowledge Catalog installation documentation:
https://www.ibm.com/docs/en/SSQNUZ_4.0/wsj/install/install-wkc.html

Watson Studio installation documentation:
https://www.ibm.com/docs/en/SSQNUZ_4.0/svc-spss/spss-install-svc.html

## Configuration

Default size for Spss Modeler is `small`. Update the size by changing the `spec.size` value in Spss Modeler CR.

## Storage

IBM SPSS Modeler supports dynamic storage provisioning using storage class.  The following storages are supported
- NFS
- Portworx 2.7 
- OCS

## Limitations

Only one instance of IBM SPSS Modeler operator can be deployed in a cluster. Multiple instances of SPSS Modeler operands can be deployed in different namespaces in a cluster.

## PodSecurityPolicy Requirements

The **restricted** SCC is required to deploy this.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements

The **restricted** SCC is required to deploy this.  It is built into OpenShift, and defined below.
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restricted denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: name-to-scc
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

=======
## Install spss-modeler with OLM based Operator 

#### Pre-req: Where to get the `spss-case-bundle-tgz`

from repo: PrivateCloud-analytics/cpd-case-repo/tree/4.0.0/dev/case-repo-dev/ibm-spss

#### 1) Install spss-modeler operator catalog operator:
```
./cloudctl case launch --tolerance 1 --case <spss-case-bundle-tgz> --namespace <namespace> --inventory spssSetup --action installCatalog
```

#### 2) Install spss-modeler operator :
```
./cloudctl case launch --tolerance 1 --case <spss-case-bundle-tgz> --namespace <namespace> --action installOperator --inventory spssSetup --args "--registry cp.stg.icr.io"

```

#### 3) Deploy spss-modeler 

```
apiVersion: spssmodeler.cpd.ibm.com/v1
kind: Spss
metadata:
  name: spss-sample
spec:    
  version: "4.0.0"
  storageClass: "${BVT_STORAGE_CLASS}"
  scaleConfig: "small"
  architecture: "amd64"
  namespace: "${BVT_LITE_NAMESPACE}"
  operation: "install"
  docker_registry_prefix: "cp.stg.icr.io/cp/cpd"  
```
e.g.
```
cat << EOF | oc apply -f -
apiVersion: spssmodeler.cpd.ibm.com/v1
kind: Spss
metadata:
  name: spss-sample
spec:    
  version: "4.0.0"
  scaleConfig: "small"
  architecture: "amd64"
  docker_registry_prefix: "cp.stg.icr.io/cp/cpd"
  storageClass: "managed-nfs-storage"
  namespace: "zen"
  operation: "install"
EOF
```

#### 4) Uninstall spss-modeler 
```
./cloudctl case launch --case <spss-case-bundle-tgz> --tolerance 1 --namespace <namespace> -action deleteCustomResources --inventory spss
```
or Run
```
oc delete Spss spss-sample -n <cpd project>
```

#### 5) Uninstall spss operator
```
./cloudctl case launch --case <spss-case-bundle-tgz> --tolerance 1 --namespace <namespace> -action uninstallOperator --inventory spssSetup
```

#### 6) Uninstall spss catalog
```
./cloudctl case launch --tolerance 1 --case <spss-case-bundle-tgz> --namespace <namespace> --inventory spssSetup --action uninstallCatalog
```
