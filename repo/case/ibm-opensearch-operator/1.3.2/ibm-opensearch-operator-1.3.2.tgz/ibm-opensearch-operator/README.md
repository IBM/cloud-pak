# Name

IBM&reg; Opensearch Operator

# Introduction

An innersource@IBM&reg; project for a IBM cloudpak certified operator managed opensearch.

