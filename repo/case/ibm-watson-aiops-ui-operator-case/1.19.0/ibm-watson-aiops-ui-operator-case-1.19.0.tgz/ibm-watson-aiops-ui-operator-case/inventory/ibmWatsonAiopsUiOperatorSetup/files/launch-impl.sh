# (C) Copyright IBM Corp. 2021  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the connector utilities  operator and was
# derived from the IBM panamax sample operator.

# Connector utilities operator specific variables
caseName="ibm-watson-aiops-ui-operator-case"
operatorName="ibm-watson-aiops-ui-operator"
case_depedencies=""
recursive_action=1


# returns name of the inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
# this list must be updated as additional items are added to case_dependencies
# the dependent CASE items must support `install-catalog` and `uninstall-catalog`
# the echo value must be the name of the CASE inventory for the catalog actions
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-cp-automation-foundation)
        echo "iafOperatorSetup"j
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source including dependent catalogs
install_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the catalog source including dependent catalogs
install_catalog() {

    validate_install_catalog

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

install_service_account() {
  saName="ibm-watson-aiops-ui-operator-manager-role"
  # Make sure there isn't an exisitng service account created previously, just delete it
  if [[ $($kubernetesCLI get sa $saName -n "${CV_TEST_NAMESPACE}") -gt 0 ]]; then
        echo "Service Acount .. $saName found ... remove it!"
        $kubernetesCLI delete sa $saName
        return
  fi

  operators_path="${CV_TEST_BUNDLE_DIR}/operators"
  local sa_file="${operators_path}/${operatorName}/config/rbac/service_account.yaml"

  validate_file_exists "${sa_file}"

  # Create the service account in our namespace
  sed -e "s|manager-role|ibm-watson-aiops-ui-operator-manager-role|g; s|openshift-operators|${CV_TEST_NAMESPACE}|g" "${sa_file}"| $kubernetesCLI apply ${dryRun} -f - -n "${CV_TEST_NAMESPACE}"
  sleep 10


  # We need to also copy the cp4mcm team docker pull secret into our namespace
  CP4_TEAM_TEST_PULL_SECRET="hyc-cp4mcm-team-docker-local.artifactory.swg-devops.com"
  kubectl get secret ${CP4_TEAM_TEST_PULL_SECRET} -n default -o yaml | sed "s/namespace: .*/namespace: ${CV_TEST_NAMESPACE}/" | kubectl apply -f -
  sleep 10

  # Link the CP4 Team pull secret into our newly created service account
  oc secrets link serviceaccount/$saName  $CP4_TEAM_TEST_PULL_SECRET --for=pull -n "${CV_TEST_NAMESPACE}"
}


install_operator_group() {
  # If they operator group already exists in our namespace then we are good!
  if [[ $($kubernetesCLI get og -n "${CV_TEST_NAMESPACE}") -gt 0 ]]; then
        echo "Found operator group inside namespace: $CV_TEST_NAMESPACE"
        $kubernetesCLI get og -n "${CV_TEST_NAMESPACE}" -o yaml
        return
  fi

  operators_path="${CV_TEST_BUNDLE_DIR}/operators"
  local group_file="${operators_path}/${operatorName}/hack/dev/kustomize_install/assets/operatorgroup.yaml"

  validate_file_exists "${group_file}"

  echo "Create operator group ..."
  sed -e "s|REPLACE_NAMESPACE|${CV_TEST_NAMESPACE}|g" "${group_file}" | $kubernetesCLI apply ${dryRun} -n "${CV_TEST_NAMESPACE}" -f -

  if [[ $($kubernetesCLI get og -n "${CV_TEST_NAMESPACE}") -gt 0 ]]; then
        echo "Found operator group inside namespace: $CV_TEST_NAMESPACE"
        $kubernetesCLI get og -n "${CV_TEST_NAMESPACE}" -o yaml
        return
  fi
}

# Our operator deploys several UIs so we need to add their CRDs
# - base-ui / aiops-ui / aimodel-ui / application-ui / connector-ui
# This is part of the prereqs
install_operator_base_crds() {
  operators_path="${CV_TEST_BUNDLE_DIR}/operators"
  local base_path="${operators_path}/${operatorName}/config/crd/bases"
  local base_ui="${base_path}/consoleui.aiops.ibm.com_baseuis.yaml"
  local aiops_ui="${base_path}/consoleui.aiops.ibm.com_aiopsuis.yaml"
  local aimodel_ui="${base_path}/consoleui.aiops.ibm.com_aimodeluis.yaml"

  validate_file_exists "${base_ui}"
  validate_file_exists "${aiops_ui}"
  validate_file_exists "${aimodel_ui}"
  validate_file_exists "${connector_ui}"

  $kubernetesCLI apply ${dryRun} -f ${base_ui}
  $kubernetesCLI apply ${dryRun} -f ${aiops_ui}
  $kubernetesCLI apply ${dryRun} -f ${aimodel_ui}
  $kubernetesCLI apply ${dryRun} -f ${connector_ui}
}

# Our operator requires leader election, roles, and role bindings to be present
# so that pods can have the correct access.
# This is part of the prereqs
install_operator_role_rolebinding() {
  operators_path="${CV_TEST_BUNDLE_DIR}/operators"

  local rbac_path="${operators_path}/${operatorName}/config/rbac"
  local leader_election_role="${rbac_path}/leader_election_role.yaml"
  local leader_election_binding="${rbac_path}/leader_election_role_binding.yaml"
  local role_role="${rbac_path}/role.yaml"
  local role_binding="${rbac_path}/role_binding.yaml"

  validate_file_exists "${leader_election_role}"
  validate_file_exists "${leader_election_binding}"
  validate_file_exists "${role_role}"
  validate_file_exists "${role_binding}"

  managerRole="ibm-watson-aiops-ui-operator-manager-role"
  $kubernetesCLI apply ${dryRun} -f ${leader_election_role} -n "${CV_TEST_NAMESPACE}"
  sed -e "s|manager-role|${managerRole}|g; s|openshift-operators|${CV_TEST_NAMESPACE}|g" "${leader_election_binding}" | $kubernetesCLI apply ${dryRun} -n "${CV_TEST_NAMESPACE}" -f -

  sed -e "s|REPLACE_NAMESPACE|${CV_TEST_NAMESPACE}|g; s|manager-role|${managerRole}|g" "${role_role}" | $kubernetesCLI apply ${dryRun} -n "${CV_TEST_NAMESPACE}" -f -

  sed -e "s|manager-role|${managerRole}|g; s|openshift-operators|${CV_TEST_NAMESPACE}|g" "${role_binding}" | $kubernetesCLI apply ${dryRun} -n "${CV_TEST_NAMESPACE}" -f -
}

# Our operator requires SecurityContextConstraints
# This is part of the prereqs
install_operator_scc() {
  operators_path="${CV_TEST_BUNDLE_DIR}/operators"

  local hack_path="${operators_path}/${operatorName}/hack/dev/kustomize_install/assets"
  local scc_yaml="${hack_path}/scc.yaml"

  validate_file_exists "${scc_yaml}"

  $kubernetesCLI apply ${dryRun} -f ${scc_yaml}

  # oc adm policy add-scc-to-user ibm-restricted-scc -z default -n ${CV_TEST_NAMESPACE}
}

# Install utilizing default CLI method
install_operator() {

  source ${CV_TEST_BUNDLE_DIR}/tests/image-mapping-utils.sh

  if [[ $($kubernetesCLI get csv "${operatorName}".v0.0.1 -n "${CV_TEST_NAMESPACE}") -gt 0 ]]; then
        echo "Found operator group inside namespace: $CV_TEST_NAMESPACE"
        $kubernetesCLI delete csv "${operatorName}".v0.0.1 -n "${CV_TEST_NAMESPACE}"
        return
  fi

    echo "-------------Installing native sdk1-------------"

    install_operator_group

    install_operator_base_crds

    install_operator_role_rolebinding

    install_operator_scc

    install_service_account


    # Verify expected yaml files for install exist
    case_path="${CV_TEST_BUNDLE_DIR}/case/${caseName}"
    local manifest_file="${case_path}/inventory/$inventory/files/bundle/manifests/ibm-watson-aiops-ui-operator.clusterserviceversion.yaml"

    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
    mappingFile="${CV_TEST_BUNDLE_DIR}/tests/image-mapping.json"
    imageToUse=$(imageMapping ibm-cp4waiops-watson-aiops-ui-operator $mappingFile)
    sed -e "s|placeholder|${CV_TEST_NAMESPACE}|g; s|hyc-cp4mcm-team-docker-local.artifactory.swg-devops.com/ibmcom/ibm-cp4waiops-watson-aiops-ui-operator:latest|$imageToUse|g" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -n "${CV_TEST_NAMESPACE}" -f -
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}
