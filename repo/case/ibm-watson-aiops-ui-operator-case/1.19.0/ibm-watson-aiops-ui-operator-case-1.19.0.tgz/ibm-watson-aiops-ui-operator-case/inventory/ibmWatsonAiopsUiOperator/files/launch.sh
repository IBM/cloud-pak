../../../../../../../submodules/cloud-pak-launch-cli/launch.sh
