../../../../../../../submodules/cloud-pak-airgap-cli/airgap.sh
