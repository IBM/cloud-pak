# Name

IBM Cloud Pak for Watson AIOps UI Case

# Introduction

## Summary

The IBM Cloud Pak for Watson AIOps, running on Red Hat OpenShift, provides consistent visibility, governance, and automation from on premises to the edge. Enterprises gain capabilities such as multicluster management, event management, application management and infrastructure management. Enterprises can use this Cloud Pak to help increase operational efficiency that is driven by intelligent data, analysis, and predictive golden signals, and gain built-in support for their compliance management. For more details, see the [IBM Cloud Pak for Watson AIOps documentation](https://www.ibm.com/support/knowledgecenter/SSFC4F/product_welcome_cloud_pak.html).

## Features
### Event management
AI management services collect information from IT assets, such as applications, the infrastructure that applications run on, and the networking systems that support them. This data is used to uncover insights and identify root causes of events. Using this data to train your models leads to better event discovery and a more accurate understanding of your topology. With this advanced understanding of your topology, you can pinpoint where events occur and the associated impact. AI-driven ChatOps and collaboration can be used to notify, update, and provide your team with near real-time potential remedies for potential incidents.

### Insight delivery
Integrated service and dynamic topology management provides complete up-to-date visibility and control over dynamic infrastructure and services, which is configurable for real-time or historical viewing.

### Incident diagnosis
Analyze performance metrics and monitoring data across systems to understand the normal operational behavior of the metrics in an environment. Data that is ingested from multiple sources and integral time-series algorithms are used to creates performance model for detecting anomalies or forecasting behavior outside of the modeled range.

### Incident resolution
Event Management capabilities monitor the health and performance of IT and network infrastructure across environments and collect, consolidate, and correlate events and topology data from different sources. These capabilities use real-time alarm, alert analytics, and broader historic data analytics to deliver actionable insights into service, network, and infrastructure performance.

# Details

## Prerequisites
- The IBM Cloud Pak for Watson AIOps UI Operator has a dependency on the IBM Cloud Pak for Watson AIOps Operator.

### PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:

```yaml
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: ibm-chart-dev-psp
spec:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: false
  allowedCapabilities:
  - CHOWN
  - DAC_OVERRIDE
  - SETGID
  - SETUID
  - NET_BIND_SERVICE
  seLinux:
    rule: RunAsAny
  supplementalGroups:
    rule: RunAsAny
  runAsUser:
    rule: RunAsAny
  fsGroup:
    rule: RunAsAny
  volumes:
  - configMap
  - secret
```

### Red Hat OpenShift SecurityContextConstraints Requirements
All pods run with the OpenShift Restricted SCC.

Custom SecurityContextConstraints definition:
My product runs with the 'restricted' SCC

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (MB) | CPU (cores) | Disk (MB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Application Details UI |    100         |     256Mi        |    382       |   1    |
| Base UI |    100         |     256Mi       |    382      |   1    |
| Connector UI |    100         |     256Mi        |      382     |    1   |
| AI Models UI |    100         |     256Mi        |      382     |    1   |

# Installing

For installation and configuration, see [IBM Cloud Pak for Watson AIOps](https://ibm.biz/cp4waiops-install).

## Configuration

* Provide configuration instructions if any

## Storage

IBM Cloud Pak for Watson AIOps UI does not have any storage requirement.

## Limitations

* Only one instance of the IBM Cloud Pak for Watson AIOps UI service is supported within a cluster.

## Documentation

To learn more, see the [IBM Cloud Pak for Watson AIOps documentation](https://ibm.biz/cp4waiops-welcome).
