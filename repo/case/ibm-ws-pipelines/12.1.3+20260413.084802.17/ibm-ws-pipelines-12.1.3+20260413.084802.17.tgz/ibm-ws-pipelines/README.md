# Name

IBM&reg; Watson Pipelines

# Introduction

## Summary

The Watson Pipelines editor provides a graphical interface for orchestrating an end-to-end flow of assets from creation through deployment. It enables to automate an end-to-end flow to prepare data, then create, train, deploy, monitor and update machine learning models and Python scripts. To design a pipeline you drag nodes onto the canvas, specify objects and parameters, then run and monitor the pipeline.

## Features

Watson Pipelines are built off of Kubeflow pipelines on Tekton runtime and are fully integrated into the Watson Studio platform, allowing users to combine tools including:
- Notebooks
- Data refinery flows
- AutoAI experiments
- Web service / online deployments
- Batch deployments
- Import and export of Project / Space assets

into repeatable and automated pipelines.

# Details

## Prerequisites

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=installing-pre-installation-tasks)

### Resources Required

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=planning-system-requirements)

# Installing

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=installing)

## Configuration

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=installing)

## Storage

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=planning-storage-considerations)

## Limitations

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=issues-watson-studio)

## Documentation

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=overview)

## PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
Not Applicable
```

## SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
metadata:
  annotations:
    include.release.openshift.io/self-managed-high-availability: "true"
    kubernetes.io/description: restrict denies access to all host features and requires pods to be run with a UID, and SELinux context that are allocated to the namespace.  This is the most restrictive SCC and it is used by default for authenticated users.
    release.openshift.io/create-only: "true"
  name: restrict
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```
