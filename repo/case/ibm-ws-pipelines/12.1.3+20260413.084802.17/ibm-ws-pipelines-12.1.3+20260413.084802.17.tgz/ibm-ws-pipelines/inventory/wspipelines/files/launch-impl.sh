#!/bin/bash

# (C) Copyright IBM Corp. 2020, 2021  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ws pipelines operator

# ws-pipelines operator specific variables
operand_pods_prefixes="opa|tekton-extensions-controller|tekton-extensions-webhook|wsp-ts|portal-pipelines|artifact-store"
cr_system_status="betterThanYesterday"
pods_count=5 #default small scale

# - additional variables
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cr_file="${scriptDir}/op-cli/wspipelines_cr.yaml"
scale_config=""
storage_class=""
localTektonRuntime=""

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2

    if [[ "$key" =~ -- ]]; then
        echo "Parsing arg: ${key}=${val}"
    fi
    
    case $key in
      --scaleConfig)
          scale_config="${val}"
          ;;
      --localTektonRuntime)
          localTektonRuntime="${val}"
          ;;
    esac
}

preinstall_checks() {

  echo "Pre-install checks ..."

  # echo "Check tekton pipelines status ..."

  # # check tekton pipelines controller status
  # if [[ $(oc get deployments -n ${namespace} | grep -c tekton-pipelines-controller) -gt 0 ]]; then
  #   echo "Tekton pipelines controller is already installed."
  #   oc get deployments tekton-pipelines-controller -n ${namespace}
  #   echo "Quitting installation ..."
  #   exit 1
  # fi

  echo "Check tekton CRDs status ..."

  # check tekton CRDs status, cleanup if CRDs exist
#  if [[ $(oc get crd --no-headers | grep -c tekton) != 0 ]]; then
#
#    echo "Tekton CRDs cleanup ..."
#    for crd in $(oc get crd --no-headers | grep tekton | awk '{print $1}'); do
#        oc patch crd "${crd}" -p '{"metadata":{"finalizers":[]}}' --type=merge
#        oc delete crd "${crd}" --ignore-not-found=true --wait=true
#        sleep 10
#    done

#    if [[ $(oc get crd --no-headers | grep -c tekton) != 0 ]]; then
#        echo "Tekton CRDs are already installed."
#        oc get crd --no-headers | grep tekton
#        echo "Quitting installation ..."
#        exit 1
#    fi
#
#  fi

  echo "Pre-install checks successful. Starting installation."

}

# ----- INSTALL ACTIONS -----

# install operand custom resources
apply_custom_resources() {

    preinstall_checks

    echo "------------- Creating custom resources in ${namespace} namespace -------------"

    validate_file_exists "${cr_file}"

    if [[ -n "${scale_config}" ]]; then
        echo "Setting scaleConfig to ${scale_config}."
        sed -i "s|scaleConfig.*|scaleConfig: ${scale_config}|g" "${cr_file}"
    fi

    if [[ -n "${localTektonRuntime}" ]]; then
        echo "Setting localTektonRuntime to ${localTektonRuntime}."
        sed -i "s|localTektonRuntime.*|localTektonRuntime: ${localTektonRuntime}|g" "${cr_file}"
    fi

    if [[ -z ${filestorageclass} && -z ${storagevendor} ]]; then
        echo "storagevendor and filestorageclass both are empty. Setting filestorageclass and blockstorageclass to default managed-nfs-storage"
    fi
    
    if [[ -n "${storageclass}" ]]; then
        echo "Setting storageClass to ${storageclass}."
        sed -i "/^\ \ license:.*/i \ \ storageClass: ${storageclass}" "${cr_file}"
    fi
    if [[ -n "${filestorageclass}" ]]; then
        echo "Setting filestorageclass to ${filestorageclass}."
        sed -i "/^\ \ license:.*/i \ \ fileStorageClass: ${filestorageclass}" "${cr_file}"
    elif [[ -z ${filestorageclass} && -z ${storagevendor} ]]; then
        echo "Setting filestorageclass to default: managed-nfs-storage"
        sed -i "/^\ \ license:.*/i \ \ fileStorageClass: managed-nfs-storage" "${cr_file}"
    fi
    if [[ -n "${blockstorageclass}" ]]; then
        echo "Setting blockstorageclass to ${blockstorageclass}."
        sed -i "/^\ \ license:.*/i \ \ blockStorageClass: ${blockstorageclass}" "${cr_file}"
    elif [[ -z ${blockstorageclass} && -z ${storagevendor} ]]; then
        echo "Setting blockstorageclass to default: managed-nfs-storage"
        sed -i "/^\ \ license:.*/i \ \ blockStorageClass: managed-nfs-storage" "${cr_file}"
    fi
    if [[ -n "${storagevendor}" ]]; then
      if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" ]]; then
        err_exit "storagevendor value must either be \"ocs\" or \"portworx\""
      fi
        echo "Setting storagevendor to ${storagevendor}."
        sed -i "/^\ \ license:.*/i \ \ storageVendor: ${storagevendor}" "${cr_file}"
    fi

    oc apply -f "${cr_file}" -n "${namespace}"

    sleep 30

    # Ensure WS Pipelines is installed
    while [[ "$(oc get pods -n "${namespace}" | grep -E "${operand_pods_prefixes}" | grep -Ec "1/1.*Running" )" -lt "${pods_count}" ]] ; do

      echo "Installation in progress..."
      oc get pods -n "${namespace}" | grep -E "${operand_pods_prefixes}"

     sleep 60

    done

    # Ensure tekton CRDs are installed
    echo "Installed tekton CRDs:"
    oc get crd --no-headers | grep tekton

    echo "WS Pipelines installed successfully."

}

# ----- UNINSTALL ACTIONS -----

delete_custom_resources() {

    echo "------------- Deleting custom resources in ${namespace} namespace -------------"

    validate_file_exists "${cr_file}"
    oc delete -f "${cr_file}" -n "${namespace}"
    sleep 30

    # Delete shared runtime deployments
    while [[ "$(oc get deployment -n "${namespace}" --no-headers -o custom-columns=NAME:.metadata.name -l 'icpdsupport/addOnId=ws-pipelines' -l 'app=tekton-shared-runtime' | wc -l)" -gt 0 ]]; do
      for pr_dep in $(oc get deployment -n "${namespace}" --no-headers -o custom-columns=NAME:.metadata.name -l 'icpdsupport/addOnId=ws-pipelines' -l 'app=tekton-shared-runtime')
      do
        oc delete deployment -n "${namespace}" ${pr_dep}
        sleep 10
      done
    done

    # Ensure WS Pipelines is uninstalled
    while [[ "$(oc get pods -n "${namespace}" | grep -Ec "${operand_pods_prefixes}")" != 0 ]] ; do

      echo "Uninstallation in progress..."
      oc get pods -n "${namespace}" | grep -E "${operand_pods_prefixes}"

      sleep 60

    done

    # Ensure Tekton CRDs are uninstalled
    while [[ $(oc get crd --no-headers | grep -c tekton) != 0 ]]; do

      echo "Waiting for Tekton CRDs deletion ..."

      for crd in $(oc get crd --no-headers | grep tekton | awk '{print $1}'); do

        for cr_object in $(oc get ${crd} --no-headers | awk '{print $1}'); do
            oc delete ${crd} ${cr_object} --ignore-not-found=true
        done
        
        oc patch crd "${crd}" -p '{"metadata":{"finalizers":[]}}' --type=merge
        oc delete crd "${crd}" --ignore-not-found=true --wait=true
        sleep 10
      done

    done

    echo "WS Pipelines uninstalled successfully."
}
