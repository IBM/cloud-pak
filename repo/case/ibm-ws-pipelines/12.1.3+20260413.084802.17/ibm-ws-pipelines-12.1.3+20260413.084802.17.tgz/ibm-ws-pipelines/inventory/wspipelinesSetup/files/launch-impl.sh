#!/bin/bash

# (C) Copyright IBM Corp. 2020, 2021  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this ws pipelines operator

# wspipelines operator specific variables
inventory="wspipelinesSetup"
case_catalog_name="ibm-cpd-wspipelines-operator-catalog"
catalog_namespace="openshift-marketplace"
cr_system_status="betterThanYesterday"
operator_pod_prefix="ibm-cpd-wspipelines-operator"
case_depedencies="ibm-ccs"

# additional variables
wspipelinessetup_defintion_files="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}


# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""
    arch=$(oc version -o json|grep platform|tail -1)

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"
        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")
        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "------------- Installing operator group for ${namespace} namespace -------------"


    local op_grp_file="${wspipelinessetup_defintion_files}/op-olm/operator-group.yaml"
    validate_file_exists "${op_grp_file}"

    if [[ "$(oc get operatorgroup -n "${namespace}" --no-headers 2>/dev/null | wc -l)" -gt 0 ]]; then
        echo "Operator group already exist in ${namespace} namespace, skip creation."
    else
        echo "Creating operator group in ${namespace} namespace..."
        sed <"${op_grp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | oc apply -n "${namespace}" -f -
    fi

}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    echo "------------- Installing catalog source -------------"


    local catalog_source_file="${wspipelinessetup_defintion_files}/op-olm/catalog-source.yaml"
    validate_file_exists "${catalog_source_file}"
    oc apply -f "${catalog_source_file}" -n ${catalog_namespace}

}

# Install utilizing default OLM method
install_operator() {

    validate_install_args

    install_operator_group

    echo "------------- Installing via OLM -------------"


    local subscription_file="${wspipelinessetup_defintion_files}/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"
    local service_account_file="${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_serviceaccount.yaml"
    validate_file_exists "${service_account_file}"

    # check if catalog source is installed
    echo "Checking if catalog source exists..."
    if ! oc get catsrc "${case_catalog_name}" -n "${catalog_namespace}"; then
        echo "Creating catalog source ${case_catalog_name} in ${catalog_namespace} namespace..."
        install_catalog
        echo "Wait for catalog installation to complete."
        sleep 60
    else
        echo "Catalog source ${case_catalog_name} in ${catalog_namespace} namespace exists."
        oc get catsrc "${case_catalog_name}" -n "${catalog_namespace}"

    fi

    # create subscription
    echo "Creating subscription ..."
    oc apply -f "${subscription_file}" -n "${namespace}"



    # Ensure WS Pipelines Operator is installed
    while [[ "$(oc get pods -n "${namespace}" | grep -E "ibm-cpd-wspipelines-operator" |grep -Ec "1/1.*Running" )" != 1 ]] ; do

      echo "Installation in progress..."
      oc get pods -n "${namespace}" | grep -E "ibm-cpd-wspipelines-operator"

      sleep 60

    done

}

# Install utilizing default CLI method
install_operator_native() {

    echo "------------- Installing operator native -------------"

    oc apply -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines.cpd.ibm.com_wspipelines_crd.yaml"
    oc apply -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_role.yaml"
    oc apply -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_role_binding.yaml"
    oc apply -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_serviceaccount.yaml"  -n "${namespace}"

    sed <"${wspipelinessetup_defintion_files}/op-cli/wspipelines_manager.yaml" "s|namespace: system|namespace: ${namespace}|g" | oc apply  -f -

    # Check WS Pipelines Operator status
    while [[ "$(oc get pods -n "${namespace}" | grep -E "ibm-cpd-wspipelines-operator" |grep -Ec "1/1.*Running" )" != 1 ]] ; do

      echo "Installation in progress..."
      oc get pods -n "${namespace}" | grep -E "ibm-cpd-wspipelines-operator"

      sleep 60

    done

}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}
# deletes the catalog source
uninstall_catalog() {

    validate_install_catalog "uninstall"

    local catsrc_file="${wspipelinessetup_defintion_files}/op-olm/catalog-source.yaml"

    echo "------------- Uninstalling catalog source -------------"
    oc delete -f "${catsrc_file}" -n "${catalog_namespace}" --ignore-not-found=true

}

# Uninstall operator installed via OLM
uninstall_operator() {

    echo "------------- Uninstalling operator installed via OLM -------------"

    # Find installed CSV
    csv_name=$(oc get subscription "${case_catalog_name}-subscription" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)

    # Remove the subscription
    echo "Deleting ${case_catalog_name}-subscription subscription..."
    oc delete subscription "${case_catalog_name}-subscription" -n "${namespace}" --ignore-not-found=true

    # Remove the CSV which was generated by the subscription but does not get garbage collected
    if [[ -n "${csv_name}" ]] ;then

      echo "Deleting ${csv_name} csv..."
      oc delete clusterserviceversion "${csv_name}" -n "${namespace}" --ignore-not-found=true

    fi;

    # don't remove operator group, some other may have a dependency
    # oc delete OperatorGroup "${case_catalog_name}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    echo "Deleting WS Pipelines CRD..."
    oc delete crd wspipelines.wspipelines.cpd.ibm.com --ignore-not-found=true

    # delete service account
    echo "Deleting ibm-cpd-wspipelines-operator-serviceaccount serviceaccount..."
    oc delete -n "${namespace}" serviceaccount ibm-cpd-wspipelines-operator-serviceaccount --ignore-not-found=true

    # delete installplan
    install_plan_name=$(oc get installplan -n "${namespace}" --no-headers | grep "${csv_name}" | cut -d' ' -f1 | head -1)

    if [[ -n "${install_plan_name}" ]]; then

      echo "Deleting ${install_plan_name} installplan..."
      oc delete installplan "${install_plan_name}" -n "${namespace}" --ignore-not-found=true

    fi

    # Delete catalog source
    echo "Deleting ${case_catalog_name} catalogsource..."
    oc delete catsrc "${case_catalog_name}" -n "${catalog_namespace}" --ignore-not-found=true

    # Ensure WS Pipelines Operator is uninstalled
    while [[ "$(oc get pods -n "${namespace}" | grep -Ec "${operator_pod_prefix}")" != 0 ]] ; do

      echo "Uninstallation in progress..."
      oc get pods -n "${namespace}" | grep -E "${operator_pod_prefix}"

      sleep 60

    done

    echo "WS Pipelines Operator uninstalled successfully."
}

# Uninstall operator installed via CLI
uninstall_operator_native() {

    echo "------------- Uninstalling operator native -------------"

    oc delete -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines.cpd.ibm.com_wspipelines_crd.yaml"
    oc delete -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_role.yaml"
    oc delete -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_role_binding.yaml"
    oc delete -f "${wspipelinessetup_defintion_files}/op-cli/wspipelines_operator_serviceaccount.yaml" -n "${namespace}"

    sed <"${wspipelinessetup_defintion_files}/op-cli/wspipelines_manager.yaml" "s|namespace: system|namespace: ${namespace}|g" | oc delete  -f -

    # Ensure WS Pipelines Operator is uninstalled
    while [[ "$(oc get pods -n "${namespace}" | grep -Ec "${operator_pod_prefix}")" != 0 ]] ; do

      echo "Uninstallation in progress..."
      oc get pods -n "${namespace}" | grep -E "${operator_pod_prefix}"

      sleep 60

    done

    echo "WS Pipelines Operator uninstalled successfully."

}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
