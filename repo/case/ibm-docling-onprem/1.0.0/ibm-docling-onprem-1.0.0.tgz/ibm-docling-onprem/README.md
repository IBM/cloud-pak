# Name

IBM Docling On-Premises

# Introduction & Summary

IBM Docling On-Premises converts documents such as PDFs, images, and office files into structured formats for search, analytics, and GenAI applications. It runs on an on-premises Red Hat OpenShift cluster and is deployed and managed by the Docling Operator.

The operator reconciles the `DoclingCluster` and `DoclingClusterConfig` custom resources into a complete Docling environment: Docling Serve (API and UI), a Ray cluster for document processing, a Valkey cache, and Triton inference services for layout and OCR models.

## Features

* Document conversion through the Docling Serve API and UI
* Operator-based installation and lifecycle management with the `DoclingCluster` and `DoclingClusterConfig` custom resources
* Small, medium, and large sizing tiers for each IBM licensing edition (production, non-production, reserved production, reserved non-production)
* GPU-accelerated layout and OCR inference with Triton
* Optional TLS for Docling Serve and mTLS for Ray, issued by cert-manager
* Prometheus metrics for Docling, Ray, Valkey, and Triton
* IBM License Service integration for usage tracking

# Details

## Prerequisites

### Resources Required

* Red Hat OpenShift cluster with cluster-admin access, and the `oc` and `helm` (v3+) CLIs
* User-defined workload monitoring enabled
* Red Hat Connectivity Link (RHCL), cert-manager Operator, and Red Hat OpenShift AI (RHOAI) with the `ray` and `kserve` components set to `Managed`
* Node Feature Discovery and NVIDIA GPU Operator, with schedulable GPUs
* IBM License Manager (IBM Licensing Operator) and the `IBMLicensingDefinition` resources for GPU and CPU tracking
* IBM Container Registry (`cp.icr.io`) image pull secret
* S3-compatible artifact storage credentials

# Installing

## Installing Docling On-Premises

The full procedure can be found in the installer downloadable archive `runbooks/docling_on_prem_runbook.md`. In summary:

1. Install the cluster prerequisites in the order given in the prerequisites runbook.

2. Create the Docling namespace and the required secrets:
   * `icr-pull-secret`
   * `docling-serve-artifact-storage`
   * `docling-serve-api-key`
   * `docling-serve-tls` (optional, only if Docling Serve TLS is enabled)

3. Choose a sizing tier and product edition under `samples/<size>/<product>/`, and set the namespace, images, storage, and licensing details in the `DoclingClusterConfig` and `DoclingCluster` files.

4. Deploy the operator controller:
   ```bash
   bash scripts/deploy-docling-operator.sh --docling-namespace=<docling-namespace>
   ```

5. Apply the custom resources:
   ```bash
   oc apply -f samples/<size>/<product>/docling_v1alpha1_doclingclusterconfig.yaml
   oc apply -f samples/<size>/<product>/docling_v1alpha1_doclingcluster.yaml
   ```

6. Verify the deployment and access the Docling UI as described in the runbook.

## Post-installation

These runbooks cover the tasks that remain with the cluster owner:

* `runbooks/docling_on_prem_networking.md`: expose the Docling Serve API and UI with an OpenShift Route
* `runbooks/docling_on_prem_security.md`: egress considerations and ingress `NetworkPolicy`
* `runbooks/docling_on_prem_monitoring.md`: Prometheus `ServiceMonitor` and `PodMonitor` resources

## Configuration

* Edit the `DoclingCluster` and `DoclingClusterConfig` files under `samples/<size>/<product>/` for the Docling stack, and re-apply them with `oc apply`
* Edit `docling-operator/values-cluster.yaml` for operator settings, and re-run the deploy script
* Upgrade and uninstall steps are in the runbook
