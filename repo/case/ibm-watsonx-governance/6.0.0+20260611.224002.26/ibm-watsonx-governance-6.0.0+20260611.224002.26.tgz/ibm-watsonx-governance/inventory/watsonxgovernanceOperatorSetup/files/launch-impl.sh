# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this watsonxgovernance operator

# watsonxgovernance operator specific variables
caseName="ibm-watsonx-governance"
inventory="watsonxgovernanceOperatorSetup"
caseCatalogName="ibm-cpd-watsonx-governance-operator-catalog"
channelName="v6.0"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
case_depedencies="ibm-factsheet ibm-watson-openscale ibm-openpages ibm-wml-cpd ibm-watsonx-ai-ifm"

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-watsonx-governance-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:222df8f0e71a6f60e1d980facd4dda1bb9b646840d6f27209df0fe629e99666a}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
CATALOG_IMAGE="${CATALOG_IMAGE:=ibm-cpd-watsonx-governance-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:69f97a3dcb6b47978d943ecf66df3c09c4de89958ef93d1e0a39aeb668f65638}"
entitledRegistry="icr.io/cpopen"
storageclass=""
backupstorageclass=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-factsheet)
        echo "factsheetOperatorSetup"
        return 0
        ;;
    ibm-openpages)
        echo "operatorSetup"
        return 0
        ;;
    ibm-watson-openscale)
         echo "ibmWatsonOpenscaleOperatorSetup"
         return 0
         ;;
    ibm-wml-cpd)
         echo "wmlOperatorSetup"
         return 0
         ;;
    ibm-watsonx-ai-ifm)
         echo "watsonxaiifmSetup"
         return 0
         ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""
    arch=$($kubernetesCLI version -o json|grep platform|tail -1)

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"
        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")
        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "------------- Installing operator group for $namespace -------------"

    watsonxgovernancesetup_defintion_files="${casePath}/inventory/watsonxgovernanceOperatorSetup/files"
    local opgrp_file="${watsonxgovernancesetup_defintion_files}/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    
    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        $kubernetesCLI -n ${namespace} apply -n ${namespace} ${dryRun} -f ${catsrc_file}
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply 
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
  
        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply -n ${namespace}  ${dryRun} -f -) | cat
    fi

    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    echo "-------------Installing via OLM-------------"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -eq 0 ]]; then
        echo "Operator group in namespace ${namespace} is missing"
        err_exit "Install operator failed"
    fi

    install_catalog

    local subscription_file="${casePath}/inventory/watsonxgovernanceOperatorSetup/files/op-olm/subscription.yaml"
    sed -i "s|sourceNamespace:.*|sourceNamespace: ${namespace}|" ${subscription_file}
    $kubernetesCLI apply -f "${subscription_file}" -n ${namespace}
    echo "Wait for subscription to complete"
    sleep 60

    echo "done"
}

# Install utilizing default CLI method
install_operator_native() {
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="watsonxgovernance"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    watsonxgovernancesetup_defintion_files="${casePath}/inventory/watsonxgovernanceOperatorSetup/files/"

    watsonxgovernance_crd_files="${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance.cpd.ibm.com_watsonxgovernance.yaml"
    validate_file_exists ${watsonxgovernance_crd_files}
    operator_files="${watsonxgovernancesetup_defintion_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_serviceaccount.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role_binding.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role_binding.yaml"

    # Apply yaml files manipulate variable input as required
    # create CDR
    $kubernetesCLI apply ${dryRun} -f ${watsonxgovernance_crd_files}
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role.yaml
    $kubernetesCLI apply ${dryRun} -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_serviceaccount.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role_binding.yaml
    sed <"${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    echo "done"
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/watsonxgovernanceOperatorSetup/files/op-olm/catalog_source.yaml
    sed -i "s|namespace:.*|namespace: ${namespace}|" ${catsrc_file}

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    $kubernetesCLI delete crd watsonxgovernance.watsonxgovernance.cpd.ibm.com --ignore-not-found=true ${dryRun}
    # delete service account
    $kubernetesCLI delete -n "${namespace}" serviceaccount ibm-cpd-watsonx-governance-operator-serviceaccount --ignore-not-found=true ${dryRun}
    # delete installplan
    if [[ -n "${csvName}" ]]; then
      installplanName=$($kubernetesCLI get installplan -n ${namespace} --no-headers|grep $csvName|cut -d' ' -f1|head -1)
      [[ -n "${installplanName}" ]] && { $kubernetesCLI delete installplan "${installplanName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    fi
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    watsonxgovernancesetup_defintion_files="${casePath}/inventory/watsonxgovernanceOperatorSetup/files"

    watsonxgovernance_crd_files="${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance.cpd.ibm.com_watsonxgovernance.yaml"
    validate_file_exists ${watsonxgovernance_crd_files}
    operator_files="${watsonxgovernancesetup_defintion_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_serviceaccount.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role_binding.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role.yaml"
    validate_file_exists "${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role_binding.yaml"

    # Apply yaml files manipulate variable input as required

    sed <"${operator_files}" "s| system| ${namespace}|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    sed <"${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role_binding.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_serviceaccount.yaml
    $kubernetesCLI delete ${dryRun} -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_cluster_role.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${watsonxgovernancesetup_defintion_files}/op-cli/watsonxgovernance_operator_role.yaml
    # delete CDR
    $kubernetesCLI delete ${dryRun} -f ${watsonxgovernance_crd_files}

}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
