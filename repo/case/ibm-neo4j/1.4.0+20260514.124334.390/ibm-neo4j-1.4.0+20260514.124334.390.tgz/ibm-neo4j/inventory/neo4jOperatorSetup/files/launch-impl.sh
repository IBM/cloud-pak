# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this neo4j operator

# neo4j operator specific variables
caseName="ibm-neo4j"
inventory="neo4jOperatorSetup"
caseCatalogName="ibm-cpd-neo4j-operator-catalog"
channelName="v5.0"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-neo4j-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:55f23d6485365381ccc75ca2284a3cd8ec36d9dd02a268bf17bc52a2e5008555}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
CATALOG_IMAGE="${CATALOG_IMAGE:=ibm-cpd-neo4j-operator-catalog}"
CATALOG_DIGEST="${CATALOG_DIGEST:-sha256:82240a5248058a5b3a198021d1cab49a9952a3692008979122a4817cbcf0e290}"
entitledRegistry="icr.io/cpopen"
storageclass=""
backupstorageclass=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""
    arch=$($kubernetesCLI version -o json|grep platform|tail -1)

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"
        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")
        if [ ! -z "$registry" ]; then
            registry_arg="--registry ${registry}"
        else
            registry_arg=""
        fi

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--registry ${registry} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "------------- Installing operator group for $namespace -------------"

    neo4jsetup_defintion_files="${casePath}/inventory/neo4jOperatorSetup/files"
    local opgrp_file="${neo4jsetup_defintion_files}/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -ne 0 ]]; then
        echo "Operator group already exist in namespace ${namespace}, skip creation"
    else
        sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"
    sed -i "s|namespace:.*|namespace: ${namespace}|" ${catsrc_file}
    CATALOG_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${CATALOG_IMAGE}@${CATALOG_DIGEST}

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
        $kubernetesCLI -n ${namespace} apply ${dryRun} -f ${catsrc_file}
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/[^/]*\///")"

        # specical handle of staging registry for testing.
        # replace cp.stg.icr.io/cp/cpd/<image name>:<tag>
        if [[ ${registry} == "cp.stg.icr.io" ]]; then
            local catsrc_image_mod="${registry}/cp/$(echo "${CATALOG_IMAGE_FULL_PATH}" | sed -e "s/.*\///")"
        fi

        # apply catalog source
        sed "${catsrc_file}" -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI -n ${namespace} apply ${dryRun} -f -) | cat
    fi

    echo "done"
}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    echo "-------------Installing via OLM-------------"

    operatorgourpexist=$($kubernetesCLI get operatorgroup -n ${namespace} --no-headers 2>/dev/null|wc -l)
    if [[ ${operatorgourpexist} -eq 0 ]]; then
        echo "Operator group in namespace ${namespace} is missing"
        err_exit "Install operator failed"
    fi

    neo4jsetup_defintion_files="${casePath}/inventory/neo4jOperatorSetup/files"
    local subscription_file="${neo4jsetup_defintion_files}/op-olm/subscription.yaml"
    sed -i "s|sourceNamespace:.*|sourceNamespace: ${namespace}|" ${subscription_file}
    validate_file_exists "${subscription_file}"
    local catalog_source_file="${neo4jsetup_defintion_files}/op-olm/catalog_source.yaml"
    validate_file_exists "${catalog_source_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${namespace}"; then
        echo "Catalog source '${caseCatalogName}' in namespace '${namespace}' is missing"
        err_exit "Install operator failed"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    $kubernetesCLI apply -f "${subscription_file}" -n ${namespace}
    echo "Wait for subscription to complete"
    sleep 60

    echo "done"
}

# Install utilizing default CLI method
install_operator_native() {
    if [ ! -z "$registry" ]; then
        OPERATOR_REGISTRY=$registry
    fi

    # Verfiy arguments are valid
    validate_install_args

    OPERATOR_IMAGE_FULL_PATH=${OPERATOR_REGISTRY}/${OPERATOR_IMAGE}@${OPERATOR_DIGEST}
    OPERATOR_PREFIX="neo4j"

    # Proceed with install
    echo "-------------Installing native sdk1-------------"

    # Verify expected yaml files for install exist
    neo4jsetup_defintion_files="${casePath}/inventory/neo4jOperatorSetup/files/"

    neo4j_crd_files="${neo4jsetup_defintion_files}/op-cli/neo4j.cpd.ibm.com_neo4j.yaml"
    validate_file_exists ${neo4j_crd_files}
    operator_files="${neo4jsetup_defintion_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_serviceaccount.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role_binding.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role_binding.yaml"
    if [ ! -z "$secret" ]; then
        echo -e "\nimagePullSecrets:\n- name: $secret" >> ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_serviceaccount.yaml
    fi

    # Apply yaml files manipulate variable input as required
    # create CDR
    $kubernetesCLI apply ${dryRun} -f ${neo4j_crd_files}
    # create namespace and operator
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role.yaml
    $kubernetesCLI apply ${dryRun} -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_serviceaccount.yaml
    $kubernetesCLI apply ${dryRun} -n "${namespace}" -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role_binding.yaml
    if [ ! -z "${networkPolicy}" ]; then
        echo "installing operator network policy...."
        validate_file_exists "${networkPolicy}"
        $kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${networkPolicy}"
    fi
    sed <"${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply ${dryRun} -f -
    sed <"${operator_files}" "s| system| ${namespace}|g" | sed "s|image: .*|image: ${OPERATOR_IMAGE_FULL_PATH}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    echo "done"
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/neo4jOperatorSetup/files/op-olm/catalog_source.yaml
    sed -i "s|namespace:.*|namespace: ${namespace}|" ${catsrc_file}

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
    $kubernetesCLI delete crd neo4j.neo4j.cpd.ibm.com --ignore-not-found=true ${dryRun}
    # delete service account
    $kubernetesCLI delete -n "${namespace}" serviceaccount ibm-cpd-neo4j-operator-serviceaccount --ignore-not-found=true ${dryRun}
    # delete installplan
    if [[ -n "${csvName}" ]]; then
      installplanName=$($kubernetesCLI get installplan -n ${namespace} --no-headers|grep $csvName|cut -d' ' -f1|head -1)
      [[ -n "${installplanName}" ]] && { $kubernetesCLI delete installplan "${installplanName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }
    fi
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
    neo4jsetup_defintion_files="${casePath}/inventory/neo4jOperatorSetup/files"

    neo4j_crd_files="${neo4jsetup_defintion_files}/op-cli/neo4j.cpd.ibm.com_neo4j.yaml"
    validate_file_exists ${neo4j_crd_files}
    operator_files="${neo4jsetup_defintion_files}/op-cli/manager.yaml"
    validate_file_exists ${operator_files}
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_serviceaccount.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role_binding.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role.yaml"
    validate_file_exists "${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role_binding.yaml"

    # Apply yaml files manipulate variable input as required

    sed <"${operator_files}" "s| system| ${namespace}|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    sed <"${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role_binding.yaml" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete ${dryRun} -f -
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role_binding.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_serviceaccount.yaml
    $kubernetesCLI delete ${dryRun} -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_cluster_role.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f ${neo4jsetup_defintion_files}/op-cli/neo4j_operator_role.yaml
    $kubernetesCLI delete ${dryRun} -n "${namespace}" -f "${networkPolicy}"
    # delete CDR
    $kubernetesCLI delete ${dryRun} -f ${neo4j_crd_files}

}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
