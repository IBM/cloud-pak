# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this neo4j operator

# neo4j operator specific variables
caseName="ibm-neo4j"
inventory="neo4jOperatorSetup"
channelName="v5.4"
cr_system_status="betterThanYesterday"
# - variables specific to catalog/operator installation
case_depedencies=""

# - additional variables
OPERATOR_IMAGE="${OPERATOR_IMAGE:-ibm-cpd-neo4j-operator}"
OPERATOR_DIGEST="${OPERATOR_DIGEST:-sha256:5ab9144eef45254ff2d996dff26b33cc94b6e5611dd2af7c7ab103e1e6c8978f}"
OPERATOR_REGISTRY="${OPERATOR_REGISTRY:-icr.io/cpopen}"
entitledRegistry="icr.io/cpopen"
storageclass=""
filestorageclass=""
blockstorageclass=""
storagevendor=""
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
casePath="${scriptDir}/../../../../.."


# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_neo4j.yaml

    echo "storagevendor: ${storagevendor}, storageclass: ${storageclass}, filestorageclass: ${filestorageclass}, blockstorageclass: ${blockstorageclass}"
    if [[ -z ${filestorageclass} && -z ${storageclass} ]]; then
        err_exit "storageclass and filestorageclass MUST not all empty"
    fi

    validate_file_exists "$cr"
    cp $cr ${casePath}/inventory/${inventory}/files/op-cli/tmp_cpd_v1beta1_neo4j.yaml
    local tmpcr="${casePath}/inventory/${inventory}/files/op-cli/tmp_cpd_v1beta1_neo4j.yaml"
    validate_file_exists "$tmpcr"

    if [[ ! -z $storageclass ]]; then
        sed -i "/^\ \ license:.*/i \ \ storageClass: ${storageclass}" ${tmpcr}
    fi
    if [[ ! -z $filestorageclass ]]; then
        sed -i "/^\ \ license:.*/i \ \ fileStorageClass: ${filestorageclass}" ${tmpcr}
    fi
    if [[ ! -z $blockstorageclass ]]; then
        sed -i "/^\ \ license:.*/i \ \ blockStorageClass: ${blockstorageclass}" ${tmpcr}
    fi
    echo "AFTER processing filestorageclass and blockstorageclass"
    cat ${tmpcr}

    echo
    echo

    if [[ -z $storagevendor ]]; then
        sed "${tmpcr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
        if [[ ${storagevendor} != "ocs" && ${storagevendor} != "portworx" && ${storagevendor} != "\"\"" ]]; then
            err_exit "storagevendor value must be empty, \"ocs\" or \"portworx\""
        fi
        sed "${tmpcr}" -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" -e "/^\ \ license:.*/i \ \ storageVendor: ${storagevendor}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi
    rm ${tmpcr}
}

# ----- UNINSTALL ACTIONS -----

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/op-cli/cpd_v1beta1_neo4j.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" ${dryRun}
}
