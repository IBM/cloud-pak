# IBM Maximo AI Service

Operator for IBM Maximo AI Service
