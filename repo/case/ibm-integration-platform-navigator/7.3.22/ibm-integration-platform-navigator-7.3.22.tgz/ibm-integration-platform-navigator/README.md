# Name

IBM&reg; Cloud Pak for Integration

# Introduction

**Note:** This operator was previously called the **IBM Cloud Pak for Integration Platform Navigator** operator.

The Cloud Pak for Integration operator provides a UI to allow users to deploy and manage new instances of the Cloud Pak components, and allows navigation between them in a simple, consistent manner.
The Cloud Pak for Integration offers a simplified solution to integration challenges, allowing enterprises to modernize its processes while positioning itself for future innovation.
Once installed, Cloud Pak for Integration eases monitoring, maintenance and upgrades, helping the enterprise stay ahead of the innovation curve.

# Details
The following components can be managed in the Platform UI:
- IBM API Connect, implementing managed APIs
- IBM App Connect Enterprise, providing integration workflows
- IBM App Connect Designer, to build integration flows with prebuilt connectors and no-code templates
- IBM MQ, for secure and reliable assured delivery
- IBM Aspera HSTS, for large file transfers
- IBM DataPower Gateway, for a purpose-built security and integration gateway
- IBM Automation Foundation assets, to store, manage, retrieve and search integration assets
- IBM Integration tracing, to track and trace integrations built in IBM Automation
- IBM Event Streams, for event handling based on Kafka

## Prerequisites
**Installing the operator**
- **Operator v4.0 channel:** Red Hat OpenShift version 4.4.4 or later, with 4.4.13 or later preferred.
- **Operator v4.1-eus channel:** Red Hat Openshift version 4.6 or later.
- **Operator v4.2 channel:** Red Hat Openshift version 4.6 or later.
- **Operator v5.0 channel:** Red Hat Openshift version 4.6 or later.
- **Operator v5.1 channel:** Red Hat Openshift version 4.6 or later.
- **Operator v5.2 channel:** Red Hat Openshift version 4.6 or later.
- **Operator v5.3 channel:** Red Hat Openshift version 4.6 or later.
- **Operator v6.0 channel:** Red Hat Openshift version 4.10.
- **Operator v7.0 channel:** Red Hat Openshift version 4.10.
- A user with the cluster administrator role.

**Creating an instance of the Platform UI with the operator**
- A user with the edit role or above for the namespace where the instance will be created.
- For online clusters, create a secret called `ibm-entitlement-key` in the namespace where the instance will be created. The secret must contain `cp` as the username, `cp.icr.io` as the docker server, and an entitlement key as the password. Get an entitlement key from the [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).
- For restricted environments, [configure the cluster for image mirroring](https://www.ibm.com/docs/en/cloud-paks/cp-integration/latest?topic=installing-in-air-gapped-environment).

## Resources Required
- The operator requests 0.4 CPU cores and 0.5 Gi memory.
- Each Platform UI requests 2.2 CPU cores and 4.6 Gi memory, but can be run with fewer resources with lower performance.
- The IBM Cloud Pak foundational services operator and its dependencies will be installed automatically when you install the IBM Cloud Pak for Integration operator. For more information, see hardware requirements and recommendations for IBM Common Services.
- A RWX storage class is required for the Platform UI.

## Installing
See the [Cloud Pak for Integration IBM Documentation](https://ibm.biz/integration-documentation) for installation instructions.

# Configuration
See the [Cloud Pak for Integration IBM Documentation](https://ibm.biz/integration-documentation) for configuration options.

### Limitations
- Only runs on amd64, s390x and ppc64le architectures
- Only runs on Linux operating systems

### Red Hat OpenShift SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
- Both the operator and the instance of the Platform UI run under Red Hat restricted SCC.

### Supported Versions
The following outlines which Platform UI versions are supported by each operator channel:
- **Operator v4.0 channel:** Supports versions 2020.3.1-1, 2020.3.1-0, 2020.2.1.1-0, and 2020.2.1-0. Supported architectures: amd64 and s390x.
- **Operator v4.1-eus channel:** Supports versions 2020.4.1-11, 2020.4.1-10, 2020.4.1-9, 2020.4.1-8, 2020.4.1-7, 2020.4.1-6, 2020.4.1-5, 2020.4.1-4, 2020.4.1-3, 2020.4.1-2, 2020.4.1-1, 2020.4.1-0, 2020.3.1-1, 2020.3.1-0, 2020.2.1.1-0, and 2020.2.1-0. Supported architectures: amd64 and s390x.
- **Operator v4.2 channel:** Supports versions 2021.1.1-0, 2020.4.1-1, 2020.4.1-0, 2020.3.1-1, and 2020.3.1-0. Deprecates versions 2020.2.1.1-0 and 2020.2.1-0. Supported architectures: **only** amd64.
- **Operator v5.0 channel:** Supports versions 2021.2.1-0, 2021.1.1-0, 2020.4.1-2, 2020.4.1-1, 2020.4.1-0. Deprecates versions 2020.3.1-1 and 2020.3.1-0. Versions 2020.2.1.1-0 and 2020.2.1-0 are removed. Supported architectures: **only** amd64.
- **Operator v5.1 channel:** Supports versions 2021.3.1-0, 2021.2.1-0, 2021.1.1-0, 2020.4.1-3, 2020.4.1-2, 2020.4.1-1, 2020.4.1-0. Deprecates versions 2020.3.1-1 and 2020.3.1-0. Supported architectures: amd64 and s390x.
- **Operator v5.2 channel:** Supports versions 2021.4.1-0, 2021.3.1-0, 2021.2.1-0, 2021.1.1-0, 2020.4.1-5, 2020.4.1-4, 2020.4.1-3, 2020.4.1-2, 2020.4.1-1, 2020.4.1-0. Deprecates versions 2020.3.1-1 and 2020.3.1-0. Supported architectures: amd64, s390x and ppc64le.
- **Operator v5.3 channel:** Supports versions 2021.4.1-2, 2021.4.1-1, 2021.4.1-0, 2021.3.1-0, 2021.2.1-0. Deprecates versions 2021.1.1-0, 2020.4.1-7, 2020.4.1-6, 2020.4.1-5, 2020.4.1-4, 2020.4.1-3, 2020.4.1-2, 2020.4.1-1, 2020.4.1-0, 2020.3.1-1 and 2020.3.1-0. Supported architectures: amd64, s390x and ppc64le.
- **Operator v6.0 channel:** Supports versions 2022.2.1-4, 2022.2.1-3, 2022.2.1-2, 2022.2.1-1, 2022.2.1-0 and 2022.2.1-0. Deprecates versions 2021.4.1-2, 2021.4.1-1, 2021.4.1-0, 2021.3.1-0, 2021.2.1-0, 2021.1.1-0, 2020.4.1-8, 2020.4.1-7, 2020.4.1-6, 2020.4.1-5, 2020.4.1-4, 2020.4.1-3, 2020.4.1-2, 2020.4.1-1 and 2020.4.1-0. Versions 2020.3.1-0 and 2020.3.1-1 are removed. Supported architectures: amd64, s390x and ppc64le.
- **Operator v7.0 channel:** Supports versions 2022.4.1-0, 2022.2.1-4, 2022.2.1-3, 2022.2.1-2, 2022.2.1-1 and 2022.2.1-0. Versions 2021.4.1-2, 2021.4.1-1, 2021.4.1-0, 2021.3.1-0, 2021.2.1-0, 2021.1.1-0, 2020.4.1-8, 2020.4.1-7, 2020.4.1-6, 2020.4.1-5, 2020.4.1-4, 2020.4.1-3, 2020.4.1-2, 2020.4.1-1 and 2020.4.1-0 are removed. Supported architectures: amd64, s390x and ppc64le.

*Copyright IBM Corporation 2020-2022. All Rights Reserved.*
