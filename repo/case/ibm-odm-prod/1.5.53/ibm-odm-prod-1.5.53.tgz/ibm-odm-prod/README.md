# ibm-odm-prod
The ibm-odm-prod CASE is an IBM packaged version of an production-ready version of [IBM® Operational Decision Manager](https://www.ibm.com/us-en/marketplace/operational-decision-manager).

# Introduction
This CASE provides a helm chart to install a production-ready cluster of ODM in IBM Kubernetes environments.

## Summary
ODM is a tool for capturing, automating, and governing repeatable business decisions. You identify situations about your business and then automate the actions to take as a result of the insight you gained about your policies and customers. For more information, see [ODM in knowledge center](https://www.ibm.com/docs/en/odm/8.11.1).

# Details
This CASE contains a single inventory item:
- ibmOdmProd - a helm chart that bootstrap an ODM deployment on a Kubernetes cluster

# Prerequisites

- Kubernetes 1.19+ with Beta APIs enabled
- Helm 3.2 and later version
- One PersistentVolume needs to be created prior to installing the chart if `internalDatabase.persistence.enabled=true` and `internalDatabase.persistence.dynamicProvisioning=false`.
- To preserve sensitive data, you must create a secret that encapsulates the database user and password before you install the Helm release.

Before you install ODM for production, you need to gather all the configuration information that you will use for your release. For more information, refer to the [Prerequisites section](./inventory/ibmOdmProd/README.md#prerequisites) of the Chart Readme.

# Installing the CASE

The following instructions should be executed as namespace administrator.

Add the public IBM Helm charts repository and install the chart:

  ```console
  $ helm repo add ibm-charts-entitled https://raw.githubusercontent.com/IBM/charts/master/repo/entitled
  $ helm repo update
  $ helm install my-odm-prod-release \
    --set license=true \
    --set usersPassword=my-password \
    --set internalDatabase.secretCredentials=my-odm-db-secret \
    ibm-charts-entitled/ibm-odm-prod
  ```

  > Note: In OpenShift, you must set the following parameters `--set customization.runAsUser=''`. Refer to [Required Parameters](#required-parameters) for more information.

## Required Parameters

- Review the [product license](LICENSES/LICENSE-EN) and set `license=true` to accept the license agreement.

- If you want to use the default user access, you **must** define a password to be used by the default users like *odmAdmin* by setting the parameter `usersPassword`. Refer to [Configuring user access](https://www.ibm.com/docs/en/odm/8.11.1?topic=production-configuring-user-access) to provide customized user access.

- Specify the name of the secret, created in [Prerequisites](#prerequisites) section, as the value for the parameters `internalDatabase.secretCredentials` or `externalDatabase.secretCredentials`, depending on the type of database you use.

- If you are deploying on OpenShift, you must define the `customization.runAsUser` parameter as empty since the **restricted** scc requires to use an arbitrary UID.
  ```console
  $ helm install my-odm-prod-release \
    --set license=true \
    --set usersPassword=my-password \
    --set internalDatabase.secretCredentials=my-odm-db-secret \
    --set customization.runAsUser='' \
    ibm-charts-entitled/ibm-odm-prod
  ```
  > **Note**: Similarly, if you use the internal database, `internalDatabase.runAsUser` should be set empty.
  For more information, refer to the [Red Hat OpenShift SecurityContextConstraints Requirements](#red-hat-openshift-securitycontextconstraints-requirements) section.

## Resources Required

The default resources configuration are the following:

| Service  | CPU Request | CPU Limit | Memory Request (Mi) | Memory Limit (Mi) | Replica Count |
| - | - | - | - | - | - |
| Decision Center | 0.5 | 2 | 1500 | 4096 | 1 |
| Decision Runner | 0.5 | 2 | 512 | 4096 | 1 |
| Decision Server Console | 0.5 | 2 | 512 | 1024 | 1 |
| Decision Server Runtime | 0.5 | 2 | 512 | 4096 | 1 |
| **Total**  | **2CPU** | **4CPU** | **3036Mi** | **13Gi** | **/** |

Cluster Node: 1
Networking speed: 1Gbs

For more information on customization and recommended profiles, refer to the [Resources Required section](./inventory/ibmOdmProd/README.md#resources-required) of the Chart Readme.

## Internal Storage Requirements

Use cases for PostgreSQL as an internal database:

- Persistent storage using Kubernetes dynamic provisioning. Uses the default storageclass defined by the Kubernetes admin or by using a custom storageclass which will override the default.
 - Set global values to:
   - **internalDatabase.persistence.enabled**: `true` (default)
   - **internalDatabase.persistence.useDynamicProvisioning**: `true`
 - Specify a custom *storageClassName* per volume or leave the value empty to use the default *storageClass*.

- Persistent storage using a predefined *PersistentVolumeClaim* or *PersistentVolume* setup prior to the deployment of this chart
 - Set global values to:
   - **internalDatabase.persistence.enabled**: `true` (default)
   - **internalDatabase.persistence.useDynamicProvisioning**: `false` (default)
 - Kubernetes binding process selects a pre-existing volume based on the accessMode and size.

## Security Requirements

### Service Account Requirements

  By default, the chart creates and uses the custom serviceAccount named `<releasename>-ibm-odm-prod-service-account`.

  The serviceAccount should be granted the appropriate PodSecurityPolicy or SecurityContextConstraints depending on your cluster. Refer to the [PodSecurityPolicy Requirements](#podsecuritypolicy-requirements) or [Red Hat OpenShift SecurityContextConstraints Requirements](#red-hat-openshift-securitycontextconstraints-requirements) documentation.

### PodSecurityPolicy Requirements

  This chart requires a PodSecurityPolicy to be bound to the target namespace prior to installation. To meet this requirement, a specific cluster and namespace might have to be scoped by a cluster administrator.

  The predefined PodSecurityPolicy name [`ibm-restricted-psp`](https://ibm.biz/cpkspec-psp) has been verifed for this chart. If your target namespace is bound to this PodSecurityPolicy, you can proceed to install the chart.

  This chart also defines a custom PodSecurityPolicy which can be used to finely control the permissions/capabilities needed to deploy this chart. A cluster administrator can create the custom PodSecurityPolicy and the ClusterRole by applying the following descriptors files in the appropriate namespace:

  <details>
  <summary>Custom PodSecurityPolicy definition:</summary>

  ```yaml
  apiVersion: extensions/v1beta1
  kind: PodSecurityPolicy
  metadata:
    name: ibm-odm-psp
  spec:
    allowPrivilegeEscalation: false
    forbiddenSysctls:
    - '*'
    fsGroup:
      ranges:
      - max: 65535
        min: 1
      rule: MustRunAs
    requiredDropCapabilities:
    - ALL
    runAsUser:
      rule: MustRunAsNonRoot
    seLinux:
      rule: RunAsAny
    supplementalGroups:
      ranges:
      - max: 65535
        min: 1
      rule: MustRunAs
    volumes:
    - configMap
    - emptyDir
    - projected
    - secret
    - downwardAPI
    - persistentVolumeClaim
  ```
  </details>

  <details>
  <summary>Custom ClusterRole for the custom PodSecurityPolicy:</summary>

  ```yaml
  apiVersion: rbac.authorization.k8s.io/v1
  kind: ClusterRole
  metadata:
    name: ibm-odm-clusterrole
  rules:
  - apiGroups:
    - extensions
    resourceNames:
    - ibm-odm-psp
    resources:
    - podsecuritypolicies
    verbs:
    - use
  ```
  </details>


### Red Hat OpenShift SecurityContextConstraints Requirements

  This chart requires a SecurityContextConstraints to be granted to the serviceAccount prior to installation.
  A cluster administrator can either bind the SecurityContextConstraints to the target namespace or add the scc specifically to the serviceAccount.

  The predefined SecurityContextConstraints name: [`restricted`](https://ibm.biz/cpkspec-scc) has been verified for this chart. In Openshift, `restricted` is used by default for authenticated users.

  > **Note**: To use the `restricted` scc, you must define the `customization.runAsUser` parameter as empty. Similarly, if you use the internal database, `internalDatabase.runAsUser` should be set empty.

  This chart also defines a custom SecurityContextConstraints which can be used to finely control the permissions/capabilities needed to deploy this chart. A cluster administrator can create the custom SecurityContextConstraints by applying the following descriptors files in the appropriate namespace:

  <details>
  <summary>Custom SecurityContextConstraints definition:</summary>

  ```yaml
  apiVersion: security.openshift.io/v1
  kind: SecurityContextConstraints
  metadata:
    annotations:
    name: ibm-odm-scc
  allowHostDirVolumePlugin: false
  allowHostIPC: false
  allowHostNetwork: false
  allowHostPID: false
  allowHostPorts: false
  allowPrivilegedContainer: false
  allowPrivilegeEscalation: false
  allowedCapabilities: []
  allowedFlexVolumes: []
  allowedUnsafeSysctls: []
  defaultAddCapabilities: []
  defaultPrivilegeEscalation: false
  forbiddenSysctls:
    - "*"
  fsGroup:
    type: MustRunAs
    ranges:
    - max: 65535
      min: 1
  readOnlyRootFilesystem: false
  requiredDropCapabilities:
  - ALL
  runAsUser:
    type: MustRunAsRange
  seccompProfiles:
  - docker/default
  seLinuxContext:
    type: RunAsAny
  supplementalGroups:
    type: MustRunAs
    ranges:
    - max: 65535
      min: 1
  volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
  priority: 0
  ```
  </details>

## Configuration
Refer to the [Configuration section](./inventory/ibmOdmProd/README.md#configuration) of the Chart Readme.

## Limitations

The following ODM on premises features are not supported:
[Features not included](https://www.ibm.com/docs/en/odm/8.11.1?topic=kubernetes-features-not-included-in-odm-certified)

## Documentation

See [ODM on Certified Kubernetes in knowledge center](https://www.ibm.com/docs/en/odm/8.11.1?topic=operational-decision-manager-certified-kubernetes-8111).

You can find step-by-step guides on how to deploy an Operational Decision Manager (ODM) instance on different platforms (Amazon Elastic Kubernetes Service (EKS), Google Kubernetes Engine (GKE) and Azure kubernetes Service (AKS)) and configure ODM with custom SSO like Okta, in the [DecisionsDev/odm-docker-kubernetes](https://github.com/DecisionsDev/odm-docker-kubernetes/blob/master/README.md) repository.
