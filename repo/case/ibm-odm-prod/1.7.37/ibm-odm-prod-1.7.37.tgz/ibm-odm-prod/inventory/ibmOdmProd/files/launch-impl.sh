# (C) Copyright IBM Corp. 2023  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName="ibm-odm-prod"
inventory="ibmOdmProd"
caseCatalogName="xx"
channelName="xx"

# variables specific to catalog installation
catalogNamespace="openshift-marketplace"

# implement functions to install or uninstall products
# example

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --foo)
        echo "$val"
        ;;
    --bar)
        echo "do something"
        ;;
    esac
}

install() {
    echo "Please use helm install cli"
}

uninstall() {
    echo "Please use helm install cli"
}
