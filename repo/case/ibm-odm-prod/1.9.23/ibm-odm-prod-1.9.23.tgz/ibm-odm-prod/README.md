# ibm-odm-prod
The ibm-odm-prod CASE is an IBM packaged version of an production-ready version of [IBM® Operational Decision Manager](https://www.ibm.com/us-en/marketplace/operational-decision-manager).

# Introduction
This CASE provides a helm chart to install a production-ready cluster of ODM in IBM Kubernetes environments.

## Summary
ODM is a tool for capturing, automating, and governing repeatable business decisions. You identify situations about your business and then automate the actions to take as a result of the insight you gained about your policies and customers. For more information, see [ODM in knowledge center](https://www.ibm.com/docs/en/odm/9.0.0).

# Details
This CASE contains a single inventory item:
- ibmOdmProd - a helm chart that bootstrap an ODM deployment on a Kubernetes cluster

# Prerequisites

- Kubernetes 1.25+ 
- Helm 3.9.x and later version. Please refer to this [table](https://helm.sh/docs/topics/version_skew/#supported-version-skew) to determine what version of Helm is compatible with your cluster.
- One PersistentVolume needs to be created prior to installing the chart if `internalDatabase.persistence.enabled=true` and `internalDatabase.persistence.dynamicProvisioning=false`.  In that case, it is required that the securityContext.fsGroup 26 has read and write permissions on the postgres data directory. You can update the permissions by mounting the volume temporarily or accessing the host machine and performing the following commands:

  ```console
  chown -R 26:26 /var/lib/pgsql/data
  chmod -R ug+rw /var/lib/pgsql/data
  ```
  Refer to [Internal Storage Requirements](#internal-storage-requirements) section for more information.
  
- To preserve sensitive data, you must create a secret that encapsulates the database user and password before you install the Helm release.
  ```
  kubectl create secret generic my-odm-db-secret \
          --from-literal=db-user=<user-name> \
          --from-literal=db-password=<password>
  ```

  For details, refer to [Configuring the database](https://www.ibm.com/docs/en/odm/9.0.0?topic=production-configuring-database).

Before you install ODM for production, you need to gather all the configuration information that you will use for your release. For more information, refer to the [Prerequisites section](./inventory/ibmOdmProd/README.md#prerequisites) of the Chart Readme.

# Installing the CASE

The following instructions should be executed as namespace administrator.

1. Create a secret to use the Entitled Registry

    - To get your entitlement key, log in to [MyIBM Container Software Library](https://myibm.ibm.com/products-services/containerlibrary) with the IBMid and password that are associated with the entitled software.

    - In the **Container software library** tile, verify your entitlement on the **View library** page, and then go to **Get entitlement key**  to retrieve the key.

    - Create the pull secret:

    ```shell
    kubectl create secret docker-registry icregistry-secret \
        --docker-server=cp.icr.io \
        --docker-username=cp \
        --docker-password="<API_KEY_GENERATED>" \
        --docker-email=<USER_EMAIL>
    ```

    Where:

    - *API_KEY_GENERATED* is the entitlement key from the previous step. Make sure you enclose the key in double-quotes.
    - *USER_EMAIL* is the email address associated with your IBMid.

    > Note: The **cp.icr.io** value for the docker-server parameter is the only registry domain name that contains the images. You must set the *docker-username* to **cp** to use an entitlement key as *docker-password*.

2. Add the public IBM Helm charts repository and install the chart:

  ```console
  helm repo add ibm-helm https://raw.githubusercontent.com/IBM/charts/master/repo/ibm-helm
  helm repo update
  helm install my-odm-prod-release \
    --set license=true \
    --set image.pullSecrets=icregistry-secret \
    --set usersPassword=my-password \
    --set internalDatabase.secretCredentials=my-odm-db-secret \
    --set internalDatabase.populateSampleData=true \
    ibm-helm/ibm-odm-prod
  ```

  > Note: In OpenShift, you must set the following parameters `--set customization.runAsUser='' --set internalDatabase.runAsUser=''`  and you can also set the parameter `--set service.enableRoute=true`. Refer to [Required Parameters](#required-parameters) for more information.

## Required Parameters

- Review the [product license](LICENSES/LICENSE-EN) and set `license=true` to accept the license agreement.

- If you want to use the default user access, you **must** define a password to be used by the default users like *odmAdmin* by setting the parameter `usersPassword`. Refer to [Configuring user access](https://www.ibm.com/docs/en/odm/9.0.0?topic=production-configuring-user-access) to provide customized user access.

- Specify the name of the secret, created in [Prerequisites](#prerequisites) section, as the value for the parameters `internalDatabase.secretCredentials` or `externalDatabase.secretCredentials`, depending on the type of database you use.

- If you are deploying on OpenShift, you must define the `customization.runAsUser` parameter as empty since the **restricted** scc requires to use an arbitrary UID.

- Similarly, if you use the internal database, `internalDatabase.runAsUser` should be set empty. For more information, refer to the [Red Hat OpenShift SecurityContextConstraints Requirements](#red-hat-openshift-securitycontextconstraints-requirements) section.

Here is an example to install ODM on Openshift including a PostgreSQL internal database with samples:
  ```console
  helm install my-odm-prod-release \
    --set license=true \
    --set image.pullSecrets=icregistry-secret \
    --set usersPassword=my-password \
    --set internalDatabase.secretCredentials=my-odm-db-secret \
    --set internalDatabase.populateSampleData=true \
    --set internalDatabase.runAsUser='' \    
    --set customization.runAsUser='' \
    --set service.enableRoute=true \
    ibm-helm/ibm-odm-prod
  ```

Refer to the [Configuration](#configuration) section for advanced configuration. You can find the default values of all parameters in the [ODM for production configuration parameters](https://www.ibm.com/docs/en/odm/9.0.0?topic=reference-odm-production-configuration-parameters).

## Resources Required

The default resources configuration are the following:

| Service  | CPU Request | CPU Limit | Memory Request (Mi) | Memory Limit (Mi) | Replica Count |
| - | - | - | - | - | - |
| Decision Center | 0.5 | 2 | 1500 | 4096 | 1 |
| Decision Runner | 0.5 | 2 | 512 | 4096 | 1 |
| Decision Server Console | 0.5 | 2 | 512 | 1024 | 1 |
| Decision Server Runtime | 0.5 | 2 | 512 | 4096 | 1 |
| **Total**  | **2CPU** | **4CPU** | **3036Mi** | **13Gi** | **/** |

Cluster Node: 1
Networking speed: 1Gbs

For more information on customization and recommended profiles, refer to the [Resources Required section](./inventory/ibmOdmProd/README.md#resources-required) of the Chart Readme.

## Internal Storage Requirements

Use cases for PostgreSQL as an internal database:

- Persistent storage using Kubernetes dynamic provisioning. Uses the default storageclass defined by the Kubernetes admin or by using a custom storageclass which will override the default.
 - Set global values to:
   - **internalDatabase.persistence.enabled**: `true` (default)
   - **internalDatabase.persistence.useDynamicProvisioning**: `true`
 - Specify a custom *storageClassName* per volume or leave the value empty to use the default *storageClass*.

- Persistent storage using a predefined *PersistentVolumeClaim* or *PersistentVolume* setup prior to the deployment of this chart
 - Set global values to:
   - **internalDatabase.persistence.enabled**: `true` (default)
   - **internalDatabase.persistence.useDynamicProvisioning**: `false` (default)
 - Kubernetes binding process selects a pre-existing volume based on the accessMode and size.

## Security Requirements

### Service Account Requirements

By default, the chart creates and uses a custom service account named `<releasename>-ibm-odm-prod-service-account`.

The service account should be granted the appropriate `SecurityContextConstraints` (SCC) depending on your cluster.
 Refer [Red Hat OpenShift SecurityContextConstraints Requirements](#red-hat-openshift-securitycontextconstraints-requirements) documentation for specific guidelines.

You can also configure the chart to use a custom service account. In this case, a cluster administrator can create the custom service account, and the namespace administrator can configure the chart to use this service account by setting the `serviceAccountName` parameter:

```console
helm install my-odm-prod-release \
  --set license=true \
  --set serviceAccountName=ibm-odm-prod-service-account \
  --set image.pullSecrets=icregistry-secret \
  --set usersPassword=my-password \
  --set internalDatabase.secretCredentials=my-odm-db-secret \
  --set internalDatabase.populateSampleData=true \
  ibm-helm/ibm-odm-prod
```

### Pod Security

Red Hat OpenShift Container Platform (OCP) provides Pod security using `SecurityContextConstraints` (SCC) resources to enforce policies based on user and group mappings, similar to the Kubernetes Pod Security Policy (PSP) API. Starting with Kubernetes v1.25, the Pod Security Admission (PSA) controller replaces PSP and introduces namespace-based enforcement for Pod security, simplifying management.

From OpenShift 4.11 onwards, the PSA controller which enforces Pod security standards at the namespace level is supported. For more details, refer to [Understanding and Managing Pod Security Admission](https://kubernetes.io/docs/concepts/security/pod-security-admission/).

### Pod Security Context

The following Pod Security Contexts are recommended for ODM pods to comply with Kubernetes and OpenShift security standards (compatible with both the `restricted` SCC in OpenShift <4.11 and `restricted-v2` SCC in OpenShift 4.11+):

```yaml
securityContext:
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: true
  capabilities:
    drop:
    - ALL
  runAsNonRoot: true
```

### Security context parameters description

- **`allowPrivilegeEscalation: false`**  
  Prevents processes in the container from gaining additional privileges, even if the process could potentially do so. This is a key security measure to block privilege escalation attempts.

- **`privileged: false`**  
  Disables access to the host’s devices and limits actions requiring root privileges. This ensures that the container's scope of actions is limited, reducing the risk of compromising the node.

- **`readOnlyRootFilesystem: true`**  
  Ensures that the root file system remains immutable, reducing the potential for attacks that involve modifying executable files or system libraries within the container.

- **`capabilities: drop: - ALL`**  
  Drops all Linux capabilities to run the container with the least privileges possible, reducing the attack surface. This follows the principle of least privilege to minimize the risk of privilege escalation.

- **`runAsNonRoot: true`**  
  Enforces that the container runs as a non-root user. If an image attempts to run as the root user (UID 0), the container will fail to start, ensuring that no process in the container has root privileges.

These settings align with the latest Kubernetes security standards and are compatible with Kubernetes-native clusters and OpenShift environments.

For OpenShift-specific changes to Pod Security Standards, see [Important OpenShift changes to Pod Security Standards](https://connect.redhat.com/en/blog/important-openshift-changes-pod-security-standards).

If you are upgrading from older Kubernetes versions to v1.25 and above, refer to [Kubernetes Migrate from PSP](https://kubernetes.io/docs/tasks/configure-pod-container/migrate-from-psp/) for guidance on migrating from PSP to the new PSA controller.

### Red Hat OpenShift SecurityContextConstraints Requirements

  This chart requires a SecurityContextConstraints to be granted to the serviceAccount prior to installation.
  A cluster administrator can either bind the SecurityContextConstraints to the target namespace or add the scc specifically to the serviceAccount.

  The predefined SecurityContextConstraints name: [`restricted`](https://ibm.biz/cpkspec-scc) has been verified for this chart. In Openshift, `restricted` is used by default for authenticated users.

  > **Note**: To use the `restricted` scc, you must define the `customization.runAsUser` parameter as empty. Similarly, if you use the internal database, `internalDatabase.runAsUser` should be set empty.

  This chart also defines a custom SecurityContextConstraints which can be used to finely control the permissions/capabilities needed to deploy this chart. A cluster administrator can create the custom SecurityContextConstraints by applying the following descriptors files in the appropriate namespace:

  <details>
  <summary>Custom SecurityContextConstraints definition:</summary>

  ```yaml
  apiVersion: security.openshift.io/v1
  kind: SecurityContextConstraints
  metadata:
    annotations:
    name: ibm-odm-scc
  allowHostDirVolumePlugin: false
  allowHostIPC: false
  allowHostNetwork: false
  allowHostPID: false
  allowHostPorts: false
  allowPrivilegedContainer: false
  allowPrivilegeEscalation: false
  allowedCapabilities: []
  allowedFlexVolumes: []
  allowedUnsafeSysctls: []
  defaultAddCapabilities: []
  defaultPrivilegeEscalation: false
  forbiddenSysctls:
    - "*"
  fsGroup:
    type: MustRunAs
    ranges:
    - max: 65535
      min: 1
  readOnlyRootFilesystem: false
  requiredDropCapabilities:
  - ALL
  runAsUser:
    type: MustRunAsRange
  seccompProfiles:
  - docker/default
  seLinuxContext:
    type: RunAsAny
  supplementalGroups:
    type: MustRunAs
    ranges:
    - max: 65535
      min: 1
  volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
  priority: 0
  ```
  </details>

### Tracking ODM usage with the IBM License Service
Refer to the [Tracking ODM usage with the IBM License Service section](./inventory/ibmOdmProd/README.md#tracking-odm-usage-with-the-ibm-license-service) of the Chart Readme.

## Configuration
Refer to the [Configuration section](./inventory/ibmOdmProd/README.md#configuration) of the Chart Readme.

## Limitations

The following ODM on premises features are not supported:
[Features not included](https://www.ibm.com/docs/en/odm/9.0.0?topic=kubernetes-decision-features-not-included)

## Documentation

See [ODM on Certified Kubernetes in knowledge center](https://www.ibm.com/docs/en/odm/9.0.0?topic=operational-decision-manager-certified-kubernetes-900).

You can find step-by-step guides on how to deploy an Operational Decision Manager (ODM) instance on different platforms (Amazon Elastic Kubernetes Service (EKS), Google Kubernetes Engine (GKE), Azure kubernetes Service (AKS), and Red Hat OpenShift Kubernetes Service on IBM Cloud (ROKS)) and configure ODM with custom SSO like Okta, in the [DecisionsDev/odm-docker-kubernetes](https://github.com/DecisionsDev/odm-docker-kubernetes/blob/master/README.md) repository.
