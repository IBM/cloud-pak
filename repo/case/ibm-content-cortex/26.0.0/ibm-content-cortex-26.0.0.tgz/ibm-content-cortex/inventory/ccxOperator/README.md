# Name

IBM&reg; Content Cortex

# Introduction

## Summary
IBM Content Cortex provides a paradigm for managing enterprise content and activating content automation at scale. With IBM Content Cortex, organizations can centralize content and infuse governance, security, and intelligence throughout the content lifecycle, activating content in a way that makes it usable for AI agents. Content Cortex can help transform content services repositories from passive systems into one trusted, collaborative, source of truth to fuel business operations and content automation.

## Features

Follow [link](https://www.ibm.com/docs/en/filenet-p8-platform/26.0.0?topic=containers-getting-started) for more details.

* IBM&reg; Content Cortex

  IBM Content Cortex provides enterprise content management to enable secure access, collaboration support, content synchronization and sharing, and mobile  support to engage users over all channels and devices. IBM® Content Cortex consists of Content Process Engine (CPE), Content Search Service (CSS), Content  Management Interoperability Services (CMIS), Content Navigator Task Manager  and Content Services GraphQL (CGQL).

* IBM&reg; Content Navigator
  
  IBM Content Navigator provides a console to enable teams to view their documents, folders, and searches in ways that help them to complete their tasks.

## Details

## Prerequisites

- Follow [link] (https://www.ibm.com/docs/en/filenet-p8-platform/5.5.x?topic=deployment-identifying-infrastructure-requirements)

  - IBM® Content Cortex
    * Follow [link](https://www.ibm.com/docs/en/filenet-p8-platform/26.0.0?topic=using-containers)
    * Follow [link](https://www.ibm.com/docs/en/filenet-p8-platform/26.0.0?topic=containers-installing)

  - IBM® Content Navigator
    * Follow [link](https://www.ibm.com/docs/en/filenet-p8-platform/26.0.0?topic=domain-configuring-content-navigator-in-container-environment) for details about this product.


# PodSecurityPolicy Requirements

# SecurityContextConstraints Requirements

### Red Hat OpenShift SecurityContextConstraints Requirements
This Operator uses default Openshift Restricted SCC

  - IBM® Content Cortex
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

  - IBM® Content Navigator
For Red Hat OpenShift, the default restricted SecurityContextConstraints (SCC) is sufficient.

### Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| CP4A      |  32 GB      |    8        |   500     |  3    |


# Download required container images.
- You can access the container images in the IBM Entitled registry with your IBMid.

        * Create a pull secret for the IBM Cloud Entitled Registry
          Follow [link] (https://www.ibm.com/docs/en/filenet-p8-platform/26.0.0?topic=operator-getting-access-container-images)

## Installing

Follow [link] (https://www.ibm.com/docs/en/filenet-p8-platform/26.0.0?topic=deployments-preparing-air-gap-environment)


### Configuration

Create a namespace and execute IBM Content Cortex Operator.

## Storage

IBM® FileNet Content Engine Operator supports a NFS storage system.  A NFS storage system needs to be created as a pre-req before deploying IBM® Cloud Pak for Automation chart. 
Dynamic Provisioning of PersistenceVolumes is not supported by provising Storage Class in Custom Resource file.

## Documentation

# Limitations

Follow [link] (https://www.ibm.com/docs/en/filenet-p8-platform/5.5.x?topic=containers-known-issues-limitations-content-services)
