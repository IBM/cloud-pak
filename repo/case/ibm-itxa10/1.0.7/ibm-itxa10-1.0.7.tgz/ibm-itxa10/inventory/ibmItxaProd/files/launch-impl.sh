#i (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName="ibm-itxa10"
inventory="ibmItxaProd"
caseCatalogName=
channelName=

# variables specific to catalog installation
catalogNamespace="openshift-marketplace"

# implement functions to install or uninstall products
# example

# overriding dynamic args thats passed with --args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --chart)
        export chart=$val
        ;;
    --releaseName)
        export releaseName=$val
        ;;
    --values)
        export values=$val 
        ;;
    esac
}

install() {
    helm install $releaseName -f $values $chart
}

uninstall() {
    helm uninstall $releaseName
}