watsonx Code Assistant Base
