# Name

IBM&reg; Events Operator

# Contents (adopters)
- [Introduction](#introduction)
- [Prerequisites](#prerequisites)
- [Installing](#installing)
- [Resources Required](#resources-required)
- [Configuration](#configuration)
- [Security Context Constraints (SCC) Requirements](#red-hat-openshift-securityContextConstraints-requirements)
- [To Uninstall](#to-uninstall)

---
---

## Introduction

The IBM Events Operator is a Kafka service based on the open-source [Apache Kafka](https://kafka.apache.org/) project. The IBM Events Operator takes advantage of the open-source [Strimzi](https://strimzi.io) Operator that is published under the Cloud Native Computing Foundation.

---

## Prerequisites

### Install the Common Services Operator

Follow the installation instructions in the [IBM Common Services documentation](http://ibm.biz/cpcsdocs) to install IBM Common Services.

---

## Installing

IBM internal users can access detailed information on how to install the Events Operator at the [Adoption Guide](https://github.ibm.com/IBMPrivateCloud/BedrockServices/blob/master/AdopterGuides/EventsAdoptionGuide.md#requesting-the-kafka-operator).

---

## Resources Required

The IBM product that requests the Events Operator Kafka instance will determine the resource requirements. This can be edited, however the minimum values supported are as follows:

| Software  | Memory  | CPU | Disk | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Kafka Broker (per replica) |  1Gi       |   1000m         |    Usage dependent       |  1     |
| Kafka Controller (per replica)  | 1Gi   |     1000m        |    Usage dependent      |     1  |
| Cluster Operator  |  1Gi      |     1000m        |    N/A     |     1  |
| Entity Operator - Topic Operator  |  1Gi      |     1000m        |    N/A       |     1  |
| Entity Operator - User Operator |  1Gi      |     1000m        |    N/A       |     1  |

---

## Configuration

For more information about configuring the IBM Events Operator, see the [IBM Common Services documentation](http://ibm.biz/cpcsdocs).

---

### Red Hat OpenShift SecurityContextConstraints Requirements

Events Operator runs with the 'restricted-v2' SCC by default.

If you want to apply a custom SCC, use the following sample which provides a basic SCC for the operator.

### Sample Custom SCC
```
metadata:
  name: <YOUR_SCC>
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: RunAsAny
kind: SecurityContextConstraints
priority: 2
readOnlyRootFilesystem: true
requiredDropCapabilities:
  - KILL
  - MKNOD
  - SETUID
  - SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
```

1. Add the name of the target namespace you created earlier for your installation:
```
groups:
    - system:serviceaccounts:<INSTALLATION_NAMESPACE>
```
2. Provide a unique name for your SCC in the metadata section:
```
metadata:
  name: <YOUR_SCC>
```

For more information about Security Context Constraints in OpenShift, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.5/authentication/managing-security-context-constraints.html).

## Details

See the [IBM Common Services documentation](http://ibm.biz/cpcsdocs) for more information about using the IBM Events Operator.

---

## To Uninstall

See the [IBM Common Services documentation](http://ibm.biz/cpcsdocs) for information about uninstalling the IBM Events Operator.


