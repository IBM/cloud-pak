#!/usr/bin/env bash
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName="ibm-aspera-hsts-operator"
inventory="v1_hstsOperatorSetup"
caseCatalogName="aspera-operators"
channelName="v1.5"

redisCase="ibm-cloud-databases-redis"
redisInventory="redisOperator"

# variables specific to catalog installation
catalogNamespace="openshift-marketplace"

# implement functions to install or uninstall products

# install
install() {
    echo "Implementation goes here"
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# installs the catalog source of any dependencies
install_dependent_catalogs() {

    local dep_redis_case="$(dependent_case_tgz "${redisCase}" "${inputcasedir}")"
    echo "-------------Installing dependent catalog source: "${dep_redis_case}"-------------"
    validate_file_exists "${dep_redis_case}"
    
    cloudctl case launch \
        --case "${dep_redis_case}" \
        --namespace "${namespace}" \
        --inventory ${redisInventory} \
        --action install-catalog \
        --args "--registry ${registry}" \
        -t 1

    if [[ $? -ne 0 ]]; then
        err_exit "installing dependent catalog for '${dep_redis_case}' failed"
    fi
}

# installs the catalog source
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"
    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

    # replace original registry with local registry
    local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

    # apply catalog source
    sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | $kubernetesCLI apply -f -
}

# Install operator via olm
install_operator() {

    echo "-------------Installing operator olm-------------"
    validate_install_args

    local opgrp_file="${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml
    validate_file_exists "${opgrp_file}"
    
    # apply operator group
    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI apply -n "${namespace}" -f -

    # Proceed with install
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml ]] && { err_exit "Missing required subscription yaml, exiting deployment."; }

    # check if catalog source is installed
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # subscription
    sed <"${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml "s|REPLACE_NAMESPACE|${namespace}|g" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | $kubernetesCLI apply -n "${namespace}" -f -
}

# apply custom resources
apply_custom_resources() {
    
    echo "-------------Applying custom resources-------------"
    # check if custom resource file exists
    local cr="${casePath}"/inventory/"${inventory}"/files/hsts.aspera.ibm.com_v1_ibmasperahsts_cr.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    
    # check if license file exists + post process
    validate_file_exists "${licenseFile}"
    licenseFileContents=$(cat "${licenseFile}" | tr -d '\n')
    
    # update cr + apply
    set -e
    sed <"${cr}" \
        -e "s|accept: false|accept: true|g" \
        -e "s|ASPERA_LICENSE|${licenseFileContents}|g" |\
    $kubernetesCLI apply -n "$namespace" -f -
    set +e
}

# uninstall
uninstall() {
    echo "Implementation goes here"
}

# uninstall the catalog source of any dependencies
uninstall_dependent_catalogs() {

    local dep_redis_case="${inputcasedir}/${redisCase}"
    echo "-------------Uninstalling dependent catalog source: ${dep_redis_case}-------------"
    validate_file_exists "${dep_redis_case}"

    cloudctl case launch \
        --case "${dep_redis_case}" \
        --namespace "${namespace}" \
        --inventory ${redisInventory} \
        --action uninstall-catalog \
        -t 1

    if [[ $? -ne 0 ]]; then
        err_exit "Uninstalling dependent catalog for '${dep_redis_case}' failed"
    fi
}

# uninstall the catalog source
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    echo "-------------Uninstalling catalog source-------------"
    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true
}

# uninstall operator installed via olm
uninstall_operator() {

    echo "-------------Uninstalling operator olm-------------"
    # find the redis subscription
    redisSub=$($kubernetesCLI get subscriptions -n "${namespace}" | grep redis-operator | awk '{print $1}')
    
    # find installed hsts csv
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    
    # find the installed redis csv
    [[ -n "${redisSub}" ]] && { redisCsvName=$($kubernetesCLI get subscription "${redisSub}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true); }

    # remove the hsts subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true
    
    # remove the redis subscription
    [[ -n "${redisSub}" ]] && { $kubernetesCLI delete subscription "${redisSub}" -n "${namespace}" --ignore-not-found=true; }

    # remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true; }
    
    # remove redis CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${redisCsvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${redisCsvName}" -n "${namespace}" --ignore-not-found=true; }
    
    # delete hsts crds
    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true
    done

    # delete redis crds
    $kubernetesCLI delete crd backups.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd buckets.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd formations.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd formationlocks.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd recipes.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd recipetemplates.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd redissentinels.redis.databases.cloud.ibm.com --ignore-not-found=true
    $kubernetesCLI delete crd releases.redis.databases.cloud.ibm.com --ignore-not-found=true

    # delete operator group
    local opgrp_file="${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml
    validate_file_exists "${opgrp_file}"
    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | $kubernetesCLI delete -n "${namespace}" --ignore-not-found=true -f -
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    kubectl delete ibmasperahsts quickstart -n "${namespace}" --ignore-not-found=true
}
