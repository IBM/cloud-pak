# hstsOperator

Contains the HSTS Operator custom resource and launch scripts to install/delete the custom resources
