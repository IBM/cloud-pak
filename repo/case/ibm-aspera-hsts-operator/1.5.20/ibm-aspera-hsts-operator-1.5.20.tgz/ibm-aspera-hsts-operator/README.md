# IBM Aspera HSTS

## Introduction

This CASE bundle provides an operator to install IBM Aspera HSTS.

---

## Details

This CASE bundle contains three inventory items:

- `v1_hstsOperatorSetup` - The installation of the IBM Aspera HSTS Operator. Required for installing the `v1_hstsOperator` inventory item.
- `v1_hstsOperator` - Several example resources provided, each of which will create an instance of IBM Aspera HSTS if the operator has been installed.

---

## Prerequisites

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/install_aspera.html) documentation.

IBM Aspera HSTS depends on IBM Cloud Databases Redis Operator for various services. In an Air-gapped installation ensure all the dependent Redis images are present in the target (internal) registry and the Catalog Source is available before installing this CASE bundle.

---

## Installing

### Install IBM Aspera HSTS operator

See the following README for details of installing the inventory items found in this CASE bundle:

- [IBM Aspera HSTS Operator Setup README](inventory/v1_hstsOperatorSetup/README.md)

### Create instance of IBM Aspera HSTS

See the following readme files for details of installing the inventory items found in this CASE bundle:

- [IBM Aspera HSTS Instance README](inventory/v1_hstsOperator/README.md)

## Configuration

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/install_aspera.html) documentation.

## Limitations

Not applicable

## Resources Required

Refer to the [Knowledge Center](https://www.ibm.com/support/knowledgecenter/SSGT7J_20.2/install/install_aspera.html) documentation.

## SecurityContextConstraints Requirements

The IBM Aspera HSTS Operator currently requires the `restricted` scc in order to run.

```yaml
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegeEscalation: true
allowPrivilegedContainer: false
allowedCapabilities: null
apiVersion: security.openshift.io/v1
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
groups: []
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
users: []
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```

## Installing on an air-gapped OpenShift cluster

### 1. Preparing host

- Ensure you have the following set up:

  - The OpenShift Container Platform CLI [installed](https://docs.openshift.com/container-platform/4.3/cli_reference/openshift_cli/getting-started-cli.html)
  - The IBM Cloud Pak CLI (cloudctl) [installed](https://github.com/IBM/cloud-pak-cli)

If the cluster has a Bastion host which has access to public internet then the following steps can be performed from the Bastion host.

Ensure that the Bastion host can access:

- The public internet to download the CASE bundle and images.
- The target (internal) image registry where all the images will be mirrored to.
- The OpenShift cluster to install the operator on.

In the absence of a Bastion host, prepare a portable device which has access to the public internet to download the CASE bundle and images, and also target registry where the images will be mirrored.

### 2. Download CASE

Create a local directory to save the CASE bundle.
```
$ mkdir /tmp/cases
```

Run the following command to download, validate and extract the CASE bundle.
```
$ cloudctl case save --case case/ibm-aspera-hsts-operator --outputdir /tmp/cases
```
The following output is displayed:
```
Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```

Verify that the CASE and images csv have been generated.
```
$ ls /tmp/cases/
total 328
drwxr-xr-x  2 user  staff      64  5 Jun 10:57 charts
-rw-r--r--  1 user  staff      32  5 Jun 10:57 ibm-aspera-hsts-operator-1.0.0-charts.csv
-rw-r--r--  1 user  staff    4842  5 Jun 13:34 ibm-aspera-hsts-operator-1.0.0-images.csv
-rw-r--r--  1 user  staff  155586  5 Jun 10:57 ibm-aspera-hsts-operator-1.0.0.tgz
```

### 3. Configure Registry Auth

Create the auth secret for the source registry where all the images are available publicly.
For IBM Aspera HSTS, all images are either present in the Entitled Registry (`cp.icr.io`)
or in DockerHub.

```
$ cloudctl case launch \
  --case <case-path>/ibm-aspera-hsts-operator \
  --namespace <target-namespace> \
  --inventory v1_hstsOperatorSetup \
  --action configure-creds-airgap \
  --args "--registry cp.icr.io --user iamapikey --pass xyz"
```

Create the auth secret for the target (internal) registry.

```
$ cloudctl case launch \
  --case <case-path>/ibm-aspera-hsts-operator \
  --namespace <target-namespace> \
  --inventory v1_hstsOperatorSetup \
  --action configure-creds-airgap \
  --args "--registry $TARGET_REGISTRY --user abc --pass xyz"
```

Both of these credentials will be saved to `<HOME-DIRECTORY>/.airgap/<registry-name>.json`

### 4. Mirror Images

The following step mirrors the images from source registry to target (internal) registry based on the CASE images.

```
$ cloudctl case launch \
  --case <case-path>/ibm-aspera-hsts-operator \
  --namespace <target-namespace> \
  --inventory v1_hstsOperatorSetup \
  --action mirror-images \
  --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

After this step, ensure that all the images have been mirrored to the target registry by checking the registry.

### 5. Configure Cluster for Airgap

The following step creates a global image pull secret for the target registry if the registry auth was configured in Step 3. This will also create the ImageSourceContentPolicy for the cluster.

WARNING:

Cluster resources must adjust to the new pull secret, which can temporarily limits the access to the cluster. Authorization credentials are stored in `<HOME-DIRECTORY>/.airgap/secrets` and `/tmp/airgap*` to ensure this information is not lost.
Applying the ImageSourceContentPolicy causes cluster nodes to recycle, which will result in limited access to the cluster until all the nodes are ready.

```
$ cloudctl case launch \
  --case <case-path>/ibm-aspera-hsts-operator \
  --namespace <target-namespace> \
  --inventory v1_hstsOperatorSetup \
  --action configure-cluster-airgap  \
  --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

### 6. Install Catalog

Install the Catalog using the following command:
```
$ cloudctl case launch \
  --case <case-path>/ibm-aspera-hsts-operator \
  --namespace <target-namespace> \
  --inventory v1_hstsOperatorSetup \
  --action install-catalog \
  --args "--registry $TARGET_REGISTRY"
```

### 7. Install Operator

Before installing the operator, ensure you create a secret called `ibm-entitlement-key` in the namespace where you want to create an instance of IBM Aspera HSTS.

The following step will install the operator:
```
$ cloudctl case launch \
  --case <case-path>/ibm-aspera-hsts-operator \
  --namespace <target-namespace> \
  --inventory v1_hstsOperatorSetup \
  --action install-operator
```

Alternatively, refer to [Installing](inventory/v1_hstsOperatorSetup/README.md) section.
