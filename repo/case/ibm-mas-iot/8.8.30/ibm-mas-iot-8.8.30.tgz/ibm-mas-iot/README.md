# Name

IBM&reg; Maximo&reg; Application Suite IoT

## Introduction
## Summary
IBM&reg; Maximo&reg; Application Suite IoT is a program that that makes it simple to derive value from Internet of Things (IoT) assets.

## Features
Use IBM&reg; Maximo&reg; Application Suite IoT to connect and ingest data from your Internet of Things (IoT) assets.

## Details

## Prerequisites

See prerequisites details here https://www.ibm.com/support/knowledgecenter/SSRHPA_8.6.0

Summary of Prerequisites required for IBM&reg; Maximo&reg; Application Suite IoT:
- Compute architecture required: 64-bit Intel/AMD x86
- Supported cloud type: rhocp4 RedHat OpenShift Container Platform 4.6
- cert-manager 1.1.0 (or higher) installed in the cluster. See cert-manger [documentation](https://cert-manager.io/docs/installation/openshift/#installing-with-regular-manifests) for install details
- MongoDB, either internal to the cluster or external
- DB2 Warehouse, either internal to the cluster or external
- Behaviour Analytics Service to assist with collecting and processing license and usage information. For quickstart information on how to install the Behavior Analytics Services Operator in non-air gapped environments, see the [Behavior Analytics Services quick start guide for Maximo Application Suite](https://developer.ibm.com/openlabsdev/ui/behavior-analytics-services).
- IBM Suite License Service (SLS) to be available to provide the licensing system that Maximo Application Suite uses.
- Service Bindings Operator installed from the OpenShift Marketplace
- An IBM Entitled Registry key

## Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
|           |             |             |           |       |
| **Total** |   16        |  15         |  10       |  2    |

## Installing

- Navigate to OperatorHub in your OpenShift Dashboard and install the ibm-mas operator following the instructions presented there.
- Deploy an instance of the `Suite` via the installed operator. Provide details of the cert-manager namespace and a Certificate Issuer to use (if configured). You must also accept the license
- Once the suite is installed you can then create the following via the OpenShift Installed Operator page to complete the Maximo Application Suite initial install:
  - Configure BAS Integration: Provide the host details and contact details of the Behaviour Analytics Service prereq. Including any TLS certificates required to contact this service.
  - Configure MongoDb: Provide the host details and crendentials of the MongoDB prereq. Including any TLS certificates required to contact this service.
  - Configure SLS: Configure details of the IBM Suite License Service prereq. Including any TLS certificates required to contact this service.
  - Create Workspace: Create the workspace to be used. Details on Addons don't need to be provided at this point.
- Once all resources have reported "Ready" status you can navigate to Admin Dashboard: `https://admin.{{suite_instanceId}}.{{suite_domain}}` and login with the credentials from the secret `{{ suite_instanceId }}-credentials-superuser`
- Once logged in to th Admin Dashboard, IBM&reg; Maximo&reg; Application Suite IoT can be installed from the catalog.

## Configuration

See the details provided in [IBM docs](https://www.ibm.com/support/knowledgecenter/SSRHPA_8.6.0) for more information about how to configure Maximo Application Suite IoT.

### Storage

IoT requires a PVC to store the MQTT broker state. Set the storage class and size of the PVC in the IoT CR.

#### Requirements

View a list of available storage classes in your cluster by executing the following command: `oc get storageclasses`. Choose the appropriate storage class and size for your workload. The storage class can be used to dynamically provision a persistent volume with access mode RWO (ReadWriteOnce).

#### Storage on IBM Cloud

The following IBM Cloud storage classes have been tested with:

- ibmc-block-gold

#### Supported and Tested Storage 
We have tested with the storage provider OpenShift Container Storage and storage class ibmc-block-gold from IBM Cloud. No specific filesystem permissions are required.

### Scaling
In the IoT CR settings.deployment.size can be set to dev, small, or medium to configure the level of scaling utilized by the IoT application.  As of version 8.4.0 there is no support for auto-scaling.

## Limitations

- The operator only supports single namespace deployment
- The operator will only watch for resources in its own namespace
- Multiple instances of the operator can be deployed in a single cluster
- Multiple installations of IoT can **not** be deployed in the same namespace
- Each IoT resource must be deployed into a namespace that matches the expected naming convention of `mas-{instanceId}-iot`

## SecurityContextConstraints Requirements

The operator uses the OpenShift default `restricted` SCC (Security Context Constraints).

## PodSecurityPolicy Requirements
The operator runs in OpenShift so no PodSecurityPolicy configuration is required.

## Reason Codes

#### Actions Operator
- **Ready** : Actions now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### Auth Operator
- **Ready** : Auth now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### Datapower Operator
- **Ready** : Datapower now ready

#### Devops Operator
- **Ready** : Devops now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore  is not ready

#### DM Operator
- **Ready** : DM now ready
- ** Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready
- **ServiceVerificationFailed** : Dm Pods not in running state

#### DSC Operator
- **Ready** : DSC now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready
- **MissingService** : Required service is not present

#### Guardian Operator
- **Ready** : Guardian now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### MBGX Operator
- **Ready** : MBGX now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready
- **ServiceVerificationFailed** : Mbgx Pods not in running state

#### MFGX Operator
- **Ready** : Auth now ready

#### MFGX Operator
- **Ready** : MFGX now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### Monitor Operator
- **Ready** : Monitor now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### Orgmgmt Operator
- **Ready** : Orgmgmt now ready

#### Provision Operator
- **Ready** : Provision now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### Registry Operator
- **Ready** : Registry now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### WebUI Operator
- **Ready** : WebUI now ready
- **Timed out after 3 minute waiting for truststore to be ready** : Truststore is not ready

#### IoTWorkspace Operator
- **Ready** : IoTWorkspace now ready
- **InvalidConfiguration** : Labels mas.ibm.com/instanceId and/or mas.ibm.com/workspaceId have unexpected values
- **IoTWorkspaceSynchFailure** : Failure synching iot org
