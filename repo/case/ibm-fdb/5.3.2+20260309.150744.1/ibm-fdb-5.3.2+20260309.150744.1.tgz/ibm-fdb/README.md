# Name

IBM&reg; Foundationdb

# Introduction

TBD

## Details

TBD

## Features

TBD

# Details

## Prerequisites

- IBM Cloud Pak for Data must be deployed before you can install IBM Foundationdb.
- Kubernetes 1.19.0 or later
- Openshift 4.6.0 or later
- Shared Storage (Portworx, OCS or NFS) - a minimum of three worker nodes 

### Resources Required

Minimum scheduling capacity:

| Software      | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| ------------- | ----------- | ----------- | --------- | ----- |
| FoundationDB  |     TBD     |     TBD     |    TBD    |   3   |
| **Total**     |             |             |           |       |

### PodSecurityPolicy Requirements

The **restricted** SCC is required. It is built into OpenShift.
Custom PodSecurityPolicy definition:
```
Not Applicable
```

### SecurityContextConstraints Requirements

The **restricted** SCC is required. It is built into OpenShift.
Custom SecurityContextConstraints definition:
```
Not Applicable
```

# Installation guidance

TBD

# Installing IBM Foundationdb

This operator can be installed in an on-line or air-gapped cluster through either of following install paths :
1. Operator Life Cycle Manager (default)
2. Kubernetes CLI

## Installing online using OpenShift Operator Catalog

1. (Optional) Create an image pull secret and service account (using template under op-cli directory) if you are installing the operator from an authenticated registry.

```bash
kubectl create secret docker-registry 'cp.icr.io' --docker-server='cp.icr.io' --docker-username='cp' --docker-password='<token>' --docker-email='<user>' --namespace='<target namespace>'
```

```bash
< case/ibm-sample-panamax/inventory/v2_panamaxOperatorSetup/files/op-cli/service_account.yaml  sed 's|REPLACE_SECRET|cp.icr.io|g' | oc apply --namespace'<target namespace>' -f -
```

2. Install the operator catalog for IBM Match 360 with Watson and its dependencies.

```bash
oc ibm-pak launch --case ${DIR}/fdb-cp4d-case-${FDB_CASE_VERSION}.tgz --action install-catalog --inventory fdbOperator --namespace ${OPERATOR_NAMESPACE}
````

3. Install the operator by using OLM.

```bash
oc ibm-pak launch --case ${DIR}/fdb-cp4d-case-${FDB_CASE_VERSION}.tgz --action installOperator --inventory fdbOperator --namespace ${OPERATOR_NAMESPACE}
```

## Installing online using the command line

1. (Optional) Create an image pull secret if you are installing the operator from an authenticated registry.

```bash
oc ibm-pak create secret docker-registry 'cp.icr.io' --docker-server='cp.icr.io' --docker-username='cp' --docker-password='<token>' --docker-email='<user>' --namespace='<target namespace>'
```

2. Patch the NamespaceScoped common-service resource to include the namespace that you will be provisioning IBM Match 360 with Watson into.

```bash
oc patch nss common-service -n ${OPERATOR_NAMESPACE} --type='json' -p='[{"op": "add", "path":"/spec/namespaceMembers/0","value": "'${INSTANCE_NAMESPACE}'" }]'
```

3. Install the operator catalog for IBM Match 360 with Watson and its dependencies.

```bash
oc ibm-pak  launch --case ${DIR}/fdb-cp4d-case-${FDB_CASE_VERSION}.tgz --action install-catalog --inventory fdbOperator --namespace ${OPERATOR_NAMESPACE}
````

4. Install the operator using the command line. Specify the image pull secret as an argument if you are installing from an authenticated registry.

```bash
oc ibm-pak  launch --case ${DIR}/fdb-cp4d-case-${FDB_CASE_VERSION}.tgz --action installOperator --inventory fdbOperator --namespace ${OPERATOR_NAMESPACE} --args "--secret cp.icr.io "
```

Alternatively, the installation script can create an image pull secret.  when authenticated registry user and token are also provided as arguments

```bash
oc ibm-pak oc ibm-pak  launch --case ${DIR}/fdb-cp4d-case-${FDB_CASE_VERSION}.tgz --action installOperator --inventory fdbOperator --namespace ${OPERATOR_NAMESPACE} --args "--registry cp.icr.io --secret cp.icr.io --user cp --pass <token>"
```

5. Create an IBM Foundationdb instance

```bash
oc ibm-pak  launch                   \
    --case case/ibm-sample-panamax     \
    --namespace <target namespace>     \
    --inventory v2_panamaxOperator     \
    --action apply-custom-resources    \
    --args "--systemStatus hello"
```

### Installing in an air-gapped OpenShift Cluster with bastion

#### 1. Prepare the bastion host

* Log on to the bastion host.

* Verify that the bastion host has access to:
  * Public internet (to download CASE and images).
  * A target image registry ( where the images will be mirrored).
  * A target Red Hat OpenShift cluster to install the operator.

* Download and install the required command line tools:
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with Openshift Cluster
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE

All of the following steps should be run from the bastion host computer.

#### 2. Download CASE

1. Create a directory to save the CASE to a local directory:

```bash
$ mkdir /tmp/cases
```

2. Run the following command to download CASE:

```bash
$ oc ibm-pak save --case case/ibm-fdb --outputdir /tmp/cases
Downloading and extracting the CASE ...
- Success
Retrieving CASE version ...
- Success
Validating the CASE ...
- Success
Creating inventory ...
- Success
Finding inventory items
- Success
Resolving inventory items ...
Parsing inventory items
- Success
```

3. Verify that the CASE and images csv have been downloaded:

```bash
$ ls /tmp/cases/
drwxr-xr-x 2 root root      6 May 25 13:04 charts
-rw-r--r-- 1 root root     32 May 25 13:04 ibm-fdb-4.0.0-charts.csv
-rw-r--r-- 1 root root   3553 May 25 13:04 ibm-fdb-4.0.0-images.csv
-rw-r--r-- 1 root root 193817 May 25 13:04 ibm-fdb-4.0.0.1.359.tgz
```

#### 3. Configure registry authentication

1. Create an authentication secret for the the source image registry.

2. Create a registry secret for the source image registry. If the registry is public and doesn't require credentials, then skip this step.

```bash
$ oc ibm-pak  launch \
    --case case/ibm-fdb \
    --inventory fdbOperator \
    --action configure-creds-airgap \
    --args "--registry cp.icr.io --user iamapikey --pass xyz"
```

3. Create an auth secret for the target image registry.

```bash
$ oc ibm-pak  launch  \
    --case case/ibm-fdb \
    --inventory fdbOperator \
    --action configure-creds-airgap \
    --args "--registry $TARGET_REGISTRY --user abc --pass xyz"
```

The credentials are now saved to `~/.airgap/secrets/<registry-name>.json`

#### 4. Mirror images

Run the following commands to copy the images from the saved CASE (images.csv) to the target registry in the air-gapped environment

```bash
$ oc ibm-pak  launch \
    --case case/ibm-fdb \
    --inventory fdbOperator \
    --action mirror-images \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

#### 5. Configure the air-gapped cluster

Configure the air-gapped cluster to:
* Create a global image pull secret for the target registry (skipped if target registry is unauthenticated).
* Create a imagesourcecontentpolicy.

WARNING:
* Cluster resources must adjust to the new pull secret, which can temporarily limit the usability of the cluster. Authorization credentials are stored in $HOME/.airgap/secrets and /tmp/airgap* to support this action
* Applying imagesourcecontentpolicy causes cluster nodes to recycle.

Run the following commands to configure the cluster:

```bash
$ oc ibm-pak  launch \
    --case case/ibm-fdb \
    --namespace <target namespace> \
    --inventory fdbOperator \
    --action configure-cluster-airgap \
    --args "--registry $TARGET_REGISTRY --inputDir /tmp/cases"
```

### 6. Install the catalog source

Run the following commands to install the operator catalogsource in the openshift-marketplace namespace, and also to install catalogs from dependent subcases (none in this case):

```bash
oc ibm-pak  launch \
  --case case/ibm-fdb \
  --namespace <target namespace> \
  --inventory fdbOperator \
  --action install-catalog \
  --args "--registry $TARGET_REGISTRY --inputDir $OFFLINEDIR --recursive"
```

### 7. Install the operator

TBD

### Installing in an air-gapped OpenShift cluster without bastion

#### 1. Prepare a portable device

Prepare a portable device, such as laptop, that be used to download the CASE and images and that can be carried into the air-gapped environment.

* Verify that the portable device has access to:
  * Public internet (to download CASE and images).
  * A target image registry ( where the images will be mirrored).
  * A target openshift cluster to install the operator.

* Download and install the required command line tools
  * [oc](https://docs.openshift.com/container-platform/3.6/cli_reference/get_started_cli.html#installing-the-cli) - To interact with the Red Hat OpenShift cluster.
  * [cloud-pak-cli](https://github.com/IBM/cloud-pak-cli) - To download and install CASE.

All of the following steps should be run from the portable device.

#### 2. Download CASE

See instructions from the previous [Downloading CASE](#2-download-case) section.

#### 3. Configure registry authentication

See the instructions from the previous [Configure registry authentication](#3-configure-registry-auth) section.

#### 4. Mirror images

See the instructions from the previous [Mirror images](#4-mirror-images) section.

#### 5. Configure the air-gapped cluster

See the instructions from the previous [Configure the air-gapped cluster](#5-configure-cluster-for-airgap) section.

### 6. Install the catalog source

See the instructions from the previous [Install the catalog source](#6-install-catalog-source) section.

### 7. Install the operator

See the instructions from the [Installing IBM Match 360 with Watson](#installing-match-360-with-watson) section.

## Configuration

For information about configuring and administering services in IBM Cloud Pak for Data, see [IBM Documentation](https://www.ibm.com/docs/SSQNUZ_4.0/cpd/admin/administer.html)

## Storage

For information about storage in IBM Cloud Pak for Data, see [IBM Documentation](https://www.ibm.com/docs/SSQNUZ_4.0/cpd/plan/storage_considerations.html).

## Limitations

Only one service instance of IBM Foundationdb is supported per namespace. 

## Documentation

For more information about installing, configuring, and using IBM Foundationdb, see [IBM Documentation](https://www.ibm.com/docs/SSQNUZ_4.0/svc-welcome/fdb.html).
