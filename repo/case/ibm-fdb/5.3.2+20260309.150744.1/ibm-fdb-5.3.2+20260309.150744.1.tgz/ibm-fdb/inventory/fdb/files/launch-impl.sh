# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to the fdb operator

inventory="fdbOperator" # default inventory item
subscriptionName="ibm-fdb-operator-subscription"
channelName="v0.1"
catalogNamespace="openshift-marketplace"
catalogSource="ibm-fdb-operator-catalog"

# Override the check_kube_namespace function in launch script
# to support catalog actions without passing namespace
check_kube_namespace() {
    if [[ "$action" == *installCatalog* || "$action" == *uninstallCatalog* ]]; then
        echo "Namespace for catalog is openshift-marketplace"
    else
        [[ -z "${namespace}" ]] && { err_exit "The namespace parameter was not specified."; }
        if ! $kubernetesCLI get namespace "${namespace}" >/dev/null; then
            err_exit "Unable to retrieve namespace ${namespace}"
        fi
    fi
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    # ibm-cloud-databases-redis)
    #     echo "redisOperator"
    #     return 0
    #     ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {
  local dep_case=""

  for dep in $case_dependencies; do
      local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

      echo "-------------Installing dependent catalog source: ${dep_case}-------------"

      validate_file_exists "${dep_case}"
      local inventory=""
      inventory=$(dependent_inventory_item "${dep}")

      oc ibm-pak launch \
          --case "${dep_case}" \
          --namespace "${namespace}" \
          --inventory "${inventory}" \
          --action install-catalog \
          --args "--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun } --registry ${registry}"
          
      #cloudctl case launch \
      #    --case "${dep_case}" \
      #    --namespace "${namespace}" \
      #    --inventory "${inventory}" \
      #    --action install-catalog \
      #    --args "--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun } --registry ${registry}" \
      #    --tolerance "${tolerance_val}"

      if [[ $? -ne 0 ]]; then
          err_exit "installing dependent catalog for '${dep_case}' failed"
      fi
  done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "--inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun } --registry ${registry}"
        #    --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|ibm-common-services|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

upgrade_existing_cluster(){
	# Check if there is an existing operator	
	# If the existing operator is 4.0.x then Add license to CR and clean operator, catalog, and CRD
	export OldpackageName1=fdb-kubernetes-operator
	export OldpackageName2=ibm-opencontent-foundationdb
	export OldpackageName2fs=ibm-fdb-controller-catalog

	OldcsvName1=$(kubectl get csv -n "${FDB_OPERATOR_NAMESPACE}" | grep ${OldpackageName1} | cut -d' ' -f1)
	OldcsvName2=$(kubectl get csv -n "${FDB_OPERATOR_NAMESPACE}" | grep ${OldpackageName2} | cut -d' ' -f1)

	oldcsvversion1=${OldcsvName1#${OldpackageName1}.}
	oldcsvversion2=${OldcsvName2#${OldpackageName2}.}
    
	if [ "${oldcsvversion1}" != "${oldcsvversion2}" ]; then
		echo ${OldcsvName1} 
		echo ${OldcsvName2}

		#Will add modify crd file part later       
		oc replace -f ${casePath}/inventory/${inventory}/files/foundationdb.opencontent.ibm.com_fdbclusters.yaml
		oc replace -f ${casePath}/inventory/${inventory}/files/foundationdb.opencontent.ibm.com_fdbcontrollerconfigs.yaml
		           
		# Check if existing cluster is installed and add license to it if it does
		#$kubernetesCLI get FdbCluster -n "${namespace}"
		#rc=$?
		#if [ $rc == 0 ]; then
		#	local CLUSTER=$(oc get FdbCluster --no-headers | awk '{ print $1 }')
		#	#sed <"${casePath}"/inventory/fdb/files/foundationdb_v1_fdbcluster.yaml "s/  name: .*/  name: $CLUSTER/g"
		#	$kubernetesCLI get FdbCluster $CLUSTER -n "${namespace}" -o yaml | sed  ':a;N;$!ba;s~\nspec:~\nspec:\n  license:\n    accept: true~' | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
		#fi

		OldsubscriptionName1=$(kubectl get subscription -n "${FDB_OPERATOR_NAMESPACE}" | grep ${OldpackageName1} | cut -d' ' -f1)
		OldsubscriptionName2=$(kubectl get subscription -n "${FDB_OPERATOR_NAMESPACE}" | grep ${OldpackageName2fs} | cut -d' ' -f1)

		printf "[INFO]: Old operator csv names are \n --> ${OldcsvName1} \n --> ${OldcsvName2}\n"
		printf "[INFO]: Old operator subscription names are \n --> ${OldsubscriptionName1} \n --> ${OldsubscriptionName2}\n"
		printf "[INFO]: Old operators on 4.0 level will be uninstalled before upgrade \n"
		oc delete clusterserviceversion ${OldcsvName1} ${OldcsvName2}
		oc delete subscription ${OldsubscriptionName1} ${OldsubscriptionName2}

		OldCatalog1=$(oc get catalogsource -n openshift-marketplace| grep fdb-catalog  | cut -d' ' -f1)
		OldCatalog2=$(oc get catalogsource -n openshift-marketplace| grep ibm-fdb-controller-catalog  | cut -d' ' -f1)
		OldCatalog3d=$(oc get catalogsource -n openshift-marketplace| grep ibm-fdb-operator-catalog  | awk '{print $3}')
		OldCatalog3=$(oc get catalogsource -n openshift-marketplace| grep ibm-fdb-operator-catalog  | cut -d' ' -f1)
		
		if [ -n "${OldCatalog1}" ] || [ -n "${OldCatalog2}" ] ; then
			printf "[INFO]: Old fdb catalogs are \n --> ${OldCatalog1} , ${OldCatalog2} \n"
			$kubernetesCLI delete catalogsource -n openshift-marketplace ${OldCatalog1} ${OldCatalog2} 
			if [ "${OldCatalog3d}" != "FoundationDB" ] && [ -n "${OldCatalog3d}" ] ; then 
				printf "[INFO]: Old fdb catalogs also has \n -->  ${OldCatalog3}\n"
				$kubernetesCLI delete catalogsource -n openshift-marketplace ${OldCatalog3}
			else
				printf "[INFO]: No more Old fdb catalog exist\n"        
			fi
		else
			echo "INFO: Old catalogs not exist, no need to clean"
		fi
	else
			
		printf "[INFO]: Your current fdb operator version is case bundle version ${oldcsvversion1} \n"
	fi
	 
}


# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"
    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    if [[ -z $registry ]]; then
        tee >($kubernetesCLI apply ${dryRun} -f -) <"${catsrc_file}" | cat
    else
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
         sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

	# If there is already an existing old operator, update it.
	upgrade_existing_cluster
	
	
    # check if catalog source is installed
    echo "checking if catalog source exists ..."
    if ! $kubernetesCLI get catsrc "${catalogSource}" -n "${catalogNamespace}"; then
        err_exit "expected catalog source '${catalogSource}' expected to be installed namespace '${catalogNamespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed <"${subscription_file}" "s|REPLACE_NAMESPACE|${namespace}|g; s|REPLACE_CHANNEL_NAME|$channelName|g; s|REPLACE_CATALOG_NAMESPACE|${catalogNamespace}|g; s|REPLACE_CATALOG_SOURCE|${catalogSource}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# Install utilizing default CLI method
install_operator_native() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi
    
    # Proceed with install
    echo "-------------Installing native-------------"

    # Verify expected yaml files for install exist
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    
    local base_crd_file1="${op_cli_files}/foundationdbbackups.apps.foundationdb.org-custom-resource-definition.yaml"
    local base_crd_file2="${op_cli_files}/foundationdbclusters.apps.foundationdb.org-custom-resource-definition.yaml"
    local base_crd_file3="${op_cli_files}/foundationdbrestores.apps.foundationdb.org-custom-resource-definition.yaml"
    local base_sa_file="${op_cli_files}/apple-fdb-controller-manager-service-account.yaml"
    local base_role_file="${op_cli_files}/apple-fdb-manager-role-role.yaml"
    local base_role_binding_file="${op_cli_files}/apple-fdb-manager-rolebinding-role-binding.yaml"
    local base_deployment_file="${op_cli_files}/apple-fdb-controller-manager-deployment.yaml"

    validate_file_exists "${base_crd_file1}"
    validate_file_exists "${base_crd_file2}"
    validate_file_exists "${base_crd_file3}"
    validate_file_exists "${base_sa_file}"
    validate_file_exists "${base_role_file}"
    validate_file_exists "${base_role_binding_file}"
    validate_file_exists "${base_deployment_file}"

    # Apply yaml files manipulate variable input as required
    # create crd
    $kubernetesCLI apply ${dryRun} -f "${base_crd_file1}"
    $kubernetesCLI apply ${dryRun} -f "${base_crd_file2}"
    $kubernetesCLI apply ${dryRun} -f "${base_crd_file3}"
    # create service account, after fixing namespace
    sed <"${base_sa_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create role, after fixing namespace
    sed <"${base_role_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create role binding, after fixing namespace
    sed <"${base_role_binding_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create operator deployment, after fixing namespace
    sed <"${base_deployment_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    # Verify expected yaml files for install exist
    local crd_file="${op_cli_files}/fdbcontrollerconfigs.foundationdb.opencontent.ibm.com-custom-resource-definition.yaml"
    local ibm_fdb_cluster_crd_file="${op_cli_files}/fdbclusters.foundationdb.opencontent.ibm.com-custom-resource-definition.yaml"
    local sa_file="${op_cli_files}/ibm-fdb-controller-manager-service-account.yaml"
    local role_file="${op_cli_files}/ibm-fdb-manager-role-role.yaml"
    local role_binding_file="${op_cli_files}/ibm-fdb-manager-rolebinding-role-binding.yaml"
    local deployment_file="${op_cli_files}/ibm-fdb-controller-manager-deployment.yaml"
    local configmap_file="${op_cli_files}/ibm-fdb-controller-config-config-map.yaml"

    validate_file_exists "${crd_file}"
    validate_file_exists "${ibm_fdb_cluster_crd_file}"
    validate_file_exists "${sa_file}"
    validate_file_exists "${role_file}"
    validate_file_exists "${role_binding_file}"
    validate_file_exists "${deployment_file}"

    # Apply yaml files manipulate variable input as required
    # create crd
    $kubernetesCLI apply ${dryRun} -f "${crd_file}"
    $kubernetesCLI apply ${dryRun} -f "${ibm_fdb_cluster_crd_file}"
    # create service account, after fixing namespace
    sed <"${sa_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create role, after fixing namespace
    sed <"${role_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create role binding, after fixing namespace
    sed <"${role_binding_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
    # create operator deployment, after fixing namespace
    sed <"${deployment_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
	# create operator config-map
    sed <"${configmap_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"

    local cr="${casePath}"/inventory/"${inventory}"/files/foundationdb_v1_fdbcluster.yaml

    validate_file_exists "$cr"

    echo "-------------Installing sample cluster-------------"
    if [ -z "$ENABLE_TLS" ]; then
            echo "INFO: ENABLE_TLS is not set in the environment. TLS by default is enabled."
            #sed <"${cr}" -e "s/accept: false/accept: true/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
			$kubernetesCLI apply ${dryRun} -n "${namespace}" -f "${cr}"
    else
            sed <"${cr}" -e "s/enableTls: true/enableTls:  $ENABLE_TLS/g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    fi
}

# ----- UNINSTALL ACTIONS -----
delete_custom_resources() {
    echo "-------------Applying custom resources-------------"

    local cr="${casePath}"/inventory/"${inventory}"/files/foundationdb_v1_fdbcluster.yaml

    echo "-------------Uninstalling sample cluster-------------"
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" --ignore-not-found=true ${dryRun}
    #sed <"${cr}" -e "s/accept: false/accept: true/g" | $kubernetesCLI delete --ignore-not-found=true ${dryRun} -n "${namespace}" -f -
}

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }"
        #    --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_dependencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        oc ibm-pak launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }"
        #    --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${subscriptionName}" -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${subscriptionName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove FDB subscriptions
    $kubernetesCLI delete subscription -l "operators.coreos.com/fdb-kubernetes-operator.${namespace}=" -n "${namespace}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete subscription -l "operators.coreos.com/ibm-opencontent-foundationdb.${namespace}=" -n "${namespace}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete clusterserviceversion -l "operators.coreos.com/fdb-kubernetes-operator.${namespace}=" -n "${namespace}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete clusterserviceversion -l "operators.coreos.com/ibm-opencontent-foundationdb.${namespace}=" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # deleting InstallPlan for ibm-fdb-operator
    FDB_IP_EXISTS=$(oc get installplan -n ${namespace} | grep "ibm-fdb")
    rc=$?
    if [ $rc == 0 ]; then
    oc delete installplan $(oc get installplan -n ${namespace} | grep ibm-fdb |awk '{ print $1 }') -n ${namespace}
    else
    echo "FDB Installplan Not Found...."
    fi

    # delete crds
    if [[ $deleteCRDs -eq 1 ]]; then
        IBM_FDB_CLUSTER_CRD_EXISTS=$(oc get customresourcedefinition.apiextensions.k8s.io/fdbclusters.foundationdb.opencontent.ibm.com)
        rc=$?
        if [ $rc == 0 ]; then
          oc delete customresourcedefinition.apiextensions.k8s.io/fdbclusters.foundationdb.opencontent.ibm.com
        else
          echo "CRD fdbclusters.foundationdb.opencontent.ibm.com Not Found...."
        fi
        IBM_FDB_CONTROLLER_CONFIG_CRD_EXISTS=$(oc get customresourcedefinition.apiextensions.k8s.io/fdbcontrollerconfigs.foundationdb.opencontent.ibm.com)
        rc=$?
        if [ $rc == 0 ]; then
          oc delete customresourcedefinition.apiextensions.k8s.io/fdbcontrollerconfigs.foundationdb.opencontent.ibm.com
        else
          echo "CRD fdbcontrollerconfigs.foundationdb.opencontent.ibm.com Not Found...."
        fi
        # Don't delete FoundationDB CRDs to avoid affecting other services using FoundationDB
    fi
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
    validate_install_args "uninstall"

    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_operators
    fi
    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
    local ibm_fdb_cluster_crd_file="${op_cli_files}/fdbclusters.foundationdb.opencontent.ibm.com-custom-resource-definition.yaml"
    local ibm_fdb_controller_config_crd_file="${op_cli_files}/fdbcontrollerconfigs.foundationdb.opencontent.ibm.com-custom-resource-definition.yaml"
    local sa_file="${op_cli_files}/ibm-fdb-controller-manager-service-account.yaml"
    local role_file="${op_cli_files}/ibm-fdb-manager-role-role.yaml"
    local role_binding_file="${op_cli_files}/ibm-fdb-manager-rolebinding-role-binding.yaml"
    local deployment_file="${op_cli_files}/ibm-fdb-controller-manager-deployment.yaml"

    local base_crd_file1="${op_cli_files}/foundationdbbackups.apps.foundationdb.org-custom-resource-definition.yaml"
    local base_crd_file2="${op_cli_files}/foundationdbclusters.apps.foundationdb.org-custom-resource-definition.yaml"
    local base_crd_file3="${op_cli_files}/foundationdbrestores.apps.foundationdb.org-custom-resource-definition.yaml"
    local base_sa_file="${op_cli_files}/apple-fdb-controller-manager-service-account.yaml"
    local base_role_file="${op_cli_files}/apple-fdb-manager-role-role.yaml"
    local base_role_binding_file="${op_cli_files}/apple-fdb-manager-rolebinding-role-binding.yaml"
    local base_deployment_file="${op_cli_files}/apple-fdb-controller-manager-deployment.yaml"


    echo "-------------Uninstalling operator-------------"
    # Verify expected yaml files for uninstall and delete resources for each
    [[ -f "${deployment_file}" ]] && { sed <"${deployment_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${role_file}" ]] && { sed <"${role_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${role_binding_file}" ]] && { sed <"${role_binding_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${sa_file}" ]] && { sed <"${sa_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${base_deployment_file}" ]] && { sed <"${base_deployment_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${base_role_file}" ]] && { sed <"${base_role_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${base_role_binding_file}" ]] && { sed <"${base_role_binding_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }
    [[ -f "${base_sa_file}" ]] && { sed <"${base_sa_file}" "s|replace-namespace|${namespace}|g" | $kubernetesCLI delete ${dryRun} --ignore-not-found=true -n "${namespace}" -f - ; }

    # delete crds
    if [[ $deleteCRDs -eq 1 ]]; then
        echo "deleting crd"
        $kubernetesCLI delete -f "${ibm_fdb_cluster_crd_file}" --ignore-not-found=true ${dryRun}
        $kubernetesCLI delete -f "${ibm_fdb_controller_config_crd_file}" --ignore-not-found=true ${dryRun}
        $kubernetesCLI delete -f "${base_crd_file1}" --ignore-not-found=true ${dryRun}
        $kubernetesCLI delete -f "${base_crd_file2}" --ignore-not-found=true ${dryRun}
        $kubernetesCLI delete -f "${base_crd_file3}" --ignore-not-found=true ${dryRun}
        # Don't delete FoundationDB CRDs to avoid affecting other services using FoundationDB
    fi
}
