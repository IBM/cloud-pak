# Name

IBM&reg; Data Replication on Cloud

# Introduction

## Summary

* IBM Data Replication on Cloud is a multi-tenant managed service for moving data in real time across short or large distances between data containers. 

## Features

* Supports CREATE TABLE, ALTER TABLE ALTER COLUMN, and DROP TABLE data definition language
* Automatically maps from origin type to semantically equivalent destination type;
* Uses a store and forward architecture to efficiently exploit network over distance;
* Auto-scales to match client workload;

# Details

## Prerequisites

- OpenShift Version >= 4.12
- IBM Cloud Pak for Data >= 5.1.0
- Common Core Services (CCS) >= 5.1.0

### Resources Required

See [Details](https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=requirements-hardware)

# Installing

The installation includes the following major steps:

1. Configuring your cluster to pull Cloud Pak for Data images
2. Configuring an image content source policy
3. Creating the catalog source
4. Creating operator subscriptions
5. Creating a custom resource


## Configuration

* To scale Data Replication services, you can specify spec.scaleConfig in the Data Replication custom resource to small, medium, or large.

### SecurityContextConstraints Requirements
_WRITER NOTES:  Replace the Predefined SCC Name and SCC Definition with the required values in your chart.  _

This chart requires a SecurityContextConstraints to be bound to the target namespace prior to installation. To meet this requirement there may be cluster scoped as well as namespace scoped pre and post actions that need to occur.

The predefined SecurityContextConstraints name: `anyuid` has been verified for this chart, if your target namespace is bound to this SecurityContextConstraints resource you can proceed to install the chart.

This chart also defines a custom SecurityContextConstraints which can be used to finely control the permissions/capabilities needed to deploy this chart. You can enable this custom SecurityContextConstraints resource using the supplied instructions/scripts in the pak_extension pre-install directory.

- From the user interface, you can copy and paste the following snippets to enable the custom SecurityContextConstraints
  - Custom SecurityContextConstraints definition:
    ```
    apiVersion: security.openshift.io/v1
    kind: SecurityContextConstraints
    metadata:
      name: ibm-chart-dev-scc
    readOnlyRootFilesystem: false
    allowedCapabilities:
    - CHOWN
    - DAC_OVERRIDE
    - SETGID
    - SETUID
    - NET_BIND_SERVICE
    seLinux:
      type: MustRunAs
    supplementalGroups:
      type: RunAsAny
    runAsUser:
      type: RunAsAny
    fsGroup:
      rule: RunAsAny
    volumes:
    - configMap
    - secret

## Storage

Each Data Replication instance requires a minimum of 20GB allocated or more (each instance is comprised of two engine replicas which require 10GB each). Installation creates automatically a single instance, requiring an initial installation minimum of 20GB.

Data Replication supports the following storage classes:
- NFS: managed-nfs-storage


## Limitations

- Only the`x86-64` platform is supported by this operator.


## Documentation

* Product documentation for IBM Data Replication can be found [here]())
