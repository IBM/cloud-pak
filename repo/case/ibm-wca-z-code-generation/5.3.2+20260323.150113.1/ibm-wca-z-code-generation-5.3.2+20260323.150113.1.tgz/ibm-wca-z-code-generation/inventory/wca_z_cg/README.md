# IBM Watsonx Code Assistant for Z - Code Generation

Inventory: `wca_z_cg`