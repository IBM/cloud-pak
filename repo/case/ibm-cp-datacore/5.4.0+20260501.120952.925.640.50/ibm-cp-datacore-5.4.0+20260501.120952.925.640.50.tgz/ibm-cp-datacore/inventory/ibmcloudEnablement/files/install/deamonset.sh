#!/bin/bash

cat << EOF | oc create -f -
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: update-docker-config
  namespace: kube-system
  labels:
    app: update-docker-config
spec:
  selector:
    matchLabels:
      name: update-docker-config
  template:
    metadata:
      labels:
        name: update-docker-config
    spec:
      initContainers:
        - command: ["/bin/sh", "-c"]
          args:
            - >
              echo "Checking if RHEL or RHCOS host";
              [[ -s /docker-config/var/lib/kubelet/config.json  ]] && CONFIG_PATH=/docker-config/var/lib/kubelet/config.json || CONFIG_PATH=/docker-config/var/lib/kubelet/config.json;
              echo "Backing up or restoring config.json";
              [[ -s /docker-config/var/lib/kubelet/config.json ]] && cp /docker-config/var/lib/kubelet/config.json /docker-config/var/lib/kubelet/config.json-bkp || cp  /docker-config/var/lib/kubelet/config.json-bkp /docker-config/var/lib/kubelet/config.json;
              echo "Merging secret with config.json";
              /host/usr/bin/jq -s '.[0] * .[1]' /docker-config/var/lib/kubelet/config.json /auth/.dockerconfigjson > /docker-config/var/lib/kubelet/config.tmp;
              mv /docker-config/var/lib/kubelet/config.tmp /docker-config/var/lib/kubelet/config.json;
              echo "Sending signal to reload crio config";
              pidof crio;
              kill -1 \$(pidof crio)
          image: icr.io/ibm/alpine:latest
          imagePullPolicy: IfNotPresent
          name: updater
          resources: {}
          securityContext:
            privileged: true
          volumeMounts:
            - name: docker-auth-secret
              mountPath: /auth
            - name: docker
              mountPath: /docker-config
            - name: bin
              mountPath: /host/usr/bin
            - name: lib64
              mountPath: /lib64
      containers:
        - resources:
            requests:
              cpu: 0.01
          image: icr.io/ibm/alpine:latest
          name: sleepforever
          command: ["/bin/sh", "-c"]
          args:
            - >
              while true; do
                sleep 100000;
              done
      hostPID: true
      volumes:
        - name: docker-auth-secret
          secret:
            secretName: docker-auth-secret
        - name: docker
          hostPath:
            path: /
        - name: bin
          hostPath:
            path: /usr/bin
        - name: lib64
          hostPath:
            path: /lib64
            hostPathType: Directory
EOF
