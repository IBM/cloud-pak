#!/bin/bash
#******************************************************************************
# Licensed Materials - Property of IBM
# (c) Copyright IBM Corporation 2020. All Rights Reserved.
#
# Note to U.S. Government Users Restricted Rights:
# Use, duplication or disclosure restricted by GSA ADP Schedule
# Contract with IBM Corp.
#******************************************************************************

# LOGIN
printf "%s" "$KUBECONFIG_VALUE" > ./kubeconfig.json
printf "%s" "$KUBECONFIG_PEM_VALUE" > ./ca.pem

# Clean up pem file contents
sed -i 's/\\n/\n/g' ca.pem
sed -i 's/\"//g' ca.pem

# Arguments
export NAMESPACE=${JOB_NAMESPACE}
export CLUSTER_NAME=${JOB_CLUSTER_NAME}
export STORAGE_CLASS=${storage}
export DOCKER_USERNAME=${DOCKER_REGISTRY_USER:-ekey}
export DOCKER_REGISTRY=${DOCKER_REGISTRY:-cp.icr.io/cp/cpd}
if [[ "${ENVIRONMENT}" == "STAGING" ]]; then
  export DOCKER_REGISTRY="cp.stg.icr.io/cp/cpd"
fi
export DOCKER_REGISTRY_PASS=${DOCKER_REGISTRY_PASS}
export WKC="${wkc}"
export WML="${wml}"
export WS="${wsl}"
export DV="${dv}"
export OPENSCALE="${aiopenscale}"
export ANALYTICSENGINE="${spark}"
export DASHBOARD="${dashboard}"
export DB2WH="${db2wh}"
export RSTUDIO="${rstudio}"
export DMC="${dmc}"
export DB2OLTP="${db2oltp}"
export COGNOS_ANALYTICS="${cognos_analytics}"
export MATCH360="${match360}"
export FACTSHEET="${factsheet}"
export WS_PIPELINES="${ws_pipelines}"
export DODS="${dods}"
export BIGSQL="${bigsql}"
export PLANNING_ANALYTICS="${planning_analytics}"
export OPENPAGES="${openpages}"
export SPSS="${spss}"
export DATASTAGE_ENT="${datastage_ent}"
export WATSON_SPEECH="${watson_speech}"
export WATSON_DISCOVERY="${watson_discovery}"
export WATSON_ASSISTANT="${watson_assistant}"
export MANTAFLOW="${mantaflow}"
export CLUSTERTYPE=${PROVIDER}
export ADD_REGISTRY_SECRETS="${clusterconfig}"
export API_KEY="${apikey}"
export ENTITLEMENT_KEY="${entitlement_key}"

if [[ $ADD_REGISTRY_SECRETS == true ]]; then
        echo -e "\e[1m clusterconfig selected \e[0m"
        if [ ${API_KEY} == ""  ||  ${ENTITLEMENT_KEY} == ""]; then
        echo -e "\e[1m Since, clusterconfig is chosen as true, provide API key and Entitlement Key. These values are true only for a fresh installation of CP4D. If you are adding services to an existing CP4D instance, select false for clusterconfig. \e[0m"
        exit 0
        fi
fi

#Do not allow to update the already installed workspace
installopdeploy=`oc get deploy -n ${NAMESPACE} | grep install-operator | awk '{print $1}'`
if [[ "$installopdeploy" != "" ]]; then
	echo -e "\e[1m If you have an existing installation of Cloud Pak for Data 3.5, you cannot upgrade to Cloud Pak for Data 4.0. The initial release of Cloud Pak for Data 4.0 supports only new installations. Please Refer to IBM Cloud Pak for Data 4.0 documentation. https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=overview-whats-new \e[0m"
   exit 0
fi

#Do not allow to run if an installer pod is already running in the same namespace.
installpod=`oc get pods -n ${NAMESPACE} | grep cp4data-installer | grep -v Completed | awk '{print $1}'`
if [[ $installpod != "" ]]; then
     echo -e "\e[1m There is another installation $installpod running in the namespace ${NAMESPACE}. Please do the install once it is completed \e[0m"
     exit 0
fi

# VPC-gen2 Cluster supports ODF storage.

#Check ODF storage is configured in the cluster
if [[ ${STORAGE_CLASS} == "ODF" ]]; then
  if ! oc get sc | awk '{print $2}' | grep -q 'openshift-storage.cephfs.csi.ceph.com'; then
     echo -e "\e[1m ODF storage is not configured on this cluster. Please configure ODF first and try installing \e[0m"
     exit 1
  fi
fi

if [[ ${STORAGE_CLASS} == "ODF" ]]; then
  if ! oc get sc | awk '{print $2}' | grep -q 'openshift-storage.rbd.csi.ceph.com'; then
     echo -e "\e[1m ODF storage is not configured on this cluster. Please configure ODF first and try installing \e[0m"
     exit 1
  fi
fi


CLUSTER_NAME=$(oc get configmap cluster-info -n kube-system -o jsonpath="{.data.name}")

if oc get subscription -n ibm-common-services ibm-common-service-operator >/dev/null 2>&1; then
        echo "Bedrock already installed. Skipping config changes..."
        elif [[ $ADD_REGISTRY_SECRETS == true ]]; then

        pull_secret=$(echo -n "cp:$ENTITLEMENT_KEY" | base64 -w0)

        oc get secret/pull-secret -n openshift-config -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d | sed -e 's|:{|:{"cp.icr.io":{"auth":"'$pull_secret'"\},|' > /tmp/dockerconfig.json
        oc set data secret/pull-secret -n openshift-config --from-file=.dockerconfigjson=/tmp/dockerconfig.json


                ibmcloud config --check-version=false
                ibmcloud login --apikey ${API_KEY} > /tmp/ibmlogin.txt 
                if grep BXNIM0415E /tmp/ibmlogin.txt  > /dev/null
                then
                   echo -e "\e[1m Unable to authenticate with provided API key, Please provide valid IBM Cloud API Key and try again. \e[0m"
                   exit 1
                fi
                #./ibm-cp-datacore/inventory/ibmcloudEnablement/files/install/roks-update.sh $CLUSTER_NAME $CLUSTERTYPE
		oc create secret docker-registry docker-auth-secret --docker-server=cp.icr.io  --docker-username=cp --docker-password=$ENTITLEMENT_KEY --namespace kube-system
                ./ibm-cp-datacore/inventory/ibmcloudEnablement/files/install/deamonset.sh
                sleep 100
		oc new-project cpd-operator > /dev/null 2>&1 # create project
		oc new-project ibm-knative-events > /dev/null 2>&1 # create project ibm-knative-events
                oc create secret docker-registry ibm-entitlement-key --docker-server=cp.icr.io  --docker-username=cp --docker-password=$ENTITLEMENT_KEY --namespace cpd-operator
		oc create secret docker-registry ibm-entitlement-key --docker-server=cp.icr.io  --docker-username=cp --docker-password=$ENTITLEMENT_KEY --namespace ibm-knative-events
                oc create secret docker-registry ibm-entitlement-key --docker-server=cp.icr.io  --docker-username=cp --docker-password=$ENTITLEMENT_KEY --namespace ${NAMESPACE}
        else
        echo -e "\e[1m To propagate pull secrets to nodes, please select "true" for clusterconfig and provide your IBM Cloud API_KEY. \e[0m"
fi

echo "Back to install script"

#Create Performance Storageclass if user choses the option
if [[ ${STORAGE_CLASS} == "ibmc-file-custom-gold-gid" ]]; then
   oc get sc | grep ibmc-file-custom-gold-gid
   if [[ $? -eq 1 ]]; then
   cat << EOF | kubectl apply -f -
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  labels:
    addonmanager.kubernetes.io/mode: EnsureExists
    kubernetes.io/cluster-service: "true"
  name: ibmc-file-custom-gold-gid
parameters:
  billingType: hourly
  classVersion: "2"
  gidAllocate: "true"
  sizeIOPSRange: |-
    [20-39]Gi:[1000-1000]
    [40-79]Gi:[2000-2000]
    [80-99]Gi:[4000-4000]
    [100-499]Gi:[6000-6000]
    [500-999]Gi:[10000-10000]
    [1000-1999]Gi:[20000-20000]
    [2000-2999]Gi:[40000-40000]
    [3000-3999]Gi:[48000-48000]
    [4000-7999]Gi:[48000-48000]
    [8000-9999]Gi:[48000-48000]
    [10000-12000]Gi:[48000-48000]
  type: Performance
provisioner: ibm.io/ibmc-file
reclaimPolicy: Delete
volumeBindingMode: Immediate
EOF
fi
fi

echo "ADD_REGISTRY_SECRETS selected as $ADD_REGISTRY_SECRETS"
echo "Cluster chosen for installation is ${CLUSTER_NAME}"

#Check route for image registry if it is not created
if ! oc get route -n openshift-image-registry | awk '{print $1}'| grep -q 'image-registry'; then
  echo "Create image registry route"
  oc create route reencrypt --service=image-registry -n openshift-image-registry
else
  policy=`oc get route -n openshift-image-registry | awk '$1 == "image-registry" {print $5}'`
  if [[ $policy != "reencrypt" ]]; then
  oc delete route image-registry -n openshift-image-registry
  oc create route reencrypt --service=image-registry -n openshift-image-registry
  fi
fi

oc annotate route image-registry --overwrite haproxy.router.openshift.io/balance=source -n openshift-image-registry

# create pull secret

oc delete secret icp4d-anyuid-docker-pull -n kube-system

oc create secret docker-registry icp4d-anyuid-docker-pull -n ${NAMESPACE} --docker-server=${DOCKER_REGISTRY} --docker-username=${DOCKER_USERNAME} --docker-password=${DOCKER_REGISTRY_PASS}
oc secrets -n ${NAMESPACE} link cpdinstall icp4d-anyuid-docker-pull --for=pull
oc create secret docker-registry icp4d-anyuid-docker-pull -n kube-system --docker-server=${DOCKER_REGISTRY} --docker-username=${DOCKER_USERNAME} --docker-password=${DOCKER_REGISTRY_PASS}
oc secrets -n kube-system link cpdinstall icp4d-anyuid-docker-pull --for=pull
oc create secret docker-registry sa-${NAMESPACE} -n ${NAMESPACE} --docker-server=${DOCKER_REGISTRY} --docker-username=${DOCKER_USERNAME} --docker-password=${DOCKER_REGISTRY_PASS}

cat << EOF | kubectl apply --namespace ${NAMESPACE} -f -
---
apiVersion: v1
kind: Secret
metadata:
  name: cp4dinstaller-sensitive-data
  namespace: ${NAMESPACE}
type: Opaque
data:
  docker-registry-username: "$(echo -n ${DOCKER_USERNAME} | base64 -w0)"
  docker-registry-password: "$(echo -n ${DOCKER_REGISTRY_PASS} | base64 -w0)"
EOF

export ID=$RANDOM


cat << EOF | kubectl apply --namespace ${NAMESPACE} -f -
---
apiVersion: batch/v1
kind: Job
metadata:
  name: cloud-installer-$ID
  labels:
    app: cp4data-installer-$ID
spec:
  backoffLimit: 0
  completions: 1
  parallelism: 1
  template:
    metadata:
      labels:
        app: cp4data-installer-$ID
      annotations:
        productName: IBM Cloud Pak for Data
        productVersion: 5.4.x
    spec:
      containers:
      - env:
        - name: NAMESPACE
          value: ${NAMESPACE}
        - name: STORAGE_CLASS
          value: ${STORAGE_CLASS}
        - name: CLUSTER_NAME
          value: ${CLUSTER_NAME}
        - name: CLUSTERTYPE
          value: ${CLUSTERTYPE}
        - name: DOCKER_REGISTRY
          value: ${DOCKER_REGISTRY}
        - name: DOCKER_USERNAME
          valueFrom:
            secretKeyRef:
              name: cp4dinstaller-sensitive-data
              key: docker-registry-username
        - name: DOCKER_REGISTRY_USER
          valueFrom:
            secretKeyRef:
              name: cp4dinstaller-sensitive-data
              key: docker-registry-username
        - name: DOCKER_REGISTRY_PASS
          valueFrom:
            secretKeyRef:
              name: cp4dinstaller-sensitive-data
              key: docker-registry-password
        - name: DEPLOY_WKC
          value: "${WKC}"
        - name: DEPLOY_WS
          value: "${WS}"
        - name: DEPLOY_WML
          value: "${WML}"
        - name: DEPLOY_OPENSCALE
          value: "${OPENSCALE}"
        - name: DEPLOY_DV
          value: "${DV}"
        - name: DEPLOY_DASHBOARD
          value: "${DASHBOARD}"
        - name: DEPLOY_ANALYTICSENGINE
          value: "${ANALYTICSENGINE}"
        - name: DEPLOY_DB2WH
          value: "${DB2WH}"
        - name: DEPLOY_RSTUDIO
          value: "${RSTUDIO}"
        - name: DEPLOY_DMC
          value: "${DMC}"
        - name: DEPLOY_DB2OLTP
          value: "${DB2OLTP}"
        - name: DEPLOY_COGNOS_ANALYTICS
          value: "${COGNOS_ANALYTICS}"
        - name: DEPLOY_MATCH360
          value: "${MATCH360}"
        - name: DEPLOY_FACTSHEET
          value: "${FACTSHEET}"
        - name: DEPLOY_WS_PIPELINES
          value: "${WS_PIPELINES}"
        - name: DEPLOY_DODS
          value: "${DODS}"
        - name: DEPLOY_BIGSQL
          value: "${BIGSQL}"
        - name: DEPLOY_PLANNING_ANALYTICS
          value: "${PLANNING_ANALYTICS}"
        - name: DEPLOY_OPENPAGES
          value: "${OPENPAGES}"
        - name: DEPLOY_SPSS
          value: "${SPSS}"
        - name: DEPLOY_DATASTAGE_ENT
          value: "${DATASTAGE_ENT}"
        - name: DEPLOY_WATSON_SPEECH
          value: "${WATSON_SPEECH}"
        - name: DEPLOY_WATSON_DISCOVERY
          value: "${WATSON_DISCOVERY}"
        - name: DEPLOY_WATSON_ASSISTANT
          value: "${WATSON_ASSISTANT}"
        - name: DEPLOY_MANTAFLOW
          value: "${MANTAFLOW}"
        name: installer
        image: ${DOCKER_REGISTRY}/cp4d-installer:5.4.0-amd64
        imagePullPolicy: Always
        resources:
          limits:
            memory: "4Gi"
            cpu: 2
        command: [ "/bin/sh", "-c" ]
        args: [ "./deploy-cp4data.sh; sleep 300" ]
      serviceAccountName: cpdinstall
      imagePullSecrets:
      - name: icp4d-anyuid-docker-pull
      restartPolicy: Never
EOF
[[ $? -ne 0 ]] && exit 1

sleep 60
POD=$(kubectl get pods -n ${NAMESPACE} -l app=cp4data-installer-$ID -o jsonpath="{.items[0].metadata.name}")

if [[ ${POD} != "" ]]; then
echo "Waiting for ${POD} is running"
for ((retry=0;retry<=9999;retry++)); do
  if [[ -z "$POD" ]]; then
      echo "Waiting for installer pod to start."
      sleep 2
  else
    oc get pod ${POD} -n ${NAMESPACE} |grep '1/1'
    [[ $? -eq 0 ]] && break

    # Restart pod after 10 min
      if [[ ${retry} -eq 60 ]]; then
        echo "Restart the pod and check."
        oc describe pod ${POD} -n ${NAMESPACE}
        oc delete pod ${POD} -n ${NAMESPACE} --grace-period=0 --force
        POD=$(kubectl get pods -n ${NAMESPACE} -l app=cp4data-installer-$ID -o jsonpath="{.items[0].metadata.name}")
      fi


    # 15 min timeout
      if [[ ${retry} -eq 90 ]]; then
        echo "Timeout to wait for installer pod up and running, it could be the image pull failing."
        echo "Please use command 'oc get pod ${POD}' to check details"
        oc describe pod ${POD} -n ${NAMESPACE}
        oc logs ${POD} -n ${NAMESPACE}
        exit 1
      fi
  fi

  sleep 10
done
else
echo "Installer pod is not created yet"
oc describe job cp4data-installer-$ID
fi


sleep 3
echo "Tailing the pod log"
oc logs -n ${NAMESPACE} --follow $POD
status=`oc get pods -n ${NAMESPACE} | grep $POD | awk '{print $3}'`
if [[ $status != "Completed" ]]; then
for (( retry=0;retry<=20;retry++)); do
  oc logs -n ${NAMESPACE} $POD --tail=30 | grep -q "Installation not successful\|Access Cloud Pak for Data console using the address"
  if [[ $? -eq 1 ]]; then
  echo "Tailing the pod log"
  oc logs -n ${NAMESPACE} --follow $POD --tail=30
  else
  break
  fi
done
fi

sleep 10

#Check status of lite install operator
zen_status=$(oc get ZenService lite-cr -n ${NAMESPACE} -o jsonpath="{.status.zenStatus}")
if [[ $zen_status =~ (Complete|Completed) ]] ; then
        oppod=`oc get pods -n ibm-common-services | grep ibm-zen-operator | awk '{print $1}'`
        oc logs $oppod -n ibm-common-services | grep "Lite is installed"
exit 0
else
exit 1
fi
