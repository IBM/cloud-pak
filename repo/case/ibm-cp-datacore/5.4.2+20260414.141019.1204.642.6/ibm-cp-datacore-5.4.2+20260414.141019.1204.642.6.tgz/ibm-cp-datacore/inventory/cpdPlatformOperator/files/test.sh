#!/bin/bash

scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo $scriptDir

casePath="${scriptDir}/../../.."
echo $casePath

inventory="cpd_platform_operator"
echo "${casePath}"/inventory/"${inventory}"/resources.yaml


catsrc_file="$scriptDir/deploy/catalog-source.yaml"

catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
echo "orig - ${catsrc_image_orig}" 

registry="test-registry"
catsrc_image_registry=$(echo ${catsrc_image_orig%/*})
echo ${catsrc_image_registry}

if [[ -n ${registry} ]]; then 
    catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/.*\///")"
else 
    catsrc_image_mod=${catsrc_image_orig}
fi
echo "mod - ${catsrc_image_mod}"


 # check if catalog digest available 
image=$(echo $catsrc_image_mod | sed "s/.*\/\(.*\)/\1/g")
echo "image - $image"

imageName=$(echo $image | awk -F: '{print $1}')
echo "image name - $imageName"

imageTag=$(echo $image | awk -F: '{print $2}')
echo "image tag - $imageTag"


imageDigest=$(grep "image: $imageName$" "${casePath}"/inventory/"${inventory}"/resources.yaml -A 2 | grep digest | awk -F": " '{print $2}')
echo "image digest - $imageDigest"

# catsrc_image_mod_digest=$(echo ${catsrc_image_mod} | sed "s#\(.*\):.*#\1@${imageDigest}#g")
# sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod_digest}|g" 



install_catalog() {
   echo "-------------Installing catalog source-------------"

   local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/catalog-source.yaml

   # Verfy expected yaml files for install exit
   validate_file_exists "${catsrc_file}"

   # Apply yaml files manipulate variable input as required

   local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
   echo "orig - ${catsrc_image_orig}"  
   # replace original registry with local registry
   local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/.*\///")"
   echo "mod - ${catsrc_image_mod}"

   # check if catalog digest available 
   image=$(echo $catsrc_image_mod | sed "s/.*\/\(.*\)/\1/g")
   imageName=$(echo $image | awk -F: '{print $1}')
   imageTag=$(echo $image | awk -F: '{print $2}')
   imageDigest=$(grep "image: $imageName$" "${casePath}"/inventory/resources.yaml -A 2 | grep digest | awk -F": " '{print $2}')

   # apply catalog source
   if [[ ! -z "$imageDigest" ]];then
       catsrc_image_mod_digest=$(echo ${catsrc_image_mod} | sed "s#\(.*\):.*#\1@${imageDigest}#g")
       sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod_digest}|g" | $kubernetesCLI apply -f -
   else
       sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | $kubernetesCLI apply -f -
   fi 
}