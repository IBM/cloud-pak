#!/usr/bin/env bash
#
# (C) Copyright IBM Corp. 2020  All Rights Reserved.
#
# Script install Couchdb Operator through the Operator Lifecycle Manager (OLM) or via command line (CLI)
# application of kubernetes manifests in both an online and offline airgap environment.  This script can be invoked using
# `cloudctl`, a command line tool to manage Container Application Software for Enterprises (CASEs), or directly on an
# uncompressed CASE archive.  Running the script through `cloudctl case launch` has added benefit of pre-requisite validation
# and verification of integrity of the CASE.  Cloudctl download and usage istructions are available at [github.com/IBM/cloud-pak-cli](https://github.com/IBM/cloud-pak-cli).
#
# Pre-requisites:
#   oc or kubectl installed
#   sed installed
#   CASE tgz downloaded & uncompressed
#   authenticated to cluster
#
# Parameters are documented within print_usage function.

# ***** GLOBALS *****

# ----- DEFAULTS -----

# Command line tooling & path
kubernetesCLI="oc"
scriptName=$(basename "$0")
scriptDir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Script invocation defaults for parms populated via cloudctl
action="install-operator"
caseJsonFile=""
casePath="${scriptDir}/../../.."
instance=""
inventory="cpdPlatformOperator"

# - optional parameter / argument defaults
dryRun=""
deleteCRDs=0
namespace=""
registry=""
pass=""
secret=""
user=""
inputcasedir=""
cr_system_status="betterThanYesterday"
recursive_catalog_install=0

# - variables specific to catalog/operator installation
caseCatalogName="cpd-platform"
catalogNamespace="openshift-marketplace"
channelName="stable-v1"
catalogDigest=":latest"

# - additional variables
storageclass=""


# ***** ACTIONS *****

# ----- INSTALL ACTIONS -----

install_operator_group() {
    echo "-------------Installing operator group-------------"
    sed -i "s/REPLACE_NAMESPACE/${namespace}/g" ${casePath}/inventory/${inventory}/files/deploy/operator-group.yaml
    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator-group.yaml -n ${namespace}
}

override_catalog_apply() {
    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/catalog-source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
    echo "orig - ${catsrc_image_orig}"  
    # replace original registry with local registry
    if [[ -n ${registry} ]]; then 
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/.*\///")"
    else 
        local catsrc_image_mod=${catsrc_image_orig}
    fi
    echo "mod - ${catsrc_image_mod}"

    # check if catalog digest available 
    image=$(echo $catsrc_image_mod | sed "s/.*\/\(.*\)/\1/g")
    imageName=$(echo $image | awk -F@ '{print $1}')
    imageTag=$(echo $image | awk -F@ '{print $2}')
    imageDigest=$(grep "$imageName$" "${casePath}"/inventory/"${inventory}"/resources.yaml -A 2 | grep digest | awk -F": " '{print $2}')

    # apply catalog source
    if [[ ! -z "$imageDigest" ]];then
        catsrc_image_mod_digest="$(echo ${catsrc_image_mod} | cut -d @ -f 1)@$imageDigest"
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod_digest}|g" | $kubernetesCLI apply -f -
    else
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | $kubernetesCLI apply -f -
    fi 
}

# Installs the catalog source and operator group
install_catalog() {
    echo "-------------Installing catalog source-------------"
    validate_install_catalog

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/deploy/catalog-source.yaml

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')
    echo "orig - ${catsrc_image_orig}"  
    # replace original registry with local registry
    if [[ -n ${registry} ]]; then 
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | cut -d '/' -f 2-)"
    else 
        local catsrc_image_mod=${catsrc_image_orig}
    fi
    echo "mod - ${catsrc_image_mod}"

    # check if catalog digest available 
    image=$(echo $catsrc_image_mod | cut -d "/" -f2-)
    imageName=$(echo $image | awk -F@ '{print $1}')
    imageTag=$(echo $image | awk -F@ '{print $2}')
    imageDigest=$(grep "$imageName$" "${casePath}"/inventory/"${inventory}"/resources.yaml -A 2 | grep digest | awk -F": " '{print $2}')

    # apply catalog source
    if [[ "$dryRun" == "--dry-run" ]];then
        dryRun="--dry-run=server -o yaml"
    fi
    if [[ ! -z "$imageDigest" ]];then
        catsrc_image_mod_digest="$(echo ${catsrc_image_mod} | cut -d @ -f 1)@$imageDigest"
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod_digest}|g" | $kubernetesCLI apply ${dryRun} -f -
    else
        sed <"${catsrc_file}" "s|${catsrc_image_orig}|${catsrc_image_mod}|g" | $kubernetesCLI apply ${dryRun} -f -
    fi 
}

# Install utilizing default OLM method
install_operator() {

    validate_install_args
    echo "-------------Installing via OLM-------------"
    opgroup=$(oc get operatorgroup)
    if [[ -z ${opgroup} ]]; then
        install_operator_group
    else
        echo "operatorGroup already exists, skipping create"
    fi

    # # link secret in openshift-marketplace
    # if [[ "$secret" != "" ]]; then
    #    $kubernetesCLI get secret ${secret} -n ${namespace} --export -o yaml | $kubernetesCLI apply -n openshift-marketplace -f -
    #    $kubernetesCLI secrets link serviceaccount/default ${secret} --for=pull -n openshift-marketplace
    #    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source-staging.yaml
    # else
    #    $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/install/catalog-source.yaml
    # fi

    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/catalog-source.yaml
    # install_catalog
    override_catalog_apply

	echo "Wait for catalog installation to complete"
	sleep 30

	$kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/subscription.yaml -n ${namespace}
    echo "Wait for subscription to complete"
	sleep 60
	
    # $kubernetesCLI apply -f "${casePath}"/inventory/"${inventory}"/files/deploy/service_account.yaml -n ${namespace}

    # if [[ "$secret" != "" ]]; then
    #    $kubernetesCLI secrets link serviceaccount/ibm-zen-operator-serviceaccount ${secret} --for=pull -n ${namespace} 
    # fi
    # # restart pod to refresh secret
	# oc delete pod -l control-plane=cpd

}

# install operand custom resources
apply_custom_resources() {

cat << EOF | oc apply -f -
apiVersion: cpd.ibm.com/v1
kind: Ibmcpd
metadata:
  name: ibmcpd-cr
  namespace: ${namespace}
spec:
  license:
    accept: true
  storageClass: managed-nfs-storage
  version: "4.0.0"
  storageClass: ${storageclass}
EOF
    
}


# ----- UNINSTALL ACTIONS -----

# deletes the catalog source and operator group
uninstall_catalog() {
    echo "-------------Uninstalling catalog-------------"
    #TODO: may need to remove csv
    if [[ "$dryRun" == "--dry-run" ]];then
        dryRun="--dry-run=server"
    fi
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/subscription.yaml ${dryRun}
    $kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/operator-group.yaml ${dryRun}
	$kubernetesCLI delete -f "${casePath}"/inventory/"${inventory}"/files/deploy/catalog-source.yaml ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator via OLM-------------"
	
	uninstall_catalog
    delete_resources
}

delete_resources() {

    echo "-------------Deleting operator resources-------------"
    $kubernetesCLI delete secret "${secret}" --ignore-not-found=true
    $kubernetesCLI delete secret ibm-entitlement-key --ignore-not-found=true
}


# ***** END ACTIONS *****

# Verifies that we have a connection to the Kubernetes cluster
check_kube_connection() {
    # Check if default oc CLI is available and if not fall back to kubectl
    command -v $kubernetesCLI >/dev/null 2>&1 || { kubernetesCLI="kubectl"; }
    command -v $kubernetesCLI >/dev/null 2>&1 || { err_exut "No kubernetes cli found - tried oc and kubectl"; }

    # Query apiservices to verify connectivity
    if ! $kubernetesCLI get apiservices >/dev/null 2>&1; then
        # Developer note: A kubernetes CLI should be included in your prereqs.yaml as a client prereq if it is required for your script.
        err_exit "Verify that $kubernetesCLI is installed and you are connected to a Kubernetes cluster."
    fi
}

