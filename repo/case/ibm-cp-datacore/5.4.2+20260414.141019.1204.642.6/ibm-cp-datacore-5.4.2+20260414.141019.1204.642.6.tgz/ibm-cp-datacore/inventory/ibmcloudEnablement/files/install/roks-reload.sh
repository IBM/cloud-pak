#!/bin/bash
#
# Reload worker nodes in a cluster

cluster=$1
workers=${@:2}
if [[ -z "${cluster}" ]]; then
    echo "Usage: $0 <cluster> <workers...>" >&2
    exit 2
fi

function get_state {
    worker=$1
    ibmcloud ks worker get -s --cluster ${cluster} --worker ${worker} --json | jq -r '.state' | tr '[:upper:]' '[:lower:]'
}

function reload {
    worker=$1

    # this is the name under which k8s knows the node
    private_ip=$(ibmcloud ks worker get -s --cluster ${cluster} --worker ${worker} --json | jq -r .privateIP)
    echo "Reloading node ${worker} (${private_ip}) ..."

    # initiate reload
    kubectl drain ${private_ip} --force --ignore-daemonsets --delete-local-data
    ibmcloud ks worker reload -s -f --cluster ${cluster} --worker ${worker}

    # wait 30 min for reloading to complete
    reloaded=false
    (( end_time=SECONDS+1800 ))
    while (( SECONDS < end_time )); do
        time=$(date +'%H:%M:%S')
        state=$(get_state ${worker})
        echo "${time} ${state}"
        case ${state} in
            normal)
                if ${reloaded}; then
                    break
                fi
                ;;
            reloading|reload_pending)
                reloaded=true
                ;;
            reload_failed)
                break
                ;;
        esac
        sleep 5
    done

    state=$(get_state ${worker})
    if [[ ${state} != normal ]]; then
        echo "Failed to reload node ${worker}" >&2
        return 1
    fi

    # reopen for business
    kubectl uncordon ${private_ip}
}

if [[ -z "${workers}" ]]; then
    workers=$(ibmcloud ks worker ls -s --cluster ${cluster} --json | jq -r '.[].id')
fi

# it would be nice to do more than one at a time but you can't have more than 20%
# of the cluster down for reloading and for our small clusters that means just one
failures=false
for worker in ${workers}; do
    if ! reload ${worker}; then
        failures=true
    fi
done

if ${failures}; then
    echo "Not all nodes could be reloaded" >&2
    exit 1
fi
