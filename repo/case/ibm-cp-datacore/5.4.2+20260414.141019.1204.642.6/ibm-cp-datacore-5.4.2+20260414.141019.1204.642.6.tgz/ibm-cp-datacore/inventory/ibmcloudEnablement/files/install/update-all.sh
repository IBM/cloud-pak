#!/bin/bash

cd $(dirname $0)
CUR_DIR=$(pwd)
#/bin/bash ${CUR_DIR}/update-registries-conf.sh ${CUR_DIR}/registries.conf
/bin/bash ${CUR_DIR}/update-config-json.sh ${CUR_DIR}/config.json
exit 0
