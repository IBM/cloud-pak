#!/bin/bash

echo -e "\e[1m Uninstallation of Cloud Pak for Data 4.0 does not clean up the services, install operators and catalog source created during the installation. Please Refer to Uninstalling Cloud Pak for Data section, for complete Uninstallation. https://www.ibm.com/docs/en/cloud-paks/cp-data/4.0?topic=installing-uninstalling-cloud-pak-data  \e[0m"

