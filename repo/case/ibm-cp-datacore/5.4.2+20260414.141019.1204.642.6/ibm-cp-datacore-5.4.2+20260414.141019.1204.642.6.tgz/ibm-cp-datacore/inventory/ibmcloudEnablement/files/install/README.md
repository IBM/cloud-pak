You can specify which services you want to install in Cloud Pak for Data. For each service that you want to install, set the value of the parameter to `true`.

The default value for each service is set to `false`. The Cloud Pak for Data Control Pane is installed by default if you do not specify any services to install.

If you have already configured the global image pull secret with the necessary credentials and worker nodes are reloaded, you can skip configchanges and apikey parameters.

To configure image pull secrets on the cluster, set the value of configchanges to `Required` and provide your `IBM Cloud API Key` in the apikey.

After you click **Install**, you are redirected to the workspace to track and manage your installation. In the workspace, you can find the URL for IBM Cloud Pak for Data, which you can access after the installation is complete.
