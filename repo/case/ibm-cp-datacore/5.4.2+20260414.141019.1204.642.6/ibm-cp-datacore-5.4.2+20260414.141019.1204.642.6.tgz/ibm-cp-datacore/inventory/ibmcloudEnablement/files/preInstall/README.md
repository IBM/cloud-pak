#### Prerequisites
This task must be completed by a Red Hat OpenShift cluster administrator. The administrator must have an [access]( https://cloud.ibm.com/docs/openshift?topic=openshift-users) policy in IBM Cloud Identity and Access Management that has an Operator role or higher.

#### Changes applied
The script makes the following changes to your Red Hat OpenShift cluster:

*  Creates the security context constraints that are required for Cloud Pak for Data.
*  Grants the security context constraints to the service accounts that are required for Cloud Pak for Data.

