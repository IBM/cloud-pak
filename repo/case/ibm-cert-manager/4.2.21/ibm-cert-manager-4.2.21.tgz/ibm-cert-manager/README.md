# Name

IBM&reg; Cert Manager

# Introduction

## Summary

* This is a CASE for IBM Cert Manager Operator which is used to deploy cert-manager service.
* Cert Manager is a Kubernetes add-on to automate the management and issuance of TLS certificates from various issuing sources.
* You can use the your product cert-manager to create and mount a certificate to a Kubernetes Deployment, StatefulSet, or DaemonSet. You can also create and add a certificate to a Kubernetes Ingress.
* For more details on cert-manager, visit [IBM Cert Manager](https://www.ibm.com/support/knowledgecenter/SSHKN6/cert-manager/3.5.0/cert_manager.html) or [cert-manager community documentation](https://www.ibm.com/links?url=https%3A%2F%2Fcert-manager.readthedocs.io%2Fen%2Flatest%2F).
* For details on cert-manager operator, see [IBM Cert Manager Operator Github Repository](https://github.com/IBM/ibm-cert-manager-operator).

## Features

* Issues certificates from a variety of certificate issuing sources such as Let’s Encrypt, HashiCorp Vault, Venafi, a simple signing key pair, or self signed
* Ensures certificates are valid and up to date
* Attempts renewal of certificates at a configured time before expiry

# Details

## Prerequisites

* Kubernetes 1.18+ must be installed.
* OpenShift 4.5+ must be installed.

### Resources Required

* Describe Minimum System Resources Required

Minimum scheduling capacity:

| Software  | Memory (GB) | CPU (cores) | Disk (GB) | Nodes |
| --------- | ----------- | ----------- | --------- | ----- |
| Controller  | .300     | .100        |          | 1     |
| Webhook     | .300     | .100        |           | 1 |
| CA Injector | .300     | .100        |           | 1     |
| **Total** |    1.2     | .4          |           |       |

# PodSecurityPolicy Requirements

Red Hat OpenShift Container Platform (OCP) supports equivalent functionality using SecurityContextConstraints (SCC).  PodSecurityPolices are NOT used on OpenShift.  They can be installed, but OCP does not yet enforce them (the PodAdmissionController is not enabled).

### PodSecurityPolicy Requirements

Custom PodSecurityPolicy definition:

```
See Red Hat OpenShift SecurityContextConstraints Requirements
```

# SecurityContextConstraints Requirements

The Platform API service requires running with the OpenShift Container Platform 4.3 default privileged Security Context Constraints (SCCs).

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
apiVersion: security.openshift.io/v1
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: >-
      restricted denies access to all host features and requires pods to be run
      with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated
      users.
  name: cert-manager-restricted
allowedCapabilities: null
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowPrivilegeEscalation: true
defaultAddCapabilities: null
fsGroup:
  type: MustRunAs
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
  - KILL
  - MKNOD
  - SETUID
  - SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
volumes:
  - configMap
  - downwardAPI
  - emptyDir
  - persistentVolumeClaim
  - projected
  - secret
users: []

```

For more information about the OpenShift Container Platform Security Context Constraints, see [Managing Security Context Constraints](https://docs.openshift.com/container-platform/4.3/authentication/managing-security-context-constraints.html).

# Installing

For installation and configuration, see the [IBM Cloud Platform Common Services documentation](http://ibm.biz/cpcsdocs).

## Configuration

* See the link provided in `Installing` section for configuration i.e. [IBM Cloud Platform Common Services documentation](http://ibm.biz/cpcsdocs).

## Storage

All state is stored in the Kubernetes API server and persisted in etcd. This includes certificates, issuers, clusterissuers, certificate secrets.

## Limitations

The certificate manager service (operand) is a singleton. Do not run more than one instance of cert-manager-controller within the same cluster.

## Documentation

* [IBM Cert Manager Operator Github Repository](https://github.com/IBM/ibm-cert-manager-operator)
* [IBM Cloud Platform Common Services documentation](http://ibm.biz/cpcsdocs)

## SecurityContextConstraints Requirements

The cert-manager service supports running under the OpenShift Container Platform default restricted security context constraints.