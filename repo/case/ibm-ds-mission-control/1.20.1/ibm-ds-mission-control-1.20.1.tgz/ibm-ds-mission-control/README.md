# IBM DataStax Mission Control CPE CASE

Cloud Pak Extension (CPE) CASE package for publishing Mission Control container images to production registry.

## Purpose

This CASE package is used exclusively for image publication through the CPE delivery pipeline. It does **not** include Helm charts or deployment manifests.

## Key Differences from SWH CASE

- **Image-only**: No Helm charts included
- **Production coordinates**: Uses `cp.icr.io/cp/ibm-ds-mission-control/*` registry
