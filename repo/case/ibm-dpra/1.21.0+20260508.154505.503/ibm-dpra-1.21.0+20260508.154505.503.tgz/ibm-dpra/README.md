# Name

ibm-dpra-case-bundle&reg;

# Introduction

IBM Data Privacy Risk Assessment for Cloud Pak for Data (DPRA) is a privacy-centric risk detection application that enables you to seamlessly measure privacy risks in datasets of any size. The application performs statistical analysis on datasets to objectively quantify privacy risks and delivers standardized risk-scoring metrics through a unified dashboard. 

# Details
## Prerequisites 
### Install Rabbit MQ operator
```
kubectl apply -f "https://github.com/rabbitmq/cluster-operator/releases/latest/download/cluster-operator.yml"
```

### Create CPD Auth secret to authenticate to CPD UI 
```
kubectl create secret generic truata-cpd-secret --from-literal=username=<cpd_username> --from-literal=password=<cpd_password> -n <namespace>
```

### Recommended Storage Providers

Portworx and OCS are the recommended storage providers and Portworx provides passive enryption features.

### Resources Required

| Software | Storage | 
| ----------- | ----------- | 
| Minimum memory |      2GB       |
| Minimum CPU |      1 vCPU       |
| Minimum storage |      100 GB       |

# PodSecurityPolicy Requirements
Custom PodSecurityPolicy definition:
```
```

This release is only for OpenShift, and uses SecurityContextConstraints

# SecurityContextConstraints Requirements
Custom SecurityContextConstraints definition:
```
```

No custom SCC is used. This case bundle uses the "restricted" default SCC:

```
allowHostDirVolumePlugin: false
allowHostIPC: false
allowHostNetwork: false
allowHostPID: false
allowHostPorts: false
allowPrivilegedContainer: false
allowedCapabilities: []
apiVersion: v1
defaultAddCapabilities: []
fsGroup:
  type: MustRunAs
groups:
- system:authenticated
kind: SecurityContextConstraints
metadata:
  annotations:
    kubernetes.io/description: restricted denies access to all host features and requires
      pods to be run with a UID, and SELinux context that are allocated to the namespace.  This
      is the most restrictive SCC and it is used by default for authenticated users.
  creationTimestamp: null
  name: restricted
priority: null
readOnlyRootFilesystem: false
requiredDropCapabilities:
- KILL
- MKNOD
- SYS_CHROOT
- SETUID
- SETGID
runAsUser:
  type: MustRunAsRange
seLinuxContext:
  type: MustRunAs
supplementalGroups:
  type: RunAsAny
volumes:
- configMap
- downwardAPI
- emptyDir
- persistentVolumeClaim
- projected
- secret
```



# Installing
## Supported installModes
```
  installModes:
  - supported: true
    type: OwnNamespace
  - supported: true
    type: SingleNamespace
  - supported: true
    type: MultiNamespace
  - supported: true
    type: AllNamespaces
```
## Installing the product
This operator can be installed through either:
- Case bundles
- Air-gapped cluster
### To install operator with CASE bundle
```
cloudctl case launch --case ibm-dpra.tgz  --namespace openshift-marketplace --inventory ibmDpraOperator  -t 1 --action installCatalog --args "--recursive --inputDir ."

cloudctl case launch --case ibm-dpra.tgz --namespace ibm-common-services  --inventory ibmDpraOperator  -t 1 --action installOperator --args "--recursive --inputDir ."
```

### To install from air gapped cluster
1. Mirror images to the airgap environment
```
cloudctl case launch  --case ibm-dpra.tgz --namespace <target namespace> --inventory ibmDpraOperator -t 1 --action mirror-images --args "--registry <target-registry> --inputDir <directory>"
```
2. Create global image pull secret for target registry.
3. Create ImageContentSourcePolicy
```bash
cloudctl case launch --case ibm-dpra.tgz --namespace <target namespace>  --inventory ibmDpraOperator --action configure-cluster-airgap --args "--registry <target-registry> --inputDir <directory>" 
```
4. Install catalog source in the openshift-marketplace namespace
```
cloudctl case launch --case ibm-dpra.tgz --namespace openshift-marketplace --inventory ibmDpraOperator -t 1 --action install-catalog --args "--registry <target-registry> --inputDir <directory>"
```
5. Install subscription
```
cloudctl case launch --case ibm-dpra.tgz --namespace ibm-common-services  --inventory ibmDpraOperator  -t 1 --action installOperator --args "--registry <target-registry> --inputDir <directory>"
```

### Install the DPRA service
```
cat <<EOF |oc apply -f -
apiVersion: dpra.truata.com/v1
kind: DpraService
metadata:
  name: truata-calibrate
  namespace: zen
spec:
  block_storage_class: nfs-client                                                #depends on the storage provider
  file_storage_class:  nfs-client                                                #depends on the storage provider
  calibrate_namespace: zen
  license:
    accept:        true
  spark_instance_version: 4.5.0
  dpra_storage_size:      2Gi
  version:         1.0.0
  storage_size: 2Gi
EOF

```

## Verifying the product
### Custom Resource Status
<b>Completed</b>: The component is running and ready to use.</br>
<b>Failed</b>: The component failed. Check the operator logs for errors.</br>
<b>InProgress</b>: The component is being installed or updated and is not available to use.</br>

## Uninstalling the product
### Cleanup any previous installs (if applicable)
```
oc delete dpraservice --all -n zen
oc delete csv dpra-operator.v1.0.0 -n ibm-common-services
oc delete sub ibm-cpd-dpra-operator-catalog-subscription -n ibm-common-services
oc delete operator dpra-operator.ibm-common-services -n ibm-common-services
oc delete catalogsource ibm-cpd-dpra-operator-catalog -n openshift-marketplace
```
### Manually delete any existing Spark instance & volumes through CPD UI (if applicable)
For example, delete 1 spark instance and 2 spark-related volumes through "My Instances" and "Storage Volumes" page:
```
https://cpd-zen.apps.<fyre_cluster>.cp.fyre.ibm.com/zen/#/volumes
https://cpd-zen.apps.<fyre_cluster>.cp.fyre.ibm.com/zen/#/myInstances
```

### Cleanup or remove Spark

```
oc delete ae --all -n zen
oc delete csv ibm-cpd-ae.v2.0.0 -n ibm-common-services
oc delete csv ibm-cpd-ae.v2.1.0 -n ibm-common-services
oc delete csv ibm-cpd-ae.v2.2.0 -n ibm-common-services
oc delete sub ibm-cpd-ae-operator -n ibm-common-services
oc delete operator analyticsengine-operator.ibm-common-services -n ibm-common-services
oc delete catalogsource ibm-cpd-ae-operator-catalog -n openshift-marketplace
```

## Troubleshooting 

If your sub is not creating an operator pod / csv, try saving the sub

```
oc get sub <dpra sub name> -o yaml > test
```
  
Then go to namespace openshift-operator-lifecycle-manager and delete the olm-operator pod ( so it restarts ) and go back to ibm-common-services and apply the sub again 
```
oc apply -f test
```

# Configuration

The following specs are supplied to the custom resource (CR):

| Option Name |	Required |	Default|	Description |
| ----------- | ----------- | ----------- | ----------- | 
|license.accept	|Yes	|N/A|	You must set this to "true" to accept the license terms and conditions|
|tls_extra_ca	|No	|	|Base64encoded list of PEM encoded certificate authorities for trusting non public endpoints. Generally this shouldn't be required to be set|
|license_file_b64_encoded	|No|	internal|	If you want to override the license file can base64 encode it and supply here|
|file_storage_class|	No|	nfs-client|	Can set the specific storage class for all of the non spark, ReadWriteMany, volumes for the service|
|block_storage_class|	No	|nfs-client	|Can set the specific storage class for all of the non spark ReadWriteOnly, volumes for the service|
|cpd_route_name|	No	|cpd	|The name of the route to CPD nginx|
|is_image_registry_pull_secret_required|	No	|False	|If you need to use the secret for acquiring images in an air gapped private repo situation, valid values are "True" or "False"|
|image_registry_pull_secret_name	|No	|ibm-entitlement-key	|The name of the pull secret that's used if enabled|
|image_registry_base_url_prefix	|No	|image-registry.openshift-image-registry.svc:5000/{{ calibrate_namespace }}	|Default image registry path for sourcing docker images|
|spark_storage_class	|No	|file_storage_class|	Storage class type for Spark volumes, as these are ReadWriteMany volumes, by default they inherit the file_storage_class|
|spark_volume_name	|No	|dpra-spark-volume|	The name of the spark volume used for DPRA|
|spark_instance_name	|No|	|truata-calibrate-spark-cpd	|Name of the spark instance for processing DPRA requests|
|spark_instance_version|	No|	4.5.0|	The spark instance version|
|profile_name|	No	|default|	Can use either "default" or "production"|
|scaling_profile_name|	No	|default	|Can use either "default", "production" or "oadp"|

# Limitations
- DPRA cannot be deployed more than once in a single namespace. It can, however, be deployed into different namespaces along with CPD and other prereqs.
- It is currently only supported by OpenShift 4.8, 4.10 and CPD v4.5.2.
- This service does not currently implement high availability.  You may experience downtime if your Kubernetes cluster loses a node, until pods get rescheduled.
- DPRA is currently supported only on self-managed Openshift.

# Documentation
Truata will update after release.

# Open-source dependencies sources
- rabbitmqoperator/cluster-operator:1.14.0
- rabbitmq:3.10.2-management
- rabbitmqoperator/default-user-credential-updater:1.0.2
- percona/percona-server-mongodb:5.0
- registry.connect.redhat.com/hashicorp/vault:1.10.3-ubi 
