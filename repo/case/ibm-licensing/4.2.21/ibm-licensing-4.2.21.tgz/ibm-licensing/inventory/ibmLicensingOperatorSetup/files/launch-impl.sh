# (C) Copyright IBM Corp. 2024  All Rights Reserved.
#
# This script implements/overrides the abstract functions defined in launch.sh interface

# operator specific variables
caseName=
inventory=
caseCatalogName="ibm-licensing-catalog"
catalogNamespace="openshift-marketplace"
channelName=

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # Verify expected yaml files for install exit
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml ]] && { err_exit "Missing required catalog source yaml, exiting deployment."; }
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml ]] && { err_exit "Missing required operator group yaml, exiting deployment."; }

    echo "-------------Create catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required

    local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

    # replace original registry with local registry
    local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"
    if echo "${registry}" | grep -qE "quay.io|docker.io"; then
        catsrc_image_mod="${catsrc_image_orig}"
    fi

    # apply catalog source
    sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
}


# Install utilizing default OLM method
install_operator() {
#    echo "-------------skip-------------"
    wait=30

    # Create operator group
    echo "check for any existing operator group in ${namespace} ..."
    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}' ) -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
    else
        echo "no existing operator group found"
        if [[ "$namespace" != "openshift-operators" ]]; then
            echo "-------------Create operator group-------------"
            sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${casePath}"/inventory/"${inventory}"/files/op-olm/operator_group.yaml | $kubernetesCLI apply -n "${namespace}" -f -
        fi
    fi

    # Proceed with install
    echo "-------------Installing IBM License Service via OLM-------------"
    # Verify expected yaml files for install exit
    [[ ! -f "${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml ]] && { err_exit "Missing required subscription yaml, exiting deployment."; }
    
    echo "-------------Create IBM License Service operator subscription-------------"
    sed -e "s|REPLACE_CHANNEL|${channelName}|g" -e "s|REPLACE_NAMESPACE|${namespace}|g" "${casePath}"/inventory/"${inventory}"/files/op-olm/subscription.yaml | $kubernetesCLI apply -n "${namespace}" -f -

    # - check if ibm license operator subscription created
    while true; do
      $kubernetesCLI describe sub ibm-licensing-operator-app -n ${namespace}
      $kubernetesCLI -n ${namespace} get sub ibm-licensing-operator-app &>/dev/null && break
      sleep $wait
    done

    echo "-------------Install complete-------------"
}
