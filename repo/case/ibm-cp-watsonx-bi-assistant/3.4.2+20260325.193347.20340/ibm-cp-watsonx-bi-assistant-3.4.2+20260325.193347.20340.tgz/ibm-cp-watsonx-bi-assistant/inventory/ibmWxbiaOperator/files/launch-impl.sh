# (C) Copyright IBM Corp. 2020, 2022  All Rights Reserved.
#
# This script implements/overrides the base functions defined in launch.sh
# This implementation is specific to this panamax operator

# Cognos Analytics operator specific variables
caseName="ibm-wxbia"
inventory="ibmWxbiaOperatorSetup"
caseCatalogName="ibm-cpd-wxbia-operator-catalog"
catalogNamespace="openshift-marketplace"
channelName="v3.4"
cr_system_status="betterThanYesterday"
cr_storage_class=""
cr_file_storage_class=""
cr_block_storage_class=""
cr_version="3.4.2"
cr_install_ccs="true"
cr_install_ifm="true"

# - variables specific to catalog/operator installation
#catalogNamespace="openshift-marketplace"
#couchDeployment="deployment.apps/couchdb-operator" #dependency
case_depedencies="ibm-ccs"

# parse additional dynamic args
parse_custom_dynamic_args() {
    key=$1
    val=$2
    case $key in
    --systemStatus)
        cr_system_status=$val
        ;;
    --storageClass)
        cr_storage_class=$val
        ;;
    --fileStorageClass)
        cr_file_storage_class=$val
        ;;
    --blockStorageClass)
        cr_block_storage_class=$val
        ;;
    --version)
        cr_version=$val
        ;;
    --installCCS)
        cr_install_ccs=$val
        ;;
    --installIFM)
        cr_install_ifm=$val
        ;;
    esac
}

# returns name of inventory containing setup code, given a CASE name
# this is used during the install of catalog of dependent CASE
dependent_inventory_item() {
    local case_name=$1
    case $case_name in
    ibm-ccs)
        echo "ccsSetup"
        return 0
        ;;
    *)
        echo "unknown case: $case_name"
        return 1
        ;;
    esac
}

# returns a case tgz given a dependency name
dependent_case_tgz() {
    local case_name=$1
    local input_dir=$2

    # if there are multiple versions of the case is downloaded ( this happens when same dependency
    # is requested by a different case but with a different version)
    # use the latest version
    # the below command finds files that start with dependent case name, sorts by semver field
    # note that this sort flag is only available on GNU sort ( linux versions)
    case_tgz=$(find "${input_dir}" -name "${case_name}*.tgz" | sort --reverse --version-sort --field-separator="-" | head -n1)

    if [[ -z ${case_tgz} ]]; then
        err_exit "failed to find case tgz for dependent case: ${case_name}"
    fi

    echo "${case_tgz}"
}

# ----- INSTALL ACTIONS -----

# Installs the catalog source and operator group of any dependencies
install_dependent_catalogs() {

    local dep_case=""
    if [ ! -z "$registry" ]; then
      registry_arg="--registry ${registry}"
    else
      registry_arg=""
    fi

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"

        echo "-------------Installing dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-catalog \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

# Installs the operators (native) of any dependencies
install_dependent_operators() {

    local dep_case=""
    if [ ! -z "$registry" ]; then
      registry_arg="--registry ${registry}"
    else
      registry_arg=""
    fi
    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"


        echo "-------------Installing dependent operator: ${dep_case} -------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action install-operator-native \
            --args "${registry_arg} --inputDir ${inputcasedir} --recursive ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "installing dependent catalog for '${dep_case}' failed"
        fi
    done
}

install_operator_group() {

    echo "check for any existing operator group in ${namespace} ..."

    if [[ $($kubernetesCLI get og -n "${namespace}" -o=go-template --template='{{len .items}}') -gt 0 ]]; then
        echo "found operator group"
        $kubernetesCLI get og -n "${namespace}" -o yaml
        return
    fi

    echo "no existing operator group found"

    echo "------------- Installing operator group for $namespace -------------"

    local opgrp_file="${casePath}/inventory/${inventory}/files/op-olm/operator_group.yaml"
    validate_file_exists "${opgrp_file}"

    sed <"${opgrp_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat

    echo "done"
}

# Installs the catalog source and operator group
install_catalog() {

    validate_install_catalog

    # install all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_catalogs
    fi

    echo "-------------Installing catalog source-------------"

    local catsrc_file="${casePath}/inventory/${inventory}/files/op-olm/catalog_source.yaml"

    # Verfy expected yaml files for install exit
    validate_file_exists "${catsrc_file}"

    # Apply yaml files manipulate variable input as required
    if [[ -z $registry ]]; then
        # If an additional arg named registry is NOT passed in, then just apply
#        tee >($kubernetesCLI apply ${dryRun} -f -) < "${catsrc_file}"
        sed <"${catsrc_file}" "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
    else
        # If an additional arg named registry is passed in, then adjust the name of the image and apply
        local catsrc_image_orig=$(grep "image:" "${catsrc_file}" | awk '{print$2}')

        # replace original registry with local registry
        local catsrc_image_mod="${registry}/$(echo "${catsrc_image_orig}" | sed -e "s/[^/]*\///")"

        # apply catalog source
#        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
        sed -e "s|${catsrc_image_orig}|${catsrc_image_mod}|g" "${catsrc_file}" | sed "s|REPLACE_NAMESPACE|${namespace}|g" | tee >($kubernetesCLI apply ${dryRun} -f -) | cat
    fi

    echo "done"

}

# Install utilizing default OLM method
install_operator() {
    # Verfiy arguments are valid
    validate_install_args

    # install all operators of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        install_dependent_operators
    fi

    install_operator_group

    echo "-------------Installing via OLM-------------"

    local subscription_file="${casePath}/inventory/${inventory}/files/op-olm/subscription.yaml"
    validate_file_exists "${subscription_file}"

    # check if catalog source is installed
    echo "checking if catalog source exists ..."
#    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${catalogNamespace}"; then
#        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${catalogNamespace}'"
#    fi
    if ! $kubernetesCLI get catsrc "${caseCatalogName}" -n "${namespace}"; then
        err_exit "expected catalog source '${caseCatalogName}' expected to be installed namespace '${namespace}'"
    fi

    # create subscription
    # fix namespace and channel before creating subscription
    sed -e "s|REPLACE_NAMESPACE|${namespace}|g" "${subscription_file}" | sed "s|REPLACE_CHANNEL_NAME|$channelName|g" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

parse_yaml() {
   local prefix=$2
   local s='[[:space:]]*' w='[a-zA-Z0-9_]*' fs=$(echo @|tr @ '\034')
   sed -ne "s|,$s\]$s\$|]|" \
        -e ":1;s|^\($s\)\($w\)$s:$s\[$s\(.*\)$s,$s\(.*\)$s\]|\1\2: [\3]\n\1  - \4|;t1" \
        -e "s|^\($s\)\($w\)$s:$s\[$s\(.*\)$s\]|\1\2:\n\1  - \3|;p" $1 | \
   sed -ne "s|,$s}$s\$|}|" \
        -e ":1;s|^\($s\)-$s{$s\(.*\)$s,$s\($w\)$s:$s\(.*\)$s}|\1- {\2}\n\1  \3: \4|;t1" \
        -e    "s|^\($s\)-$s{$s\(.*\)$s}|\1-\n\1  \2|;p" | \
   sed -ne "s|^\($s\):|\1|" \
        -e "s|^\($s\)-$s[\"']\(.*\)[\"']$s\$|\1$fs$fs\2|p" \
        -e "s|^\($s\)-$s\(.*\)$s\$|\1$fs$fs\2|p" \
        -e "s|^\($s\)\($w\)$s:$s[\"']\(.*\)[\"']$s\$|\1$fs\2$fs\3|p" \
        -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p" | \
   awk -F$fs '{
      indent = length($1)/2;
      vname[indent] = $2;
      for (i in vname) {if (i > indent) {delete vname[i]; idx[i]=0}}
      if(length($2)== 0){  vname[indent]= ++idx[indent] };
      if (length($3) > 0) {
         vn=""; for (i=0; i<indent; i++) { vn=(vn)(vname[i])("_")}
         printf("%s%s%s=\"%s\"\n", "'$prefix'",vn, vname[indent], $3);
      }
   }'
}

# Install utilizing default CLI method
install_operator_native() {
    # Verify arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Installing native sdk1-------------"
#    set -x
    # Verify expected yaml files for install exist
#    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
#    local manifest_file="${op_cli_files}/manifestsNativeDeploy.yaml"
#
#    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
#    sed -e "s|ibm-sample-panamax-operator-system|${namespace}|g" "${manifest_file}" | $kubernetesCLI apply ${dryRun} -n "${namespace}" -f -

    local oper_root="${casePath}/../../operators/ibm-cpd-wxbia-operator"

    local default_kustomization_file="${oper_root}/config/default/kustomization.yaml"
    validate_file_exists "${default_kustomization_file}"
    sed -i "s|namespace: .*|namespace: ${namespace}|g" ${default_kustomization_file}

    local resources_file=${casePath}/inventory/ibmCaOperatorSetup/resources.yaml
    validate_file_exists "${resources_file}"

#    local img_digest=$(sed -nz 's/\(.*image: ibm-ca-operator.*digest: \)\([a-zA-Z0-9:]*\)\(.*\)/\2/p' ${resources_file})
    eval $(parse_yaml ${resources_file})
#    set | grep resources
    if [ "${resources_resourceDefs_2}" == "image: cpopen/ibm-watsonx-bi-assistant-operator" ]; then
      local img_digest=${resources_resourceDefs_2_digest}
    else
      err_exit "Unable to find image digest in resources file: ibm-watsonx-bi-assistant-operator"
    fi

    local canonical_make_file=$(cd "${oper_root}"; pwd)
    make -C ${canonical_make_file} deploy IMG=cp.icr.io/cp/cpd/ibm-watsonx-bi-assistant-operator@${img_digest}
#    make -C ${canonical_make_file} deploy IMG=hyc-cp4d-team-cognos-analytics-docker-local.artifactory.swg-devops.com/$BUILDFF_MATRIX_IMAGE:$BUILDFF_MATRIX_VERSION
#    validate_file_exists "${canonical_make_file}"
}

# install operand custom resources
apply_custom_resources() {
    echo "-------------Applying custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/wxbia_v1_wxbiaservice.yaml

    validate_file_exists "$cr"

    local storage_class_opt=""
    local file_storage_class_opt=""
    local block_storage_class_opt=""

    if [ -n "$cr_storage_class" ]; then
        storage_class_opt="storageClass: ${cr_storage_class}"
    fi
    if [ -n "$cr_file_storage_class" ]; then
        file_storage_class_opt="fileStorageClass: ${cr_file_storage_class}"
    fi
    if [ -n "$cr_block_storage_class" ]; then
        block_storage_class_opt="blockStorageClass: ${cr_block_storage_class}"
    fi

#    sed -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g" -e "s/accept: false/accept: true/g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
#    declare -p
    sed -e "s|systemStatus.*|systemStatus: ${cr_system_status}|g"\
        -e "s/accept: false/accept: true/g"\
        -e "s|version.*|version: ${cr_version}|g"\
        -e "s|installCCS.*|installCCS: ${cr_install_ccs}|g"\
        -e "s|installIFM.*|installIFM: ${cr_install_ifm}|g"\
        -e "s|storageClass.*|${storage_class_opt}|g"\
        -e "s|fileStorageClass.*|${file_storage_class_opt}|g"\
        -e "s|blockStorageClass.*|${block_storage_class_opt}|g"\
        -e "s|storage_class.*|storage_class: ${cr_storage_class}|g" "${cr}" | tee >($kubernetesCLI apply ${dryRun} -n "${namespace}" -f -) | cat
}

# ----- UNINSTALL ACTIONS -----

uninstall_dependent_catalogs() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent catalog source: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-catalog \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

uninstall_dependent_operators() {

    local dep_case=""

    for dep in $case_depedencies; do
        local dep_case="$(dependent_case_tgz "${dep}" "${inputcasedir}")"
        echo "-------------Uninstalling dependent operator: ${dep_case}-------------"

        validate_file_exists "${dep_case}"
        local inventory=""
        inventory=$(dependent_inventory_item "${dep}")

        cloudctl case launch \
            --case "${dep_case}" \
            --namespace "${namespace}" \
            --inventory "${inventory}" \
            --action uninstall-operator-native \
            --args "--recursive --inputDir ${inputcasedir} ${dryRun:+--dryRun }" \
            --tolerance "${tolerance_val}"

        if [[ $? -ne 0 ]]; then
            err_exit "Uninstalling dependent catalog source: ${dep_case} failed"
        fi

    done
}

# deletes the catalog source and operator group
uninstall_catalog() {

    validate_install_catalog "uninstall"

    # uninstall all catalogs of subcases first
    if [[ ${recursive_action} -eq 1 ]]; then
        uninstall_dependent_catalogs
    fi

    local catsrc_file="${casePath}"/inventory/"${inventory}"/files/op-olm/catalog_source.yaml

    echo "-------------Uninstalling catalog source-------------"
    $kubernetesCLI delete -f "${catsrc_file}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via OLM
uninstall_operator() {
    echo "-------------Uninstalling operator-------------"
    # Find installed CSV
    csvName=$($kubernetesCLI get subscription "${caseCatalogName}"-subscription -o go-template --template '{{.status.installedCSV}}' -n "${namespace}" --ignore-not-found=true)
    # Remove the subscription
    $kubernetesCLI delete subscription "${caseCatalogName}-subscription" -n "${namespace}" --ignore-not-found=true ${dryRun}
    # Remove the CSV which was generated by the subscription but does not get garbage collected
    [[ -n "${csvName}" ]] && { $kubernetesCLI delete clusterserviceversion "${csvName}" -n "${namespace}" --ignore-not-found=true ${dryRun}; }

    # don't remove operator group, some other may have a dependency
    # $kubernetesCLI delete OperatorGroup "${caseCatalogName}-group" -n "${namespace}" --ignore-not-found=true

    # delete crds
#    for crdYaml in "${casePath}"/inventory/"${inventory}"/files/op-cli/*_crd.yaml; do
#        $kubernetesCLI delete -f "${crdYaml}" --ignore-not-found=true ${dryRun}
#    done
    # - dependent resources
#    $kubernetesCLI delete -n "${namespace}" "${couchDeployment}" --ignore-not-found=true ${dryRun}
    # Delete catalog source
#    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${catalogNamespace}" --ignore-not-found=true ${dryRun}
    $kubernetesCLI delete CatalogSource "${caseCatalogName}" -n "${namespace}" --ignore-not-found=true ${dryRun}
}

# Uninstall operator installed via CLI
uninstall_operator_native() {
   # Verfiy arguments are valid
    validate_install_args

    # Proceed with install
    echo "-------------Uninstalling native -------------"

    # Verify expected yaml files for install exist
#    local op_cli_files="${casePath}/inventory/${inventory}/files/op-cli"
#    local manifest_file="${op_cli_files}/manifestsNativeDeploy.yaml"
#
#    validate_file_exists "${manifest_file}"

    # Apply yaml files manipulate variable input as required
#    sed <"${manifest_file}" "s|ibm-sample-panamax-operator-system|${namespace}|g" | $kubernetesCLI delete ${dryRun} -n "${namespace}" -f -
    local oper_root="${casePath}/../../operators/ibm-cpd-wxbia-operator"

    local default_kustomization_file="${oper_root}/config/default/kustomization.yaml"
    validate_file_exists "${default_kustomization_file}"
    sed -i "s|namespace: .*|namespace: ${namespace}|g" ${default_kustomization_file}

    local canonical_make_file=$(cd "${oper_root}"; pwd)
    make -C ${canonical_make_file} undeploy
}

delete_custom_resources() {
    echo "-------------Deleting custom resources-------------"
    local cr="${casePath}"/inventory/"${inventory}"/files/wxbia_v1_wxbiaservice.yaml
    [[ ! -f ${cr} ]] && { err_exit "Missing required ${cr}, exiting deployment."; }
    $kubernetesCLI delete -n "${namespace}" -f "${cr}" --wait ${dryRun}
}

install() {
    install_operator
}

uninstall() {
    uninstall_operator
}
