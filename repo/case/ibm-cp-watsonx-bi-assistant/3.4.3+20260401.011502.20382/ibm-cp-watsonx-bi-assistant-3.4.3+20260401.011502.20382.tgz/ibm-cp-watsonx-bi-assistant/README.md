# IBM watsonx BI

https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-svc.html

# Introduction
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-svc.html

# Details
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-svc.html
## Prerequisites
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-adm-cmd.html

### Red Hat OpenShift SecurityContextConstraints Requirements

Custom SecurityContextConstraints definition:

```
...
```

### Resources Required
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-instance.html

# Installing
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-svc-install.html

## Configuration

https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-instance.html

## Storage
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-instance.html


## Limitations
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-instance.html

## Documentation
https://www.ibm.com/support/producthub/icpdata/docs/content/SSQNUZ_current/cpd/svc/cognos/wxbia/wxbia-svc.html
